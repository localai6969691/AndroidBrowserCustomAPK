#!/bin/bash
# build_plugin.sh — build lại RIÊNG module :ebookleech thành 1 file .jar
# nạp được bằng DexClassLoader. KHÔNG build lại app chính (:app), KHÔNG
# tạo APK mới, KHÔNG cần cài đè app lên máy — đây chính là quy trình
# "sửa lỗi EbookLeech mà không đụng gì tới app chính" đã hứa.
#
# CHẠY TỪ ĐÂU: thư mục gốc project (chứa settings.gradle)
# YÊU CẦU: đã cài Android SDK build-tools (có sẵn nếu đã cài Android
#          Studio), biến môi trường ANDROID_HOME trỏ đúng SDK.
#
# Sau khi chạy xong, copy file .jar sinh ra vào điện thoại (qua cáp USB/
# Google Drive/bất kỳ cách nào) tới đúng thư mục:
#   /sdcard/Android/data/com.colablive.keeper/files/plugins/
# rồi khởi động lại app (không cần cài lại .apk) — EbookLeech phiên bản
# mới có hiệu lực ngay.

set -e

MODULE_DIR="ebookleech"
OUT_DIR="$MODULE_DIR/build/outputs/plugin"
JAR_NAME="ebookleech-plugin.jar"

echo "== 1/4: Biên dịch module :ebookleech (không đụng :app) =="
./gradlew ":${MODULE_DIR}:assembleRelease"

CLASSES_DIR="$MODULE_DIR/build/intermediates/javac/release/classes"
# Với Kotlin thuần: build/tmp/kotlin-classes/release
KOTLIN_CLASSES_DIR="$MODULE_DIR/build/tmp/kotlin-classes/release"

echo "== 2/4: Tìm build-tools mới nhất để lấy d8 =="
BUILD_TOOLS_DIR=$(ls -d "$ANDROID_HOME"/build-tools/*/ | sort -V | tail -1)
D8="${BUILD_TOOLS_DIR}d8"

if [ ! -x "$D8" ]; then
    echo "LỖI: không tìm thấy d8 trong $BUILD_TOOLS_DIR — kiểm tra lại ANDROID_HOME"
    exit 1
fi

mkdir -p "$OUT_DIR"
WORK_DIR=$(mktemp -d)

echo "== 3/4: Đóng gói .class thành classes.dex bằng d8 =="
find "$KOTLIN_CLASSES_DIR" -name "*.class" > "$WORK_DIR/class_list.txt"
"$D8" --release --output "$WORK_DIR" @"$WORK_DIR/class_list.txt"

echo "== 4/4: Đóng gói classes.dex + entry-points.txt thành .jar =="
cp "$MODULE_DIR/src/main/resources/META-INF/colablive-plugin/entry-points.txt" "$WORK_DIR/entry-points.txt.tmp"
mkdir -p "$WORK_DIR/META-INF/colablive-plugin"
mv "$WORK_DIR/entry-points.txt.tmp" "$WORK_DIR/META-INF/colablive-plugin/entry-points.txt"

cd "$WORK_DIR"
zip -q -r "$JAR_NAME" classes.dex META-INF
cd - > /dev/null

cp "$WORK_DIR/$JAR_NAME" "$OUT_DIR/$JAR_NAME"
rm -rf "$WORK_DIR"

echo ""
echo "✅ Xong: $OUT_DIR/$JAR_NAME"
echo ""
echo "Bước tiếp theo:"
echo "  adb push \"$OUT_DIR/$JAR_NAME\" /sdcard/Android/data/com.colablive.keeper/files/plugins/"
echo "  (hoặc copy tay qua bất kỳ cách nào bạn quen — chỉ cần đúng thư mục trên)"
echo "  Sau đó mở lại app — EbookLeech bản mới có hiệu lực, KHÔNG cần cài lại .apk"
