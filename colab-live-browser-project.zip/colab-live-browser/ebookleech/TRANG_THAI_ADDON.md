# TRẠNG THÁI ADDON EbookLeech — cập nhật đúng theo code hiện tại

> ⚠ **CẬP NHẬT 7.98 (đọc trước):** trong dự án `colab-live-browser` addon này được **NHÚNG TRỰC TIẾP vào module `:app`** (không có module `:core`/`:ebookleech` riêng, không build `.jar`, không nạp động). Phần "1. Kiến trúc" bên dưới mô tả kiến trúc plugin dự kiến ban đầu — KHÔNG còn đúng với app thật. Chi tiết và lý do: `PROJECT_STATUS.md` của app, mục 222. Thư mục `plugin_mode_unused/` giữ lại các file build plugin chỉ để tham khảo; `settings.gradle` chỉ include `:app`.


> File này SỐNG CHUNG với addon — đóng gói kèm trong `ebookleech-addon.zip`
> mỗi lần gửi. Các file tài liệu CŨ dưới đây đã LỖI THỜI, đừng đọc nữa:
> `PROJECT_STATUS_EBOOKLEECH.md` (bundle rất cũ), `CAI_DAT.md` (bundle
> rất cũ, đã bị `EBOOKLEECH_TICH_HOP.md` + `PATCH_CO_BAN.md` thay thế cho
> phần cài đặt — phần tính năng trong đó cũng lỗi thời nốt).

---

## 1. Kiến trúc (không đổi từ các lượt trước — tóm tắt)

3 tầng: `:app` (4 feature gốc) → `:core` (tách ra, `com.android.library`,
merge vào APK — chứa `BrowserFeature`, `AppPrefs`, `PluginLoader`,
`PluginServiceLogic`/`PluginForegroundServiceProxy`,
`PluginWorkLogic`/`PluginWorker`, `FolderPickerBridge`, proxy...) →
`:ebookleech` (36 file `.kt`, `compileOnly project(':core')`, build ra
`.jar` RIÊNG, nạp động bằng `DexClassLoader`, KHÔNG merge vào APK).

**Lỗi kiến trúc đã sửa** (Service/Worker không thể sống trong `.jar` —
Android chỉ khởi tạo được từ class có sẵn trong APK): `EbookLeechServiceLogic`/
`EbookLeechWorkLogic` (trong `.jar`) implement interface, chuyển tiếp qua
`PluginForegroundServiceProxy`/`PluginWorker` (thật, trong `:core`, khai
trong `AndroidManifest.xml`). Chi tiết đầy đủ: `PluginServiceLogic.kt`.

**FileProvider authority đã sửa**: `"${applicationId}.fileprovider"`
(không phải `.provider` như bản đoán đầu tiên).

---

## 2. Danh sách 36 file `.kt` trong `ebookleech-addon.zip` — theo nhóm

| Nhóm | File |
|---|---|
| Feature entry-point | `EbookLeechFeature.kt` |
| Model | `LeechJob.kt`, `LeechChapter.kt`, `LeechImage.kt`, `LeechProject.kt`, `LeechProjectRepository.kt`, `LeechJobRepository.kt`, `CrawlCheckpoint.kt`, `CrawlCheckpointRepository.kt`, `CrawlStage.kt`, `RegexRule.kt`, `TocNode.kt`, `SitePreset.kt`, `SitePresetRepository.kt` |
| Engine (cào) | `EbookLeechCrawler.kt`, `GeckoViewEngineExt.kt`, `ChapterCache.kt`, `ContentProcessor.kt`, `ContentSpinner.kt`, `ImageDownloader.kt`, `ElementPickerBridge.kt`, `JsonPathExtractor.kt`, `ProxyPoolManager.kt`, `WordPressPublisher.kt` |
| Cào từ xa | `remote/SecureTokenStore.kt`, `remote/GitHubRemoteConfig.kt`, `remote/GitHubApiClient.kt`, `remote/RemoteCrawlRunner.kt` |
| Service | `EbookLeechService.kt` (chứa `EbookLeechServiceLogic`), `EbookLeechWorker.kt` (chứa `EbookLeechWorkLogic` + `EbookLeechWorkScheduler`), `EbookLeechProgressStore.kt`, `EbookLeechSlotRegistry.kt` |
| Điều phối | `EbookLeechScheduler.kt` |
| Xuất | `EbookExporter.kt` |
| Sao lưu | `EbookLeechBackupManager.kt` |
| UI | `EbookLeechSettingsView.kt` (2400+ dòng — toàn bộ UI) |

**File KHÔNG PHẢI `.kt`** (cào từ xa — dùng chung cho cả GitHub Actions lẫn Colab):
`remote_runner/crawler.py`, `remote_runner/requirements.txt`,
`remote_runner/colab_notebook.ipynb`.

---

## 3. Tính năng — TRẠNG THÁI THẬT

### 3.1 Cào cơ bản — ổn định từ đầu
Phase -1 (kịch bản nhiều bước) → Phase 0 (tự dò phân trang) → Phase 1
(thu link chương) → Phase 2 (cào nội dung, phát hiện Cloudflare/captcha,
dừng chờ giải tay) → Phase 3 (xuất EPUB3/TXT/HTML). Checkpoint + resume.

### 3.2 5 nợ kỹ thuật ban đầu — CẢ 5 ĐÃ XONG
- [x] MediaStore cho targetSdk ≥ 30 (`EbookExporter.publishStagingTree()`)
- [x] SAF picker cho Restore (không giới hạn đúng 1 thư mục)
- [x] Nút "Nạp .jar mới"/"Nạp lại plugin" — nạp lại KHÔNG cần khởi động lại app
- [x] Proxy per-slot — xác nhận TỰ ĐỘNG kế thừa (tab thật của khe), thêm UI hiện trạng thái + nút tự tìm
- [x] Checkpoint lưu bytes ảnh (`CrawlCheckpointRepository.persistImageBytes()`) — resume không mất ảnh nữa

### 3.3 4 tính năng KDN — CẢ 4 ĐÃ XONG
- [x] **AJAX Leech thật** — dùng thẳng JSON API làm nguồn (`JsonPathExtractor.kt`)
- [x] **Preset site** — lưu/áp dụng lại bộ selector cho site cùng kiểu. KHÔNG kèm sẵn preset thật nào — tự lưu sau khi cào thành công 1 site
- [x] **Xoay nhiều proxy** — ⚠️ CHỈ xoay GIỮA CÁC LẦN JOB MỚI khởi động, KHÔNG xoay giữa chừng 1 job đang chạy (giới hạn kiến trúc GeckoRuntime)
- [x] **Spinner chống trùng lặp** — cú pháp `{a|b|c}`, 2 `RegexRule.Kind` mới

### 3.4 Còn 1 việc để trống — có lý do rõ ràng
- [ ] Preset site chưa có preset THẬT nào dựng sẵn — cần bạn tự tạo từ
  job đã chạy thành công, hoặc cho thêm site cụ thể để không phải đoán bừa.

### 3.5 Cào từ xa — kiến trúc chung cho cả 2 backend
`RemoteCrawlRunner.kt` nhận tham số `backend` ("GITHUB" hoặc "COLAB") —
**toàn bộ phần "hàng đợi" (job-spec, checkpoint, ảnh) và logic cào
(`crawler.py`) dùng CHUNG 100%, không tách riêng theo backend** — chỉ
khác đúng ở "chỗ chạy":

| | GitHub Actions | Google Colab |
|---|---|---|
| Kích hoạt | App tự dispatch qua Actions API | Bạn tự mở link + bấm "Run all" |
| Biết còn sống | Tra trạng thái lần chạy (Actions API thật) | Không có API — dùng `heartbeat.json` riêng (xem 3.6) |
| Phải giữ gì mở | Không cần — chạy trên máy chủ GitHub | PHẢI giữ tab Colab mở (tự ngắt sau ~90 phút không tương tác) |
| Cấu hình | `☁️ Cấu hình GitHub` (repo/token, mã hoá AndroidKeyStore) | DÙNG CHUNG cấu hình đó — không cấu hình riêng |

- [x] `SecureTokenStore.kt` — mã hoá PAT bằng AndroidKeyStore (KHÔNG
  dùng `androidx.security-crypto` — lý do đầy đủ trong file: cách đóng
  gói `.jar` addon không bundle thư viện ngoài, dùng framework tránh vá `:core`)
- [x] `GitHubApiClient.kt` — Contents API (đọc/ghi file, kể cả nhị phân) + Actions API, `HttpURLConnection` thuần
- [x] `crawler.py` — Playwright (Chromium headless, KHÔNG phải `requests`
  thuần nữa) — chạy được JS, tự qua phần lớn Cloudflare JS challenge, tải
  ảnh offline (commit CÙNG checkpoint, không lệch pha)
- [x] `colab_notebook.ipynb` — vỏ mỏng: cài Playwright, clone repo, chạy
  thẳng `crawler.py` — không có logic riêng cho Colab

**Giới hạn CỨNG, cả 2 backend, không vượt qua được**:
- **CAPTCHA thật** (cần người bấm) — không có ai ngồi giải trên máy chủ.
  Cần dịch vụ giải CAPTCHA trả phí bên thứ 3 mới qua được — CHƯA làm (tốn
  tiền thật + có thể vi phạm điều khoản site, cần bạn xác nhận trước).
- `useLoginSession` không hỗ trợ — `cookieHeader` (dán tay) thì có.
- Hỗ trợ `preListStages`/`autoDetectPagination` — đã port sang Python (mục 3.11).
- Nặng + chậm hơn nhiều so với tải HTML thô (cài Chromium ~1-2 phút mỗi lần).
- **CHƯA TỪNG CHẠY THỬ THẬT** trên cả GitHub Actions lẫn Colab.

Cài đặt: dán `EBOOKLEECH_REMOTE_CRAWL_STEP.yml` (gửi kèm, ngoài addon zip
vì `.github/` không thuộc phạm vi zip) vào `build.yml` thật — làm 1 lần.
Colab không cần thêm bước cài đặt nào khác (`.ipynb` đã có sẵn trong addon).

### 3.6 "Biết Colab còn sống hay không" — KHÔNG liên quan tới mất dữ liệu
**Phải tách rõ 2 việc khác nhau hoàn toàn**:
1. **Bảo toàn dữ liệu** — checkpoint + ảnh commit lên git mỗi 5 chương/120s
   (`git_commit_push()`, dùng CHUNG cho cả 2 backend). Colab/Actions sập
   bất cứ lúc nào → dữ liệu tới đúng lần commit gần nhất VẪN CÒN trên
   GitHub — KHÔNG phụ thuộc việc app có biết "còn sống" hay không.
2. **Hiển thị trạng thái** — chỉ để bạn xem, không ảnh hưởng dữ liệu.
   GitHub Actions có API thật để tra. Colab thì KHÔNG — giải quyết bằng
   `HeartbeatThread` (trong `crawler.py`): 1 thread NỀN, độc lập hoàn
   toàn với vòng cào chính, ghi `remote-jobs/<id>-heartbeat.json` mỗi 45s
   BẤT KỂ đang làm gì (kể cả đang tải 1 trang nặng, chậm) — app poll file
   nhỏ này, báo "có vẻ đã ngắt" nếu quá **3 phút** không đổi (ngưỡng ngắn
   được vì heartbeat không bị chặn bởi tốc độ cào, khác bản đầu dựa vào
   checkpoint chính — dễ báo nhầm, đã bỏ).

### 3.7 "Chờ giải thủ công" cho remote (chụp màn hình khi bị chặn dai dẳng)
Có, nhưng **không đảm bảo giải được** — khác hẳn local:
- Local: bị chặn → mở CHÍNH tab đang chặn, giải trực tiếp → chắc chắn
  qua (cùng 1 phiên/IP/trình duyệt từ đầu tới cuối).
- Remote: `crawler.py` phát hiện chặn dai dẳng → DỪNG CẢ JOB (không cào
  mù tiếp) → chụp màn hình (`page.screenshot()`) → commit lên repo → app
  tải về hiển thị (khối cảnh báo đỏ, có ảnh thay vì tab thật) → nút "🌐
  Mở URL trong trình duyệt của bạn" (tab CỦA BẠN, khác hẳn máy chạy
  crawler) → "🔄 Chạy lại".
- **GIỚI HẠN THẬT không tránh được**: máy chạy crawler (GitHub/Colab) và
  điện thoại bạn là **2 IP khác nhau**. Site chặn theo IP thì bạn tự giải
  trên điện thoại KHÔNG khiến máy kia hết bị chặn. Cách khả thi nhất: lấy
  cookie phiên MỚI sau khi giải, dán vào job, "Chạy lại" — CÓ THỂ qua
  được tuỳ site, KHÔNG đảm bảo 100%.
- Đã cân nhắc nhưng CHƯA LÀM: tunnel điều khiển trực tiếp phiên trình
  duyệt đang chạy — khả thi nhưng rủi ro bảo mật cao, phức tạp, dễ vỡ.

### 3.8 Trực quan/linh hoạt: Local vs Remote
**KHÔNG, remote không trực quan bằng local khi CẤU HÌNH job**:

| | Local | Remote (cả 2 backend) |
|---|---|---|
| Chọn selector CSS | 🎯 Element Picker — chạm chọn trực tiếp trên trang thật | Gõ tay CSS selector "mù" |
| Đăng nhập | `useLoginSession` — mượn phiên thật | Chỉ cookie dán tay |
| Giải Cloudflare/captcha | Trực tiếp, chắc chắn qua | Screenshot + đoán cookie mới (xem 3.7) |
| Kịch bản nhiều bước / tự dò phân trang | Có | Có (đã port — xem 3.11) |

**Tin tốt**: Element Picker dùng tab local, **độc lập hoàn toàn** với
`remoteBackend` — dựng/kiểm tra selector bằng local trước, xong mới
chuyển job sang remote để chạy khối lượng lớn.

### 3.9 Đồng bộ tiến trình — 3 CHIỀU, không phải cào lại từ đầu khi đổi nơi
Trả lời trực tiếp câu "chuyển giữa các nơi có mất tiến độ không": **KHÔNG
mất — đã xác nhận lại bằng cách lần theo code thật** (không chỉ suy luận):

- **Local ↔ GitHub Actions**: 2 chiều — remote poll về merge local, VÀ
  local đẩy checkpoint+ảnh lên trước khi dispatch (`RemoteCrawlRunner.start()`,
  đoạn đẩy checkpoint nằm TRƯỚC nhánh rẽ theo backend).
- **Local ↔ Colab**: CŨNG 2 chiều — vì đoạn đẩy checkpoint lên (nói trên)
  và đoạn poll về (bước 0/1 trong `pollOnce()`) đều **không phân nhánh
  theo backend**, áp dụng y hệt cho Colab.
- **GitHub Actions ↔ Colab**: gián tiếp qua CÙNG 1 checkpoint file trên
  CÙNG 1 repo — đổi job từ backend này sang backend kia, `crawler.py` (y
  hệt file cho cả 2) tự đọc thấy checkpoint có sẵn và cào tiếp, không cần
  biết checkpoint đó tới từ đâu.

→ **Kết luận: đổi qua lại Local/GitHub/Colab bao nhiêu lần cũng được,
không đâu bắt cào lại từ đầu**, miễn checkpoint còn tồn tại (bị xoá khi
job export xong hoặc bạn chủ động "Chạy mới" trên job KHÔNG có checkpoint).

**Sửa kèm lúc làm việc này** — 2 lỗi/thiếu sót phát hiện được:
1. Nút "▶ Chạy ngay" trước đây LUÔN cào lại từ đầu dù đã có checkpoint —
   giờ tự kiểm tra `CrawlCheckpointRepository.exists()`.
2. Tách `resumeFromCheckpoint` (có checkpoint → tiếp tục) khỏi
   `isAppRestartRecovery` (app vừa khởi động lại, có lần chạy Actions
   ĐANG DỞ cần nối polling) — trước dùng CHUNG 1 cờ, sai vì `findLatestRun()`
   không lọc theo job_id (giới hạn thật của API GitHub) — nối nhầm dễ bắt
   sai lần chạy của job khác hoặc lần chạy cũ đã xong từ lâu.

**Khoảng hở nhỏ còn lại**: app bị kill NGAY lúc job vừa dispatch (chưa có
checkpoint đầu tiên) → không tự nối lại theo dõi sau khi mở app lại (job
vẫn chạy bình thường ở remote, chỉ mất theo dõi tạm — bấm "Chạy lại" để nối).

### 3.10 MỚI — "Lỡ GitHub sập/mất tài khoản thì sao" — làm rõ + 2 nút mới
Câu hỏi thật hay, làm rõ 2 việc hay bị nhầm là một:
1. **Dữ liệu đã cào KHÔNG phụ thuộc vào GitHub còn sống hay không** —
   checkpoint đã TỰ đồng bộ về máy liên tục qua poll định kỳ (mục 3.9) từ
   trước — không phải "chỉ nằm trên GitHub". Ebook HOÀN CHỈNH luôn build
   TẠI MÁY (`EbookExporter`), không bao giờ qua GitHub.
2. **Nhưng đúng là có lỗ hổng khác**: bản đồng bộ đó nằm trong bộ nhớ
   RIÊNG của app (`CrawlCheckpointRepository`) — mất máy/gỡ app thì mất,
   DÙ GitHub còn nguyên. Đây mới là rủi ro thật "chỉ có 1 bản, dù ở đâu".

**Đã có sẵn TRƯỚC bản này** (không phải mới): nút "📤 Sao lưu" ghi checkpoint
ra `Downloads/EbookLeech/Backup/` — ngoài bộ nhớ riêng app, người dùng
thấy được, xuất đi Drive/email/USB tuỳ ý — độc lập hoàn toàn GitHub lẫn
app. Chỉ thiếu ảnh (theo thiết kế checkpoint tự động từ đầu) và phải nhớ
bấm tay.

**Đã sửa 2 thiếu sót đó**:
- [x] `EbookLeechBackupManager` giờ nhúng bytes ảnh (base64) vào file
  backup — CHỈ áp dụng cho backup THỦ CÔNG (hợp lý vì đây là hành động có
  chủ đích, chấp nhận file to hơn 1 chút — checkpoint TỰ ĐỘNG hàng ngày
  vẫn giữ nguyên không nhúng bytes, đúng thiết kế cũ, tránh phình liên tục)
- [x] Tự động gọi "Sao lưu" khi job remote vào trạng thái NEEDS_ACTION
  (mốc dễ bị để lâu chờ nhất — không cần nhớ bấm tay đúng lúc quan trọng)
- [x] Nút "🔄 Đồng bộ ngay" — bỏ qua lịch chờ ~20s, tải checkpoint/ảnh mới
  nhất ngay lập tức (dùng trước khi Sao lưu để chắc có dữ liệu mới nhất)
- [x] Nút "💾 Sao lưu ngay" — hiện trực tiếp trên từng job remote đang
  chạy/đang chờ thủ công, không cần vào menu chính

### 3.11 — Làm nốt phần "chưa xong" còn lại (2/3 mục đã làm, xem 3.12 cho mục thứ 3)
Còn 5 mục trong danh sách "chưa xong" — 2 mục làm được ngay (đã làm), 1
mục tunnel đã có cách an toàn hơn (xem 3.12), 2 mục vẫn cần xác nhận
trước: preset site thật (cần site cụ thể, không đoán bừa), dịch vụ giải
CAPTCHA trả phí (tốn tiền thật + rủi ro ToS). Mục đã làm:

- [x] **Port `preListStages`/`autoDetectPagination` sang remote** —
  `crawler.py` thêm `auto_detect_pagination()` (giữ nguyên 5 template dò
  phân trang như bản Kotlin) và `traverse_pre_list_stages()` (duyệt BFS
  qua từng tầng kịch bản). **Khác 1 chút so với Kotlin** (đã cân nhắc,
  chấp nhận được): bản Kotlin có thể xen kẽ Phase1/Phase2 giữa các
  entry, bản Python thu thập HẾT link mọi entry trước rồi mới cào nội
  dung 1 lần — ebook CUỐI CÙNG giống hệt, chỉ khác thứ tự xử lý nội bộ.
- [x] **Sửa "khoảng hở nhỏ"** (app kill ngay lúc job vừa dispatch, chưa
  kịp poll lần đầu → không tự nối lại theo dõi) — giờ tạo NGAY 1
  checkpoint RỖNG cục bộ trước khi dispatch, để `resumeInterruptedJobs()`
  nhận diện đúng job này khi app khởi động lại.

### 3.12 MỚI — Điều khiển trình duyệt từ xa qua git (không tunnel)
Mục thứ 3 từ "3 mục cần xác nhận trước" đã làm, vì tìm ra cách giải quyết
vấn đề bảo mật thay vì đẩy rủi ro cho người dùng: dùng lại kênh git+token
đã xác thực (PAT mã hoá AndroidKeyStore) thay vì tunnel — chỉ người có
token mới ghi được lệnh.

**Luồng hoạt động**:
- Job bị chặn (CAPTCHA/login) → crawler.py commit ảnh chụp màn hình như
  trước, nhưng thay vì đóng browser và thoát → GIỮ browser sống, khởi
  động `InteractiveCommandPoller` (thread nền) poll `remote-jobs/<id>-cmd.json`
  mỗi 4 giây.
- UI hiện khối "🖥️ Điều khiển trình duyệt từ xa" với các nút: 📸 Chụp
  màn hình, ↵ Enter, ⭾ Tab, ✕ Esc, ⬇⬆ Cuộn, ⌨ Gõ text…, 🎯 Click
  selector…, JS… — gọi `sendInteractiveAction()` trong `RemoteCrawlRunner`.
- App ghi file lệnh lên git → Python thực thi → chụp ảnh kết quả → xoá
  file lệnh → commit. App biết "xong" khi GET file lệnh trả 404.
- Sau ~25 phút chờ (xấp xỉ sàn Actions còn lại) không có lệnh → thoát gọn.

**Lệnh**: `screenshot`, `click:<selector>`, `click_coord:<x>,<y>`,
`type:<text>`, `press:<key>`, `scroll:<direction>`, `wait:<ms>`, `eval:<js>`.

**Độ trễ**: ~5-15s/lệnh (git push → poll) — không tức thời, nhưng đủ để
dán cookie mới hoặc click CAPTCHA slide thủ công.

- [x] `sendInteractiveAction()` + `INTERACTIVE_POLL_INTERVAL_MS` (5s) —
  `RemoteCrawlRunner.kt`
- [x] `InteractiveCommandPoller` (thread nền khi pause) — `crawler.py`
- [x] UI điều khiển đầy đủ — `EbookLeechSettingsView.kt`
- [x] `getActiveRemoteRunner()` — `EbookLeechScheduler.kt`

### 3.13 MỚI — Giải CAPTCHA xong → tiếp tục cào NGAY tại chỗ (không dispatch lại)
Nâng cấp trực tiếp từ 3.12: trước đây dù có điều khiển được, người dùng vẫn
phải bấm "🔄 Chạy lại" để tiếp tục — mà "Chạy lại" = dispatch job MỚI =
Actions runner MỚI = **IP khác** = nếu site chặn theo IP, phải giải lại
captcha từ đầu, vô nghĩa. Giờ có nút "✅ Đã giải xong — Tiếp tục cào ngay"
dùng lại **đúng session/cookie/IP đang bị chặn**, không dispatch gì cả.

**Cơ chế**:
- `InteractiveCommandPoller` nhận thêm `resume_event` (threading.Event) —
  khi thấy action `"resume_crawl"`, xoá file lệnh (báo "đã xử lý" cho app)
  rồi `set()` event thay vì thực thi click/type như các lệnh khác.
- Tách logic pause ra hàm riêng `handle_blocked_pause()` — chờ ĐỒNG THỜI
  2 tín hiệu: `resume_event` (người dùng báo đã giải xong) HOẶC hết
  `MAX_INTERACTIVE_WAIT_S` (25 phút, không ai làm gì).
- Vòng Phase 2 đổi từ `for i in range(...)` sang `while i < len(...)` —
  lý do: khi resume tại chỗ cần THỬ LẠI đúng chương `i` (không tăng
  index), `for` không cho làm việc này, phải tự quản lý index bằng tay.
- Resume thành công → `continue` vòng `while` (retry chương `i` với
  `crawl_one_chapter_html`/`crawl_one_chapter_ajax` bình thường, dùng
  nguyên `page`/`context` cũ — cookie/session CAPTCHA vừa giải vẫn còn).
- Hết giờ không ai giải → dọn dẹp, thoát hẳn như cũ (fallback: người dùng
  vẫn "Chạy lại" được, chỉ là mất session/IP cũ).

**UI**: nút xanh "✅ Đã giải xong — Tiếp tục cào ngay" đặt đầu khối điều
khiển (`EbookLeechSettingsView.kt`), có caption giải thích lợi ích so với
"🔄 Chạy lại (dispatch mới)" — nút cũ đổi màu xám, coi như phương án dự
phòng khi không giải được tại chỗ.

- [x] `resume_event` trong `InteractiveCommandPoller` + xử lý action
  `"resume_crawl"` — `crawler.py`
- [x] `handle_blocked_pause()` (tách logic pause dùng chung) — `crawler.py`
- [x] Vòng Phase 2 đổi `for`→`while`, hỗ trợ retry đúng chương — `crawler.py`
- [x] Nút "✅ Đã giải xong — Tiếp tục cào ngay" — `EbookLeechSettingsView.kt`

**Giới hạn còn lại**: nếu site chặn "cứng" theo dấu vân tay trình duyệt
headless (không chỉ CAPTCHA hiển thị) thì dù giải xong CAPTCHA, request
sau vẫn có thể bị chặn lại — không có cách khắc phục từ trong app (đây là
giới hạn của việc chạy Playwright/Chromium headless trên CI, không phải
lỗi của cơ chế resume này).

### 3.14 MỚI — Giảm dấu hiệu bị nhận diện là bot: headed+Xvfb + giữ session xuyên các lần chạy
Giải quyết trực tiếp giới hạn nêu ở cuối mục 3.13. **Không "dứt điểm"**
(vẫn là cuộc chạy đua vũ trang với anti-bot cấp cao như Cloudflare/
DataDome — những hệ thống đó còn soi TLS fingerprint + hành vi, nằm ngoài
tầm với của 2 thay đổi này) — nhưng giảm đáng kể khả năng bị chặn ngay từ
đầu, và tận dụng lại đúng cơ chế resume ở 3.13 để không phí công giải lại.

**a) Headed mode + Xvfb** — Chromium chạy `headless=True` để lại vài dấu
hiệu nội tại mà site dựa vào để phân biệt bot (thiếu 1 số API render,
timing khác biệt) — dù `headless=False` (headed) cũng KHÔNG có các dấu
hiệu này, tự nhiên giống trình duyệt người dùng thật hơn. Runner Ubuntu
không có màn hình vật lý → cần Xvfb (màn hình ảo) để headed mode có chỗ
khởi động.
- [x] `browser.launch(headless=False, args=["--no-sandbox", "--disable-dev-shm-usage"])`
  — `crawler.py` (2 cờ args là chuẩn ổn định cho container/CI, không liên
  quan trực tiếp tới headed/headless)
- [x] Bước "Cài Xvfb" (`apt-get install xvfb`) + lệnh chạy crawler bọc
  trong `xvfb-run --auto-servernum --server-args="-screen 0 1920x1080x24"`
  — `EBOOKLEECH_REMOTE_CRAWL_STEP.yml`
- ⚠️ **Bạn cần dán ĐÈ lại job `remote-crawl` trong `build.yml` bằng bản
  yml mới** — nếu chỉ cập nhật addon mà không cập nhật workflow, crawler
  vẫn chạy được nhưng KHÔNG có Xvfb → Chromium headed sẽ crash ngay lúc
  launch (không có display để vẽ ra).

**b) Giữ session (cookie + localStorage) xuyên suốt các lần chạy** — trước
đây mỗi lần dispatch remote là 1 phiên "hoàn toàn mới tinh" với site (dù
cùng máy chủ) — nhiều site anti-bot tin tưởng session đã tồn tại lâu hơn
session vừa tạo. Giờ lưu lại `context.storage_state()` (cookie +
localStorage mọi origin) ra file `remote-jobs/<id>-storage-state.json`,
khôi phục ngay khi tạo context ở lần chạy sau — kể cả sau khi giải CAPTCHA
xong (3.13), lưu ngay lúc đó vì đó là cookie "vừa qua xác minh", giá trị
nhất.
- [x] `make_context()` nhận `storage_state_path`, tự khôi phục nếu file
  tồn tại — `crawler.py`
- [x] `save_storage_state()` — gọi sau Phase 1, mỗi lần commit checkpoint
  trong Phase 2, và quan trọng nhất: NGAY sau khi `resume_crawl` thành
  công trong `handle_blocked_pause()` — `crawler.py`
- File `storage-state.json` được `git add -A` gom vào cùng commit
  checkpoint như bình thường — không cần thêm logic git riêng.

**Vẫn KHÔNG dứt điểm 100%** — với site dùng anti-bot enterprise
(Cloudflare/DataDome/Akamai) kiểm tra thêm TLS fingerprint (JA3) và phân
tích hành vi (tốc độ chuột/gõ phím), 2 thay đổi này không chạm tới được.
Bước tiếp theo nếu vẫn bị chặn: dùng proxy dân dụng thay IP datacenter
của GitHub Actions (đã có sẵn `ProxyScraper.kt`/`ProxyHealthChecker.kt`
trong project — chưa port sang Python, chưa làm).

### 3.15 MỚI — Rà soát phát hiện 3 lỗi trong tính năng điều khiển từ xa (3.12/3.13) — ĐÃ SỬA
Rà soát riêng (không phải người dùng báo lỗi) sau khi làm xong 3.12-3.14,
phát hiện tính năng điều khiển từ xa **có nối dây nhưng nối SAI** ở 3 chỗ.
Cả 3 đều đã sửa, nhưng ghi lại đầy đủ vì đây là bài học thiết kế thật —
lần sau thêm callback/polling mới cần soát kỹ thứ tự các nhánh `if` sớm
`return` (`return@Thread`) có thể chặn mất code phía sau.

**Lỗi 1 — `awaitingInteractiveResult` không bao giờ reset khi job đang
paused**: `pollOnce()` có nhánh `if (pausedForManualReview) {...;
return@Thread}` đặt TRƯỚC đoạn kiểm tra kết quả lệnh interactive — mà
`pausedForManualReview` giữ nguyên `true` suốt lúc chờ (trừ lệnh
`resume_crawl`) → đoạn kiểm tra kết quả không bao giờ chạy tới →
`scheduleInteractivePoll()` tự lặp lại **vô thời hạn** mỗi 5s.
→ **Đã sửa**: chuyển đoạn kiểm tra lên TRƯỚC nhánh `pausedForManualReview`,
xử lý đủ 2 trường hợp (`resume_crawl` phát hiện qua `pausedForManualReview`
tắt; lệnh thường phát hiện qua mốc `lastInteractiveAt` mới hơn lần trước).
Thêm `MAX_INTERACTIVE_POLL_RETRIES` (36 lần ≈ 3 phút) làm lưới an toàn dự
phòng, tự dừng nếu có tình huống ngoài dự tính (Python crash, git push lỗi
liên tục).

**Lỗi 2 — ảnh chụp màn hình của lệnh interactive không bao giờ hiện lên
UI**: Python commit ảnh mới (`_interactive_<id>_<ts>.png`) lên git thật,
nhưng checkpoint chỉ có field `pausedScreenshotFile` (ghi 1 lần lúc mới
chặn, không đổi nữa) — Kotlin không có cách nào biết tên file ảnh MỚI.
→ **Đã sửa**: Python ghi thêm `lastInteractiveScreenshotFile`/
`lastInteractiveAt`/`lastInteractiveError` vào checkpoint sau MỖI lệnh
(`_update_checkpoint_interactive_result()`); Kotlin đọc field này, tải ảnh,
cập nhật `pendingActionScreenshotPath` qua callback mới `onInteractiveResult`.

**Lỗi 3 — hệ quả của lỗi 1: nhánh `pausedForManualReview` chạy vô điều
kiện mỗi lần poll** → (a) spam lại thông báo + tự backup mỗi 5 giây trong
lúc chờ 1 lệnh xử lý xong, (b) NGAY SAU KHI lỗi 2 vừa sửa xong cập nhật
đúng ảnh interactive mới, cùng 1 lần poll đó lại bị ghi đè NGƯỢC về ảnh
chặn ban đầu (`onNeedsManualAction` gọi lại, set `pendingActionScreenshotPath`
về giá trị cũ).
→ **Đã sửa**: thêm `lastNotifiedPausedSavedAt` — so sánh với `savedAt`
trong checkpoint (mốc này CHỈ đổi khi có đợt chặn MỚI hoặc resume, KHÔNG
đổi khi `InteractiveCommandPoller` chỉ patch 3 field `lastInteractive*`) —
chỉ thực sự tải ảnh chặn + gọi `onNeedsManualAction` khi mốc này thay đổi.

**Lỗi kiến trúc phụ (phát hiện lúc sửa lỗi 2)**: bản vá đầu tiên gọi thẳng
`LeechJobRepository.updateJob(...)` từ trong `RemoteCrawlRunner.kt` — VI
PHẠM kiến trúc cố ý của project (file này KHÔNG import `LeechJobRepository`,
mọi thay đổi job đều đi qua callback tiêm từ constructor, việc ghi thật sự
nằm ở nơi khởi tạo runner trong `EbookLeechScheduler.kt` — xem
`onNeedsManualAction`/`onColabReady` đã có sẵn). Sẽ KHÔNG biên dịch được
nếu để nguyên. Đã sửa: thêm callback `onInteractiveResult` theo đúng
pattern, `EbookLeechScheduler.kt` mới là nơi gọi `LeechJobRepository`.

- [x] Thứ tự kiểm tra trong `pollOnce()` — `RemoteCrawlRunner.kt`
- [x] `MAX_INTERACTIVE_POLL_RETRIES` — `RemoteCrawlRunner.kt`
- [x] `_update_checkpoint_interactive_result()` — `crawler.py`
- [x] `lastNotifiedPausedSavedAt` — `RemoteCrawlRunner.kt`
- [x] Callback `onInteractiveResult` (thay gọi thẳng `LeechJobRepository`)
  — `RemoteCrawlRunner.kt` + `EbookLeechScheduler.kt`

**Chưa test thật** — toàn bộ phân tích trên dựa vào đọc code tĩnh (không
có thiết bị/CI thật để chạy thử). Rủi ro còn lại: có thể còn edge-case
chưa lường tới (vd 2 lệnh interactive gửi liên tiếp quá nhanh, mạng chập
chờn giữa lúc Python đang commit...).

---

## 4. CHƯA TEST THẬT trên thiết bị (nhắc lại vì quan trọng)

Không có môi trường Android SDK/Actions/Colab thật để chạy suốt quá trình
làm việc — mọi thứ đúng trên giấy theo cách đọc code + tài liệu chính
thức, đã tự kiểm tra cân bằng ngoặc/cấu trúc (kể cả AST parser cho phần
Python) từng file, nhưng CHƯA build/chạy thử lần nào. Phần đồng bộ 3
chiều + heartbeat 2 thread là phần tinh vi nhất — càng cần test sớm. Gửi
log lỗi cụ thể để sửa đúng chỗ, không đoán mò thêm.

## 5. Cài đặt

Đọc `EBOOKLEECH_TICH_HOP.md` + `PATCH_CO_BAN.md` (gửi ở các lượt trước,
vẫn còn đúng — phần CÀI ĐẶT/kiến trúc `:core` không đổi từ đó tới giờ,
chỉ riêng file `ebookleech/` bên trong đã cập nhật nhiều lần, luôn lấy
bản `ebookleech-addon.zip` MỚI NHẤT). Riêng cào từ xa: đọc mục 3.5 ở trên.
