# EbookLeech — Tài liệu kỹ thuật (bản 7.104)

Mục đích: mô tả đúng những gì mã đang làm để (a) người bảo trì không phải đoán, (b) một ứng dụng leech khác (ví dụ app chạy trên PC) có thể theo dõi tiến độ hoặc nhận/giao việc dở dang với EbookLeech.
Mọi khẳng định dưới đây đều lấy từ mã nguồn của dự án; chỗ nào chưa kiểm chứng thì ghi rõ ở mục 10. Đây KHÔNG phải một API ổn định: schema có thể đổi giữa các bản, hãy đối chiếu số bản (`BuildMarker.VERSION`).

Đường dẫn Kotlin viết tắt: `E/` = `app/src/main/java/com/colablive/keeper/features/ebookleech/`.

---

## 1. Tóm tắt một trang

- EbookLeech cào một truyện (danh sách chương → từng chương) rồi xuất ra EPUB/TXT/HTML.
- Có **hai nơi cào**: (1) **tại máy** — dùng tab GeckoView thật của khe, chạy JavaScript như trình duyệt; (2) **từ xa** — script Python (`remote_runner/crawler.py`) chạy Chromium thật qua Playwright trên GitHub Actions hoặc Google Colab. Điện thoại chỉ giao việc và theo dõi qua **một repo GitHub dùng làm "bảng tin chung"**.
- Tiến độ lưu thành **checkpoint JSON** (danh sách link chương, chương đã cào, vị trí đang dở). Cả hai nơi cào dùng **cùng schema checkpoint**.
- Chạy theo lịch: một service nền gọi `tick` mỗi 30 giây; job nào đến hạn thì chạy lại **từ đầu** (không tiếp tục checkpoint cũ), trừ khi bật "Chỉ cào chương mới" để dùng lại chương đã có (tại máy từ 7.100, từ xa từ 7.102).
- Từ 7.102: sau mỗi lần xuất, ứng dụng so danh sách chương với lần xuất trước để đếm **chương mới** (thông báo đẩy `+N chương mới`), và có chế độ **ghi đè file ebook cũ** (`updateExistingFile`).
- Từ 7.104: **quét nhanh danh sách theo điểm neo** (mục 6.7) — lần cập nhật sau không đọc lại mọi trang danh sách; **thông tin truyện** (tác giả, tóm tắt, thể loại, trạng thái, đánh giá, bìa…; mục 6.8) lưu trong ebook (metadata OPF + trang "Giới thiệu") và file `.story.json` + ảnh bìa cạnh ebook; điện thoại có thể **giao kho chương đã cào** cho máy cào từ xa/LeechDesk nối tiếp (mục 6.9).
- Không có API cục bộ (HTTP/socket) cho chương trình ngoài. Cách đồng bộ với app khác hiện chỉ có qua: repo GitHub (mục 8.A, 8.B), file sao lưu JSON (8.C) và file ebook đã xuất (8.D).

---

## 2. Thành phần và luồng

```
Giao diện (E/ui/EbookLeechSettingsView.kt)  ──tạo/sửa job──▶  LeechJobRepository  (AppPrefs, theo khe)
                                                                     │
Service nền theo khe (E/service/EbookLeechService.kt) ─ tick 30s ─▶ EbookLeechScheduler.tick
   ▲ WorkManager 15 phút bật lại service nếu bị hệ thống tắt           │ isDue? ─▶ startJob
                                                                     │
                 ┌───────────────────────────────────────────────────┴───────────────┐
        remoteBackend = NONE                                          remoteBackend = GITHUB | COLAB
                 │                                                                    │
   EbookLeechCrawler (tab GeckoView)                                   RemoteCrawlRunner ──Contents API──▶ repo GitHub
   E/engine/EbookLeechCrawler.kt                                       E/remote/RemoteCrawlRunner.kt        remote-jobs/<id>*.json
        │ evaluateJsOnTab                                                       │ dispatch workflow                │
        ▼                                                                       ▼                                  ▼
   ContentProcessor (luật tìm & thay)                                  GitHub Actions / Colab ─▶ crawler.py ─git push─▶ checkpoint, ảnh
        │                                                                       │ (điện thoại poll 20 giây, đọc checkpoint)
        ▼                                                                       ▼
   EbookExporter (EPUB/TXT/HTML) ◀──────────── danh sách LeechChapter ◀─────────┘
        │
        ▼
   Downloads/EbookLeech/<tên job>/<tên>_<yyyyMMdd_HHmm>.<đuôi>   (mặc định mỗi lần xuất tạo file MỚI;
   updateExistingFile=true: tên cố định <tên>.<đuôi>, ghi đè file cũ — 7.102)
```

| Thành phần | File | Vai trò |
|---|---|---|
| Lập lịch | `E/EbookLeechScheduler.kt` | `tick`, `isDue`, `startJob`, khôi phục job dở sau khi app bị kill |
| Service | `E/service/EbookLeechService.kt`, `EbookLeechWorker.kt` | Foreground service theo khe, `TICK_INTERVAL_MS = 30_000`; WorkManager 15 phút khởi động lại service. 7.102: `postNewChaptersNotification` (kênh `ebook_leech_new_chapters_channel`, mỗi job một thông báo, lần sau của cùng job đè lên) |
| Cào tại máy | `E/engine/EbookLeechCrawler.kt` | Các pha cào (mục 5) |
| Chạy JS trong tab | `E/engine/GeckoViewEngineExt.kt` | `evaluateJsOnTab`: mở URL, chờ `readyState=complete`, +800ms, (tuỳ chọn cuộn lazy-load), chạy script |
| Thử selector | `E/engine/SelectorTester.kt` | Chạy đúng hai script của crawler trên trang 1 và chương đầu, báo bằng chữ |
| Xử lý nội dung | `E/engine/ContentProcessor.kt` | Áp luật tìm & thay (regex) |
| Xuất ebook | `E/export/EbookExporter.kt` | EPUB/TXT/HTML vào `Downloads/EbookLeech/<tên job>/` |
| Kho chương | `E/model/ChapterArchiveRepository.kt` | Bản 7.100: nhớ chương đã cào giữa các lần chạy; 7.102: thêm "mốc xuất" `.baseline` (mục 3.4) |
| Việc sau/trước khi xuất | `E/export/ExportFollowUp.kt` | Bản 7.102: so với lần xuất trước (đếm chương mới, có đổi không), chữ ký cấu hình xuất, quyết định bỏ qua xuất, dòng ghi chú — dùng chung cho cào tại máy, cào từ xa và xuất sau khi sắp xếp mục lục |
| Checkpoint | `E/model/CrawlCheckpoint.kt`, `CrawlCheckpointRepository.kt` | Trạng thái giữa chừng của MỘT lần chạy |
| Cào từ xa (điện thoại) | `E/remote/RemoteCrawlRunner.kt`, `GitHubApiClient.kt`, `GitHubRemoteConfig.kt` | Đẩy job, dispatch workflow, poll checkpoint, tải ảnh |
| Cào từ xa (máy chủ) | `remote_runner/crawler.py`, `EBOOKLEECH_REMOTE_CRAWL_STEP.yml`, `remote_runner/colab_notebook.ipynb` | Playwright + git push checkpoint |
| Sao lưu | `E/backup/EbookLeechBackupManager.kt` | JSON `Downloads/EbookLeech/Backup/ebookleech_backup_<yyyyMMdd_HHmmss>.json` |

Điều kiện chạy theo lịch (đọc từ `EbookLeechScheduler.tick/isDue/startJob`):
- Bỏ qua job đang `RUNNING`, `PAUSED`, `NEEDS_ACTION`. Job `DONE`/`ERROR`/`IDLE` đến hạn thì chạy lại.
- `INTERVAL`: `now - lastRunAt >= intervalMinutes`. `DAILY`: ngày của `lastRunAt` < ngày hiện tại. `MANUAL`: không bao giờ tự chạy.
- Chạy mới (`resumeFromCheckpoint=false`): **xoá checkpoint cũ** rồi cào từ đầu.
- Cào tại máy cần **khe đang mở trong tiến trình** (`GeckoViewEngine.forSlot(slot)`); không có thì job chuyển `ERROR`. Cào từ xa không cần khe.

---

## 3. Mô hình dữ liệu

### 3.1 `LeechJob` (cấu hình + trạng thái một job)
Lưu trong `AppPrefs` theo khe (khoá `jobs_json`) và được ghi nguyên vẹn vào `remote-jobs/<id>.json` khi cào từ xa. Mẫu thật do `LeechJob.toJson()` sinh ra với giá trị mặc định (rút gọn bớt các trường rỗng ở cuối):

```json
{
 "id": "J1", "name": "Truyen mau", "projectId": "",
 "listPageUrl": "https://example.com/truyen/1",
 "listPageUrlPattern": "https://example.com/truyen/1?page={page}", "maxPages": 3,
 "chapterLinkSelector": "a.ch", "chapterLinkAttribute": "href",
 "chapterTitleSelector": "h1.t", "chapterContentSelector": "div.body",
 "bookTitleSelector": "", "bookCoverSelector": "", "authorSelector": "",
 "outputFormat": "EPUB", "outputFileName": "",
 "scheduleMode": "MANUAL", "intervalMinutes": 60,
 "status": "IDLE", "chaptersCollected": 0, "lastRunAt": 0, "outputFilePath": "",
 "delayBetweenPagesMs": 1500, "useJsRendering": true, "customUserAgent": "",
 "cookieHeader": "", "useLoginSession": false,
 "publishToWordPress": false, "wpSiteUrl": "", "wpUsername": "", "wpAppPassword": "",
 "wpPostStatus": "draft", "wpCategoryId": 0, "wpPostTitleTemplate": "{title}",
 "pendingActionUrl": "", "pendingActionReason": "", "pendingActionScreenshotPath": "",
 "simulateScrollForLazyLoad": false, "maxScrollAttempts": 6,
 "regexRules": [], "downloadImages": false, "maxImagesPerChapter": 30,
 "autoDetectPagination": false, "suggestAjaxEndpoints": false, "detectedAjaxEndpoints": [],
 "resolvedPaginationPattern": "",
 "ajaxListMode": false, "ajaxListUrlTemplate": "", "ajaxListItemsPath": "", "ajaxListUrlField": "url",
 "ajaxContentMode": false, "ajaxContentTitleField": "title", "ajaxContentField": "content",
 "remoteBackend": "NONE",
 "preListStages": [], "manualTocReview": false, "tocOverride": [],
 "incrementalUpdate": false, "lastRunNote": "", "refreshLastN": 0,
 "skipIfTextContains": [], "minTextLength": 0, "chapterNextPageSelector": "", "maxChapterPages": 10,
 "updateExistingFile": false, "notifyNewChapters": true
}
```

Giá trị liệt kê: `outputFormat` ∈ {EPUB, TXT, HTML}; `scheduleMode` ∈ {MANUAL, INTERVAL, DAILY}; `status` ∈ {IDLE, RUNNING, REVIEW_READY, NEEDS_ACTION, PAUSED, DONE, ERROR}; `remoteBackend` ∈ {NONE, GITHUB, COLAB}.
Phiên bản mới có thể thêm trường: đọc kiểu "bỏ qua trường lạ", và coi trường thiếu là giá trị mặc định (`fromJson` dùng `optXxx` với mặc định).

> **Cảnh báo bảo mật**: `cookieHeader` và `wpAppPassword` nằm nguyên văn trong file job được commit lên repo khi cào từ xa. Repo dùng để cào từ xa **phải để riêng tư (private)**. Nội dung truyện cào được cũng được commit vào repo đó.

Các trường 7.100/7.101: `incrementalUpdate`, `refreshLastN` (cào tại máy dùng từ 7.100; **`crawler.py` dùng cả hai từ 7.102**), `skipIfTextContains`, `minTextLength`, `chapterNextPageSelector`, `maxChapterPages` (chỉ cào **tại máy** dùng); `lastRunNote` (dòng tóm tắt lần chạy, hiện trên thẻ job).
Các trường 7.102 (chỉ phía điện thoại dùng, `crawler.py` bỏ qua): `updateExistingFile` (mặc định `false`: ebook tên cố định, ghi đè file cũ), `notifyNewChapters` (mặc định `true`: báo `+N chương mới`). `fromJson` thiếu trường thì dùng mặc định nên job cũ chạy y như trước.

### 3.2 `LeechChapter` (một chương)
```json
{ "index": 1, "title": "Chuong 1", "htmlContent": "<div class=\"body\">…</div>", "textContent": "…",
  "sourceUrl": "https://example.com/truyen/1/c1",
  "images": [ { "originalUrl": "…", "localFileName": "img_1_1.jpg", "mimeType": "image/jpeg" } ] }
```
- `sourceUrl`: khoá nhận diện chương (kho chương dùng nó để biết chương đã có).
- `index`: **phải duy nhất trong một danh sách** — `EbookExporter` dùng nó làm tên entry `OEBPS/chapter_<index>.xhtml` và khoá mục lục; trùng sẽ làm EPUB lỗi hoặc mất chương. Cào tại máy đánh số 1, 2, 3… Từ 7.101 `crawler.py` cũng dùng `max(index đang có)+1`. Bản Python trước 7.101 dùng `index = vị trí 0-based`, nên checkpoint cũ có thể bắt đầu từ 0. **Bên thứ ba không nên giả định chỉ số bắt đầu từ 0 hay 1; chỉ cần đảm bảo duy nhất và tăng dần theo thứ tự đọc.**
- `images[].localFileName`: tên file trong `remote-jobs/<id>-images/` (từ xa) hoặc `<filesDir>/ebookleech_checkpoints/<slot>_<id>_images/` (điện thoại). Quy ước tên `img_<index>_<số thứ tự>.<đuôi>`; `htmlContent` đã đổi `src` ảnh thành `images/<tên file>`. Byte ảnh KHÔNG nằm trong JSON checkpoint (chỉ nằm trong file sao lưu thủ công, dạng base64).

### 3.3 `CrawlCheckpoint`
Mẫu thật do `crawler.py` sinh ra sau khi cào xong 2 chương (rút gọn nội dung):

```json
{
 "jobId": "J1",
 "phase": "CRAWLING_CHAPTERS",
 "listPageEntries": [], "listPageEntryIndex": 0,
 "chapterLinks": ["https://…/c/1", "https://…/c/2"],
 "chapterProgressIndex": 2,
 "chaptersSoFar": [ { "index": 1, "title": "Chuong 1", "htmlContent": "…", "textContent": "…", "sourceUrl": "https://…/c/1", "images": [] },
                    { "index": 2, "title": "Chuong 2", "htmlContent": "…", "textContent": "…", "sourceUrl": "https://…/c/2", "images": [] } ],
 "blockedChapterCount": 0,
 "pausedAtIndex": -1,
 "savedAt": 1794131660632,
 "remoteDone": true
}
```
| Trường | Ý nghĩa |
|---|---|
| `phase` | `COLLECTING_LINKS` (đang thu danh sách) hoặc `CRAWLING_CHAPTERS` (đang cào nội dung) |
| `chapterLinks` | Toàn bộ link chương, đúng thứ tự đọc |
| `chapterProgressIndex` | Số chương đã xử lý (0-based = vị trí chương tiếp theo cần cào) |
| `chaptersSoFar` | Các chương đã cào, theo thứ tự (chương lỗi được thêm dạng giữ chỗ có tiêu đề chứa `[loi]`/`[lỗi]`) |
| `blockedChapterCount` | Số chương lỗi/bị chặn |
| `pausedAtIndex` | `-1` = không tạm dừng; `>=0` = đang chờ giải xác minh tại `chapterLinks[pausedAtIndex]` |
| `savedAt` | Mili-giây epoch lúc ghi |
| `remoteDone` | (chỉ file từ xa) `true` khi `crawler.py` đã xong cả job |
| `pausedForManualReview`, `lastInteractiveAt` | (chỉ file từ xa) cờ tạm dừng chờ người, mốc lệnh điều khiển từ xa gần nhất |
| `runnerVersion` | (chỉ file từ xa, từ 7.102) số bản của runner đã ghi checkpoint này (`"7.103"` với `crawler.py`; `"leechdesk-1.3.0"` với LeechDesk). Thiếu = `crawler.py` là bản cũ. App dùng nó để báo lỗi rõ khi repo giữ zip cũ (mục 6.4) |
| `reusedCount`, `crawledCount` | (chỉ file từ xa, từ 7.102) số chương dùng lại từ lần chạy trước / số chương phải mở trang cào ở lần chạy này (cộng dồn cả khi bị ngắt rồi chạy tiếp) |
| `skippedCount` | (chỉ file từ xa, từ 7.103) số chương bị bỏ qua vì khớp quy tắc bỏ qua (cụm văn bản / quá ngắn). Chương bị bỏ KHÔNG nằm trong `chaptersSoFar` và không tốn `index` |

### 3.4 Kho chương (bản 7.100, chỉ cào tại máy)
- `<filesDir>/ebookleech_archive/<slot>_<jobId>.json`: mảng `LeechChapter` của lần chạy gần nhất (chương lỗi/bị chặn không lưu), kèm thư mục ảnh `<slot>_<jobId>_images/`.
- `<slot>_<jobId>.sig`: chữ ký cấu hình xuất của **lần xuất gần nhất** (`định dạng|tên file|số mục lục thủ công|updateExistingFile`; trường cuối thêm ở 7.102 nên bật/tắt ghi đè luôn ép xuất lại). Dùng để quyết định có bỏ qua việc xuất lại không (mục 6.3).
- `<slot>_<jobId>.baseline` (7.102): **mốc xuất** — mỗi dòng `sourceUrl<TAB>CRC32(tiêu đề + NUL + htmlContent)` của từng chương trong lần xuất gần nhất, theo thứ tự xuất. Dùng để: (1) đếm chương mới = số chương có URL không nằm trong mốc; (2) biết lần này có GIỐNG HỆT lần xuất trước không. Ghi sau mỗi lần xuất thành công (kể cả job không bật cập nhật tăng dần, để thông báo chương mới chạy được cho mọi job). Không có mốc (chưa từng xuất, hoặc đã "Xoá kho") => lần xuất này coi là "lần đầu", **không** báo chương mới.
- Kho **không nằm trong sao lưu**; khoá theo URL chương đúng như site trả. Với cào từ xa, "kho" là checkpoint `remoteDone=true` của lần chạy trước nằm trong repo (mục 6.4), không phải file này; riêng `.baseline` và `.sig` vẫn nằm trên điện thoại cho cả hai chế độ.

### 3.5 Nơi lưu trên điện thoại
| Dữ liệu | Vị trí |
|---|---|
| Job, dự án | `AppPrefs` (SharedPreferences theo khe), khoá `jobs_json` |
| Checkpoint | `<filesDir>/ebookleech_checkpoints/<slot>_<jobId>.json` + `_images/` |
| Kho chương, chữ ký, mốc xuất | `<filesDir>/ebookleech_archive/…` (mục 3.4) |
| Mốc "kết quả cũ" khi theo dõi cào từ xa (7.102) | SharedPreferences `ebookleech_remote_run_<slot>`, khoá `stale_done_saved_at_<jobId>` (mục 6.4) |
| Ebook đã xuất | `Downloads/EbookLeech/<tên job>/` (MediaStore trên Android 10+; `outputFilePath` có thể là `content://…`) |
| Sao lưu | `Downloads/EbookLeech/Backup/ebookleech_backup_*.json` |

`<filesDir>` là bộ nhớ riêng của app: chương trình khác trên điện thoại/PC không đọc được nếu không root. Muốn lấy ra phải qua sao lưu hoặc file ebook.

---

## 4. Cách trang JavaScript được xử lý

### 4.1 Cào tại máy (GeckoView)
- Mở URL trong **một tab crawl riêng** của khe (cùng proxy, cùng fingerprint của khe), đợi `document.readyState == "complete"`, đợi thêm **800 ms**, rồi chạy script lấy dữ liệu bằng trình duyệt thật. Script chạy sau khi JS của trang đã chạy nên thấy DOM đã dựng.
- **Giới hạn đã biết**: chỉ chờ cố định 800 ms sau khi tải xong; **không có "chờ cho tới khi selector xuất hiện"**. Site dựng nội dung chậm hơn mức đó có thể trả trang rỗng hoặc selector rơi về `document.title`/`body`. Công cụ **🧪 Thử selector** cho biết selector nào đang khớp hay rơi về mặc định.
- **Lazy-load (cuộn)**: tuỳ chọn `simulateScrollForLazyLoad` + `maxScrollAttempts`. Cuộn dần xuống đáy, mỗi lần đợi 700 ms, đo lại chiều cao, dừng khi hết đổi. **Bản 7.101 sửa lỗi thứ tự**: trước đó cuộn xảy ra TRƯỚC khi mở URL đích nên cuộn nhầm trang của lần trước; nay cuộn nằm trong `evaluateJsOnTab` sau khi trang đích tải xong. Chưa chạy trên điện thoại thật.
- Chế độ **AJAX Leech** (`ajaxListMode`/`ajaxContentMode`): gọi thẳng API JSON của site thay vì đọc DOM, dùng khi site có endpoint rõ ràng.
- Danh sách chương chỉ cuộn-vô-hạn (infinite scroll) **chưa được hỗ trợ** (cuộn chỉ áp dụng cho trang chương).

### 4.2 Cào từ xa (`crawler.py`, Playwright + Chromium)
- Chạy JS như trình duyệt thật. `page.goto(..., wait_until="domcontentloaded")` rồi **từ 7.101** chờ phần tử đích (selector của job) xuất hiện tối đa `renderWaitMs` (mặc định 8000 ms; trang tĩnh đã có sẵn phần tử nên không chậm thêm; bước dò phân trang chờ 3000 ms), và cuộn lazy-load nếu `simulateScrollForLazyLoad`. Trước 7.101 chụp trang ngay lúc DOMContentLoaded.
- Chạy **headed dưới `xvfb-run`** nếu có `DISPLAY`; không có thì rơi về headless (7.101).
- Gặp trang chặn (Cloudflare/captcha) dai dẳng: dừng job, chụp màn hình, chờ người xử lý qua điều khiển từ xa (khối interactive); không tự bỏ qua chương.
- Không hỗ trợ `useLoginSession`; dùng `cookieHeader`.
- **Từ 7.103** hỗ trợ cùng ngữ nghĩa như cào tại máy: **bỏ qua chương** (`skipIfTextContains` so trên văn bản thô, không phân biệt hoa thường; `minTextLength` so trên văn bản đã xử lý; chương bị bỏ không vào ebook, không tốn `index`, không vào kho) và **chương nhiều trang** (`chapterNextPageSelector` + `maxChapterPages`: lấy link `href` đầu tiên khớp, tự dừng khi hết link / đủ số trang / link trỏ sang chương khác trong danh sách / link đã thăm; tiêu đề lấy ở trang 1; trang ≥ 2 lỗi thì giữ phần đã có và thêm một dòng ghi chú). Thống kê `skippedCount` nằm trong checkpoint xong. Trước 7.103 `crawler.py` bỏ qua hai tuỳ chọn này một cách im lặng (chương VIP/quá ngắn vẫn vào ebook, chương nhiều trang chỉ lấy trang 1).
- Hằng số: `PAGE_TIMEOUT_MS = 30_000`, `CLOUDFLARE_MAX_RETRIES = 2`, commit checkpoint mỗi 5 chương hoặc 120 giây, `MAX_IMAGE_BYTES = 6 MiB`.

---

## 5. Thuật toán cào tại máy (các pha)

| Pha | Việc | Lưu checkpoint |
|---|---|---|
| -1 | Kịch bản nhiều bước (`preListStages`): duyệt trước để tìm trang danh sách thật | Sau khi xong toàn bộ kịch bản |
| 0 | Tự dò phân trang (`autoDetectPagination`) | — |
| 1 | Thu link chương từ `listPageUrl` / `listPageUrlPattern` (`{page}`), tối đa `maxPages`, bằng `chapterLinkSelector` + `chapterLinkAttribute` | Sau mỗi "entry" nguồn |
| 2 | Với từng link: mở, lấy tiêu đề/nội dung bằng `chapterTitleSelector`/`chapterContentSelector`, áp luật tìm & thay, tải ảnh (nếu bật), (tuỳ chọn) đăng WordPress | **Sau mỗi chương** |
| 3 | Xuất ebook (hoặc chờ sắp xếp mục lục nếu `manualTocReview`) | Xoá checkpoint khi xong |

Script lấy dữ liệu là `EbookLeechCrawler.collectLinksJs` / `extractChapterJs` (JSON trả về: `links`; hoặc `title`, `html`, `text`, `tm`/`cm` = selector khớp thật hay rơi mặc định, `next` = link trang kế). `SelectorTester` dùng đúng hai script này.

Tiếp tục sau khi app bị kill: `resumeInterruptedJobs` đọc checkpoint và cào tiếp đúng chương dở (độ chi tiết xem chú thích đầu `CrawlCheckpoint.kt`).

---

## 6. Cập nhật truyện chưa hoàn thành

### 6.1 Cào tại máy + "♻️ Chỉ cào chương mới" (bản 7.100/7.101)
1. Mỗi lần chạy **vẫn quét lại toàn bộ trang danh sách** (từ 7.104: chỉ khi tắt `listFastScan` hoặc đến lượt quét đầy đủ — mục 6.7) — xem mục 6.4c: đây là giới hạn BẢN CHẤT (muốn biết site có chương mới hay chưa thì phải đọc danh sách), chỉ giảm được chứ không bỏ được; chưa làm phần giảm.
2. Chương nào đã có trong kho theo `sourceUrl` thì dùng lại, không mở trang; chương chưa có thì mở và cào. `refreshLastN` > 0: cào lại N chương cuối (lỗi mạng khi cào lại thì giữ bản kho).
3. Quy tắc bỏ qua (`skipIfTextContains`, `minTextLength`): chương bị bỏ không vào ebook, không tốn số thứ tự, không lưu kho (lần sau site mở khoá vẫn thử lại).
4. Chương nhiều trang: `chapterNextPageSelector` + `maxChapterPages`; tự dừng khi hết link, đủ số trang, link lặp, hoặc link trỏ sang chương khác trong danh sách.

### 6.2 Lịch
`INTERVAL`/`DAILY` + dịch vụ nền (mục 2). Job `DONE` đến hạn sẽ tự chạy lại. Điều kiện: khe đang mở trong tiến trình, service chưa bị hệ thống dừng.

### 6.3 Xuất ebook sau mỗi lần chạy
- Mặc định mỗi lần xuất tạo **file mới** có dấu thời gian trong tên (`Downloads/EbookLeech/<job>/…_yyyyMMdd_HHmm.epub`); file cũ giữ nguyên.
- **Bản 7.101:** khi bật "Chỉ cào chương mới" và lần chạy này **giống hệt** lần xuất trước (cùng danh sách chương, tiêu đề, HTML; cùng chữ ký cấu hình xuất; file ebook cũ vẫn còn; không bật "xem trước mục lục"), không xuất lại, giữ `outputFilePath` cũ và ghi `lastRunNote` = "… không có chương mới …". Có chương mới/đổi nội dung/đổi định dạng/xoá file cũ → xuất như thường. (Từ 7.102 việc so sánh này nằm ở `ExportFollowUp.canSkipExport` cho đường cào từ xa; đường cào tại máy vẫn so với kho chương.)
- **Bản 7.102 — "Cập nhật Ở FILE CŨ" (`updateExistingFile=true`):** tên file cố định `<tên>.<đuôi>` (không dấu thời gian). Khi xuất, `EbookExporter` tìm trong MediaStore bản ghi cùng `DISPLAY_NAME` + `RELATIVE_PATH` (`Download/EbookLeech/<job>/`) rồi mở `openOutputStream(uri, "wt")` ghi đè (cắt về 0 rồi ghi); không tìm thấy hoặc không ghi được thì **rơi về tạo file mới** (không mất dữ liệu). Ebook vẫn dựng lại **toàn bộ** truyện: EPUB là file zip nên "nối thêm chương" thực chất là ghi lại cả file. Không có chế độ file phụ chỉ chứa chương mới.
- **Bản 7.102 — thông báo chương mới:** xem mục 6.5.

### 6.4 Cào từ xa — "Chỉ cào chương mới" (bản 7.102, giao thức đổi ở 7.103)
**Trước 7.102** `crawler.py` không có cập nhật tăng dần, và còn một lỗi lớn: chạy lại một job đã xong sẽ đọc checkpoint cũ (`remoteDone=true`), thấy đã làm xong hết `chapterLinks` cũ, **không thu lại danh sách chương**, xuất lại đúng dữ liệu cũ (đã tái hiện: site tăng 5 → 8 chương, lần hai vẫn ra 5). Bản 7.101 chữa bằng cách ghi đè checkpoint đã xong bằng bản rỗng, nhưng cách đó phá luôn dữ liệu cần để dùng lại chương → mỗi lần phải cào lại toàn bộ.

**Thiết kế 7.102 (đã THAY ở 7.103 — giữ lại để hiểu mã cũ và vì sao đổi):** quyết định "đây là lần chạy mới" nằm hoàn toàn trong `crawler.py`: thấy checkpoint `remoteDone=true` thì coi là lần chạy trước, tự dựng `-archive.json` từ `chaptersSoFar` cũ rồi thu lại danh sách. Điện thoại không đụng checkpoint cũ, chỉ nhớ `savedAt` của nó (`staleDoneSavedAt`, lưu SharedPreferences) để bỏ qua kết quả cũ khi poll; nhận checkpoint xong mới mà **thiếu `runnerVersion`** thì báo "crawler.py trong repo là bản CŨ" thay vì xuất lại dữ liệu cũ. Phần còn lại (dùng lại theo `sourceUrl`, giữ `index` + tên ảnh, `refreshLastN`, commit theo số chương VỪA cào ≥ 5 hoặc 120 giây, bị ngắt thì chạy tiếp và nạp lại `-archive.json`, thống kê `reusedCount`/`crawledCount`) vẫn đúng ở 7.103.

**Vì sao đổi ở 7.103 (lỗi tìm ra khi làm đồng bộ với LeechDesk):** logic "checkpoint xong = lần chạy trước" là một **hợp đồng ngầm chỉ `crawler.py` hiểu**. Runner thứ ba (LeechDesk 1.2 trở xuống) thấy checkpoint `remoteDone=true` thì làm đúng điều đã dạy nó từ trước: coi là *đã xong* và trả lại nguyên kết quả cũ mà không mở trang nào (đã tái hiện: site có thêm chương, 7.102 + LeechDesk 1.2.0 vẫn trả 6 chương cũ, 0 trang được mở). Tức là **bản 7.102 làm hỏng việc chạy lại job qua LeechDesk** — và hỏng im lặng. Sửa không nằm ở LeechDesk mà ở giao thức, để mọi runner (hiện có và tương lai) chạy đúng mà không phải học luật riêng.

### 6.4b Giao thức "lần chạy mới" (bản 7.103, không phụ thuộc runner)
Khi người dùng bấm chạy một job từ xa **mới hoàn toàn** (không phải nối lại checkpoint dở), điện thoại (`RemoteCrawlRunner.prepareFreshRemoteRun`) làm theo THỨ TỰ này:
1. Đọc checkpoint đang có trên repo. Nếu nó `remoteDone=true` **và** job bật `incrementalUpdate` → ghi nguyên checkpoint đó thành `remote-jobs/<id>-archive.json` (kho chương lần trước).
2. Ghi đè `remote-jobs/<id>-checkpoint.json` bằng một checkpoint **rỗng, chưa xong** (`COLLECTING_LINKS`, 0 chương, không có `remoteDone`).
3. Ghi `remote-jobs/<id>.json` (job-spec) **CUỐI CÙNG**, kèm `runRequestedAt` = giờ bấm chạy (ms).
4. Rồi mới dispatch workflow / báo người dùng bấm "Run all".

Hệ quả: với mọi runner, tình huống hiện ra là trường hợp cổ điển "có checkpoint dở, chưa có chương nào" nên một runner **cũ hoàn toàn** vẫn cào đúng từ đầu; runner mới đọc thêm `-archive.json` để cào tăng dần. Spec ghi CUỐI vì runner có "tự nhận" (LeechDesk `autoAccept`) có thể bắt đầu ngay khi thấy spec đổi — nếu spec ghi trước thì nó thấy checkpoint xong cũ mà chưa có archive. Job không bật `incrementalUpdate`: không ghi archive (và xoá archive cũ nếu có), vẫn reset checkpoint → cào lại toàn bộ như mong muốn. Poll phía điện thoại giữ nguyên các lớp bảo vệ 7.102 (mốc `staleDoneSavedAt`, báo lỗi thiếu `runnerVersion`) — với giao thức mới chúng chỉ còn là lưới an toàn cho repo giữ `crawler.py` cũ.
`crawler.py` 7.103 vẫn giữ nhánh cũ "checkpoint xong = lần chạy trước" (cho repo chưa cập nhật điện thoại / job do công cụ khác tạo).

### 6.4c Giới hạn còn lại của cào từ xa (7.103) — nói thẳng
Đã giải quyết ở 7.103: bỏ qua chương + chương nhiều trang (6.4 / 4.2); khoảng trống `index` do `refreshLastN` (chương cào lại **giữ `index` cũ**; chương mới nhận `index_cao_nhất + 1` với `index_cao_nhất` tính cả kho nên tên ảnh `img_<index>_<n>` không đụng nhau; LeechDesk giữ `index` hợp lệ + duy nhất thay vì đánh số lại); xoá kho mất mốc xuất (6.5); chạy lại job qua runner khác `crawler.py` (LeechDesk 1.3, mục 8.0).
**Còn lại, KHÔNG phải do thiếu việc:**
1. *(7.104: đã GIẢM bằng quét nhanh theo điểm neo — xem 6.7; giới hạn còn lại ghi ở đó.)* *Quét lại toàn bộ trang danh sách mỗi lần.* Bản chất: không có cách đáng tin để biết site có chương mới mà không đọc danh sách. Chỉ giảm được: nếu trang danh sách phân trang theo thứ tự mới nhất trước, có thể dừng sớm khi gặp một chương đã có trong kho. Hướng này **chưa làm** vì sai với site sắp xếp cũ-nhất-trước hoặc đổi thứ tự, và vì rủi ro bỏ sót chương lớn hơn lợi ích (mỗi trang danh sách rẻ hơn nhiều so với một chương).
2. *Lần chạy tăng dần đầu tiên chỉ dùng lại được khi repo đã có checkpoint `remoteDone=true` của lần trước* (job mới, hoặc lần trước bị lỗi/ngắt thì phải cào hết). Không có cách khác: dữ liệu để "dùng lại" chỉ có ở đó. (Với job vừa cào TẠI MÁY, kho chương nằm ở điện thoại và không tự đẩy lên repo.)
3. *Bên thứ ba ghi checkpoint dở KHÔNG được đặt `remoteDone=true`:* `crawler.py` (nhánh cũ) sẽ coi đó là lần chạy đã xong.
4. *Runner cũ hơn (crawler.py ≤ 7.102 trong repo, LeechDesk < 1.3):* vẫn cào đúng nhưng **cào lại toàn bộ** (không tăng dần). `crawler.py` 7.102 chạy thật với chuỗi ghi file của 7.103 (`app_fresh`): đủ 8 chương, `reusedCount=0`, `runnerVersion=7.102` — vì nhánh "chạy tiếp" của nó không nạp kho. Điện thoại 7.103 nhận ra trường hợp này (`incrementalRequested`, `reusedCount=0`, `runnerVersion` < 7.103) và ghi vào thẻ job "crawler.py trong repo là bản cũ hơn 7.103…". Runner không khai `runnerVersion` (crawler.py 7.101, LeechDesk < 1.3) thì thẻ job ghi "runner cũ chưa hỗ trợ chỉ-cào-chương-mới". LeechDesk < 1.3 còn hiện thêm một "job" ma tên `<id>-archive` trong hộp thư.
5. Checkpoint do `crawler.py` 7.101 tạo có cùng cấu trúc (thiếu `runnerVersion`/`reusedCount`/`crawledCount`) nên dùng lại được — kịch bản `inc_foreign` — nhưng chưa thử trên repo GitHub thật.

### 6.5 Thông báo "có chương mới" (bản 7.102)
- Sau mỗi lần xuất thành công (cào tại máy, cào từ xa, hoặc xuất sau khi sắp xếp mục lục), `ExportFollowUp.compare` so danh sách chương với `.baseline` của lần xuất trước. **Chương mới = chương có `sourceUrl` không nằm trong mốc.** Sửa nội dung một chương cũ làm dòng mốc đổi (nên vẫn xuất lại) nhưng **không** tính chương mới.
- Gọi `onNewChapters(newCount, total)` => `EbookLeechScheduler` => `EbookLeechService.postNewChaptersNotification` khi và chỉ khi: `job.notifyNewChapters`, **đã có mốc** (lần đầu không báo) và `newCount > 0`. Không xuất lại (không đổi) => không báo.
- Thông báo: kênh `ebook_leech_new_chapters_channel` (độ ưu tiên mặc định), id `9500 + hash(tên job)` (mỗi job một thông báo, lần sau đè lên). Bấm vào: nếu `outputFilePath` là `content://` thì `ACTION_VIEW` với MIME của định dạng (epub/html/txt) cấp quyền đọc URI; ngược lại mở app. Android 13+ cần quyền `POST_NOTIFICATIONS` (đã khai báo trong manifest); chưa cấp thì hệ thống âm thầm bỏ qua.
- `lastRunNote` hiện cho mọi job: `dd/MM HH:mm — xuất lần đầu N chương` | `+K chương mới (tổng N)` | `tổng N chương, không có chương mới`, kèm chi tiết `(mở trang A chương, dùng lại B từ kho)` hoặc `(máy chủ mở trang A, dùng lại B)`.
- **Bản 7.103:** nút "Xoá kho" chỉ xoá KHO CHƯƠNG (nội dung + ảnh; `ChapterArchiveRepository.deleteArchive`) và **giữ** mốc xuất `.baseline` + chữ ký cấu hình (chỉ vài chục KB: URL + băm), nên lần cào lại sau đó vẫn báo đúng "+N chương mới". Trước 7.103 xoá kho làm mất mốc → lần sau bị coi là "xuất lần đầu" và không báo chương mới. Xoá HẲN job (`ChapterArchiveRepository.delete`) vẫn xoá cả mốc. Thêm: nếu mốc cũ **không trùng URL nào** với danh sách mới (đổi link nguồn / đổi cấu trúc trang) thì `compare` coi như xuất lần đầu thay vì báo "+N chương mới" cho cả cuốn (`ExportFollowUp.compare`).

### 6.6 Mục lục trong ebook (`EbookExporter`)
- **EPUB:** có `OEBPS/nav.xhtml` (EPUB3, `<nav epub:type="toc">`, danh sách `<ol>` lồng nhau) **và** `OEBPS/toc.ncx` (EPUB2, `navPoint` lồng nhau); mỗi chương một mục theo thứ tự danh sách. Mặc định mục phẳng (không có "Tập"); có phân cấp (Tập → chương) chỉ khi người dùng sắp xếp thủ công qua `tocOverride` (mục 9 của hướng dẫn). `index` chương phải duy nhất vì dùng làm tên entry `chapter_<index>.xhtml` và khoá mục lục.
- **HTML:** khung `<div id="toc">` ở đầu trang, danh sách `<ol>` các link nhảy tới từng chương (lồng nhau khi có Tập).
- **TXT:** KHÔNG có danh sách mục lục; chỉ có tên truyện, rồi từng chương gồm dòng tiêu đề + đường kẻ + nội dung (Tập hiện dạng dòng `# tên tập`).
- Mức kiểm chứng: đọc mã và (với EPUB/HTML) kiểm cấu trúc đầu ra; **chưa mở thử bằng ứng dụng đọc EPUB thật**.

---

### 6.7 Quét nhanh danh sách theo điểm neo (bản 7.104)
**Vì sao.** Quét lại mọi trang danh sách mỗi lần tốn N lượt tải (N = số trang), dễ chạm giới hạn tốc độ/chống bot. Hướng "đặt điểm neo rồi lần sau bắt đầu chỗ kết thúc" là hướng quen thuộc (KDN có con trỏ URL cào gần nhất và tuỳ chọn cào lại từ trang cuối — `PostSaver.php`, các khoá `_last_crawled_url_id` / `_active_recrawling_from_last_page`, chỉ xác nhận SỰ TỒN TẠI; Scrapy DeltaFetch bỏ qua request đã thấy ở lần trước) nên 7.104 làm theo, nhưng có đường lui vì hướng này có điểm mù.
**Thuật toán** (`ListScanPlanner`, bộ lập kế hoạch có CÙNG thuật toán ở `E/engine/ListScanPlanner.kt`, `remote_runner/crawler.py` và LeechDesk `ld/incremental.py`; phần Python ở hai nơi giống từng ký tự, phần Kotlin được so khớp hành vi bằng 3000 ca):
1. *ĐẦU:* mở trang 1; nếu có link đã biết (từ kho) ⇒ đã chạm vùng cũ.
2. *THĂM DÒ:* nhảy tới trang `gợi ý trang cuối − 1` (gợi ý = số trang lần trước) để kiểm tra có link đã biết không và danh sách có dài thêm không.
3. *CUỐI:* quét tiếp từ đó đến hết. Danh sách cuối = phần mới đọc ở ĐẦU + phần giữa lấy từ kho + phần mới ở CUỐI.
4. *Đường lui:* trang bị chặn, trang 1 rỗng dù kho có chương (⇒ coi như bị chặn, GIỮ danh sách cũ — `[Phase1] Trang 1 rong …`), không tìm thấy điểm neo, hoặc đã `FAST_SCAN_MAX_STREAK = 10` lần quét nhanh liên tiếp ⇒ quét đầy đủ.
**Điều kiện áp dụng** (`EbookLeechCrawler.canPlanScan`, cùng điều kiện ở runner Python): `incrementalUpdate` + kho không rỗng + KHÔNG có `preListStages` + đúng một nguồn danh sách + không phải nối lại checkpoint đang ở giai đoạn thu link + biết mẫu phân trang (`listPageUrlPattern`/mẫu đã tự dò) hoặc chế độ AJAX có `ajaxListUrlTemplate`. Quét NHANH còn cần `listScan.lastPage ≥ 1` từ lần trước ⇒ lần đầu (và lần đầu sau khi nâng từ kho 7.103) chạy bộ lập kế hoạch ở chế độ ĐẦY ĐỦ (giống vòng lặp cũ, nhưng giữ danh sách cũ nếu trang lỗi giữa chừng) rồi ghi nhớ trang cuối.
Công tắc: `LeechJob.listFastScan` (mặc định bật; hộp tick "⚡ Quét nhanh danh sách theo điểm neo" trong cài đặt EbookLeech; LeechDesk: tab "Cập nhật & thông tin truyện"). Thông tin lần quét (`listScan`: mode, lastPage, pagesLoaded, skippedPages, fastStreak) nằm trong checkpoint/kho; log/ghi chú lần chạy: "Quét nhanh: đọc A trang, bỏ qua B trang giữa danh sách …".
**Giới hạn (đã chứng minh bằng test, KHÔNG phải ước đoán):** chương được chèn GIỮA danh sách (không ở đầu/cuối) và chương bị đổi tên/đổi URL ở giữa chỉ thấy ở lần quét đầy đủ kế tiếp (tối đa 10 lần sau, hoặc khi bạn tắt `listFastScan`). Site đảo thứ tự danh sách giữa các lần làm điểm neo sai ⇒ rơi về quét đầy đủ.

### 6.8 Thông tin truyện (story meta) — bản 7.104
**Mục tiêu:** ebook là nguyên liệu để đăng lên web truyện, nên mang theo thông tin chứ không chỉ chữ.
**Lược đồ** `ebookleech.story/1` (`E/model/StoryMeta.kt`): `title, author, summary, summaryHtml, genres[], tags[], status, statusText, rating{value,scale,count}, language, sourceUrl, sourceSite, coverUrl, coverFile, coverMime, altTitles[], series, seriesIndex, publishedAt, updatedAt, translator, publisher, extra{}, sources{trường→nguồn}, fetchedAt`.
**Cấu hình job:** `storyMetaEnabled` (mặc định bật), `storyInfoUrl` (trang chứa thông tin; rỗng = trang danh sách), `storyMetaSelectors`, `storyMetaManual`, `storyMetaWaitMs` (chỉ runner từ xa đọc; điện thoại dùng độ trễ cố định ~0,8 s), `storySidecar` (xuất `.story.json`).
**Lấy từ đâu** (`E/engine/StoryMetaJs.kt` — hằng `STORY_META_JS`, chạy trong trang danh sách/giới thiệu): selector người dùng (`storyMetaSelectors`) > JSON-LD (kể cả `@graph` kiểu Yoast, bỏ tác giả "admin") > Open Graph/meta > microdata (`itemprop` trong `[itemtype*="Book"]`) > nhãn "Tác giả:/Thể loại:/Tình trạng:/Đánh giá:/Cập nhật:" > h1/`<title>`. Mỗi trường ghi lại nguồn trong `sources`. **Gộp qua các lần:** lần trước < mới trích < nhập tay (`storyMetaManual`). Script này GIỐNG TỪNG BYTE ở `tools/story_meta/story_meta.js`, `crawler.py`, `StoryMetaJs.kt`, LeechDesk `ld/storymeta.py` (kiểm bằng `tools/story_meta/story_meta_identity.py`; `StoryMetaJs.kt` do `tools/gen_story_meta_kt.py` sinh — sửa JS nguồn rồi sinh lại, đừng sửa tay).
**Xuất** (`E/export/EbookMarkup.kt`, `EbookExporter`):
| Định dạng | Nội dung |
|---|---|
| EPUB | OPF: `dc:title`, `dc:creator`, `dc:description`, `dc:subject` (thể loại + nhãn), `dc:language`, `dc:source`, `calibre:series`/`series_index`, ảnh bìa (`cover-image`); trang `info.xhtml` ("Giới thiệu") đứng đầu spine + mục lục; XHTML được làm sạch nghiêm ngặt (`xhtmlFix`) |
| TXT / HTML | khối thông tin ở đầu file |
| Cạnh ebook | `<tên>.story.json` (toàn bộ lược đồ + `webMapping`: post_title, excerpt, content, categories, tags, featured_image, trường tuỳ chỉnh — để công cụ đăng truyện lên web đọc) và `<tên>.cover.<đuôi>` |
**Luật "chỉ khi có gì để nói":** trang "Giới thiệu" (EPUB) và khối thông tin (TXT/HTML) chỉ được thêm khi có nội dung NGOÀI tên truyện/nguồn/ngôn ngữ, hoặc có ảnh bìa (`hasInfoPage`, `headerRows`). Lý do: gần như trang nào cũng có `<h1>`/`<title>`, nếu không gate thì mọi ebook đều có trang "Giới thiệu" gần rỗng. Python (LeechDesk) cùng luật (`has_info_page`, `header_rows`).
**Bảng so với các công cụ cùng loại** (nguồn ở PROJECT_STATUS §228.9; so ở mức trường dữ liệu công khai, không phải so mã):
| Tính năng | FanFicFare | lightnovel-crawler | EbookLeech 7.104 |
|---|---|---|---|
| Tên/tác giả/tóm tắt | có | có (`title`, `authors`, `synopsis`) | có |
| Thể loại/nhãn vào metadata ebook | có (`include_subject_tags`) | `tags` | có (`dc:subject`) |
| Trạng thái đang ra/hoàn thành | có (trang tiêu đề) | — (chưa thấy ở trang đã đọc) | có (`status`, `statusText`) |
| Xếp hạng | chưa xác minh | chưa thấy | có (`rating{value,scale,count}`) |
| Series | có (một số site) | — | có (`series`, `seriesIndex`) |
| Bìa | có | `cover_url`/`cover_file` | có (tải một lần, dùng lại) |
| Cập nhật dùng lại chương cũ | có (trong EPUB cũ) | — | có (kho chương, 7.100) + quét nhanh danh sách (7.104) |
| Dữ liệu cho đăng web | — | — | `.story.json` + `webMapping` |
**Chưa có (nói thẳng):** thông tin theo TỪNG chương (ngày đăng, người dịch từng chương); gộp truyện trùng/nhiều nguồn; kiểm tra liên kết hỏng; tự đăng lên web (chỉ tạo dữ liệu); với site không có dữ liệu cấu trúc/nhãn quen thuộc phải đặt selector hoặc nhập tay.

### 6.9 Điện thoại → cloud → PC nối tiếp việc dở (bản 7.104)
Khi job bật chạy từ xa/đồng bộ, `ArchiveSeed.build` (`E/remote/ArchiveSeed.kt`) dựng kho `{chaptersSoFar, chapterLinks, listScan, storyMeta}` từ những chương ĐÃ cào ở máy (thứ tự, URL, nội dung, điểm neo danh sách, thông tin truyện, kích thước ảnh), `RemoteCrawlRunner` đẩy lên `remote-jobs/<id>-archive.json` (+ `-images/` gồm ảnh bìa). Runner (crawler.py / LeechDesk) đọc kho → quét nhanh theo điểm neo → chỉ cào chương mới → đẩy checkpoint về, **kèm `storyMeta`**, điện thoại lưu lại. Kho là `{…}` (đối tượng); dạng cũ (mảng chương) vẫn đọc được; kho hỏng (không phải mảng) coi như rỗng.
Giới hạn: phần Kotlin (dựng kho, đẩy, lưu lại) mới BIÊN DỊCH, chưa chạy với GitHub thật hay điện thoại thật; phía Python/LeechDesk đã chạy thật với GitHub giả và `FakeAddon` (bắt chước chuỗi ghi file của Kotlin).

---

## 7. Giao thức cào từ xa (qua repo GitHub)

Điện thoại và máy chủ cào **chỉ nói chuyện qua file trong repo**, theo đường dẫn tính từ gốc repo (đặc điểm của Contents API):

| File | Ai ghi | Nội dung |
|---|---|---|
| `remote-jobs/<id>.json` | Điện thoại | `LeechJob` (mục 3.1) **+ `runRequestedAt`** (ms, 7.103: giờ bấm chạy lần mới; runner tự nhận so với mốc đã nhận để biết có lần chạy mới). Ghi CUỐI CÙNG trong chuỗi chuẩn bị (6.4b) |
| `remote-jobs/<id>-checkpoint.json` | Runner (`crawler.py` / LeechDesk) và điện thoại (reset rỗng lúc bấm chạy lần mới; hoặc khi chuyển job dở sang từ xa) | `CrawlCheckpoint` + `remoteDone` + (7.102/7.103) `savedAt`, `runnerVersion`, `reusedCount`, `crawledCount`, `skippedCount` (mục 3.3) |
| `remote-jobs/<id>-archive.json` | Điện thoại (7.103, lúc bấm chạy lần mới, chỉ khi job bật `incrementalUpdate`); `crawler.py` nhánh cũ (7.102) | Kho chương của lần chạy trước: **mảng `LeechChapter` HOẶC nguyên checkpoint `remoteDone=true`** (có khoá `chaptersSoFar`) — runner phải đọc được cả hai. `crawler.py` xoá khi xong; LeechDesk không xoá (file nằm tới lần bấm chạy kế tiếp, khi điện thoại ghi đè hoặc xoá). Runner KHÔNG được coi file này là một job |
| `remote-jobs/<id>-images/<tên file>` | `crawler.py` | Ảnh đã tải |
| `remote-jobs/<id>-heartbeat.json` | `crawler.py` mỗi ~45 giây | Dấu thời gian "còn sống" |
| `remote-jobs/<id>-cmd.json` | Điện thoại | Lệnh điều khiển từ xa khi đang chờ giải xác minh |
| `remote-jobs/<id>-storage-state.json` | `crawler.py` | Phiên trình duyệt (cookie…) để tiếp tục sau khi giải xác minh |
| `leechdesk-status/<instanceId>.json` | LeechDesk (1.3) | `{id,name,kind:"leechdesk",version,ts(ms),jobs:[{id,name,status,done,total}]}` — bản tin trạng thái của một máy LeechDesk; điện thoại đọc để hiện màn hình theo dõi (`LeechDeskHub`, mục 8.0) |

Luồng (GitHub Actions):
1. Điện thoại chuẩn bị theo 6.4b: lần chạy mới hoàn toàn => (nếu `incrementalUpdate`) lưu checkpoint xong cũ thành `-archive.json`, reset checkpoint thành bản rỗng chưa xong, ghi `<id>.json` CUỐI CÙNG kèm `runRequestedAt`; nối lại job dở => ghi checkpoint cục bộ dở. (7.102 giữ nguyên checkpoint xong cũ và nhớ `savedAt` của nó — gây lỗi với runner không phải `crawler.py`, mục 6.4.) Rồi gọi `POST /repos/{owner}/{repo}/actions/workflows/ebookleech-remote-crawl.yml/dispatches` với `inputs.job_id`.
2. Workflow (`ubuntu-latest`, `timeout-minutes: 180`, `permissions: contents: write`) lấy mã crawler từ thư mục `colab-live-browser/ebookleech/remote_runner/` nếu có, **hoặc giải nén từ `colab-live-browser-project.zip` ở gốc repo** (7.101; quy trình build của dự án chỉ đẩy file zip nên checkout thường không thấy thư mục đã giải nén), đặt ra ngoài cây git (`$RUNNER_TEMP/ebookleech-src`, vì `crawler.py` chạy `git add -A`), cài Python 3.11, thư viện, Chromium, Xvfb rồi chạy `xvfb-run … python3 "$EBOOKLEECH_SRC/crawler.py" <id>` **với thư mục làm việc = gốc repo** (`crawler.py` lấy `repo_dir = os.getcwd()`, không phụ thuộc vị trí file script).
3. Runner đọc `<id>.json`; checkpoint **chưa xong** => tiếp tục (nếu có `-archive.json` thì nạp làm kho dùng lại — đây là cách lần chạy mới tăng dần bắt đầu và cũng là cách chạy tiếp sau khi bị ngắt); checkpoint **`remoteDone=true`** (chỉ gặp với điện thoại cũ/công cụ khác) => `crawler.py` coi là lần chạy mới (mục 6.4); không có checkpoint => bắt đầu mới. Commit + push checkpoint và ảnh mỗi 5 chương **vừa cào** hoặc 120 giây; cuối cùng ghi `remoteDone=true` kèm `runnerVersion`/`reusedCount`/`crawledCount`.
4. Điện thoại poll mỗi 20 giây (5 giây khi đang chờ lệnh tương tác), đọc checkpoint, tải ảnh mới, cập nhật tiến độ; khi `remoteDone=true` thì lấy `chaptersSoFar` và xuất ebook **tại điện thoại**.

Colab: không có API dispatch; điện thoại chỉ ghi file và hiện link mở notebook, người dùng bấm "Run all". Notebook phải chạy với thư mục làm việc = gốc repo (đã sửa ở 7.101: bản cũ `chdir` vào thư mục con nên `crawler.py` báo `No such file: remote-jobs/<id>.json`) và, giống workflow, tự lấy `crawler.py` từ thư mục đã giải nén hoặc từ file zip ở gốc repo (giải nén bằng `zipfile` vào `ebookleech_src/` ngoài repo).

---

## 8. Đồng bộ với một ứng dụng leech khác (ví dụ LeechDesk trên PC)

Từ 7.103 có một đường đồng bộ chính thức với **LeechDesk 1.3** (app cào chạy trên PC/VPS, Python thuần, do bạn đính kèm): hai bên nói chuyện qua cùng repo GitHub `remote-jobs/` — **không cần cổng/API riêng**. Các mục A–D bên dưới là các điểm tiếp xúc cấp thấp (vẫn đúng), 8.0 là cách dùng thực tế. Chưa có đồng bộ hai chiều thời gian thực và không có xử lý xung đột ngoài "mỗi job một runner tại một thời điểm".

### 8.0 LeechDesk như một runner thay GitHub Actions/Colab (bản 7.103)
**Điện thoại → LeechDesk (giao việc).** Job đặt "Chạy từ xa" (GitHub): điện thoại ghi spec + checkpoint theo 6.4b. LeechDesk (bật "Cầu nối addon", cùng repo + nhánh + token) thấy job ở hộp thư: *Nhận & chạy tiếp*, hoặc **Tự nhận** (VPS không người trực — nhận cả khi `runRequestedAt` mới hơn mốc đã nhận, tức là job đã xong lần trước nay bấm chạy lại). LeechDesk cào bằng **cùng ngữ nghĩa với `crawler.py`**: dùng lại chương theo `sourceUrl` từ `-archive.json` (giữ `index` + ảnh), `refreshLastN`, bỏ qua chương, chương nhiều trang, `index` chương mới = cao nhất + 1; đẩy checkpoint định kỳ (mặc định 120 s) + heartbeat (60 s); khi xong đẩy `remoteDone=true` kèm `runnerVersion="leechdesk-<phiên bản>"`, `reusedCount`, `crawledCount`, `skippedCount`. Điện thoại nhận bằng đường poll sẵn có và xuất ebook tại máy (so mốc, báo chương mới, ghi chú: thẻ job ghi tên runner qua `runnerLabel`).
**LeechDesk → điện thoại (giao ngược).** Nút "📤 Giao addon" đẩy spec + checkpoint dở (`remoteDone=false`); điện thoại nối tiếp. Job LeechDesk đang cào "hộ" điện thoại nhưng có `manualTocReview` thì giữ `remoteDone=false` tới khi người dùng sắp xếp mục lục ở LeechDesk, rồi đẩy spec kèm `tocOverride` trước `remoteDone=true`; điện thoại 7.103 dùng `tocOverride` đó (`RemoteCrawlRunner.mergeTocFromRemoteSpec`, tương ứng bản vá 0002 của LeechDesk).
**Màn hình theo dõi trên điện thoại** (Cài đặt EbookLeech → "🖥 Máy LeechDesk (PC)", `LeechDeskHub`): đọc `leechdesk-status/*.json` → máy nào (online nếu bản tin < 2 phút), từng job % tiến độ, cảnh báo máy chạy LeechDesk < 1.3; và **hộp thư nhận job**: liệt kê `remote-jobs/*.json` mà điện thoại chưa có, nhập một job (spec + checkpoint) về làm job cục bộ. Hộp thư bỏ qua `-checkpoint/-archive/-heartbeat/-cmd/-storage-state/-images`.
**Giao thức file** (không đổi cho runner cũ): mục 7 + `PROTOCOL.md` §B của LeechDesk.
**Kích thước/giới hạn GitHub** (đã tra tài liệu, xem "Nguồn" cuối): đọc file > 1 MB phải dùng media type `raw` (JSON thường chỉ trả nội dung ≤ 1 MB; `object` để lấy `sha` của file lớn; tối đa 100 MB); danh sách thư mục qua Contents API cắt ở **1000 mục** (đồng bộ nhiều job → dùng Git Trees API, từng cấp không đệ quy); `If-None-Match` + ETag trả 304 không tính vào hạn mức chính; giới hạn phụ (secondary) trả 403/429 kèm `Retry-After`; PUT trượt `sha` (409/422) thử lại một lần. `GitHubApiClient` 7.103 làm tất cả (trước đó: đọc JSON thường nên hỏng với checkpoint > 1 MB, và `getFileSha` coi file lớn là "file mới" nên không ghi đè được).
**Tương thích ngược:** LeechDesk **1.2** hay cũ hơn vẫn cào ĐÚNG với điện thoại 7.103 (vì giao thức 6.4b trông như một job mới hoàn toàn), nhưng cào lại toàn bộ, không có `runnerVersion` (điện thoại không báo lỗi vì checkpoint không phải xong-cũ), và hiện thêm entry `<id>-archive` ở hộp thư. **Điện thoại ≤ 7.102 + LeechDesk (kể cả 1.3) KHÔNG chạy lại được job đã xong** (đã tái hiện bằng `test_7102_flow.py` với cả 1.2.0 và 1.3.0: site thêm chương, LeechDesk vẫn trả `done` với chương cũ, không mở trang nào): điện thoại 7.102 chỉ ghi lại spec, không đổi checkpoint xong và không có dấu hiệu `runRequestedAt`, nên runner không thể phân biệt "chạy lại" với "đã xong ở runner khác". Muốn chạy lại job qua LeechDesk phải dùng điện thoại 7.103. Job chạy lần đầu (chưa có checkpoint xong) thì mọi tổ hợp đều đúng.

### A. Chỉ theo dõi tiến độ (chỉ đọc) — chỉ với job cào từ xa
App PC đọc (Contents API hoặc raw) `remote-jobs/<id>-checkpoint.json` và `-heartbeat.json` bằng token chỉ-đọc (Contents: read).
- Phần trăm: `len(chaptersSoFar) / len(chapterLinks)` (khi `chapterLinks` rỗng thì chưa biết tổng).
- Xong: `remoteDone == true`. Với điện thoại **7.103** checkpoint bị reset về bản rỗng chưa xong lúc bấm chạy (6.4b) nên `remoteDone` thuộc về lần chạy HIỆN TẠI; nếu cần chắc, so thêm `savedAt` mới hơn `runRequestedAt` trong spec. (Điện thoại 7.102 giữ kết quả xong của lần trước tới khi runner ghi đè, nên `remoteDone` một mình không đủ.) Thống kê tăng dần: `reusedCount`/`crawledCount`. Đang chờ người: `pausedForManualReview == true` hoặc `pausedAtIndex >= 0`.
- Còn chạy hay đã chết: heartbeat trễ hơn vài phút so với giờ hiện tại thì runner nhiều khả năng đã dừng (heartbeat ghi ~45 giây/lần).
- Với job cào **tại máy**: tiến độ không được đưa ra ngoài; chỉ thấy khi người dùng bấm "Sao lưu" (mục C).

### B. Chuyển giao job dở dang cho máy chủ cào tiếp (PC → GitHub/điện thoại)
App PC ghi `remote-jobs/<id>.json` (mục 3.1) và `remote-jobs/<id>-checkpoint.json` với:
`phase = "CRAWLING_CHAPTERS"`, `chapterLinks` = **toàn bộ** link theo thứ tự, `chapterProgressIndex = k` (số chương đã làm), `chaptersSoFar` = k chương đã cào đúng thứ tự (mỗi chương đủ 6 trường, `index` **duy nhất**, `sourceUrl` đúng bằng link tương ứng), `pausedAtIndex = -1`, **không** có `remoteDone` (hoặc `false` — đặt `true` cho dữ liệu dở dang là sai: từ 7.102 `crawler.py` coi đó là một lần chạy đã xong và bắt đầu lần chạy mới). Rồi dispatch workflow (hoặc để người dùng bấm chạy trong app).
- Đã kiểm bằng chạy thật `crawler.py`: checkpoint do bên ngoài ghi (3 chương dở, 8 chương tổng) → `crawler.py` giữ nguyên 3 chương đầu, cào 5 chương còn lại, `index` duy nhất (cả khi bên ngoài đánh số từ 0 lẫn từ 1).
- Chưa kiểm: phía điện thoại có tải đúng checkpoint này về và xuất ebook không (đường poll `RemoteCrawlRunner` chưa chạy trên máy thật).
- Nội dung `htmlContent` nên là HTML đã làm sạch (EPUB dựng từ nó); ảnh nếu có phải đặt ở `remote-jobs/<id>-images/<localFileName>` và HTML trỏ `images/<localFileName>`.

### C. Qua file sao lưu JSON (điện thoại ↔ PC, thủ công)
"Sao lưu" ghi `Downloads/EbookLeech/Backup/ebookleech_backup_<time>.json`:
```json
{ "formatVersion": 2, "exportedAt": 1794131660632,
  "projects": [ … ], "jobs": [ <LeechJob>, … ],
  "checkpoints": [ <CrawlCheckpoint kèm ảnh base64 trong images[]>, … ] }
```
- PC → điện thoại: app PC sinh file đúng định dạng này; người dùng chọn "Khôi phục" (MERGE: chỉ thêm job/dự án chưa có; REPLACE: xoá hết rồi nạp). Job có checkpoint đi kèm sẽ giữ trạng thái và tiến độ.
- Điện thoại → PC: app PC đọc `jobs` và `checkpoints[].chaptersSoFar`.
- Job **không** có checkpoint khi sao lưu bị đặt về `IDLE`, `chaptersCollected = 0`, `outputFilePath` rỗng.
- Kho chương 7.100 **không** nằm trong file sao lưu.
- Chưa chạy "Khôi phục" từ file do chương trình ngoài sinh ra; chỉ đọc mã `importFromFile`.

### D. Qua ebook đã xuất
`Downloads/EbookLeech/<tên job>/…epub|txt|html`. Mỗi lần xuất là một file mới, toàn bộ truyện. Không có metadata đi kèm (số chương, URL nguồn). App PC chỉ nhận được kết quả cuối, không có tiến độ.

### Nếu cần đồng bộ hai chiều thật sự
Cần thiết kế thêm (chưa làm): (1) một "manifest" chung (id job, URL nguồn, tổng chương, chương mới nhất, thời điểm) ghi vào repo hoặc thư mục chia sẻ; (2) quy ước khoá chương (hiện là `sourceUrl`) và chuẩn hoá URL; (3) quy tắc khi hai bên cùng sửa. Có thể làm nếu bạn muốn; hiện mã không có.

---

## 9. Phiên bản liên quan
- 7.98: ghép addon vào app, mục 222.
- 7.100: cập nhật tăng dần, bỏ qua chương, chương nhiều trang, Thử selector (mục 224).
- 7.101 (mục 225): `crawler.py` chờ JS dựng xong + cuộn lazy-load + headless khi không có màn hình ảo + `index` chương duy nhất; chạy lại job từ xa đã xong thì thấy chương mới; cuộn lazy-load phía điện thoại đúng thứ tự; không xuất lại khi không có chương mới + `lastRunNote`; notebook Colab chạy đúng thư mục + có màn hình ảo; sửa chú thích đầu `RemoteCrawlRunner.kt` và đầu file workflow đã lỗi thời; workflow và notebook lấy mã crawler từ file zip ở gốc repo (bản cũ đòi thư mục đã giải nén, hỏng ngay bước cài thư viện trong repo chỉ có file zip).
- 7.102 (mục 226): cào từ xa **chỉ cào chương mới** (`crawler.py` dùng lại chương theo `sourceUrl`, `-archive.json`, `runnerVersion`; điện thoại giữ mốc "kết quả cũ" và báo lỗi khi repo giữ zip cũ); **mốc xuất** `.baseline`; **thông báo chương mới**; **ghi đè file ebook cũ** (`updateExistingFile`); ghi chú lần chạy cho mọi job; tài liệu mục lục trong ebook (6.6).

- 7.103 (mục 227): **giao thức "lần chạy mới" không phụ thuộc runner** (`prepareFreshRemoteRun`: `-archive.json` + checkpoint rỗng + spec ghi cuối kèm `runRequestedAt`); `crawler.py` có **bỏ qua chương + chương nhiều trang**, chương cào lại giữ `index`; **`GitHubApiClient` viết lại** (file > 1 MB, ETag, thư mục > 1000 mục, giới hạn phụ, thử lại khi trượt `sha`); **"Xoá kho" giữ mốc xuất**; **`LeechDeskHub` + màn hình "🖥 Máy LeechDesk (PC)"**; dùng `tocOverride` từ spec từ xa; nhãn runner trên thẻ job. Kèm **LeechDesk 1.3.0** (file zip riêng).
- 7.104 (mục 228): **quét nhanh danh sách theo điểm neo** (6.7), **thông tin truyện** trong ebook + `.story.json` + bìa (6.8), **điện thoại → cloud → PC nối tiếp** (6.9), LeechDesk 1.4.0; quy tắc trang "Giới thiệu"/khối thông tin chỉ khi có gì ngoài tên truyện; sửa `xhtmlFix`; `crawler.py` giữ danh sách cũ khi trang 1 rỗng; phía trình duyệt: chẩn đoán kéo-thả, hoãn điều hướng thử thách ở tab nền (`ChallengeNav`), chẩn đoán đơ.

## 10. Mức đã kiểm chứng (nói thẳng)

Đã chạy thật trong sandbox (`tools/remote_e2e/`, Chromium + Playwright thật, web giả cục bộ, repo git "origin" cục bộ — KHÔNG phải GitHub Actions thật):
- Trang tĩnh: cào đúng. Trang JS dựng nội dung sau 1,5 giây: trước sửa 0 chương, sau sửa 5/5. Trang chỉ có nội dung sau khi cuộn: trước sửa 0/5 (kể cả bật cuộn, vì bản Python chưa có cuộn), sau sửa 5/5.
- Chạy không có màn hình ảo: trước sửa crash `Missing X server or $DISPLAY`, sau sửa chạy headless.
- Chạy lại job đã xong: trước sửa vẫn ra 5 chương khi site có 8; sau khi checkpoint cũ được ghi đè bằng bản rỗng do chính lớp Kotlin `CrawlCheckpoint.toJson()` sinh ra thì ra 8.
- Chuyển giao checkpoint từ bên ngoài (mục 8.B) và `index` duy nhất.
- Notebook Colab cũ chạy trong thư mục con: lỗi `FileNotFoundError remote-jobs/<id>.json`; chạy ở gốc repo: đúng.
- Bước "Chuẩn bị mã crawler" của workflow (trích đúng đoạn `run:` từ file yml rồi chạy bằng bash) với repo chỉ có file zip, repo có thư mục đã giải nén, và repo trống (báo lỗi rõ, thoát mã 1); `crawler.py` giải nén từ zip chạy từ ngoài repo qua `remote_e2e/e2e.py` (trang tĩnh 5/5); logic ô 3 của notebook (viết lại bằng Python thuần) chạy đủ 3 trường hợp. Vẫn KHÔNG phải Actions/Colab thật.

Bản 7.102, cào từ xa tăng dần, chạy thật `crawler.py` (cùng harness, thêm kịch bản `noinc_rerun`, `inc_rerun`, `inc_refresh`, `inc_foreign`, `inc_resume`): site tĩnh 5 → 8 chương, lần hai chỉ mở trang chương 6, 7, 8 (3 trang); lần ba không đổi mở 0 trang; `refreshLastN` cào lại đúng N chương cuối (lỗi thì giữ bản cũ); checkpoint do bên ngoài ghi có `index` lạ/trùng không làm đụng tên ảnh; lần chạy bị ngắt giữa chừng rồi chạy tiếp vẫn dùng lại chương cũ từ `-archive.json` (kiểm cả khi chương cũ nằm SAU điểm ngắt); job không bật tăng dần vẫn cào lại toàn bộ; các kịch bản cũ không hồi quy. Vẫn là máy tính + web giả, KHÔNG phải Actions thật.

Đã chạy mô phỏng trên JVM (`tools/ebookleech_sim/`, **53 kiểm tra đạt**): logic của `EbookLeechCrawler` + `ExportFollowUp` với web giả (cập nhật tăng dần, bỏ qua chương, chương nhiều trang, chống vòng lặp, không xuất lại khi không đổi, ghi chú lần chạy; 7.102: lần đầu không báo, thêm chương => `onNewChapters(N, tổng)`, tắt thông báo, job không tăng dần vẫn báo, sửa chương cũ không báo, xoá kho mất mốc, đổi `updateExistingFile` ép xuất lại). Đã làm hỏng mã cố ý (báo cả khi chưa có mốc; đếm chương mới theo băm nội dung) để chắc các kiểm tra mới thực sự bắt được lỗi. Android/GeckoView/Notification là stub: mô phỏng chỉ kiểm LOGIC gọi hàm thông báo, **không** kiểm thông báo hiện ra.

Biên dịch toàn dự án bằng `kotlinc` so với bản 7.100 và so với 7.101: không có lỗi nội bộ mới (thư viện Android thật không có sẵn nên phần lớn lỗi tham chiếu Android bị lọc; đây là kiểm tra hồi quy, không phải build APK).

**Bản 7.103** (cùng harness, chạy `crawler.py` thật từ chính file zip cuối cùng):
- Kịch bản mới `multi` (chương 2 gộp 3 trang, chương 5 có nút "Tiếp" trỏ sang chương 6 nên KHÔNG được nối nhầm), `multi_max` (dừng ở `maxChapterPages`), `skip` (bỏ chương có cụm VIP + chương quá ngắn; `index` liên tục, `skippedCount`), `skip_inc` (bỏ qua + tăng dần cùng lúc), `app_fresh` / `app_fresh_noinc` (giả lập đúng chuỗi ghi file của `prepareFreshRemoteRun`, rồi chạy `crawler.py` — có tăng dần: chỉ mở chương mới, `index` liên tục; không tăng dần: cào lại đủ, không dính dữ liệu cũ) và kiểm `index` không đụng nhau sau `refreshLastN`. Các kịch bản cũ (static, js, lazy_on, rerun_reset, noinc_rerun, inc_rerun, inc_refresh, inc_foreign, inc_resume) chạy lại, không hồi quy.
- LeechDesk 1.3.0 chạy thật với **GitHub giả** + "FakeAddon" (một lớp Python bắt chước đúng chuỗi ghi file của Kotlin — **KHÔNG chạy mã Kotlin**): `tests/test_sync.py` 30 kiểm tra — tăng dần (chỉ mở 3 chương mới, `index` 1..9 liên tục, `runnerVersion`, thống kê), không tăng dần cào lại đủ, VPS tự nhận khi có `runRequestedAt` mới, bỏ qua + nhiều trang, hộp thư thấy job nằm ngoài 1000 mục đầu (Git Trees), `-archive.json` không bị hiểu là job. Chạy cùng LeechDesk 1.2.0 (chưa vá) với giao thức mới: cào đúng nhưng cào lại toàn bộ (không tăng dần).
- `tools/github_client_test` (25 kiểm tra): mã `GitHubApiClient.kt` THẬT biên dịch bằng kotlinc và chạy trên JVM với một máy chủ GitHub giả viết bằng Python (file > 1 MB, `raw`/`object`, ETag/304, thư mục > 1000, 403 + `Retry-After`, hết hạn mức giờ không treo luồng, 409/422 thử lại một lần, dispatch workflow).
- Mô phỏng JVM `EbookLeechCrawler` + `ExportFollowUp` **58** kiểm tra (S22/S22b mới: "Xoá kho" giữ mốc xuất; mốc không trùng URL nào ⇒ coi như xuất lần đầu).
- Biên dịch toàn dự án bằng kotlinc: không lỗi nội bộ mới so với 7.102 ("cần xem 15", giống hệt). Có một lỗi suy luận kiểu thật ở `getFileSha` đã sửa (viết lại biểu thức `optString(...).ifEmpty { null }`).
- Tái hiện lỗi của chính 7.102: điện thoại 7.102 + LeechDesk 1.2.0 **và** 1.3.0 trả `done` với chương cũ khi chạy lại job đã xong (không mở trang nào); điện thoại 7.103 không còn gặp (kiểm với `test_sync.py` và `app_fresh`).

**CHƯA kiểm chứng:**
- Toàn bộ trên điện thoại thật: GeckoView, `evaluateJsOnTab`, cuộn lazy-load phía điện thoại, thẻ job mới, nút Thử selector.
- 7.102 trên điện thoại thật: thông báo có hiện và bấm mở đúng ebook không; ghi đè file cũ qua MediaStore (`openOutputStream(uri, "wt")`) trên các bản Android khác nhau và khi file cũ do app khác tạo; hộp thoại có hai ô tick mới; phía điện thoại nhận checkpoint từ xa tăng dần (mốc `staleDoneSavedAt`, lưu SharedPreferences qua lần tắt/mở app, báo lỗi zip cũ) — đã biên dịch, chưa chạy; mở EPUB đã xuất bằng ứng dụng đọc thật để xem mục lục.
- GitHub Actions thật (workflow, quyền token, poll, tải ảnh, xuất ebook từ checkpoint từ xa) và Colab thật.
- Site thật (Cloudflare, chống bot, lazy-load thật).
- Các giới hạn nêu trong tài liệu (quét lại mọi trang danh sách, kho không nằm trong sao lưu, khoá theo URL…).
- 7.103 trên điện thoại thật: `prepareFreshRemoteRun` (chuỗi ghi file chạy thật trên GitHub thật, kể cả khoảng trễ giữa các commit), màn hình "🖥 Máy LeechDesk (PC)" và hộp thư nhận job (`LeechDeskHub` đã biên dịch, chưa chạy), nhãn runner trên thẻ job, "Xoá kho" giữ mốc (đã mô phỏng logic, chưa bấm trên máy).
- `GitHubApiClient` 7.103 với **GitHub thật**: media type `raw` cho file > 1 MB, ETag/304, Git Trees, giới hạn phụ — hành vi lấy theo tài liệu GitHub (xem Nguồn) và kiểm với máy chủ giả mô phỏng theo tài liệu đó; chưa gặp phản hồi thật.
- LeechDesk 1.3.0 với **app Android thật** (FakeAddon chỉ bắt chước chuỗi ghi file của Kotlin) và với GitHub thật; Chrome/Edge thật của LeechDesk (xem HANDOVER của LeechDesk).
- Trường hợp job vừa cào TẠI MÁY rồi chuyển sang chạy từ xa tăng dần: kho chương nằm ở điện thoại, repo chưa có checkpoint xong nên lần đầu cào đủ (6.4c).

**Bản 7.104 — ĐÃ chạy thật (JVM / Python / Chromium, KHÔNG phải điện thoại):**
- Bộ lập kế hoạch quét nhanh: 22 kiểm tra tích hợp + 3000 ca so Kotlin ↔ Python; `crawler.py` THẬT (Chromium + git cục bộ), kịch bản `fast_scan` (`tools/remote_e2e`): lần 2 chỉ mở trang 1, 7, 8, 9, 10 và 3 chương mới, bìa không tải lại; trang 1 rỗng ⇒ giữ danh sách cũ; chương chèn giữa chỉ thấy ở quét đầy đủ (đúng như giới hạn đã nêu); 6 kịch bản cũ không hồi quy.
- Xuất ebook: `EbookMarkup`/`EbookStaging` THẬT biên dịch bằng kotlinc chạy trên JVM, `validate_staging.py` **544 dòng PASS, 0 FAIL, 12 bộ xuất file + 25 ca HTML hỏng cho bộ làm sạch XHTML** (gồm `E6_titleonly`, `T3_txt_sourceonly`, `H3_html_sourceonly`); kiểm cấu trúc EPUB (XML nghiêm ngặt, OPF, nav, spine), TXT, HTML, `.story.json`.
- Script trích `STORY_META_JS` chạy trong Chromium trên nhiều trang mẫu (JSON-LD, Open Graph, nhãn, microdata, Yoast `@graph`, selector); 4 bản chép giống từng byte (`story_meta_identity.py`).
- LeechDesk 1.4.0: toàn bộ bộ test (bridge 33, cloud 58, crypto 19, e2e 45, hub 46, **story_scan 52**, sync 30, toc 14, tocgen 34, **ui_story 13**, plumbing) không lỗi; xuất EPUB/TXT/HTML/.story.json của LeechDesk so với Kotlin: 22/22 (`check_ld_export.py`); bộ trích HTTP của LeechDesk (`extract_basic`) trùng bản JS trên 27 trang mẫu.
- `ChallengeNav` (bảng chân trị): 20/20 trên JVM.
- Biên dịch toàn dự án bằng kotlinc: "cần xem 15", GIỐNG HỆT bản gốc (không lỗi nội bộ mới).
- Lỗi thật tìm ra khi kiểm (đã sửa): lambda cuối của `ArchiveSeed.build`; `xhtmlFix` hỏng `<` trần; trang "Giới thiệu"/khối thông tin xuất hiện cả khi chỉ có tên truyện; LeechDesk lồng `<tr>`; LeechDesk không bao giờ tải bìa ở engine HTTP (sai khoá `cover`/`coverUrl`); kho hỏng làm sập `build_archive`.
**Bản 7.104 — CHƯA kiểm chứng:**
- Mọi thứ trên điện thoại thật: giao diện hộp tick/mục "Thông tin truyện", `ArchiveSeed` + `RemoteCrawlRunner` (đẩy kho/lưu lại) với GitHub thật, GeckoView 145 (đặc biệt reflection `LoadRequest.isDirectNavigation/isRedirect/triggerUri` của `ChallengeNav` — lỗi thì KHÔNG hoãn gì cả).
- EPUB mở bằng ứng dụng đọc thật hoặc `epubcheck` (mới kiểm bằng XML nghiêm ngặt + cấu trúc); thư viện (Calibre/Google Play Books…) hiển thị tác giả/bìa.
- Site thật (cấu trúc phân trang lạ, chống bot, trang danh sách không ổn định thứ tự).
- LeechDesk 1.4.0 với Chrome/Edge thật, GitHub thật và app Android thật (FakeAddon chỉ bắt chước chuỗi ghi file).
- Nguyên nhân đơ trình duyệt; vì sao một khe không lỗi kéo-thả; cái gì khiến tab nền gọi API đúng lúc bị chuyển sang captcha (xem PROJECT_STATUS §228).

**Nguồn tra cứu (đã đọc trong lúc làm 7.103):**
- GitHub Docs — Repository contents (media type `raw`/`object`, giới hạn 1 MB / 100 MB, thư mục tối đa 1000 mục): https://docs.github.com/en/rest/repos/contents
- GitHub Docs — Git trees: https://docs.github.com/en/rest/git/trees
- GitHub Docs — Rate limits for the REST API (hạn mức chính, giới hạn phụ, `Retry-After`): https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api
- GitHub Docs — Best practices for using the REST API (yêu cầu có điều kiện `ETag`/`If-None-Match`, 304, xử lý giới hạn phụ): https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api

**Nguồn tra cứu bản 7.104 (tra lại ngày 14/11/2026; chỉ xác nhận ý tưởng và trường dữ liệu chung):**
- Scrapy DeltaFetch — bỏ qua request tới trang đã thấy ở lần cào trước, khoá = dấu vân tay request hoặc `deltafetch_key`, lưu bằng `dbm`, `DELTAFETCH_RESET`: https://github.com/scrapy-plugins/scrapy-deltafetch
- FanFicFare FAQ — tiêu đề/tác giả/tóm tắt (`keep_summary_html`)/trạng thái/thể loại vào tag (`include_subject_tags`)/series; cập nhật EPUB dùng lại chương trong file cũ: https://github.com/JimmXinu/FanFicFare/wiki/FAQs
- lightnovel-crawler — trường của đối tượng truyện (`title`, `authors`, `synopsis`, `tags`, `cover_url`, `language`…): https://www.mintlify.com/lncrawl/lightnovel-crawler/api/novels
- KDN Auto Leech (mã bạn đính kèm) — `app/Objects/Crawling/Savers/PostSaver.php`: `_last_crawled_url_id`, `_active_recrawling_from_last_page` (chỉ xác nhận sự tồn tại của cài đặt).

