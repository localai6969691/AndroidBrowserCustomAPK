#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
crawler.py — cào từ xa cho 1 job EbookLeech, chạy trên GitHub Actions.
BẢN PLAYWRIGHT (Chromium headless) — thay bản `requests` thuần trước đó.

CÁCH DÙNG (do workflow gọi, không cần chạy tay):
    python3 remote_runner/crawler.py <job_id>

Đọc job-spec tại  remote-jobs/<job_id>.json  (app Android đã đẩy lên qua
Contents API — xem RemoteCrawlRunner.kt).
Ghi checkpoint tại remote-jobs/<job_id>-checkpoint.json — CÙNG SCHEMA với
`CrawlCheckpoint.toJson()`/`LeechChapter.toJson()` phía Kotlin.
Ghi ẢNH tại      remote-jobs/<job_id>-images/<tên file>  — CÙNG QUY ƯỚC đặt
tên/rewrite với `ImageDownloader.kt` (`img_<chương>_<số>.<đuôi>`, HTML
được đổi `src` thành `images/<tên file>`) để `EbookExporter` phía Kotlin
xử lý được y hệt nhau bất kể cào tại máy hay từ xa.

═══════════════════════════════════════════════════════════════════════
NÂNG CẤP SO VỚI BẢN TRƯỚC (dùng `requests` thuần — không còn nữa):
- Dùng Chromium HEADLESS THẬT (Playwright) — chạy được JavaScript, site
  SPA/render-bằng-JS giờ cào được (trước đây ra trang rỗng).
- TỰ QUA ĐƯỢC phần lớn "Cloudflare chặn" — đa số chặn Cloudflare thực ra
  chỉ là JS challenge tự động (trang tạm hiện "Checking your browser…"
  rồi tự chuyển tiếp sau vài giây) — trình duyệt thật chạy JS là qua bình
  thường, không cần ai bấm gì. Có đợi thêm vài giây + thử lại 1-2 lần nếu
  vẫn thấy trang chặn ngay sau khi tải xong.
- Tải ẢNH luôn, offline hoàn toàn — commit lên git CÙNG LÚC với checkpoint
  (xem `git_commit_push()`) nên nếu runner sập giữa chừng, ảnh ĐÃ TẢI
  không mất, y hệt nguyên tắc bảo toàn dữ liệu của checkpoint text.

VẪN CÒN GIỚI HẠN THẬT (không đổi được):
- CAPTCHA THẬT (hCaptcha/reCAPTCHA cần người bấm) — KHÔNG qua được, không
  có ai ngồi giải trên máy chủ Actions. Site dùng loại này (không phải
  JS-challenge-tự-động) sẽ vẫn bị ghi là lỗi/chặn, cào tiếp chương sau.
- KHÔNG hỗ trợ `useLoginSession` (không mượn được phiên đăng nhập THẬT
  của app) — nhưng job có `cookieHeader` (dán cookie tay) THÌ CÓ hỗ trợ —
  xem `make_context()`.
- Hỗ trợ `preListStages`/`autoDetectPagination` — đã port đầy đủ từ bản Kotlin.
- Hỗ trợ điều khiển tương tác từ xa qua git (xem `InteractiveCommandPoller`).
- CHƯA TỪNG CHẠY THỬ THẬT trên GitHub Actions — viết đúng theo tài liệu
  Playwright chính thức + đọc kỹ code Kotlin gốc để port logic tương
  đương, nhưng chưa có 1 lần chạy thật xác nhận. Nặng + chậm hơn hẳn bản
  `requests` cũ — cần theo dõi `timeout-minutes` của workflow có đủ không
  với job dài.
═══════════════════════════════════════════════════════════════════════
"""

import json
import os
import random
import re
import subprocess
import sys
import time
from urllib.parse import urljoin

from playwright.sync_api import sync_playwright, TimeoutError as PwTimeoutError
from bs4 import BeautifulSoup
import threading

CHECKPOINT_COMMIT_EVERY_N_CHAPTERS = 5
CHECKPOINT_COMMIT_EVERY_SECONDS = 120
PAGE_TIMEOUT_MS = 30_000
CLOUDFLARE_RETRY_WAIT_S = 6
CLOUDFLARE_MAX_RETRIES = 2
MAX_IMAGE_BYTES = 6 * 1024 * 1024  # khớp MAX_IMAGE_BYTES trong ImageDownloader.kt
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

BLOCK_KEYWORDS = [
    "checking your browser", "just a moment", "verify you are human",
    "attention required", "ddos-guard", "access denied",
]
# Từ khoá CHỈ dùng để phát hiện chặn — KHÔNG dùng "cloudflare"/"captcha"
# một mình (nhiều site nhắc tới các từ này trong nội dung bình thường,
# không phải đang bị chặn) — chỉ coi là chặn khi khớp đúng cụm rõ ràng.


# ─────────────────────────────────────────────────────────────────────
# ContentSpinner — port từ ContentSpinner.kt (giữ ĐÚNG cú pháp {a|b|c})
# ─────────────────────────────────────────────────────────────────────
_SPIN_GROUP = re.compile(r"\{([^{}]*)\}")


def spin(template: str) -> str:
    if not template or "{" not in template:
        return template

    def _pick(m):
        options = m.group(1).split("|")
        if len(options) <= 1:
            return m.group(0)
        return random.choice(options)

    return _SPIN_GROUP.sub(_pick, template)


# ─────────────────────────────────────────────────────────────────────
# JsonPathExtractor — port từ JsonPathExtractor.kt (cú pháp "a.b[0].c")
# ─────────────────────────────────────────────────────────────────────
_SEGMENT_RE = re.compile(r"^([a-zA-Z0-9_]*)((?:\[\d+\])*)$")
_INDEX_RE = re.compile(r"\[(\d+)\]")


def json_path_resolve(root, path: str):
    if not path:
        return root
    current = root
    for seg in path.split("."):
        if current is None or not seg:
            return None
        m = _SEGMENT_RE.match(seg)
        if not m:
            return None
        key, indices_raw = m.group(1), m.group(2)
        if key:
            if not isinstance(current, dict):
                return None
            current = current.get(key)
            if current is None:
                return None
        for idx_s in _INDEX_RE.findall(indices_raw):
            idx = int(idx_s)
            if not isinstance(current, list) or idx >= len(current):
                return None
            current = current[idx]
    return current


def json_path_str(root, path: str):
    v = json_path_resolve(root, path)
    if v is None:
        return None
    return v if isinstance(v, str) else str(v)


# ─────────────────────────────────────────────────────────────────────
# ContentProcessor — port SUBSET các RegexRule.Kind (xem RegexRule.kt)
# ─────────────────────────────────────────────────────────────────────
def apply_regex_rules(title, html, text, rules):
    for rule in rules:
        if not rule.get("enabled", True):
            continue
        target = rule.get("target", "CONTENT_HTML")
        kind = rule.get("kind", "PLAIN_REPLACE")
        pattern = rule.get("pattern", "")
        replacement = rule.get("replacement", "")
        ci = rule.get("caseInsensitive", False)

        def get_input():
            return title if target == "TITLE" else (html if target == "CONTENT_HTML" else text)

        def set_input(v):
            nonlocal title, html, text
            if target == "TITLE":
                title = v
            elif target == "CONTENT_HTML":
                html = v
            else:
                text = v

        cur = get_input()
        is_html = target == "CONTENT_HTML"

        if kind == "PLAIN_REPLACE":
            if pattern:
                if ci:
                    cur = re.sub(re.escape(pattern), replacement.replace("\\", "\\\\"), cur, flags=re.IGNORECASE)
                else:
                    cur = cur.replace(pattern, replacement)
        elif kind == "REGEX_REPLACE":
            try:
                flags = re.IGNORECASE if ci else 0
                cur = re.sub(pattern, replacement, cur, flags=flags)
            except re.error:
                pass
        elif kind == "TRIM":
            cur = "\n".join(line.strip() for line in cur.split("\n"))
        elif kind == "REMOVE_EMPTY_LINES":
            cur = re.sub(r"\n{3,}", "\n\n", cur)
        elif kind == "TO_UPPERCASE":
            cur = cur.upper()
        elif kind == "TO_LOWERCASE":
            cur = cur.lower()
        elif kind == "CAPITALIZE_FIRST":
            cur = cur[:1].upper() + cur[1:] if cur else cur
        elif kind == "STRIP_HTML_TAGS":
            if is_html:
                cur = re.sub(r"<[^>]*>", "", cur)
        elif kind == "SPIN_INSERT_PREFIX":
            cur = spin(replacement) + cur
        elif kind == "SPIN_INSERT_SUFFIX":
            cur = cur + spin(replacement)

        set_input(cur)

    return title, html, text


def strip_tags_rough(html: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)).strip()


def looks_blocked(html: str) -> bool:
    lowered = html.lower()[:4000]
    return any(k in lowered for k in BLOCK_KEYWORDS)


# ─────────────────────────────────────────────────────────────────────
# ImageDownloader — port từ ImageDownloader.kt, GIỮ ĐÚNG quy ước đặt tên
# "img_<chương>_<số>.<đuôi>" + rewrite src → "images/<tên file>", để
# EbookExporter.kt phía Kotlin xử lý được y hệt bất kể nguồn cào.
# ─────────────────────────────────────────────────────────────────────
_IMG_SRC_RE = re.compile(r'<img[^>]+src\s*=\s*["\']([^"\']+)["\'][^>]*>', re.IGNORECASE)


def guess_extension(mime_type: str, url: str) -> str:
    mapping = {"jpeg": "jpg", "jpg": "jpg", "png": "png", "webp": "webp", "gif": "gif"}
    for key, ext in mapping.items():
        if key in mime_type:
            return ext
    from_url = url.rsplit(".", 1)[-1].split("?")[0].lower() if "." in url else ""
    return from_url if from_url in ("jpg", "jpeg", "png", "webp", "gif") else "jpg"


def download_and_localize_images(context, html: str, base_url: str, chapter_index: int, max_images: int, images_dir: str):
    """@return (html đã rewrite src, list metadata ảnh [{originalUrl, localFileName, mimeType}])"""
    matches = []
    seen = set()
    for m in _IMG_SRC_RE.finditer(html):
        src = m.group(1)
        if src not in seen and not src.startswith("data:"):
            seen.add(src)
            matches.append(src)

    downloaded = []
    url_to_local = {}
    counter = 0
    os.makedirs(images_dir, exist_ok=True)

    for src_url in matches:
        if counter >= max_images:
            break
        absolute_url = urljoin(base_url, src_url)
        try:
            resp = context.request.get(absolute_url, timeout=15_000)
        except Exception as e:
            print(f"    [Anh] Loi tai {absolute_url}: {e}", flush=True)
            continue
        if not resp.ok:
            continue
        mime_type = (resp.headers.get("content-type", "") or "").split(";")[0].strip() or "image/jpeg"
        if not mime_type.startswith("image/"):
            continue
        body = resp.body()
        if len(body) > MAX_IMAGE_BYTES:
            continue

        counter += 1
        ext = guess_extension(mime_type, absolute_url)
        local_name = f"img_{chapter_index}_{counter}.{ext}"
        with open(os.path.join(images_dir, local_name), "wb") as f:
            f.write(body)
        downloaded.append({"originalUrl": absolute_url, "localFileName": local_name, "mimeType": mime_type})
        url_to_local[src_url] = local_name

    new_html = html
    for original, local in url_to_local.items():
        new_html = new_html.replace(original, f"images/{local}")

    return new_html, downloaded


# ─────────────────────────────────────────────────────────────────────
# Playwright — tải trang, tự chờ qua Cloudflare JS challenge
# ─────────────────────────────────────────────────────────────────────
def make_context(browser, job, storage_state_path=None):
    ua = job.get("customUserAgent") or DEFAULT_USER_AGENT
    # ĐÃ THÊM — nếu có file storage_state từ lần chạy trước (cookie +
    # localStorage đã lưu, xem save_storage_state() và nơi gọi trong
    # main()/handle_blocked_pause()) thì khôi phục NGAY khi tạo context —
    # Playwright tự nạp lại toàn bộ cookie + localStorage của mọi origin
    # đã lưu, coi như tiếp tục đúng phiên cũ (không phải "khách lạ" với
    # site nữa — nhiều site anti-bot tin tưởng session đã tồn tại lâu hơn
    # session vừa tạo).
    kwargs = {"user_agent": ua}
    if storage_state_path and os.path.exists(storage_state_path):
        kwargs["storage_state"] = storage_state_path
        print(f"[Session] Khoi phuc storage_state tu lan chay truoc: {storage_state_path}", flush=True)
    context = browser.new_context(**kwargs)
    cookie_header = job.get("cookieHeader", "")
    if cookie_header:
        # Chuỗi Cookie thô dạng "a=1; b=2" — tiêm qua extra HTTP header,
        # Chromium tự gửi kèm mọi request trong context này (khác
        # context.add_cookies() cần cấu trúc object riêng từng cookie —
        # job.cookieHeader vốn đã là chuỗi thô người dùng dán tay, tiêm
        # thẳng đỡ phải tự parse lại thành từng cookie).
        context.set_extra_http_headers({"Cookie": cookie_header})
    return context


def save_storage_state(context, storage_state_path):
    """ĐÃ THÊM — lưu cookie + localStorage hiện tại của context ra file, để
    lần chạy remote SAU (nếu có — job khác hoặc dispatch lại job này) khôi
    phục lại được qua make_context(). Gọi hàm này ở các mốc quan trọng:
    sau Phase 1, sau mỗi lần commit checkpoint trong Phase 2, và NGAY SAU
    KHI người dùng giải CAPTCHA xong (handle_blocked_pause) — mốc cuối này
    quan trọng nhất, vì đó là lúc cookie "đã qua xác minh" mới nhất."""
    try:
        context.storage_state(path=storage_state_path)
    except Exception as e:
        # Không để lỗi lưu storage_state làm gãy cả job — chỉ mất tác dụng
        # "nhớ phiên" cho lần sau, không ảnh hưởng lần chạy hiện tại.
        print(f"[Session] Luu storage_state loi (bo qua, khong anh huong job hien tai): {e}", flush=True)


def goto_with_cloudflare_retry(page, url):
    """@return (html, still_blocked) — still_blocked=True khi hết số lần
    thử mà vẫn thấy trang chặn (khác lỗi mạng/timeout — đây là lúc CẦN
    dừng cả job lại chờ người dùng, xem crawl_one_chapter_html())."""
    html = ""
    for attempt in range(CLOUDFLARE_MAX_RETRIES + 1):
        try:
            page.goto(url, timeout=PAGE_TIMEOUT_MS, wait_until="domcontentloaded")
        except PwTimeoutError:
            if attempt < CLOUDFLARE_MAX_RETRIES:
                print(f"    Timeout tai trang (lan {attempt + 1}) - thu lai", flush=True)
                continue
            print("    Timeout - bo cuoc trang nay", flush=True)
            try:
                return page.content(), False  # timeout mạng thường, KHÔNG phải bị chặn — không cần dừng cả job
            except Exception:
                return "", False
        html = page.content()
        if not looks_blocked(html):
            return html, False
        if attempt < CLOUDFLARE_MAX_RETRIES:
            print(f"    Co ve dang bi chan (Cloudflare JS challenge?) - cho {CLOUDFLARE_RETRY_WAIT_S}s roi thu lai ({attempt + 1}/{CLOUDFLARE_MAX_RETRIES})", flush=True)
            page.wait_for_timeout(CLOUDFLARE_RETRY_WAIT_S * 1000)
    return html, True  # hết số lần thử, VẪN bị chặn — có thể là CAPTCHA thật, không phải JS challenge tự động


# ─────────────────────────────────────────────────────────────────────
# Phase 0 — ĐÃ THÊM: port autoDetectPagination từ EbookLeechCrawler.kt
# (trước đây job remote BẮT BUỘC phải tự khai rõ listPageUrlPattern —
# không tự dò được). Thử lần lượt 5 template phân trang phổ biến với
# page=2, so với baseline (link chương ở trang 1) — template nào cho ra
# link MỚI thì coi là đúng. Giữ NGUYÊN VẸN đúng 5 template + thứ tự thử
# như bản Kotlin gốc (paginationCandidates trong EbookLeechCrawler.kt).
# ─────────────────────────────────────────────────────────────────────
PAGINATION_CANDIDATES = [
    "{base}?page={page}", "{base}/page/{page}", "{base}/trang-{page}", "{base}/page-{page}", "{base}/{page}",
]


def auto_detect_pagination(page, job, base_url, baseline_links):
    """@return template đã dò được (còn nguyên "{page}", "{base}" đã thay)
    hoặc None nếu không template nào cho kết quả mới (coi như 1 trang)."""
    base = base_url.rstrip("/")
    baseline = set(baseline_links)
    selector = job["chapterLinkSelector"]
    attr = job.get("chapterLinkAttribute", "href")

    for template in PAGINATION_CANDIDATES:
        candidate_url = template.replace("{base}", base).replace("{page}", "2")
        print(f"[Phase0] Thu template phan trang: {candidate_url}", flush=True)
        html, still_blocked = goto_with_cloudflare_retry(page, candidate_url)
        if still_blocked:
            print(f"[Phase0] Template {template} bi chan - bo qua, thu template khac", flush=True)
            continue
        soup = BeautifulSoup(html, "lxml")
        links = set()
        for el in soup.select(selector):
            href = (el.get(attr) or "").strip()
            if href:
                links.add(urljoin(candidate_url, href))
        if links - baseline:
            print(f"[Phase0] Da do duoc pattern: {template}", flush=True)
            return template
    print("[Phase0] Khong tu do duoc phan trang - coi nhu chi co 1 trang", flush=True)
    return None


# ─────────────────────────────────────────────────────────────────────
# Phase 1 — thu thập link chương (BeautifulSoup parse HTML đã render đầy
# đủ từ Playwright — vẫn cần bs4/lxml để áp CSS selector, không tự viết
# lại selector engine)
# ─────────────────────────────────────────────────────────────────────
def collect_chapter_links_html(context, job, base_url=None, page=None):
    links = []
    pattern = job.get("listPageUrlPattern", "") or job.get("resolvedPaginationPattern", "")
    base_url = base_url if base_url is not None else job.get("listPageUrl", "")
    max_pages = job.get("maxPages", 50)
    selector = job["chapterLinkSelector"]
    attr = job.get("chapterLinkAttribute", "href")
    # ĐÃ SỬA — nhận `page` có sẵn (tái dùng qua nhiều entry khi có
    # preListStages, tránh mở/đóng tab liên tục) — tự tạo mới nếu không
    # truyền vào (giữ nguyên hành vi cũ cho trường hợp 1 nguồn duy nhất).
    owns_page = page is None
    if page is None:
        page = context.new_page()
    start_page = 1

    # Chỉ tự dò khi CHƯA có pattern nào (khớp điều kiện needsDetection bản
    # Kotlin gốc: autoDetectPagination && listPageUrlPattern rỗng && resolvedPaginationPattern rỗng).
    if not pattern and job.get("autoDetectPagination", False):
        print("[Phase0] Dang tu do cach phan trang...", flush=True)
        html1, blocked1 = goto_with_cloudflare_retry(page, base_url)
        if blocked1:
            print("[Phase0] Trang goc bi chan - bo qua tu do phan trang, coi nhu chi co 1 trang", flush=True)
        else:
            soup1 = BeautifulSoup(html1, "lxml")
            for el in soup1.select(selector):
                href = (el.get(attr) or "").strip()
                if href:
                    absolute = urljoin(base_url, href)
                    if absolute not in links:
                        links.append(absolute)
            detected = auto_detect_pagination(page, job, base_url, links)
            if detected:
                pattern = detected
            start_page = 2  # trang 1 đã xử lý xong ở bước dò, khỏi tải lại

    for p in range(start_page, max_pages + 1):
        if pattern:
            # .replace("{base}", ...) an toàn cho CẢ pattern thủ công (không
            # chứa "{base}", replace no-op) LẪN pattern tự dò (chứa "{base}").
            url = pattern.replace("{base}", base_url.rstrip("/")).replace("{page}", str(p))
        elif p == 1:
            url = base_url
        else:
            break

        print(f"[Phase1] Trang {p}: {url}", flush=True)
        html, still_blocked = goto_with_cloudflare_retry(page, url)
        if still_blocked:
            print(f"[Phase1] Trang {p} bị chặn dai dẳng — dừng thu thập ở đây (không dừng cả job vì chưa có chương nào cào, không có gì để mất)", flush=True)
            break

        soup = BeautifulSoup(html, "lxml")
        found_new = False
        for el in soup.select(selector):
            href = (el.get(attr) or "").strip()
            if not href:
                continue
            absolute = urljoin(url, href)
            if absolute not in links:
                links.append(absolute)
                found_new = True
        if not found_new:
            break
        time.sleep(job.get("delayBetweenPagesMs", 1500) / 1000.0)

    if owns_page:
        page.close()
    return links


# ─────────────────────────────────────────────────────────────────────
# Phase -1 — ĐÃ THÊM: port preListStages (kịch bản nhiều bước tuỳ biến)
# từ EbookLeechCrawler.phaseNeg1TraverseStages(). Duyệt qua từng "tầng"
# stage kiểu BFS: bắt đầu với frontier = [listPageUrl], mỗi stage lấy hết
# link (theo linkSelector/linkAttribute, giới hạn maxLinksPerPage nếu có)
# từ MỌI url trong frontier hiện tại, gộp thành frontier MỚI cho stage kế
# tiếp. Hết stage → frontier cuối (distinct) chính là danh sách
# "listPageEntries" — MỖI URL trong đó chạy Phase 0/1/2 như 1 nguồn riêng.
#
# KHÁC 1 CHÚT so với bản Kotlin gốc (đã cân nhắc, chấp nhận được): bản
# Kotlin CÓ THỂ xen kẽ Phase1/Phase2 giữa các entry (thu link chương của
# entry này xong là cào nội dung entry đó luôn, rồi mới sang entry kế) —
# bản Python này THU THẬP HẾT link chương của TẤT CẢ entry trước, rồi mới
# cào nội dung TẤT CẢ 1 lần — ebook CUỐI CÙNG giống hệt nhau (đủ chương,
# đủ nội dung), chỉ khác thứ tự xử lý nội bộ, đơn giản hoá code hợp lý.
# ─────────────────────────────────────────────────────────────────────
def traverse_pre_list_stages(page, job):
    stages = job.get("preListStages", [])
    frontier = [job.get("listPageUrl", "")]
    for stage_idx, stage in enumerate(stages):
        label = stage.get("label", f"Buoc {stage_idx + 1}")
        selector = stage["linkSelector"]
        attr = stage.get("linkAttribute", "href")
        max_links = stage.get("maxLinksPerPage", 0)
        print(f"[Phase-1] Buoc {stage_idx + 1}/{len(stages)}: {label} ({len(frontier)} trang nguon)", flush=True)
        next_frontier = []
        for url in frontier:
            html, still_blocked = goto_with_cloudflare_retry(page, url)
            if still_blocked:
                print(f"[Phase-1] {url} bi chan - bo qua URL nay trong buoc, tiep tuc URL khac", flush=True)
                continue
            soup = BeautifulSoup(html, "lxml")
            links = []
            for el in soup.select(selector):
                href = (el.get(attr) or "").strip()
                if href:
                    links.append(urljoin(url, href))
            if max_links > 0:
                links = links[:max_links]
            next_frontier.extend(links)
            time.sleep(job.get("delayBetweenPagesMs", 1500) / 1000.0)
        frontier = next_frontier
    seen = set()
    result = []
    for u in frontier:
        if u not in seen:
            seen.add(u)
            result.append(u)
    return result


def collect_chapter_links_ajax(context, job, base_url=None):
    links = []
    template = job.get("ajaxListUrlTemplate", "")
    items_path = job.get("ajaxListItemsPath", "")
    url_field = job.get("ajaxListUrlField", "url")
    max_pages = job.get("maxPages", 50)
    base_url = base_url if base_url is not None else job.get("listPageUrl", "")

    for p in range(1, max_pages + 1):
        api_url = template.replace("{page}", str(p)).replace("{base}", base_url.rstrip("/"))
        print(f"[Phase1-AJAX] Trang {p}: {api_url}", flush=True)
        try:
            resp = context.request.get(api_url, timeout=PAGE_TIMEOUT_MS)
            data = resp.json() if resp.ok else None
        except Exception as e:
            print(f"[Phase1-AJAX] Loi tai API trang {p}: {e} - dung o day", flush=True)
            break
        if data is None:
            print(f"[Phase1-AJAX] Trang {p} khong phai JSON hop le - dung o day", flush=True)
            break

        items = json_path_resolve(data, items_path) if items_path else data
        if not isinstance(items, list):
            print(f"[Phase1-AJAX] Khong tim thay mang chuong tai path \"{items_path}\" - dung o day", flush=True)
            break

        found_new = False
        for item in items:
            raw_url = json_path_str(item, url_field)
            if not raw_url:
                continue
            absolute = urljoin(api_url, raw_url)
            if absolute not in links:
                links.append(absolute)
                found_new = True
        if not found_new:
            break
        time.sleep(job.get("delayBetweenPagesMs", 1500) / 1000.0)

    return links


# ─────────────────────────────────────────────────────────────────────
# Phase 2 — cào nội dung từng chương
# ─────────────────────────────────────────────────────────────────────
class BlockedNeedsManualReview(Exception):
    """Báo hiệu ĐẶC BIỆT — khác lỗi 1 chương thường (mạng lỗi, không tìm
    thấy selector...) — nghĩa là trang có vẻ chặn THẬT SỰ (không phải JS
    challenge tự động, đã thử lại CLOUDFLARE_MAX_RETRIES lần vẫn vậy).
    `main()` bắt exception này để TẠM DỪNG CẢ JOB (không chỉ bỏ qua 1
    chương) — chụp màn hình, commit, dừng hẳn, chờ người dùng xem lại."""
    def __init__(self, url):
        self.url = url
        super().__init__(f"Trang bị chặn dai dẳng: {url}")


def crawl_one_chapter_html(page, job, url):
    html, still_blocked = goto_with_cloudflare_retry(page, url)
    if still_blocked:
        raise BlockedNeedsManualReview(url)
    soup = BeautifulSoup(html, "lxml")

    title_el = soup.select_one(job["chapterTitleSelector"])
    content_el = soup.select_one(job["chapterContentSelector"])
    if content_el is None:
        return None, f"Khong tim thay noi dung voi selector \"{job['chapterContentSelector']}\""

    title = title_el.get_text(strip=True) if title_el else ""
    content_html = str(content_el)
    content_text = content_el.get_text("\n", strip=True)
    return (title, content_html, content_text), None


def crawl_one_chapter_ajax(context, job, url):
    try:
        resp = context.request.get(url, timeout=PAGE_TIMEOUT_MS)
        data = resp.json() if resp.ok else None
    except Exception as e:
        return None, f"Loi mang: {e}"
    if data is None:
        return None, "Khong parse duoc JSON"
    title = json_path_str(data, job.get("ajaxContentTitleField", "title")) or ""
    content_raw = json_path_str(data, job.get("ajaxContentField", "content")) or ""
    if not content_raw:
        return None, f"Khong tim thay noi dung tai path \"{job.get('ajaxContentField', 'content')}\""
    return (title, content_raw, strip_tags_rough(content_raw)), None


# ─────────────────────────────────────────────────────────────────────
# Checkpoint — ĐÚNG schema CrawlCheckpoint.toJson()/LeechChapter.toJson()
# phía Kotlin.
# ─────────────────────────────────────────────────────────────────────
def chapter_to_json(index, title, html, text, source_url, images):
    return {
        "index": index, "title": title, "htmlContent": html, "textContent": text,
        "sourceUrl": source_url, "images": images,
    }


def build_checkpoint_json(job_id, phase, chapter_links, progress_index, chapters_so_far,
                           blocked_count, remote_done):
    return {
        "jobId": job_id, "phase": phase,
        "listPageEntries": [], "listPageEntryIndex": 0,
        "chapterLinks": chapter_links, "chapterProgressIndex": progress_index,
        "chaptersSoFar": chapters_so_far, "blockedChapterCount": blocked_count,
        "pausedAtIndex": -1, "savedAt": int(time.time() * 1000),
        "remoteDone": remote_done,
    }


_GIT_LOCK = threading.Lock()  # ĐÃ THÊM — tránh 2 thread (vòng cào chính +
# heartbeat) cùng git add/commit lúc chạm nhau, dễ gây lỗi/mất file giữa
# 2 lần commit chồng chéo.


def git_commit_push(repo_dir, message):
    with _GIT_LOCK:
        subprocess.run(["git", "-C", repo_dir, "add", "-A"], check=True)
        result = subprocess.run(["git", "-C", repo_dir, "diff", "--cached", "--quiet"])
        if result.returncode == 0:
            return
        subprocess.run(["git", "-C", repo_dir, "commit", "-m", message], check=True)
        for attempt in range(3):
            subprocess.run(["git", "-C", repo_dir, "pull", "--rebase", "--autostash"])
            push = subprocess.run(["git", "-C", repo_dir, "push"])
            if push.returncode == 0:
                return
            print(f"[git] Push lan {attempt + 1} that bai, thu lai...", flush=True)
            time.sleep(3)
        print("[git] Push that bai sau 3 lan thu - checkpoint LAN NAY khong len duoc repo, lan commit SAU se mang theo du du lieu (khong mat, chi tre).", flush=True)


class HeartbeatThread(threading.Thread):
    """
    ĐÃ THÊM — trả lời thẳng câu hỏi "sao không làm cho app biết Colab còn
    sống hay không": đây chính là cách làm — 1 thread NỀN, ĐỘC LẬP HOÀN
    TOÀN với vòng lặp cào chính, cứ mỗi HEARTBEAT_INTERVAL_S lại ghi + commit
    1 file NHỎ (`remote-jobs/<job_id>-heartbeat.json`) chỉ chứa timestamp
    hiện tại. App phía Kotlin poll đúng file NHỎ này (nhanh, rẻ, tách biệt
    khỏi checkpoint chính) — heartbeat KHÔNG bị chặn dù 1 trang đang tải
    chậm (khác dựa vào `savedAt` của checkpoint chính như bản trước — cái
    đó CHỈ đổi sau mỗi 5 chương/120s, dễ báo nhầm "có vẻ đã dừng" trong
    lúc thực ra chỉ đang cào 1 trang nặng).
    Dừng heartbeat qua `stop_event` khi `main()` kết thúc (thành công hay
    lỗi) — không để lại tiến trình treo vô ích.
    """
    def __init__(self, repo_dir, job_id, interval_s=45):
        super().__init__(daemon=True)
        self.repo_dir = repo_dir
        self.job_id = job_id
        self.interval_s = interval_s
        self.stop_event = threading.Event()

    def run(self):
        path = f"remote-jobs/{self.job_id}-heartbeat.json"
        while not self.stop_event.is_set():
            try:
                with open(path, "w", encoding="utf-8") as f:
                    json.dump({"aliveAt": int(time.time() * 1000)}, f)
                git_commit_push(self.repo_dir, f"EbookLeech remote: {self.job_id} - heartbeat")
            except Exception as e:
                print(f"[Heartbeat] Loi ghi/commit (khong nghiem trong, thu lai lan sau): {e}", flush=True)
            self.stop_event.wait(self.interval_s)


class InteractiveCommandPoller(threading.Thread):
    """
    ĐÃ THÊM — điều khiển trình duyệt từ xa qua kênh git (không tunnel).

    Thiết kế bảo mật: chỉ ai có GitHub PAT (đã mã hoá trong AndroidKeyStore
    của app) mới ghi được file lệnh lên repo — không mở thêm endpoint mạng
    nào, không cần xác thực thêm — dùng lại chính cơ chế bảo mật đang có.

    Giao thức:
    1. App ghi `remote-jobs/<id>-cmd.json` = {"action": "...", "sentAt": ...}
    2. Thread này poll file đó mỗi CMD_POLL_INTERVAL_S giây khi job đang ở
       trạng thái NEEDS_ACTION (bị chặn, chờ người dùng xử lý thủ công).
    3. Thấy file mới → parse action → thực thi qua Playwright → chụp ảnh
       kết quả → commit ảnh → XOÁ file lệnh (dùng git rm + commit, không phải
       GitHub Contents DELETE — đơn giản hơn, đủ cho mục đích này).
    4. App phía Kotlin nhận biết "lệnh đã xong" khi GET file cmd trả 404.

    Lệnh hỗ trợ (khớp với sendInteractiveAction() bên Kotlin):
        screenshot                  — chụp màn hình hiện tại
        click:<css_selector>        — click element
        click_coord:<x>,<y>         — click toạ độ pixel
        type:<text>                 — gõ text vào element focus hiện tại
        press:<key>                 — nhấn phím (Enter, Tab, Escape, Space...)
        scroll:<direction>          — cuộn (up/down/top/bottom)
        wait:<ms>                   — chờ ms milliseconds (tối đa 30000)
        eval:<js>                   — thực thi JavaScript và chụp màn hình sau
    """
    CMD_POLL_INTERVAL_S = 4
    MAX_WAIT_MS = 30_000

    def __init__(self, repo_dir, job_id, page, images_dir, interval_s=CMD_POLL_INTERVAL_S, resume_event=None):
        super().__init__(daemon=True)
        self.repo_dir = repo_dir
        self.job_id = job_id
        self.page = page           # Playwright page đang chạy — thread chính GIỮ NGUYÊN, không đóng
        self.images_dir = images_dir
        self.interval_s = interval_s
        self.stop_event = threading.Event()
        self._cmd_path = f"remote-jobs/{job_id}-cmd.json"
        # ĐÃ THÊM — đường dẫn checkpoint chính, dùng để ghi
        # lastInteractiveScreenshotFile/lastInteractiveAt sau MỖI lệnh (xem
        # _update_checkpoint_interactive_result()) — đây là cách DUY NHẤT
        # để app phía Kotlin biết ảnh MỚI NHẤT nằm ở file nào, vì
        # pausedScreenshotFile chỉ ghi 1 lần lúc mới bị chặn, không đổi nữa
        # sau đó (lỗi đã phát hiện — trước đây ảnh của các lệnh sau KHÔNG
        # BAO GIỜ hiện lên UI dù đã commit lên git thành công).
        self._checkpoint_path = f"remote-jobs/{job_id}-checkpoint.json"
        # ĐÃ THÊM — event báo "người dùng đã giải xong (bằng các lệnh
        # click/type/press ở trên, hoặc tự giải qua ảnh chụp rồi bấm nút),
        # tiếp tục cào NGAY tại đúng chương đang bị chặn, dùng lại NGUYÊN
        # session/cookie hiện có (KHÔNG dispatch lại — dispatch lại = Actions
        # runner MỚI = IP MỚI = phải giải lại captcha lần nữa, vô nghĩa).
        # main() chờ event này thay vì chỉ chờ timeout như trước.
        self.resume_event = resume_event

    def run(self):
        print(f"[Interactive] Bat dau poll lenh tuong tac moi {self.interval_s}s", flush=True)
        while not self.stop_event.is_set():
            try:
                self._check_and_execute()
            except Exception as e:
                print(f"[Interactive] Loi poll/thuc thi lenh (thu lai lan sau): {e}", flush=True)
            self.stop_event.wait(self.interval_s)
        print("[Interactive] Da dung", flush=True)

    def _check_and_execute(self):
        if not os.path.exists(self._cmd_path):
            return
        try:
            with open(self._cmd_path, "r", encoding="utf-8") as f:
                cmd_data = json.load(f)
        except Exception:
            return  # file đang được ghi dở

        action = cmd_data.get("action", "")
        if not action:
            return

        # ĐÃ THÊM — lệnh đặc biệt "resume_crawl": KHÔNG thực thi như 1 hành
        # động trên trang (không click/type gì) — chỉ xoá file lệnh (báo
        # "đã xử lý" cho app) rồi báo hiệu resume_event cho main() biết để
        # thoát vòng chờ, thử lại chương đang bị chặn NGAY trên session này.
        if action == "resume_crawl":
            print("[Interactive] Nhan tin hieu 'resume_crawl' - bao hieu tiep tuc cao tai day", flush=True)
            with _GIT_LOCK:
                subprocess.run(["git", "-C", self.repo_dir, "rm", "-f", self._cmd_path], capture_output=True)
                result = subprocess.run(["git", "-C", self.repo_dir, "diff", "--cached", "--quiet"])
                if result.returncode != 0:
                    subprocess.run(["git", "-C", self.repo_dir, "commit", "-m",
                        f"EbookLeech remote interactive: {self.job_id} - resume_crawl"], check=True)
                    for attempt in range(3):
                        subprocess.run(["git", "-C", self.repo_dir, "pull", "--rebase", "--autostash"])
                        push = subprocess.run(["git", "-C", self.repo_dir, "push"])
                        if push.returncode == 0:
                            break
                        time.sleep(3)
            if self.resume_event is not None:
                self.resume_event.set()
            return

        print(f"[Interactive] Thuc thi lenh: {action}", flush=True)
        screenshot_name = f"_interactive_{self.job_id}_{int(time.time())}.png"
        screenshot_path = os.path.join(self.images_dir, screenshot_name)
        os.makedirs(self.images_dir, exist_ok=True)
        error_msg = ""

        try:
            self._execute_action(action)
            # Chụp màn hình SAU khi thực thi để thấy kết quả
            self.page.screenshot(path=screenshot_path, full_page=False, timeout=10_000)
            print(f"[Interactive] Da chup man hinh ket qua: {screenshot_name}", flush=True)
        except Exception as e:
            error_msg = str(e)
            print(f"[Interactive] Lenh loi: {e} — van chup man hinh hien tai", flush=True)
            try:
                self.page.screenshot(path=screenshot_path, full_page=False, timeout=10_000)
            except Exception:
                screenshot_path = None
                screenshot_name = ""

        # ĐÃ THÊM — cập nhật checkpoint NGAY tại đây (trước khi commit) — đây
        # là phần sửa lỗi "ảnh lệnh sau không hiện lên UI": ghi tên file ảnh
        # MỚI NHẤT + mốc thời gian vào checkpoint.json, app phía Kotlin đọc
        # đúng field này (lastInteractiveScreenshotFile/lastInteractiveAt)
        # để biết ảnh nào là mới nhất và tải về hiển thị.
        self._update_checkpoint_interactive_result(screenshot_name, action, error_msg)

        # Commit ảnh kết quả (nếu có), checkpoint vừa cập nhật, và XOÁ file
        # lệnh — TẤT CẢ trong CÙNG 1 commit (đồng bộ, không lệch pha).
        with _GIT_LOCK:
            if screenshot_path and os.path.exists(screenshot_path):
                subprocess.run(["git", "-C", self.repo_dir, "add", screenshot_path])
            subprocess.run(["git", "-C", self.repo_dir, "add", self._checkpoint_path])
            # Xoá file lệnh — sau khi xoá + commit là dấu hiệu "đã xong"
            # cho phía Kotlin (GET cmd file trả 404) — vẫn giữ dấu hiệu này
            # dù giờ đã có lastInteractiveAt, vì có nơi khác (vd polling
            # thường) cũng có thể muốn biết cmd hiện có đang treo hay không.
            subprocess.run(["git", "-C", self.repo_dir, "rm", "-f", self._cmd_path], capture_output=True)
            result = subprocess.run(["git", "-C", self.repo_dir, "diff", "--cached", "--quiet"])
            if result.returncode != 0:
                subprocess.run(["git", "-C", self.repo_dir, "commit", "-m",
                    f"EbookLeech remote interactive: {self.job_id} - {action[:40]}"], check=True)
                for attempt in range(3):
                    subprocess.run(["git", "-C", self.repo_dir, "pull", "--rebase", "--autostash"])
                    push = subprocess.run(["git", "-C", self.repo_dir, "push"])
                    if push.returncode == 0:
                        break
                    time.sleep(3)
        print(f"[Interactive] Xong lenh '{action}' — da commit ket qua", flush=True)

    def _update_checkpoint_interactive_result(self, screenshot_name, action, error_msg):
        """ĐÃ THÊM — đọc checkpoint hiện tại, ghi thêm 3 field mô tả kết quả
        lệnh interactive VỪA XONG, rồi lưu lại. KHÔNG dùng _GIT_LOCK ở đây
        (chỉ là I/O file cục bộ, chưa commit git) — an toàn vì lúc hàm này
        chạy, thread cào chính (main()) đang BỊ CHẶN trong vòng chờ của
        handle_blocked_pause() (không ghi checkpoint song song), thread
        heartbeat chỉ ghi file heartbeat riêng (không đụng checkpoint.json)
        — không có ai khác ghi đè checkpoint.json cùng lúc."""
        try:
            with open(self._checkpoint_path, "r", encoding="utf-8") as f:
                cp = json.load(f)
        except Exception as e:
            print(f"[Interactive] Khong doc duoc checkpoint de cap nhat ket qua (bo qua): {e}", flush=True)
            return
        cp["lastInteractiveScreenshotFile"] = screenshot_name
        cp["lastInteractiveAction"] = action
        cp["lastInteractiveError"] = error_msg
        cp["lastInteractiveAt"] = int(time.time() * 1000)
        try:
            with open(self._checkpoint_path, "w", encoding="utf-8") as f:
                json.dump(cp, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Interactive] Ghi checkpoint ket qua loi (bo qua, khong chan lenh): {e}", flush=True)

    def _execute_action(self, action: str):
        """Thực thi 1 lệnh trên self.page — NÉM exception nếu thất bại."""
        if action == "screenshot":
            return  # chụp ảnh sau khi hàm này return, không cần làm gì

        if action.startswith("click:"):
            selector = action[len("click:"):]
            self.page.click(selector, timeout=10_000)

        elif action.startswith("click_coord:"):
            coords = action[len("click_coord:"):]
            x, y = (int(v.strip()) for v in coords.split(",", 1))
            self.page.mouse.click(x, y)

        elif action.startswith("type:"):
            text = action[len("type:"):]
            self.page.keyboard.type(text)

        elif action.startswith("press:"):
            key = action[len("press:"):]
            self.page.keyboard.press(key)

        elif action.startswith("scroll:"):
            direction = action[len("scroll:"):]
            if direction == "down":
                self.page.evaluate("window.scrollBy(0, window.innerHeight * 0.8)")
            elif direction == "up":
                self.page.evaluate("window.scrollBy(0, -window.innerHeight * 0.8)")
            elif direction == "top":
                self.page.evaluate("window.scrollTo(0, 0)")
            elif direction == "bottom":
                self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")

        elif action.startswith("wait:"):
            ms = min(int(action[len("wait:"):]), self.MAX_WAIT_MS)
            self.page.wait_for_timeout(ms)

        elif action.startswith("eval:"):
            js = action[len("eval:"):]
            self.page.evaluate(js)

        else:
            raise ValueError(f"Lenh khong nhan biet: {action!r}")


def handle_blocked_pause(context, page, job_id, repo_dir, checkpoint_path, images_dir,
                          chapter_links, i, chapters_so_far, blocked_count, blocked_url,
                          has_own_page, storage_state_path=None):
    """
    ĐÃ THÊM — tách riêng logic "job bị chặn dai dẳng" thành 1 hàm dùng
    chung: chụp màn hình + commit trạng thái NEEDS_ACTION, rồi khởi động
    InteractiveCommandPoller nhận lệnh điều khiển TỪ app (click/type/press
    — xem sendInteractiveAction() phía Kotlin) NGAY trên session trình
    duyệt đang bị chặn này.

    KHÁC bản trước (chỉ chờ timeout rồi thoát hẳn): giờ chờ CẢ 2 tín hiệu —
    (a) resume_event được set (người dùng tự giải xong bằng các lệnh điều
    khiển, hoặc giải qua ảnh chụp rồi bấm "Tiếp tục cào ngay") → return
    resumed=True, gọi lại NGAY hàm cào cho đúng chương i, KHÔNG dispatch
    lại workflow (dispatch lại = Actions runner MỚI = IP MỚI = phải giải
    lại captcha lần nữa từ đầu, vô nghĩa với site chặn theo IP).
    (b) hết MAX_INTERACTIVE_WAIT_S giây không có gì → resumed=False, caller
    tự dọn dẹp (đóng browser) rồi thoát hẳn — người dùng có thể "Chạy lại"
    sau (dispatch mới, đọc checkpoint cũ, thử lại từ đúng chương bị chặn).

    @return (resumed: bool, interactive_page) — interactive_page là page
    ĐANG DÙNG (có thể là `page` cũ hoặc page mới tạo nếu trước đó None do
    ajax_content=True) — caller cập nhật lại biến `page` từ giá trị này.
    """
    screenshot_name = f"_block_{job_id}.png"
    screenshot_path = os.path.join(images_dir, screenshot_name)
    os.makedirs(images_dir, exist_ok=True)
    interactive_page = page if page else context.new_page()
    if not page:
        try:
            interactive_page.goto(blocked_url, timeout=PAGE_TIMEOUT_MS, wait_until="domcontentloaded")
        except Exception:
            pass  # không thể tải lại — vẫn giữ page để nhận lệnh screenshot/điều khiển

    try:
        interactive_page.screenshot(path=screenshot_path, full_page=False, timeout=10_000)
        print(f"[Paused] Da chup man hinh trang chan: {screenshot_path}", flush=True)
    except Exception as shot_err:
        print(f"[Paused] Chup man hinh loi (khong chan viec tam dung job): {shot_err}", flush=True)
        screenshot_name = ""

    with open(checkpoint_path, "w", encoding="utf-8") as f:
        cp = build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, i, chapters_so_far, blocked_count, False)
        cp["pausedForManualReview"] = True
        cp["pausedUrl"] = blocked_url
        cp["pausedReason"] = (
            "Trang bi chan dai dang sau khi thu lai - co the la CAPTCHA that (can nguoi giai) "
            "hoac site da chan han IP cua may chay crawler. Dung cac nut dieu khien trong app "
            "(chup man hinh, click, go text...) de tu giai NGAY tren phien nay, roi bam "
            "'Da giai xong, tiep tuc cao ngay' - KHONG can 'Chay lai' (dispatch lai se doi IP, "
            "phai giai lai tu dau neu site chan theo IP)."
        )
        cp["pausedScreenshotFile"] = screenshot_name
        json.dump(cp, f, ensure_ascii=False, indent=2)
    git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - TAM DUNG (bi chan tai chuong {i + 1})")
    print(f"[Paused] Da tam dung job o chuong {i + 1} - cho lenh dieu khien hoac tin hieu resume_crawl", flush=True)

    resume_event = threading.Event()
    interactive_poller = InteractiveCommandPoller(repo_dir, job_id, interactive_page, images_dir, resume_event=resume_event)
    interactive_poller.start()

    MAX_INTERACTIVE_WAIT_S = 25 * 60  # 25 phút — xấp xỉ sàn Actions còn lại
    WAIT_CHUNK = 4  # kiểm tra resume_event thường xuyên hơn poll lệnh thường
    # (interval_s=CMD_POLL_INTERVAL_S=4 của poller) để phản hồi resume nhanh
    waited = 0
    resumed = False
    while waited < MAX_INTERACTIVE_WAIT_S:
        if resume_event.wait(timeout=WAIT_CHUNK):
            resumed = True
            break
        waited += WAIT_CHUNK
        if not interactive_poller.is_alive():
            break

    interactive_poller.stop_event.set()
    interactive_poller.join(timeout=10)
    print(f"[Interactive] Da dung sau {waited}s ({'tiep tuc cao' if resumed else 'het gio cho, se dong'})", flush=True)

    if resumed:
        # ĐÃ THÊM — lưu storage_state NGAY LÚC NÀY, vì đây là mốc quan
        # trọng nhất: cookie/localStorage của session VỪA qua CAPTCHA/xác
        # minh — nếu job này (hoặc job khác cùng site) chạy remote lần
        # sau, khôi phục được đúng cookie "đã tin cậy" này, không phải
        # giải lại từ đầu. Lưu TRƯỚC git_commit_push để commit dưới đây
        # đem theo file này (git_commit_push dùng `git add -A`).
        if storage_state_path:
            save_storage_state(context, storage_state_path)
        # Ghi lại pausedForManualReview=False NGAY — để app poll thấy job
        # đã hết trạng thái chờ (không phải đợi tới lần commit chương tiếp
        # theo mới hết hiện cảnh báo đỏ).
        with open(checkpoint_path, "w", encoding="utf-8") as f:
            cp = build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, i, chapters_so_far, blocked_count, False)
            json.dump(cp, f, ensure_ascii=False, indent=2)
        git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - da giai xong, tiep tuc cao tu chuong {i + 1}")
    else:
        if has_own_page and interactive_page is not page:
            # page mới tạo riêng cho chế độ AJAX — không cần giữ, đóng luôn
            # (caller sẽ đóng `page` gốc, nếu có, theo logic cũ)
            try:
                interactive_page.close()
            except Exception:
                pass

    return resumed, interactive_page


def main():
    if len(sys.argv) < 2:
        print("Thieu tham so job_id"); sys.exit(1)
    job_id = sys.argv[1]
    repo_dir = os.getcwd()

    with open(f"remote-jobs/{job_id}.json", "r", encoding="utf-8") as f:
        job = json.load(f)

    checkpoint_path = f"remote-jobs/{job_id}-checkpoint.json"
    images_dir = f"remote-jobs/{job_id}-images"
    chapter_links = []
    chapters_so_far = []
    blocked_count = 0
    start_index = 0

    if os.path.exists(checkpoint_path):
        print("[Resume] Tim thay checkpoint cu - cao tiep, KHONG cao lai tu dau (anh da tai truoc do van con nguyen trong remote-jobs/*-images/)", flush=True)
        with open(checkpoint_path, "r", encoding="utf-8") as f:
            old = json.load(f)
        chapter_links = old.get("chapterLinks", [])
        chapters_so_far = old.get("chaptersSoFar", [])
        blocked_count = old.get("blockedChapterCount", 0)
        start_index = old.get("chapterProgressIndex", 0)

    download_images = job.get("downloadImages", False)
    max_images_per_chapter = job.get("maxImagesPerChapter", 30)
    ajax_content = job.get("ajaxContentMode", False)

    # ĐÃ THÊM — khởi động heartbeat NỀN ngay từ đây, trước cả khi vào
    # Phase 1 (Phase 1 có thể tự nó mất nhiều phút với site nhiều trang) —
    # app cần thấy "còn sống" ngay cả trong lúc chưa cào được chương nào.
    heartbeat = HeartbeatThread(repo_dir, job_id)
    heartbeat.start()
    print(f"[Heartbeat] Bat dau bao con song moi {heartbeat.interval_s}s", flush=True)

    try:
        with sync_playwright() as p:
            # ĐÃ ĐỔI — headless=True → headless=False (chế độ "headed").
            # Lý do: Chromium headless để lại vài dấu hiệu nhận diện được
            # (thiếu 1 số API render nội bộ, timing hơi khác) mà các trang
            # có CAPTCHA/anti-bot dựa vào để phân biệt bot — headed mode
            # KHÔNG có các dấu hiệu này (tự nhiên giống trình duyệt người
            # dùng thật hơn). Trên runner Ubuntu KHÔNG có màn hình vật lý —
            # bước "Cài Xvfb" trong workflow (`xvfb-run ...`) cấp 1 display
            # ảo để Chromium headed có chỗ khởi động.
            #
            # Vẫn KHÔNG "dứt điểm" — chỉ giảm 1 lớp dấu hiệu trong nhiều lớp
            # mà anti-bot cấp cao (Cloudflare/DataDome...) kiểm tra (TLS
            # fingerprint, hành vi chuột/gõ phím... vẫn ngoài tầm với).
            #
            # --no-sandbox + --disable-dev-shm-usage: 2 cờ tiêu chuẩn khi
            # chạy Chromium trong container/CI (runner Actions chạy trong
            # môi trường hạn chế quyền + /dev/shm nhỏ — thiếu 2 cờ này dễ
            # crash ngẫu nhiên giữa chừng, không liên quan gì tới headed/
            # headless).
            browser = p.chromium.launch(
                headless=False,
                args=["--no-sandbox", "--disable-dev-shm-usage"],
            )
            # ĐÃ THÊM — khôi phục storage_state (cookie + localStorage) từ
            # lần chạy TRƯỚC nếu có, để phiên mới KHÔNG bị coi là "hoàn
            # toàn mới tinh" mỗi lần dispatch — đặc biệt hữu ích ngay sau
            # khi người dùng vừa giải CAPTCHA thành công ở lần chạy trước
            # (xem handle_blocked_pause() — lưu storage_state TRƯỚC khi
            # commit, để lần dispatch SAU đó — nếu có — kế thừa được luôn,
            # không phải giải lại).
            storage_state_path = f"remote-jobs/{job_id}-storage-state.json"
            context = make_context(browser, job, storage_state_path=storage_state_path)

            if not chapter_links:
                print("[Phase1] Thu thap danh sach chuong...", flush=True)
                stages = job.get("preListStages", [])
                if stages:
                    # ĐÃ THÊM — port preListStages (xem traverse_pre_list_stages()
                    # và ghi chú đầy đủ ở đó về 1 khác biệt nhỏ so với bản Kotlin).
                    stage_page = context.new_page()
                    entries = traverse_pre_list_stages(stage_page, job)
                    print(f"[Phase-1] Duyet xong kich ban - {len(entries)} nguon danh sach chuong", flush=True)
                    for entry_idx, entry_url in enumerate(entries):
                        print(f"[Phase1] Nguon {entry_idx + 1}/{len(entries)}: {entry_url}", flush=True)
                        if job.get("ajaxListMode", False):
                            entry_links = collect_chapter_links_ajax(context, job, base_url=entry_url)
                        else:
                            entry_links = collect_chapter_links_html(context, job, base_url=entry_url, page=stage_page)
                        for l in entry_links:
                            if l not in chapter_links:
                                chapter_links.append(l)
                    stage_page.close()
                elif job.get("ajaxListMode", False):
                    chapter_links = collect_chapter_links_ajax(context, job)
                else:
                    chapter_links = collect_chapter_links_html(context, job)
                print(f"[Phase1] Thu duoc {len(chapter_links)} link chuong", flush=True)
                with open(checkpoint_path, "w", encoding="utf-8") as f:
                    json.dump(build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, 0, [], 0, False), f, ensure_ascii=False, indent=2)
                # ĐÃ THÊM — lưu storage_state sau Phase 1 (đã đi qua trang
                # danh sách chương, có thể đã tự vượt qua 1 lớp Cloudflare/
                # xác minh nhẹ — lưu lại cookie này cho lần chạy sau).
                save_storage_state(context, storage_state_path)
                git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - xong Phase 1 ({len(chapter_links)} chuong)")

            page = context.new_page() if not ajax_content else None
            last_commit_time = time.time()

            # ĐÃ ĐỔI từ `for i in range(...)` sang `while i < len(...)` —
            # lý do: khi bị chặn và người dùng resume tại chỗ (xem
            # handle_blocked_pause), cần THỬ LẠI đúng chương i (không tăng
            # index) trên CÙNG session vừa giải xong — `for` không cho retry
            # cùng 1 giá trị i, phải tự quản lý index bằng tay.
            i = start_index
            while i < len(chapter_links):
                url = chapter_links[i]
                print(f"[Phase2] Chuong {i + 1}/{len(chapter_links)}: {url}", flush=True)
                try:
                    if ajax_content:
                        result, err = crawl_one_chapter_ajax(context, job, url)
                    else:
                        result, err = crawl_one_chapter_html(page, job, url)
                except BlockedNeedsManualReview as e:
                    # ĐÃ ĐỔI — thay vì luôn thoát hẳn, giờ gọi
                    # handle_blocked_pause() (dùng chung với vòng chờ
                    # interactive) và CÓ THỂ retry đúng chương i nếu người
                    # dùng resume tại chỗ (giải captcha qua nút điều khiển
                    # rồi bấm "Tiếp tục cào ngay") — không cần dispatch lại.
                    resumed, new_page = handle_blocked_pause(
                        context, page, job_id, repo_dir, checkpoint_path, images_dir,
                        chapter_links, i, chapters_so_far, blocked_count, e.url,
                        has_own_page=(page is None),
                        storage_state_path=storage_state_path,
                    )
                    if resumed:
                        if not ajax_content:
                            page = new_page  # có thể là page mới nếu trước đó None
                        continue  # THỬ LẠI đúng chương i — không tăng index
                    # Hết giờ chờ, không ai giải — dọn dẹp và thoát hẳn như cũ.
                    # Người dùng vẫn có thể "Chạy lại" sau (dispatch mới, đọc
                    # checkpoint, thử lại từ đúng chương i này).
                    if page:
                        try:
                            page.close()
                        except Exception:
                            pass
                    browser.close()
                    return  # THOÁT main() ngay — finally bên dưới vẫn chạy để dừng heartbeat

                except Exception as e:
                    result, err = None, f"Loi khong xac dinh: {e}"

                if err:
                    print(f"[Phase2] Loi chuong {i + 1}: {err}", flush=True)
                    chapters_so_far.append(chapter_to_json(i, f"Chuong {i + 1} [loi]", f"<p>Khong lay duoc noi dung: {err}</p>", f"[Khong lay duoc noi dung: {err}]", url, []))
                    blocked_count += 1
                else:
                    raw_title, raw_html, raw_text = result
                    images_meta = []
                    if download_images and raw_html:
                        raw_html, images_meta = download_and_localize_images(context, raw_html, url, i, max_images_per_chapter, images_dir)
                        if images_meta:
                            print(f"    Da tai {len(images_meta)} anh", flush=True)
                    title, html, text = apply_regex_rules(raw_title or f"Chuong {i + 1}", raw_html, raw_text, job.get("regexRules", []))
                    chapters_so_far.append(chapter_to_json(i, title, html, text, url, images_meta))

                now = time.time()
                should_commit = (
                    (i + 1 - start_index) % CHECKPOINT_COMMIT_EVERY_N_CHAPTERS == 0
                    or (now - last_commit_time) >= CHECKPOINT_COMMIT_EVERY_SECONDS
                    or i == len(chapter_links) - 1
                )
                if should_commit:
                    # git add -A (trong git_commit_push) tu gom CA checkpoint
                    # JSON lan moi anh moi ghi vao remote-jobs/<id>-images/
                    # trong CUNG 1 commit - anh va checkpoint LUON dong bo voi
                    # nhau, khong lech pha.
                    with open(checkpoint_path, "w", encoding="utf-8") as f:
                        json.dump(build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, i + 1, chapters_so_far, blocked_count, False), f, ensure_ascii=False, indent=2)
                    # ĐÃ THÊM — lưu storage_state cùng nhịp với checkpoint
                    # (rẻ — chỉ đọc cookie/localStorage hiện có, không tốn
                    # network) — luôn có bản mới nhất phòng khi job bị kill
                    # đột ngột giữa chừng (app crash, Actions timeout...).
                    save_storage_state(context, storage_state_path)
                    git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - {i + 1}/{len(chapter_links)} chuong")
                    last_commit_time = now

                time.sleep(job.get("delayBetweenPagesMs", 1500) / 1000.0)
                i += 1  # ĐÃ THÊM — for cũ tự tăng, while phải tự làm; CHỈ chạy
                        # khi không "continue" ở nhánh resumed (retry i cũ)

            if page:
                page.close()
            browser.close()

        with open(checkpoint_path, "w", encoding="utf-8") as f:
            json.dump(build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, len(chapter_links), chapters_so_far, blocked_count, True), f, ensure_ascii=False, indent=2)
        git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - HOAN TAT ({len(chapters_so_far)} chuong, {blocked_count} loi/chan)")
        print(f"[Done] Xong - {len(chapters_so_far)} chuong, {blocked_count} loi/chan", flush=True)

    finally:
        # ĐÃ THÊM — LUÔN dừng heartbeat khi main() kết thúc, dù thành công,
        # lỗi, hay pause-chờ-thủ-công (return ở trên) — không để lại thread
        # nền ghi heartbeat vô ích sau khi crawl đã xong/dừng hẳn.
        heartbeat.stop_event.set()
        heartbeat.join(timeout=5)
        print("[Heartbeat] Da dung", flush=True)


if __name__ == "__main__":
    main()
