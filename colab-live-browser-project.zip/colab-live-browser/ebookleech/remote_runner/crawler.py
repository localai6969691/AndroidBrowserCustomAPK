#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
crawler.py — cào từ xa cho 1 job EbookLeech, chạy trên GitHub Actions.
BẢN PLAYWRIGHT (Chromium headless) — thay bản `requests` thuần trước đó.

CÁCH DÙNG (do workflow gọi, không cần chạy tay):
    python3 remote_runner/crawler.py <job_id>

Đọc job-spec tại  remote-jobs/<job_id>.json  (app Android đã đẩy lên qua
Contents API — xem RemoteCrawlRunner.kt).
Ghi checkpoint tại remote-jobs/<job_id>-checkpoint.json — CÙNG SCHEMA với
`CrawlCheckpoint.toJson()`/`LeechChapter.toJson()` phía Kotlin.
Ghi ẢNH tại      remote-jobs/<job_id>-images/<tên file>  — CÙNG QUY ƯỚC đặt
tên/rewrite với `ImageDownloader.kt` (`img_<chương>_<số>.<đuôi>`, HTML
được đổi `src` thành `images/<tên file>`) để `EbookExporter` phía Kotlin
xử lý được y hệt nhau bất kể cào tại máy hay từ xa.

═══════════════════════════════════════════════════════════════════════
NÂNG CẤP SO VỚI BẢN TRƯỚC (dùng `requests` thuần — không còn nữa):
- Dùng Chromium THẬT (Playwright) — chạy được JavaScript, site
  SPA/render-bằng-JS giờ cào được (trước đây ra trang rỗng). Bản 7.101:
  chạy HEADED khi có DISPLAY (xvfb-run), tự rơi về headless khi không có;
  và CHỜ phần tử đích (selector của job) xuất hiện sau khi DOM tải xong
  (`renderWaitMs`, mặc định 8000ms) + cuộn lazy-load khi job bật — trước
  7.101 chụp trang ngay lúc DOMContentLoaded nên site dựng nội dung bằng JS
  chậm hơn ~1 giây ra RỖNG (đã tái hiện: 0/5 chương, sau sửa 5/5).
- TỰ QUA ĐƯỢC phần lớn "Cloudflare chặn" — đa số chặn Cloudflare thực ra
  chỉ là JS challenge tự động (trang tạm hiện "Checking your browser…"
  rồi tự chuyển tiếp sau vài giây) — trình duyệt thật chạy JS là qua bình
  thường, không cần ai bấm gì. Có đợi thêm vài giây + thử lại 1-2 lần nếu
  vẫn thấy trang chặn ngay sau khi tải xong.
- Tải ẢNH luôn, offline hoàn toàn — commit lên git CÙNG LÚC với checkpoint
  (xem `git_commit_push()`) nên nếu runner sập giữa chừng, ảnh ĐÃ TẢI
  không mất, y hệt nguyên tắc bảo toàn dữ liệu của checkpoint text.

BẢN 7.102 — CHỈ CÀO CHƯƠNG MỚI (job bật `incrementalUpdate`):
- Lần chạy trước ĐÃ XONG (checkpoint có `remoteDone=true`) thì lần này là lần chạy MỚI: KHÔNG tiếp tục checkpoint cũ (trước 7.102 tiếp tục => không thu lại
  danh sách chương => không bao giờ thấy chương mới). Thu lại danh sách chương; chương nào đã có trong checkpoint cũ (khoá = `sourceUrl`, y hệt kho chương
  phía điện thoại) thì DÙNG LẠI, không mở trang; chỉ mở trang chương mới (+ `refreshLastN` chương cuối cào lại, lỗi thì giữ bản cũ). Chương lỗi/bị chặn
  không bao giờ được dùng lại. Chương dùng lại GIỮ NGUYÊN `index` và ảnh (không đánh số lại — tên ảnh `img_<index>_<n>` không đụng nhau); chương mới nhận
  `index` = (chỉ số lớn nhất từng thấy, kể cả chương cũ chưa kịp dùng lại) + 1.
- Bản sao chương cũ nằm ở `remote-jobs/<id>-archive.json` trong LÚC chạy (để nếu lần chạy bị ngắt giữa chừng thì lần sau vẫn dùng lại được phần chưa xử lý);
  xoá khi chạy xong. Job KHÔNG bật `incrementalUpdate`: lần chạy mới cào lại toàn bộ như trước (nhưng thu lại danh sách chương, không còn dùng checkpoint cũ).
- Checkpoint có thêm `runnerVersion`, `reusedCount`, `crawledCount` (app bỏ qua trường lạ; `runnerVersion` để app biết crawler.py đã là bản mới).
- CHƯA có ở bản từ xa: bỏ qua chương theo điều kiện (`skipIfTextContains`/`minTextLength`) và chương nhiều trang (`chapterNextPageSelector`) — chỉ có ở cào tại máy.

VẪN CÒN GIỚI HẠN THẬT (không đổi được):
- CAPTCHA THẬT (hCaptcha/reCAPTCHA cần người bấm) — KHÔNG qua được, không
  có ai ngồi giải trên máy chủ Actions. Site dùng loại này (không phải
  JS-challenge-tự-động) sẽ vẫn bị ghi là lỗi/chặn, cào tiếp chương sau.
- KHÔNG hỗ trợ `useLoginSession` (không mượn được phiên đăng nhập THẬT
  của app) — nhưng job có `cookieHeader` (dán cookie tay) THÌ CÓ hỗ trợ —
  xem `make_context()`.
- Hỗ trợ `preListStages`/`autoDetectPagination` — đã port đầy đủ từ bản Kotlin.
- Hỗ trợ điều khiển tương tác từ xa qua git (xem `InteractiveCommandPoller`).
- CHƯA TỪNG CHẠY THỬ THẬT trên GitHub Actions — viết đúng theo tài liệu
  Playwright chính thức + đọc kỹ code Kotlin gốc để port logic tương
  đương, nhưng chưa có 1 lần chạy thật xác nhận. Nặng + chậm hơn hẳn bản
  `requests` cũ — cần theo dõi `timeout-minutes` của workflow có đủ không
  với job dài.
═══════════════════════════════════════════════════════════════════════
"""

import json
import os
import random
import re
import subprocess
import sys
import time
from urllib.parse import urljoin

from playwright.sync_api import sync_playwright, TimeoutError as PwTimeoutError
from bs4 import BeautifulSoup
import threading

RUNNER_VERSION = "7.104"  # app so với trường `runnerVersion` trong checkpoint để biết crawler.py trong repo có phải bản mới không
CHECKPOINT_COMMIT_EVERY_N_CHAPTERS = 5
CHECKPOINT_COMMIT_EVERY_SECONDS = 120
PAGE_TIMEOUT_MS = 30_000
CLOUDFLARE_RETRY_WAIT_S = 6
CLOUDFLARE_MAX_RETRIES = 2
MAX_IMAGE_BYTES = 6 * 1024 * 1024  # khớp MAX_IMAGE_BYTES trong ImageDownloader.kt
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

BLOCK_KEYWORDS = [
    "checking your browser", "just a moment", "verify you are human",
    "attention required", "ddos-guard", "access denied",
]
# Từ khoá CHỈ dùng để phát hiện chặn — KHÔNG dùng "cloudflare"/"captcha"
# một mình (nhiều site nhắc tới các từ này trong nội dung bình thường,
# không phải đang bị chặn) — chỉ coi là chặn khi khớp đúng cụm rõ ràng.


# ─────────────────────────────────────────────────────────────────────
# ContentSpinner — port từ ContentSpinner.kt (giữ ĐÚNG cú pháp {a|b|c})
# ─────────────────────────────────────────────────────────────────────
_SPIN_GROUP = re.compile(r"\{([^{}]*)\}")


def spin(template: str) -> str:
    if not template or "{" not in template:
        return template

    def _pick(m):
        options = m.group(1).split("|")
        if len(options) <= 1:
            return m.group(0)
        return random.choice(options)

    return _SPIN_GROUP.sub(_pick, template)


# ─────────────────────────────────────────────────────────────────────
# JsonPathExtractor — port từ JsonPathExtractor.kt (cú pháp "a.b[0].c")
# ─────────────────────────────────────────────────────────────────────
_SEGMENT_RE = re.compile(r"^([a-zA-Z0-9_]*)((?:\[\d+\])*)$")
_INDEX_RE = re.compile(r"\[(\d+)\]")


def json_path_resolve(root, path: str):
    if not path:
        return root
    current = root
    for seg in path.split("."):
        if current is None or not seg:
            return None
        m = _SEGMENT_RE.match(seg)
        if not m:
            return None
        key, indices_raw = m.group(1), m.group(2)
        if key:
            if not isinstance(current, dict):
                return None
            current = current.get(key)
            if current is None:
                return None
        for idx_s in _INDEX_RE.findall(indices_raw):
            idx = int(idx_s)
            if not isinstance(current, list) or idx >= len(current):
                return None
            current = current[idx]
    return current


def json_path_str(root, path: str):
    v = json_path_resolve(root, path)
    if v is None:
        return None
    return v if isinstance(v, str) else str(v)


# ─────────────────────────────────────────────────────────────────────
# ContentProcessor — port SUBSET các RegexRule.Kind (xem RegexRule.kt)
# ─────────────────────────────────────────────────────────────────────
def apply_regex_rules(title, html, text, rules):
    for rule in rules:
        if not rule.get("enabled", True):
            continue
        target = rule.get("target", "CONTENT_HTML")
        kind = rule.get("kind", "PLAIN_REPLACE")
        pattern = rule.get("pattern", "")
        replacement = rule.get("replacement", "")
        ci = rule.get("caseInsensitive", False)

        def get_input():
            return title if target == "TITLE" else (html if target == "CONTENT_HTML" else text)

        def set_input(v):
            nonlocal title, html, text
            if target == "TITLE":
                title = v
            elif target == "CONTENT_HTML":
                html = v
            else:
                text = v

        cur = get_input()
        is_html = target == "CONTENT_HTML"

        if kind == "PLAIN_REPLACE":
            if pattern:
                if ci:
                    cur = re.sub(re.escape(pattern), replacement.replace("\\", "\\\\"), cur, flags=re.IGNORECASE)
                else:
                    cur = cur.replace(pattern, replacement)
        elif kind == "REGEX_REPLACE":
            try:
                flags = re.IGNORECASE if ci else 0
                cur = re.sub(pattern, replacement, cur, flags=flags)
            except re.error:
                pass
        elif kind == "TRIM":
            cur = "\n".join(line.strip() for line in cur.split("\n"))
        elif kind == "REMOVE_EMPTY_LINES":
            cur = re.sub(r"\n{3,}", "\n\n", cur)
        elif kind == "TO_UPPERCASE":
            cur = cur.upper()
        elif kind == "TO_LOWERCASE":
            cur = cur.lower()
        elif kind == "CAPITALIZE_FIRST":
            cur = cur[:1].upper() + cur[1:] if cur else cur
        elif kind == "STRIP_HTML_TAGS":
            if is_html:
                cur = re.sub(r"<[^>]*>", "", cur)
        elif kind == "SPIN_INSERT_PREFIX":
            cur = spin(replacement) + cur
        elif kind == "SPIN_INSERT_SUFFIX":
            cur = cur + spin(replacement)

        set_input(cur)

    return title, html, text


def strip_tags_rough(html: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)).strip()


def looks_blocked(html: str) -> bool:
    lowered = html.lower()[:4000]
    return any(k in lowered for k in BLOCK_KEYWORDS)


# ─────────────────────────────────────────────────────────────────────
# ImageDownloader — port từ ImageDownloader.kt, GIỮ ĐÚNG quy ước đặt tên
# "img_<chương>_<số>.<đuôi>" + rewrite src → "images/<tên file>", để
# EbookExporter.kt phía Kotlin xử lý được y hệt bất kể nguồn cào.
# ─────────────────────────────────────────────────────────────────────
_IMG_SRC_RE = re.compile(r'<img[^>]+src\s*=\s*["\']([^"\']+)["\'][^>]*>', re.IGNORECASE)


def guess_extension(mime_type: str, url: str) -> str:
    mapping = {"jpeg": "jpg", "jpg": "jpg", "png": "png", "webp": "webp", "gif": "gif"}
    for key, ext in mapping.items():
        if key in mime_type:
            return ext
    from_url = url.rsplit(".", 1)[-1].split("?")[0].lower() if "." in url else ""
    return from_url if from_url in ("jpg", "jpeg", "png", "webp", "gif") else "jpg"


def download_and_localize_images(context, html: str, base_url: str, chapter_index: int, max_images: int, images_dir: str):
    """@return (html đã rewrite src, list metadata ảnh [{originalUrl, localFileName, mimeType}])"""
    matches = []
    seen = set()
    for m in _IMG_SRC_RE.finditer(html):
        src = m.group(1)
        if src not in seen and not src.startswith("data:"):
            seen.add(src)
            matches.append(src)

    downloaded = []
    url_to_local = {}
    counter = 0
    os.makedirs(images_dir, exist_ok=True)

    for src_url in matches:
        if counter >= max_images:
            break
        absolute_url = urljoin(base_url, src_url)
        try:
            resp = context.request.get(absolute_url, timeout=15_000)
        except Exception as e:
            print(f"    [Anh] Loi tai {absolute_url}: {e}", flush=True)
            continue
        if not resp.ok:
            continue
        mime_type = (resp.headers.get("content-type", "") or "").split(";")[0].strip() or "image/jpeg"
        if not mime_type.startswith("image/"):
            continue
        body = resp.body()
        if len(body) > MAX_IMAGE_BYTES:
            continue

        counter += 1
        ext = guess_extension(mime_type, absolute_url)
        local_name = f"img_{chapter_index}_{counter}.{ext}"
        with open(os.path.join(images_dir, local_name), "wb") as f:
            f.write(body)
        downloaded.append({"originalUrl": absolute_url, "localFileName": local_name, "mimeType": mime_type})
        url_to_local[src_url] = local_name

    new_html = html
    for original, local in url_to_local.items():
        new_html = new_html.replace(original, f"images/{local}")

    return new_html, downloaded


# ─────────────────────────────────────────────────────────────────────
# Playwright — tải trang, tự chờ qua Cloudflare JS challenge
# ─────────────────────────────────────────────────────────────────────
def make_context(browser, job, storage_state_path=None):
    ua = job.get("customUserAgent") or DEFAULT_USER_AGENT
    # ĐÃ THÊM — nếu có file storage_state từ lần chạy trước (cookie +
    # localStorage đã lưu, xem save_storage_state() và nơi gọi trong
    # main()/handle_blocked_pause()) thì khôi phục NGAY khi tạo context —
    # Playwright tự nạp lại toàn bộ cookie + localStorage của mọi origin
    # đã lưu, coi như tiếp tục đúng phiên cũ (không phải "khách lạ" với
    # site nữa — nhiều site anti-bot tin tưởng session đã tồn tại lâu hơn
    # session vừa tạo).
    kwargs = {"user_agent": ua}
    if storage_state_path and os.path.exists(storage_state_path):
        kwargs["storage_state"] = storage_state_path
        print(f"[Session] Khoi phuc storage_state tu lan chay truoc: {storage_state_path}", flush=True)
    context = browser.new_context(**kwargs)
    cookie_header = job.get("cookieHeader", "")
    if cookie_header:
        # Chuỗi Cookie thô dạng "a=1; b=2" — tiêm qua extra HTTP header,
        # Chromium tự gửi kèm mọi request trong context này (khác
        # context.add_cookies() cần cấu trúc object riêng từng cookie —
        # job.cookieHeader vốn đã là chuỗi thô người dùng dán tay, tiêm
        # thẳng đỡ phải tự parse lại thành từng cookie).
        context.set_extra_http_headers({"Cookie": cookie_header})
    return context


def save_storage_state(context, storage_state_path):
    """ĐÃ THÊM — lưu cookie + localStorage hiện tại của context ra file, để
    lần chạy remote SAU (nếu có — job khác hoặc dispatch lại job này) khôi
    phục lại được qua make_context(). Gọi hàm này ở các mốc quan trọng:
    sau Phase 1, sau mỗi lần commit checkpoint trong Phase 2, và NGAY SAU
    KHI người dùng giải CAPTCHA xong (handle_blocked_pause) — mốc cuối này
    quan trọng nhất, vì đó là lúc cookie "đã qua xác minh" mới nhất."""
    try:
        context.storage_state(path=storage_state_path)
    except Exception as e:
        # Không để lỗi lưu storage_state làm gãy cả job — chỉ mất tác dụng
        # "nhớ phiên" cho lần sau, không ảnh hưởng lần chạy hiện tại.
        print(f"[Session] Luu storage_state loi (bo qua, khong anh huong job hien tai): {e}", flush=True)


RENDER_WAIT_MS_DEFAULT = 8000      # chờ tối đa bấy nhiêu ms cho phần tử đích xuất hiện (trang JS dựng nội dung sau khi DOM tải xong)
RENDER_WAIT_MS_PROBE = 3000        # bước dò (thử template phân trang) chờ ngắn hơn: sai template thì không có phần tử nào, khỏi chờ lâu
LAZY_SCROLL_STEP_MS = 700          # khớp autoScrollThenRun phía Kotlin


def scroll_for_lazy_load(page, job):
    """Cuộn dần xuống đáy, đo lại chiều cao trang, lặp tới khi chiều cao không đổi hoặc hết `maxScrollAttempts` — cùng logic bản điện thoại
    (autoScrollThenRun trong EbookLeechCrawler.kt), để job "trang chỉ hiện nội dung khi cuộn xuống" chạy đúng cả khi cào từ xa."""
    attempts = int(job.get("maxScrollAttempts", 6) or 6)
    last = -1
    for _ in range(attempts):
        try:
            h = page.evaluate("() => { window.scrollTo(0, document.body.scrollHeight); return document.body.scrollHeight; }")
        except Exception:
            return
        if h == last:
            return
        last = h
        page.wait_for_timeout(LAZY_SCROLL_STEP_MS)


def settle_dynamic_page(page, job, wait_selector, lazy_scroll, html_now, wait_ms=None):
    """`wait_until="domcontentloaded"` chỉ nghĩa là HTML đã tải, KHÔNG nghĩa là JavaScript đã dựng xong nội dung (site SPA/render-bằng-JS thường
    dựng danh sách chương hoặc nội dung chương SAU thời điểm đó). Đợi phần tử đích (selector job đã cấu hình) xuất hiện — trang tĩnh đã có sẵn
    phần tử nên trả về NGAY, không chậm thêm; hết thời gian mà không thấy thì KHÔNG coi là lỗi ở đây (bước bóc tách phía sau tự báo "không tìm thấy").
    Rồi cuộn lazy-load nếu job bật. @return html mới nhất (hoặc html_now nếu không đọc lại được)."""
    # Cuộn TRƯỚC rồi mới chờ phần tử: với trang lazy-load, phần tử đích chỉ xuất hiện SAU khi cuộn — chờ trước thì luôn chờ cạn hết thời gian rồi mới cuộn
    # (đã đo: 49s thay vì ~15s cho 5 chương). Trang JS dựng chậm (không lazy) vẫn được bước chờ phía sau lo.
    if lazy_scroll:
        scroll_for_lazy_load(page, job)
    if wait_selector:
        timeout = wait_ms if wait_ms is not None else int(job.get("renderWaitMs", RENDER_WAIT_MS_DEFAULT))
        try:
            page.wait_for_selector(wait_selector, timeout=timeout, state="attached")
        except Exception:
            pass
    try:
        return page.content()
    except Exception:
        return html_now


def goto_with_cloudflare_retry(page, url, job=None, wait_selector=None, lazy_scroll=False, wait_ms=None):
    """@return (html, still_blocked) — still_blocked=True khi hết số lần
    thử mà vẫn thấy trang chặn (khác lỗi mạng/timeout — đây là lúc CẦN
    dừng cả job lại chờ người dùng, xem crawl_one_chapter_html()).
    Bản 7.101: `wait_selector`/`lazy_scroll` — chờ trang JS dựng xong nội dung (xem settle_dynamic_page); chỉ chờ SAU khi đã chắc trang không phải trang chặn."""
    html = ""
    for attempt in range(CLOUDFLARE_MAX_RETRIES + 1):
        try:
            page.goto(url, timeout=PAGE_TIMEOUT_MS, wait_until="domcontentloaded")
        except PwTimeoutError:
            if attempt < CLOUDFLARE_MAX_RETRIES:
                print(f"    Timeout tai trang (lan {attempt + 1}) - thu lai", flush=True)
                continue
            print("    Timeout - bo cuoc trang nay", flush=True)
            try:
                return page.content(), False  # timeout mạng thường, KHÔNG phải bị chặn — không cần dừng cả job
            except Exception:
                return "", False
        html = page.content()
        if not looks_blocked(html):
            if wait_selector or lazy_scroll:
                html = settle_dynamic_page(page, job or {}, wait_selector, lazy_scroll, html, wait_ms)
            return html, False
        if attempt < CLOUDFLARE_MAX_RETRIES:
            print(f"    Co ve dang bi chan (Cloudflare JS challenge?) - cho {CLOUDFLARE_RETRY_WAIT_S}s roi thu lai ({attempt + 1}/{CLOUDFLARE_MAX_RETRIES})", flush=True)
            page.wait_for_timeout(CLOUDFLARE_RETRY_WAIT_S * 1000)
    return html, True  # hết số lần thử, VẪN bị chặn — có thể là CAPTCHA thật, không phải JS challenge tự động


# ─────────────────────────────────────────────────────────────────────
# Phase 0 — ĐÃ THÊM: port autoDetectPagination từ EbookLeechCrawler.kt
# (trước đây job remote BẮT BUỘC phải tự khai rõ listPageUrlPattern —
# không tự dò được). Thử lần lượt 5 template phân trang phổ biến với
# page=2, so với baseline (link chương ở trang 1) — template nào cho ra
# link MỚI thì coi là đúng. Giữ NGUYÊN VẸN đúng 5 template + thứ tự thử
# như bản Kotlin gốc (paginationCandidates trong EbookLeechCrawler.kt).
# ─────────────────────────────────────────────────────────────────────
PAGINATION_CANDIDATES = [
    "{base}?page={page}", "{base}/page/{page}", "{base}/trang-{page}", "{base}/page-{page}", "{base}/{page}",
]


def auto_detect_pagination(page, job, base_url, baseline_links):
    """@return template đã dò được (còn nguyên "{page}", "{base}" đã thay)
    hoặc None nếu không template nào cho kết quả mới (coi như 1 trang)."""
    base = base_url.rstrip("/")
    baseline = set(baseline_links)
    selector = job["chapterLinkSelector"]
    attr = job.get("chapterLinkAttribute", "href")

    for template in PAGINATION_CANDIDATES:
        candidate_url = template.replace("{base}", base).replace("{page}", "2")
        print(f"[Phase0] Thu template phan trang: {candidate_url}", flush=True)
        html, still_blocked = goto_with_cloudflare_retry(page, candidate_url, job=job, wait_selector=selector, wait_ms=RENDER_WAIT_MS_PROBE)
        if still_blocked:
            print(f"[Phase0] Template {template} bi chan - bo qua, thu template khac", flush=True)
            continue
        soup = BeautifulSoup(html, "lxml")
        links = set()
        for el in soup.select(selector):
            href = (el.get(attr) or "").strip()
            if href:
                links.add(urljoin(candidate_url, href))
        if links - baseline:
            print(f"[Phase0] Da do duoc pattern: {template}", flush=True)
            return template
    print("[Phase0] Khong tu do duoc phan trang - coi nhu chi co 1 trang", flush=True)
    return None


# <<STORY_META BEGIN>>
# ─────────────────────────────────────────────────────────────────────
# Bản 7.104 — THÔNG TIN TRUYỆN (tác giả, tóm tắt, thể loại, tag, tình trạng, đánh giá, bìa...) để ebook thành nguyên liệu đăng lên web truyện.
# `STORY_META_JS` chạy TRONG trang (Playwright `page.evaluate`) và GIỐNG HỆT từng byte bản trong LeechDesk (ld/storymeta.py) và app (StoryMetaJs.kt) — có test so khớp.
# Thứ tự ưu tiên: selector người dùng > JSON-LD > Open Graph/book:/meta > microdata > nhãn "Tác giả:/Thể loại:" > h1/<title>; người dùng nhập tay (storyMetaManual) thắng tất cả.
# ─────────────────────────────────────────────────────────────────────
STORY_META_JS = r"""function (cfg) {
  cfg = cfg || {};
  var sel = cfg.selectors || {};
  var out = {}, src = {};
  var LIST_FIELDS = { genres: 1, tags: 1, altTitles: 1 };
  var KNOWN = { title: 1, author: 1, summary: 1, genres: 1, tags: 1, status: 1, rating: 1, cover: 1, language: 1, altTitles: 1, series: 1, seriesIndex: 1, publishedAt: 1, updatedAt: 1, translator: 1, publisher: 1 };

  function clean(s) { return (s == null ? '' : String(s)).replace(/[\u00a0\u200b\u200c\u200d\ufeff]/g, ' ').replace(/\s+/g, ' ').trim(); }
  function has(f) { return Object.prototype.hasOwnProperty.call(out, f); }
  function put(f, v, from) {
    if (has(f) || v == null) return;
    if (typeof v === 'string') { v = v.trim(); if (!v) return; }
    if (Array.isArray(v)) { if (!v.length) return; }
    if (typeof v === 'object' && !Array.isArray(v) && !Object.keys(v).length) return;
    out[f] = v; src[f] = from;
  }
  function abs(u) {
    u = clean(u);
    if (!u || /^(data|javascript|blob):/i.test(u)) return '';
    try { return new URL(u, document.baseURI).href; } catch (e) { return u; }
  }
  function qAll(css) { try { return Array.prototype.slice.call(document.querySelectorAll(css)); } catch (e) { return []; } }
  function q1(css) { try { return document.querySelector(css); } catch (e) { return null; } }
  function metaC(attr, name) {
    var els = qAll('meta[' + attr + '="' + name + '"]'), r = [];
    for (var i = 0; i < els.length; i++) { var c = clean(els[i].getAttribute('content')); if (c) r.push(c); }
    return r;
  }
  function meta1(attr, name) { var r = metaC(attr, name); return r.length ? r[0] : ''; }
  function splitList(s) {
    var parts = clean(s).split(/\s*[,;|\u3001\uff0c\u00b7\u2022\n]\s*/), r = [], seen = {};
    for (var i = 0; i < parts.length; i++) { var p = parts[i].trim(); if (p && !seen[p.toLowerCase()]) { seen[p.toLowerCase()] = 1; r.push(p); } }
    return r;
  }
  function uniq(arr) {
    var r = [], seen = {};
    for (var i = 0; i < arr.length; i++) { var p = clean(arr[i]); if (p && !seen[p.toLowerCase()]) { seen[p.toLowerCase()] = 1; r.push(p); } }
    return r;
  }
  var LABEL_PREFIX = /^(t\u00e1c gi\u1ea3 |t\u00e1c gi\u1ea3|author|by|t\u00ecnh tr\u1ea1ng|tr\u1ea1ng th\u00e1i|status|th\u1ec3 lo\u1ea1i|genres?|categories|category|tags?|ngu\u1ed3n|source|d\u1ecbch gi\u1ea3|translator|\u4f5c\u8005|\u72b6\u6001|\u5206\u7c7b)\s*[:\uff1a]\s*/i;
  function stripLabel(s) { return clean(s).replace(LABEL_PREFIX, ''); }
  function blockText(el) {
    var t = '';
    try { t = el.innerText; } catch (e) { }
    if (!t) t = el.textContent || '';
    var lines = t.replace(/\r/g, '').split('\n'), r = [];
    for (var i = 0; i < lines.length; i++) { var l = clean(lines[i]); if (l) r.push(l); }
    return r.join('\n');
  }
  function textToLines(s) {
    var lines = String(s || '').replace(/\r/g, '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n').replace(/<[^>]+>/g, '').split('\n'), r = [];
    for (var i = 0; i < lines.length; i++) { var l = clean(lines[i]); if (l) r.push(l); }
    return r.join('\n');
  }

  function normStatus(s) {
    s = clean(s).toLowerCase();
    if (!s) return '';
    if (/(dropped|\bdrop\b|abandon|discontinued|cancel|b\u1ecf d\u1edf|\u0111\u00e3 drop|\u5f03\u5751)/.test(s)) return 'dropped';
    if (/(hiatus|t\u1ea1m ng\u01b0ng|t\u1ea1m d\u1eebng|t\u1ea1m ngh\u1ec9|on hold|on-hold|paused|\u6682\u505c|\u4f11\u8f09)/.test(s)) return 'hiatus';
    if (/(ch\u01b0a ho\u00e0n|ch\u01b0a full|\u0111ang|c\u00f2n ti\u1ebfp|ti\u1ebfp t\u1ee5c|ongoing|on-going|in progress|serializ|updating|not complete|incomplete|unfinished|\u8fde\u8f7d|\u9023\u8f09)/.test(s)) return 'ongoing';
    if (/(ho\u00e0n th\u00e0nh|ho\u00e0n t\u1ea5t|ho\u00e0n|\bfull\b|\u0111\u00e3 xong|k\u1ebft th\u00fac|complet|finished|ended|\u5b8c\u7ed3|\u5b8c\u7d50|\u5b8c\u672c)/.test(s)) return 'completed';
    return '';
  }
  function num(s) {
    s = String(s).trim();
    if (/^\d{1,3}([.,]\d{3})+$/.test(s)) return parseFloat(s.replace(/[.,]/g, ''));
    return parseFloat(s.replace(',', '.'));
  }
  function parseRating(s) {
    s = clean(s);
    var m = s.match(/(\d+(?:[.,]\d+)?)\s*(?:\/|tr\u00ean|out of|of)\s*(\d+(?:[.,]\d+)?)/i), v, sc = 0;
    if (m) { v = num(m[1]); sc = num(m[2]); }
    else { m = s.match(/(\d+(?:[.,]\d+)?)/); if (!m) return null; v = num(m[1]); }
    if (!isFinite(v)) return null;
    if (!sc || !isFinite(sc)) sc = v <= 5 ? 5 : (v <= 10 ? 10 : 100);
    var r = { value: v, scale: sc }, c = s.match(/(\d[\d.,]*)\s*(?:votes?|ratings?|reviews?|\u0111\u00e1nh gi\u00e1|l\u01b0\u1ee3t|ng\u01b0\u1eddi)/i) || s.match(/\((\d[\d.,]*)\)/);
    if (c) { var n = num(c[1]); if (isFinite(n)) r.count = n; }
    return r;
  }
  function ratingFrom(value, best, count) {
    var v = parseFloat(String(value).replace(',', '.'));
    if (!isFinite(v)) return null;
    var sc = parseFloat(String(best == null ? '' : best).replace(',', '.'));
    var r = { value: v, scale: isFinite(sc) && sc > 0 ? sc : (v <= 5 ? 5 : (v <= 10 ? 10 : 100)) };
    var n = parseFloat(String(count == null ? '' : count).replace(/[.,]/g, ''));
    if (isFinite(n)) r.count = n;
    return r;
  }
  function normDate(s) {
    s = clean(s);
    if (!s) return '';
    if (/^\d{4}-\d{2}-\d{2}([T ]|$)/.test(s)) return s.length > 10 ? s.replace(' ', 'T') : s;
    var m = s.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})(?:\s+.*)?$/);
    if (m) { var d = ('0' + m[1]).slice(-2), mo = ('0' + m[2]).slice(-2); return m[3] + '-' + mo + '-' + d; }
    var t = Date.parse(s);
    if (isFinite(t)) { try { return new Date(t).toISOString().slice(0, 10); } catch (e) { } }
    return s;
  }
  function normLang(s) {
    s = clean(s).toLowerCase().replace(/_/g, '-');
    var m = s.match(/^([a-z]{2,3})(?:-|$)/);
    return m ? m[1] : '';
  }

  var siteName = meta1('property', 'og:site_name');
  function trimSite(t) {
    t = clean(t);
    var seps = [' | ', ' - ', ' \u2013 ', ' \u2014 ', ' \u00bb ', ' :: '], i, k;
    for (i = 0; i < seps.length; i++) {
      k = t.lastIndexOf(seps[i]);
      if (k > 0) {
        var tail = t.slice(k + seps[i].length).toLowerCase(), host = (location.hostname || '').replace(/^www\./, '').toLowerCase();
        if ((siteName && tail === siteName.toLowerCase()) || (host && tail.replace(/\s+/g, '').indexOf(host.split('.')[0]) >= 0)) return t.slice(0, k).trim();
      }
    }
    return t;
  }
  function parseSel(s) {
    s = String(s || '').trim();
    var m = s.match(/^(.*\S)\s*@([A-Za-z_:][\w:.\-]*)\s*$/);
    return m ? { css: m[1], attr: m[2] } : { css: s, attr: '' };
  }
  function imgUrl(el, attr) {
    if (!el) return '';
    if (attr) return abs(el.getAttribute(attr));
    var names = ['content', 'src', 'data-src', 'data-lazy-src', 'data-original', 'data-cfsrc'], i, v;
    for (i = 0; i < names.length; i++) { v = el.getAttribute && el.getAttribute(names[i]); if (v && abs(v)) return abs(v); }
    v = el.getAttribute && (el.getAttribute('srcset') || el.getAttribute('data-srcset'));
    if (v) return abs(clean(v).split(',')[0].trim().split(' ')[0]);
    var inner = el.querySelector && el.querySelector('img');
    if (inner && inner !== el) return imgUrl(inner, '');
    var bg = '';
    try { bg = (el.style && el.style.backgroundImage) || window.getComputedStyle(el).backgroundImage || ''; } catch (e) { }
    var m = bg.match(/url\((['"]?)(.*?)\1\)/);
    return m ? abs(m[2]) : '';
  }
  function bySelector(field, spec) {
    var p = parseSel(spec);
    if (!p.css) return;
    var els = qAll(p.css), i;
    if (!els.length) return;
    function one(el) { return p.attr ? clean(el.getAttribute(p.attr)) : clean(el.textContent); }
    if (field === 'cover') { put('cover', imgUrl(els[0], p.attr), 'selector'); return; }
    if (field === 'summary') {
      var t = p.attr ? textToLines(els[0].getAttribute(p.attr)) : blockText(els[0]);
      var lines = t.split('\n');
      if (lines.length && LABEL_PREFIX.test(lines[0])) lines[0] = lines[0].replace(LABEL_PREFIX, '');
      put('summary', lines.join('\n').trim(), 'selector'); return;
    }
    if (LIST_FIELDS[field]) {
      var arr = [];
      for (i = 0; i < els.length; i++) { var v = stripLabel(one(els[i])); if (els.length === 1) arr = arr.concat(splitList(v)); else if (v) arr.push(v); }
      put(field, uniq(arr), 'selector'); return;
    }
    if (field === 'author' || field === 'translator') {
      var names = [];
      for (i = 0; i < els.length; i++) { var a = stripLabel(one(els[i])); if (a) names.push(a); }
      put(field, uniq(names).join(', '), 'selector'); return;
    }
    var val = stripLabel(one(els[0]));
    if (field === 'status') { put('status', normStatus(val), 'selector'); put('statusText', val, 'selector'); }
    else if (field === 'rating') { put('rating', parseRating(val), 'selector'); }
    else if (field === 'publishedAt' || field === 'updatedAt') { put(field, normDate(val), 'selector'); }
    else if (field === 'language') { put('language', normLang(val), 'selector'); }
    else if (field === 'seriesIndex') { var n = parseFloat(val.replace(',', '.')); if (isFinite(n)) put('seriesIndex', n, 'selector'); }
    else if (KNOWN[field]) { put(field, val, 'selector'); }
    else { out.extra = out.extra || {}; if (!out.extra[field]) out.extra[field] = val; }
  }
  for (var f in sel) { if (Object.prototype.hasOwnProperty.call(sel, f) && sel[f]) bySelector(f, sel[f]); }

  // ---- 2) JSON-LD ----
  function ldNodes() {
    var nodes = [], scripts = qAll('script[type="application/ld+json"]');
    function walk(x) {
      if (!x) return;
      if (Array.isArray(x)) { for (var i = 0; i < x.length; i++) walk(x[i]); return; }
      if (typeof x !== 'object') return;
      nodes.push(x);
      if (x['@graph']) walk(x['@graph']);
    }
    for (var i = 0; i < scripts.length; i++) { try { walk(JSON.parse(scripts[i].textContent)); } catch (e) { } }
    return nodes;
  }
  function typesOf(n) { var t = n['@type']; return (Array.isArray(t) ? t : [t]).map(function (x) { return String(x || ''); }); }
  function ldName(v) {
    if (v == null) return '';
    if (typeof v === 'string') return clean(v);
    if (Array.isArray(v)) return uniq(v.map(ldName)).join(', ');
    return clean(v.name || '');
  }
  function ldImage(v) {
    if (!v) return '';
    if (typeof v === 'string') return abs(v);
    if (Array.isArray(v)) return ldImage(v[0]);
    return abs(v.url || v.contentUrl || '');
  }
  function ldList(v) {
    if (v == null) return [];
    if (Array.isArray(v)) return uniq(v.map(function (x) { return typeof x === 'string' ? x : ldName(x); }));
    return splitList(typeof v === 'string' ? v : ldName(v));
  }
  (function () {
    var nodes = ldNodes(), book = null, other = null, i, t;
    for (i = 0; i < nodes.length; i++) {
      t = typesOf(nodes[i]);
      if (!book && t.some(function (x) { return /^(Book|Audiobook|CreativeWorkSeries|BookSeries)$/.test(x); })) book = nodes[i];
      if (!other && t.some(function (x) { return /^(Article|NewsArticle|BlogPosting|CreativeWork|WebPage|ItemPage)$/.test(x); })) other = nodes[i];
    }
    var n = book || other;
    if (!n) return;
    var isBook = !!book;
    put('title', trimSite(n.name || n.headline || ''), 'jsonld');
    if (isBook) put('author', ldName(n.author || n.creator), 'jsonld');
    put('summary', textToLines(n.description || ''), 'jsonld');
    put('cover', ldImage(n.image || n.thumbnailUrl), 'jsonld');
    put('genres', ldList(n.genre), 'jsonld');
    put('tags', ldList(n.keywords), 'jsonld');
    put('language', normLang(typeof n.inLanguage === 'string' ? n.inLanguage : ldName(n.inLanguage)), 'jsonld');
    put('publishedAt', normDate(n.datePublished || ''), 'jsonld');
    put('updatedAt', normDate(n.dateModified || ''), 'jsonld');
    if (n.aggregateRating) put('rating', ratingFrom(n.aggregateRating.ratingValue, n.aggregateRating.bestRating, n.aggregateRating.ratingCount || n.aggregateRating.reviewCount), 'jsonld');
    if (isBook) put('publisher', ldName(n.publisher), 'jsonld');
    if (isBook && n.isPartOf) put('series', ldName(n.isPartOf), 'jsonld');
    if (isBook && n.alternateName) put('altTitles', ldList(n.alternateName), 'jsonld');
  })();

  put('title', trimSite(meta1('property', 'og:title')), 'og');
  put('author', uniq(metaC('property', 'og:novel:author').concat(metaC('property', 'book:author').filter(function (a) { return !/^https?:/i.test(a); }))).join(', '), 'og');
  put('author', clean(meta1('name', 'author')), 'meta');
  put('summary', textToLines(meta1('property', 'og:description')), 'og');
  put('summary', textToLines(meta1('name', 'description')), 'meta');
  put('cover', abs(meta1('property', 'og:image') || meta1('property', 'og:image:url') || meta1('name', 'twitter:image') || meta1('property', 'twitter:image')), 'og');
  (function () { var l = q1('link[rel="image_src"]'); if (l) put('cover', abs(l.getAttribute('href')), 'link'); })();
  put('genres', uniq([].concat(metaC('property', 'og:novel:category'), metaC('property', 'og:novel:genre'), metaC('property', 'article:section')).reduce(function (a, s) { return a.concat(splitList(s)); }, [])), 'og');
  put('tags', uniq([].concat(metaC('property', 'book:tag'), metaC('property', 'article:tag'))), 'og');
  put('tags', splitList(meta1('name', 'keywords')), 'meta');
  var st = meta1('property', 'og:novel:status') || meta1('property', 'og:status');
  if (st) { put('status', normStatus(st), 'og'); put('statusText', st, 'og'); }
  put('language', normLang(meta1('property', 'og:locale')), 'og');
  put('publishedAt', normDate(meta1('property', 'article:published_time') || meta1('property', 'book:release_date') || meta1('property', 'og:novel:release_date')), 'og');
  put('updatedAt', normDate(meta1('property', 'article:modified_time') || meta1('property', 'og:updated_time') || meta1('property', 'og:novel:update_time')), 'og');
  put('publisher', siteName, 'og');

  // ---- 4) microdata (itemprop) ----
  (function () {
    var scope = q1('[itemtype*="Book"]') || document;
    function ip(name) { return Array.prototype.slice.call(scope.querySelectorAll('[itemprop="' + name + '"]')); }
    var e;
    if ((e = ip('name')[0])) put('title', clean(e.getAttribute('content') || e.textContent), 'itemprop');
    var au = ip('author').map(function (el) { var n = el.querySelector('[itemprop="name"]'); return clean(n ? n.textContent : (el.getAttribute('content') || el.textContent)); });
    put('author', uniq(au).join(', '), 'itemprop');
    if ((e = ip('description')[0])) put('summary', blockText(e), 'itemprop');
    if ((e = ip('image')[0])) put('cover', imgUrl(e, ''), 'itemprop');
    var g = ip('genre').map(function (el) { return clean(el.getAttribute('content') || el.textContent); });
    put('genres', uniq(g), 'itemprop');
    if ((e = ip('inLanguage')[0])) put('language', normLang(e.getAttribute('content') || e.textContent), 'itemprop');
    function tv(e) { return e ? (e.getAttribute('content') || e.textContent) : null; }
    var rv = ip('ratingValue')[0];
    if (rv) put('rating', ratingFrom(tv(rv), tv(ip('bestRating')[0]), tv(ip('ratingCount')[0] || ip('reviewCount')[0])), 'itemprop');
  })();

  var LABELS = {
    author: /^(t\u00e1c gi\u1ea3|author|authors|writer|\u4f5c\u8005)$/i,
    genres: /^(th\u1ec3 lo\u1ea1i|genres?|categor(?:y|ies)|\u5206\u7c7b|\u7c7b\u578b)$/i,
    tags: /^(tags?|t\u1eeb kh\u00f3a|keywords?|nh\u00e3n)$/i,
    status: /^(t\u00ecnh tr\u1ea1ng|tr\u1ea1ng th\u00e1i|status|\u72b6\u6001)$/i,
    translator: /^(d\u1ecbch gi\u1ea3|nh\u00f3m d\u1ecbch|translator|translated by)$/i,
    altTitles: /^(t\u00ean kh\u00e1c|t\u00ean g\u1ecdi kh\u00e1c|alternative names?|alternate names?|other names?|also known as|\u5225\u540d|\u522b\u540d)$/i,
    rating: /^(\u0111\u00e1nh gi\u00e1|rating|ratings|\u8bc4\u5206)$/i,
    publishedAt: /^(ng\u00e0y \u0111\u0103ng|ng\u00e0y t\u1ea1o|published|release date|\u0111\u0103ng ng\u00e0y)$/i,
    updatedAt: /^(c\u1eadp nh\u1eadt|c\u1eadp nh\u1eadt l\u1ea7n cu\u1ed1i|updated|last updated|ng\u00e0y c\u1eadp nh\u1eadt)$/i
  };
  (function () {
    var cands = qAll('li,p,div,span,dt,th,td,b,strong,label,h3,h4,h5,small'), i, j, el, t, m, rest, k, lab, anchors, sib;
    for (i = 0; i < cands.length; i++) {
      el = cands[i];
      t = clean(el.textContent);
      if (!t || t.length > 500) continue;
      m = t.match(/^([^:\uff1a]{2,24})\s*[:\uff1a]\s*(.*)$/);
      var label = null;
      if (m) { label = clean(m[1]); rest = clean(m[2]); }
      else if (t.length <= 24) { label = t.replace(/[:\uff1a]\s*$/, ''); rest = ''; if (label === t) continue; }
      else continue;
      for (k in LABELS) {
        if (!Object.prototype.hasOwnProperty.call(LABELS, k) || !LABELS[k].test(label)) continue;
        if (has(k)) break;
        var valueEl = el;
        if (!rest) {
          sib = el.nextElementSibling;
          if (!sib && el.parentElement && /^(dt|th)$/i.test(el.tagName)) sib = el.parentElement.nextElementSibling;
          if (!sib) break;
          valueEl = sib; rest = clean(sib.textContent);
          if (!rest || rest.length > 400) break;
        } else if (el.children && el.children.length > 8) break;
        anchors = Array.prototype.slice.call(valueEl.querySelectorAll('a')).map(function (a) { return clean(a.textContent); }).filter(Boolean);
        if (LIST_FIELDS[k]) put(k, uniq(anchors.length ? anchors : splitList(rest)), 'label');
        else if (k === 'author' || k === 'translator') put(k, uniq(anchors.length ? anchors : [rest]).join(', '), 'label');
        else if (k === 'status') { put('status', normStatus(rest), 'label'); put('statusText', rest, 'label'); }
        else if (k === 'rating') put('rating', parseRating(rest), 'label');
        else put(k, normDate(rest), 'label');
        break;
      }
    }
    if (!has('summary')) {
      var heads = qAll('h1,h2,h3,h4,h5,h6,strong,b,div,span,p');
      for (i = 0; i < heads.length; i++) {
        t = clean(heads[i].textContent);
        if (t.length > 30 || !/^(gi\u1edbi thi\u1ec7u|t\u00f3m t\u1eaft|n\u1ed9i dung|m\u00f4 t\u1ea3|synopsis|summary|description|overview|\u7b80\u4ecb|\u5185\u5bb9\u7b80\u4ecb)\s*[:\uff1a]?$/i.test(t)) continue;
        if (heads[i].children.length > 2) continue;
        var s2 = heads[i].nextElementSibling, body = '';
        while (s2 && !body) { var bt = blockText(s2); if (bt.length >= 40) body = bt; s2 = s2.nextElementSibling; }
        if (body) { put('summary', body, 'label'); break; }
      }
    }
  })();

  (function () {
    var h = q1('h1'); if (h) put('title', clean(h.textContent), 'h1');
    put('title', trimSite(document.title || ''), 'title');
    put('language', normLang(document.documentElement.getAttribute('lang') || document.documentElement.getAttribute('xml:lang') || ''), 'html');
  })();

  var canon = q1('link[rel="canonical"]');
  out.sourceUrl = abs((canon && canon.getAttribute('href')) || meta1('property', 'og:url') || location.href);
  out.sourceSite = siteName || (location.hostname || '').replace(/^www\./, '');
  src.sourceUrl = 'page';
  if (out.cover) { out.coverUrl = out.cover; src.coverUrl = src.cover; delete out.cover; delete src.cover; }
  if (out.summary && out.summary.length > 8000) out.summary = out.summary.slice(0, 8000);
  ['genres', 'tags', 'altTitles'].forEach(function (k) { if (out[k] && out[k].length > 60) out[k] = out[k].slice(0, 60); });
  if (out.summary) out.summaryHtml = out.summary.split('\n').map(function (l) { return '<p>' + l.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</p>'; }).join('');
  return JSON.stringify({ meta: out, sources: src });
}
"""
STORY_META_SCHEMA = 1
STORY_COVER_MAX_BYTES = 6 * 1024 * 1024


def story_selectors_from_job(job):
    """selector theo trường: các trường cũ bookTitleSelector/bookCoverSelector/authorSelector (chưa từng được dùng) + storyMetaSelectors (dict tuỳ ý; khoá lạ => `extra`)."""
    sel = {}
    for key, legacy in (("title", "bookTitleSelector"), ("coverUrl", "bookCoverSelector"), ("author", "authorSelector")):
        v = (job.get(legacy) or "").strip()
        if v:
            sel["cover" if key == "coverUrl" else key] = v
    raw = job.get("storyMetaSelectors")
    if isinstance(raw, dict):
        for k, v in raw.items():
            if isinstance(k, str) and isinstance(v, str) and k.strip() and v.strip():
                k = k.strip()
                sel["cover" if k == "coverUrl" else k] = v.strip()
    return sel


def _story_empty(v):
    return v is None or v == "" or v == [] or v == {}


def merge_story_meta(prev, fresh, manual):
    """kết quả = lần trước (lấp chỗ trống khi trang lần này không có) <- mới trích được <- người dùng nhập tay (thắng tất cả). `sources` ghi nguồn của từng trường."""
    out = {k: v for k, v in (prev or {}).items() if not _story_empty(v)}
    srcs = dict(out.get("sources") or {})
    fresh = dict(fresh or {})
    fresh_src = fresh.pop("sources", {}) or {}
    for k, v in fresh.items():
        if _story_empty(v):
            continue
        if k == "extra" and isinstance(v, dict):
            ex = dict(out.get("extra") or {})
            ex.update({a: b for a, b in v.items() if not _story_empty(b)})
            out["extra"] = ex
            continue
        out[k] = v
        if k in fresh_src:
            srcs[k] = fresh_src[k]
    for k, v in (manual or {}).items():
        if k in ("sources", "fetchedAt", "schema") or _story_empty(v):
            continue
        out[k] = v
        srcs[k] = "manual"
    if srcs:
        out["sources"] = srcs
    return out


def fetch_story_cover(context, cover_url, referer, images_dir, prev_meta):
    """Tải ảnh bìa về `<images_dir>/cover.<ext>`. Trả {"coverFile","coverMime"} hoặc {} nếu không tải được. Giữ nguyên bản cũ nếu URL không đổi và file còn."""
    prev_meta = prev_meta or {}
    prev_file = prev_meta.get("coverFile") or ""
    if prev_file and prev_meta.get("coverUrl") == cover_url and os.path.exists(os.path.join(images_dir, prev_file)):
        return {"coverFile": prev_file, "coverMime": prev_meta.get("coverMime") or "image/jpeg"}
    try:
        resp = context.request.get(cover_url, timeout=20_000, headers={"Referer": referer} if referer else None)
    except Exception as e:
        print(f"[Story] Khong tai duoc anh bia {cover_url}: {e}", flush=True)
        return {}
    if not resp.ok:
        print(f"[Story] Anh bia tra ve HTTP {resp.status}: {cover_url}", flush=True)
        return {}
    mime = (resp.headers.get("content-type", "") or "").split(";")[0].strip().lower()
    body = resp.body()
    if not mime.startswith("image/") or not body:
        print(f"[Story] Anh bia khong phai anh ({mime or 'khong ro'}): {cover_url}", flush=True)
        return {}
    if len(body) > STORY_COVER_MAX_BYTES:
        print(f"[Story] Anh bia qua lon ({len(body)} byte) - bo qua", flush=True)
        return {}
    ext = guess_extension(mime, cover_url)
    os.makedirs(images_dir, exist_ok=True)
    for old in os.listdir(images_dir):
        if old.startswith("cover."):
            try:
                os.remove(os.path.join(images_dir, old))
            except OSError:
                pass
    name = f"cover.{ext}"
    with open(os.path.join(images_dir, name), "wb") as f:
        f.write(body)
    return {"coverFile": name, "coverMime": mime}


def collect_story_meta(context, job, images_dir, prev_meta):
    """Mở trang thông tin truyện (`storyInfoUrl`, mặc định trang danh sách chương), chạy STORY_META_JS, gộp với lần trước + nhập tay, tải bìa. Lỗi => trả lại bản cũ (không làm hỏng lần cào)."""
    prev_meta = prev_meta or {}
    manual = job.get("storyMetaManual") if isinstance(job.get("storyMetaManual"), dict) else {}
    if not job.get("storyMetaEnabled", True):
        return merge_story_meta(prev_meta, {}, manual) if manual else dict(prev_meta)
    url = (job.get("storyInfoUrl") or "").strip() or job.get("listPageUrl", "")
    fresh = {}
    page = None
    try:
        page = context.new_page()
        html, still_blocked = goto_with_cloudflare_retry(page, url, job=job)
        if still_blocked:
            print("[Story] Trang thong tin truyen bi chan - giu thong tin cu", flush=True)
        else:
            try:
                page.wait_for_timeout(int(job.get("storyMetaWaitMs", 1200)))
            except Exception:
                pass
            raw = page.evaluate("(" + STORY_META_JS + ")", {"selectors": story_selectors_from_job(job)})
            data = json.loads(raw)
            fresh = data.get("meta") or {}
            fresh["sources"] = data.get("sources") or {}
            print(f"[Story] Trich duoc thong tin truyen: {', '.join(k for k in fresh if k != 'sources') or '(khong co gi)'}", flush=True)
    except Exception as e:
        print(f"[Story] Loi khi lay thong tin truyen ({e}) - giu thong tin cu", flush=True)
    finally:
        if page is not None:
            try:
                page.close()
            except Exception:
                pass
    meta = merge_story_meta(prev_meta, fresh, manual)
    if meta.get("coverUrl"):
        meta.update(fetch_story_cover(context, meta["coverUrl"], url, images_dir, prev_meta))
    meta["schema"] = STORY_META_SCHEMA
    meta["fetchedAt"] = int(time.time() * 1000)
    return meta
# <<STORY_META END>>


# ──────────────────────────────────────────────────────────────────
# Bản 7.104 — QUÉT NHANH DANH SÁCH THEO ĐIỂM NEO (ListScanPlanner)
# Khối này GIỐNG HỆT bản trong ld/incremental.py (LeechDesk) và ListScanPlanner.kt (app) — sửa một nơi phải sửa cả ba (có test so khớp chéo).
#
# Ý tưởng: lần quét trước đã lưu danh sách chương theo thứ tự (kho `known`) và số trang cuối (`hint_last_page`). Chương mới chỉ xuất hiện ở HAI MÉP danh sách:
#  • ĐẦU danh sách (trang mới nhất đứng đầu — kiểu KDN/blog) => đọc từ trang 1 tới trang chứa chương đầu tiên của kho;
#  • CUỐI danh sách (danh sách cũ→mới, chương mới nối vào trang cuối) => nhảy tới trang cuối của lần trước (lùi 1 trang làm đệm).
# Phần giữa (các trang toàn chương đã có) KHÔNG đọc lại — nhưng chương trong đó vẫn được giữ đúng thứ tự cũ từ kho. Mọi giả định không khớp (không thấy chương đầu kho,
# trang nhảy tới không chứa chương nào đã biết, thứ tự đảo lộn, trang trống/bị chặn) => tự lùi về quét tuần tự đầy đủ như trước. Không dùng cho nhiều nguồn (preListStages).
FAST_SCAN_MAX_STREAK = 10  # sau chừng đó lần quét nhanh liên tiếp, lần kế tiếp quét ĐẦY ĐỦ (bắt chương chèn/đổi tên ở giữa)


class ListScanPlanner:
    """Bộ lập kế hoạch quét trang danh sách. Dùng: `while (p := pl.next_page()) is not None: pl.on_page(p, fetch(p))` rồi `pl.result()`.
    `fetch(p)` trả list URL chương (rỗng nếu trang không tồn tại/không có chương) hoặc None nếu bị chặn/lỗi."""

    def __init__(self, max_pages, known_order=None, hint_last_page=0, fast=False):
        self.max_pages = max(1, int(max_pages))
        self.known = []
        self.pos = {}
        for u in known_order or []:
            if u and u not in self.pos:
                self.pos[u] = len(self.known)
                self.known.append(u)
        try:
            self.hint = int(hint_last_page or 0)
        except (TypeError, ValueError):
            self.hint = 0
        self.fast = bool(fast and self.known and self.hint >= 1)
        self.phase = "TOP"      # TOP -> (PROBE ->) BOTTOM
        self.page = 1
        self.probe = 0
        self.probe_steps = 0
        self.top_end = 0
        self.skipped_pages = 0
        self.scanned = []
        self.scanned_set = set()
        self.top = []
        self.bottom = []
        self.loaded = 0
        self.last_page = 0
        self.done = False
        self.blocked = False
        self.blocked_phase = ""
        self.fell_back = False

    def next_page(self):
        if self.done:
            return None
        return self.probe if self.phase == "PROBE" else self.page

    def _add(self, links, p, bucket):
        new = []
        for u in links:
            if u not in self.scanned_set:
                self.scanned.append(u)
                self.scanned_set.add(u)
                new.append(u)
        bucket.extend(new)
        if new:
            self.last_page = max(self.last_page, p)   # trang cuối CÓ chương mới (site trả lại trang cuối cho trang quá cuối không làm "dài" danh sách)
        return new

    def on_page(self, p, links):
        self.loaded += 1
        if links is None:
            self.blocked = True
            self.blocked_phase = self.phase
            self.done = True
            return
        links = [u for u in links if u]
        if self.phase == "PROBE":
            self._on_probe(p, links)
            return
        new = self._add(links, p, self.top if self.phase == "TOP" else self.bottom)
        if not new:
            self.done = True          # trang không còn link mới => hết danh sách (đúng luật cũ)
            return
        if p >= self.max_pages:
            self.done = True
            return
        if self.phase == "TOP" and self.fast:
            if self.known[0] in links:
                self.top_end = p
                start = max(p + 1, min(self.hint - 1, self.max_pages))
                if start <= p + 1:
                    self.phase = "BOTTOM"
                    self.page = p + 1
                else:
                    self.phase = "PROBE"
                    self.probe = start
                    self.probe_steps = 0
                return
            if p + 1 >= self.hint - 1:
                # đã đọc tới vùng cuối của lần trước mà vẫn chưa thấy chương đầu kho => giả định sai, quét đầy đủ
                self.fast = False
                self.fell_back = True
        self.page = p + 1

    def _on_probe(self, p, links):
        if any(u in self.pos for u in links):
            self.skipped_pages = p - self.top_end - 1
            self._add(links, p, self.bottom)
            self.phase = "BOTTOM"
            self.page = p + 1
            if p >= self.max_pages:
                self.done = True
            return
        # trang trống / toàn chương lạ => lùi (tối đa 3 lần), không neo được thì quét tuần tự từ sau phần đầu
        self.probe_steps += 1
        nxt = p - 1
        if nxt <= self.top_end or self.probe_steps > 3:
            self.phase = "BOTTOM"
            self.page = self.top_end + 1
            self.fell_back = True
        else:
            self.probe = nxt

    def _kept(self, after_pos):
        return [u for u in self.known[after_pos + 1:] if u not in self.scanned_set]

    def result(self):
        """-> (links, meta, inconsistent). inconsistent=True: kết quả nhanh không đáng tin, người gọi phải quét lại ĐẦY ĐỦ (bộ lập kế hoạch mới với fast=False)."""
        skipped = self.fast and self.skipped_pages > 0
        meta = {"mode": "fast" if skipped else "full", "lastPage": self.last_page,
                "pagesLoaded": self.loaded, "pagesSkipped": self.skipped_pages if skipped else 0}
        if self.blocked and self.known:
            # trang danh sách bị chặn giữa chừng (cả khi quét đầy đủ): GIỮ phần kho chưa quét thay vì để mất khỏi ebook
            top_pos = [self.pos[u] for u in self.top if u in self.pos]
            bot_pos = [self.pos[u] for u in self.bottom if u in self.pos]
            lo = max(top_pos) if top_pos else -1
            if bot_pos and min(bot_pos) > lo:
                middle = [u for u in self.known[lo + 1:min(bot_pos)] if u not in self.scanned_set]
                tail = self._kept(max(bot_pos))
            else:
                middle = self._kept(lo)
                tail = []
            meta["mode"] = "fast" if self.fast else "full"
            meta["blocked"] = True
            return self._dedupe(self.top + middle + self.bottom + tail), meta, False
        if not skipped:
            return list(self.scanned), meta, False
        top_pos = [self.pos[u] for u in self.top if u in self.pos]
        bot_pos = [self.pos[u] for u in self.bottom if u in self.pos]
        if not top_pos or not bot_pos:
            return [], meta, True
        lo, hi = max(top_pos), min(bot_pos)
        if hi <= lo:
            return [], meta, True
        middle = [u for u in self.known[lo + 1:hi] if u not in self.scanned_set]
        return self._dedupe(self.top + middle + self.bottom), meta, False

    @staticmethod
    def _dedupe(seq):
        seen, out = set(), []
        for u in seq:
            if u not in seen:
                seen.add(u)
                out.append(u)
        return out


def run_list_scan(fetch, max_pages, known_order=None, hint_last_page=0, fast=False, sleep=None, delay_s=0.0, log=None):
    """Chạy trọn một lần quét với `fetch(p)`; tự quét lại ĐẦY ĐỦ nếu kết quả nhanh không nhất quán. -> (links, meta)."""
    for attempt_fast in ((True, False) if fast else (False,)):
        pl = ListScanPlanner(max_pages, known_order, hint_last_page, attempt_fast)
        first = True
        while True:
            p = pl.next_page()
            if p is None:
                break
            if not first and sleep and delay_s:
                sleep(delay_s)
            first = False
            pl.on_page(p, fetch(p))
        links, meta, bad = pl.result()
        if not bad:
            if log and meta.get("mode") == "fast":
                log(f"[Phase1] Quét nhanh: đọc {meta['pagesLoaded']} trang, bỏ qua {meta['pagesSkipped']} trang giữa danh sách (giữ nguyên thứ tự từ kho)")
            return links, meta
        if log:
            log("[Phase1] Quét nhanh cho kết quả không nhất quán với kho — quét lại ĐẦY ĐỦ danh sách")
    return links, meta


# Kết quả quét danh sách gần nhất (chế độ, trang cuối, số trang đã đọc/bỏ qua) — main() ghi vào checkpoint để làm điểm neo cho lần sau.
LAST_LIST_SCAN_META = {}


# ─────────────────────────────────────────────────────────────────────
# Phase 1 — thu thập link chương (BeautifulSoup parse HTML đã render đầy
# đủ từ Playwright — vẫn cần bs4/lxml để áp CSS selector, không tự viết
# lại selector engine)
# ─────────────────────────────────────────────────────────────────────
def collect_chapter_links_html(context, job, base_url=None, page=None, scan=None):
    links = []
    LAST_LIST_SCAN_META.clear()
    pattern = job.get("listPageUrlPattern", "") or job.get("resolvedPaginationPattern", "")
    base_url = base_url if base_url is not None else job.get("listPageUrl", "")
    max_pages = job.get("maxPages", 50)
    selector = job["chapterLinkSelector"]
    attr = job.get("chapterLinkAttribute", "href")
    # ĐÃ SỬA — nhận `page` có sẵn (tái dùng qua nhiều entry khi có
    # preListStages, tránh mở/đóng tab liên tục) — tự tạo mới nếu không
    # truyền vào (giữ nguyên hành vi cũ cho trường hợp 1 nguồn duy nhất).
    owns_page = page is None
    if page is None:
        page = context.new_page()
    start_page = 1

    if scan and pattern:
        # Bản 7.104: quét nhanh theo điểm neo (ListScanPlanner) — chỉ đọc ĐẦU + CUỐI danh sách, phần giữa lấy từ kho. Chỉ khi đã có sẵn mẫu phân trang (không cần dò) và 1 nguồn.
        def fetch_html(pg):
            url = pattern.replace("{base}", base_url.rstrip("/")).replace("{page}", str(pg))
            print(f"[Phase1] Trang {pg}: {url}", flush=True)
            html, still_blocked = goto_with_cloudflare_retry(page, url, job=job, wait_selector=selector)
            if still_blocked:
                print(f"[Phase1] Trang {pg} bị chặn dai dẳng — dừng thu thập ở đây (giữ phần đã có trong kho)", flush=True)
                return None
            out = []
            for el in BeautifulSoup(html, "lxml").select(selector):
                href = (el.get(attr) or "").strip()
                if href:
                    out.append(urljoin(url, href))
            if pg == 1 and not out and scan["known"]:
                # trang 1 rỗng trong khi kho có chương = nhiều khả năng bị chặn/đổi giao diện => coi như bị chặn, GIỮ danh sách cũ (không để cả danh sách "biến mất") — giống app + LeechDesk
                print(f"[Phase1] Trang 1 rong du kho co {len(scan['known'])} chuong - coi nhu bi chan, giu danh sach cu", flush=True)
                return None
            return out
        fast_links, meta = run_list_scan(fetch_html, max_pages, scan["known"], scan["hint"], bool(scan.get("fast")), sleep=time.sleep,
                                         delay_s=job.get("delayBetweenPagesMs", 1500) / 1000.0, log=lambda m: print(m, flush=True))
        LAST_LIST_SCAN_META.update(meta)
        if owns_page:
            page.close()
        return fast_links

    # Chỉ tự dò khi CHƯA có pattern nào (khớp điều kiện needsDetection bản
    # Kotlin gốc: autoDetectPagination && listPageUrlPattern rỗng && resolvedPaginationPattern rỗng).
    if not pattern and job.get("autoDetectPagination", False):
        print("[Phase0] Dang tu do cach phan trang...", flush=True)
        html1, blocked1 = goto_with_cloudflare_retry(page, base_url, job=job, wait_selector=selector)
        if blocked1:
            print("[Phase0] Trang goc bi chan - bo qua tu do phan trang, coi nhu chi co 1 trang", flush=True)
        else:
            soup1 = BeautifulSoup(html1, "lxml")
            for el in soup1.select(selector):
                href = (el.get(attr) or "").strip()
                if href:
                    absolute = urljoin(base_url, href)
                    if absolute not in links:
                        links.append(absolute)
            detected = auto_detect_pagination(page, job, base_url, links)
            if detected:
                pattern = detected
            start_page = 2  # trang 1 đã xử lý xong ở bước dò, khỏi tải lại

    last_p = 0
    for p in range(start_page, max_pages + 1):
        if pattern:
            # .replace("{base}", ...) an toàn cho CẢ pattern thủ công (không
            # chứa "{base}", replace no-op) LẪN pattern tự dò (chứa "{base}").
            url = pattern.replace("{base}", base_url.rstrip("/")).replace("{page}", str(p))
        elif p == 1:
            url = base_url
        else:
            break

        print(f"[Phase1] Trang {p}: {url}", flush=True)
        html, still_blocked = goto_with_cloudflare_retry(page, url, job=job, wait_selector=selector)
        if still_blocked:
            print(f"[Phase1] Trang {p} bị chặn dai dẳng — dừng thu thập ở đây (không dừng cả job vì chưa có chương nào cào, không có gì để mất)", flush=True)
            break

        soup = BeautifulSoup(html, "lxml")
        found_new = False
        for el in soup.select(selector):
            href = (el.get(attr) or "").strip()
            if not href:
                continue
            absolute = urljoin(url, href)
            if absolute not in links:
                links.append(absolute)
                found_new = True
        if not found_new:
            break
        last_p = p
        time.sleep(job.get("delayBetweenPagesMs", 1500) / 1000.0)

    LAST_LIST_SCAN_META.update({"mode": "full", "lastPage": last_p or (1 if links else 0), "pagesLoaded": last_p})
    if owns_page:
        page.close()
    return links


# ─────────────────────────────────────────────────────────────────────
# Phase -1 — ĐÃ THÊM: port preListStages (kịch bản nhiều bước tuỳ biến)
# từ EbookLeechCrawler.phaseNeg1TraverseStages(). Duyệt qua từng "tầng"
# stage kiểu BFS: bắt đầu với frontier = [listPageUrl], mỗi stage lấy hết
# link (theo linkSelector/linkAttribute, giới hạn maxLinksPerPage nếu có)
# từ MỌI url trong frontier hiện tại, gộp thành frontier MỚI cho stage kế
# tiếp. Hết stage → frontier cuối (distinct) chính là danh sách
# "listPageEntries" — MỖI URL trong đó chạy Phase 0/1/2 như 1 nguồn riêng.
#
# KHÁC 1 CHÚT so với bản Kotlin gốc (đã cân nhắc, chấp nhận được): bản
# Kotlin CÓ THỂ xen kẽ Phase1/Phase2 giữa các entry (thu link chương của
# entry này xong là cào nội dung entry đó luôn, rồi mới sang entry kế) —
# bản Python này THU THẬP HẾT link chương của TẤT CẢ entry trước, rồi mới
# cào nội dung TẤT CẢ 1 lần — ebook CUỐI CÙNG giống hệt nhau (đủ chương,
# đủ nội dung), chỉ khác thứ tự xử lý nội bộ, đơn giản hoá code hợp lý.
# ─────────────────────────────────────────────────────────────────────
def traverse_pre_list_stages(page, job):
    stages = job.get("preListStages", [])
    frontier = [job.get("listPageUrl", "")]
    for stage_idx, stage in enumerate(stages):
        label = stage.get("label", f"Buoc {stage_idx + 1}")
        selector = stage["linkSelector"]
        attr = stage.get("linkAttribute", "href")
        max_links = stage.get("maxLinksPerPage", 0)
        print(f"[Phase-1] Buoc {stage_idx + 1}/{len(stages)}: {label} ({len(frontier)} trang nguon)", flush=True)
        next_frontier = []
        for url in frontier:
            html, still_blocked = goto_with_cloudflare_retry(page, url, job=job, wait_selector=selector)
            if still_blocked:
                print(f"[Phase-1] {url} bi chan - bo qua URL nay trong buoc, tiep tuc URL khac", flush=True)
                continue
            soup = BeautifulSoup(html, "lxml")
            links = []
            for el in soup.select(selector):
                href = (el.get(attr) or "").strip()
                if href:
                    links.append(urljoin(url, href))
            if max_links > 0:
                links = links[:max_links]
            next_frontier.extend(links)
            time.sleep(job.get("delayBetweenPagesMs", 1500) / 1000.0)
        frontier = next_frontier
    seen = set()
    result = []
    for u in frontier:
        if u not in seen:
            seen.add(u)
            result.append(u)
    return result


def collect_chapter_links_ajax(context, job, base_url=None, scan=None):
    links = []
    LAST_LIST_SCAN_META.clear()
    template = job.get("ajaxListUrlTemplate", "")
    items_path = job.get("ajaxListItemsPath", "")
    url_field = job.get("ajaxListUrlField", "url")
    max_pages = job.get("maxPages", 50)
    base_url = base_url if base_url is not None else job.get("listPageUrl", "")

    if scan:
        # Bản 7.104: quét nhanh theo điểm neo cho danh sách AJAX (ListScanPlanner).
        def fetch_ajax(pg):
            api_url = template.replace("{page}", str(pg)).replace("{base}", base_url.rstrip("/"))
            print(f"[Phase1-AJAX] Trang {pg}: {api_url}", flush=True)
            try:
                resp = context.request.get(api_url, timeout=PAGE_TIMEOUT_MS)
                data = resp.json() if resp.ok else None
            except Exception as e:
                print(f"[Phase1-AJAX] Loi tai API trang {pg}: {e} - dung o day", flush=True)
                return None
            if data is None:
                print(f"[Phase1-AJAX] Trang {pg} khong phai JSON hop le - dung o day", flush=True)
                return None
            items = json_path_resolve(data, items_path) if items_path else data
            if not isinstance(items, list):
                print(f"[Phase1-AJAX] Khong tim thay mang chuong tai path \"{items_path}\" - dung o day", flush=True)
                return None
            out = []
            for item in items:
                raw_url = json_path_str(item, url_field)
                if raw_url:
                    out.append(urljoin(api_url, raw_url))
            if pg == 1 and not out and scan["known"]:
                print(f"[Phase1-AJAX] Trang 1 rong du kho co {len(scan['known'])} chuong - coi nhu bi chan, giu danh sach cu", flush=True)
                return None
            return out
        fast_links, meta = run_list_scan(fetch_ajax, max_pages, scan["known"], scan["hint"], bool(scan.get("fast")), sleep=time.sleep,
                                         delay_s=job.get("delayBetweenPagesMs", 1500) / 1000.0, log=lambda m: print(m, flush=True))
        LAST_LIST_SCAN_META.update(meta)
        return fast_links

    last_p = 0
    for p in range(1, max_pages + 1):
        api_url = template.replace("{page}", str(p)).replace("{base}", base_url.rstrip("/"))
        print(f"[Phase1-AJAX] Trang {p}: {api_url}", flush=True)
        try:
            resp = context.request.get(api_url, timeout=PAGE_TIMEOUT_MS)
            data = resp.json() if resp.ok else None
        except Exception as e:
            print(f"[Phase1-AJAX] Loi tai API trang {p}: {e} - dung o day", flush=True)
            break
        if data is None:
            print(f"[Phase1-AJAX] Trang {p} khong phai JSON hop le - dung o day", flush=True)
            break

        items = json_path_resolve(data, items_path) if items_path else data
        if not isinstance(items, list):
            print(f"[Phase1-AJAX] Khong tim thay mang chuong tai path \"{items_path}\" - dung o day", flush=True)
            break

        found_new = False
        for item in items:
            raw_url = json_path_str(item, url_field)
            if not raw_url:
                continue
            absolute = urljoin(api_url, raw_url)
            if absolute not in links:
                links.append(absolute)
                found_new = True
        if not found_new:
            break
        last_p = p
        time.sleep(job.get("delayBetweenPagesMs", 1500) / 1000.0)

    LAST_LIST_SCAN_META.update({"mode": "full", "lastPage": last_p or (1 if links else 0), "pagesLoaded": last_p})
    return links


# ─────────────────────────────────────────────────────────────────────
# Phase 2 — cào nội dung từng chương
# ─────────────────────────────────────────────────────────────────────
class BlockedNeedsManualReview(Exception):
    """Báo hiệu ĐẶC BIỆT — khác lỗi 1 chương thường (mạng lỗi, không tìm
    thấy selector...) — nghĩa là trang có vẻ chặn THẬT SỰ (không phải JS
    challenge tự động, đã thử lại CLOUDFLARE_MAX_RETRIES lần vẫn vậy).
    `main()` bắt exception này để TẠM DỪNG CẢ JOB (không chỉ bỏ qua 1
    chương) — chụp màn hình, commit, dừng hẳn, chờ người dùng xem lại."""
    def __init__(self, url):
        self.url = url
        super().__init__(f"Trang bị chặn dai dẳng: {url}")


def _read_chapter_page(page, job, url):
    """Mở MỘT trang chương, đọc (tiêu đề, html, text, link "trang kế"). Trả (kết quả, lỗi). Bị chặn dai dẳng => BlockedNeedsManualReview."""
    html, still_blocked = goto_with_cloudflare_retry(
        page, url, job=job, wait_selector=job["chapterContentSelector"],
        lazy_scroll=bool(job.get("simulateScrollForLazyLoad", False)),
    )
    if still_blocked:
        raise BlockedNeedsManualReview(url)
    soup = BeautifulSoup(html, "lxml")

    title_el = soup.select_one(job["chapterTitleSelector"])
    content_el = soup.select_one(job["chapterContentSelector"])
    if content_el is None:
        return None, f"Khong tim thay noi dung voi selector \"{job['chapterContentSelector']}\""

    title = title_el.get_text(strip=True) if title_el else ""
    content_html = str(content_el)
    content_text = content_el.get_text("\n", strip=True)
    next_url = ""
    sel = (job.get("chapterNextPageSelector") or "").strip()
    if sel:
        try:
            nel = soup.select_one(sel)
        except Exception:
            nel = None
        href = ((nel.get("href") if nel is not None else "") or "").strip()
        if href and not href.lower().startswith(("javascript:", "#")):
            next_url = urljoin(getattr(page, "url", None) or url, href)
    return (title, content_html, content_text, next_url), None


def crawl_one_chapter_html(page, job, url, chapter_links=None):
    """Bản 7.103: chương chia nhiều trang (`chapterNextPageSelector`, y hệt `gatherChapterPages` phía điện thoại): sau trang 1 lần lượt mở link "trang kế" và NỐI nội dung vào cùng
    một chương (tiêu đề lấy ở trang 1). Dừng khi: không còn link / đủ `maxChapterPages` / link đã đi qua (vòng lặp) / link là một CHƯƠNG khác trong danh sách (nhiều site dùng chung
    nút "Tiếp" cho cả trang kế lẫn chương kế). Trang >= 2 bị chặn => BlockedNeedsManualReview như cũ; trang >= 2 lỗi => giữ phần đã lấy + ghi chú trong nội dung."""
    first, err = _read_chapter_page(page, job, url)
    if err:
        return None, err
    title, html, text, nxt = first
    if not (job.get("chapterNextPageSelector") or "").strip():
        return (title, html, text), None
    max_pages = max(1, int(job.get("maxChapterPages", 10) or 10))
    others = set(chapter_links or [])
    visited = {url}
    page_no = 1
    while True:
        is_other_chapter = bool(nxt) and nxt != url and nxt in others
        if not nxt or page_no >= max_pages or is_other_chapter or nxt in visited:
            break
        visited.add(nxt)
        print(f"    ...trang {page_no + 1} cua chuong hien tai: {nxt}", flush=True)
        time.sleep(job.get("delayBetweenPagesMs", 1500) / 1000.0)
        try:
            more, err2 = _read_chapter_page(page, job, nxt)
        except BlockedNeedsManualReview:
            raise
        except Exception as e:
            more, err2 = None, f"{e}"
        if err2:
            note = f"[Khong lay duoc trang {page_no + 1} cua chuong: {err2}]"
            html += f"\n<p>{note}</p>"
            text += f"\n\n{note}"
            break
        html += "\n" + more[1]
        text += "\n\n" + more[2]
        nxt = more[3]
        page_no += 1
    return (title, html, text), None


def skip_reason(job, raw_text, processed_text):
    """Bản 7.103: lý do BỎ QUA chương (None = giữ) — y hệt `EbookLeechCrawler.skipReason` phía điện thoại. Cụm cấm kiểm trên text THÔ (trước luật tìm & thay, vì luật có thể xoá đúng cụm đó),
    độ dài kiểm SAU luật. Chương bị bỏ qua không vào ebook, không tốn số thứ tự, không nằm trong kho (lần sau site mở khoá vẫn thử lại)."""
    low = (raw_text or "").lower()
    for ph in job.get("skipIfTextContains") or []:
        p = (ph or "").strip()
        if p and p.lower() in low:
            return f'chua cum "{p}"'
    try:
        min_len = int(job.get("minTextLength", 0) or 0)
    except (TypeError, ValueError):
        min_len = 0
    n = len((processed_text or "").strip())
    if min_len > 0 and n < min_len:
        return f"noi dung qua ngan ({n} < {min_len} ky tu)"
    return None


def crawl_one_chapter_ajax(context, job, url):
    try:
        resp = context.request.get(url, timeout=PAGE_TIMEOUT_MS)
        data = resp.json() if resp.ok else None
    except Exception as e:
        return None, f"Loi mang: {e}"
    if data is None:
        return None, "Khong parse duoc JSON"
    title = json_path_str(data, job.get("ajaxContentTitleField", "title")) or ""
    content_raw = json_path_str(data, job.get("ajaxContentField", "content")) or ""
    if not content_raw:
        return None, f"Khong tim thay noi dung tai path \"{job.get('ajaxContentField', 'content')}\""
    return (title, content_raw, strip_tags_rough(content_raw)), None


# ─────────────────────────────────────────────────────────────────────
# Checkpoint — ĐÚNG schema CrawlCheckpoint.toJson()/LeechChapter.toJson()
# phía Kotlin.
# ─────────────────────────────────────────────────────────────────────
def chapter_to_json(index, title, html, text, source_url, images):
    return {
        "index": index, "title": title, "htmlContent": html, "textContent": text,
        "sourceUrl": source_url, "images": images,
    }


def next_chapter_number(chapters_so_far):
    """Số thứ tự chương kế tiếp = max(index đang có) + 1 (checkpoint rỗng => 1). Đảm bảo `index` duy nhất, xem chú thích ở vòng Phase 2."""
    best = 0
    for c in chapters_so_far:
        try:
            best = max(best, int(c.get("index", 0)))
        except (TypeError, ValueError):
            pass
    return best + 1


def max_chapter_index(chapters):
    """Chỉ số `index` lớn nhất trong danh sách chương (0 nếu rỗng); phần tử hỏng bị bỏ qua."""
    best = 0
    for c in chapters:
        try:
            best = max(best, int(c.get("index", 0)))
        except (TypeError, ValueError, AttributeError):
            pass
    return best


def is_reusable_chapter(ch):
    """Y hệt `ChapterArchiveRepository.isReusable` phía Kotlin (cộng thêm dạng KHÔNG DẤU mà chính crawler.py ghi cho chương lỗi): chương lỗi/bị chặn KHÔNG dùng lại."""
    try:
        title = ch.get("title", "") or ""
        text = ch.get("textContent", "") or ""
        if not ch.get("sourceUrl"):
            return False
        return not (
            "[loi]" in title or "[lỗi]" in title or "[BỊ CHẶN" in title
            or text.startswith("[Khong lay duoc") or text.startswith("[Không lấy được nội dung") or text.startswith("[Bị chặn")
        )
    except AttributeError:
        return False


def build_archive(chapters):
    """Danh sách chương đã cào xong lần trước => dict {sourceUrl: chương} (chỉ chương dùng lại được; URL trùng thì giữ bản đầu).
    Bản 7.103: nhận cả MẢNG chương lẫn nguyên một checkpoint (dict có `chaptersSoFar`) — app đẩy nguyên checkpoint xong của lần trước lên `-archive.json` mà không phải tách."""
    if isinstance(chapters, dict):
        chapters = chapters.get("chaptersSoFar", [])
    if not isinstance(chapters, (list, tuple)):          # kho hỏng (số, chuỗi...) => coi như rỗng, không làm hỏng cả lần chạy
        chapters = []
    out = {}
    for ch in chapters:
        if is_reusable_chapter(ch) and ch["sourceUrl"] not in out:
            out[ch["sourceUrl"]] = ch
    return out


def parse_archive_data(data):
    """Nội dung `-archive.json` => (kho {url: chương}, thứ tự danh sách lần trước [url], meta quét danh sách {lastPage, fastStreak, ...}, thông tin truyện lần trước `storyMeta`).
    Dạng MẢNG chương (bản 7.102/7.103 cũ): thứ tự = thứ tự các chương trong kho, không có meta (=> lần này quét đầy đủ). Dạng nguyên checkpoint xong (dict): `chapterLinks` là thứ tự ĐẦY ĐỦ
    của danh sách lần trước (kể cả chương từng bị bỏ qua/lỗi => lần này vẫn thử lại), `listScan` là điểm neo (trang cuối...) do chính runner ghi lần trước."""
    archive = build_archive(data)
    known, meta, story = [], {}, {}
    if isinstance(data, dict):
        known = [u for u in (data.get("chapterLinks") or []) if isinstance(u, str) and u]
        m = data.get("listScan")
        meta = m if isinstance(m, dict) else {}
        sm = data.get("storyMeta")
        story = sm if isinstance(sm, dict) else {}
    if not known:
        known = list(archive.keys())
    return archive, known, meta, story


def take_over_chapter(cached, used_indexes, index_high):
    """Lấy một chương đã cào ở lần trước để đưa vào danh sách lần này: GIỮ `index` cũ (ảnh `img_<index>_<n>` của nó giữ nguyên tên file), trừ khi index đó hỏng/đã bị chương khác chiếm
    (kho do công cụ khác tạo) thì cấp số mới. Trả (chương, index_high mới); `used_indexes` được cập nhật tại chỗ."""
    ch = dict(cached)
    try:
        idx = int(ch.get("index"))
    except (TypeError, ValueError):
        idx = None
    if idx is None or idx in used_indexes:
        index_high += 1
        idx = index_high
        ch["index"] = idx
    used_indexes.add(idx)
    return ch, index_high


def build_checkpoint_json(job_id, phase, chapter_links, progress_index, chapters_so_far,
                           blocked_count, remote_done, stats=None):
    cp = {
        "jobId": job_id, "phase": phase,
        "listPageEntries": [], "listPageEntryIndex": 0,
        "chapterLinks": chapter_links, "chapterProgressIndex": progress_index,
        "chaptersSoFar": chapters_so_far, "blockedChapterCount": blocked_count,
        "pausedAtIndex": -1, "savedAt": int(time.time() * 1000),
        "remoteDone": remote_done,
        "runnerVersion": RUNNER_VERSION,
    }
    if stats:
        cp.update(stats)  # reusedCount / crawledCount — app phía Kotlin bỏ qua trường lạ
    return cp


_GIT_LOCK = threading.Lock()  # ĐÃ THÊM — tránh 2 thread (vòng cào chính +
# heartbeat) cùng git add/commit lúc chạm nhau, dễ gây lỗi/mất file giữa
# 2 lần commit chồng chéo.


def git_commit_push(repo_dir, message):
    with _GIT_LOCK:
        subprocess.run(["git", "-C", repo_dir, "add", "-A"], check=True)
        result = subprocess.run(["git", "-C", repo_dir, "diff", "--cached", "--quiet"])
        if result.returncode == 0:
            return
        subprocess.run(["git", "-C", repo_dir, "commit", "-m", message], check=True)
        for attempt in range(3):
            subprocess.run(["git", "-C", repo_dir, "pull", "--rebase", "--autostash"])
            push = subprocess.run(["git", "-C", repo_dir, "push"])
            if push.returncode == 0:
                return
            print(f"[git] Push lan {attempt + 1} that bai, thu lai...", flush=True)
            time.sleep(3)
        print("[git] Push that bai sau 3 lan thu - checkpoint LAN NAY khong len duoc repo, lan commit SAU se mang theo du du lieu (khong mat, chi tre).", flush=True)


class HeartbeatThread(threading.Thread):
    """
    ĐÃ THÊM — trả lời thẳng câu hỏi "sao không làm cho app biết Colab còn
    sống hay không": đây chính là cách làm — 1 thread NỀN, ĐỘC LẬP HOÀN
    TOÀN với vòng lặp cào chính, cứ mỗi HEARTBEAT_INTERVAL_S lại ghi + commit
    1 file NHỎ (`remote-jobs/<job_id>-heartbeat.json`) chỉ chứa timestamp
    hiện tại. App phía Kotlin poll đúng file NHỎ này (nhanh, rẻ, tách biệt
    khỏi checkpoint chính) — heartbeat KHÔNG bị chặn dù 1 trang đang tải
    chậm (khác dựa vào `savedAt` của checkpoint chính như bản trước — cái
    đó CHỈ đổi sau mỗi 5 chương/120s, dễ báo nhầm "có vẻ đã dừng" trong
    lúc thực ra chỉ đang cào 1 trang nặng).
    Dừng heartbeat qua `stop_event` khi `main()` kết thúc (thành công hay
    lỗi) — không để lại tiến trình treo vô ích.
    """
    def __init__(self, repo_dir, job_id, interval_s=45):
        super().__init__(daemon=True)
        self.repo_dir = repo_dir
        self.job_id = job_id
        self.interval_s = interval_s
        self.stop_event = threading.Event()

    def run(self):
        path = f"remote-jobs/{self.job_id}-heartbeat.json"
        while not self.stop_event.is_set():
            try:
                with open(path, "w", encoding="utf-8") as f:
                    json.dump({"aliveAt": int(time.time() * 1000)}, f)
                git_commit_push(self.repo_dir, f"EbookLeech remote: {self.job_id} - heartbeat")
            except Exception as e:
                print(f"[Heartbeat] Loi ghi/commit (khong nghiem trong, thu lai lan sau): {e}", flush=True)
            self.stop_event.wait(self.interval_s)


class InteractiveCommandPoller(threading.Thread):
    """
    ĐÃ THÊM — điều khiển trình duyệt từ xa qua kênh git (không tunnel).

    Thiết kế bảo mật: chỉ ai có GitHub PAT (đã mã hoá trong AndroidKeyStore
    của app) mới ghi được file lệnh lên repo — không mở thêm endpoint mạng
    nào, không cần xác thực thêm — dùng lại chính cơ chế bảo mật đang có.

    Giao thức:
    1. App ghi `remote-jobs/<id>-cmd.json` = {"action": "...", "sentAt": ...}
    2. Thread này poll file đó mỗi CMD_POLL_INTERVAL_S giây khi job đang ở
       trạng thái NEEDS_ACTION (bị chặn, chờ người dùng xử lý thủ công).
    3. Thấy file mới → parse action → thực thi qua Playwright → chụp ảnh
       kết quả → commit ảnh → XOÁ file lệnh (dùng git rm + commit, không phải
       GitHub Contents DELETE — đơn giản hơn, đủ cho mục đích này).
    4. App phía Kotlin nhận biết "lệnh đã xong" khi GET file cmd trả 404.

    Lệnh hỗ trợ (khớp với sendInteractiveAction() bên Kotlin):
        screenshot                  — chụp màn hình hiện tại
        click:<css_selector>        — click element
        click_coord:<x>,<y>         — click toạ độ pixel
        type:<text>                 — gõ text vào element focus hiện tại
        press:<key>                 — nhấn phím (Enter, Tab, Escape, Space...)
        scroll:<direction>          — cuộn (up/down/top/bottom)
        wait:<ms>                   — chờ ms milliseconds (tối đa 30000)
        eval:<js>                   — thực thi JavaScript và chụp màn hình sau
    """
    CMD_POLL_INTERVAL_S = 4
    MAX_WAIT_MS = 30_000

    def __init__(self, repo_dir, job_id, page, images_dir, interval_s=CMD_POLL_INTERVAL_S, resume_event=None):
        super().__init__(daemon=True)
        self.repo_dir = repo_dir
        self.job_id = job_id
        self.page = page           # Playwright page đang chạy — thread chính GIỮ NGUYÊN, không đóng
        self.images_dir = images_dir
        self.interval_s = interval_s
        self.stop_event = threading.Event()
        self._cmd_path = f"remote-jobs/{job_id}-cmd.json"
        # ĐÃ THÊM — đường dẫn checkpoint chính, dùng để ghi
        # lastInteractiveScreenshotFile/lastInteractiveAt sau MỖI lệnh (xem
        # _update_checkpoint_interactive_result()) — đây là cách DUY NHẤT
        # để app phía Kotlin biết ảnh MỚI NHẤT nằm ở file nào, vì
        # pausedScreenshotFile chỉ ghi 1 lần lúc mới bị chặn, không đổi nữa
        # sau đó (lỗi đã phát hiện — trước đây ảnh của các lệnh sau KHÔNG
        # BAO GIỜ hiện lên UI dù đã commit lên git thành công).
        self._checkpoint_path = f"remote-jobs/{job_id}-checkpoint.json"
        # ĐÃ THÊM — event báo "người dùng đã giải xong (bằng các lệnh
        # click/type/press ở trên, hoặc tự giải qua ảnh chụp rồi bấm nút),
        # tiếp tục cào NGAY tại đúng chương đang bị chặn, dùng lại NGUYÊN
        # session/cookie hiện có (KHÔNG dispatch lại — dispatch lại = Actions
        # runner MỚI = IP MỚI = phải giải lại captcha lần nữa, vô nghĩa).
        # main() chờ event này thay vì chỉ chờ timeout như trước.
        self.resume_event = resume_event

    def run(self):
        print(f"[Interactive] Bat dau poll lenh tuong tac moi {self.interval_s}s", flush=True)
        while not self.stop_event.is_set():
            try:
                self._check_and_execute()
            except Exception as e:
                print(f"[Interactive] Loi poll/thuc thi lenh (thu lai lan sau): {e}", flush=True)
            self.stop_event.wait(self.interval_s)
        print("[Interactive] Da dung", flush=True)

    def _check_and_execute(self):
        if not os.path.exists(self._cmd_path):
            return
        try:
            with open(self._cmd_path, "r", encoding="utf-8") as f:
                cmd_data = json.load(f)
        except Exception:
            return  # file đang được ghi dở

        action = cmd_data.get("action", "")
        if not action:
            return

        # ĐÃ THÊM — lệnh đặc biệt "resume_crawl": KHÔNG thực thi như 1 hành
        # động trên trang (không click/type gì) — chỉ xoá file lệnh (báo
        # "đã xử lý" cho app) rồi báo hiệu resume_event cho main() biết để
        # thoát vòng chờ, thử lại chương đang bị chặn NGAY trên session này.
        if action == "resume_crawl":
            print("[Interactive] Nhan tin hieu 'resume_crawl' - bao hieu tiep tuc cao tai day", flush=True)
            with _GIT_LOCK:
                subprocess.run(["git", "-C", self.repo_dir, "rm", "-f", self._cmd_path], capture_output=True)
                result = subprocess.run(["git", "-C", self.repo_dir, "diff", "--cached", "--quiet"])
                if result.returncode != 0:
                    subprocess.run(["git", "-C", self.repo_dir, "commit", "-m",
                        f"EbookLeech remote interactive: {self.job_id} - resume_crawl"], check=True)
                    for attempt in range(3):
                        subprocess.run(["git", "-C", self.repo_dir, "pull", "--rebase", "--autostash"])
                        push = subprocess.run(["git", "-C", self.repo_dir, "push"])
                        if push.returncode == 0:
                            break
                        time.sleep(3)
            if self.resume_event is not None:
                self.resume_event.set()
            return

        print(f"[Interactive] Thuc thi lenh: {action}", flush=True)
        screenshot_name = f"_interactive_{self.job_id}_{int(time.time())}.png"
        screenshot_path = os.path.join(self.images_dir, screenshot_name)
        os.makedirs(self.images_dir, exist_ok=True)
        error_msg = ""

        try:
            self._execute_action(action)
            # Chụp màn hình SAU khi thực thi để thấy kết quả
            self.page.screenshot(path=screenshot_path, full_page=False, timeout=10_000)
            print(f"[Interactive] Da chup man hinh ket qua: {screenshot_name}", flush=True)
        except Exception as e:
            error_msg = str(e)
            print(f"[Interactive] Lenh loi: {e} — van chup man hinh hien tai", flush=True)
            try:
                self.page.screenshot(path=screenshot_path, full_page=False, timeout=10_000)
            except Exception:
                screenshot_path = None
                screenshot_name = ""

        # ĐÃ THÊM — cập nhật checkpoint NGAY tại đây (trước khi commit) — đây
        # là phần sửa lỗi "ảnh lệnh sau không hiện lên UI": ghi tên file ảnh
        # MỚI NHẤT + mốc thời gian vào checkpoint.json, app phía Kotlin đọc
        # đúng field này (lastInteractiveScreenshotFile/lastInteractiveAt)
        # để biết ảnh nào là mới nhất và tải về hiển thị.
        self._update_checkpoint_interactive_result(screenshot_name, action, error_msg)

        # Commit ảnh kết quả (nếu có), checkpoint vừa cập nhật, và XOÁ file
        # lệnh — TẤT CẢ trong CÙNG 1 commit (đồng bộ, không lệch pha).
        with _GIT_LOCK:
            if screenshot_path and os.path.exists(screenshot_path):
                subprocess.run(["git", "-C", self.repo_dir, "add", screenshot_path])
            subprocess.run(["git", "-C", self.repo_dir, "add", self._checkpoint_path])
            # Xoá file lệnh — sau khi xoá + commit là dấu hiệu "đã xong"
            # cho phía Kotlin (GET cmd file trả 404) — vẫn giữ dấu hiệu này
            # dù giờ đã có lastInteractiveAt, vì có nơi khác (vd polling
            # thường) cũng có thể muốn biết cmd hiện có đang treo hay không.
            subprocess.run(["git", "-C", self.repo_dir, "rm", "-f", self._cmd_path], capture_output=True)
            result = subprocess.run(["git", "-C", self.repo_dir, "diff", "--cached", "--quiet"])
            if result.returncode != 0:
                subprocess.run(["git", "-C", self.repo_dir, "commit", "-m",
                    f"EbookLeech remote interactive: {self.job_id} - {action[:40]}"], check=True)
                for attempt in range(3):
                    subprocess.run(["git", "-C", self.repo_dir, "pull", "--rebase", "--autostash"])
                    push = subprocess.run(["git", "-C", self.repo_dir, "push"])
                    if push.returncode == 0:
                        break
                    time.sleep(3)
        print(f"[Interactive] Xong lenh '{action}' — da commit ket qua", flush=True)

    def _update_checkpoint_interactive_result(self, screenshot_name, action, error_msg):
        """ĐÃ THÊM — đọc checkpoint hiện tại, ghi thêm 3 field mô tả kết quả
        lệnh interactive VỪA XONG, rồi lưu lại. KHÔNG dùng _GIT_LOCK ở đây
        (chỉ là I/O file cục bộ, chưa commit git) — an toàn vì lúc hàm này
        chạy, thread cào chính (main()) đang BỊ CHẶN trong vòng chờ của
        handle_blocked_pause() (không ghi checkpoint song song), thread
        heartbeat chỉ ghi file heartbeat riêng (không đụng checkpoint.json)
        — không có ai khác ghi đè checkpoint.json cùng lúc."""
        try:
            with open(self._checkpoint_path, "r", encoding="utf-8") as f:
                cp = json.load(f)
        except Exception as e:
            print(f"[Interactive] Khong doc duoc checkpoint de cap nhat ket qua (bo qua): {e}", flush=True)
            return
        cp["lastInteractiveScreenshotFile"] = screenshot_name
        cp["lastInteractiveAction"] = action
        cp["lastInteractiveError"] = error_msg
        cp["lastInteractiveAt"] = int(time.time() * 1000)
        try:
            with open(self._checkpoint_path, "w", encoding="utf-8") as f:
                json.dump(cp, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Interactive] Ghi checkpoint ket qua loi (bo qua, khong chan lenh): {e}", flush=True)

    def _execute_action(self, action: str):
        """Thực thi 1 lệnh trên self.page — NÉM exception nếu thất bại."""
        if action == "screenshot":
            return  # chụp ảnh sau khi hàm này return, không cần làm gì

        if action.startswith("click:"):
            selector = action[len("click:"):]
            self.page.click(selector, timeout=10_000)

        elif action.startswith("click_coord:"):
            coords = action[len("click_coord:"):]
            x, y = (int(v.strip()) for v in coords.split(",", 1))
            self.page.mouse.click(x, y)

        elif action.startswith("type:"):
            text = action[len("type:"):]
            self.page.keyboard.type(text)

        elif action.startswith("press:"):
            key = action[len("press:"):]
            self.page.keyboard.press(key)

        elif action.startswith("scroll:"):
            direction = action[len("scroll:"):]
            if direction == "down":
                self.page.evaluate("window.scrollBy(0, window.innerHeight * 0.8)")
            elif direction == "up":
                self.page.evaluate("window.scrollBy(0, -window.innerHeight * 0.8)")
            elif direction == "top":
                self.page.evaluate("window.scrollTo(0, 0)")
            elif direction == "bottom":
                self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")

        elif action.startswith("wait:"):
            ms = min(int(action[len("wait:"):]), self.MAX_WAIT_MS)
            self.page.wait_for_timeout(ms)

        elif action.startswith("eval:"):
            js = action[len("eval:"):]
            self.page.evaluate(js)

        else:
            raise ValueError(f"Lenh khong nhan biet: {action!r}")


def handle_blocked_pause(context, page, job_id, repo_dir, checkpoint_path, images_dir,
                          chapter_links, i, chapters_so_far, blocked_count, blocked_url,
                          has_own_page, storage_state_path=None):
    """
    ĐÃ THÊM — tách riêng logic "job bị chặn dai dẳng" thành 1 hàm dùng
    chung: chụp màn hình + commit trạng thái NEEDS_ACTION, rồi khởi động
    InteractiveCommandPoller nhận lệnh điều khiển TỪ app (click/type/press
    — xem sendInteractiveAction() phía Kotlin) NGAY trên session trình
    duyệt đang bị chặn này.

    KHÁC bản trước (chỉ chờ timeout rồi thoát hẳn): giờ chờ CẢ 2 tín hiệu —
    (a) resume_event được set (người dùng tự giải xong bằng các lệnh điều
    khiển, hoặc giải qua ảnh chụp rồi bấm "Tiếp tục cào ngay") → return
    resumed=True, gọi lại NGAY hàm cào cho đúng chương i, KHÔNG dispatch
    lại workflow (dispatch lại = Actions runner MỚI = IP MỚI = phải giải
    lại captcha lần nữa từ đầu, vô nghĩa với site chặn theo IP).
    (b) hết MAX_INTERACTIVE_WAIT_S giây không có gì → resumed=False, caller
    tự dọn dẹp (đóng browser) rồi thoát hẳn — người dùng có thể "Chạy lại"
    sau (dispatch mới, đọc checkpoint cũ, thử lại từ đúng chương bị chặn).

    @return (resumed: bool, interactive_page) — interactive_page là page
    ĐANG DÙNG (có thể là `page` cũ hoặc page mới tạo nếu trước đó None do
    ajax_content=True) — caller cập nhật lại biến `page` từ giá trị này.
    """
    screenshot_name = f"_block_{job_id}.png"
    screenshot_path = os.path.join(images_dir, screenshot_name)
    os.makedirs(images_dir, exist_ok=True)
    interactive_page = page if page else context.new_page()
    if not page:
        try:
            interactive_page.goto(blocked_url, timeout=PAGE_TIMEOUT_MS, wait_until="domcontentloaded")
        except Exception:
            pass  # không thể tải lại — vẫn giữ page để nhận lệnh screenshot/điều khiển

    try:
        interactive_page.screenshot(path=screenshot_path, full_page=False, timeout=10_000)
        print(f"[Paused] Da chup man hinh trang chan: {screenshot_path}", flush=True)
    except Exception as shot_err:
        print(f"[Paused] Chup man hinh loi (khong chan viec tam dung job): {shot_err}", flush=True)
        screenshot_name = ""

    with open(checkpoint_path, "w", encoding="utf-8") as f:
        cp = build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, i, chapters_so_far, blocked_count, False)
        cp["pausedForManualReview"] = True
        cp["pausedUrl"] = blocked_url
        cp["pausedReason"] = (
            "Trang bi chan dai dang sau khi thu lai - co the la CAPTCHA that (can nguoi giai) "
            "hoac site da chan han IP cua may chay crawler. Dung cac nut dieu khien trong app "
            "(chup man hinh, click, go text...) de tu giai NGAY tren phien nay, roi bam "
            "'Da giai xong, tiep tuc cao ngay' - KHONG can 'Chay lai' (dispatch lai se doi IP, "
            "phai giai lai tu dau neu site chan theo IP)."
        )
        cp["pausedScreenshotFile"] = screenshot_name
        json.dump(cp, f, ensure_ascii=False, indent=2)
    git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - TAM DUNG (bi chan tai chuong {i + 1})")
    print(f"[Paused] Da tam dung job o chuong {i + 1} - cho lenh dieu khien hoac tin hieu resume_crawl", flush=True)

    resume_event = threading.Event()
    interactive_poller = InteractiveCommandPoller(repo_dir, job_id, interactive_page, images_dir, resume_event=resume_event)
    interactive_poller.start()

    MAX_INTERACTIVE_WAIT_S = 25 * 60  # 25 phút — xấp xỉ sàn Actions còn lại
    WAIT_CHUNK = 4  # kiểm tra resume_event thường xuyên hơn poll lệnh thường
    # (interval_s=CMD_POLL_INTERVAL_S=4 của poller) để phản hồi resume nhanh
    waited = 0
    resumed = False
    while waited < MAX_INTERACTIVE_WAIT_S:
        if resume_event.wait(timeout=WAIT_CHUNK):
            resumed = True
            break
        waited += WAIT_CHUNK
        if not interactive_poller.is_alive():
            break

    interactive_poller.stop_event.set()
    interactive_poller.join(timeout=10)
    print(f"[Interactive] Da dung sau {waited}s ({'tiep tuc cao' if resumed else 'het gio cho, se dong'})", flush=True)

    if resumed:
        # ĐÃ THÊM — lưu storage_state NGAY LÚC NÀY, vì đây là mốc quan
        # trọng nhất: cookie/localStorage của session VỪA qua CAPTCHA/xác
        # minh — nếu job này (hoặc job khác cùng site) chạy remote lần
        # sau, khôi phục được đúng cookie "đã tin cậy" này, không phải
        # giải lại từ đầu. Lưu TRƯỚC git_commit_push để commit dưới đây
        # đem theo file này (git_commit_push dùng `git add -A`).
        if storage_state_path:
            save_storage_state(context, storage_state_path)
        # Ghi lại pausedForManualReview=False NGAY — để app poll thấy job
        # đã hết trạng thái chờ (không phải đợi tới lần commit chương tiếp
        # theo mới hết hiện cảnh báo đỏ).
        with open(checkpoint_path, "w", encoding="utf-8") as f:
            cp = build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, i, chapters_so_far, blocked_count, False)
            json.dump(cp, f, ensure_ascii=False, indent=2)
        git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - da giai xong, tiep tuc cao tu chuong {i + 1}")
    else:
        if has_own_page and interactive_page is not page:
            # page mới tạo riêng cho chế độ AJAX — không cần giữ, đóng luôn
            # (caller sẽ đóng `page` gốc, nếu có, theo logic cũ)
            try:
                interactive_page.close()
            except Exception:
                pass

    return resumed, interactive_page


def main():
    if len(sys.argv) < 2:
        print("Thieu tham so job_id"); sys.exit(1)
    job_id = sys.argv[1]
    repo_dir = os.getcwd()

    with open(f"remote-jobs/{job_id}.json", "r", encoding="utf-8") as f:
        job = json.load(f)

    checkpoint_path = f"remote-jobs/{job_id}-checkpoint.json"
    images_dir = f"remote-jobs/{job_id}-images"
    chapter_links = []
    chapters_so_far = []
    blocked_count = 0
    start_index = 0

    # Bản 7.102 — chỉ cào chương mới. Phân biệt 2 trường hợp khi đã có checkpoint:
    #  (a) checkpoint CHƯA xong (`remoteDone` không phải true: lần chạy trước bị ngắt, hoặc điện thoại đẩy checkpoint dở lên) => TIẾP TỤC như trước;
    #  (b) checkpoint ĐÃ xong (`remoteDone=true`) => đây là lần chạy MỚI. Trước 7.102 vẫn "tiếp tục" => thấy đã làm xong hết `chapterLinks` cũ, KHÔNG thu lại danh
    #      sách chương => không bao giờ thấy chương mới (đã tái hiện: site tăng 5 -> 8 chương, lần chạy hai vẫn ra 5).
    archive_path = f"remote-jobs/{job_id}-archive.json"
    incremental = bool(job.get("incrementalUpdate", False))
    try:
        refresh_last_n = max(0, int(job.get("refreshLastN", 0) or 0))
    except (TypeError, ValueError):
        refresh_last_n = 0
    archive = {}          # {sourceUrl: chương đã cào ở lần chạy trước} — chỉ dùng khi `incremental`
    reused_count = 0      # số chương dùng lại, KHÔNG mở trang
    crawled_count = 0     # số chương phải mở trang cào (cả chương lỗi, cả chương bị bỏ qua)
    skipped_count = 0     # bản 7.103: số chương bị BỎ QUA theo skipIfTextContains/minTextLength (không vào ebook)
    known_order = []      # bản 7.104: thứ tự danh sách chương của lần quét trước (từ kho) — căn cứ của "quét nhanh theo điểm neo"
    scan_meta = {}        # bản 7.104: điểm neo lần trước {lastPage, fastStreak, ...}
    list_scan_meta = {}   # bản 7.104: điểm neo của lần quét NÀY (ghi vào checkpoint => lần sau dùng)
    story_meta = {}       # bản 7.104: thông tin truyện của lần chạy NÀY (tác giả, tóm tắt, bìa...)
    prev_story_meta = {}  # thông tin truyện lần trước (từ kho) — lấp chỗ trống nếu trang lần này không có

    def run_stats():
        return {"reusedCount": reused_count, "crawledCount": crawled_count, "skippedCount": skipped_count, "listScan": list_scan_meta, "storyMeta": story_meta}

    old = None
    if os.path.exists(checkpoint_path):
        with open(checkpoint_path, "r", encoding="utf-8") as f:
            old = json.load(f)
    if old is not None and old.get("remoteDone"):
        old_chapters = old.get("chaptersSoFar", [])
        if incremental:
            archive, known_order, scan_meta, prev_story_meta = parse_archive_data(old)
            with open(archive_path, "w", encoding="utf-8") as f:
                # dạng dict: kho chương + thứ tự danh sách + điểm neo quét + thông tin truyện (để lần nạp lại sau khi bị ngắt vẫn biết)
                json.dump({"chaptersSoFar": list(archive.values()), "chapterLinks": known_order, "listScan": scan_meta, "storyMeta": prev_story_meta}, f, ensure_ascii=False)
            print(f"[NewRun] Lan chay truoc da xong ({len(old_chapters)} chuong) - day la lan chay MOI: thu lai danh sach chuong, dung lai {len(archive)} chuong da co (che do chi cao chuong moi)", flush=True)
        else:
            if os.path.exists(archive_path):
                os.remove(archive_path)
            print(f"[NewRun] Lan chay truoc da xong ({len(old_chapters)} chuong) - day la lan chay MOI: thu lai danh sach chuong va cao lai TOAN BO (job khong bat 'chi cao chuong moi')", flush=True)
        old = None  # KHÔNG tiếp tục checkpoint đã xong
    if old is not None:
        print("[Resume] Tim thay checkpoint cu - cao tiep, KHONG cao lai tu dau (anh da tai truoc do van con nguyen trong remote-jobs/*-images/)", flush=True)
        chapter_links = old.get("chapterLinks", [])
        chapters_so_far = old.get("chaptersSoFar", [])
        blocked_count = old.get("blockedChapterCount", 0)
        start_index = old.get("chapterProgressIndex", 0)
        # thống kê của lần chạy ĐANG DỞ (từ các process trước đó) cộng dồn với phần process này làm tiếp
        reused_count = int(old.get("reusedCount", 0) or 0)
        crawled_count = int(old.get("crawledCount", 0) or 0)
        skipped_count = int(old.get("skippedCount", 0) or 0)
        if isinstance(old.get("listScan"), dict) and old.get("listScan"):
            list_scan_meta = old["listScan"]  # đã quét xong danh sách ở lần chạy dở này => giữ nguyên điểm neo
        if isinstance(old.get("storyMeta"), dict) and old.get("storyMeta"):
            story_meta = old["storyMeta"]     # thông tin truyện đã lấy ở lần chạy dở này => dùng tiếp, không lấy lại
        if incremental and os.path.exists(archive_path):
            try:
                with open(archive_path, "r", encoding="utf-8") as f:
                    archive, known_order, scan_meta, prev_story_meta = parse_archive_data(json.load(f))
                print(f"[Resume] Nap lai kho {len(archive)} chuong cu de dung lai phan chua xu ly", flush=True)
            except (OSError, ValueError) as e:
                print(f"[Resume] Khong doc duoc kho chuong cu ({e}) - chuong chua xu ly se duoc cao lai", flush=True)
    # `index` cao nhất ĐÃ DÙNG (cả chương cũ trong kho chưa kịp dùng lại): chương MỚI luôn nhận số lớn hơn mọi số đã có => không bao giờ đụng chương cũ (kể cả tên ảnh `img_<index>_<n>`).
    index_high = max(max_chapter_index(chapters_so_far), max_chapter_index(list(archive.values())))
    used_indexes = {int(c["index"]) for c in chapters_so_far if str(c.get("index", "")).lstrip("-").isdigit()}

    download_images = job.get("downloadImages", False)
    max_images_per_chapter = job.get("maxImagesPerChapter", 30)
    ajax_content = job.get("ajaxContentMode", False)

    # ĐÃ THÊM — khởi động heartbeat NỀN ngay từ đây, trước cả khi vào
    # Phase 1 (Phase 1 có thể tự nó mất nhiều phút với site nhiều trang) —
    # app cần thấy "còn sống" ngay cả trong lúc chưa cào được chương nào.
    heartbeat = HeartbeatThread(repo_dir, job_id)
    heartbeat.start()
    print(f"[Heartbeat] Bat dau bao con song moi {heartbeat.interval_s}s", flush=True)

    try:
        with sync_playwright() as p:
            # ĐÃ ĐỔI — headless=True → headless=False (chế độ "headed").
            # Lý do: Chromium headless để lại vài dấu hiệu nhận diện được
            # (thiếu 1 số API render nội bộ, timing hơi khác) mà các trang
            # có CAPTCHA/anti-bot dựa vào để phân biệt bot — headed mode
            # KHÔNG có các dấu hiệu này (tự nhiên giống trình duyệt người
            # dùng thật hơn). Trên runner Ubuntu KHÔNG có màn hình vật lý —
            # bước "Cài Xvfb" trong workflow (`xvfb-run ...`) cấp 1 display
            # ảo để Chromium headed có chỗ khởi động.
            #
            # Vẫn KHÔNG "dứt điểm" — chỉ giảm 1 lớp dấu hiệu trong nhiều lớp
            # mà anti-bot cấp cao (Cloudflare/DataDome...) kiểm tra (TLS
            # fingerprint, hành vi chuột/gõ phím... vẫn ngoài tầm với).
            #
            # --no-sandbox + --disable-dev-shm-usage: 2 cờ tiêu chuẩn khi
            # chạy Chromium trong container/CI (runner Actions chạy trong
            # môi trường hạn chế quyền + /dev/shm nhỏ — thiếu 2 cờ này dễ
            # crash ngẫu nhiên giữa chừng, không liên quan gì tới headed/
            # headless).
            # Bản 7.101: chỉ chạy HEADED khi thật sự có màn hình (DISPLAY — xvfb-run cấp). Không có DISPLAY (vd notebook Colab cũ chạy thẳng `python3`)
            # thì Chromium headed chết ngay lúc launch với "Missing X server or $DISPLAY" (đã tái hiện khi kiểm) — rơi về headless thay vì sập cả job.
            has_display = bool(os.environ.get("DISPLAY"))
            if not has_display:
                print("[Browser] Khong co DISPLAY (khong co xvfb-run) - chay Chromium HEADLESS thay vi headed (de bi nhan dien la bot hon)", flush=True)
            browser = p.chromium.launch(
                headless=not has_display,
                args=["--no-sandbox", "--disable-dev-shm-usage"],
            )
            # ĐÃ THÊM — khôi phục storage_state (cookie + localStorage) từ
            # lần chạy TRƯỚC nếu có, để phiên mới KHÔNG bị coi là "hoàn
            # toàn mới tinh" mỗi lần dispatch — đặc biệt hữu ích ngay sau
            # khi người dùng vừa giải CAPTCHA thành công ở lần chạy trước
            # (xem handle_blocked_pause() — lưu storage_state TRƯỚC khi
            # commit, để lần dispatch SAU đó — nếu có — kế thừa được luôn,
            # không phải giải lại).
            storage_state_path = f"remote-jobs/{job_id}-storage-state.json"
            context = make_context(browser, job, storage_state_path=storage_state_path)

            if not chapter_links:
                print("[Phase1] Thu thap danh sach chuong...", flush=True)
                stages = job.get("preListStages", [])
                if stages:
                    # ĐÃ THÊM — port preListStages (xem traverse_pre_list_stages()
                    # và ghi chú đầy đủ ở đó về 1 khác biệt nhỏ so với bản Kotlin).
                    stage_page = context.new_page()
                    entries = traverse_pre_list_stages(stage_page, job)
                    print(f"[Phase-1] Duyet xong kich ban - {len(entries)} nguon danh sach chuong", flush=True)
                    for entry_idx, entry_url in enumerate(entries):
                        print(f"[Phase1] Nguon {entry_idx + 1}/{len(entries)}: {entry_url}", flush=True)
                        if job.get("ajaxListMode", False):
                            entry_links = collect_chapter_links_ajax(context, job, base_url=entry_url)
                        else:
                            entry_links = collect_chapter_links_html(context, job, base_url=entry_url, page=stage_page)
                        for l in entry_links:
                            if l not in chapter_links:
                                chapter_links.append(l)
                    stage_page.close()
                    list_scan_meta = {}  # nhiều nguồn: không dùng điểm neo
                else:
                    # Bản 7.104: có kho + điểm neo lần trước => thử QUÉT NHANH (chỉ đọc đầu + cuối danh sách). Mọi điều kiện không thoả => quét đầy đủ như cũ.
                    prev_last = int(scan_meta.get("lastPage", 0) or 0)
                    prev_streak = int(scan_meta.get("fastStreak", 0) or 0)
                    ajax_list = bool(job.get("ajaxListMode", False))
                    has_pattern = bool(job.get("listPageUrlPattern", "") or job.get("resolvedPaginationPattern", ""))
                    fast_scan = None
                    if incremental and archive and known_order and (ajax_list or has_pattern):
                        # Luôn đi qua bộ lập kế hoạch khi có kho (chế độ đầy đủ y hệt vòng lặp cũ, lại GIỮ chương cũ nếu trang danh sách bị chặn giữa chừng); quét nhanh chỉ khi đủ điều kiện.
                        use_fast = bool(job.get("listFastScan", True)) and prev_last >= 1
                        if use_fast and prev_streak >= FAST_SCAN_MAX_STREAK:
                            use_fast = False
                            print(f"[Phase1] Đã quét nhanh {prev_streak} lần liên tiếp — lần này quét ĐẦY ĐỦ để bắt chương chèn/đổi tên ở giữa danh sách", flush=True)
                        fast_scan = {"known": known_order, "hint": prev_last, "fast": use_fast}
                    if ajax_list:
                        chapter_links = collect_chapter_links_ajax(context, job, scan=fast_scan)
                    else:
                        chapter_links = collect_chapter_links_html(context, job, scan=fast_scan)
                    list_scan_meta = dict(LAST_LIST_SCAN_META)
                    if list_scan_meta.get("blocked"):
                        list_scan_meta["lastPage"] = max(int(list_scan_meta.get("lastPage", 0) or 0), prev_last)
                    list_scan_meta["fastStreak"] = prev_streak + 1 if list_scan_meta.get("mode") == "fast" else 0
                print(f"[Phase1] Thu duoc {len(chapter_links)} link chuong", flush=True)
                story_meta = collect_story_meta(context, job, images_dir, prev_story_meta)
                with open(checkpoint_path, "w", encoding="utf-8") as f:
                    json.dump(build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, 0, [], 0, False, {"listScan": list_scan_meta, "storyMeta": story_meta}), f, ensure_ascii=False, indent=2)
                # ĐÃ THÊM — lưu storage_state sau Phase 1 (đã đi qua trang
                # danh sách chương, có thể đã tự vượt qua 1 lớp Cloudflare/
                # xác minh nhẹ — lưu lại cookie này cho lần chạy sau).
                save_storage_state(context, storage_state_path)
                git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - xong Phase 1 ({len(chapter_links)} chuong)")

            if not story_meta:
                # tiếp tục một lần chạy dở mà chưa có thông tin truyện (checkpoint của runner cũ) => lấy bây giờ
                story_meta = collect_story_meta(context, job, images_dir, prev_story_meta)

            page = context.new_page() if not ajax_content else None
            last_commit_time = time.time()

            # ĐÃ ĐỔI từ `for i in range(...)` sang `while i < len(...)` —
            # lý do: khi bị chặn và người dùng resume tại chỗ (xem
            # handle_blocked_pause), cần THỬ LẠI đúng chương i (không tăng
            # index) trên CÙNG session vừa giải xong — `for` không cho retry
            # cùng 1 giá trị i, phải tự quản lý index bằng tay.
            i = start_index
            crawled_since_commit = 0
            while i < len(chapter_links):
                url = chapter_links[i]
                cached = archive.get(url) if incremental else None
                must_refresh = refresh_last_n > 0 and i >= len(chapter_links) - refresh_last_n
                if cached is not None and not must_refresh:
                    # Dùng lại chương đã cào ở lần chạy trước: KHÔNG mở trang, GIỮ NGUYÊN index + ảnh (ảnh đã nằm sẵn trong remote-jobs/<id>-images/).
                    reused, index_high = take_over_chapter(cached, used_indexes, index_high)
                    chapters_so_far.append(reused)
                    reused_count += 1
                    if reused_count % 50 == 0:
                        print(f"[Phase2] Dung lai {reused_count} chuong tu kho (chua mo trang nao)", flush=True)
                    if (time.time() - last_commit_time) >= CHECKPOINT_COMMIT_EVERY_SECONDS:
                        with open(checkpoint_path, "w", encoding="utf-8") as f:
                            json.dump(build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, i + 1, chapters_so_far, blocked_count, False,
                                                            run_stats()), f, ensure_ascii=False, indent=2)
                        git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - {i + 1}/{len(chapter_links)} chuong")
                        last_commit_time = time.time()
                    i += 1
                    continue
                print(f"[Phase2] Chuong {i + 1}/{len(chapter_links)}: {url}", flush=True)
                try:
                    if ajax_content:
                        result, err = crawl_one_chapter_ajax(context, job, url)
                    else:
                        result, err = crawl_one_chapter_html(page, job, url, chapter_links)
                except BlockedNeedsManualReview as e:
                    # ĐÃ ĐỔI — thay vì luôn thoát hẳn, giờ gọi
                    # handle_blocked_pause() (dùng chung với vòng chờ
                    # interactive) và CÓ THỂ retry đúng chương i nếu người
                    # dùng resume tại chỗ (giải captcha qua nút điều khiển
                    # rồi bấm "Tiếp tục cào ngay") — không cần dispatch lại.
                    resumed, new_page = handle_blocked_pause(
                        context, page, job_id, repo_dir, checkpoint_path, images_dir,
                        chapter_links, i, chapters_so_far, blocked_count, e.url,
                        has_own_page=(page is None),
                        storage_state_path=storage_state_path,
                    )
                    if resumed:
                        if not ajax_content:
                            page = new_page  # có thể là page mới nếu trước đó None
                        continue  # THỬ LẠI đúng chương i — không tăng index
                    # Hết giờ chờ, không ai giải — dọn dẹp và thoát hẳn như cũ.
                    # Người dùng vẫn có thể "Chạy lại" sau (dispatch mới, đọc
                    # checkpoint, thử lại từ đúng chương i này).
                    if page:
                        try:
                            page.close()
                        except Exception:
                            pass
                    browser.close()
                    return  # THOÁT main() ngay — finally bên dưới vẫn chạy để dừng heartbeat

                except Exception as e:
                    result, err = None, f"Loi khong xac dinh: {e}"

                # Bản 7.103: bỏ qua chương theo điều kiện (khoá/rỗng/thông báo) TRƯỚC khi cấp số thứ tự và tải ảnh — chương bị bỏ không tốn `index`, không vào ebook, không vào kho
                # (cả khi nó là chương trong `refreshLastN`: giống cào tại máy, chương bị bỏ qua không được thay bằng bản cũ).
                skipped_why = None
                if not err and result is not None and (job.get("skipIfTextContains") or int(job.get("minTextLength", 0) or 0) > 0):
                    probe_text = result[2]
                    processed_text = apply_regex_rules(result[0] or f"Chuong {i + 1}", result[1], probe_text, job.get("regexRules", []))[2]
                    skipped_why = skip_reason(job, probe_text, processed_text)

                # Bản 7.101: `index` của chương = SỐ THỨ TỰ DUY NHẤT (1, 2, 3…) tính từ chỉ số lớn nhất ĐANG CÓ trong checkpoint, KHÔNG phải vị trí 0-based `i` như trước.
                # Lý do: bản điện thoại đánh số 1-based (chapters.size + 1); khi chuyển job dở từ điện thoại sang GitHub, Python tiếp tục với index=i (0-based) làm chương mới
                # đầu tiên TRÙNG index với chương cuối đã cào ở máy => EbookExporter ghi hai entry `OEBPS/chapter_<index>.xhtml` cùng tên vào EPUB (ZipOutputStream báo
                # "duplicate entry") và ảnh `img_<index>_<n>` của hai chương đè nhau. Dùng max+1 thì duy nhất bất kể checkpoint do ai tạo (điện thoại 1-based, bản Python cũ 0-based,
                # công cụ ngoài).
                # Bản 7.102: số mới = (index cao nhất từng thấy, kể cả chương cũ trong kho) + 1 — thay cho `next_chapter_number(chapters_so_far)`, vì chương cũ trong kho có thể
                # chưa nằm trong `chapters_so_far` (sẽ được dùng lại ở vị trí sau) nhưng ảnh `img_<index>_<n>` của chúng đã chiếm tên file.
                crawled_since_commit += 1
                if skipped_why is not None:
                    print(f"[Phase2] Bo qua chuong {i + 1}: {skipped_why}", flush=True)
                    crawled_count += 1
                    skipped_count += 1
                    chapter_number = None
                elif err and cached is not None:
                    # Cào lại chương trong `refreshLastN` bị lỗi (mạng/chặn) => GIỮ bản cũ thay vì thay bằng chương lỗi (y hệt hành vi cào tại máy).
                    print(f"[Phase2] Loi khi cao lai chuong {i + 1} ({err}) - giu ban cu", flush=True)
                    kept, index_high = take_over_chapter(cached, used_indexes, index_high)
                    chapters_so_far.append(kept)
                    reused_count += 1
                    chapter_number = None
                else:
                    # Bản 7.103: chương CÀO LẠI (nằm trong `refreshLastN`) GIỮ `index` cũ nếu còn trống — trước đây mỗi lần làm mới lại cấp số mới => số thứ tự thủng dần và ảnh cũ
                    # `img_<index>_<n>` thành mồ côi. Ảnh mới ghi đè đúng tên file cũ. Chương mới hẳn (không có bản cũ) vẫn lấy `index_high + 1`.
                    chapter_number = None
                    if cached is not None:
                        try:
                            old_idx = int(cached.get("index"))
                        except (TypeError, ValueError):
                            old_idx = None
                        if old_idx is not None and old_idx not in used_indexes:
                            chapter_number = old_idx
                    if chapter_number is None:
                        index_high += 1
                        chapter_number = index_high
                    used_indexes.add(chapter_number)
                    crawled_count += 1
                if chapter_number is None:
                    pass
                elif err:
                    print(f"[Phase2] Loi chuong {i + 1}: {err}", flush=True)
                    chapters_so_far.append(chapter_to_json(chapter_number, f"Chuong {i + 1} [loi]", f"<p>Khong lay duoc noi dung: {err}</p>", f"[Khong lay duoc noi dung: {err}]", url, []))
                    blocked_count += 1
                else:
                    raw_title, raw_html, raw_text = result
                    images_meta = []
                    if download_images and raw_html:
                        raw_html, images_meta = download_and_localize_images(context, raw_html, url, chapter_number, max_images_per_chapter, images_dir)
                        if images_meta:
                            print(f"    Da tai {len(images_meta)} anh", flush=True)
                    title, html, text = apply_regex_rules(raw_title or f"Chuong {i + 1}", raw_html, raw_text, job.get("regexRules", []))
                    chapters_so_far.append(chapter_to_json(chapter_number, title, html, text, url, images_meta))

                now = time.time()
                should_commit = (
                    crawled_since_commit >= CHECKPOINT_COMMIT_EVERY_N_CHAPTERS
                    or (now - last_commit_time) >= CHECKPOINT_COMMIT_EVERY_SECONDS
                    or i == len(chapter_links) - 1
                )
                if should_commit:
                    # git add -A (trong git_commit_push) tu gom CA checkpoint
                    # JSON lan moi anh moi ghi vao remote-jobs/<id>-images/
                    # trong CUNG 1 commit - anh va checkpoint LUON dong bo voi
                    # nhau, khong lech pha.
                    with open(checkpoint_path, "w", encoding="utf-8") as f:
                        json.dump(build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, i + 1, chapters_so_far, blocked_count, False,
                                                        run_stats()), f, ensure_ascii=False, indent=2)
                    crawled_since_commit = 0
                    # ĐÃ THÊM — lưu storage_state cùng nhịp với checkpoint
                    # (rẻ — chỉ đọc cookie/localStorage hiện có, không tốn
                    # network) — luôn có bản mới nhất phòng khi job bị kill
                    # đột ngột giữa chừng (app crash, Actions timeout...).
                    save_storage_state(context, storage_state_path)
                    git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - {i + 1}/{len(chapter_links)} chuong")
                    last_commit_time = now

                time.sleep(job.get("delayBetweenPagesMs", 1500) / 1000.0)
                i += 1  # ĐÃ THÊM — for cũ tự tăng, while phải tự làm; CHỈ chạy
                        # khi không "continue" ở nhánh resumed (retry i cũ)

            if page:
                page.close()
            browser.close()

        with open(checkpoint_path, "w", encoding="utf-8") as f:
            json.dump(build_checkpoint_json(job_id, "CRAWLING_CHAPTERS", chapter_links, len(chapter_links), chapters_so_far, blocked_count, True,
                                            run_stats()), f, ensure_ascii=False, indent=2)
        # Xong cả job: bản sao chương cũ hết tác dụng (checkpoint `remoteDone=true` chính là kho cho lần chạy sau) — xoá để repo không giữ hai bản dữ liệu giống nhau.
        if os.path.exists(archive_path):
            os.remove(archive_path)
        git_commit_push(repo_dir, f"EbookLeech remote: {job_id} - HOAN TAT ({len(chapters_so_far)} chuong, {blocked_count} loi/chan)")
        print(f"[Done] Xong - {len(chapters_so_far)} chuong, {blocked_count} loi/chan, mo trang {crawled_count}, dung lai {reused_count}, bo qua {skipped_count}", flush=True)

    finally:
        # ĐÃ THÊM — LUÔN dừng heartbeat khi main() kết thúc, dù thành công,
        # lỗi, hay pause-chờ-thủ-công (return ở trên) — không để lại thread
        # nền ghi heartbeat vô ích sau khi crawl đã xong/dừng hẳn.
        heartbeat.stop_event.set()
        heartbeat.join(timeout=5)
        print("[Heartbeat] Da dung", flush=True)


if __name__ == "__main__":
    main()
