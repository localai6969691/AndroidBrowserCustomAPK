# Hướng dẫn sử dụng EbookLeech

(Cùng nội dung với nút "📖 Hướng dẫn" trong app: `app/src/main/assets/ebookleech/huong_dan.md`.)

## 1. EbookLeech dùng để làm gì
Cào nội dung từ một trang web (ví dụ trang đọc truyện): lấy danh sách chương, mở từng chương, lấy tiêu đề và nội dung, rồi gom lại thành ebook EPUB, TXT hoặc HTML. Có thể chạy ngay trên điện thoại (dùng đúng tab trình duyệt của khe này, nên đi cùng proxy/đăng nhập của khe), hoặc chạy từ xa trên GitHub Actions / Google Colab.
Ebook xuất ra nằm ở thư mục Tải xuống (Download) > EbookLeech > tên job. Bấm "📖 Mở ebook" ở thẻ job để mở.
Mục lục trong ebook: EPUB có mục lục (mỗi chương một mục, hiện trong trình đọc), HTML có khung "Mục lục" ở đầu trang với link nhảy tới từng chương, TXT KHÔNG có danh sách mục lục (chỉ có tiêu đề từng chương ngăn cách bằng đường kẻ). Muốn gom chương thành các "Tập" hoặc đổi tên mục thì dùng mục 9. Mục lục EPUB mới được kiểm tra bằng cách đọc mã và kiểm cấu trúc file, chưa mở thử bằng ứng dụng đọc thật.

## 2. Bật tính năng
- Vào Cài đặt tính năng của khe, bật "Ebook Leech". Khi bật, một thông báo dịch vụ nền sẽ hiện ra cho khe đó.
- Mỗi khe (tiến trình riêng) có danh sách job riêng và dùng tab riêng của khe để cào. Muốn cào ở khe nào thì mở màn hình này từ khe đó.

## 3. Tạo job đầu tiên (từng bước)
1. Bấm "+ Thêm Job mới".
2. Tên job: tên bạn tự đặt, cũng là tên thư mục và tên file ebook. Dự án: nhóm job lại cho gọn (không bắt buộc).
3. URL trang danh sách (trang 1): địa chỉ trang liệt kê các chương (mục lục truyện).
4. Phân trang nếu mục lục có nhiều trang: điền "Pattern phân trang" có {page} (ví dụ https://site.com/truyen?page={page}), hoặc bỏ trống ô đó và bật "Tự dò cách phân trang". "Số trang danh sách tối đa" chặn việc cào quá nhiều trang.
5. Selector CSS trang danh sách: "Selector link chương" là bộ chọn trỏ tới các thẻ link chương (ví dụ .chapter-list a); "Thuộc tính href" thường để nguyên href.
6. Selector CSS trang chương: "Selector tiêu đề chương" và "Selector nội dung chương".
7. Không rành CSS? Bấm nút "🎯 Chọn" bên cạnh ô selector: app mở trang thật, bạn chạm vào phần tử cần lấy (link chương thì chọn kiểu danh sách, tiêu đề/nội dung thì chọn một phần tử), app tự điền selector.
8. Chọn Định dạng (EPUB/TXT/HTML), "Chạy ở đâu", "Lịch chạy". Bấm Lưu.
9. Ở thẻ job bấm "▶ Chạy ngay". Theo dõi trạng thái và số chương đã cào ngay trên thẻ.
Mẹo: lần đầu hãy thử trên một truyện nhỏ (đặt "Số trang danh sách tối đa" = 1) để kiểm tra selector trước khi cào cả bộ.

## 4. Các trạng thái của job
- Chờ: chưa chạy.
- ▶ Đang chạy: đang cào (có thể bấm "⏹ Dừng").
- ⏸ Đã dừng: bạn dừng hoặc bị ngắt; "▶ Chạy ngay" sẽ cào tiếp từ điểm dừng (nếu còn checkpoint), không cào lại từ đầu.
- 📑 Chờ sắp xếp mục lục: đã cào xong, đang đợi bạn sắp xếp (nếu bật tuỳ chọn dừng lại để sắp xếp).
- ⚠️ Cần giải xác minh thủ công: trang đòi Cloudflare/CAPTCHA (xem mục 5).
- ✅ Xong: đã xuất ebook. ❌ Lỗi: xem dòng lý do trên thẻ job.

## 5. Khi trang đòi xác minh (Cloudflare / CAPTCHA)
- Chạy trên điện thoại: app dừng lại và báo "Cần giải xác minh thủ công". Mở tab đang bị chặn, tự giải xác minh, rồi bấm "✅ Đã giải xong, tiếp tục". Có thể bấm "⏭ Bỏ qua chương này".
- Chạy từ xa: máy chủ không có người ngồi, nên job dừng lại và app hiện ảnh chụp màn hình trang bị chặn. Dùng khối "🖥️ Điều khiển trình duyệt từ xa" để chụp màn hình, gõ chữ, click selector, gửi phím Enter/Tab/Esc, cuộn, chạy JS ngay trên phiên đang bị chặn (cùng IP, cùng cookie), rồi bấm "✅ Đã giải xong — Tiếp tục cào ngay"; không phải chạy lại từ đầu. Cách thay thế: "🌐 Mở URL này trong trình duyệt của bạn" rồi "🔄 Chạy lại (dispatch mới)": giải xác minh trên điện thoại không chắc giúp máy chủ hết bị chặn vì IP khác nhau; khả thi hơn là dán cookie phiên mới vào ô Cookie của job.
- CAPTCHA thật vẫn cần người giải; chưa có dịch vụ giải tự động.

## 6. Site cần đăng nhập
- Bật "Dùng đăng nhập có sẵn trong app" để tab cào dùng cookie đăng nhập của khe (đăng nhập trước ở tab thường), hoặc dán "Cookie header" vào form job (ví dụ session=abc123; token=xyz).
- Mặc định tắt: tab cào chạy ẩn danh, không lưu gì.

## 7. Kịch bản nhiều bước
Dùng khi phải đi qua vài trang trung gian mới tới mục lục (ví dụ Trang chủ > Thể loại > Sách > danh sách chương). Bấm "+ Thêm bước trung gian", mỗi bước có tên và "Selector link ở bước này", theo đúng thứ tự. Nút "🗺️ Kịch bản" trên thẻ job cho xem luồng các bước và sửa riêng từng bước.

## 8. Tìm và thay thế trong nội dung
Mục "Tìm & thay thế trong nội dung cào" xử lý tiêu đề/nội dung mỗi chương sau khi cào, trước khi lưu vào ebook. Chọn "Áp dụng lên" (tiêu đề, nội dung HTML hoặc nội dung chữ) và "Loại xử lý":
- Tìm & thay thế văn bản thường (không cần biết regex): dùng để xoá dòng quảng cáo, đổi tên nhân vật.
- Regex: cho người rành regex. Có ô "không phân biệt hoa thường".
- Cắt khoảng trắng đầu/cuối dòng, xoá dòng trống thừa, đổi chữ hoa/thường, viết hoa đầu câu, bỏ hết thẻ HTML.
- Spin nội dung: mẫu có dạng {phương án 1|phương án 2|...}; mỗi chương tự chọn ngẫu nhiên một phương án để các bài không trùng nhau (hữu ích khi đăng WordPress).

## 9. Sắp xếp mục lục
Bật "Cào xong thì DỪNG lại cho tôi sắp xếp mục lục". Khi job ở trạng thái "📑 Chờ sắp xếp mục lục", bấm "📑 Sắp xếp mục lục": giữ và kéo (hoặc dùng ▲ ▼) để đổi vị trí, ✏ đổi tên, 🗑 loại khỏi ebook, tick nhiều mục rồi bấm "📁 Gộp mục đã chọn thành 1 Tập". Xong thì xuất ebook.

## 10. Ảnh, cuộn trang, trang dựng bằng JavaScript
- "Tải ảnh về máy, nhúng offline vào ebook": ebook có ảnh nhưng nặng và chậm hơn. "Số ảnh tối đa / chương" giới hạn số ảnh.
- "Trang chỉ hiện nội dung khi cuộn xuống": bật cho trang tải chậm (lazy-load). Cào tại máy: sau khi trang chương mở xong, app cuộn dần xuống đáy (mỗi lần chờ 0,7 giây, tối đa "Số lần cuộn tối đa", dừng sớm khi trang hết dài thêm) rồi mới lấy nội dung. Bản 7.101 sửa lỗi cũ là cuộn xảy ra TRƯỚC khi trang đích mở; phần này chưa thử trên điện thoại thật. Cuộn chỉ áp dụng cho trang chương, không áp dụng cho trang danh sách kiểu "cuộn mãi mới hiện thêm chương" (loại đó chưa hỗ trợ).
- **Trang dựng bằng JavaScript** (chương/danh sách chỉ hiện sau khi JS chạy), cào tại máy: dùng tab trình duyệt thật nên JS có chạy. App đợi trang báo tải xong rồi đợi thêm 0,8 giây cố định, rồi mới đọc. Trang dựng chậm hơn mức đó có thể ra 0 chương hoặc chương rỗng, và chế độ này CHƯA có "chờ tới khi selector xuất hiện". Bấm "🧪 Thử selector" để biết selector có khớp không; nếu trang quá chậm, dùng cào từ xa (mục 13) hoặc "AJAX Leech thật" (mục 16).
- **Trang dựng bằng JavaScript**, cào từ xa (bản 7.101): máy chủ chờ phần tử selector xuất hiện tối đa 8 giây mỗi trang rồi mới đọc, và cuộn lazy-load nếu bạn bật tuỳ chọn trên. Trang tĩnh không bị chậm thêm. Đã chạy thật trên site giả (trang dựng sau 1,5 giây: trước sửa 0/5 chương, sau sửa 5/5); chưa thử trên site thật.

## 11. Lịch chạy
Thủ công (bạn bấm chạy), Theo chu kỳ (nhập số phút), hoặc Mỗi ngày. "Delay giữa các trang (ms)" là thời gian nghỉ giữa các lần mở trang; để site khỏi chặn, đừng đặt quá thấp.
- Cách chạy theo lịch: dịch vụ nền kiểm tra mỗi 30 giây, job nào đến hạn thì tự chạy. Job đang chạy, đang tạm dừng hoặc đang chờ bạn xử lý xác minh thì bị bỏ qua. Cào TẠI MÁY cần khe này đang mở trong app (không có thì job báo lỗi); cào từ xa thì không cần.
- Mỗi lần chạy theo lịch mặc định cào lại TỪ ĐẦU rồi xuất một file MỚI (tên có ngày giờ) trong thư mục của job; file cũ không bị ghi đè.
- **Truyện chưa hoàn thành, muốn tự cập nhật chương mới**: chọn "Theo chu kỳ" hoặc "Mỗi ngày" và bật "♻️ Chỉ cào chương mới" (mục 17). Mỗi lần: quét lại danh sách chương, chỉ mở chương chưa có, rồi xuất lại CẢ truyện nếu có thay đổi. Nếu không có gì mới thì KHÔNG xuất lại và thẻ job ghi dòng "🕒 …không có chương mới".
- Từ bản 7.102: bật "📎 Cập nhật Ở FILE CŨ" thì ebook có tên cố định và mỗi lần cập nhật GHI ĐÈ lên đúng file đó (không chất đống file có ngày giờ); bật "🔔 Thông báo khi có chương mới" thì điện thoại báo "+N chương mới" và bấm vào thông báo là mở ebook. Cả hai chỉnh ở bước "Cập nhật tăng dần…" của Kịch bản (mục 17).
- Cào từ xa cũng hỗ trợ "Chỉ cào chương mới" (từ bản 7.102): máy chủ dùng lại chương của lần chạy xong trước, chỉ mở trang chương mới. Điều kiện: repo GitHub phải có file zip bản 7.103 trở lên (mục 13.4); từ 7.103 cách giao việc đã đổi nên chạy lại job đúng cả khi máy chủ là máy LeechDesk trên PC (mục 19).
- "Nối thêm chương vào file cũ" hiểu theo nghĩa: ebook được dựng lại đủ cả truyện rồi ghi đè lên file cũ (EPUB là file nén, không "chèn thêm" được từng chương). Kết quả bạn thấy là một file duy nhất luôn đầy đủ, không phải một file phụ chỉ chứa chương mới.

## 13. Cào từ xa (GitHub Actions / Google Colab) — hướng dẫn từng bước
## 13.1 Là gì, hoạt động ra sao
Cào từ xa = nhờ một máy ảo của GitHub (GitHub Actions) hoặc Google Colab mở Chromium thật và cào hộ bạn. Điện thoại chỉ giao việc và nhận kết quả, không phải mở trình duyệt cào. Một repo GitHub đóng vai "bảng tin chung":
1. App ghi file mô tả job vào thư mục remote-jobs/ của repo, rồi gọi GitHub chạy workflow.
2. Máy ảo chạy script cào (crawler.py), cứ mỗi 5 chương hoặc 2 phút thì ghi tiến độ (checkpoint) và ảnh vào repo.
3. App đọc tiến độ mỗi 20 giây. Cào xong, app tải chương về và xuất ebook NGAY TRÊN ĐIỆN THOẠI vào Tải xuống > EbookLeech > tên job.
App phải còn chạy (nền) để nhận kết quả; nếu app bị tắt giữa chừng thì lần mở sau app nối lại việc theo dõi (đọc từ mã, chưa thử thật).

## 13.2 Khi nào nên dùng, khi nào không
- Nên: truyện nhiều chương, không muốn điện thoại tốn pin/mạng; trang dựng bằng JavaScript.
- Không hợp: (1) trang cần đăng nhập, vì máy chủ không mượn được phiên đăng nhập của khe, chỉ dùng được cookie bạn dán vào ô Cookie của job; (2) trang chặn IP của GitHub/Google, vì máy chủ KHÔNG đi qua proxy của khe mà dùng IP riêng của nó; (3) khi cần "bỏ qua chương" hoặc "chương nhiều trang" (mục 17), vì máy chủ chưa có; riêng "Chỉ cào chương mới" thì máy chủ có từ bản 7.102.
- Không có nút "🎯 Chọn" trên máy chủ: dựng và kiểm selector bằng chế độ điện thoại + "🧪 Thử selector" trước, rồi mới đổi sang từ xa.

## 13.3 Chuẩn bị
- Một tài khoản GitHub.
- Một repo RIÊNG TƯ (Private). Bắt buộc riêng tư vì: file job chứa nguyên văn cookie và mật khẩu ứng dụng WordPress (nếu bạn điền), và toàn bộ nội dung truyện cào được bị commit vào repo. Có thể dùng repo build APK của bạn nếu nó đang riêng tư; nếu repo đó công khai, tạo một repo riêng tư mới chỉ để cào (chỉ cần file zip + file workflow, xem bước 1 và 2).

## 13.4 Bước 1 — Đưa mã vào repo
1. github.com > New repository > đặt tên (ví dụ ebookleech-remote) > chọn Private > tick "Add a README file" (để repo có nhánh mặc định) > Create repository.
2. Add file > Upload files > chọn file colab-live-browser-project.zip (bản 7.102 trở lên, cùng file bạn dùng build APK) > Commit changes. Để nguyên file zip ở gốc repo, KHÔNG cần giải nén: workflow tự lấy crawler.py từ file zip (bản 7.101 sửa lỗi cũ là workflow đòi thư mục đã giải nén nên hỏng ngay bước đầu trong repo chỉ có file zip). Cập nhật bản mới của app thì upload zip mới đè lên. Với "Chỉ cào chương mới" từ xa PHẢI dùng zip bản 7.103 trở lên mới thật sự chỉ cào chương mới. Zip bản 7.102 hoặc cũ hơn vẫn cho kết quả ĐÚNG nhưng cào lại toàn bộ (đã chạy thử với crawler.py 7.102: đủ 8 chương, dùng lại 0); khi đó thẻ job ghi rõ "crawler.py trong repo là bản cũ hơn 7.103…" để bạn biết cần tải zip mới lên.

## 13.5 Bước 2 — Thêm file workflow
1. Mở file ebookleech/EBOOKLEECH_REMOTE_CRAWL_STEP.yml trong zip bằng trình xem văn bản, chép TOÀN BỘ nội dung.
2. Trong repo: Add file > Create new file > ở ô tên gõ chính xác .github/workflows/ebookleech-remote-crawl.yml (gõ dấu / thì GitHub tự tạo thư mục) > dán nội dung > Commit directly to the main branch (nhánh mặc định).
3. Kiểm tra: tab Actions của repo phải hiện "EbookLeech Remote Crawl" ở danh sách bên trái. Không hiện thì file YAML dán thiếu/sai.
Lưu ý: file phải tên đúng ebookleech-remote-crawl.yml, phải nằm ở nhánh mặc định, và KHÔNG dán vào build.yml (app gọi workflow theo tên file này, đặt trong build.yml thì GitHub trả lỗi 404).

## 13.6 Bước 3 — Tạo token (Personal Access Token)
GitHub > ảnh đại diện > Settings > Developer settings > Personal access tokens.
- Cách đã được app mô tả: **Tokens (classic)** > Generate new token (classic) > tick "repo" và "workflow" > chọn hạn dùng > Generate.
- Cách hẹp quyền hơn: **Fine-grained token**, Repository access chọn "Only select repositories" và chỉ chọn repo này; Repository permissions đặt Contents = Read and write và Actions = Read and write. Đây là theo tài liệu GitHub, chưa thử với app này; nếu app báo 403/404 khi kích hoạt thì tạo token classic.
Chép token ngay khi hiện (GitHub chỉ hiện một lần).

## 13.7 Bước 4 — Cấu hình trong app
EbookLeech > "☁️ Cào từ xa (GitHub / Colab)" (một cấu hình dùng chung cho cả GitHub Actions và Colab; trong hộp này có khối "📓 Google Colab" với nút mở/sao chép link notebook): điền Chủ repo (tên tài khoản), Tên repo, Nhánh (nhánh mặc định, thường là main), Personal Access Token > Lưu. Token được mã hoá bằng AndroidKeyStore của máy; nút "🗑 Xoá token" để xoá.

## 13.8 Bước 5 — Chạy một job
1. Thêm hoặc sửa job, điền selector như thường, mục "Chạy ở đâu" chọn "☁️ GitHub Actions (từ xa)" > Lưu.
2. Bấm "▶ Chạy ngay". App đẩy job lên repo rồi kích hoạt workflow. Có thể hẹn lịch như mục 11.
3. Theo dõi: thẻ job hiện số chương đã cào (cập nhật mỗi 20 giây, mỗi lần nhảy theo cục vì máy chủ ghi tiến độ mỗi 5 chương/2 phút). "🔄 Đồng bộ ngay" kéo tiến độ ngay; "💾 Sao lưu ngay" lưu bản hiện có. Muốn xem chi tiết: tab Actions của repo > lần chạy mới nhất > xem log.
4. Xong: app xuất ebook trên điện thoại; bấm "📖 Mở ebook".
Thời gian: vài phút đầu để máy ảo cài Chromium, sau đó mới cào. Mỗi lần chạy tối đa 180 phút (đặt trong file workflow); truyện quá dài thì lần chạy bị cắt, tiến độ đã ghi vẫn giữ, bấm chạy lại sẽ cào tiếp từ chỗ dở.
Điện thoại / GitHub / Colab dùng chung một dạng checkpoint nên về nguyên tắc chuyển qua lại được. Đã thử phía máy chủ: crawler.py cào tiếp đúng từ checkpoint dở do bên ngoài tạo; phía điện thoại nhận lại thì chưa thử (xem TAI_LIEU_KY_THUAT.md mục 8).

## 13.9 Google Colab (thủ công, không tốn phút GitHub)
1. Trong job chọn "Chạy ở đâu" = "📓 Google Colab (thủ công)" > "▶ Chạy ngay". App đẩy job lên repo rồi hiện job_id và link mở notebook.
2. Mở link bằng tài khoản Google, chạy lần lượt các ô (Runtime > Run all). Ô 2 hỏi chủ repo, tên repo, nhánh, job_id và token (dán vào ô ẩn; token không được lưu vào notebook).
3. Giữ tab Colab mở và còn kết nối suốt lúc cào (Colab tự ngắt khi không tương tác). Ngắt thì tiến độ đã ghi vẫn còn; chạy lại notebook sẽ cào tiếp.
4. Không cần file workflow, nhưng repo vẫn cần file zip ở gốc (notebook tự lấy crawler.py từ đó, bản 7.101).

## 13.10 Chi phí, giới hạn, bảo mật
- Chi phí: repo công khai dùng Actions miễn phí. Repo riêng tư trừ vào hạn mức mỗi tháng của gói GitHub: theo trang tài liệu GitHub tôi đọc hôm nay, gói Free có sẵn 12 USD tiền chạy mỗi tháng (tính ra khoảng 2.000 phút Linux theo giá 0,006 USD/phút; số phút là phép tính của tôi, không phải con số GitHub nêu, và GitHub có thể đổi). Hết hạn mức thì lần chạy bị từ chối hoặc bị tính phí tuỳ cài đặt chi tiêu của bạn; xem trang Billing của bạn.
- Bảo mật: repo phải riêng tư. Xoá thư mục remote-jobs/ sau khi xong chỉ làm file biến mất khỏi nhánh, dữ liệu vẫn còn trong lịch sử git. Cấp token cho đúng một repo nếu dùng fine-grained.
- Repo sẽ có nhiều commit và dung lượng tăng theo số ảnh/chương.
- Máy chủ chỉ dùng cookie bạn dán, không dùng đăng nhập của khe. Từ bản 7.103 máy chủ có "bỏ qua chương" và "chương nhiều trang" như cào tại máy (mục 17). Mỗi lần chạy vẫn quét lại toàn bộ danh sách chương — việc này không bỏ được vì muốn biết site có chương mới hay chưa thì phải đọc danh sách; nếu bật "Chỉ cào chương mới" thì chỉ MỞ trang chương mới, còn không thì cào lại toàn bộ.
- Với "Chỉ cào chương mới" từ xa, lần chạy đầu tiên chỉ dùng lại được khi repo đã có kết quả đã xong của lần chạy trước (job mới hoặc lần trước bị lỗi/ngắt thì phải cào hết một lần). Từ 7.103, ngay lúc bạn bấm chạy, app tự lưu kết quả cũ thành file remote-jobs/<id>-archive.json (bản sao chương cũ) rồi đặt checkpoint về rỗng; crawler.py xoá file này khi chạy xong (LeechDesk thì để lại đến lần chạy kế tiếp). Job vừa cào TẠI MÁY rồi chuyển sang chạy từ xa: repo chưa có kết quả xong nên lần đầu vẫn cào đủ.
- Gặp xác minh (Cloudflare/CAPTCHA) mà máy chủ không vượt được thì job dừng và chờ bạn; máy chủ không tự bỏ qua chương.

## 13.11 Lỗi thường gặp
- "Kích hoạt workflow lỗi …": sai tên repo/nhánh, token thiếu quyền (cần Contents + Actions write, hoặc classic repo + workflow), hoặc chưa có file workflow ở nhánh mặc định (404).
- "Lần chạy Actions kết thúc với lỗi (conclusion=failure)": mở tab Actions > lần chạy > bước màu đỏ. Lỗi "Không thấy mã crawler" nghĩa là repo thiếu file colab-live-browser-project.zip ở gốc.
- "crawler.py trong repo GitHub là bản CŨ (thiếu runnerVersion)…": repo đang giữ file zip cũ. Tải file colab-live-browser-project.zip MỚI NHẤT lên gốc repo rồi chạy lại.
- Thẻ job đứng yên ở 0 chương: đang cài Chromium (vài phút) hoặc workflow chưa chạy; xem tab Actions.
- Ra 0 chương hoặc chương rỗng: kiểm tra selector bằng chế độ điện thoại; với trang JS chậm có thể cần chạy lại (máy chủ chờ tối đa 8 giây mỗi trang).

## 14. Đăng WordPress (tuỳ chọn)
Bật "Đăng mỗi chương thành 1 bài viết WordPress" rồi điền URL site, tên đăng nhập, Application Password (tạo trong WordPress > Người dùng > Hồ sơ), trạng thái bài, ID category và mẫu tiêu đề ({title}, {bookName}).

## 15. Dự án, sao lưu, khôi phục, preset
- "🗂 Dự án": nhóm các job.
- "📤 Sao lưu" / "📥 Khôi phục": lưu và nạp lại toàn bộ job, dự án, cấu hình (nhớ sao lưu trước khi gỡ app).
- "💾 Lưu selector này làm preset" / "📋 Áp dụng preset đã lưu": dùng lại bộ selector cho site cùng kiểu. App không kèm sẵn preset nào; bạn tự lưu sau khi cào thành công một site.

## 16. Khi gặp lỗi
- Job báo lỗi hoặc cào ra 0 chương: kiểm lại selector bằng "🎯 Chọn" trên đúng trang và bằng "🧪 Thử selector"; thử bật "Trang chỉ hiện nội dung khi cuộn xuống"; tăng delay. Trang dựng bằng JavaScript rất chậm: xem mục 10.
- Site dùng API JSON: mục "AJAX Leech thật" cho phép lấy thẳng danh sách chương/nội dung từ API (điền URL API và đường dẫn field).
- Cần gửi lỗi cho người phát triển: gửi dòng lý do trên thẻ job và log (tìm từ khoá EbookLeech).

## 17. Cập nhật tăng dần, lọc chương, chương nhiều trang, thử selector (bản 7.100)
Mở thẻ job > "🗺 Kịch bản" > bước "Cập nhật tăng dần & lọc chương & chương nhiều trang". Tất cả mặc định TẮT, job cũ chạy y như trước. Cào TẠI MÁY dùng được tất cả. Cào từ xa (GitHub/Colab/máy LeechDesk) dùng được "Chỉ cào chương mới" và "Cào lại N chương cuối" (từ 7.102) cùng "Bỏ qua chương" và "Chương nhiều trang" (từ 7.103). "Cập nhật Ở FILE CŨ" và "Thông báo" xảy ra trên điện thoại nên dùng được ở cả hai chế độ.
- ♻️ **Chỉ cào chương mới**: app nhớ chương đã cào (theo URL) sau mỗi lần chạy. Lần sau (tay hoặc theo lịch) chỉ MỞ trang của chương chưa có (danh sách chương được quét nhanh theo điểm neo từ bản 7.104 — mục 20, hoặc quét lại toàn bộ khi tắt/đến lượt quét đầy đủ) rồi xuất lại cả sách. "Cào lại N chương cuối" dành cho site hay sửa chương mới đăng (nếu cào lại mà lỗi mạng thì giữ bản đã lưu). Site đổi dạng URL chương thì mọi chương coi là mới. Muốn cào lại từ đầu: nút "🗑 Xoá kho" (từ 7.103 nút này chỉ xoá nội dung chương, vẫn nhớ "lần xuất trước"). Kho không nằm trong Sao lưu; đổi máy thì lần đầu cào lại hết. Với cào từ xa, "kho" chính là kết quả lần chạy xong trước nằm trong repo; chương lỗi hoặc bị chặn không bao giờ được dùng lại.
- 🚫 **Bỏ qua chương**: chương chứa một cụm bạn liệt kê (mỗi dòng một cụm, ví dụ "chương này bị khoá") hoặc có nội dung ngắn hơn N ký tự sẽ không vào ebook, không tốn số thứ tự và không lưu vào kho (lần sau site mở khoá vẫn thử lại).
- 📄 **Chương chia nhiều trang**: điền selector của link "trang kế" trong chương; app mở lần lượt và nối vào cùng chương. Tự dừng khi hết link, đủ số trang tối đa, link lặp, hoặc link trỏ sang một chương khác trong danh sách (để nút "Tiếp" dùng chung cho cả trang kế và chương kế không nuốt cả truyện).
- 🧪 **Thử selector**: nút ở đầu màn Kịch bản. Mở trang danh sách và chương đầu tiên rồi báo selector nào khớp / không khớp, nội dung lấy ra dài bao nhiêu, đoạn đầu ra sao, chương này có bị luật bỏ qua không. Nên chạy trước khi cào cả truyện. Chỉ thử trang 1 của danh sách và chương đầu, không bảo đảm mọi chương giống nhau.
- 🕒 **Không có chương mới thì không xuất lại** (bản 7.101): khi bật "Chỉ cào chương mới" và lần chạy này giống hệt lần xuất trước (cùng danh sách chương, tiêu đề, nội dung, cùng định dạng/tên file xuất, file ebook cũ vẫn còn, không bật "xem trước mục lục"), app không tạo thêm file giống y hệt mà giữ file cũ và ghi vào thẻ job dòng "🕒 …không có chương mới". Có chương mới, đổi nội dung, đổi định dạng hoặc bạn xoá mất file cũ thì xuất file mới như thường.
- 📎 **Cập nhật Ở FILE CŨ** (bản 7.102, mặc định TẮT): ebook có tên cố định, không có ngày giờ; mỗi lần xuất ghi đè lên đúng file đó trong Tải xuống > EbookLeech > tên job. Ebook vẫn là cả truyện (dựng lại từ đầu rồi ghi đè), chỉ là không sinh thêm file mới. Nếu app không ghi đè được (ví dụ file cũ do app khác tạo hoặc bị xoá) thì tự tạo file mới. Bật/tắt mục này đổi cách đặt tên nên lần chạy kế tiếp luôn xuất lại.
- 🔔 **Thông báo khi có chương mới** (bản 7.102, mặc định BẬT): sau khi xuất, app so danh sách chương với lần xuất trước; có chương mới (tính theo URL) thì hiện thông báo "📚 tên job: +N chương mới", bấm vào để mở ebook. Lần xuất đầu tiên không báo (không coi cả truyện là chương mới); sửa nội dung chương cũ không tính là chương mới; không có gì đổi thì không báo. Android 13 trở lên cần cấp quyền thông báo cho app, nếu chưa cấp thì hệ thống âm thầm bỏ qua. Thẻ job luôn ghi dòng "+N chương mới (tổng M)" dù bật hay tắt thông báo.
- "🗑 Xoá kho" (từ bản 7.103) chỉ xoá nội dung chương đã lưu để lần sau cào lại hết; app VẪN nhớ "lần xuất trước" nên lần cào lại đó vẫn báo đúng "+N chương mới". (Bản 7.102: xoá kho làm mất luôn mốc này, lần sau bị coi là xuất lần đầu.) Xoá hẳn job thì mốc mất theo. Nếu đổi link nguồn khiến KHÔNG chương nào còn khớp lần xuất trước, app coi như xuất lần đầu thay vì báo cả truyện là chương mới.
- Chương "cào lại N chương cuối" giữ số thứ tự cũ (bản 7.102 cấp số mới nên có khoảng trống); chương mới nhận số tiếp theo số lớn nhất đã có.

## 19. Máy LeechDesk trên PC làm "máy chủ cào" (bản 7.103)
LeechDesk là app cào chạy trên PC/VPS (Windows/Mac/Linux, bản 1.4.0 gửi kèm riêng (1.3.0 vẫn đồng bộ được nhưng không có quét nhanh/thông tin truyện)). Nó nói chuyện với EbookLeech qua đúng repo GitHub của "Cào từ xa", nên dùng thay GitHub Actions/Colab mà không cần cấu hình thêm trên điện thoại.
- **Giao việc:** job đặt "Chạy từ xa" như thường. Trên LeechDesk bật "Cầu nối addon" (cùng repo + nhánh + token), job hiện ở "Hộp thư addon": bấm "Nhận & chạy tiếp", hoặc bật "Tự nhận" cho VPS không người trực (VPS tự nhận cả lần bạn bấm chạy lại job đã xong).
- **Kết quả:** LeechDesk cào cùng quy tắc như máy chủ crawler.py (chỉ cào chương mới, bỏ qua chương, chương nhiều trang, cào lại N chương cuối). Xong thì điện thoại tự nhận và xuất ebook tại máy như mọi job từ xa; thẻ job ghi máy nào đã cào (ví dụ "leechdesk-1.3.0").
- **Theo dõi:** Cài đặt EbookLeech > "🖥 Máy LeechDesk (PC)": danh sách máy LeechDesk (xanh = báo tin trong 2 phút gần nhất), từng job đang chạy bao nhiêu %, và hộp thư các job LeechDesk giao mà điện thoại chưa có (nhập về làm job cục bộ). Máy chạy LeechDesk cũ hơn 1.3 được cảnh báo.
- **Cần đúng phiên bản:** để chạy lại job đã xong qua LeechDesk, điện thoại phải là 7.103 trở lên (bản 7.102 làm LeechDesk trả lại kết quả cũ mà không cào gì — lỗi này đã tái hiện và đã sửa ở 7.103). LeechDesk dưới 1.3 vẫn cào đúng nhưng cào lại toàn bộ và hiện thêm một mục lạ tên "<id>-archive" ở hộp thư.
- Việc cần hạn chế: LeechDesk không đẩy file ebook lên GitHub; ebook luôn được điện thoại dựng từ chương đã cào. Mỗi lần LeechDesk đẩy là một commit, nên dùng repo riêng.
- Mức kiểm chứng: xem mục 18 (chưa chạy trên điện thoại thật; LeechDesk chưa thử với GitHub thật).

## 20. Quét nhanh danh sách, thông tin truyện, nối tiếp từ điện thoại sang PC (bản 7.104)
Tất cả đều nằm trong cài đặt job (cào từ xa/LeechDesk dùng cùng khoá). Không có tuỳ chọn nào làm hỏng job cũ: nếu không bật "Chỉ cào chương mới" thì phần quét nhanh không có tác dụng.
- **⚡ Quét nhanh danh sách theo điểm neo** (mặc định BẬT, chỉ có tác dụng khi bật "♻️ Chỉ cào chương mới" và đã có kho từ lần trước): thay vì mở mọi trang danh sách, app chỉ đọc ĐẦU và CUỐI danh sách, phần giữa lấy lại từ kho. Cứ 10 lần quét nhanh liên tiếp thì quét đầy đủ một lần, và mọi dấu hiệu bất thường (trang bị chặn, trang 1 rỗng, không thấy điểm neo) tự quay về quét đầy đủ hoặc giữ danh sách cũ. **Nhược điểm nói thẳng:** chương mới được chèn GIỮA danh sách (không ở đầu/cuối) chỉ được thấy ở lần quét đầy đủ kế tiếp (tối đa 10 lần sau). Site hay chèn chương ở giữa thì tắt tuỳ chọn này. Thẻ job/log ghi "Quét nhanh: đọc A trang, bỏ qua B trang giữa danh sách". Điều kiện để quét nhanh chạy (cào tại máy): bật "Chỉ cào chương mới", đã có kho, job chỉ có MỘT nguồn danh sách, KHÔNG dùng kịch bản duyệt trước, và biết cách phân trang (có "Pattern phân trang" có {page}, đã tự dò ra, hoặc chế độ AJAX). Lần đầu sau khi nâng từ bản cũ, và lần đầu của job mới, quét đầy đủ để ghi nhớ trang cuối; từ lần kế tiếp mới quét nhanh. Tiếp tục một lần chạy đang dở ở giai đoạn thu thập link thì dùng cách tuần tự cũ.
- **Thông tin truyện** (mặc định BẬT): app lấy tác giả, tóm tắt, thể loại, nhãn, tình trạng, đánh giá, ngôn ngữ, bìa… từ trang (dữ liệu có cấu trúc JSON-LD/Open Graph/microdata hoặc các dòng có nhãn như "Tác giả:"). Site lạ lấy không ra thì đặt selector theo từng trường hoặc nhập tay (nhập tay thắng tất cả). "Trang thông tin truyện" để trống = dùng trang danh sách chương.
- **Ebook mang theo thông tin:** EPUB có metadata chuẩn (tác giả, mô tả, thể loại, ngôn ngữ, series, ảnh bìa — thư viện/ứng dụng đọc hiển thị được) và một trang "Giới thiệu" ở đầu sách; TXT/HTML có khối thông tin ở đầu file. Trang/khối này CHỈ được thêm khi lấy được gì đó ngoài tên truyện (hoặc có bìa); không lấy được gì thì ebook y như trước.
- **File dữ liệu cho web truyện:** cạnh ebook có "tên.story.json" (toàn bộ thông tin + phần gợi ý ánh xạ sang bài viết web: tiêu đề, trích đoạn, nội dung, chuyên mục, thẻ, ảnh đại diện) và "tên.cover.<đuôi>" (ảnh bìa). Tắt bằng ô "xuất kèm file .story.json" nếu không cần.
- **Điện thoại → cloud → PC nối tiếp:** nếu job đã cào dở/xong ở điện thoại rồi chuyển sang chạy từ xa hoặc giao cho LeechDesk, điện thoại đẩy "kho" các chương đã cào (kèm thứ tự, điểm neo, thông tin truyện, bìa) lên repo; máy kia chỉ cào chương mới rồi đẩy kết quả (kèm thông tin truyện) về. LeechDesk 1.4.0 trở lên hiểu dạng kho này (có tab "Cập nhật & thông tin truyện"); LeechDesk cũ vẫn cào đúng nhưng cào lại từ đầu.
- **Cần cập nhật zip trong repo:** để cào từ xa dùng được quét nhanh và thông tin truyện, phải tải lại file colab-live-browser-project.zip bản 7.104 lên gốc repo (đè zip cũ). Zip cũ vẫn cào được nhưng không có hai tính năng này.
- **Chưa có:** thông tin theo từng chương (ngày đăng, người dịch từng chương), gộp truyện trùng/nhiều nguồn, kiểm tra liên kết hỏng, tự đăng lên web (chỉ tạo dữ liệu cho công cụ đăng).
- **Trình duyệt (cùng bản 7.104):** tab nền không được xem sẽ KHÔNG bị app đưa sang trang captcha do chính trang tự chuyển (tuỳ chọn ẩn "defer_bg_challenge", mặc định bật; chưa có công tắc trong giao diện); khi hoãn, log ghi "[thử thách] …". Phần này chưa thử trên GeckoView thật — nếu log ghi "nguồn: không đọc được cờ" thì bản này không hoãn gì cả, hãy gửi log.

## 18. Nói thẳng về mức độ đã kiểm chứng
Tính năng này ghép vào app ở bản 7.98 và CHƯA được chạy thử thật trên thiết bị. Những gì đã kiểm tra và chưa kiểm tra:
- Đã chạy thật trên máy tính: script cào từ xa crawler.py (Playwright + Chromium + git thật) với web giả cục bộ: trang tĩnh, trang dựng bằng JS sau 1,5 giây, trang chỉ hiện nội dung sau khi cuộn, chạy khi không có màn hình ảo, nhận checkpoint dở do chương trình ngoài tạo; và việc workflow lấy crawler.py từ file zip ở gốc repo.
- Đã chạy thật (bản 7.102) cho "Chỉ cào chương mới" từ xa: site tăng 5 lên 8 chương thì lần hai chỉ mở trang 3 chương mới, lần ba (không đổi) mở 0 trang; cào lại N chương cuối; lần chạy bị ngắt giữa chừng rồi chạy tiếp vẫn dùng lại chương cũ; job không bật "chỉ cào chương mới" vẫn cào lại toàn bộ.
- Đã chạy thật (bản 7.103) crawler.py với "bỏ qua chương", "chương nhiều trang" (kể cả nút "Tiếp" trỏ sang chương kế không bị nối nhầm), chạy lại job theo đúng chuỗi ghi file mới của app (có/không tăng dần), số thứ tự chương cào lại không đổi; và LeechDesk 1.3.0 với GitHub GIẢ (30 kiểm tra): chỉ mở 3 chương mới khi site thêm 3 chương, VPS tự nhận khi bạn bấm chạy lại, thư mục hơn 1000 file. Phần Kotlin của client GitHub (file lớn, ETag, giới hạn phụ) đã chạy thật trên JVM với máy chủ GitHub giả (25 kiểm tra).
- Đã mô phỏng trên máy tính: luồng cào tại máy (cập nhật tăng dần, bỏ qua chương, chương nhiều trang, không xuất lại khi không đổi, đếm chương mới và gọi thông báo, mốc xuất, "Xoá kho" giữ mốc), 58 kiểm tra đạt, với web giả và phần Android là giả lập. Mô phỏng chỉ kiểm LOGIC: nó gọi hàm "báo chương mới", không kiểm thông báo hiện ra thật.
- CHƯA kiểm tra (thêm ở 7.103): chuỗi ghi file "chạy lần mới" và màn hình "🖥 Máy LeechDesk (PC)" trên điện thoại thật (mã đã biên dịch, chưa chạy; phần thử bên LeechDesk dùng một lớp Python bắt chước chuỗi ghi file của app, KHÔNG chạy mã Kotlin); client GitHub với GitHub thật (file > 1 MB, ETag, giới hạn phụ — mới thử với máy chủ giả viết theo tài liệu GitHub); LeechDesk với GitHub thật và với app Android thật.
- CHƯA kiểm tra: mọi thứ trên điện thoại thật (GeckoView, cuộn lazy-load phía điện thoại, thẻ job, nút Thử selector); thông báo chương mới có hiện và bấm mở đúng ebook không; ghi đè file cũ qua MediaStore trên các bản Android khác nhau; phía điện thoại khi nhận kết quả cào từ xa tăng dần (đã kiểm biên dịch, chưa chạy); GitHub Actions thật và Colab thật (quyền token, kích hoạt workflow, poll, tải ảnh); site thật có Cloudflare/chống bot; mở EPUB đã xuất bằng ứng dụng đọc thật.
- Giới hạn còn lại của 7.103 (từ 7.104 đã GIẢM bằng quét nhanh, xem mục 20; nó chỉ không quét lại toàn bộ khi bật quét nhanh): mỗi lần chạy vẫn quét lại toàn bộ danh sách chương (không bỏ được, chỉ giảm được; chưa làm phần giảm); lần chạy tăng dần đầu tiên của job vừa cào tại máy phải cào đủ vì repo chưa có kết quả cũ; điện thoại 7.102 + LeechDesk không chạy lại được job đã xong (cần 7.103); LeechDesk < 1.3 cào lại toàn bộ. Nếu app bị tắt giữa lúc máy chủ đang chạy, app nhớ mốc "kết quả cũ" ở bộ nhớ máy để khi mở lại không nhận nhầm kết quả cũ là xong (mã đã viết và biên dịch, chưa thử khi app bị tắt thật).
- **Bản 7.104 — đã chạy thật trên máy tính:** quét nhanh (crawler.py thật: lần hai chỉ mở trang 1 và các trang cuối + 3 chương mới; trang 1 rỗng thì giữ danh sách cũ; chèn giữa danh sách chỉ thấy ở quét đầy đủ — đúng như nhược điểm đã nêu); tạo EPUB/TXT/HTML có thông tin truyện (12 bộ xuất file + 25 ca HTML hỏng, 544 kiểm tra đạt, kiểm cấu trúc XML/OPF/mục lục); trích thông tin trên nhiều trang mẫu trong Chromium thật; LeechDesk 1.4.0 chạy đủ bộ test với GitHub giả; biên dịch toàn dự án không thêm lỗi mới.
- **Bản 7.104 — CHƯA kiểm tra:** mọi thứ trên điện thoại thật (hộp tick quét nhanh, mục "Thông tin truyện", đẩy/nhận kho với GitHub thật, hoãn captcha tab nền trên GeckoView thật); mở EPUB bằng ứng dụng đọc thật (mới kiểm cấu trúc); site thật; LeechDesk với Chrome/Edge + GitHub + app thật; nguyên nhân đơ trình duyệt; vì sao một khe không bị lỗi kéo-thả.
Nếu thấy chỗ nào hoạt động khác mô tả trên, hãy báo kèm ảnh chụp và log (dòng đầu log có version=7.104-…) để sửa.
