
import java.io.File
import com.colablive.keeper.core.StallLogic
object P {
    fun rssKb(pid: Int): Long = try {
        File("/proc/$pid/status").readLines().firstOrNull { it.startsWith("VmRSS:") }?.substringAfter(":")?.trim()?.substringBefore(" ")?.toLongOrNull() ?: -1L
    } catch (_: Throwable) { -1L }
    fun fdCensus(): String = try {
        val dir = File("/proc/self/fd")
        val names = dir.list() ?: return "không đọc được /proc/self/fd"
        var sock = 0; var epoll = 0; var event = 0; var pipe = 0; var file = 0; var other = 0
        for (n in names) {
            val t = try { java.nio.file.Files.readSymbolicLink(java.io.File(dir, n).toPath()).toString() } catch (_: Throwable) { "" }
            when {
                t.startsWith("socket:") -> sock++
                t.contains("eventpoll") -> epoll++
                t.contains("eventfd") -> event++
                t.startsWith("pipe:") -> pipe++
                t.startsWith("/") -> file++
                else -> other++
            }
        }
        "fd=${names.size} (socket=$sock epoll=$epoll eventfd=$event pipe=$pipe tệp=$file khác=$other)"
    } catch (e: Throwable) { "fdCensus lỗi ${e.javaClass.simpleName}" }
    private fun ctxSwitches(tid: Int): Pair<Long, Long>? = try {
        val l = File("/proc/self/task/$tid/status").readLines()
        fun f(k: String) = l.firstOrNull { it.startsWith("$k:") }?.substringAfter(":")?.trim()?.toLongOrNull() ?: 0L
        Pair(f("voluntary_ctxt_switches"), f("nonvoluntary_ctxt_switches"))
    } catch (_: Throwable) { null }
    fun hotThreadForensics(tid: Int, windowMs: Long = 600L): String = try {
        val is64 = System.getProperty("os.arch", "").contains("64")
        val c0 = ctxSwitches(tid)
        val samples = ArrayList<String>()
        var unreadable: String? = null
        val n = 20
        val gap = (windowMs / n).coerceAtLeast(5L)
        val t0 = System.currentTimeMillis()
        repeat(n) {
            try { samples.add(File("/proc/self/task/$tid/syscall").readText()) } catch (e: Throwable) { if (unreadable == null) unreadable = e.javaClass.simpleName + ":" + (e.message ?: "").take(40) }
            try { Thread.sleep(gap) } catch (_: InterruptedException) {}
        }
        val dt = (System.currentTimeMillis() - t0).coerceAtLeast(1L)
        val c1 = ctxSwitches(tid)
        val ctx = if (c0 != null && c1 != null) {
            val v = c1.first - c0.first; val nv = c1.second - c0.second
            "chuyển ngữ cảnh tự nguyện +$v (${v * 1000 / dt}/s), không tự nguyện +$nv (${nv * 1000 / dt}/s) trong ${dt}ms"
        } else "không đọc được status"
        val sys = if (samples.isEmpty()) "syscall không đọc được (${unreadable ?: "?"})" else StallLogic.summarizeSyscalls(samples, is64)
        "$ctx | syscall: $sys"
    } catch (e: Throwable) { "hotThreadForensics lỗi ${e.javaClass.simpleName}: ${e.message}" }
}
fun main() {
    val stop = java.util.concurrent.atomic.AtomicBoolean(false)
    var tidHot = -1
    val spin = Thread({ var x = 0L; while (!stop.get()) { x += System.nanoTime() % 7 } }, "AudioIPC Server")
    spin.isDaemon = true; spin.start()
    Thread.sleep(300)
    // tìm tid của luồng theo comm
    for (t in File("/proc/self/task").list()!!) { try { if (File("/proc/self/task/$t/comm").readText().trim() == "AudioIPC Server") tidHot = t.toInt() } catch (e: Exception) {} }
    println("tid luồng quay = $tidHot")
    val first = P.hotThreadForensics(tidHot, 600L)
    println("PHÁP Y: " + first)
    println("FD: " + P.fdCensus())
    println("rss tiến trình này (kB) = " + P.rssKb(ProcessHandle.current().pid().toInt()))
    stop.set(true)
    val spinSig = first.contains("running×20") || first.contains("running×19") || first.contains("running×18")
    if (tidHot < 0 || !first.contains("không tự nguyện") || !spinSig || !P.fdCensus().startsWith("fd=")) { println("FAIL"); System.exit(1) } else println("PASS: quay thuần CPU = nhiều không-tự-nguyện + syscall toàn running")
}
