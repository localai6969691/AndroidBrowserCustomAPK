#!/usr/bin/env bash
# Chạy 3 bộ kiểm thử của bản 7.110 (cần kotlinc + java; KHÔNG cần Android SDK vì chỉ dùng logic thuần).
#   kotlinc: https://github.com/JetBrains/kotlin/releases (đã thử với 2.1.20)
set -e
cd "$(dirname "$0")"
SRC=../../app/src/main/java/com/colablive/keeper
OUT=$(mktemp -d)
kotlinc $SRC/core/StallLogic.kt StallLogicTest.kt -include-runtime -d $OUT/t1.jar 2>/dev/null && java -jar $OUT/t1.jar
kotlinc $SRC/features/colab/ColabLogic.kt ColabLogicTest.kt -include-runtime -d $OUT/t2.jar 2>/dev/null && java -jar $OUT/t2.jar
# Thử thật trên /proc (Linux): luồng tên "AudioIPC Server" quay 100% phải bị nhận ra ở ~giây 16, luồng rảnh không bị báo. Mất ~20s.
kotlinc $SRC/core/StallLogic.kt ProcSpinHarness.kt -include-runtime -d $OUT/t3.jar 2>/dev/null && java -cp $OUT/t3.jar ProcSpinHarnessKt
# Bản 7.111: thử pháp y trên /proc thật (trích nguyên văn hàm từ GeckoHealthProbe.kt qua tệp harness): luồng quay thuần CPU => nhiều chuyển ngữ cảnh KHÔNG tự nguyện + syscall toàn "running".
kotlinc $SRC/core/StallLogic.kt ProcForensicsHarness.kt -include-runtime -d $OUT/t4.jar 2>/dev/null && java -cp $OUT/t4.jar ProcForensicsHarnessKt
# Bản 7.112: LogChunk — dòng ~2100 ký tự (như [CHẨN ĐOÁN ĐƠ]) không được mất phần đuôi (bộ nhớ/PSI).
kotlinc $SRC/core/LogChunk.kt LogChunkTest.kt -include-runtime -d $OUT/t5.jar 2>/dev/null && java -jar $OUT/t5.jar
