
import java.io.File
import com.colablive.keeper.core.StallLogic

object P {
    private fun statTicks(path: String): Long? = try {
        val s = File(path).readText()
        val rp = s.lastIndexOf(')')
        if (rp < 0) null else {
            val f = s.substring(rp + 2).split(' ')
            f[11].toLong() + f[12].toLong()
        }
    } catch (_: Throwable) { null }
    fun selfThreadTicks(names: MutableMap<Int, String>): Map<Int, Long> {
        val out = HashMap<Int, Long>()
        val tids = try { File("/proc/self/task").list() } catch (_: Throwable) { null } ?: return out
        for (t in tids) {
            val tid = t.toIntOrNull() ?: continue
            val ticks = statTicks("/proc/self/task/$t/stat") ?: continue
            out[tid] = ticks
            if (!names.containsKey(tid)) {
                names[tid] = try { File("/proc/self/task/$t/comm").readText().trim() } catch (_: Throwable) { "tid$tid" }
            }
        }
        names.keys.retainAll(out.keys)
        return out
    }
}

fun main() {
    val names = HashMap<Int, String>()
    val stop = java.util.concurrent.atomic.AtomicBoolean(false)
    val spin = Thread({ var x = 0L; while (!stop.get()) { x += System.nanoTime() % 7 } }, "AudioIPC Server")
    val idle = Thread({ while (!stop.get()) Thread.sleep(50) }, "idle-thread")
    spin.isDaemon = true; idle.isDaemon = true; spin.start(); idle.start()
    val tr = StallLogic.HotTracker(100)
    var firstAt = -1L; val t0 = System.currentTimeMillis()
    var falsePositiveIdle = false
    for (i in 0..19) {
        Thread.sleep(1000)
        val now = System.currentTimeMillis()
        val hots = tr.feed(now, P.selfThreadTicks(names), names)
        val v = StallLogic.classify(hots)
        if (hots.any { it.name == "idle-thread" }) falsePositiveIdle = true
        if (v.kind == StallLogic.Kind.AUDIO_RUNAWAY && firstAt < 0) firstAt = (now - t0) / 1000
        if (i % 4 == 0) println("t=" + (i + 1) + "s hots=" + hots.joinToString { it.name + ":" + it.busyPct + "pct/" + it.streakMs / 1000 + "s" } + " kind=" + v.kind)
    }
    stop.set(true)
    println("comm doc duoc tu /proc: " + names.values.filter { it.contains("Audio") || it.contains("idle") })
    println("phat hien AUDIO_RUNAWAY lan dau o giay thu: " + firstAt)
    println("bao oan luong ranh: " + falsePositiveIdle)
    if (firstAt < 15 || firstAt > 19 || falsePositiveIdle) { println("FAIL"); System.exit(1) } else println("PASS")
}
