import com.colablive.keeper.core.StallLogic
import com.colablive.keeper.core.StallLogic.HotTracker
import com.colablive.keeper.core.StallLogic.Kind
import com.colablive.keeper.core.StallLogic.Probe
import com.colablive.keeper.core.StallLogic.Action

var fails = 0; var total = 0
fun check(name: String, ok: Boolean) { total++; if (!ok) { fails++; println("FAIL: $name") } else println("ok:   $name") }

fun classify(h: List<StallLogic.Hot>) = StallLogic.classify(h)
fun decide(k: Kind, p: Probe, n: Int) = StallLogic.decide(k, p, n)

fun main() {
    val names = mapOf(10 to "AudioIPC Server", 11 to "AndroidUI", 12 to "Gecko", 13 to "RenderThread")
    // 1. Số liệu THẬT từ log: 2960ms trong 2976ms => ~99%; ticks=100/s. Mô phỏng cửa sổ 5s.
    run {
        val tr = HotTracker(100)
        var a = 0L
        var kinds = ArrayList<Kind>()
        for (step in 0..4) {
            val t = step * 5000L
            a = (step * 5000L * 99 / 100) / 10   // 99% => ticks cộng dồn
            val hots = tr.feed(t, mapOf(10 to a, 11 to step * 20L, 12 to 0L), names)
            kinds.add(classify(hots).kind)
        }
        println(kinds)
        check("1a. 2 cửa sổ đầu (10s) chưa đủ 15s => NONE", kinds[1] == Kind.NONE && kinds[0] == Kind.NONE)
        check("1b. cửa sổ thứ 3 (15s) => AUDIO_RUNAWAY", kinds[3] == Kind.AUDIO_RUNAWAY)
        check("1c. còn tiếp tục => AUDIO_RUNAWAY", kinds[4] == Kind.AUDIO_RUNAWAY)
    }
    // 2. Nóng 10s rồi nguội => dải bị cắt, nóng lại phải đếm từ đầu
    run {
        val tr = HotTracker(100)
        val seq = listOf(0L to 0L, 5000L to 495L, 10000L to 990L, 15000L to 1000L /*nguội*/, 20000L to 1495L /*nóng lại*/, 25000L to 1990L)
        val res = seq.map { (t, a) -> classify(tr.feed(t, mapOf(10 to a), names)).kind }
        println(res)
        check("2a. nóng 10s rồi nguội không báo", res[2] == Kind.NONE && res[3] == Kind.NONE)
        check("2b. nóng lại chỉ mới 10s => chưa báo", res[5] == Kind.NONE)
    }
    // 3. AndroidUI/RenderThread nóng 60s không bị coi là quay vòng
    run {
        val tr = HotTracker(100)
        var last = Kind.NONE
        for (s in 0..12) last = classify(tr.feed(s * 5000L, mapOf(11 to s * 500L, 13 to s * 480L), names)).kind
        check("3. giao diện/vẽ bận 60s => NONE", last == Kind.NONE)
    }
    // 4. Luồng lạ nóng 45s => OTHER; chưa tới 45s => NONE
    run {
        val tr = HotTracker(100)
        val ks = (0..10).map { s -> classify(tr.feed(s * 5000L, mapOf(12 to s * 495L), names)).kind }
        check("4a. 40s chưa báo", ks[8] == Kind.NONE)
        check("4b. 45s báo OTHER_RUNAWAY", ks[9] == Kind.OTHER_RUNAWAY)
    }
    // 5. Luồng mới xuất hiện giữa chừng không bị tính dải cũ; luồng biến mất bị xoá
    run {
        val tr = HotTracker(100)
        tr.feed(0, mapOf(10 to 0L), names)
        tr.feed(5000, mapOf(10 to 495L), names)
        val h = tr.feed(10000, mapOf(99 to 5000L, 10 to 990L), names) // tid 99 mới => bỏ qua cửa sổ này
        check("5a. tid mới không có mẫu trước => không nóng", h.none { it.tid == 99 })
        val h2 = tr.feed(15000, mapOf(99 to 5495L), names) // tid 10 biến mất
        check("5b. tid 99 nóng 1 cửa sổ, tid 10 đã biến mất", h2.size == 1 && h2[0].tid == 99 && h2[0].streakMs == 5000L)
        val h3 = tr.feed(20000, mapOf(10 to 1500L, 99 to 5495L), names)  // tid 10 quay lại => dải bắt đầu mới
        check("5c. tid 10 quay lại không thừa hưởng dải cũ", h3.none { it.tid == 10 })
    }
    // 6. Bảng quyết định
    check("6a. NONE => NONE", decide(Kind.NONE, Probe.NO_RESPONSE, 5) == Action.NONE)
    check("6b. quay + chưa thăm dò => PROBE", decide(Kind.AUDIO_RUNAWAY, Probe.NOT_RUN, 0) == Action.PROBE)
    check("6c. quay + trang vẫn trả lời => NONE (không khởi động lại oan)", decide(Kind.AUDIO_RUNAWAY, Probe.RESPONDED, 3) == Action.NONE)
    check("6d. quay + trang im => đếm ngược tự khởi động lại", decide(Kind.AUDIO_RUNAWAY, Probe.NO_RESPONSE, 0) == Action.AUTO_RESTART_COUNTDOWN)
    check("6e. luồng khác + trang im => chỉ mời", decide(Kind.OTHER_RUNAWAY, Probe.NO_RESPONSE, 0) == Action.OFFER_RESTART)
    check("6f. không thăm dò được + không eval nào quá hạn => NONE", decide(Kind.AUDIO_RUNAWAY, Probe.CANNOT, 0) == Action.NONE)
    check("6g. không thăm dò được + có eval quá hạn => hành động", decide(Kind.AUDIO_RUNAWAY, Probe.CANNOT, 1) == Action.AUTO_RESTART_COUNTDOWN)
    main2()
}

fun main2() {
    // 7. rankVictims: tab20 tăng 728→1040MB phải đứng đầu dù tab29 lớn hơn lúc đầu
    val start = mapOf(20 to 728_000L, 29 to 765_000L)
    val now = listOf(StallLogic.Proc("tab29", 29, 770_000L), StallLogic.Proc("tab20", 20, 1_040_000L), StallLogic.Proc("tab5", 5, 100_000L))
    val r = StallLogic.rankVictims(start, now)
    check("7a. tiến trình RSS tăng nhiều nhất đứng đầu", r[0].label == "tab20")
    check("7b. hoà tăng => RSS lớn hơn trước", r[1].label == "tab29" && r[2].label == "tab5")
    val r2 = StallLogic.rankVictims(emptyMap(), now)
    check("7c. không có mốc đầu => theo RSS giảm dần", r2.map { it.label } == listOf("tab20", "tab29", "tab5"))
    // 8. summarizeSyscalls
    val s64 = StallLogic.summarizeSyscalls(listOf("running", "22 0x5 0x7 0x20 0xffffffff 0x0 0x0 0x7ff 0x7e", "22 0x5", "running", "running", "-1 0x7ff 0x7e", "98 0x1"), true)
    println(s64)
    check("8a. nhận ra epoll_pwait(22)×2 và running×3 (64-bit)", s64.contains("running×3") && s64.contains("epoll_pwait(22)×2") && s64.contains("futex(98)×1") && s64.contains("không-trong-syscall×1"))
    val s32 = StallLogic.summarizeSyscalls(listOf("252 0x1", "252 0x2", "running"), false)
    check("8b. 32-bit: epoll_wait(252)", s32.contains("epoll_wait(252)×2") && s32.contains("32-bit"))
    check("8c. không mẫu", StallLogic.summarizeSyscalls(emptyList(), true) == "không có mẫu")
    check("8d. số lạ giữ nguyên số", StallLogic.summarizeSyscalls(listOf("9999 0x0"), true).contains("sys(9999)×1"))
    main3()
}

fun main3() {
    // 9. lifecycleSummary — phát lại log 19/11: ra nền 1208s rồi quay lại, ~63s sau thì đơ
    val t0 = 1_000_000L
    val ev = listOf(Pair(t0, false), Pair(t0 + 1_208_000L, true))
    val s = StallLogic.lifecycleSummary(ev, t0 + 1_208_000L + 63_000L)
    println(s)
    check("9a. đang ở trước, quay lại cách 63s", s.contains("đang ở TRƯỚC") && s.contains("63s"))
    check("9b. ghi được lần ra nền ngay trước kéo dài 1208s", s.contains("kéo dài 1208s") && s.contains("ở nền"))
    check("9c. đếm vòng trong 5 phút (chỉ 1 sự kiện trong 5p)", s.contains("1 lần đổi"))
    // log 18/11 23:29:45–23:30:57: 4 vòng ra/vào nền trong ~70s
    val b = 5_000_000L
    val ev2 = listOf(b to false, b + 2_000 to true, b + 15_000 to false, b + 20_000 to true, b + 24_000 to false, b + 28_000 to true)
    val s2 = StallLogic.lifecycleSummary(ev2, b + 72_000L)
    check("9d. phát hiện nhiều vòng ra/vào nền (6 lần đổi)", s2.contains("6 lần đổi"))
    check("9e. không có sự kiện", StallLogic.lifecycleSummary(emptyList(), 1L).contains("chưa có"))
    val s3 = StallLogic.lifecycleSummary(listOf(b to true), b + 400_000L)
    check("9f. sự kiện quá 5 phút không tính", s3.contains("0 lần đổi"))
    println("\n$total kiểm tra, $fails lỗi")
    if (fails > 0) System.exit(1)
}
