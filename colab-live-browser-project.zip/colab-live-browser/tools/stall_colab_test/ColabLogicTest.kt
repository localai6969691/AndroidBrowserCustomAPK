import com.colablive.keeper.features.colab.ColabLogic

var fails = 0; var total = 0
fun check(name: String, ok: Boolean) { total++; if (!ok) { fails++; println("FAIL: $name") } else println("ok:   $name") }
fun t(h: Int, m: Int, s: Int) = ((h * 60L + m) * 60L + s) * 1000L

fun main() {
    // --- Phát lại log THẬT 08:40–10:01 ---
    // 1. Nhãn: tab f471f19e (disconnected, chưa từng kết nối) vs tab ae23cb46 (running) => phải chọn ae23cb46 đang chạy
    val rNever = ColabLogic.rank("disconnected", false)
    val rRunning = ColabLogic.rank("running", true)
    check("1a. running thắng 'disconnected' của tab chưa từng kết nối (nhãn 08:41:52 trước đây SAI)", rRunning < rNever)
    check("1b. silent KHÔNG đè được running (nhãn 08:47–10:01 trước đây SAI)", rRunning < ColabLogic.rank("silent", true))
    check("1c. silent KHÔNG đè được idle", ColabLogic.rank("idle", true) < ColabLogic.rank("silent", true))
    check("1d. lỗi thật vẫn thắng running", ColabLogic.rank("error", true) < rRunning && ColabLogic.rank("crashed", true) < ColabLogic.rank("error", true))
    check("1e. disconnected của tab ĐÃ từng kết nối vẫn nổi bật nhất sau crashed", ColabLogic.rank("disconnected", true) == 1)
    check("1f. chỉ còn tab im lặng thì vẫn hiện silent (hơn unknown)", ColabLogic.rank("silent", true) < ColabLogic.rank("unknown", true))

    // 2. Tab f471f19e: 321s không tín hiệu (08:47:05) => KHÔNG được thành silent (chưa từng everOk)
    check("2. tab chưa từng kết nối không bao giờ 'silent' (08:47:05)", !ColabLogic.shouldMarkSilent(t(8,47,5), t(8,41,44), 99, false, false))

    // 3. Tab ae23cb46: tín hiệu cuối 08:49:18; 08:54:36 = 318s
    check("3a. 318s im nhưng chưa hỏi lần nào => KHÔNG báo (trước đây báo KHÔNG PHẢN HỒI lúc 08:54:36)", !ColabLogic.shouldMarkSilent(t(8,54,36), t(8,49,18), 0, true, false))
    check("3b. 318s im, mới hỏi hỏng 2 lần => chưa báo", !ColabLogic.shouldMarkSilent(t(8,54,36), t(8,49,18), 2, true, false))
    check("3c. 318s im, hỏi hỏng 3 lần liên tiếp => im lặng thật", ColabLogic.shouldMarkSilent(t(8,54,36), t(8,49,18), 3, true, false))
    check("3d. chưa tới 5 phút dù hỏi hỏng => chưa", !ColabLogic.shouldMarkSilent(t(8,53,0), t(8,49,18), 5, true, false))
    check("3e. trình duyệt đang đơ => không đổ cho Colab", !ColabLogic.shouldMarkSilent(t(9,7,7), t(9,1,49), 9, true, true))
    check("3f. lần hỏi hỏng lúc trình duyệt đơ không được đếm", !ColabLogic.countsAsPollFailure(true) && ColabLogic.countsAsPollFailure(false))

    // 4. Lịch hỏi
    check("4a. ở nền, chưa hỏi bao giờ => hỏi", ColabLogic.shouldPoll(t(8,50,0), 0L, t(8,49,18), true))
    check("4b. ở nền, vừa hỏi 30s trước => chưa", !ColabLogic.shouldPoll(t(8,50,30), t(8,50,0), t(8,50,0), true))
    check("4c. ở nền, hỏi 60s trước => hỏi", ColabLogic.shouldPoll(t(8,51,0), t(8,50,0), t(8,50,0), true))
    check("4d. đang xem, tín hiệu tươi 20s => không hỏi (tránh thêm tải cho trang)", !ColabLogic.shouldPoll(t(8,50,20), 0L, t(8,50,0), false))
    check("4e. đang xem, 2 phút không tín hiệu => hỏi", ColabLogic.shouldPoll(t(8,52,0), 0L, t(8,50,0), false))

    // 5. Máy trạng thái lượt chạy — phát lại chuỗi trạng thái thật của tab ae23cb46
    val rt = ColabLogic.RunTracker()
    var done = ArrayList<String>()
    val seq = listOf(
        t(8,43,21) to "idle", t(8,43,42) to "connecting", t(8,44,30) to "running", t(8,45,58) to "idle",   // xong thật lúc 08:45:58
        t(8,49,18) to "running", t(8,54,36) to "silent", t(8,55,18) to "running", t(9,7,7) to "silent",
        t(10,0,10) to "idle",                                                                                // silent -> idle: TRƯỚC ĐÂY không báo xong
        t(10,0,30) to "connecting", t(10,0,50) to "disconnected", t(10,1,52) to "connecting")
    for ((at, s) in seq) { if (rt.observe(s, at)) done.add("xong@" + at / 1000) }
    println(done)
    check("5a. báo xong đúng 2 lần (08:45:58 và 10:00:10)", done == listOf("xong@${t(8,45,58)/1000}", "xong@${t(10,0,10)/1000}"))
    // 5b. chạy xong qua im lặng => gapDuringRun
    val r2 = ColabLogic.RunTracker()
    r2.observe("running", t(8,49,18)); r2.observe("silent", t(8,54,36))
    check("5b. nhớ có lúc im lặng giữa lượt chạy", r2.pending && r2.gapDuringRun && r2.startedAt == t(8,49,18))
    check("5c. silent -> idle báo xong", r2.observe("idle", t(10,0,10)) && !r2.pending)
    // 5d. lượt chạy hỏng thì không báo xong
    val r3 = ColabLogic.RunTracker()
    r3.observe("running", 1L)
    check("5d. running -> crashed -> idle không báo 'xong'", !r3.observe("crashed", 2L) && !r3.observe("idle", 3L))
    // 5e. idle liên tiếp không báo xong khi chưa chạy
    val r4 = ColabLogic.RunTracker()
    check("5e. idle khi chưa từng chạy không báo xong", !r4.observe("idle", 1L) && !r4.observe("idle", 2L))
    // 5f. running -> connecting -> idle vẫn tính xong
    val r5 = ColabLogic.RunTracker()
    r5.observe("running", 1L); r5.observe("connecting", 2L)
    check("5f. running -> connecting -> idle vẫn báo xong", r5.observe("idle", 3L))

    println("\n$total kiểm tra, $fails lỗi")
    if (fails > 0) System.exit(1)
}
