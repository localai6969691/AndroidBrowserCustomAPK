import com.colablive.keeper.core.LogChunk
var fails = 0; var total = 0
fun check(n: String, ok: Boolean) { total++; if (!ok) { fails++; println("FAIL: $n") } else println("ok:   $n") }
fun main() {
    val short = "Khe 0: [đơ-watchdog] ngắn"
    check("1. dòng ngắn giữ nguyên", LogChunk.split(short) == listOf(short))
    // Mô phỏng ĐÚNG cấu trúc dòng [CHẨN ĐOÁN ĐƠ] ~2100 ký tự có MemEvidence ở CUỐI
    val head = "Khe 0: [tải lại][CHẨN ĐOÁN ĐƠ] tab=74f52a9d onPageStart(tab) 4→4 (không tăng) | list()=TRẢ VỀ sau 12ms | eval=CHƯA trả về sau 3s"
    val sys = (1..7).joinToString(" | ") { "tiến trình$it: chính(pid=${1000 + it},imp=100) State=S (sleeping) Threads=99 VmRSS=672052 kB cgroup=[0::/uid_10574/pid_$it]" } + " | " + "x".repeat(300)
    val mem = "bộ nhớ hệ thống: MemAvailable=4421MB SwapFree=0MB | PSI: some avg10=0.00 avg60=0.00 | nhân Δpgmajfault=12 Δpswpin=0 Δpswpout=0"
    val full = "$head | $sys | $mem"
    println("độ dài gốc = ${full.length}")
    val parts = LogChunk.split(full)
    println("số mảnh = ${parts.size}; độ dài lớn nhất = ${parts.maxOf { it.length }}")
    check("2a. mọi mảnh <= 1500 (ngưỡng cắt của DebugLog)", parts.all { it.length <= 1500 })
    check("2b. nhiều hơn 1 mảnh", parts.size >= 2)
    check("2c. PHẦN BỘ NHỚ Ở CUỐI vẫn còn nguyên (trước đây bị cắt mất)", parts.last().contains("PSI: some avg10=0.00") && parts.last().contains("Δpswpin=0"))
    check("2d. mảnh nào cũng mang nhãn để lọc", parts.all { it.startsWith("Khe 0: [tải lại][CHẨN ĐOÁN ĐƠ] (") })
    // ghép lại không mất chữ: bỏ tiền tố, nối bằng ' | ' rồi so với thân gốc
    val body = full.removePrefix("Khe 0: [tải lại][CHẨN ĐOÁN ĐƠ] ")
    val strip = Regex("^Khe \\d+: \\[[^\\]]+\\](\\[[^\\]]+\\])? \\(\\d+/\\d+\\) ")
    val rebuilt = parts.joinToString(" | ") { it.replace(strip, "") }
    check("2e. ghép lại đủ nội dung gốc (không mất, không thừa ký tự)", rebuilt.replace(" | ", "") == body.replace(" | ", ""))
    check("2f. không bẻ đôi mục ngắn ở giữa (mục 'PSI: ...' nằm trọn trong một mảnh)", parts.count { it.contains("PSI: some avg10") } == 1 && parts.count { it.contains("nhân Δpgmajfault=12") } == 1)
    // mục một mình dài hơn ngưỡng => cắt cứng nhưng không mất
    val big = "Khe 1: [đơ-watchdog] " + "y".repeat(4000)
    val bp = LogChunk.split(big)
    check("3a. mục quá dài bị cắt cứng, mọi mảnh <=1500", bp.size >= 3 && bp.all { it.length <= 1500 })
    check("3b. tổng số 'y' giữ nguyên 4000", bp.sumOf { p -> p.count { it == 'y' } } == 4000)
    // không có nhãn
    val nolabel = "z".repeat(3000)
    val np = LogChunk.split(nolabel)
    check("4. không nhãn vẫn chia được và không mất chữ", np.size >= 3 && np.sumOf { p -> p.count { it == 'z' } } == 3000 && np.all { it.length <= 1500 })
    println("\n$total kiểm tra, $fails lỗi"); if (fails > 0) System.exit(1)
}
