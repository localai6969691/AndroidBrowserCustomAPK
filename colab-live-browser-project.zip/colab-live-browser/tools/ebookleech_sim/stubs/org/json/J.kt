package org.json
class JSONException(m: String?) : Exception(m)
class JSONObject() {
    val m = LinkedHashMap<String, Any?>()
    constructor(s: String) : this() { val p = Parser(s); val v = p.value(); if (v !is JSONObject) throw JSONException("not obj"); m.putAll(v.m) }
    fun put(k: String, v: Any?): JSONObject { m[k] = v; return this }
    fun has(k: String) = m.containsKey(k)
    fun remove(k: String): Any? = m.remove(k)
    fun keys(): Iterator<String> = m.keys.toList().iterator()
    fun optDouble(k: String, d: Double = Double.NaN): Double = (m[k] as? Number)?.toDouble() ?: d
    fun length() = m.size
    fun opt(k: String): Any? = m[k]
    fun optString(k: String): String = (m[k] as? String) ?: if (m[k] == null) "" else m[k].toString()
    fun optString(k: String, d: String): String = if (m.containsKey(k) && m[k] != null) m[k].toString() else d
    @JvmName("optStringN") fun optString(k: String, d: String?): String? = if (m.containsKey(k) && m[k] != null) m[k].toString() else d
    constructor(src: Map<*, *>) : this() { for ((k, v) in src) m[k.toString()] = v }
    fun getLong(k: String): Long = (m[k] as? Number)?.toLong() ?: throw JSONException("no $k")
    fun getJSONArray(k: String): JSONArray = m[k] as? JSONArray ?: throw JSONException("no $k")
    fun optInt(k: String, d: Int = 0): Int = (m[k] as? Number)?.toInt() ?: d
    fun optLong(k: String, d: Long = 0L): Long = (m[k] as? Number)?.toLong() ?: d
    fun optBoolean(k: String, d: Boolean = false): Boolean = (m[k] as? Boolean) ?: d
    fun optJSONArray(k: String): JSONArray? = m[k] as? JSONArray
    fun optJSONObject(k: String): JSONObject? = m[k] as? JSONObject
    fun getString(k: String): String = m[k]?.toString() ?: throw JSONException("no $k")
    fun getInt(k: String): Int = (m[k] as? Number)?.toInt() ?: throw JSONException("no $k")
    fun getJSONObject(k: String): JSONObject = m[k] as? JSONObject ?: throw JSONException("no $k")
    override fun toString(): String = "{" + m.entries.joinToString(",") { quote(it.key) + ":" + ser(it.value) } + "}"
    companion object {
        @JvmField val NULL: Any = Any()
        @JvmStatic fun quote(s: String?): String {
            val sb = StringBuilder("\"")
            for (c in (s ?: "")) when (c) { '"' -> sb.append("\\\""); '\\' -> sb.append("\\\\"); '\n' -> sb.append("\\n"); '\r' -> sb.append("\\r"); '\t' -> sb.append("\\t"); else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c) }
            return sb.append('"').toString()
        }
        fun ser(v: Any?): String = when (v) { null -> "null"; is String -> quote(v); is JSONObject -> v.toString(); is JSONArray -> v.toString(); else -> v.toString() }
    }
}
class JSONArray() {
    val l = ArrayList<Any?>()
    constructor(c: Collection<*>) : this() { l.addAll(c) }
    constructor(s: String) : this() { val v = Parser(s).value(); if (v !is JSONArray) throw JSONException("not arr"); l.addAll(v.l) }
    fun length() = l.size
    fun getString(i: Int): String = l[i].toString()
    fun getInt(i: Int): Int = (l[i] as? Number)?.toInt() ?: throw JSONException("no int")
    fun getJSONObject(i: Int): JSONObject = l[i] as? JSONObject ?: throw JSONException("no obj")
    fun put(v: Any?): JSONArray { l.add(v); return this }
    fun opt(i: Int): Any? = l.getOrNull(i)
    override fun toString(): String = "[" + l.joinToString(",") { JSONObject.ser(it) } + "]"
}
class JSONTokener(val s: String) { fun nextValue(): Any? = Parser(s).value() }
class Parser(val s: String) {
    var i = 0
    fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
    fun value(): Any? {
        ws()
        if (i >= s.length) throw JSONException("eof")
        return when (val c = s[i]) {
            '{' -> { i++; val o = JSONObject(); ws(); if (s[i] == '}') { i++; return o }
                while (true) { ws(); val k = str(); ws(); if (s[i] != ':') throw JSONException("colon"); i++; o.put(k, value()); ws(); if (s[i] == ',') { i++; continue }; if (s[i] == '}') { i++; break }; throw JSONException("obj") }; o }
            '[' -> { i++; val a = JSONArray(); ws(); if (s[i] == ']') { i++; return a }
                while (true) { a.put(value()); ws(); if (s[i] == ',') { i++; continue }; if (s[i] == ']') { i++; break }; throw JSONException("arr") }; a }
            '"' -> str()
            't' -> { i += 4; true } 'f' -> { i += 5; false } 'n' -> { i += 4; JSONObject.NULL }
            else -> { val st = i; while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++; val t = s.substring(st, i); if (t.isEmpty()) throw JSONException("bad $c"); if (t.contains('.') || t.contains('e') || t.contains('E')) t.toDouble() else (t.toLongOrNull() ?: t.toDouble()) }
        }
    }
    fun str(): String {
        if (s[i] != '"') throw JSONException("str"); i++
        val sb = StringBuilder()
        while (s[i] != '"') { var c = s[i++]; if (c == '\\') { c = s[i++]; when (c) { 'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r'); 'u' -> { sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }; else -> sb.append(c) } } else sb.append(c) }
        i++; return sb.toString()
    }
}
