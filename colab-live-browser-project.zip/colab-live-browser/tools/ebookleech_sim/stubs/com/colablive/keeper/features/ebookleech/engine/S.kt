package com.colablive.keeper.features.ebookleech.engine
import android.content.Context
import com.colablive.keeper.features.ebookleech.model.*
object ProxyPoolManager { fun rotateToNext(c: Context, s: Int) {} }
object ImageDownloader {
    fun processChapterImages(html: String, chapterIndex: Int, userAgent: String, maxImages: Int): Pair<String, List<LeechImage>> = Pair(html, emptyList())
    // Bản 7.104: bìa giả — chỉ URL kết thúc bằng cover.jpg tải được; đếm số lần gọi để kiểm "không tải lại khi URL bìa không đổi".
    var coverCalls = 0
    val coverReferers = ArrayList<String>()
    fun downloadCover(coverUrl: String, userAgent: String, referer: String): Pair<ByteArray, String>? {
        coverCalls++; coverReferers.add(referer)
        return if (coverUrl.endsWith("cover.jpg")) Pair(byteArrayOf(1, 2, 3, 4, 5), "image/jpeg") else null
    }
}
class PubResult(val success: Boolean, val postUrl: String?, val error: String?)
object WordPressPublisher { fun publishChapter(job: LeechJob, ch: LeechChapter, name: String): PubResult = PubResult(true, null, null) }
