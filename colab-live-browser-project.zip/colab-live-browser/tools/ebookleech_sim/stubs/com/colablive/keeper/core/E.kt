package com.colablive.keeper.core
class BrowserTab(val id: String)
class GeckoViewEngine {
    fun getActiveTab(): BrowserTab? = null
    fun createTab(url: String = "about:blank", isPrivate: Boolean = false, openerTabId: String? = null): BrowserTab = BrowserTab("x")
    fun closeTab(tabId: String) {}
    fun switchToTab(tabId: String) {}
    fun getTabs(): List<BrowserTab> = emptyList()
    fun loadUrl(url: String) {}
    fun evaluateJs(js: String, cb: (String?) -> Unit) {}
}
