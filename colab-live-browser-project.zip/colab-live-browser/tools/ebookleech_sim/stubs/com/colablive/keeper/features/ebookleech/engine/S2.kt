package com.colablive.keeper.features.ebookleech.engine
import com.colablive.keeper.core.GeckoViewEngine
object FakeWeb {
    var handler: (String, String, (String) -> Unit, (String) -> Unit) -> Unit = { _, _, _, e -> e("no handler") }
    val requested = ArrayList<String>()
}
fun GeckoViewEngine.evaluateJsOnTab(crawlTabId: String, url: String, js: String, timeoutMs: Long = 15_000L, installAjaxPatchFirst: Boolean = false, scrollAttempts: Int = 0, onResult: (String) -> Unit, onError: (String) -> Unit) {
    FakeWeb.requested.add(url); FakeWeb.handler(url, js, onResult, onError)
}
