package com.colablive.keeper.features.ebookleech.export
import android.content.Context
import com.colablive.keeper.features.ebookleech.model.*
object Rec { var exported: List<LeechChapter> = emptyList(); var calls = 0 }
// Ghi một file THẬT để canSkipExport() kiểm "file ebook cũ còn không" như trên máy; tên chứa định dạng để thử đổi định dạng.
object EbookExporter { fun export(c: Context, job: LeechJob, ch: List<LeechChapter>): String {
    Rec.exported = ch.toList(); Rec.calls++
    val f = java.io.File(c.filesDir, "out_${job.id}_${job.outputFormat.name}.bin"); f.writeText("x"); return f.absolutePath } }
