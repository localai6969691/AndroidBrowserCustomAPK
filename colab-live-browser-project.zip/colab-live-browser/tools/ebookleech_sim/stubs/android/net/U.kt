package android.net
class Uri { companion object { fun parse(s: String): Uri = Uri() } }
