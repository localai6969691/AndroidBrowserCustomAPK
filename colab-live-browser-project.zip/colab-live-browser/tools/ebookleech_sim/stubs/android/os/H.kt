package android.os
class Looper { companion object { fun getMainLooper(): Looper = Looper(); fun myLooper(): Looper? = null } }
object Q { val q = java.util.concurrent.LinkedBlockingQueue<Runnable>() }
class Handler(l: Looper) {
    fun post(r: Runnable): Boolean { Q.q.add(r); return true }
    fun postDelayed(r: Runnable, d: Long): Boolean { Q.q.add(r); return true }
    fun removeCallbacks(r: Runnable) { Q.q.remove(r) }
}
