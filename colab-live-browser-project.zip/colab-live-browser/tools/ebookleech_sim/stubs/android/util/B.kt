package android.util
/** Stub JVM của android.util.Base64 (chỉ các hàm GitHubApiClient dùng). */
object Base64 {
    const val DEFAULT = 0
    const val NO_WRAP = 2
    fun encodeToString(b: ByteArray, flags: Int): String = java.util.Base64.getEncoder().encodeToString(b)
    fun decode(s: String, flags: Int): ByteArray = java.util.Base64.getMimeDecoder().decode(s)
}
