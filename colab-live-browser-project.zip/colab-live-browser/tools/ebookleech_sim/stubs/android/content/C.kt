package android.content
class SimResolver { fun openInputStream(u: android.net.Uri): java.io.InputStream? = null }
open class Context { val filesDir: java.io.File = java.io.File(System.getProperty("sim.dir") ?: "/tmp/sim"); val contentResolver = SimResolver() }
