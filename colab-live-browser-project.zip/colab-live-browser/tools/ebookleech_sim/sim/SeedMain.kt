import com.colablive.keeper.features.ebookleech.remote.ArchiveSeed
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

var fails = 0
fun check(name: String, cond: Boolean, extra: String = "") { if (!cond) fails++; println((if (cond) "PASS " else "FAIL ") + name + (if (!cond) "  -> $extra" else "")) }

fun ch(i: Int, vararg imgs: String, url: String = "https://x/c$i"): JSONObject = JSONObject().put("index", i).put("title", "Chương $i").put("htmlContent", "<p>Nội dung $i</p>").put("textContent", "Nội dung $i")
    .put("sourceUrl", url).put("images", JSONArray().also { a -> imgs.forEach { a.put(JSONObject().put("originalUrl", "https://x/$it").put("localFileName", it).put("mimeType", "image/jpeg")) } })

fun main(args: Array<String>) {
    val out = File(args[0]); out.mkdirs()
    val sizes = mapOf("a.jpg" to 100L, "b.jpg" to 200L, "c.jpg" to 300L, "gone.jpg" to -1L)
    val size = { n: String -> sizes[n] ?: -1L }
    fun arr(vararg c: JSONObject) = JSONArray().also { a -> c.forEach { a.put(it) } }
    val order = listOf("https://x/c1", "https://x/c2", "https://x/c3", "https://x/c4", "https://x/c5", "https://x/c6")

    // 1) bình thường: ảnh dùng chung 1 lần, chương thiếu ảnh bị loại, chương không URL bị loại
    val s1 = ArchiveSeed.build(arr(ch(1), ch(2, "a.jpg", "b.jpg"), ch(3, "a.jpg"), ch(4, "gone.jpg"), ch(5, url = ""), ch(6)), order, 6, 3, JSONObject().put("author", "Tg"), size)
    val j1 = JSONObject(s1.json)
    check("S1 gieo 4 chương (1,2,3,6), loại 2 (thiếu ảnh, không URL)", s1.included == 4 && s1.excluded == 2 && j1.getJSONArray("chaptersSoFar").length() == 4, "${s1.included}/${s1.excluded}")
    check("S1 ảnh dùng chung đếm 1 lần: a.jpg,b.jpg = 300 byte", s1.imageNames == listOf("a.jpg", "b.jpg") && s1.imageBytes == 300L, "${s1.imageNames} ${s1.imageBytes}")
    check("S1 giữ thứ tự danh sách đầy đủ + điểm neo + thông tin truyện", j1.getJSONArray("chapterLinks").length() == 6 && j1.getJSONObject("listScan").getInt("lastPage") == 6 && j1.getJSONObject("listScan").getInt("fastStreak") == 3 && j1.getJSONObject("storyMeta").getString("author") == "Tg")
    File(out, "seed1.json").writeText(s1.json, Charsets.UTF_8)

    // 2) hạn mức số ảnh = 2: chương 2 (2 ảnh) vào, chương 3 dùng lại a.jpg (đã có) vẫn vào, chương có ảnh mới c.jpg bị loại
    val s2 = ArchiveSeed.build(arr(ch(1), ch(2, "a.jpg", "b.jpg"), ch(3, "a.jpg"), ch(4, "c.jpg"), ch(6)), order, 0, 0, null, size, maxImageFiles = 2)
    check("S2 hạn mức 2 ảnh: loại chương cần ảnh thứ 3, chương dùng lại ảnh cũ vẫn vào", s2.included == 4 && s2.excluded == 1 && s2.imageNames == listOf("a.jpg", "b.jpg") && !s2.json.contains("\"https://x/c4\"\"") , "${s2.included} ${s2.imageNames}")
    check("S2 chương bị loại không nằm trong JSON gieo", JSONObject(s2.json).getJSONArray("chaptersSoFar").let { a -> (0 until a.length()).none { a.getJSONObject(it).getInt("index") == 4 } })

    // 3) hạn mức byte ảnh
    val s3 = ArchiveSeed.build(arr(ch(1, "a.jpg"), ch(2, "b.jpg"), ch(3, "c.jpg")), order, 3, 0, null, size, maxImageBytes = 350)
    check("S3 hạn mức 350 byte: a(100)+b(200) vào, c(300) bị loại", s3.included == 2 && s3.excluded == 1 && s3.imageBytes == 300L, "${s3.included} ${s3.imageBytes}")

    // 4) hạn mức dung lượng JSON: chương nào làm vượt thì loại (các chương sau nhỏ hơn vẫn có thể vào)
    val big = ch(2).put("htmlContent", "x".repeat(20_000))
    val s4 = ArchiveSeed.build(arr(ch(1), big, ch(3)), order, 3, 0, null, size, maxJsonBytes = 10_000)
    check("S4 hạn mức JSON: chương 2 (20KB) bị loại, 1 và 3 vào", s4.included == 2 && s4.excluded == 1 && s4.json.length < 10_000, "${s4.included} ${s4.json.length}")

    // 5) rỗng / không chương nào đủ điều kiện
    val s5 = ArchiveSeed.build(arr(ch(4, "gone.jpg")), order, 1, 0, null, size)
    check("S5 không chương nào đủ điều kiện => included = 0 (người gọi bỏ qua việc gieo)", s5.included == 0 && s5.excluded == 1)
    val s6 = ArchiveSeed.build(JSONArray(), emptyList(), 0, 0, null, size)
    check("S6 kho rỗng => included = 0", s6.included == 0 && JSONObject(s6.json).getJSONArray("chapterLinks").length() == 0)
    println(if (fails == 0) "ALL PASS" else "FAILS=$fails")
    System.exit(if (fails == 0) 0 else 1)
}
