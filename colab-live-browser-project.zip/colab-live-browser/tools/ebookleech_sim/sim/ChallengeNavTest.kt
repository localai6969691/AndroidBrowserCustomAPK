import com.colablive.keeper.core.ChallengeNav

var fails = 0
fun check(name: String, cond: Boolean, extra: String = "") { if (!cond) fails++; println((if (cond) "PASS " else "FAIL ") + name + (if (!cond) "  -> $extra" else "")) }
class FakeReq(@JvmField val isDirectNavigation: Boolean, @JvmField val isRedirect: Boolean, @JvmField val triggerUri: String?, @JvmField val hasUserGesture: Boolean = false)
class NoFieldsReq

fun main() {
    val chat = "https://claude.ai/chat/8439c9b9-5b1a-495d-bddd-0f5b2838105e"
    val ch = "https://claude.ai/api/challenge_redirect?to=https%3A%2F%2Fclaude.ai%2Fchat%2F8439c9b9-5b1a-495d-bddd-0f5b2838105e"
    check("nhận diện challenge_redirect", ChallengeNav.isChallengeUrl(ch))
    check("không nhầm trang chat thường", !ChallengeNav.isChallengeUrl(chat))
    check("trang quay về sau thử thách (__cf_chl_rt_tk) KHÔNG bị coi là điểm khởi đầu", !ChallengeNav.isChallengeUrl("$chat?__cf_chl_rt_tk=abc-1.0.1.1-xyz"))
    check("chuỗi 'challenge_redirect' chỉ nằm trong query không tính", !ChallengeNav.isChallengeUrl("https://x.com/page?next=/api/challenge_redirect"))
    check("URL hỏng không ném lỗi", !ChallengeNav.isChallengeUrl("ht!tp://%%%"))
    check("đích lấy từ to= (giải mã %xx)", ChallengeNav.targetOf(ch, "fallback") == chat, ChallengeNav.targetOf(ch, "fallback") ?: "null")
    check("to= khác host bị bỏ => dùng fallback", ChallengeNav.targetOf("https://claude.ai/api/challenge_redirect?to=https%3A%2F%2Fevil.com%2Fx", "fb") == "fb")
    check("to= dùng http (không https) bị bỏ => fallback", ChallengeNav.targetOf("https://claude.ai/api/challenge_redirect?to=http%3A%2F%2Fclaude.ai%2Fx", "fb") == "fb")
    check("to= là javascript: bị bỏ => fallback", ChallengeNav.targetOf("https://claude.ai/api/challenge_redirect?to=javascript%3Aalert(1)", "fb") == "fb")
    check("không có to= => fallback; fallback null => null", ChallengeNav.targetOf("https://claude.ai/api/challenge_redirect", "fb") == "fb" && ChallengeNav.targetOf("https://claude.ai/api/challenge_redirect", null) == null)
    // bảng chân trị hoãn
    check("HOÃN: bật + tab nền + không ghim + do TRANG", ChallengeNav.shouldDefer(true, false, false, false))
    check("không hoãn khi đang xem", !ChallengeNav.shouldDefer(true, true, false, false))
    check("không hoãn khi tab ghim chạy nền (người dùng chủ động giữ)", !ChallengeNav.shouldDefer(true, false, true, false))
    check("không hoãn khi do APP gọi loadUri (isDirectNavigation=true)", !ChallengeNav.shouldDefer(true, false, false, true))
    check("không hoãn khi KHÔNG đọc được cờ nguồn (giữ hành vi cũ)", !ChallengeNav.shouldDefer(true, false, false, null))
    check("không hoãn khi tắt pref", !ChallengeNav.shouldDefer(false, false, false, false))
    // reflection
    val o1 = ChallengeNav.originOf(FakeReq(false, true, "https://claude.ai/chat/x"))
    check("đọc cờ nguồn: TRANG tự chuyển, redirect, kích bởi URL", o1.isDirect == false && o1.isRedirect == true && o1.trigger == "https://claude.ai/chat/x" && o1.note().contains("TRANG tự chuyển"), o1.note())
    val o2 = ChallengeNav.originOf(FakeReq(true, false, null))
    check("đọc cờ nguồn: APP gọi loadUri", o2.isDirect == true && o2.note().contains("APP gọi loadUri"), o2.note())
    val o3 = ChallengeNav.originOf(NoFieldsReq())
    check("không có trường => null, ghi 'không đọc được cờ'", o3.isDirect == null && o3.isRedirect == null && o3.note().contains("không đọc được cờ"), o3.note())
    check("đường đi trọn vẹn với log thật: tab nền, trang tự chuyển => hoãn, đích = trang chat", ChallengeNav.shouldDefer(true, false, false, o1.isDirect) && ChallengeNav.targetOf(ch, null) == chat)

    // ===== 7.105: hoãn MỌI cú tự chuyển trang của tab không xem =====
    val T = true; val F = false
    check("NAV HOÃN: bật, cửa sổ hiện tại, tab nền, không ghim, trang tự chuyển, không redirect, không thao tác", ChallengeNav.shouldDeferNav(T, F, F, F, F, F, T))
    check("NAV không hoãn khi tắt pref", !ChallengeNav.shouldDeferNav(F, F, F, F, F, F, T))
    check("NAV không hoãn khi là tab đang xem", !ChallengeNav.shouldDeferNav(T, T, F, F, F, F, T))
    check("NAV không hoãn khi tab ghim chạy nền", !ChallengeNav.shouldDeferNav(T, F, T, F, F, F, T))
    check("NAV không hoãn khi APP gọi loadUri", !ChallengeNav.shouldDeferNav(T, F, F, T, F, F, T))
    check("NAV không hoãn khi là redirect của lần tải đang dở", !ChallengeNav.shouldDeferNav(T, F, F, F, T, F, T))
    check("NAV không hoãn khi có thao tác người dùng", !ChallengeNav.shouldDeferNav(T, F, F, F, F, T, T))
    check("NAV không hoãn khi là cửa sổ mới (popup)", !ChallengeNav.shouldDeferNav(T, F, F, F, F, F, F))
    check("NAV không hoãn khi không đọc được isDirectNavigation", !ChallengeNav.shouldDeferNav(T, F, F, null, F, F, T))
    check("NAV không hoãn khi không đọc được isRedirect", !ChallengeNav.shouldDeferNav(T, F, F, F, null, F, T))
    check("NAV không hoãn khi không đọc được hasUserGesture", !ChallengeNav.shouldDeferNav(T, F, F, F, F, null, T))
    val o4 = ChallengeNav.originOf(FakeReq(false, false, "https://claude.ai/chat/x", true))
    check("đọc cờ hasUserGesture=true", o4.hasGesture == true && o4.note().contains("thao tác người dùng=true"), o4.note())
    val o5 = ChallengeNav.originOf(FakeReq(false, false, null, false))
    check("đường đi trọn vẹn: cú tự chuyển trang nền (không redirect, không thao tác) => hoãn", ChallengeNav.shouldDeferNav(T, F, F, o5.isDirect, o5.isRedirect, o5.hasGesture, T))
    val o6 = ChallengeNav.originOf(NoFieldsReq())
    check("không có trường nào => hasGesture null => không hoãn", o6.hasGesture == null && !ChallengeNav.shouldDeferNav(T, F, F, o6.isDirect, o6.isRedirect, o6.hasGesture, T))
    println(if (fails == 0) "ALL PASS" else "FAILS=$fails")
    System.exit(if (fails == 0) 0 else 1)
}
