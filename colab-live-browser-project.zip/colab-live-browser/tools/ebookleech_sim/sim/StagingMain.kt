import com.colablive.keeper.features.ebookleech.export.EbookMarkup
import com.colablive.keeper.features.ebookleech.export.EbookStaging
import com.colablive.keeper.features.ebookleech.model.*
import java.io.File

// Dựng THẬT EPUB/TXT/HTML + file kèm .story.json bằng EbookStaging/EbookMarkup (mã app), ghi vào -Dstage.dir/<kịch bản>/.
// Việc kiểm hợp lệ (zip, XML nghiêm ngặt, OPF/NCX/nav, liên kết, schema) do tests/validate_staging.py làm bằng bộ phân tích KHÁC (Python) để không tự chấm bài mình.

fun png(): ByteArray = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 1, 2, 3, 4)
fun jpg(): ByteArray = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(), 9, 9, 9)

fun baseJob(id: String, fmt: LeechJob.OutputFormat) = LeechJob(
    id = id, name = "Truyện Thử: Tập 1/2?", listPageUrl = "https://x/list", listPageUrlPattern = "", maxPages = 3,
    chapterLinkSelector = "a", chapterTitleSelector = "h1", chapterContentSelector = "div", delayBetweenPagesMs = 0,
    outputFormat = fmt,
)

val NASTY = "<p>Xin chào<br>dòng hai</p><p>A &amp; B &nbsp; C & D &copy; &hellip; &unknownent; 5 < 6 là sai? 7 > 3</p>" +
    "<p><IMG SRC=\"images/img_1_1.jpg\" alt=\"a&b\"><BR><hr></p><script>alert('x')</script><style>p{}</style><!-- ghi chú --><p>Hết&#160;chương\u0001 \u000B</p>"

fun main() {
    val root = File(System.getProperty("stage.dir")); root.deleteRecursively(); root.mkdirs()
    val now = 1_762_900_000_000L
    val img1 = LeechImage("https://x/i1.jpg", "img_1_1.jpg", "image/jpeg", jpg())
    val ch1 = LeechChapter(1, "Chương 1: Mở đầu <&>", NASTY, "Xin chào dòng hai A & B", "https://x/c1", listOf(img1))
    val ch2 = LeechChapter(2, "Chương 2", "<p>Nội dung hai</p><p>Thêm một đoạn nữa ở đây cho đủ chữ.</p>", "Nội dung hai Thêm một đoạn nữa ở đây cho đủ chữ.", "https://x/c2")
    val ch3 = LeechChapter(3, "Chương 3 \"ngoặc\" 'đơn'", "<div><p>Ba</p></div>", "Ba", "https://x/c3")
    val chapters = listOf(ch1, ch2, ch3)
    val flat = chapters.map { TocNode("auto_${it.index}", it.title, it.index) }
    val nested = listOf(
        TocNode("v1", "Quyển 1 & Mở màn", null, listOf(TocNode("a1", "Chương 1: Mở đầu <&>", 1), TocNode("a2", "Chương 2", 2))),
        TocNode("v2", "Quyển 2", null, listOf(TocNode("a3", "Chương 3 \"ngoặc\" 'đơn'", 3))),
    )
    val full = StoryMeta(
        title = "Đấu Phá <Thương Khung> & Bạn", author = "Thiên Tàm Thổ Đậu", summary = "Dòng một có & ký tự < đặc biệt >.\nDòng hai: \"trích dẫn\" và 'nháy'.\n\nDòng ba 😀 emoji.",
        genres = listOf("Tiên hiệp", "Huyền huyễn"), tags = listOf("Hệ thống", "tiên hiệp", "Nhiệt huyết"), status = "ongoing", statusText = "Đang ra",
        rating = StoryRating(4.5, 5.0, 1234), language = "vi", sourceUrl = "https://x/truyen?a=1&b=2", sourceSite = "x", coverUrl = "https://x/cover.png",
        coverFile = "cover.png", coverMime = "image/png", altTitles = listOf("Battle Through the Heavens", "斗破苍穹"), series = "Đấu Phá", seriesIndex = 2.5,
        publishedAt = "2020-03-04", updatedAt = "2026-11-10", translator = "Nhóm dịch A", publisher = "NXB Thử", extra = mapOf("views" to "1.2M", "follow" to "30k"),
        sources = mapOf("author" to "jsonld"), fetchedAt = now,
    )
    val cover = LeechImage("https://x/cover.png", "cover.png", "image/png", png())
    val gen = "colab-live-browser/EbookLeech test"

    fun run(name: String, job: LeechJob, toc: List<TocNode>, story: StoryMeta, cov: LeechImage?) {
        val d = File(root, name)
        val st = EbookStaging.stage(job, chapters, toc, story, cov, d, now, gen)
        println("STAGED $name main=${st.mainFile.name} mime=${st.mainMime}")
    }
    val epub = LeechJob.OutputFormat.EPUB
    run("E1_full_nested", baseJob("E1", epub), nested, full, cover)
    run("E2_blank_flat", baseJob("E2", epub), flat, StoryMeta(), null)
    run("E3_nocover_nosidecar", baseJob("E3", epub).copy(storySidecar = false), flat, full.copy(coverUrl = "", coverFile = "", coverMime = ""), null)
    run("E4_fixedname", baseJob("E4", epub).copy(updateExistingFile = true, outputFileName = "ten_co_dinh"), flat, full, cover.copy(localFileName = "cover.jpg", mimeType = "image/jpeg", bytes = jpg()))
    run("E5_coveronly", baseJob("E5", epub), flat, StoryMeta(), cover)
    // chỉ có TÊN truyện (trang nào cũng có h1/title) => KHÔNG đáng một trang "Giới thiệu" riêng; tên vẫn là tiêu đề sách
    run("E6_titleonly", baseJob("E6", epub), flat, StoryMeta(title = "Chỉ Có Tên Truyện"), null)
    run("T1_txt", baseJob("T1", LeechJob.OutputFormat.TXT), nested, full, cover)
    run("T2_txt_blank", baseJob("T2", LeechJob.OutputFormat.TXT), flat, StoryMeta(), null)
    run("T3_txt_sourceonly", baseJob("T3", LeechJob.OutputFormat.TXT), flat, StoryMeta(title = "Tên Truyện", sourceUrl = "https://x.test/truyen", sourceSite = "x.test", language = "vi"), null)
    run("H3_html_sourceonly", baseJob("H3", LeechJob.OutputFormat.HTML), flat, StoryMeta(title = "Tên Truyện", sourceUrl = "https://x.test/truyen", sourceSite = "x.test", language = "vi"), null)
    run("H1_html", baseJob("H1", LeechJob.OutputFormat.HTML), nested, full, cover)
    run("H2_html_blank", baseJob("H2", LeechJob.OutputFormat.HTML), flat, StoryMeta(), null)

    // Bộ ca HTML hỏng => xhtmlFix. Ghi ra xhtml_cases.json để Python kiểm bằng bộ phân tích XML nghiêm ngặt (và kiểm xhtmlFix(xhtmlFix(x)) == xhtmlFix(x)).
    val cases = linkedMapOf(
        "bare_lt" to "a < b <3 c &lt; d ]]> e > f",
        "unquoted_attr" to "<img src=a.jpg width=10><a href=x.html>l</a>",
        "valueless_attr" to "<input disabled checked><p hidden>x</p>",
        "vue_angular_attrs" to "<div @click=\"go()\" :class=\"a\" v-if=\"x\" [prop]=\"1\" (click)=\"f()\" onclick=\"evil()\" ONMOUSEOVER='e()'>t</div>",
        "unbalanced" to "<p>a<b>bold</p><i>x",
        "stray_close" to "x</div></span>y</p>z",
        "uppercase" to "<P CLASS=\"A\">x</P><BR><IMG SRC=\"a.png\">",
        "dup_attr" to "<a href=\"1\" href=\"2\" HREF=\"3\">l</a>",
        "implicit_p" to "<p>a<p>b<li>1<li>2",
        "bad_numeric" to "&#0;|&#xD800;|&#65;|&#x41;|&#1114112;|&#x1F600;|&#11;",
        "selfclose_nonvoid" to "<div/>x<span/>y",
        "namespaced" to "<o:p>a</o:p><svg:rect/>b",
        "svg_xlink" to "<svg viewBox=\"0 0 1 1\"><use xlink:href=\"#a\"/></svg>",
        "doctype_cdata_quote" to "<!DOCTYPE html><div title=\"a<b&c\">x</div><![CDATA[y]]>z",
        "unterminated_tag" to "text <div class=\"x",
        "gt_in_attr" to "<a title=\"a>b\" href=\"x\">l</a>",
        "wrappers" to "<html><head><title>T</title><meta charset=utf-8></head><body><p>x</p></body></html>",
        "empty" to "",
        "unicode" to "<p>Tiếng Việt 😀 中文 ñ</p>",
        "nested_deep" to "<div><div><div><span>a</span></div></div></div>",
        "script_style" to "<p>a</p><script>if(a<b){}</script><style>p>b{}</style><noscript>x</noscript><iframe src=x></iframe><p>b</p>",
        "table_loose" to "<table><tr><td>1<td>2<tr><td>3</table>",
        "br_variants" to "a<br>b<br/>c<br />d</br>e",
        "entity_zoo" to "&amp;&lt;&gt;&quot;&apos;&nbsp;&copy;&hellip;&mdash;&notanentity;&amp &x; &#38;&#x26;",
        "attr_entity" to "<a href=\"?a=1&b=2&amp;c=3&nbsp;\" title='He said \"hi\" & left'>l</a>",
    )
    val sb = StringBuilder("[")
    cases.entries.forEachIndexed { i, (k, v) ->
        val o = EbookMarkup.xhtmlFix(v)
        if (i > 0) sb.append(',')
        sb.append("{\"name\":").append(org.json.JSONObject.quote(k)).append(",\"in\":").append(org.json.JSONObject.quote(v))
            .append(",\"out\":").append(org.json.JSONObject.quote(o)).append(",\"out2\":").append(org.json.JSONObject.quote(EbookMarkup.xhtmlFix(o))).append('}')
    }
    sb.append(']')
    File(root, "xhtml_cases.json").writeText(sb.toString(), Charsets.UTF_8)
    println("CASES ${cases.size}")
}
