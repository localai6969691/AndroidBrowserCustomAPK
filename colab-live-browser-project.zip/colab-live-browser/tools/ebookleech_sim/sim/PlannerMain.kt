import com.colablive.keeper.features.ebookleech.engine.ListScanPlanner
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// So khớp chéo ListScanPlanner (Kotlin) với bản Python: cùng kịch bản => cùng danh sách chương, cùng meta, cùng thứ tự trang đã đọc.
fun main(args: Array<String>) {
    val root = JSONArray(File(args[0]).readText(Charsets.UTF_8))
    var fails = 0
    var shown = 0
    val modes = HashMap<String, Int>()
    for (i in 0 until root.length()) {
        val c = root.getJSONObject(i)
        val pages = c.getJSONObject("pages")
        val trace = ArrayList<Int>()
        val fetch = { p: Int ->
            trace.add(p)
            val v = pages.opt(p.toString())
            if (v is JSONArray) (0 until v.length()).map { v.getString(it) } else if (v == null) emptyList() else null
        }
        val known = c.getJSONArray("known").let { a -> (0 until a.length()).map { a.getString(it) } }
        val r = ListScanPlanner.run(fetch, c.getInt("maxPages"), known, c.getInt("hint"), c.optBoolean("fast", false))
        val ex = c.getJSONObject("expect")
        val exLinks = ex.getJSONArray("links").let { a -> (0 until a.length()).map { a.getString(it) } }
        val exTrace = ex.getJSONArray("trace").let { a -> (0 until a.length()).map { a.getInt(it) } }
        val em = ex.getJSONObject("meta")
        val sameMeta = r.meta.mode == em.getString("mode") && r.meta.lastPage == em.getInt("lastPage") && r.meta.pagesLoaded == em.getInt("pagesLoaded") &&
            r.meta.pagesSkipped == em.getInt("pagesSkipped") && r.meta.blocked == em.optBoolean("blocked", false)
        modes[r.meta.mode] = (modes[r.meta.mode] ?: 0) + 1
        val ok = r.links == exLinks && trace == exTrace && sameMeta
        if (!ok) { fails++; if (shown++ < 5) println("FAIL case ${c.getInt("id")} kind=${c.getString("kind")} links=${r.links == exLinks} trace=${trace == exTrace} meta=$sameMeta\n  kt trace=$trace meta=${r.meta.mode}/${r.meta.lastPage}/${r.meta.pagesLoaded}/${r.meta.pagesSkipped}\n  py trace=$exTrace meta=$em") }
    }
    println("PLANNER cases=${root.length()} modes=$modes fails=$fails")
    println(if (fails == 0) "ALL PASS" else "FAILS=$fails")
    System.exit(if (fails == 0) 0 else 1)
}
