import com.colablive.keeper.core.LocalePolicy
import com.colablive.keeper.features.fingerprint.DeviceProfiles

var fails = 0
fun check(name: String, cond: Boolean, extra: String = "") { if (!cond) fails++; println((if (cond) "PASS " else "FAIL ") + name + (if (!cond) "  -> $extra" else "")) }

fun main() {
    val n = DeviceProfiles.localeProfiles.size
    val zhIdx = DeviceProfiles.localeProfiles.indexOfFirst { it.language == "zh-CN" }
    check("có hồ sơ zh-CN trong danh sách (để thử đúng ca lỗi)", zhIdx >= 0)
    val dev = LocalePolicy.deviceProfile("Asia/Ho_Chi_Minh", listOf("vi-VN"))

    // hồ sơ máy thật
    check("máy thật vi-VN: múi giờ + ngôn ngữ lấy từ máy, thêm en-US/en nếu thiếu", dev.timezone == "Asia/Ho_Chi_Minh" && dev.language == "vi-VN" && dev.locale == "vi-VN" && dev.languages == listOf("vi-VN", "en-US", "en") && dev.name == LocalePolicy.DEVICE_NAME)
    check("đã có en => không thêm", LocalePolicy.deviceProfile("Europe/London", listOf("en-GB", "fr-FR")).languages == listOf("en-GB", "fr-FR"))
    check("dùng '_' và 'und' được làm sạch; trùng bị loại", LocalePolicy.deviceProfile("UTC", listOf("vi_VN", "und", "vi-VN", " ")).languages == listOf("vi-VN", "en-US", "en"))
    val empty = LocalePolicy.deviceProfile("", emptyList())
    check("không có dữ liệu máy => en-US + UTC (không bao giờ là một nước khác)", empty.language == "en-US" && empty.timezone == "UTC" && empty.languages == listOf("en-US"))

    // ca lỗi gốc: chỉ số 'Trung Quốc' nằm trong prefs mà KHÔNG có dấu ý định (do ô chọn tự ghi lúc dựng / backup đóng băng)
    check("LỖI GỐC: idx=zh-CN nhưng KHÔNG có dấu ý định => dùng MÁY THẬT, không phải Trung Quốc", LocalePolicy.resolve(zhIdx, false, dev).language == "vi-VN" && LocalePolicy.resolve(zhIdx, false, dev).timezone == "Asia/Ho_Chi_Minh")
    check("chưa lưu gì (idx=-1) => máy thật", LocalePolicy.resolve(-1, false, dev) === dev)
    check("dấu ý định nhưng chưa lưu chỉ số => máy thật", LocalePolicy.resolve(-1, true, dev) === dev)
    check("dấu ý định + chỉ số hợp lệ => đúng hồ sơ người dùng chọn", LocalePolicy.resolve(zhIdx, true, dev).language == "zh-CN")
    check("chỉ số hỏng (ngoài khoảng) dù có dấu ý định => máy thật", LocalePolicy.resolve(n + 5, true, dev) === dev && LocalePolicy.resolve(-3, true, dev) === dev)
    check("nhãn nguồn đúng", LocalePolicy.sourceLabel(zhIdx, true).contains("CHỌN TAY") && LocalePolicy.sourceLabel(zhIdx, false).contains("máy thật"))
    // QUÉT: với MỌI chỉ số, không dấu ý định thì không bao giờ ra hồ sơ danh sách
    check("quét mọi chỉ số: không dấu ý định => luôn là máy thật", (-2..n + 2).all { LocalePolicy.resolve(it, false, dev) === dev })
    check("quét mọi chỉ số hợp lệ: có dấu ý định => đúng hồ sơ thứ i", (0 until n).all { LocalePolicy.resolve(it, true, dev) === DeviceProfiles.localeProfiles[it] })

    // ô chọn
    val labels = LocalePolicy.spinnerLabels()
    check("nhãn ô chọn = các hồ sơ cũ (giữ nguyên thứ tự/chỉ số) + 1 mục 'Theo máy thật' ở cuối", labels.size == n + 1 && labels.take(n) == DeviceProfiles.localeProfiles.map { it.name } && labels.last().startsWith(LocalePolicy.DEVICE_NAME))
    check("vị trí ban đầu: không dấu ý định => mục cuối (Theo máy thật), KHÔNG phải hồ sơ băm", LocalePolicy.spinnerPosition(zhIdx, false) == n && LocalePolicy.spinnerPosition(-1, false) == n)
    check("vị trí ban đầu: có dấu ý định => đúng hồ sơ đã chọn", LocalePolicy.spinnerPosition(zhIdx, true) == zhIdx)
    // mô phỏng vòng đời ô chọn: dựng (sự kiện ban đầu) rồi người dùng đổi
    var storedIdx = -1; var storedBy = false
    fun fire(position: Int, shown: Int): Int {
        if (!LocalePolicy.isRealChange(position, shown)) return shown
        val c = LocalePolicy.choiceFor(position)
        if (c.byUser) storedBy = true
        storedIdx = c.idx
        if (!c.byUser) storedBy = false
        return position
    }
    var shown = LocalePolicy.spinnerPosition(storedIdx, storedBy)
    shown = fire(shown, shown)   // sự kiện lúc dựng màn hình
    check("MỞ Cài đặt (sự kiện dựng ban đầu) KHÔNG ghi gì: idx=-1, by_user=false", storedIdx == -1 && !storedBy)
    check("sau khi mở Cài đặt, hồ sơ hiệu lực vẫn là máy thật", LocalePolicy.resolve(storedIdx, storedBy, dev) === dev)
    shown = fire(zhIdx, shown)
    check("người dùng chọn zh-CN => ghi idx + dấu ý định; hồ sơ hiệu lực = zh-CN", storedIdx == zhIdx && storedBy && LocalePolicy.resolve(storedIdx, storedBy, dev).language == "zh-CN")
    shown = fire(n, shown)
    check("người dùng quay lại 'Theo máy thật' => xoá dấu ý định; hồ sơ hiệu lực = máy thật", storedIdx == -1 && !storedBy && LocalePolicy.resolve(storedIdx, storedBy, dev) === dev)
    check("lần dựng lại sau khi chọn thật: vị trí ban đầu khớp lựa chọn đã lưu (không bắn ghi đè)", run { storedIdx = zhIdx; storedBy = true; val s = LocalePolicy.spinnerPosition(storedIdx, storedBy); fire(s, s); storedIdx == zhIdx && storedBy })

    // choiceFor
    check("choiceFor: hồ sơ trong danh sách => byUser; mục cuối/ngoài khoảng => (-1,false)", LocalePolicy.choiceFor(0).byUser && LocalePolicy.choiceFor(n - 1).idx == n - 1 && !LocalePolicy.choiceFor(n).byUser && LocalePolicy.choiceFor(n).idx == -1 && !LocalePolicy.choiceFor(-1).byUser)

    println(if (fails == 0) "ALL PASS" else "FAILED $fails")
    if (fails != 0) kotlin.system.exitProcess(1)
}
