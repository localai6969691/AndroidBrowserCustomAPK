import android.content.Context
import android.os.Q
import com.colablive.keeper.core.GeckoViewEngine
import com.colablive.keeper.features.ebookleech.engine.*
import com.colablive.keeper.features.ebookleech.export.Rec
import com.colablive.keeper.features.ebookleech.model.*
import org.json.JSONObject

var fails = 0
fun check(name: String, cond: Boolean, extra: String = "") { if (!cond) fails++; println((if (cond) "PASS " else "FAIL ") + name + (if (!cond) "  -> $extra" else "")) }

// site model: chapter url -> (title, text, nextUrl?)
class Site { val chapters = LinkedHashMap<String, Triple<String, String, String?>>(); val extra = HashMap<String, Triple<String, String, String?>>(); var failUrls = HashSet<String>() }
fun mkSite(n: Int): Site { val s = Site(); for (i in 1..n) s.chapters["https://x/c$i"] = Triple("Ch $i", "Noi dung chuong $i ".repeat(10), null); return s }

fun install(site: Site) {
    FakeWeb.requested.clear()
    FakeWeb.handler = { url, js, ok, err ->
        if (url == "https://x/list") {
            val links = site.chapters.keys.map { "\"$it\"" }.joinToString(",")
            ok("{\"links\":[$links]}")
        } else if (url.startsWith("https://x/list/page/")) ok("{\"links\":[]}")
        else if (url in site.failUrls) err("mạng lỗi")
        else {
            val c = site.chapters[url] ?: site.extra[url]
            if (c == null) err("404") else {
                val next = c.third
                val nextPart = if (js.contains("var next") && next != null) ",\"next\":${JSONObject.quote(next)}" else ""
                ok("{\"title\":${JSONObject.quote(c.first)},\"html\":${JSONObject.quote("<p>" + c.second + "</p>")},\"text\":${JSONObject.quote(c.second)}$nextPart,\"tm\":true,\"cm\":true}")
            }
        }
    }
}

fun job(id: String, inc: Boolean, refresh: Int = 0, skip: List<String> = emptyList(), minLen: Int = 0, next: String = "") = LeechJob(
    id = id, name = id, listPageUrl = "https://x/list", listPageUrlPattern = "", maxPages = 3,
    chapterLinkSelector = "a", chapterTitleSelector = "h1", chapterContentSelector = "div",
    delayBetweenPagesMs = 0, incrementalUpdate = inc, refreshLastN = refresh, skipIfTextContains = skip, minTextLength = minLen, chapterNextPageSelector = next,
)

val storyScripts = ArrayList<String>()
var lastDonePath: String? = null
var lastNote: String? = null
val newChapterCalls = ArrayList<Pair<Int, Int>>()
fun runJob(ctx: Context, j: LeechJob): Pair<Boolean, List<String>> {
    Rec.exported = emptyList(); lastDonePath = null; lastNote = null; newChapterCalls.clear()
    var done = false; var err: String? = null
    val msgs = ArrayList<String>()
    val c = EbookLeechCrawler(ctx, 0, GeckoViewEngine(), j, { _, _, m -> msgs.add(m) }, {}, { p -> lastDonePath = p; done = true }, {}, { _, _ -> }, { e -> err = e }, { n -> lastNote = n }, { n, t -> newChapterCalls.add(Pair(n, t)) })
    c.start()
    var guard = 0
    while (!done && err == null && guard++ < 200000) {
        val r = Q.q.poll(300, java.util.concurrent.TimeUnit.MILLISECONDS) ?: if (Thread.activeCount() > 0 && guard < 50) continue else break
        r.run()
    }
    Thread.sleep(400) // chờ Thread lưu kho
    return Pair(done, msgs)
}

fun main() {
    val dir = java.io.File(System.getProperty("sim.dir")); dir.deleteRecursively(); dir.mkdirs()
    val ctx = Context()

    // S1: lần đầu
    var site = mkSite(5); install(site)
    var (ok, msgs) = runJob(ctx, job("J1", true))
    check("S1 xong", ok, msgs.takeLast(3).toString())
    check("S1 xuất 5 chương", Rec.exported.size == 5, "${Rec.exported.size}")
    check("S1 mở 5 trang chương", FakeWeb.requested.count { it.startsWith("https://x/c") } == 5, FakeWeb.requested.toString())
    check("S1 kho lưu 5", ChapterArchiveRepository.count(ctx, 0, "J1") == 5)

    // S2: thêm 2 chương mới => chỉ mở c6,c7
    site = mkSite(7); install(site)
    ok = runJob(ctx, job("J1", true)).first
    val opened = FakeWeb.requested.filter { it.startsWith("https://x/c") }
    check("S2 xong", ok)
    check("S2 chỉ mở c6,c7", opened == listOf("https://x/c6", "https://x/c7"), opened.toString())
    check("S2 xuất 7 chương theo thứ tự 1..7", Rec.exported.map { it.index } == (1..7).toList() && Rec.exported.map { it.sourceUrl } == (1..7).map { "https://x/c$it" })
    check("S2 kho 7", ChapterArchiveRepository.count(ctx, 0, "J1") == 7)

    // S3: refreshLastN=2 + lỗi mạng ở c7 => giữ bản cũ
    site = mkSite(7); site.failUrls.add("https://x/c7"); install(site)
    ok = runJob(ctx, job("J1", true, refresh = 2)).first
    val op3 = FakeWeb.requested.filter { it.startsWith("https://x/c") }
    check("S3 mở lại c6,c7", op3 == listOf("https://x/c6", "https://x/c7"), op3.toString())
    check("S3 c7 giữ bản cũ (không phải chương lỗi)", Rec.exported.size == 7 && !Rec.exported[6].title.contains("[lỗi]") && Rec.exported[6].textContent.startsWith("Noi dung chuong 7"), Rec.exported.lastOrNull()?.title ?: "")

    // S4: không bật tăng dần => cào lại hết, hành vi cũ
    site = mkSite(3); install(site)
    ok = runJob(ctx, job("J2", false)).first
    check("S4 không tăng dần: mở 3, xuất 3", ok && FakeWeb.requested.count { it.startsWith("https://x/c") } == 3 && Rec.exported.size == 3)
    check("S4 không tạo kho", ChapterArchiveRepository.count(ctx, 0, "J2") == 0)

    // S5: bỏ qua chương theo cụm + độ dài; đánh số liên tục; không lưu kho
    site = mkSite(5)
    site.chapters["https://x/c2"] = Triple("Ch 2", "Chương này BỊ KHOÁ vui lòng đăng nhập", null)
    site.chapters["https://x/c4"] = Triple("Ch 4", "ngắn", null)
    install(site)
    ok = runJob(ctx, job("J3", true, skip = listOf("bị khoá"), minLen = 20)).first
    check("S5 bỏ 2 chương, giữ 3", ok && Rec.exported.size == 3, "${Rec.exported.size} ${Rec.exported.map { it.title }}")
    check("S5 đánh số liên tục 1..3", Rec.exported.map { it.index } == listOf(1, 2, 3))
    check("S5 kho chỉ 3 chương", ChapterArchiveRepository.count(ctx, 0, "J3") == 3)
    // lần sau site mở khoá c2 => chỉ mở c2 và c4 (2 chương từng bị bỏ)
    site.chapters["https://x/c2"] = Triple("Ch 2", "Noi dung da mo khoa ".repeat(5), null)
    site.chapters["https://x/c4"] = Triple("Ch 4", "Noi dung chuong 4 ".repeat(5), null)
    install(site)
    ok = runJob(ctx, job("J3", true, skip = listOf("bị khoá"), minLen = 20)).first
    check("S5b lần sau chỉ mở 2 chương từng bị bỏ", FakeWeb.requested.filter { it.startsWith("https://x/c") } == listOf("https://x/c2", "https://x/c4"), FakeWeb.requested.toString())
    check("S5b xuất đủ 5 theo đúng thứ tự site", Rec.exported.map { it.sourceUrl } == (1..5).map { "https://x/c$it" })

    // S6: chương nhiều trang
    site = mkSite(3)
    site.chapters["https://x/c1"] = Triple("Ch 1", "Trang A ".repeat(5), "https://x/c1_2")
    site.extra["https://x/c1_2"] = Triple("Ch 1 p2", "Trang B ".repeat(5), "https://x/c1_3")
    site.extra["https://x/c1_3"] = Triple("Ch 1 p3", "Trang C ".repeat(5), "https://x/c2") // trỏ sang CHƯƠNG 2 => phải dừng
    install(site)
    ok = runJob(ctx, job("J4", false, next = ".next")).first
    val ch1 = Rec.exported.firstOrNull()
    check("S6 gộp 3 trang vào chương 1", ok && ch1 != null && ch1.textContent.contains("Trang A") && ch1.textContent.contains("Trang B") && ch1.textContent.contains("Trang C"), ch1?.textContent ?: "null")
    check("S6 tiêu đề lấy ở trang 1", ch1?.title == "Ch 1", ch1?.title ?: "")
    check("S6 không nuốt chương 2 vào chương 1", ch1 != null && !ch1.textContent.contains("Noi dung chuong 2"))
    check("S6 vẫn đủ 3 chương", Rec.exported.size == 3, "${Rec.exported.size}")
    // vòng lặp next
    site = mkSite(2)
    site.chapters["https://x/c1"] = Triple("Ch 1", "Loop ", "https://x/c1")
    install(site)
    ok = runJob(ctx, job("J5", false, next = ".next")).first
    check("S7 next trỏ lại chính nó không treo", ok && Rec.exported.size == 2)
    // maxChapterPages
    site = mkSite(1)
    for (p in 1..20) (if (p == 1) site.chapters else site.extra)[if (p == 1) "https://x/c1" else "https://x/c1_$p"] = Triple("T", "P$p ", "https://x/c1_${p + 1}")
    install(site)
    ok = runJob(ctx, job("J6", false, next = ".next").copy(maxChapterPages = 4)).first
    check("S8 giới hạn 4 trang", ok && Rec.exported.firstOrNull()?.textContent?.let { it.contains("P4") && !it.contains("P5") } == true, Rec.exported.firstOrNull()?.textContent ?: "")

    // ---- Bản 7.101: không xuất lại khi không có gì đổi + ghi chú lần chạy ----
    // S9: lần 1 xuất; lần 2 y hệt (giống Scheduler: outputFilePath của lần trước được đưa vào job) => KHÔNG xuất
    site = mkSite(5); install(site)
    ok = runJob(ctx, job("J7", true)).first
    val path1 = lastDonePath ?: ""
    check("S9 lần 1 xuất + có đường dẫn", ok && path1.isNotBlank() && Rec.calls >= 1 && java.io.File(path1).exists(), path1)
    check("S9 lần 1 ghi chú có 'mở trang 5'", lastNote?.contains("mở trang 5 chương") == true, lastNote ?: "null")
    val callsBefore = Rec.calls
    install(site)
    ok = runJob(ctx, job("J7", true).copy(outputFilePath = path1)).first
    check("S9 lần 2 không đổi => KHÔNG gọi xuất", ok && Rec.calls == callsBefore, "calls=${Rec.calls} trước=$callsBefore")
    check("S9 lần 2 onDone('') để giữ đường dẫn cũ", lastDonePath == "", "[$lastDonePath]")
    check("S9 lần 2 ghi chú 'không có chương mới'", lastNote?.contains("không có chương mới") == true, lastNote ?: "null")
    check("S9 lần 2 không mở trang chương nào", FakeWeb.requested.none { it.startsWith("https://x/c") }, FakeWeb.requested.toString())

    // S10: có chương mới => xuất lại
    site = mkSite(6); install(site)
    ok = runJob(ctx, job("J7", true).copy(outputFilePath = path1)).first
    check("S10 có chương mới => xuất", ok && Rec.calls == callsBefore + 1 && Rec.exported.size == 6 && (lastDonePath ?: "").isNotBlank(), "calls=${Rec.calls} ${lastDonePath}")
    check("S10 ghi chú 'mở trang 1 chương, dùng lại 5'", lastNote?.contains("mở trang 1 chương, dùng lại 5") == true, lastNote ?: "null")
    val path2 = lastDonePath ?: ""

    // S11: file ebook cũ bị xoá => vẫn xuất lại dù không đổi
    java.io.File(path2).delete()
    val c11 = Rec.calls
    install(site)
    ok = runJob(ctx, job("J7", true).copy(outputFilePath = path2)).first
    check("S11 file cũ mất => xuất lại", ok && Rec.calls == c11 + 1, "calls=${Rec.calls}")

    // S12: đổi định dạng => chữ ký khác => xuất lại
    val c12 = Rec.calls
    install(site)
    ok = runJob(ctx, job("J7", true).copy(outputFilePath = lastDonePath ?: path2, outputFormat = LeechJob.OutputFormat.TXT)).first
    check("S12 đổi định dạng => xuất lại", ok && Rec.calls == c12 + 1, "calls=${Rec.calls}")

    // S13: cào lại 1 chương cuối mà nội dung KHÔNG đổi => không xuất; nội dung ĐỔI => xuất
    site = mkSite(5); install(site)
    ok = runJob(ctx, job("J8", true)).first
    val p8 = lastDonePath ?: ""
    val c13 = Rec.calls
    install(site)
    ok = runJob(ctx, job("J8", true, refresh = 1).copy(outputFilePath = p8)).first
    check("S13 refresh nhưng nội dung y hệt => không xuất", ok && Rec.calls == c13 && FakeWeb.requested.count { it.startsWith("https://x/c") } == 1, "calls=${Rec.calls} ${FakeWeb.requested}")
    site.chapters["https://x/c5"] = Triple("Ch 5", "Noi dung chuong 5 DA SUA ".repeat(10), null); install(site)
    ok = runJob(ctx, job("J8", true, refresh = 1).copy(outputFilePath = p8)).first
    check("S13 refresh và nội dung ĐỔI => xuất", ok && Rec.calls == c13 + 1 && Rec.exported.last().textContent.contains("DA SUA"), "calls=${Rec.calls}")

    // S14: site bỏ bớt 1 chương => danh sách khác kho => xuất
    site = mkSite(5); install(site)
    ok = runJob(ctx, job("J9", true)).first
    val p9 = lastDonePath ?: ""; val c14 = Rec.calls
    site = mkSite(4); install(site)
    ok = runJob(ctx, job("J9", true).copy(outputFilePath = p9)).first
    check("S14 site bớt chương => xuất", ok && Rec.calls == c14 + 1 && Rec.exported.size == 4, "calls=${Rec.calls} ${Rec.exported.size}")

    // S15: KHÔNG bật tăng dần => không bao giờ bỏ qua xuất và không ghi chú
    site = mkSite(3); install(site)
    ok = runJob(ctx, job("J10", false)).first
    val p10 = lastDonePath ?: ""; val c15 = Rec.calls
    install(site)
    ok = runJob(ctx, job("J10", false).copy(outputFilePath = p10)).first
    check("S15 không tăng dần => luôn xuất, ghi chú KHÔNG nhắc kho/mở trang", ok && Rec.calls == c15 + 1 && lastNote != null && lastNote!!.isNotBlank() && !lastNote!!.contains("mở trang") && lastNote!!.contains("không có chương mới"), "calls=${Rec.calls} note=$lastNote")

    // ---- Bản 7.102: thông báo chương mới + mốc xuất ----
    // S16: lần đầu KHÔNG thông báo (chưa có mốc, không coi cả cuốn là chương mới); ghi chú "xuất lần đầu"
    site = mkSite(4); install(site)
    ok = runJob(ctx, job("J11", true)).first
    val p11 = lastDonePath ?: ""
    check("S16 lần đầu: không thông báo chương mới", ok && newChapterCalls.isEmpty(), newChapterCalls.toString())
    check("S16 lần đầu: ghi chú 'xuất lần đầu 4 chương'", lastNote?.contains("xuất lần đầu 4 chương") == true, lastNote ?: "null")
    check("S16 lần đầu: có mốc xuất", ChapterArchiveRepository.loadExportBaseline(ctx, 0, "J11")?.size == 4)

    // S17: site thêm 2 chương => thông báo (2, 6), ghi chú "+2 chương mới (tổng 6)"
    site = mkSite(6); install(site)
    ok = runJob(ctx, job("J11", true).copy(outputFilePath = p11)).first
    check("S17 thêm 2 chương => onNewChapters(2,6)", ok && newChapterCalls == listOf(Pair(2, 6)), newChapterCalls.toString())
    check("S17 ghi chú '+2 chương mới (tổng 6)'", lastNote?.contains("+2 chương mới (tổng 6)") == true, lastNote ?: "null")
    val p11b = lastDonePath ?: ""

    // S18: không đổi => bỏ qua xuất => KHÔNG thông báo
    install(site)
    ok = runJob(ctx, job("J11", true).copy(outputFilePath = p11b)).first
    check("S18 không đổi => không thông báo", ok && newChapterCalls.isEmpty() && lastDonePath == "", "${newChapterCalls} [$lastDonePath]")

    // S19: tắt notifyNewChapters => có chương mới nhưng KHÔNG thông báo; ghi chú vẫn đếm
    site = mkSite(7); install(site)
    ok = runJob(ctx, job("J11", true).copy(outputFilePath = p11b, notifyNewChapters = false)).first
    check("S19 tắt thông báo => không gọi onNewChapters", ok && newChapterCalls.isEmpty(), newChapterCalls.toString())
    check("S19 ghi chú vẫn '+1 chương mới (tổng 7)'", lastNote?.contains("+1 chương mới (tổng 7)") == true, lastNote ?: "null")
    val p11c = lastDonePath ?: ""

    // S20: job KHÔNG tăng dần cũng thông báo được (so với mốc lần xuất trước)
    site = mkSite(3); install(site)
    ok = runJob(ctx, job("J12", false)).first
    val p12 = lastDonePath ?: ""
    check("S20 không tăng dần lần đầu: không thông báo", ok && newChapterCalls.isEmpty(), newChapterCalls.toString())
    site = mkSite(5); install(site)
    ok = runJob(ctx, job("J12", false).copy(outputFilePath = p12)).first
    check("S20 không tăng dần + thêm 2 chương => onNewChapters(2,5)", ok && newChapterCalls == listOf(Pair(2, 5)), newChapterCalls.toString())

    // S21: chương cũ ĐỔI nội dung (refresh) nhưng không có URL mới => xuất lại nhưng KHÔNG thông báo "chương mới"
    site = mkSite(5); install(site)
    ok = runJob(ctx, job("J13", true)).first
    val p13 = lastDonePath ?: ""; val c21 = Rec.calls
    site.chapters["https://x/c5"] = Triple("Ch 5", "Noi dung chuong 5 DA SUA LAN HAI ".repeat(10), null); install(site)
    ok = runJob(ctx, job("J13", true, refresh = 1).copy(outputFilePath = p13)).first
    check("S21 sửa chương cũ => xuất lại nhưng không báo chương mới", ok && Rec.calls == c21 + 1 && newChapterCalls.isEmpty(), "${Rec.calls} ${newChapterCalls}")
    check("S21 ghi chú 'không có chương mới'", lastNote?.contains("không có chương mới") == true, lastNote ?: "null")

    // S22 (bản 7.103): "Xoá kho" chỉ xoá nội dung chương/ảnh, GIỮ mốc xuất => lần cào lại sau đó vẫn báo đúng "+N chương mới" (không bị coi là xuất lần đầu)
    ChapterArchiveRepository.deleteArchive(ctx, 0, "J13")
    check("S22 Xoá kho: kho chương trống", ChapterArchiveRepository.count(ctx, 0, "J13") == 0)
    check("S22 Xoá kho: GIỮ mốc xuất", ChapterArchiveRepository.loadExportBaseline(ctx, 0, "J13")?.size == 5)
    site = mkSite(6); install(site)
    ok = runJob(ctx, job("J13", true).copy(outputFilePath = p13)).first
    check("S22 sau Xoá kho vẫn báo đúng onNewChapters(1,6)", ok && newChapterCalls == listOf(Pair(1, 6)), "${newChapterCalls} ${lastNote}")
    // Xoá HẲN job (delete) => mất cả mốc => lần sau coi như xuất lần đầu, không báo
    ChapterArchiveRepository.delete(ctx, 0, "J13")
    check("S22 xoá hẳn job cũng xoá mốc xuất", ChapterArchiveRepository.loadExportBaseline(ctx, 0, "J13") == null)
    site = mkSite(6); install(site)
    ok = runJob(ctx, job("J13", true).copy(outputFilePath = p13)).first
    check("S22 mất mốc => không thông báo, ghi chú 'xuất lần đầu'", ok && newChapterCalls.isEmpty() && lastNote?.contains("xuất lần đầu") == true, "${newChapterCalls} ${lastNote}")

    // S22b (bản 7.103): mốc cũ KHÔNG trùng URL nào với danh sách mới (đổi link nguồn/đổi cấu trúc trang) => xuất lần đầu, KHÔNG báo "+N chương mới" cho cả cuốn
    site = mkSite(4); install(site)
    ok = runJob(ctx, job("J15", true)).first
    val p15 = lastDonePath ?: ""
    ChapterArchiveRepository.saveExportBaseline(ctx, 0, "J15", listOf("https://cu/a\tdeadbeef", "https://cu/b\tdeadbeef", "https://cu/c\tdeadbeef"))
    site = mkSite(5); install(site)
    ok = runJob(ctx, job("J15", true).copy(outputFilePath = p15)).first
    check("S22b mốc không trùng URL nào => không báo chương mới, ghi chú 'xuất lần đầu'", ok && newChapterCalls.isEmpty() && lastNote?.contains("xuất lần đầu") == true, "${newChapterCalls} ${lastNote}")

    // S23: ExportFollowUp.signatureOf đổi khi bật/tắt "ghi đè file cũ" => KHÔNG bỏ qua xuất
    site = mkSite(3); install(site)
    ok = runJob(ctx, job("J14", true)).first
    val p14 = lastDonePath ?: ""; val c23 = Rec.calls
    install(site)
    ok = runJob(ctx, job("J14", true).copy(outputFilePath = p14, updateExistingFile = true)).first
    check("S23 bật 'ghi đè file cũ' => chữ ký đổi => xuất lại", ok && Rec.calls == c23 + 1, "calls=${Rec.calls}")
    check("S23 chữ ký có cờ updateExistingFile", com.colablive.keeper.features.ebookleech.export.ExportFollowUp.signatureOf(job("J14", true).copy(updateExistingFile = true)).endsWith("|true"))

    // ───────────────── Bản 7.104: thông tin truyện ─────────────────
    // Web giả trả JSON của STORY_META_JS khi script bắt đầu bằng "(function (cfg)"; mọi URL khác đi đường cũ.
    fun installStory(site: Site, story: () -> String?, storyUrl: String = "https://x/list") {
        install(site)
        val base = FakeWeb.handler
        FakeWeb.handler = { url, js, ok, err ->
            if (js.startsWith("(function (cfg)")) { storyScripts.add(js); val st = story(); if (url == storyUrl && st != null) ok(st) else err("khong co trang thong tin: $url") }
            else base(url, js, ok, err)
        }
    }
    fun storyJson(author: String, genres: String = "[\"Tien hiep\",\"Huyen huyen\"]", cover: String = "https://x/cover.jpg", summary: String = "Tom tat truyen.") =
        "{\"meta\":{\"title\":\"Truyen X\",\"author\":${JSONObject.quote(author)},\"summary\":${JSONObject.quote(summary)},\"genres\":$genres,\"status\":\"ongoing\",\"coverUrl\":${JSONObject.quote(cover)},\"sourceUrl\":\"https://x/list\"},\"sources\":{\"author\":\"jsonld\",\"title\":\"og\"}}"

    // T1: lần đầu — lấy thông tin, lưu (kèm bìa), ghi chú tiến độ, script nhận selector từ job
    var authorNow = "Tac Gia A"
    site = mkSite(3); installStory(site, { storyJson(authorNow) })
    ImageDownloader.coverCalls = 0; ImageDownloader.coverReferers.clear(); storyScripts.clear()
    val jT = job("T1", true).copy(authorSelector = ".au", storyMetaSelectors = mapOf("summary" to "div.sum", "coverUrl" to "img.c"))
    val rT1 = runJob(ctx, jT); ok = rT1.first
    val st1 = StoryMetaStore.load(ctx, "T1")
    check("T1 xong + xuất", ok && Rec.exported.size == 3, "ok=$ok")
    check("T1 lưu tác giả/tóm tắt/thể loại/tình trạng", st1 != null && st1.meta.author == "Tac Gia A" && st1.meta.summary == "Tom tat truyen." && st1.meta.genres == listOf("Tien hiep", "Huyen huyen") && st1.meta.status == "ongoing", st1?.meta?.toJson().toString())
    check("T1 lưu bìa + gắn tên file", st1?.cover?.bytes?.size == 5 && st1.meta.coverFile == "cover.jpg" && st1.meta.coverMime == "image/jpeg", "${st1?.meta?.coverFile} ${st1?.cover?.bytes?.size}")
    check("T1 tải bìa với Referer = trang thông tin", ImageDownloader.coverCalls == 1 && ImageDownloader.coverReferers == listOf("https://x/list"), "${ImageDownloader.coverCalls} ${ImageDownloader.coverReferers}")
    check("T1 script chứa selector (cũ + mới, coverUrl→cover)", storyScripts.size == 1 && storyScripts[0].contains("\"author\":\".au\"") && storyScripts[0].contains("\"summary\":\"div.sum\"") && storyScripts[0].contains("\"cover\":\"img.c\""), storyScripts.firstOrNull()?.takeLast(200) ?: "none")
    check("T1 tiến độ báo đã lưu những gì (tác giả, tóm tắt, bìa...)", rT1.second.any { it.contains("thông tin truyện:") && it.contains("tác giả") && it.contains("bìa") }, rT1.second.takeLast(4).toString())
    val pT1 = lastDonePath ?: ""

    // T2: lần sau KHÔNG đổi gì (tăng dần, không chương mới, thông tin y hệt) => bỏ qua xuất, không tải lại bìa
    val c2 = Rec.calls; ImageDownloader.coverCalls = 0
    installStory(site, { storyJson(authorNow) })
    ok = runJob(ctx, jT.copy(outputFilePath = pT1)).first
    check("T2 không đổi gì => bỏ qua xuất", ok && Rec.calls == c2, "calls=${Rec.calls} vs $c2 note=$lastNote")
    check("T2 bìa cùng URL => không tải lại", ImageDownloader.coverCalls == 0, "${ImageDownloader.coverCalls}")

    // T3: site đổi tác giả, KHÔNG có chương mới => phải xuất lại (thông tin vào ebook)
    authorNow = "Tac Gia B"
    installStory(site, { storyJson(authorNow) })
    ok = runJob(ctx, jT.copy(outputFilePath = pT1)).first
    check("T3 đổi tác giả => xuất lại dù không có chương mới", ok && Rec.calls == c2 + 1, "calls=${Rec.calls} vs ${c2 + 1}")
    check("T3 lưu tác giả mới", StoryMetaStore.load(ctx, "T1")?.meta?.author == "Tac Gia B")

    // T4: trang thông tin lỗi => giữ thông tin cũ, vẫn xong, không đổi
    installStory(site, { null })
    val c4 = Rec.calls
    ok = runJob(ctx, jT.copy(outputFilePath = lastDonePath ?: pT1)).first
    check("T4 trang thông tin lỗi: lần cào vẫn xong", ok, "ok=$ok")
    check("T4 giữ thông tin cũ", StoryMetaStore.load(ctx, "T1")?.meta?.author == "Tac Gia B" && StoryMetaStore.load(ctx, "T1")?.cover != null)
    check("T4 không đổi gì => bỏ qua xuất", Rec.calls == c4, "calls=${Rec.calls} vs $c4")

    // T5: nhập tay thắng tự trích + coi là thay đổi (xuất lại)
    val c5 = Rec.calls
    installStory(site, { storyJson("Tac Gia B") })
    val manualMeta = StoryMeta(author = "Nguoi Nhap Tay", genres = listOf("Do thi"), status = "completed", statusText = "Hoan thanh")
    ok = runJob(ctx, jT.copy(outputFilePath = lastDonePath ?: pT1, storyMetaManual = manualMeta)).first
    val st5 = StoryMetaStore.load(ctx, "T1")
    check("T5 nhập tay thắng tự trích", ok && st5?.meta?.author == "Nguoi Nhap Tay" && st5.meta.genres == listOf("Do thi") && st5.meta.status == "completed", st5?.meta?.toJson().toString())
    check("T5 trường nhập tay không điền vẫn giữ giá trị tự trích (tóm tắt)", st5?.meta?.summary == "Tom tat truyen.")
    check("T5 ghi nguồn 'manual'", st5?.meta?.sources?.get("author") == "manual", st5?.meta?.sources.toString())
    check("T5 thay đổi => xuất lại", Rec.calls == c5 + 1, "calls=${Rec.calls} vs ${c5 + 1}")

    // T6: tắt lấy thông tin => không gửi script, không lưu mới
    site = mkSite(3); storyScripts.clear(); installStory(site, { storyJson("Khong Duoc Goi") })
    ok = runJob(ctx, job("T6", true).copy(storyMetaEnabled = false)).first
    check("T6 tắt => không chạy script thông tin", ok && storyScripts.isEmpty() && StoryMetaStore.load(ctx, "T6") == null, "scripts=${storyScripts.size}")

    // T6b: tắt tự trích nhưng có nhập tay => vẫn lưu thông tin nhập tay
    ok = runJob(ctx, job("T6b", true).copy(storyMetaEnabled = false, storyMetaManual = StoryMeta(author = "Chi Nhap Tay"))).first
    check("T6b tắt tự trích + nhập tay => lưu nhập tay, không chạy script", ok && storyScripts.isEmpty() && StoryMetaStore.load(ctx, "T6b")?.meta?.author == "Chi Nhap Tay")

    // T7: URL trang thông tin riêng
    site = mkSite(2); storyScripts.clear(); installStory(site, { storyJson("Tac Gia Rieng") }, storyUrl = "https://x/about")
    ok = runJob(ctx, job("T7", false).copy(storyInfoUrl = "https://x/about")).first
    check("T7 dùng storyInfoUrl", ok && StoryMetaStore.load(ctx, "T7")?.meta?.author == "Tac Gia Rieng" && FakeWeb.requested.contains("https://x/about"), FakeWeb.requested.toString())

    // T8: không có "meta" trong kết quả (trang không có thông tin) => không lưu gì, không hỏng
    site = mkSite(2); installStory(site, { "{\"meta\":{},\"sources\":{}}" })
    ok = runJob(ctx, job("T8", false)).first
    check("T8 trang trống thông tin: vẫn xong, không lưu", ok && StoryMetaStore.load(ctx, "T8") == null)

    // T9: JSON round-trip của job (cùng khoá với runner Python) + job cũ không có khoá mới
    val jj = job("T9", true).copy(storyInfoUrl = "https://x/a", storyMetaSelectors = mapOf("author" to ".a", "genres" to "a.g"), storyMetaManual = StoryMeta(title = "Tên", summary = "Dòng 1\nDòng 2", genres = listOf("A", "B")), storyMetaWaitMs = 2500, storySidecar = false)
    val back = LeechJob.fromJson(jj.toJson())
    check("T9 round-trip trường thông tin truyện", back.storyInfoUrl == "https://x/a" && back.storyMetaSelectors == mapOf("author" to ".a", "genres" to "a.g") && back.storyMetaManual?.title == "Tên" && back.storyMetaManual?.genres == listOf("A", "B") && back.storyMetaWaitMs == 2500 && !back.storySidecar && back.storyMetaEnabled)
    val legacy = JSONObject(job("T9b", true).toJson().toString()).also { o -> listOf("storyMetaEnabled", "storyInfoUrl", "storyMetaSelectors", "storyMetaManual", "storyMetaWaitMs", "storySidecar").forEach { o.remove(it) } }
    val lb = LeechJob.fromJson(legacy)
    check("T9 job cũ (thiếu khoá) => mặc định BẬT, không selector, có file kèm", lb.storyMetaEnabled && lb.storyMetaSelectors.isEmpty() && lb.storyMetaManual == null && lb.storySidecar && lb.storyMetaWaitMs == 1200)
    val jjJson = jj.toJson()
    check("T9 khoá JSON gửi runner Python", jjJson.has("storyMetaSelectors") && jjJson.has("storyMetaManual") && jjJson.optJSONObject("storyMetaManual")?.optString("title") == "Tên" && jjJson.optInt("storyMetaWaitMs") == 2500)
    check("T9 StoryMetaCollector.selectorsFromJob: legacy + storyMetaSelectors, coverUrl→cover, selector mới thắng", StoryMetaCollector.selectorsFromJob(job("T9c", true).copy(authorSelector = ".old", bookTitleSelector = "h1", storyMetaSelectors = mapOf("author" to ".new", "coverUrl" to "img"))) == mapOf("title" to "h1", "author" to ".new", "cover" to "img"))

    // T10: xoá job xoá thông tin truyện
    StoryMetaStore.delete(ctx, "T1")
    check("T10 StoryMetaStore.delete xoá cả bìa", StoryMetaStore.load(ctx, "T1") == null)

    // ───────── F: quét nhanh danh sách theo điểm neo (bản 7.104) ─────────
    class Paged { var perPage = 5; val failPages = HashSet<Int>(); var emptyPage1 = false }
    fun installPaged(site: Site, pg: Paged) {
        install(site)
        val base = FakeWeb.handler
        FakeWeb.handler = { url, js, ok, err ->
            val lp = when {
                url == "https://x/list" -> 1
                url.startsWith("https://x/list?page=") || url.startsWith("https://x/api?page=") -> url.substringAfter("=").toInt()
                else -> 0
            }
            if (lp > 0) {
                if (lp in pg.failPages) err("mạng lỗi trang $lp")
                else {
                    val urls = if (pg.emptyPage1 && lp == 1) emptyList() else site.chapters.keys.toList().drop((lp - 1) * pg.perPage).take(pg.perPage)
                    if (url.startsWith("https://x/api")) ok("{\"items\":[" + urls.joinToString(",") { "{\"u\":\"$it\"}" } + "]}")
                    else ok("{\"links\":[" + urls.joinToString(",") { "\"$it\"" } + "]}")
                }
            } else base(url, js, ok, err)
        }
    }
    fun listPages(): List<Int> = FakeWeb.requested.filter { it.startsWith("https://x/list") || it.startsWith("https://x/api") }.map { if (it.contains("=")) it.substringAfter("=").toInt() else 1 }
    fun chapterOpens(): List<String> = FakeWeb.requested.filter { it.startsWith("https://x/c") || it.startsWith("https://x/n") || it.startsWith("https://x/m") }
    fun archiveOrder(id: String): List<String> = ChapterArchiveRepository.load(ctx, 0, id).keys.toList()
    fun addCh(site: Site, k: String) { site.chapters[k] = Triple("Ch $k", "Noi dung $k ".repeat(10), null) }
    fun pagedJob(id: String) = job(id, true).copy(listPageUrlPattern = "https://x/list?page={page}", maxPages = 50, storyMetaEnabled = false)  // thông tin truyện tắt: nó tải lại trang danh sách (đếm lẫn vào số trang)
    val pg = Paged()

    // F1: lần đầu (chưa có kho) => quét đầy đủ như cũ, ghi điểm neo
    site = mkSite(30)
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F1")).first
    check("F1 lần đầu: đọc đủ trang 1..7 (trang 7 rỗng)", ok && listPages() == (1..7).toList(), listPages().toString())
    val lm1 = ChapterArchiveRepository.loadListMeta(ctx, 0, "F1")
    check("F1 ghi điểm neo: thứ tự 30 chương, trang cuối 6, chưa có lần nhanh", lm1 != null && lm1.order == site.chapters.keys.toList() && lm1.lastPage == 6 && lm1.fastStreak == 0, "${lm1?.order?.size} ${lm1?.lastPage} ${lm1?.fastStreak}")

    // F2: thêm 2 chương CUỐI => quét nhanh: đọc đầu (1), nhảy tới trang cuối-1 (5), rồi 6,7,8; BỎ QUA 2,3,4
    addCh(site, "https://x/c31"); addCh(site, "https://x/c32")
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F1")).first
    check("F2 quét nhanh: chỉ đọc trang 1,5,6,7,8 (bỏ qua 2,3,4)", ok && listPages() == listOf(1, 5, 6, 7, 8), listPages().toString())
    check("F2 chỉ mở 2 chương mới", chapterOpens() == listOf("https://x/c31", "https://x/c32"), chapterOpens().toString())
    check("F2 ebook đủ 32 chương ĐÚNG thứ tự (phần giữa lấy từ kho)", Rec.exported.map { it.sourceUrl } == site.chapters.keys.toList(), Rec.exported.size.toString())
    val lm2 = ChapterArchiveRepository.loadListMeta(ctx, 0, "F1")
    check("F2 điểm neo mới: 32 chương, trang cuối 7, quét nhanh liên tiếp = 1", lm2 != null && lm2.order.size == 32 && lm2.lastPage == 7 && lm2.fastStreak == 1, "${lm2?.order?.size} ${lm2?.lastPage} ${lm2?.fastStreak}")
    check("F2 báo trên tiến độ là quét nhanh", lastNote?.contains("quét nhanh") == true, lastNote ?: "null")
    val pF2 = lastDonePath ?: ""

    // F3: không đổi gì => đọc 1,6,7,8, không mở chương, không xuất lại
    val c3 = Rec.calls
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F1").copy(outputFilePath = pF2)).first
    check("F3 không đổi: quét nhanh 1,6,7,8", ok && listPages() == listOf(1, 6, 7, 8), listPages().toString())
    check("F3 không mở chương nào, không xuất lại", chapterOpens().isEmpty() && Rec.calls == c3, "${chapterOpens()} calls=${Rec.calls} vs $c3")
    check("F3 quét nhanh liên tiếp = 2", ChapterArchiveRepository.loadListMeta(ctx, 0, "F1")?.fastStreak == 2)

    // F4: site CHÈN 2 chương Ở GIỮA => quét nhanh KHÔNG thấy (giới hạn đã nêu); tắt quét nhanh (hoặc tới lượt quét đầy đủ) mới thấy
    run {
        val old = site.chapters.entries.toList()
        site.chapters.clear()
        old.forEachIndexed { i, e -> site.chapters[e.key] = e.value; if (i == 11) { addCh(site, "https://x/m1"); addCh(site, "https://x/m2") } }
    }
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F1")).first
    check("F4 quét nhanh: chương chèn ở giữa CHƯA thấy (giới hạn đã nêu rõ)", ok && archiveOrder("F1").size == 32 && "https://x/m1" !in archiveOrder("F1"), archiveOrder("F1").size.toString())
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F1").copy(listFastScan = false)).first
    check("F4b tắt quét nhanh: đọc đủ trang 1..8 và thấy 2 chương chèn, đúng vị trí", ok && listPages() == (1..8).toList() && archiveOrder("F1") == site.chapters.keys.toList() && chapterOpens() == listOf("https://x/m1", "https://x/m2"), "${listPages()} ${chapterOpens()}")
    check("F4b quét đầy đủ => đặt lại số lần nhanh liên tiếp về 0", ChapterArchiveRepository.loadListMeta(ctx, 0, "F1")?.fastStreak == 0)
    // đủ 10 lần nhanh liên tiếp => lần kế tiếp TỰ quét đầy đủ (bắt chương chèn giữa)
    addCh(site, "https://x/c31x")   // chương mới ở cuối (để job có việc thật)
    run {
        val old = site.chapters.entries.toList()
        site.chapters.clear()
        old.forEachIndexed { i, e -> site.chapters[e.key] = e.value; if (i == 19) addCh(site, "https://x/m3") }
    }
    val lmS = ChapterArchiveRepository.loadListMeta(ctx, 0, "F1")!!
    ChapterArchiveRepository.saveListMeta(ctx, 0, "F1", ChapterArchiveRepository.ListMeta(lmS.order, lmS.lastPage, ListScanPlanner.FAST_SCAN_MAX_STREAK))
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F1")).first
    check("F4c đủ 10 lần nhanh => tự quét ĐẦY ĐỦ, thấy chương chèn m3 + chương mới", ok && listPages().take(8) == (1..8).toList() && "https://x/m3" in archiveOrder("F1") && "https://x/c31x" in archiveOrder("F1") && archiveOrder("F1") == site.chapters.keys.toList(), "${listPages()} ${archiveOrder("F1").size}")

    // F5: trang danh sách ĐẦU trả về 0 chương trong khi kho có => coi là lỗi, GIỮ nguyên kho + danh sách (không làm trống ebook)
    val before5 = archiveOrder("F1")
    pg.emptyPage1 = true
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F1")).first
    pg.emptyPage1 = false
    check("F5 trang đầu rỗng: chỉ đọc trang 1, KHÔNG xoá kho, giữ đủ chương", ok && listPages() == listOf(1) && archiveOrder("F1") == before5 && ChapterArchiveRepository.loadListMeta(ctx, 0, "F1")?.order == before5, "${listPages()} ${archiveOrder("F1").size} vs ${before5.size}")

    // F6: quét ĐẦY ĐỦ nhưng trang 3 lỗi mạng => giữ phần còn lại từ kho (không mất chương khỏi ebook)
    pg.failPages.add(3)
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F1").copy(listFastScan = false)).first
    pg.failPages.clear()
    check("F6 trang 3 lỗi: dừng ở trang 3 nhưng ebook/kho vẫn đủ chương cũ, đúng thứ tự", ok && listPages() == listOf(1, 2, 3) && archiveOrder("F1") == before5, "${listPages()} ${archiveOrder("F1").size} vs ${before5.size}")

    // F7: danh sách MỚI→CŨ (chương mới chèn ở ĐẦU)
    site = Site(); for (i in 20 downTo 1) addCh(site, "https://x/c$i")
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F7")).first
    check("F7 lần đầu đủ 20 chương (4 trang + trang rỗng)", ok && Rec.exported.size == 20 && listPages() == (1..5).toList(), listPages().toString())
    run { val old = site.chapters.entries.toList(); site.chapters.clear(); addCh(site, "https://x/n2"); addCh(site, "https://x/n1"); old.forEach { site.chapters[it.key] = it.value } }
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F7")).first
    check("F7b chương mới ở ĐẦU: quét nhanh bỏ qua trang 2, thấy n2,n1, giữ đúng thứ tự MỚI→CŨ", ok && listPages() == listOf(1, 3, 4, 5, 6) && chapterOpens() == listOf("https://x/n2", "https://x/n1") && Rec.exported.map { it.sourceUrl } == site.chapters.keys.toList(), "${listPages()} ${chapterOpens()}")

    // F8: AJAX — cùng cơ chế
    site = mkSite(30)
    fun ajaxJob(id: String) = job(id, true).copy(ajaxListMode = true, ajaxListUrlTemplate = "https://x/api?page={page}", ajaxListItemsPath = "items", ajaxListUrlField = "u", maxPages = 50, storyMetaEnabled = false)
    installPaged(site, pg)
    ok = runJob(ctx, ajaxJob("F8")).first
    check("F8 AJAX lần đầu đủ 30 chương", ok && Rec.exported.size == 30 && ChapterArchiveRepository.loadListMeta(ctx, 0, "F8")?.lastPage == 6, "${Rec.exported.size}")
    addCh(site, "https://x/c31"); addCh(site, "https://x/c32")
    installPaged(site, pg)
    ok = runJob(ctx, ajaxJob("F8")).first
    check("F8b AJAX quét nhanh: trang 1,5,6,7,8; thêm đúng 2 chương, đủ thứ tự", ok && listPages() == listOf(1, 5, 6, 7, 8) && chapterOpens() == listOf("https://x/c31", "https://x/c32") && Rec.exported.map { it.sourceUrl } == site.chapters.keys.toList(), "${listPages()} ${chapterOpens()}")

    // F9: job KHÔNG có mẫu phân trang => KHÔNG dùng quét nhanh (đường cũ), vẫn cào đúng
    site = mkSite(4); installPaged(site, pg)
    ok = runJob(ctx, job("F9", true).copy(storyMetaEnabled = false)).first
    check("F9 không có mẫu phân trang: đường cũ, đủ 4 chương", ok && Rec.exported.size == 4, "${Rec.exported.size}")
    // kho cũ (không có file điểm neo) + có mẫu: vẫn chạy (thứ tự lấy từ kho), lần sau mới có điểm neo
    site = mkSite(10); installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F10")).first
    run { val f = java.io.File(ctx.filesDir, "ebookleech_archive/0_F10.list.json"); f.delete() }
    addCh(site, "https://x/c11")
    installPaged(site, pg)
    ok = runJob(ctx, pagedJob("F10")).first
    check("F10 kho cũ chưa có điểm neo => quét đầy đủ, vẫn đúng 11 chương, rồi ghi điểm neo", ok && listPages() == (1..4).toList() && Rec.exported.size == 11 && ChapterArchiveRepository.loadListMeta(ctx, 0, "F10")?.lastPage == 3, "${listPages()} ${Rec.exported.size}")

    println(if (fails == 0) "ALL PASS" else "FAILS=$fails")
    System.exit(if (fails == 0) 0 else 1)
}
