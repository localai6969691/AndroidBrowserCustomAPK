import com.colablive.keeper.core.BgNetGate
import com.colablive.keeper.core.BgNetGate.TabItem

var fails = 0
fun check(name: String, cond: Boolean, extra: String = "") { if (!cond) fails++; println((if (cond) "PASS " else "FAIL ") + name + (if (!cond) "  -> $extra" else "")) }
fun tab(url: String, loaded: Boolean = true, pinned: Boolean = false, colab: Boolean = false, media: Boolean = false, upload: Boolean = false, auto: Boolean = false) =
    TabItem(url, loaded, pinned, colab, media, upload, auto)

fun main() {
    // hostOf
    check("hostOf https thường", BgNetGate.hostOf("https://Claude.AI/chat/abc?x=1#y") == "claude.ai")
    check("hostOf có cổng + user", BgNetGate.hostOf("http://user:pw@Example.com:8080/a") == "example.com")
    check("hostOf không có đường dẫn", BgNetGate.hostOf("https://colab.research.google.com") == "colab.research.google.com")
    check("hostOf dấu chấm cuối", BgNetGate.hostOf("https://example.com./x") == "example.com")
    check("hostOf không phải http(s) => rỗng", BgNetGate.hostOf("about:blank") == "" && BgNetGate.hostOf("resource://android/assets/new_tab/index.html") == "" && BgNetGate.hostOf("file:///sdcard/a.html") == "")
    check("hostOf IPv6 => rỗng (không miễn theo miền)", BgNetGate.hostOf("http://[::1]:8000/") == "")
    check("hostOf ký tự lạ/unicode => rỗng", BgNetGate.hostOf("https://exa mple.com/") == "" && BgNetGate.hostOf("https://ví-dụ.vn/") == "")
    check("hostOf rỗng/hỏng", BgNetGate.hostOf("") == "" && BgNetGate.hostOf("https://") == "" && BgNetGate.hostOf("ht!tp://x") == "")
    // exemptHosts
    check("không tab nào có lý do => không miễn gì", BgNetGate.exemptHosts(listOf(tab("https://a.com/"), tab("https://b.com/"))).isEmpty())
    check("ghim chạy nền => miễn miền", BgNetGate.exemptHosts(listOf(tab("https://drive.google.com/x", pinned = true), tab("https://a.com/"))) == listOf("drive.google.com"))
    check("Colab => miễn", BgNetGate.exemptHosts(listOf(tab("https://colab.research.google.com/drive/1", colab = true))) == listOf("colab.research.google.com"))
    check("tab CHƯA TẢI (không có session) không đóng góp danh sách miễn", BgNetGate.exemptHosts(listOf(tab("https://drive.google.com/x", loaded = false, pinned = true))).isEmpty())
    check("đang tải lên / Auto Behavior / media (app mở) đều miễn", BgNetGate.exemptHosts(listOf(tab("https://u.com/", upload = true), tab("https://z.com/", auto = true), tab("https://yt.com/", media = true))) == listOf("u.com", "yt.com", "z.com"))
    check("loại trùng và sắp xếp ổn định", BgNetGate.exemptHosts(listOf(tab("https://b.com/1", pinned = true), tab("https://a.com/", pinned = true), tab("https://B.com/2", pinned = true))) == listOf("a.com", "b.com"))
    check("URL không phải http(s) bị bỏ (không sinh miền rỗng)", BgNetGate.exemptHosts(listOf(tab("about:blank", pinned = true))).isEmpty())
    check("lý do giữ hiển thị đúng ưu tiên", tab("https://a.com/", pinned = true, media = true).keepReason() == "ghim chạy nền" && tab("https://a.com/", media = true).keepReason()!!.contains("media") && tab("https://a.com/").keepReason() == null)
    // chữ ký
    val s1 = BgNetGate.signature(true, 30000, listOf("a.com"))
    check("chữ ký đổi khi bật/tắt, ân hạn hoặc danh sách đổi", s1 != BgNetGate.signature(false, 30000, listOf("a.com")) && s1 != BgNetGate.signature(true, 5000, listOf("a.com")) && s1 != BgNetGate.signature(true, 30000, listOf("a.com", "b.com")))
    check("chữ ký ổn định khi không đổi", s1 == BgNetGate.signature(true, 30000, listOf("a.com")))
    // ân hạn
    check("ân hạn mặc định 30s; 0 hợp lệ; ngoài khoảng => mặc định", BgNetGate.graceMs(30) == 30000L && BgNetGate.graceMs(0) == 0L && BgNetGate.graceMs(-5) == 30000L && BgNetGate.graceMs(99999) == 30000L && BgNetGate.graceMs(600) == 600000L)
    // chốt an toàn
    check("báo nhận đã tới => không quá hạn", !BgNetGate.ackOverdue(1000, 1500, 9000))
    check("chưa quá 4s => chưa quá hạn", !BgNetGate.ackOverdue(1000, 0, 4500))
    check("quá 4s mà chưa báo nhận => QUÁ HẠN (tắt cổng)", BgNetGate.ackOverdue(1000, 0, 5000))
    check("báo nhận của lần gọi TRƯỚC không tính cho lần sau", BgNetGate.ackOverdue(8000, 1500, 12500))
    check("chưa từng gọi (0) => không quá hạn", !BgNetGate.ackOverdue(0, 0, 99999))
    // wanted
    check("wanted: bật + chốt chưa ngắt", BgNetGate.wanted(true, false) && !BgNetGate.wanted(false, false) && !BgNetGate.wanted(true, true))
    println(if (fails == 0) "ALL PASS" else "FAILED $fails")
    if (fails != 0) kotlin.system.exitProcess(1)
}
