# -*- coding: utf-8 -*-
"""
So khớp ĐẦU RA XUẤT FILE giữa app (Kotlin, EbookMarkup/EbookStaging) và LeechDesk (Python, ld/exporter.py + ld/storyexport.py) cho CÙNG đầu vào của sim/StagingMain.kt.

Cách chạy:   LC_ALL=C.utf8 python3 -I check_ld_export.py <thư mục stage.dir của StagingMain> <thư mục LeechDesk (có gói ld/)>

Kiểm: (1) khối <metadata> của content.opf GIỐNG HỆT từng dòng; (2) info.xhtml GIỐNG HỆT; (3) file `.story.json` giống nhau về giá trị (trừ generator và tên file chính);
      (4) đầu TXT và đầu HTML giống nhau; (5) quyết định "có trang Giới thiệu hay không" giống nhau (kể cả ca chỉ-có-tên); (6) 25 ca HTML hỏng (xhtml_cases.json) qua
      xhtml_clean của LeechDesk vẫn là XML nghiêm ngặt, không đổi khi làm sạch lần 2.
Đây là so khớp 2 bản cài đặt trên cùng đầu vào — KHÔNG thay cho epubcheck/máy đọc thật.
"""
import json
import os
import re
import sys
import tempfile
import zipfile
import xml.dom.minidom as md

STAGE, LD = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
sys.path.insert(0, LD)
from ld import exporter, storyexport  # noqa: E402

OK = FAIL = 0


def check(name, cond, extra=""):
    global OK, FAIL
    if cond:
        OK += 1
        print("PASS", name)
    else:
        FAIL += 1
        print("FAIL", name, str(extra)[:600])


NOW_MS = 1_762_900_000_000
NOW = NOW_MS / 1000.0
JOB = {"id": "E1", "name": "Truyện Thử: Tập 1/2?", "outputFormat": "EPUB"}
NASTY = ("<p>Xin chào<br>dòng hai</p><p>A &amp; B &nbsp; C & D &copy; &hellip; &unknownent; 5 < 6 là sai? 7 > 3</p>"
         "<p><IMG SRC=\"images/img_1_1.jpg\" alt=\"a&b\"><BR><hr></p><script>alert('x')</script><style>p{}</style><!-- ghi chú --><p>Hết&#160;chương\u0001 \u000B</p>")
CHAPTERS = [
    {"index": 1, "title": "Chương 1: Mở đầu <&>", "htmlContent": NASTY, "textContent": "Xin chào dòng hai A & B", "sourceUrl": "https://x/c1",
     "images": [{"originalUrl": "https://x/i1.jpg", "localFileName": "img_1_1.jpg", "mimeType": "image/jpeg"}]},
    {"index": 2, "title": "Chương 2", "htmlContent": "<p>Nội dung hai</p><p>Thêm một đoạn nữa ở đây cho đủ chữ.</p>", "textContent": "Nội dung hai Thêm một đoạn nữa ở đây cho đủ chữ.", "sourceUrl": "https://x/c2", "images": []},
    {"index": 3, "title": "Chương 3 \"ngoặc\" 'đơn'", "htmlContent": "<div><p>Ba</p></div>", "textContent": "Ba", "sourceUrl": "https://x/c3", "images": []},
]
NESTED = [{"id": "v1", "label": "Quyển 1 & Mở màn", "children": [{"id": "a1", "label": "Chương 1: Mở đầu <&>", "chapterIndex": 1}, {"id": "a2", "label": "Chương 2", "chapterIndex": 2}]},
          {"id": "v2", "label": "Quyển 2", "children": [{"id": "a3", "label": "Chương 3 \"ngoặc\" 'đơn'", "chapterIndex": 3}]}]
FLAT = [{"id": "auto_%d" % c["index"], "label": c["title"], "chapterIndex": c["index"]} for c in CHAPTERS]
FULL = {
    "title": "Đấu Phá <Thương Khung> & Bạn", "author": "Thiên Tàm Thổ Đậu", "summary": "Dòng một có & ký tự < đặc biệt >.\nDòng hai: \"trích dẫn\" và 'nháy'.\n\nDòng ba 😀 emoji.",
    "genres": ["Tiên hiệp", "Huyền huyễn"], "tags": ["Hệ thống", "tiên hiệp", "Nhiệt huyết"], "status": "ongoing", "statusText": "Đang ra",
    "rating": {"value": 4.5, "scale": 5.0, "count": 1234}, "language": "vi", "sourceUrl": "https://x/truyen?a=1&b=2", "sourceSite": "x", "coverUrl": "https://x/cover.png",
    "coverFile": "cover.png", "coverMime": "image/png", "altTitles": ["Battle Through the Heavens", "斗破苍穹"], "series": "Đấu Phá", "seriesIndex": 2.5,
    "publishedAt": "2020-03-04", "updatedAt": "2026-11-10", "translator": "Nhóm dịch A", "publisher": "NXB Thử", "extra": {"views": "1.2M", "follow": "30k"},
    "sources": {"author": "jsonld"}, "fetchedAt": NOW_MS, "schema": 1,
}
PNG = bytes([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 1, 2, 3, 4])
COVER = ("cover.png", "image/png", PNG)


def kotlin_epub(case):
    d = os.path.join(STAGE, case)
    f = [x for x in os.listdir(d) if x.endswith(".epub")][0]
    return zipfile.ZipFile(os.path.join(d, f))


def metadata_block(opf):
    m = re.search(r"<metadata[^>]*>\n(.*?)\n  </metadata>", opf, re.S)
    return m.group(1) if m else None


def py_epub(job, toc, story, cover):
    out = os.path.join(tempfile.mkdtemp(prefix="ldx"), "o.epub")
    loader = lambda n: b"\xff\xd8\xff\xe0\x09\x09\x09" if n == "img_1_1.jpg" else None
    exporter.export_epub(job, CHAPTERS, toc, out, loader, {}, story, cover, NOW)
    return zipfile.ZipFile(out)


# ---- E1: đầy đủ + lồng 2 tầng + bìa ----
zk, zp = kotlin_epub("E1_full_nested"), py_epub(JOB, NESTED, FULL, COVER)
mk, mp = metadata_block(zk.read("OEBPS/content.opf").decode()), metadata_block(zp.read("OEBPS/content.opf").decode())
check("E1: khối <metadata> content.opf GIỐNG HỆT từng dòng (Kotlin = Python)", mk is not None and mk == mp,
      "\n".join(x for x in __import__("difflib").unified_diff((mk or "").split("\n"), (mp or "").split("\n"), lineterm="")))
check("E1: info.xhtml GIỐNG HỆT", zk.read("OEBPS/info.xhtml").decode() == zp.read("OEBPS/info.xhtml").decode())
check("E1: ảnh bìa nằm trong EPUB, cùng nội dung", zk.read("OEBPS/images/cover.png") == zp.read("OEBPS/images/cover.png"))
for n in zp.namelist():
    if n.endswith((".xhtml", ".ncx", ".opf")):
        try:
            md.parseString(zp.read(n))
        except Exception as e:
            check("E1: %s là XML hợp lệ" % n, False, e)
            break
else:
    check("E1: mọi .xhtml/.ncx/.opf của bản Python là XML nghiêm ngặt", True)
opf = zp.read("OEBPS/content.opf").decode()
check("E1: manifest có cover-image (properties) + trang info đứng đầu spine", 'properties="cover-image"' in opf and opf.index('idref="info"') < opf.index('idref="chapter_1"'))
ncx_k, ncx_p = zk.read("OEBPS/toc.ncx").decode(), zp.read("OEBPS/toc.ncx").decode()
check("E1: toc.ncx cùng số điểm (info + 2 quyển + 3 chương = 6) và 'Giới thiệu' đứng đầu", ncx_k.count("<navPoint") == ncx_p.count("<navPoint") == 6 and ncx_p.index("Giới thiệu") < ncx_p.index("Quyển 1"))
nav_k, nav_p = zk.read("OEBPS/nav.xhtml").decode(), zp.read("OEBPS/nav.xhtml").decode()
check("E1: nav.xhtml cùng 4 liên kết (info + 3 chương)", nav_k.count("<a ") == nav_p.count("<a ") == 4)
# playOrder liên tục 1..n
po = [int(x) for x in re.findall(r'playOrder="(\d+)"', ncx_p)]
check("E1: playOrder của ncx liên tục 1..6", po == list(range(1, 7)), po)

# ---- sidecar ----
sk = json.loads(open(os.path.join(STAGE, "E1_full_nested", [x for x in os.listdir(os.path.join(STAGE, "E1_full_nested")) if x.endswith(".story.json")][0]), encoding="utf-8").read())
sp = json.loads(storyexport.sidecar_json(JOB, FULL, CHAPTERS, "main.epub", "base.cover.png", NOW, "g"))
for d in (sk, sp):
    d.pop("generator", None)
    d["files"].pop("ebook", None)
    d["files"]["cover"] = "X" if d["files"].get("cover") else ""
    if isinstance(d.get("webMapping"), dict):      # tên file bìa chứa mốc thời gian xuất => chỉ so sự có/không
        d["webMapping"]["featured_image"] = "X" if d["webMapping"].get("featured_image") else ""
check("E1: .story.json giống nhau về giá trị (schema, story, stats, chapters, webMapping)", sk == sp,
      json.dumps({k: (sk.get(k), sp.get(k)) for k in sk if sk.get(k) != sp.get(k)}, ensure_ascii=False))

# ---- E2/E5/E6: quyết định có trang giới thiệu ----
for case, story, cover, expect in (("E2_blank_flat", {}, None, False), ("E5_coveronly", {}, COVER, True), ("E6_titleonly", {"title": "Chỉ Có Tên Truyện"}, None, False)):
    if not os.path.isdir(os.path.join(STAGE, case)):
        continue
    zk2 = kotlin_epub(case)
    has_k = "OEBPS/info.xhtml" in zk2.namelist()
    has_p = storyexport.has_info_page(story, cover)
    check("%s: Kotlin và Python cùng quyết định %s trang Giới thiệu" % (case, "CÓ" if expect else "KHÔNG"), has_k == has_p == expect, (has_k, has_p))
    zp2 = py_epub(dict(JOB, id=case[:2]), FLAT, story, cover)
    check("%s: bản Python %s info.xhtml" % (case, "có" if expect else "không có"), ("OEBPS/info.xhtml" in zp2.namelist()) == expect)

# ---- TXT / HTML ----
def read_main(case, ext):
    d = os.path.join(STAGE, case)
    return open(os.path.join(d, [x for x in os.listdir(d) if x.endswith(ext)][0]), encoding="utf-8").read()


tk = read_main("T1_txt", ".txt")
hdr = storyexport.txt_header(storyexport.book_title(JOB["name"], FULL), FULL)
check("T1: đầu TXT (tên + '=' + dòng thông tin + giới thiệu) GIỐNG HỆT", tk.startswith(hdr), tk[:400] + "\n---\n" + hdr[:400])
t2 = read_main("T2_txt_blank", ".txt")
check("T2: TXT không thông tin: chỉ tên + '=' như bản cũ", t2.startswith(JOB["name"] + "\n" + "=" * 60 + "\n\n") and storyexport.txt_header(JOB["name"], {}) == JOB["name"] + "\n" + "=" * 60 + "\n\n")
hk = read_main("H1_html", ".html")
hh = storyexport.html_header(storyexport.book_title(JOB["name"], FULL), FULL, "images/cover.png")
check("H1: đầu HTML (bìa + h1 + ul.story-info + tóm tắt) GIỐNG HỆT", hh in hk, hh[:300])

SRC_ONLY = {"title": "Tên Truyện", "sourceUrl": "https://x.test/truyen", "sourceSite": "x.test", "language": "vi"}
if os.path.isdir(os.path.join(STAGE, "T3_txt_sourceonly")):
    t3 = read_main("T3_txt_sourceonly", ".txt")
    check("T3: chỉ tên + nguồn/ngôn ngữ => đầu TXT như bản cũ, Kotlin = Python", t3.startswith(storyexport.txt_header("Tên Truyện", SRC_ONLY)) and storyexport.txt_header("Tên Truyện", SRC_ONLY) == "Tên Truyện\n" + "=" * 60 + "\n\n", t3[:200])
    h3 = read_main("H3_html_sourceonly", ".html")
    check("H3: chỉ tên + nguồn => đầu HTML Kotlin = Python (không story-info)", storyexport.html_header("Tên Truyện", SRC_ONLY, "") in h3 and "story-info\">" not in storyexport.html_header("Tên Truyện", SRC_ONLY, ""))

# ---- 25 ca HTML hỏng ----
cases = json.load(open(os.path.join(STAGE, "xhtml_cases.json"), encoding="utf-8"))
bad = []
for c in cases:
    o = exporter.xhtml_clean(c["in"])
    try:
        md.parseString('<?xml version="1.0" encoding="UTF-8"?><html xmlns="http://www.w3.org/1999/xhtml"><body>' + o + "</body></html>")
    except Exception as e:
        bad.append((c["name"], str(e)))
    if exporter.xhtml_clean(o) != o:
        bad.append((c["name"], "không bất biến khi làm sạch lần 2"))
check("xhtml_clean (LeechDesk): %d ca HTML hỏng đều ra XML nghiêm ngặt + bất biến khi làm sạch lần 2" % len(cases), not bad, bad)
nasty_out = exporter.xhtml_clean(NASTY)
check("xhtml_clean: bỏ script/style/comment, bỏ ký tự điều khiển, escape < > &", "script" not in nasty_out and "alert" not in nasty_out and "\x01" not in nasty_out and "\x0b" not in nasty_out and "5 &lt; 6" in nasty_out and "7 &gt; 3" in nasty_out, nasty_out)

print("\nKẾT QUẢ so khớp xuất file Kotlin ↔ LeechDesk: %d pass, %d fail" % (OK, FAIL))
sys.exit(1 if FAIL else 0)
