# Mô phỏng luồng cào EbookLeech trên JVM (không cần điện thoại)

Chạy THẬT mã `EbookLeechCrawler` + các model với web giả (`stubs/`), để kiểm logic cào tăng dần / bỏ qua chương / chương nhiều trang / chống vòng lặp.
KHÔNG kiểm: GeckoView, eval_bridge, tải trang thật, Android API (đều là stub). Lỗi chỉ lộ trên máy thật vẫn có thể còn.

Cách chạy (cần kotlinc 2.0.x + java), từ thư mục này:

    E=../../app/src/main/java/com/colablive/keeper/features/ebookleech
    kotlinc -d out $(find stubs -name '*.kt') sim/Main.kt $E/model/ChapterArchiveRepository.kt $E/model/LeechChapter.kt $E/model/LeechImage.kt \
      $E/model/LeechJob.kt $E/model/CrawlStage.kt $E/model/TocNode.kt $E/model/RegexRule.kt $E/model/CrawlCheckpoint.kt $E/model/CrawlCheckpointRepository.kt \
      $E/engine/ContentProcessor.kt $E/engine/ContentSpinner.kt $E/engine/JsonPathExtractor.kt $E/engine/EbookLeechCrawler.kt $E/export/ExportFollowUp.kt
    java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dsim.dir=$PWD/simdata -cp "out:<kotlinc>/lib/kotlin-stdlib.jar" MainKt

Kết quả mong đợi: `ALL PASS` (58 kiểm tra ở bản 7.103; bản 7.102 có 53, bản 7.101 có 37). Bản 7.102 thêm `ExportFollowUp.kt` vào danh sách biên dịch và 16 kiểm tra S16–S23: lần đầu không báo chương mới, thêm chương => `onNewChapters(N, tổng)`, không đổi => không báo, tắt `notifyNewChapters`, job không tăng dần vẫn báo, sửa chương cũ không tính chương mới, xoá kho mất mốc xuất, đổi `updateExistingFile` ép xuất lại. Mô phỏng chỉ kiểm LOGIC gọi hàm thông báo (Notification là stub). Khi sửa `EbookLeechCrawler.kt`, nếu thêm phụ thuộc mới phải bổ sung stub tương ứng.

Bản 7.103 đổi S22 ("Xoá kho" chỉ xoá kho chương, GIỮ mốc xuất => lần sau vẫn báo đúng `+N chương mới`; xoá hẳn job mới xoá mốc) và thêm S22b (mốc cũ không trùng URL nào => coi như xuất lần đầu, không báo cả cuốn là chương mới). Hai thay đổi nằm ở `ChapterArchiveRepository.deleteArchive` và `ExportFollowUp.compare`.

## Bản 7.104 — thêm 4 bộ kiểm (đều chạy trên JVM, KHÔNG phải trên điện thoại)

**Lưu ý môi trường:** khi mô phỏng ghi tên file có dấu tiếng Việt, chạy JVM với `LC_ALL=C.utf8` và `-Dsun.jnu.encoding=UTF-8`, nếu không tên file thành `?` (lỗi của môi trường chạy thử, không phải của ứng dụng).

1. **Mô phỏng cào (`sim/Main.kt`) — nay 105 kiểm tra** (F1–F10 quét nhanh theo điểm neo + T1–T10 thông tin truyện, ngoài các kiểm tra S cũ). Danh sách biên dịch thêm `E/engine/ListScanPlanner.kt`, `E/engine/StoryMetaCollector.kt`, `E/engine/StoryMetaJs.kt`, `E/model/StoryMeta.kt` và `E/model/StoryMetaStore.kt` (thiếu `StoryMetaStore.kt` thì biên dịch báo "unresolved reference" ở `EbookLeechCrawler.kt` và `sim/Main.kt`). Lần chạy cuối của 7.104: 105/105 PASS. Job phân trang/ajax trong F-test đặt `storyMetaEnabled=false` để không có thêm yêu cầu trang danh sách do thu thập thông tin truyện.
2. **Xuất file (`sim/StagingMain.kt` + `validate_staging.py`) — 544 kiểm tra (12 bộ xuất file + 25 ca HTML hỏng), `ALL PASS`.** Biên dịch: `stubs/*` + `sim/StagingMain.kt` + `LeechChapter/LeechImage/LeechJob/CrawlStage/TocNode/RegexRule/StoryMeta` + `export/EbookMarkup.kt` + `export/EbookStaging.kt`. `StagingMain` ghi EPUB/TXT/HTML + `.story.json` vào một thư mục, rồi `python3 -I validate_staging.py <thư mục>` kiểm bằng bộ phân tích KHÁC (zip, XML nghiêm ngặt, OPF/NCX/nav, liên kết, schema `ebookleech.story/1`). Không phải epubcheck.
   Ca đáng chú ý: `E6_titleonly` (chỉ có tên truyện ⇒ KHÔNG có trang "Giới thiệu"), `T3_txt_sourceonly` / `H3_html_sourceonly` (chỉ có nguồn/ngôn ngữ ⇒ TXT/HTML KHÔNG có khối thông tin — luật `headerRows`: khối chỉ thêm khi có gì ngoài tên truyện). Chạy với `LC_ALL=C.utf8 -Dsun.jnu.encoding=UTF-8 -Dfile.encoding=UTF-8`.
   Ghi chú: `check_ld_export.py <thư mục dự án> <thư mục LeechDesk>` so xuất file của LeechDesk (Python) với của app (Kotlin) trên cùng dữ liệu — 22 kiểm tra, gồm T3/H3.
3. **Bộ lập kế hoạch quét nhanh (`gen_planner_cases.py` + `sim/PlannerMain.kt`) — 3000 kịch bản ngẫu nhiên, Python ↔ Kotlin phải cho Y HỆT** (danh sách chương, meta, thứ tự từng trang đã đọc). `python3 -I gen_planner_cases.py <crawler.py> planner_cases.json 3000` rồi chạy `PlannerMain` (biên dịch: `stubs/org/json/J.kt sim/PlannerMain.kt E/engine/ListScanPlanner.kt`). Sửa thuật toán ở MỘT bên thì bên kia phải sửa theo, nếu không bộ này sẽ đỏ.
4. **Gieo kho từ máy (`sim/SeedMain.kt` + `check_seed.py`).** Biên dịch: `stubs/org/json/J.kt sim/SeedMain.kt E/remote/ArchiveSeed.kt`; `check_seed.py <crawler.py> <seed.json>` kiểm runner Python đọc đúng kho đã gieo (chương, thứ tự, điểm neo, thông tin truyện).

Ngoài thư mục này còn `core/ChallengeNav.kt` (hoãn captcha tab nền) có bài kiểm riêng chạy một mình (biên dịch `ChallengeNav.kt` + file test) — 20 kiểm tra: nhận diện URL, trích đích `to=` (chỉ cùng host + https), bảng chân trị `shouldDefer`, đọc cờ nguồn điều hướng bằng reflection (thiếu trường => không hoãn).

**Chưa kiểm được bằng JVM:** GeckoView thật (cờ `isDirectNavigation/isRedirect/triggerUri` của `LoadRequest` bản 145 chưa xác minh), gọi GitHub của `RemoteCrawlRunner`, giao diện Android.

## Bản 7.107 — `sim/LocalePolicyTest.kt` (22 kiểm tra, JVM)
Biên dịch: `core/LocalePolicy.kt` + `features/fingerprint/DeviceProfiles.kt` + `sim/LocalePolicyTest.kt`; chạy lớp `LocalePolicyTestKt`. Kiểm: hồ sơ ngôn ngữ cố định = lựa chọn CÓ dấu ý định hoặc máy thật (không bao giờ băm theo tên), quét mọi chỉ số, và mô phỏng vòng đời ô chọn Locale Profile (mở Cài đặt không ghi gì; chọn/bỏ chọn). Không kiểm được: `Spinner` và `LocaleList` thật trên điện thoại.

## Bản 7.108 — `sim/BgNetGateTest.kt` (27 kiểm tra, JVM) thêm 2 ca phiên media
Biên dịch: `core/BgNetGate.kt` + `sim/BgNetGateTest.kt`; chạy lớp `BgNetGateTestKt`. Hai ca mới: tab giữ phiên media (đang phát hoặc tạm dừng) được miễn miền và lý do ghi "phiên media" (ca YouTube nhạc nền bị 7.106 chặn nhầm khi app ra nền); tab không giữ phiên thì không được miễn. Chưa kiểm được bằng JVM: việc `GeckoViewEngine` đẩy cổng đúng lúc `onPlay`/`updateNativeMediaSession`/release trên máy thật.
