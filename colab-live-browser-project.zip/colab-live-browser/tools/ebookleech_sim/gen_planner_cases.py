#!/usr/bin/env python3
"""Sinh kịch bản ngẫu nhiên (có hạt giống cố định) cho ListScanPlanner và kết quả MONG ĐỢI do bản Python (crawler.py — runner từ xa) tính ra.
Bản Kotlin (sim/PlannerMain.kt) chạy lại đúng kịch bản và phải cho Y HỆT: danh sách chương, meta, và thứ tự từng trang đã đọc.
Chạy:  python3 -I gen_planner_cases.py <crawler.py> <out.json> [số kịch bản]"""
import sys, json, random, importlib.util
spec = importlib.util.spec_from_file_location("crawler", sys.argv[1]); cr = importlib.util.module_from_spec(spec); spec.loader.exec_module(cr)
out_path = sys.argv[2]; N = int(sys.argv[3]) if len(sys.argv) > 3 else 3000
rnd = random.Random(20261112)

def mk(n, tag="c"): return [f"https://x/{tag}{i}" for i in range(1, n + 1)]

def paginate(urls, per):
    pages = {}
    total = max(1, -(-len(urls) // per))
    for p in range(1, total + 1): pages[p] = urls[(p - 1) * per:p * per]
    return pages, total

cases = []
kinds = ["append", "prepend", "both", "same", "insert_mid", "delete_mid", "shuffle", "fewer", "reverse", "unknown_all", "blocked", "wrap_last", "empty_site", "dup_links"]
for ci in range(N):
    kind = rnd.choice(kinds)
    per = rnd.choice([1, 2, 3, 5, 10, 20])
    n0 = rnd.randint(1, 120)
    old = mk(n0)
    site = list(old)
    if kind == "append": site = old + mk(rnd.randint(1, 15), "n")
    elif kind == "prepend": site = mk(rnd.randint(1, 15), "n") + old
    elif kind == "both": site = mk(rnd.randint(1, 8), "p") + old + mk(rnd.randint(1, 8), "n")
    elif kind == "insert_mid" and len(old) > 3:
        at = rnd.randint(1, len(old) - 1); site = old[:at] + mk(rnd.randint(1, 5), "m") + old[at:]
    elif kind == "delete_mid" and len(old) > 6:
        a = rnd.randint(1, len(old) - 4); site = old[:a] + old[a + rnd.randint(1, 3):]
    elif kind == "shuffle": site = list(old); rnd.shuffle(site)
    elif kind == "fewer": site = old[:max(1, len(old) // 2)]
    elif kind == "reverse": site = list(reversed(old)) + mk(3, "n")
    elif kind == "unknown_all": site = mk(rnd.randint(1, 60), "z")
    elif kind == "empty_site": site = []
    elif kind == "dup_links": site = old + old[-3:] + mk(2, "n")
    pages, total = paginate(site, per)
    old_pages, old_total = paginate(old, per)
    hint = old_total if rnd.random() < 0.9 else rnd.choice([0, 1, 2, old_total + 3])
    max_pages = rnd.choice([1, 2, 3, 5, 10, 50, total + 2, total, max(1, total - 1)])
    known = list(old) if rnd.random() < 0.9 else (list(old) + [""] + old[:2])
    if rnd.random() < 0.15: known = list(reversed(old))
    fast = rnd.random() < 0.8
    pg = {}
    for p in range(1, min(max_pages, total + 6) + 8):
        if p in pages: pg[p] = list(pages[p])
        else: pg[p] = list(pages[total]) if kind == "wrap_last" and total else []
        if rnd.random() < 0.05 and p in pages: pg[p] = pg[p] + [""]   # link rỗng lẫn vào
    blocked = []
    if kind == "blocked" or rnd.random() < 0.05:
        blocked = [rnd.randint(1, max(1, total + 1))]
        for b in blocked: pg[b] = None
    trace = []
    def fetch(p, pg=pg, trace=trace): trace.append(p); return pg.get(p, [])
    links, meta = cr.run_list_scan(fetch, max_pages, known, hint, fast)
    cases.append({"id": ci, "kind": kind, "pages": {str(k): v for k, v in pg.items()}, "maxPages": max_pages, "known": known, "hint": hint, "fast": fast,
                  "expect": {"links": links, "meta": meta, "trace": trace}})
json.dump(cases, open(out_path, "w", ensure_ascii=False and None) if False else open(out_path, "w", encoding="utf-8"), ensure_ascii=False)
from collections import Counter
print("cases", len(cases), dict(Counter(c["expect"]["meta"].get("mode") for c in cases)), "blocked", sum(1 for c in cases if c["expect"]["meta"].get("blocked")))
