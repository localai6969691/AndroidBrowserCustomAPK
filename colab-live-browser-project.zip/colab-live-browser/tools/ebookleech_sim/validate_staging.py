#!/usr/bin/env python3
"""Kiểm file EPUB/TXT/HTML + .story.json do EbookStaging (StagingMain.kt) sinh ra, bằng bộ phân tích KHÁC (Python): zip, XML nghiêm ngặt, OPF/NCX/nav, liên kết, schema.
Chạy:  python3 -I validate_staging.py <thư mục stage.dir>
KHÔNG phải epubcheck (không có mạng để tải) — chỉ kiểm những điều tra được bằng chuẩn XML/zip + các ràng buộc EPUB 3 chính. Trình đọc thật vẫn có thể chê thêm."""
import sys, os, json, zipfile, re
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

ROOT = sys.argv[1]
fails = 0
def check(name, cond, extra=""):
    global fails
    if not cond: fails += 1
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(extra)[:400]))

OPF = "{http://www.idpf.org/2007/opf}"; DC = "{http://purl.org/dc/elements/1.1/}"; NCX = "{http://www.daisy.org/z3986/2005/ncx/}"
XH = "{http://www.w3.org/1999/xhtml}"; CT = "{urn:oasis:names:tc:opendocument:xmlns:container}"

def parse_strict(name, data):
    try:
        if not data.startswith(b"<?xml"): return None, "không bắt đầu bằng <?xml (có ký tự thừa phía trước)"
        return ET.fromstring(data), None
    except ET.ParseError as e:
        return None, str(e)

def files(d): return sorted(os.listdir(d))

def validate_epub(tag, d, exp):
    fs = files(d); epubs = [f for f in fs if f.endswith(".epub")]
    check(f"{tag}: có đúng 1 file .epub", len(epubs) == 1, fs)
    if len(epubs) != 1: return
    path = os.path.join(d, epubs[0])
    z = zipfile.ZipFile(path); names = z.namelist()
    check(f"{tag}: zip không hỏng (testzip)", z.testzip() is None)
    infos = z.infolist()
    check(f"{tag}: 'mimetype' là mục ĐẦU, không nén, nội dung đúng, không extra", infos[0].filename == "mimetype" and infos[0].compress_type == 0 and z.read("mimetype") == b"application/epub+zip" and infos[0].extra == b"", (infos[0].filename, infos[0].compress_type))
    check(f"{tag}: không có đường dẫn trùng trong zip", len(names) == len(set(names)))
    cont, err = parse_strict("container", z.read("META-INF/container.xml")); check(f"{tag}: container.xml hợp lệ", cont is not None, err)
    rf = cont.find(f".//{CT}rootfile").get("full-path"); check(f"{tag}: rootfile tồn tại", rf in names, rf)
    opf, err = parse_strict("opf", z.read(rf)); check(f"{tag}: content.opf là XML hợp lệ, <?xml ở byte 0", opf is not None, err)
    if opf is None: return
    base = rf.rsplit("/", 1)[0] + "/" if "/" in rf else ""
    md = opf.find(f"{OPF}metadata"); man = opf.find(f"{OPF}manifest"); spine = opf.find(f"{OPF}spine")
    items = {i.get("id"): i for i in man}
    check(f"{tag}: id manifest không trùng", len(items) == len(list(man)), [i.get("id") for i in man])
    missing = [i.get("href") for i in man if (base + i.get("href")) not in names]
    check(f"{tag}: mọi href trong manifest đều có trong zip", not missing, missing)
    check(f"{tag}: mọi itemref trong spine có trong manifest", all(r.get("idref") in items for r in spine), [r.get("idref") for r in spine])
    check(f"{tag}: spine toc → ncx tồn tại", spine.get("toc") in items and items[spine.get("toc")].get("media-type") == "application/x-dtbncx+xml")
    navs = [i for i in man if "nav" in (i.get("properties") or "").split()]
    check(f"{tag}: có đúng 1 mục nav", len(navs) == 1)
    uid = opf.get("unique-identifier"); ids = [e for e in md.findall(f"{DC}identifier") if e.get("id") == uid]
    check(f"{tag}: unique-identifier trỏ tới dc:identifier", len(ids) == 1 and ids[0].text, uid)
    check(f"{tag}: có dc:title + dc:language", md.find(f"{DC}title") is not None and md.find(f"{DC}title").text and md.find(f"{DC}language") is not None)
    check(f"{tag}: có dcterms:modified dạng ISO", any(m.get("property") == "dcterms:modified" and re.match(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$", m.text or "") for m in md.findall(f"{OPF}meta")))
    # metadata theo kỳ vọng
    creators = [e.text for e in md.findall(f"{DC}creator")]
    check(f"{tag}: tác giả trong dc:creator", creators == exp.get("creators", []), creators)
    desc = md.find(f"{DC}description")
    check(f"{tag}: tóm tắt trong dc:description (nguyên văn, kể cả & < > \" ' và xuống dòng)", (desc.text if desc is not None else None) == exp.get("summary"), (desc.text if desc is not None else None))
    subj = [e.text for e in md.findall(f"{DC}subject")]
    check(f"{tag}: dc:subject = thể loại + tag (không trùng, không phân biệt hoa thường)", subj == exp.get("subjects", []), subj)
    check(f"{tag}: tiêu đề sách", md.find(f"{DC}title").text == exp["title"], md.find(f"{DC}title").text)
    metas = {(m.get("name") or m.get("property")): (m.get("content") if m.get("name") else m.text) for m in md.findall(f"{OPF}meta")}
    for k, v in exp.get("metas", {}).items():
        check(f"{tag}: meta {k} = {v!r}", metas.get(k) == v, metas.get(k))
    for k in exp.get("no_metas", []):
        check(f"{tag}: KHÔNG có meta {k}", k not in metas, metas.get(k))
    # bìa
    cov_items = [i for i in man if "cover-image" in (i.get("properties") or "").split()]
    if exp.get("cover"):
        check(f"{tag}: có đúng 1 mục cover-image", len(cov_items) == 1, len(cov_items))
        ci = cov_items[0]; data = z.read(base + ci.get("href"))
        sig_ok = data.startswith(b"\x89PNG") if ci.get("media-type") == "image/png" else data.startswith(b"\xff\xd8\xff")
        check(f"{tag}: ảnh bìa đúng loại/byte ({ci.get('media-type')})", sig_ok and ci.get("media-type") == exp["cover"], ci.get("media-type"))
        check(f"{tag}: <meta name=cover> trỏ id mục bìa", metas.get("cover") == ci.get("id"), metas.get("cover"))
    else:
        check(f"{tag}: không có bìa", not cov_items and "cover" not in metas)
    # info page
    has_info = "info" in items
    check(f"{tag}: trang Giới thiệu {'có' if exp['info'] else 'không có'} (đúng kỳ vọng)", has_info == exp["info"], has_info)
    check(f"{tag}: spine bắt đầu bằng info" if exp["info"] else f"{tag}: spine bắt đầu bằng chương", (spine[0].get("idref") == "info") == exp["info"], spine[0].get("idref"))
    # mọi xhtml phải là XML hợp lệ; tìm chuỗi cấm
    for i in man:
        if i.get("media-type") == "application/xhtml+xml":
            data = z.read(base + i.get("href"))
            root, err = parse_strict(i.get("href"), data)
            check(f"{tag}: {i.get('href')} là XML/XHTML hợp lệ", root is not None, err)
            if root is not None:
                check(f"{tag}: {i.get('href')} không còn <script>/<style> nội dung/comment", b"<script" not in data and b"alert(" not in data and b"<!--" not in data)
                bad_ctrl = re.search(rb"[\x00-\x08\x0b\x0c\x0e-\x1f]", data)
                check(f"{tag}: {i.get('href')} không có ký tự điều khiển cấm trong XML 1.0", not bad_ctrl)
                # ảnh tham chiếu phải có trong zip
                dirn = (base + i.get("href")).rsplit("/", 1)[0]
                for im in root.iter(f"{XH}img"):
                    src = im.get("src"); p = os.path.normpath(dirn + "/" + src).replace("\\", "/")
                    check(f"{tag}: {i.get('href')} ảnh {src} có trong zip", p in names, p)
                for a in root.iter(f"{XH}a"):
                    h = (a.get("href") or "").split("#")[0]
                    if h and "://" not in h: check(f"{tag}: {i.get('href')} liên kết {h} có trong zip", os.path.normpath(dirn + "/" + h).replace("\\", "/") in names, h)
    # ncx
    ncx, err = parse_strict("ncx", z.read(base + items[spine.get("toc")].get("href"))); check(f"{tag}: toc.ncx hợp lệ", ncx is not None, err)
    if ncx is not None:
        pts = list(ncx.iter(f"{NCX}navPoint")); orders = [int(p.get("playOrder")) for p in pts]
        check(f"{tag}: playOrder duy nhất và tăng dần", orders == sorted(set(orders)) and orders == list(range(1, len(orders) + 1)), orders)
        check(f"{tag}: id navPoint duy nhất", len({p.get("id") for p in pts}) == len(pts))
        bad = [p.find(f"{NCX}content").get("src") for p in pts if (base + p.find(f"{NCX}content").get("src").split('#')[0]) not in names]
        check(f"{tag}: mọi navPoint trỏ tới file có trong zip", not bad, bad)
        check(f"{tag}: ncx dtb:uid khớp dc:identifier", [m.get("content") for m in ncx.iter(f"{NCX}meta") if m.get("name") == "dtb:uid"] == [ids[0].text])
        check(f"{tag}: số mục ncx = {exp['ncx_points']}", len(pts) == exp["ncx_points"], len(pts))
        depth = [m.get("content") for m in ncx.iter(f"{NCX}meta") if m.get("name") == "dtb:depth"]
        check(f"{tag}: dtb:depth = {exp['depth']}", depth == [str(exp["depth"])], depth)
    nav = ET.fromstring(z.read(base + navs[0].get("href")))
    navnode = [n for n in nav.iter(f"{XH}nav")]
    check(f"{tag}: nav.xhtml có <nav epub:type=toc>", len(navnode) == 1 and navnode[0].get("{http://www.idpf.org/2007/ops}type") == "toc")
    check(f"{tag}: nav có {exp['nav_links']} liên kết", len(list(nav.iter(f"{XH}a"))) == exp["nav_links"], len(list(nav.iter(f"{XH}a"))))
    # nội dung sách thật sự có chữ chương
    c1 = z.read(base + "chapter_1.xhtml").decode("utf-8")
    check(f"{tag}: chương 1 giữ chữ gốc (xuống dòng <br/>, '&amp;', mã số &#160;)", "Xin chào<br/>dòng hai" in c1 and "A &amp; B" in c1 and "&#160;" in c1 and "&amp;unknownent;" in c1 and "5 &lt; 6" in c1, c1[:600])
    if exp["info"]:
        info = z.read(base + "info.xhtml").decode("utf-8")
        for s in exp.get("info_contains", []): check(f"{tag}: trang giới thiệu chứa {s!r}", s in info, info[:800])
    return z

def sidecar(tag, d, exp):
    fs = files(d); sj = [f for f in fs if f.endswith(".story.json")]
    if not exp.get("sidecar"):
        check(f"{tag}: KHÔNG có .story.json", not sj, fs); return
    check(f"{tag}: có đúng 1 .story.json", len(sj) == 1, fs)
    j = json.load(open(os.path.join(d, sj[0]), encoding="utf-8"))
    main = [f for f in fs if f.endswith((".epub", ".txt", ".html"))][0]
    check(f"{tag}: schema ebookleech.story/1 + generator + exportedAt ISO", j["schema"] == "ebookleech.story/1" and j["generator"] and re.match(r"^\d{4}-\d\d-\d\dT", j["exportedAt"]))
    check(f"{tag}: tên file kèm khớp file chính ({main})", j["files"]["ebook"] == main and sj[0] == main.rsplit(".", 1)[0] + ".story.json", (j["files"], sj))
    cf = j["files"]["cover"]
    if exp.get("cover"):
        check(f"{tag}: file bìa kèm tồn tại, cùng tên gốc, đúng byte", cf == main.rsplit(".", 1)[0] + ".cover." + exp["cover_ext"] and os.path.exists(os.path.join(d, cf)) and open(os.path.join(d, cf), "rb").read().startswith(exp["cover_magic"]), cf)
        check(f"{tag}: webMapping.featured_image = file bìa", j["webMapping"]["featured_image"] == cf)
    else:
        check(f"{tag}: không bìa => files.cover rỗng và không có file .cover.*", cf == "" and not [f for f in fs if ".cover." in f], fs)
    check(f"{tag}: stats chương/từ", j["stats"]["chapterCount"] == 3 and j["stats"]["wordCount"] > 0 and len(j["chapters"]) == 3, j["stats"])
    check(f"{tag}: danh sách chương có sourceUrl + file", [c["sourceUrl"] for c in j["chapters"]] == ["https://x/c1", "https://x/c2", "https://x/c3"] and j["chapters"][0]["file"] == "chapter_1.xhtml")
    w = j["webMapping"]
    check(f"{tag}: webMapping.post_title = tên sách", w["post_title"] == exp["title"], w["post_title"])
    if exp.get("full"):
        check(f"{tag}: categories = thể loại, tags = tag", w["categories"] == ["Tiên hiệp", "Huyền huyễn"] and w["tags"] == ["Hệ thống", "tiên hiệp", "Nhiệt huyết"], (w["categories"], w["tags"]))
        check(f"{tag}: post_excerpt ≤ 300 ký tự, 1 dòng, kết thúc '...' nếu cắt", len(w["post_excerpt"]) <= 300 and "\n" not in w["post_excerpt"], len(w["post_excerpt"]))
        check(f"{tag}: post_content là HTML có <p>, đã escape", "<p>" in w["post_content"] and "&amp;" in w["post_content"] and "< đặc" not in w["post_content"], w["post_content"][:200])
        m = w["meta"]
        check(f"{tag}: meta tác giả/tình trạng/điểm/nguồn/bộ truyện/tên khác/trường tuỳ chỉnh", m["author"] == "Thiên Tàm Thổ Đậu" and m["status"] == "ongoing" and m["rating"]["value"] == 4.5 and m["rating"]["count"] == 1234 and m["source_url"] == "https://x/truyen?a=1&b=2" and m["series"] == "Đấu Phá" and m["alt_titles"][1] == "斗破苍穹" and m["views"] == "1.2M" and m["follow"] == "30k" and m["translator"] == "Nhóm dịch A", m)
        s = j["story"]
        check(f"{tag}: story.* đủ trường (tóm tắt nguyên văn, tình trạng, bộ truyện #2.5, mốc thời gian)", s["summary"].startswith("Dòng một có & ký tự < đặc biệt >.") and "😀" in s["summary"] and s["seriesIndex"] == 2.5 and s["publishedAt"] == "2020-03-04" and s["publisher"] == "NXB Thử", s)
    else:
        check(f"{tag}: story trống => categories/tags rỗng, không có meta tác giả", w["categories"] == [] and w["tags"] == [] and "author" not in w["meta"], w)

FULL_META = {
    "calibre:series": "Đấu Phá", "calibre:series_index": "2.5", "calibre:rating": "9", "ebookleech:status": "ongoing", "ebookleech:rating": "4.5/5 (1234 lượt)",
    "ebookleech:updated": "2026-11-10", "ebookleech:alt_titles": "Battle Through the Heavens | 斗破苍穹", "belongs-to-collection": "Đấu Phá",
}
SUMMARY = "Dòng một có & ký tự < đặc biệt >.\nDòng hai: \"trích dẫn\" và 'nháy'.\n\nDòng ba 😀 emoji."
FULL_EXP = dict(creators=["Thiên Tàm Thổ Đậu"], summary=SUMMARY, subjects=["Tiên hiệp", "Huyền huyễn", "Hệ thống", "Nhiệt huyết"], title="Đấu Phá <Thương Khung> & Bạn",
                metas=FULL_META, info=True, info_contains=["Thiên Tàm Thổ Đậu", "Đang ra", "4.5/5 (1234 lượt)", "Đấu Phá #2.5", "Nhóm dịch A", "https://x/truyen?a=1&amp;b=2", "Dòng hai: &quot;trích dẫn&quot;", "Battle Through the Heavens / 斗破苍穹"])

def d(n): return os.path.join(ROOT, n)

# E1: đầy đủ + mục lục lồng 2 tầng
e = dict(FULL_EXP, cover="image/png", ncx_points=5, depth=2, nav_links=6)  # info + 2 quyển + 3 chương = 1+2+3 = 6 điểm ncx? -> xem bên dưới
# ncx: info(1) + quyển1 + 2 chương + quyển2 + 1 chương = 1 + 1 + 2 + 1 + 1 = 6 ; nav: info + 3 chương = 4 liên kết (nhóm là <span>)
e["ncx_points"] = 6; e["nav_links"] = 4
validate_epub("E1", d("E1_full_nested"), e); sidecar("E1", d("E1_full_nested"), dict(sidecar=True, cover=True, cover_ext="png", cover_magic=b"\x89PNG", title=FULL_EXP["title"], full=True))

# E2: không có thông tin truyện, không bìa => không trang giới thiệu, tiêu đề = tên job
e2 = dict(creators=[], summary=None, subjects=[], title="Truyện Thử: Tập 1/2?", info=False, cover=None, ncx_points=3, depth=1, nav_links=3, no_metas=["ebookleech:status", "ebookleech:rating", "calibre:series", "calibre:rating"])
validate_epub("E2", d("E2_blank_flat"), e2); sidecar("E2", d("E2_blank_flat"), dict(sidecar=True, cover=False, title="Truyện Thử: Tập 1/2?", full=False))

# E3: có thông tin, không bìa, tắt file kèm
e3 = dict(FULL_EXP, cover=None, ncx_points=4, depth=1, nav_links=4)
validate_epub("E3", d("E3_nocover_nosidecar"), e3); sidecar("E3", d("E3_nocover_nosidecar"), dict(sidecar=False))

# E4: tên cố định (ghi đè), bìa JPEG
fs4 = files(d("E4_fixedname"))
check("E4: tên file cố định, không dấu thời gian", "ten_co_dinh.epub" in fs4 and "ten_co_dinh.story.json" in fs4 and "ten_co_dinh.cover.jpg" in fs4, fs4)
e4 = dict(FULL_EXP, cover="image/jpeg", ncx_points=4, depth=1, nav_links=4)
validate_epub("E4", d("E4_fixedname"), e4); sidecar("E4", d("E4_fixedname"), dict(sidecar=True, cover=True, cover_ext="jpg", cover_magic=b"\xff\xd8\xff", title=FULL_EXP["title"], full=True))

# E5: chỉ có bìa, không chữ thông tin => vẫn có trang giới thiệu (bìa + tên)
e5 = dict(creators=[], summary=None, subjects=[], title="Truyện Thử: Tập 1/2?", info=True, cover="image/png", ncx_points=4, depth=1, nav_links=4, info_contains=["Truyện Thử: Tập 1/2?"])
validate_epub("E5", d("E5_coveronly"), e5)

# E6: chỉ có tên truyện (h1/title) => không trang giới thiệu, tiêu đề = tên đó, không meta thừa
e6 = dict(creators=[], summary=None, subjects=[], title="Chỉ Có Tên Truyện", info=False, cover=None, ncx_points=3, depth=1, nav_links=3, no_metas=["ebookleech:status", "ebookleech:rating", "calibre:series", "calibre:rating"])
validate_epub("E6", d("E6_titleonly"), e6)

# TXT
def read(n, ext):
    f = [x for x in files(d(n)) if x.endswith(ext)]; return open(os.path.join(d(n), f[0]), encoding="utf-8").read(), f
t, fl = read("T1_txt", ".txt")
check("T1: TXT bắt đầu bằng tên sách rồi gạch đôi", t.startswith("Đấu Phá <Thương Khung> & Bạn\n" + "=" * 60 + "\n"), t[:120])
check("T1: TXT có tác giả/thể loại/tình trạng/điểm/nguồn", all(s in t for s in ["Tác giả: Thiên Tàm Thổ Đậu", "Thể loại: Tiên hiệp, Huyền huyễn", "Tình trạng: Đang ra", "Đánh giá: 4.5/5 (1234 lượt)", "Nguồn: https://x/truyen?a=1&b=2"]), t[:500])
check("T1: TXT có phần Giới thiệu nguyên văn", "Giới thiệu:\nDòng một có & ký tự < đặc biệt >." in t)
check("T1: TXT có đủ 3 chương theo thứ tự và Quyển", t.index("# Quyển 1 & Mở màn") < t.index("Chương 1: Mở đầu") < t.index("Chương 2") < t.index("# Quyển 2") < t.index("Chương 3"))
check("T1: TXT cũng có .story.json + bìa", len(fl) == 1 and any(x.endswith(".story.json") for x in files(d("T1_txt"))) and any(".cover.png" in x for x in files(d("T1_txt"))), files(d("T1_txt")))
sidecar("T1", d("T1_txt"), dict(sidecar=True, cover=True, cover_ext="png", cover_magic=b"\x89PNG", title=FULL_EXP["title"], full=True))
t2, _ = read("T2_txt_blank", ".txt")
check("T2: TXT không thông tin => chỉ tên + gạch, không dòng 'Tác giả'", t2.startswith("Truyện Thử: Tập 1/2?\n" + "=" * 60 + "\n") and "Tác giả" not in t2 and "Giới thiệu:" not in t2, t2[:200])

t3, _ = read("T3_txt_sourceonly", ".txt")
check("T3: TXT chỉ có tên + nguồn/ngôn ngữ (trang nào cũng có) => đầu file GIỮ NHƯ BẢN CŨ, không dòng 'Nguồn'", t3.startswith("Tên Truyện\n" + "=" * 60 + "\n\n") and "Nguồn" not in t3 and "Ngôn ngữ" not in t3, t3[:200])

# HTML
class H(HTMLParser):
    def __init__(s): super().__init__(); s.imgs = []; s.ids = set(); s.hrefs = []; s.tags = []
    def handle_starttag(s, tag, a):
        a = dict(a); s.tags.append(tag)
        if tag == "img": s.imgs.append(a.get("src"))
        if "id" in a: s.ids.add(a["id"])
        if tag == "a" and a.get("href", "").startswith("#"): s.hrefs.append(a["href"][1:])
h2, _ = read("H3_html_sourceonly", ".html")
check("H3: HTML chỉ có tên + nguồn => không có danh sách story-info (như bản cũ)", 'class="story-info"' not in h2 and "<h1>Tên Truyện</h1>" in h2 and "Nguồn" not in h2, h2[:400])
h, fl = read("H1_html", ".html"); p = H(); p.feed(h)
check("H1: HTML có <meta charset> + lang vi + title", '<meta charset="UTF-8">' in h and 'lang="vi"' in h and "<title>Đấu Phá &lt;Thương Khung&gt; &amp; Bạn</title>" in h, h[:300])
check("H1: HTML có bìa, tên, danh sách thông tin, tóm tắt", "images/cover.png" in p.imgs and "<h1>Đấu Phá &lt;Thương Khung&gt; &amp; Bạn</h1>" in h and "<b>Tác giả:</b> Thiên Tàm Thổ Đậu" in h and 'class="story-summary"' in h)
check("H1: mọi ảnh tham chiếu có file thật", all(os.path.exists(os.path.join(d("H1_html"), s)) for s in p.imgs if s), p.imgs)
check("H1: mục lục trỏ tới đúng id chương", set(p.hrefs) == {"ch1", "ch2", "ch3"} and {"ch1", "ch2", "ch3"} <= p.ids, (p.hrefs, p.ids))
check("H1: HTML có .story.json + .cover.png", any(x.endswith(".story.json") for x in files(d("H1_html"))) and any(".cover.png" in x for x in files(d("H1_html"))), files(d("H1_html")))
sidecar("H1", d("H1_html"), dict(sidecar=True, cover=True, cover_ext="png", cover_magic=b"\x89PNG", title=FULL_EXP["title"], full=True))
h2, _ = read("H2_html_blank", ".html")
check("H2: HTML không thông tin có tên sách và không có <img", "images/cover" not in h2 and "<h1>Truyện Thử: Tập 1/2?</h1>" in h2 and 'class="story-summary"' not in h2 and "<ul class=\"story-info\">" not in h2, h2[:600])

# ---- xhtmlFix: bộ ca HTML hỏng => luôn XML hợp lệ, đúng kỳ vọng chọn lọc, và lũy đẳng ----
cases = {c["name"]: c for c in json.load(open(os.path.join(ROOT, "xhtml_cases.json"), encoding="utf-8"))}
WRAP = '<root xmlns="http://www.w3.org/1999/xhtml">%s</root>'
for name, c in cases.items():
    try:
        ET.fromstring((WRAP % c["out"]).encode("utf-8")); okx = None
    except ET.ParseError as e:
        okx = str(e)
    check(f"X[{name}]: kết quả là XML hợp lệ", okx is None, (okx, c["out"]))
    check(f"X[{name}]: lũy đẳng (sửa 2 lần = sửa 1 lần)", c["out"] == c["out2"], (c["out"], c["out2"]))
EXP = {  # tên -> (chuỗi phải có, chuỗi không được có)
    "bare_lt": (["a &lt; b &lt;3 c &lt; d ]]&gt; e &gt; f"], ["]]>"]),
    "unquoted_attr": (['<img src="a.jpg" width="10" alt=""/>', '<a href="x.html">l</a>'], []),
    "valueless_attr": (['<input disabled="disabled" checked="checked"/>', '<p hidden="hidden">x</p>'], []),
    "vue_angular_attrs": (['v-if="x"', ">t</div>"], ["@click", ":class", "[prop]", "(click)", "onclick", "evil", "ONMOUSEOVER", "onmouseover"]),
    "unbalanced": (["<p>a<b>bold</b></p><i>x</i>"], []),
    "stray_close": (["xyz"], ["</div>", "</span>"]),
    "uppercase": (['<p class="A">x</p><br/><img src="a.png" alt=""/>'], ["<P", "CLASS"]),
    "dup_attr": (['<a href="1">l</a>'], ['href="2"', 'href="3"']),
    "implicit_p": (["<p>a</p><p>b<li>1</li><li>2</li></p>"], []),
    "bad_numeric": (["||&#65;|&#x41;||&#x1F600;|"], ["&#0;", "&#xD800;", "&#1114112;", "&#11;"]),
    "selfclose_nonvoid": (["<div></div>x<span></span>y"], ["<div/>", "<span/>"]),
    "namespaced": (["ab"], ["o:p", "svg:rect"]),
    "svg_xlink": (['viewBox="0 0 1 1"'], ["xlink"]),
    "doctype_cdata_quote": (['<div title="a&lt;b&amp;c">x</div>z'], ["DOCTYPE", "CDATA", "y"]),
    "unterminated_tag": (["text <div class=\"x\"></div>"], []),
    "gt_in_attr": (['<a title="a&gt;b" href="x">l</a>'], []),
    "wrappers": (["<p>x</p>"], ["<html", "<body", "<head", "<meta", ">T<", "T<p>"]),
    "table_loose": (["<table><tr><td>1</td><td>2</td></tr><tr><td>3</td></tr></table>"], []),
    "empty": ([""], []),
    "unicode": (["<p>Tiếng Việt 😀 中文 ñ</p>"], []),
    "script_style": (["<p>a</p><p>b</p>"], ["script", "style", "iframe", "noscript", "if(a"]),
    "br_variants": (["a<br/>b<br/>c<br/>de"], ["</br>"]),
    "entity_zoo": (["&amp;&lt;&gt;&quot;&apos;&#160;&#169;&#8230;&#8212;&amp;notanentity;&amp;amp &amp;x; &#38;&#x26;"], []),
    "attr_entity": (['href="?a=1&amp;b=2&amp;c=3&#160;"', "title=\"He said &quot;hi&quot; &amp; left\""], []),
}
for name, (must, mustnot) in EXP.items():
    o = cases[name]["out"]
    check(f"X[{name}]: có {must!r}", all(m in o for m in must), o)
    check(f"X[{name}]: không có {mustnot!r}", all(m not in o for m in mustnot), o)

print("ALL PASS" if fails == 0 else f"FAILS={fails}")
sys.exit(0 if fails == 0 else 1)
