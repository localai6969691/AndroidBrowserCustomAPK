#!/usr/bin/env python3
"""Bản gieo kho do Kotlin (ArchiveSeed) dựng phải được runner Python (crawler.parse_archive_data) hiểu đúng: đúng kho chương, đúng thứ tự danh sách, đúng điểm neo, đúng thông tin truyện.
Chạy:  python3 -I check_seed.py <crawler.py> <seed1.json>"""
import sys, json, importlib.util
spec = importlib.util.spec_from_file_location("crawler", sys.argv[1]); cr = importlib.util.module_from_spec(spec); spec.loader.exec_module(cr)
data = json.load(open(sys.argv[2], encoding="utf-8"))
archive, known, meta, story = cr.parse_archive_data(data)
fails = 0
def check(name, cond, extra=""):
    global fails
    if not cond: fails += 1
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(extra)[:300]))
check("Python đọc đúng 4 chương gieo (1,2,3,6)", sorted(archive) == ["https://x/c1", "https://x/c2", "https://x/c3", "https://x/c6"], sorted(archive))
check("Python lấy đúng thứ tự danh sách đầy đủ (6 URL, kể cả chương không gieo => sẽ cào lại)", known == [f"https://x/c{i}" for i in range(1, 7)], known)
check("Python lấy đúng điểm neo (lastPage 6, fastStreak 3)", meta.get("lastPage") == 6 and meta.get("fastStreak") == 3, meta)
check("Python lấy đúng thông tin truyện lần trước", story.get("author") == "Tg", story)
check("chương gieo giữ nguyên index + ảnh (để tên file ảnh khớp)", archive["https://x/c2"]["index"] == 2 and [i["localFileName"] for i in archive["https://x/c2"]["images"]] == ["a.jpg", "b.jpg"])
# bản gieo => lần chạy mới chỉ phải cào chương 4,5 (không gieo) theo danh sách
todo = [u for u in known if u not in archive]
check("runner chỉ còn phải cào c4, c5", todo == ["https://x/c4", "https://x/c5"], todo)
print("ALL PASS" if fails == 0 else f"FAILS={fails}")
sys.exit(0 if fails == 0 else 1)
