# <<STORY_META BEGIN>>
# ─────────────────────────────────────────────────────────────────────
# Bản 7.104 — THÔNG TIN TRUYỆN (tác giả, tóm tắt, thể loại, tag, tình trạng, đánh giá, bìa...) để ebook thành nguyên liệu đăng lên web truyện.
# `STORY_META_JS` chạy TRONG trang (Playwright `page.evaluate`) và GIỐNG HỆT từng byte bản trong LeechDesk (ld/storymeta.py) và app (StoryMetaJs.kt) — có test so khớp.
# Thứ tự ưu tiên: selector người dùng > JSON-LD > Open Graph/book:/meta > microdata > nhãn "Tác giả:/Thể loại:" > h1/<title>; người dùng nhập tay (storyMetaManual) thắng tất cả.
# ─────────────────────────────────────────────────────────────────────
STORY_META_JS = r"""@@JS@@"""
STORY_META_SCHEMA = 1
STORY_COVER_MAX_BYTES = 6 * 1024 * 1024


def story_selectors_from_job(job):
    """selector theo trường: các trường cũ bookTitleSelector/bookCoverSelector/authorSelector (chưa từng được dùng) + storyMetaSelectors (dict tuỳ ý; khoá lạ => `extra`)."""
    sel = {}
    for key, legacy in (("title", "bookTitleSelector"), ("coverUrl", "bookCoverSelector"), ("author", "authorSelector")):
        v = (job.get(legacy) or "").strip()
        if v:
            sel["cover" if key == "coverUrl" else key] = v
    raw = job.get("storyMetaSelectors")
    if isinstance(raw, dict):
        for k, v in raw.items():
            if isinstance(k, str) and isinstance(v, str) and k.strip() and v.strip():
                k = k.strip()
                sel["cover" if k == "coverUrl" else k] = v.strip()
    return sel


def _story_empty(v):
    return v is None or v == "" or v == [] or v == {}


def merge_story_meta(prev, fresh, manual):
    """kết quả = lần trước (lấp chỗ trống khi trang lần này không có) <- mới trích được <- người dùng nhập tay (thắng tất cả). `sources` ghi nguồn của từng trường."""
    out = {k: v for k, v in (prev or {}).items() if not _story_empty(v)}
    srcs = dict(out.get("sources") or {})
    fresh = dict(fresh or {})
    fresh_src = fresh.pop("sources", {}) or {}
    for k, v in fresh.items():
        if _story_empty(v):
            continue
        if k == "extra" and isinstance(v, dict):
            ex = dict(out.get("extra") or {})
            ex.update({a: b for a, b in v.items() if not _story_empty(b)})
            out["extra"] = ex
            continue
        out[k] = v
        if k in fresh_src:
            srcs[k] = fresh_src[k]
    for k, v in (manual or {}).items():
        if k in ("sources", "fetchedAt", "schema") or _story_empty(v):
            continue
        out[k] = v
        srcs[k] = "manual"
    if srcs:
        out["sources"] = srcs
    return out


def fetch_story_cover(context, cover_url, referer, images_dir, prev_meta):
    """Tải ảnh bìa về `<images_dir>/cover.<ext>`. Trả {"coverFile","coverMime"} hoặc {} nếu không tải được. Giữ nguyên bản cũ nếu URL không đổi và file còn."""
    prev_meta = prev_meta or {}
    prev_file = prev_meta.get("coverFile") or ""
    if prev_file and prev_meta.get("coverUrl") == cover_url and os.path.exists(os.path.join(images_dir, prev_file)):
        return {"coverFile": prev_file, "coverMime": prev_meta.get("coverMime") or "image/jpeg"}
    try:
        resp = context.request.get(cover_url, timeout=20_000, headers={"Referer": referer} if referer else None)
    except Exception as e:
        print(f"[Story] Khong tai duoc anh bia {cover_url}: {e}", flush=True)
        return {}
    if not resp.ok:
        print(f"[Story] Anh bia tra ve HTTP {resp.status}: {cover_url}", flush=True)
        return {}
    mime = (resp.headers.get("content-type", "") or "").split(";")[0].strip().lower()
    body = resp.body()
    if not mime.startswith("image/") or not body:
        print(f"[Story] Anh bia khong phai anh ({mime or 'khong ro'}): {cover_url}", flush=True)
        return {}
    if len(body) > STORY_COVER_MAX_BYTES:
        print(f"[Story] Anh bia qua lon ({len(body)} byte) - bo qua", flush=True)
        return {}
    ext = guess_extension(mime, cover_url)
    os.makedirs(images_dir, exist_ok=True)
    for old in os.listdir(images_dir):
        if old.startswith("cover."):
            try:
                os.remove(os.path.join(images_dir, old))
            except OSError:
                pass
    name = f"cover.{ext}"
    with open(os.path.join(images_dir, name), "wb") as f:
        f.write(body)
    return {"coverFile": name, "coverMime": mime}


def collect_story_meta(context, job, images_dir, prev_meta):
    """Mở trang thông tin truyện (`storyInfoUrl`, mặc định trang danh sách chương), chạy STORY_META_JS, gộp với lần trước + nhập tay, tải bìa. Lỗi => trả lại bản cũ (không làm hỏng lần cào)."""
    prev_meta = prev_meta or {}
    manual = job.get("storyMetaManual") if isinstance(job.get("storyMetaManual"), dict) else {}
    if not job.get("storyMetaEnabled", True):
        return merge_story_meta(prev_meta, {}, manual) if manual else dict(prev_meta)
    url = (job.get("storyInfoUrl") or "").strip() or job.get("listPageUrl", "")
    fresh = {}
    page = None
    try:
        page = context.new_page()
        html, still_blocked = goto_with_cloudflare_retry(page, url, job=job)
        if still_blocked:
            print("[Story] Trang thong tin truyen bi chan - giu thong tin cu", flush=True)
        else:
            try:
                page.wait_for_timeout(int(job.get("storyMetaWaitMs", 1200)))
            except Exception:
                pass
            raw = page.evaluate("(" + STORY_META_JS + ")", {"selectors": story_selectors_from_job(job)})
            data = json.loads(raw)
            fresh = data.get("meta") or {}
            fresh["sources"] = data.get("sources") or {}
            print(f"[Story] Trich duoc thong tin truyen: {', '.join(k for k in fresh if k != 'sources') or '(khong co gi)'}", flush=True)
    except Exception as e:
        print(f"[Story] Loi khi lay thong tin truyen ({e}) - giu thong tin cu", flush=True)
    finally:
        if page is not None:
            try:
                page.close()
            except Exception:
                pass
    meta = merge_story_meta(prev_meta, fresh, manual)
    if meta.get("coverUrl"):
        meta.update(fetch_story_cover(context, meta["coverUrl"], url, images_dir, prev_meta))
    meta["schema"] = STORY_META_SCHEMA
    meta["fetchedAt"] = int(time.time() * 1000)
    return meta
# <<STORY_META END>>
