import re, sys
def embed_py(target, block_file, js_file):
    js = open(js_file, encoding='utf-8').read()
    assert '"""' not in js
    blk = open(block_file, encoding='utf-8').read().replace('@@JS@@', js)
    s = open(target, encoding='utf-8').read()
    if '# <<STORY_META BEGIN>>' in s:
        a = s.index('# <<STORY_META BEGIN>>'); b = s.index('# <<STORY_META END>>') + len('# <<STORY_META END>>')
        s = s[:a] + blk.rstrip('\n') + s[b:]
    else:
        raise SystemExit('markers missing')
    open(target, 'w', encoding='utf-8').write(s)
if __name__ == '__main__':
    embed_py(*sys.argv[1:4])
