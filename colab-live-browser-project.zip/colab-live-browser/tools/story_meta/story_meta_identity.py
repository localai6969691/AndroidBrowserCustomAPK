# -*- coding: utf-8 -*-
"""
So khớp "THÔNG TIN TRUYỆN" + "QUÉT NHANH" giữa 3 nơi cài đặt (app Kotlin, runner Python crawler.py, LeechDesk).

  python3 -I tools/story_meta/story_meta_identity.py <thư mục gốc dự án> <thư mục LeechDesk (có gói ld/)> [--no-browser]

PHẦN 1 — GIỐNG HỆT TỪNG BYTE: script trích STORY_META_JS ở `tools/story_meta/story_meta.js` (nguồn duy nhất), `ebookleech/remote_runner/crawler.py`, `ld/storymeta.py` (LeechDesk) và
         `StoryMetaJs.kt` (app). Khối quét nhanh (FAST_SCAN_MAX_STREAK, ListScanPlanner, run_list_scan) ở crawler.py và `ld/incremental.py`; và mã (bỏ docstring) của các hàm dùng chung
         (parse_archive_data, is_reusable_chapter, build_archive, merge_story_meta, story_selectors_from_job, _story_empty) + hằng số.
PHẦN 2 — SO SÁNH HÀNH VI (cần Playwright/Chromium): chạy STORY_META_JS trong trình duyệt và `storymeta.extract_basic` (bộ trích RÚT GỌN của engine HTTP, không có trình duyệt) trên cùng các
         trang mẫu. Hợp đồng: với MỌI trường mà bộ trích rút gọn có trả, giá trị phải GIỐNG bản JS; bộ rút gọn được phép thiếu trường (nó không đọc nhãn "Tác giả:", microdata...). Danh sách
         trường thiếu in ra để biết giới hạn của engine HTTP.
"""
import ast
import json
import re
import sys

ROOT, LD = sys.argv[1].rstrip("/"), sys.argv[2].rstrip("/")
NO_BROWSER = "--no-browser" in sys.argv
OK = FAIL = 0


def check(name, cond, extra=""):
    global OK, FAIL
    if cond:
        OK += 1
        print("  PASS", name)
    else:
        FAIL += 1
        print("  FAIL", name, str(extra)[:700])


def read(p):
    return open(p, encoding="utf-8").read()


def between(s, a, b):
    i = s.index(a) + len(a)
    return s[i:s.index(b, i)]


CRAWLER = ROOT + "/ebookleech/remote_runner/crawler.py"
KT = ROOT + "/app/src/main/java/com/colablive/keeper/features/ebookleech/engine/StoryMetaJs.kt"
JS_SRC = ROOT + "/tools/story_meta/story_meta.js"

print("== 1a. STORY_META_JS giống hệt từng byte ở 4 nơi")
js = {"tools/story_meta/story_meta.js": read(JS_SRC),
      "crawler.py": between(read(CRAWLER), 'STORY_META_JS = r"""', '"""'),
      "LeechDesk ld/storymeta.py": between(read(LD + "/ld/storymeta.py"), '# <<STORY_META_JS BEGIN>>\nSTORY_META_JS = r"""', '"""\n# <<STORY_META_JS END>>'),
      "app StoryMetaJs.kt": between(read(KT), 'const val STORY_META_JS = """', '"""\n}')}
ref = js["tools/story_meta/story_meta.js"]
check("script có nội dung (%d ký tự, thuần ASCII)" % len(ref), len(ref) > 10000 and all(ord(c) < 128 for c in ref))
for k, v in js.items():
    check("%s == nguồn duy nhất" % k, v == ref, "độ dài %d vs %d" % (len(v), len(ref)))

print("== 1b. Mã dùng chung giữa crawler.py và LeechDesk giống nhau")


def segs(path, strip_doc):
    src = read(path)
    out = {}
    for n in ast.parse(src).body:
        if isinstance(n, (ast.FunctionDef, ast.ClassDef)):
            if strip_doc and n.body and isinstance(n.body[0], ast.Expr) and isinstance(getattr(n.body[0], "value", None), ast.Constant) and isinstance(n.body[0].value.value, str):
                n.body = n.body[1:] or [ast.Pass()]
            out[n.name] = ast.dump(n) if strip_doc else ast.get_source_segment(src, n)
        elif isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name):
                    out[t.id] = ast.dump(n.value) if strip_doc else ast.get_source_segment(src, n)
    return out


c_src, i_src, m_src = segs(CRAWLER, False), segs(LD + "/ld/incremental.py", False), segs(LD + "/ld/storymeta.py", False)
for name in ("FAST_SCAN_MAX_STREAK", "ListScanPlanner", "run_list_scan"):
    check("quét nhanh: %s giống từng ký tự (crawler.py == ld/incremental.py)" % name, name in c_src and c_src.get(name) == i_src.get(name))
c_ast, i_ast, m_ast = segs(CRAWLER, True), segs(LD + "/ld/incremental.py", True), segs(LD + "/ld/storymeta.py", True)
for name in ("parse_archive_data", "is_reusable_chapter", "build_archive"):
    check("kho: %s cùng mã (bỏ docstring)" % name, name in c_ast and c_ast.get(name) == i_ast.get(name))
for name in ("STORY_META_SCHEMA", "STORY_COVER_MAX_BYTES", "story_selectors_from_job", "_story_empty", "merge_story_meta"):
    check("thông tin truyện: %s cùng mã (bỏ docstring)" % name, name in c_ast and c_ast.get(name) == m_ast.get(name))

if NO_BROWSER:
    print("\nKẾT QUẢ so khớp thông tin truyện/quét nhanh: %d pass, %d fail (bỏ qua phần trình duyệt)" % (OK, FAIL))
    sys.exit(1 if FAIL else 0)

print("== 2. extract_basic (HTTP, rút gọn) so với STORY_META_JS chạy trong Chromium")
sys.path.insert(0, LD)
from ld import storymeta  # noqa: E402
from playwright.sync_api import sync_playwright  # noqa: E402

tree = ast.parse(read(ROOT + "/tools/story_meta/test_story_meta.py"))
FIX = {}
for n in tree.body:
    if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ("JSONLD", "OGVN", "LABELS", "SELECTORS", "YOAST", "MICRO", "SEL"):
        FIX[n.targets[0].id] = ast.literal_eval(n.value)
CASES = [("JSON-LD", FIX["JSONLD"], {}), ("Open Graph", FIX["OGVN"], {}), ("nhãn Tác giả:/Thể loại:", FIX["LABELS"], {}), ("selector người dùng", FIX["SELECTORS"], FIX["SEL"]),
         ("Yoast @graph (không lấy 'admin')", FIX["YOAST"], {}), ("microdata", FIX["MICRO"], {}), ("trang trống", "<html><body><p>không có gì</p></body></html>", {}),
         ("selector thắng JSON-LD", FIX["JSONLD"], {"title": "h1"})]
for st in ("Đang ra", "Đang tiến hành", "Chưa hoàn thành", "Còn tiếp", "Ongoing", "Hoàn thành", "Full", "Đã hoàn thành", "Completed", "Tạm ngưng", "Hiatus", "On Hold", "Dropped", "Bỏ dở"):
    CASES.append(("trạng thái '%s' (selector)" % st, "<html><body><div class=\"st\">%s</div></body></html>" % st, {"status": ".st"}))
for rt in ("4.5/5", "8.7 / 10 (123 votes)", "Rating: 4,2", "9", "85"):
    CASES.append(("đánh giá '%s' (selector)" % rt, "<html><body><div class=\"rt\">%s</div></body></html>" % rt, {"rating": ".rt"}))
def same_value(a, b):
    """Bằng nhau theo giá trị: số so theo giá trị (JS trả float, Python có thể int), dict/list so đệ quy."""
    if isinstance(a, bool) or isinstance(b, bool):
        return a == b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return float(a) == float(b)
    if isinstance(a, dict) and isinstance(b, dict):
        return set(a) == set(b) and all(same_value(a[x], b[x]) for x in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(same_value(x, y) for x, y in zip(a, b))
    return a == b


URL = "http://novel.test/truyen/abc"
missing = {}
differ = []
with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_page()
    for name, html, sel in CASES:
        page.route("http://novel.test/**", lambda r, _req, h=html: r.fulfill(body=h, content_type="text/html; charset=utf-8"))
        page.goto(URL)
        j = json.loads(page.evaluate("(" + ref + ")", {"selectors": sel}))["meta"]
        page.unroute("http://novel.test/**")
        py = storymeta.extract_basic(html, URL, sel)["meta"]
        for k, v in py.items():
            if k == "summaryHtml" or k not in j:
                if k not in j and k != "summaryHtml":
                    differ.append((name, k, "chỉ Python có", v))
                continue
            same = same_value(j[k], v)
            a, b2 = j[k], v
            if not same:
                differ.append((name, k, a, b2))
        for k in j:
            if k not in py and k not in ("summaryHtml",):
                missing.setdefault(name, []).append(k)
    b.close()
check("với MỌI trường bộ trích rút gọn có trả, giá trị GIỐNG bản JS trong trình duyệt (%d trang mẫu)" % len(CASES), not differ, json.dumps(differ[:6], ensure_ascii=False))
print("  (thông tin) trường JS lấy được mà bộ trích rút gọn của engine HTTP KHÔNG lấy%s:" % ("" if missing else " — không có trên %d trang mẫu" % len(CASES)))
agg = {}
for name, ks in missing.items():
    for k in ks:
        agg.setdefault(k, []).append(name)
for k, names in sorted(agg.items()):
    print("     %-12s %d/%d trang mẫu  (vd: %s)" % (k, len(names), len(CASES), names[0]))
print("\nKẾT QUẢ so khớp thông tin truyện/quét nhanh: %d pass, %d fail" % (OK, FAIL))
sys.exit(1 if FAIL else 0)
