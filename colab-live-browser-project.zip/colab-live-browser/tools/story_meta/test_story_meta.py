import json, sys
from playwright.sync_api import sync_playwright
JS = open(sys.argv[1] if len(sys.argv) > 1 else "story_meta.js", encoding="utf-8").read()
FAILS = []
def check(name, cond, detail=""):
    print(("   OK   " if cond else "   FAIL ") + name + ("" if cond else "  -> %s" % (detail,)))
    if not cond: FAILS.append(name)

def run(page, html, cfg=None, url="http://novel.test/truyen/abc"):
    page.route("http://novel.test/**", lambda r: r.fulfill(body=html, content_type="text/html; charset=utf-8"))
    page.goto(url)
    r = json.loads(page.evaluate("(" + JS + ")", cfg or {}))
    page.unroute("http://novel.test/**")
    return r["meta"], r["sources"]

JSONLD = """<html lang="vi"><head><title>Đấu Phá - Truyện Hay</title>
<script type="application/ld+json">{"@context":"https://schema.org","@type":"Book","name":"Đấu Phá Thương Khung","author":{"@type":"Person","name":"Thiên Tàm Thổ Đậu"},
"description":"Thiếu niên thiên tài Tiêu Viêm.<br>Bị đánh rơi xuống đáy xã hội.","image":"/img/cover.jpg","genre":["Huyền huyễn","Tiên hiệp"],"keywords":"đấu khí, luyện đan, hệ thống",
"inLanguage":"vi-VN","datePublished":"2020-03-01","dateModified":"2024-05-02T10:00:00+07:00","aggregateRating":{"@type":"AggregateRating","ratingValue":"4.6","bestRating":"5","ratingCount":"1,234"},
"publisher":{"@type":"Organization","name":"NXB Test"},"isPartOf":{"@type":"BookSeries","name":"Đấu Phá"},"alternateName":["Battle Through the Heavens","BTTH"]}</script></head><body><h1>Trang khác</h1></body></html>"""

OGVN = """<html lang="vi"><head><meta property="og:title" content="Tru Tiên | Truyện ABC"><meta property="og:site_name" content="Truyện ABC">
<meta property="og:description" content="Mô tả ngắn."><meta property="og:image" content="https://cdn.test/tt.jpg"><meta property="og:novel:author" content="Tiêu Đỉnh">
<meta property="og:novel:category" content="Tiên hiệp, Kiếm hiệp"><meta property="og:novel:status" content="Đang ra"><meta property="og:locale" content="vi_VN">
</head><body><h1>Tru Tiên</h1></body></html>"""

LABELS = """<html lang="vi"><head><title>Ngôn tình XYZ</title></head><body><h1 class="t">Hoa Khai Phú Quý</h1>
<ul class="info"><li><span>Tác giả:</span> <a href="/a/1">Cố Mạn</a></li><li><span>Thể loại:</span> <a>Ngôn tình</a>, <a>Cổ đại</a></li>
<li><span>Tình trạng:</span> Hoàn thành</li><li><span>Đánh giá:</span> 8.7/10 (532 đánh giá)</li><li><b>Cập nhật:</b> 21/09/2024</li></ul>
<h3>Giới thiệu</h3><div class="desc"><p>Một cô gái xuyên không về cổ đại và gặp được người định mệnh.</p><p>Hành trình mới bắt đầu từ đây.</p></div></body></html>"""

SELECTORS = """<html><head><title>X</title></head><body><div class="b"><h1 class="name">Truyện Chọn Selector</h1><img class="cv" data-src="/c/1.png" src="data:image/gif;base64,AAA">
<span class="au">Tác giả: Nguyễn A</span><span class="au">Trần B</span><div class="gn">Hành động; Phiêu lưu | Hài</div><div class="tg"><a>t1</a><a>t2</a><a>t1</a></div>
<div class="st">Tạm ngưng</div><div class="rt">4,5 sao</div><div class="views">12.345 lượt xem</div><div class="sm">Dòng một<br>Dòng hai</div><meta class="mm" content="meta-val"></div></body></html>"""
SEL = {"title": "h1.name", "cover": "img.cv", "author": ".au", "genres": ".gn", "tags": ".tg a", "status": ".st", "rating": ".rt", "views": ".views", "summary": ".sm", "publisher": ".mm@content"}

YOAST = """<html lang="en"><head><title>Dragon Slayer - My Site</title><meta property="og:site_name" content="My Site"><meta property="og:title" content="Dragon Slayer - My Site">
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","name":"Dragon Slayer - My Site"},{"@type":"Article","headline":"Dragon Slayer","author":{"@type":"Person","name":"admin"}}]}</script>
</head><body><h1>Dragon Slayer</h1></body></html>"""

MICRO = """<html><body><div itemscope itemtype="https://schema.org/Book"><h1 itemprop="name">Micro Book</h1><span itemprop="author" itemscope><span itemprop="name">Jane Roe</span></span>
<span itemprop="genre">Fantasy</span><div itemprop="aggregateRating" itemscope><span itemprop="ratingValue">4.2</span>/<span itemprop="bestRating">5</span> (<span itemprop="ratingCount">88</span>)</div></div></body></html>"""

with sync_playwright() as p:
    b = p.chromium.launch(); page = b.new_page()
    m, s = run(page, JSONLD)
    print("JSON-LD:", json.dumps(m, ensure_ascii=False)[:600])
    check("jsonld: title/author", m.get("title") == "Đấu Phá Thương Khung" and m.get("author") == "Thiên Tàm Thổ Đậu", m)
    check("jsonld: summary 2 dòng", m.get("summary") == "Thiếu niên thiên tài Tiêu Viêm.\nBị đánh rơi xuống đáy xã hội.", m.get("summary"))
    check("jsonld: cover tuyệt đối", m.get("coverUrl") == "http://novel.test/img/cover.jpg", m.get("coverUrl"))
    check("jsonld: genres/tags", m.get("genres") == ["Huyền huyễn", "Tiên hiệp"] and m.get("tags") == ["đấu khí", "luyện đan", "hệ thống"], (m.get("genres"), m.get("tags")))
    check("jsonld: language vi, dates", m.get("language") == "vi" and m.get("publishedAt") == "2020-03-01" and m.get("updatedAt", "").startswith("2024-05-02"), (m.get("language"), m.get("publishedAt"), m.get("updatedAt")))
    check("jsonld: rating 4.6/5, 1234 lượt", m.get("rating") == {"value": 4.6, "scale": 5.0, "count": 1234.0}, m.get("rating"))
    check("jsonld: series/publisher/altTitles", m.get("series") == "Đấu Phá" and m.get("publisher") == "NXB Test" and m.get("altTitles") == ["Battle Through the Heavens", "BTTH"], (m.get("series"), m.get("publisher"), m.get("altTitles")))
    check("jsonld: sourceUrl/sourceSite", m.get("sourceUrl") == "http://novel.test/truyen/abc" and m.get("sourceSite") == "novel.test", (m.get("sourceUrl"), m.get("sourceSite")))
    check("summaryHtml sinh từ dòng, đã escape", m.get("summaryHtml") == "<p>Thiếu niên thiên tài Tiêu Viêm.</p><p>Bị đánh rơi xuống đáy xã hội.</p>", m.get("summaryHtml"))

    m, s = run(page, OGVN)
    print("OG:", json.dumps(m, ensure_ascii=False))
    check("og: title bỏ đuôi tên site", m.get("title") == "Tru Tiên", m.get("title"))
    check("og: author/genres/status/language", m.get("author") == "Tiêu Đỉnh" and m.get("genres") == ["Tiên hiệp", "Kiếm hiệp"] and m.get("status") == "ongoing" and m.get("language") == "vi", m)
    check("og: cover + publisher", m.get("coverUrl") == "https://cdn.test/tt.jpg" and m.get("publisher") == "Truyện ABC", (m.get("coverUrl"), m.get("publisher")))

    m, s = run(page, LABELS)
    print("LABELS:", json.dumps(m, ensure_ascii=False), s)
    check("label: author/genres", m.get("author") == "Cố Mạn" and m.get("genres") == ["Ngôn tình", "Cổ đại"], (m.get("author"), m.get("genres")))
    check("label: status completed, rating 8.7/10 532", m.get("status") == "completed" and m.get("rating") == {"value": 8.7, "scale": 10.0, "count": 532.0}, (m.get("status"), m.get("rating")))
    check("label: cập nhật dd/mm/yyyy -> ISO", m.get("updatedAt") == "2024-09-21", m.get("updatedAt"))
    check("label: tóm tắt sau tiêu đề Giới thiệu", (m.get("summary") or "").startswith("Một cô gái xuyên không") and "\n" in m.get("summary", ""), m.get("summary"))
    check("label: title lấy h1", m.get("title") == "Hoa Khai Phú Quý", m.get("title"))

    m, s = run(page, SELECTORS, {"selectors": SEL})
    print("SELECTORS:", json.dumps(m, ensure_ascii=False), s)
    check("selector: title/cover (data-src, bỏ data: URI)", m.get("title") == "Truyện Chọn Selector" and m.get("coverUrl") == "http://novel.test/c/1.png", (m.get("title"), m.get("coverUrl")))
    check("selector: 2 phần tử tác giả gộp, bỏ nhãn 'Tác giả:'", m.get("author") == "Nguyễn A, Trần B", m.get("author"))
    check("selector: genres tách theo ; |", m.get("genres") == ["Hành động", "Phiêu lưu", "Hài"], m.get("genres"))
    check("selector: tags nhiều phần tử, loại trùng", m.get("tags") == ["t1", "t2"], m.get("tags"))
    check("selector: status tạm ngưng -> hiatus", m.get("status") == "hiatus" and m.get("statusText") == "Tạm ngưng", (m.get("status"), m.get("statusText")))
    check("selector: rating '4,5 sao' -> 4.5/5", m.get("rating") == {"value": 4.5, "scale": 5.0}, m.get("rating"))
    check("selector: trường tuỳ ý vào extra", m.get("extra") == {"views": "12.345 lượt xem"}, m.get("extra"))
    check("selector: summary giữ xuống dòng", m.get("summary") == "Dòng một\nDòng hai", repr(m.get("summary")))
    check("selector: @attr (content)", m.get("publisher") == "meta-val", m.get("publisher"))
    check("selector thắng JSON-LD", run(page, JSONLD, {"selectors": {"title": "h1"}})[0].get("title") == "Trang khác")

    m, s = run(page, YOAST)
    print("YOAST:", json.dumps(m, ensure_ascii=False), s)
    check("yoast: KHÔNG lấy 'admin' làm tác giả", "author" not in m, m.get("author"))
    check("yoast: title sạch (không đuôi site)", m.get("title") == "Dragon Slayer", m.get("title"))

    m, s = run(page, MICRO)
    check("microdata: title/author/genre/rating", m.get("title") == "Micro Book" and m.get("author") == "Jane Roe" and m.get("genres") == ["Fantasy"] and m.get("rating") == {"value": 4.2, "scale": 5.0, "count": 88.0}, m)

    m, s = run(page, "<html><body><p>không có gì</p></body></html>")
    check("trang trống: chỉ có sourceUrl/sourceSite, không lỗi", set(m) == {"sourceUrl", "sourceSite"}, m)

    # bảng chuẩn hoá trạng thái
    table = {"Đang ra": "ongoing", "Đang tiến hành": "ongoing", "Chưa hoàn thành": "ongoing", "Còn tiếp": "ongoing", "Ongoing": "ongoing", "连载中": "ongoing",
             "Hoàn thành": "completed", "Full": "completed", "Đã hoàn thành": "completed", "Completed": "completed", "Complete": "completed", "完结": "completed",
             "Tạm ngưng": "hiatus", "Hiatus": "hiatus", "On Hold": "hiatus", "Dropped": "dropped", "Bỏ dở": "dropped", "xyz": ""}
    bad = {}
    for k, v in table.items():
        m, _ = run(page, "<html><body><ul><li>Tình trạng: %s</li></ul></body></html>" % k)
        if m.get("status", "") != v: bad[k] = m.get("status", "")
    check("chuẩn hoá trạng thái (đa ngôn ngữ)", not bad, bad)
    rt = {"4.5/5": (4.5, 5), "8.7 / 10 (123 votes)": (8.7, 10), "Rating: 4,2": (4.2, 5), "9": (9, 10), "85": (85, 100)}
    bad = {}
    for k, v in rt.items():
        m, _ = run(page, "<html><body><ul><li>Đánh giá: %s</li></ul></body></html>" % k)
        r = m.get("rating") or {}
        if (r.get("value"), r.get("scale")) != v: bad[k] = r
    check("parse đánh giá", not bad, bad)
    b.close()
print("FAILS:", FAILS); sys.exit(1 if FAILS else 0)
