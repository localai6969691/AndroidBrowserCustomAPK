import com.colablive.keeper.features.ebookleech.remote.GitHubApiClient
import com.colablive.keeper.features.ebookleech.remote.GitHubApiClient.ApiResult
import java.security.MessageDigest

/** Vòng lặp lệnh qua stdin cho run.py: chạy THẬT GitHubApiClient.kt trên JVM với GitHub giả. Mỗi dòng: cmd<TAB>arg...  =>  một dòng trả lời ok<TAB>... hoặc err<TAB>code<TAB>msg. */
fun md5(b: ByteArray) = MessageDigest.getInstance("MD5").digest(b).joinToString("") { "%02x".format(it) }

fun main(args: Array<String>) {
    GitHubApiClient.apiBase = args[0]
    val o = "o"; val r = "r"; val br = "main"; val tok = "ghp_test"
    while (true) {
        val line = readLine() ?: break
        val a = line.split('\t')
        val t0 = System.currentTimeMillis()
        val out: String = when (a[0]) {
            "get" -> when (val x = GitHubApiClient.getFileContent(o, r, br, tok, a[1])) {
                is ApiResult.Ok -> "ok\tlen=${x.value.toByteArray(Charsets.UTF_8).size};md5=${md5(x.value.toByteArray(Charsets.UTF_8))}"
                is ApiResult.Err -> "err\t${x.httpCode}\t${x.message.replace('\n', ' ').take(200)}"
            }
            "bytes" -> when (val x = GitHubApiClient.getFileBytes(o, r, br, tok, a[1])) {
                is ApiResult.Ok -> "ok\tlen=${x.value.size};md5=${md5(x.value)}"
                is ApiResult.Err -> "err\t${x.httpCode}\t${x.message.replace('\n', ' ').take(200)}"
            }
            "put" -> when (val x = GitHubApiClient.putFile(o, r, br, tok, a[1], a[2].replace("\\n", "\n"), "test")) {
                is ApiResult.Ok -> "ok\t"
                is ApiResult.Err -> "err\t${x.httpCode}\t${x.message.replace('\n', ' ').take(200)}"
            }
            "putbig" -> {  // a[2] = số byte nội dung ASCII lặp 'x'
                val s = "x".repeat(a[2].toInt())
                when (val x = GitHubApiClient.putFile(o, r, br, tok, a[1], s, "test")) {
                    is ApiResult.Ok -> "ok\t"
                    is ApiResult.Err -> "err\t${x.httpCode}\t${x.message.replace('\n', ' ').take(200)}"
                }
            }
            "putbytes" -> when (val x = GitHubApiClient.putFileBytes(o, r, br, tok, a[1], ByteArray(a[2].toInt()) { (it % 251).toByte() }, "test")) {
                is ApiResult.Ok -> "ok\t"
                is ApiResult.Err -> "err\t${x.httpCode}\t${x.message.replace('\n', ' ').take(200)}"
            }
            "list" -> when (val x = GitHubApiClient.listDirectory(o, r, br, tok, a[1])) {
                is ApiResult.Ok -> "ok\tcount=${x.value.size};first=${x.value.minOrNull()};last=${x.value.maxOrNull()};distinct=${x.value.toSet().size}"
                is ApiResult.Err -> "err\t${x.httpCode}\t${x.message.replace('\n', ' ').take(200)}"
            }
            "dispatch" -> when (val x = GitHubApiClient.dispatchWorkflow(o, r, br, tok, "w.yml", mapOf("job_id" to "J1"))) {
                is ApiResult.Ok -> "ok\t"
                is ApiResult.Err -> "err\t${x.httpCode}\t${x.message.replace('\n', ' ').take(200)}"
            }
            "latestrun" -> when (val x = GitHubApiClient.findLatestRun(o, r, tok, "w.yml")) {
                is ApiResult.Ok -> "ok\tid=${x.value.id};status=${x.value.status};conclusion=${x.value.conclusion}"
                is ApiResult.Err -> "err\t${x.httpCode}\t${x.message.replace('\n', ' ').take(200)}"
            }
            "clear" -> { GitHubApiClient.clearCache(); "ok\t" }
            "quit" -> return
            else -> "err\t-1\tlenh la ${a[0]}"
        }
        println(out + "\tms=" + (System.currentTimeMillis() - t0))
        System.out.flush()
    }
}
