# -*- coding: utf-8 -*-
"""Kiểm thử GitHubApiClient.kt (bản 7.103) CHẠY THẬT trên JVM với một GitHub giả viết theo ngữ nghĩa trong tài liệu chính thức:
  - Contents API: JSON chỉ cho file <= big (mặc định 2000 B thu nhỏ từ 1 MB), file lớn hơn chỉ media type raw/object; liệt kê thư mục cắt cứng ở 1000 mục;
  - ETag + If-None-Match => 304; Git Trees API; giới hạn tốc độ phụ (403 + Retry-After) và hết hạn mức giờ (x-ratelimit-remaining: 0);
  - PUT: sha lệch => 409, thiếu sha cho file đã có => 422.
Chạy:  python3 run.py <thư mục chứa kotlinc/bin/kotlinc> [đường dẫn GitHubApiClient.kt]
(Không kiểm GitHub THẬT — đây là mô phỏng theo tài liệu; ETag với media type raw chưa được xác minh trên GitHub thật.)"""
import base64, hashlib, json, os, re, subprocess, sys, threading, time, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
KT_HOME = sys.argv[1]
CLIENT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "..", "..", "app", "src", "main", "java", "com", "colablive", "keeper", "features", "ebookleech", "remote", "GitHubApiClient.kt")
STUBS = os.path.join(HERE, "..", "ebookleech_sim", "stubs")

class GH:
    def __init__(self, big=2000):
        self.files = {}; self.big = big; self.log = []; self.limit_n = 0; self.limit_long = False; self.race_path = None; self.lock = threading.Lock()
        self.reads_json_big = 0

def sha(b): return hashlib.sha1(b).hexdigest()

def make_server(gh, owner="o", repo="r"):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        def log_message(self, *a): pass
        def reply(self, code, obj=None, raw=None, headers=None):
            body = raw if raw is not None else (b"" if obj is None else json.dumps(obj).encode())
            self.send_response(code); self.send_header("Content-Length", str(len(body)))
            self.send_header("Content-Type", "application/octet-stream" if raw is not None else "application/json")
            for k, v in (headers or {}).items(): self.send_header(k, v)
            self.end_headers()
            if code != 304: self.wfile.write(body)
            self.log_entry["code"] = code
        def limited(self):
            if gh.limit_long:
                self.reply(403, {"message": "API rate limit exceeded for user."}, headers={"x-ratelimit-remaining": "0", "x-ratelimit-reset": str(int(time.time()) + 3600)}); return True
            if gh.limit_n > 0:
                gh.limit_n -= 1
                self.reply(403, {"message": "You have exceeded a secondary rate limit. Please wait a few minutes before you try again."}, headers={"Retry-After": "1"}); return True
            return False
        def dirents(self, p):
            ents = {}
            for k, v in gh.files.items():
                if k.startswith(p + "/"):
                    rest = k[len(p) + 1:]
                    if "/" in rest: ents[rest.split("/")[0]] = {"name": rest.split("/")[0], "type": "dir", "path": p + "/" + rest.split("/")[0], "sha": "d" + sha(rest.split("/")[0].encode())}
                    else: ents[rest] = {"name": rest, "type": "file", "path": k, "size": len(v), "sha": sha(v)}
            return sorted(ents.values(), key=lambda e: e["name"])
        def handle_any(self):
            u = urllib.parse.urlparse(self.path); path = urllib.parse.unquote(u.path)
            self.log_entry = {"method": self.command, "path": path, "accept": self.headers.get("Accept", ""), "inm": self.headers.get("If-None-Match"), "code": None}
            gh.log.append(self.log_entry)
            assert self.headers["Authorization"].startswith("Bearer ")
            self.body = self.rfile.read(int(self.headers.get("Content-Length", 0) or 0))   # đọc thân TRƯỚC khi có thể trả 403 (giữ kết nối keep-alive không lệch)
            if self.limited(): return
            base = "/repos/%s/%s/" % (owner, repo)
            if not path.startswith(base): return self.reply(404, {"message": "Not Found"})
            rest = path[len(base):]
            if self.command == "GET" and rest.startswith("contents/"): return self.contents_get(rest[len("contents/"):].strip("/"))
            if self.command == "PUT" and rest.startswith("contents/"): return self.contents_put(rest[len("contents/"):].strip("/"))
            if self.command == "GET" and rest.startswith("git/trees/"): return self.trees_get(rest[len("git/trees/"):])
            if self.command == "POST" and rest.endswith("/dispatches"):
                return self.reply(204)
            if self.command == "GET" and "/runs" in rest:
                return self.reply(200, {"workflow_runs": [{"id": 42, "status": "in_progress", "conclusion": None}]})
            self.reply(404, {"message": "Not Found"})
        do_GET = do_PUT = do_POST = handle_any
        def contents_get(self, p):
            acc = self.headers.get("Accept", "")
            if p in gh.files:
                data = gh.files[p]; etag = 'W/"%s"' % sha(data)
                if self.headers.get("If-None-Match") == etag: return self.reply(304, headers={"ETag": etag})
                if "raw" in acc: return self.reply(200, raw=data, headers={"ETag": etag})
                if "object" in acc:
                    return self.reply(200, {"type": "file", "sha": sha(data), "size": len(data), "content": "" if len(data) > gh.big else base64.b64encode(data).decode()}, headers={"ETag": etag})
                if len(data) > gh.big:
                    gh.reads_json_big += 1
                    return self.reply(403, {"message": "This API returns blobs up to 1 MB in size. The requested blob is too large to fetch via the API"})
                return self.reply(200, {"type": "file", "sha": sha(data), "size": len(data), "content": base64.b64encode(data).decode(), "encoding": "base64"}, headers={"ETag": etag})
            ents = self.dirents(p)
            if ents:
                ents = ents[:1000]                                  # tài liệu: Contents API cắt cứng ở 1000 mục
                etag = 'W/"%s"' % sha(json.dumps(ents).encode())
                if self.headers.get("If-None-Match") == etag: return self.reply(304, headers={"ETag": etag})
                return self.reply(200, ents, headers={"ETag": etag})
            self.reply(404, {"message": "Not Found"})
        def contents_put(self, p):
            body = json.loads(self.body)
            if gh.race_path == p:                                   # runner khác ghi chen vào giữa lúc ta đọc sha và ghi
                gh.race_path = None; gh.files[p] = gh.files.get(p, b"") + b" "
            data = base64.b64decode(body["content"])
            if p in gh.files:
                if not body.get("sha"): return self.reply(422, {"message": "Invalid request.\n\n\"sha\" wasn't supplied."})
                if body["sha"] != sha(gh.files[p]): return self.reply(409, {"message": "%s does not match %s" % (p, body["sha"])})
            elif body.get("sha"): return self.reply(422, {"message": "sha wasn't supplied correctly"})
            gh.files[p] = data
            self.reply(200, {"content": {"sha": sha(data)}})
        def tree_entries(self, sha_or_ref):
            if sha_or_ref == "main": p = ""
            elif sha_or_ref.startswith("t:"): p = sha_or_ref[2:]
            else: return None
            ents = []; seen = set()
            for k, v in gh.files.items():
                if p and not k.startswith(p + "/"): continue
                rest = k[len(p) + 1:] if p else k
                if "/" in rest:
                    d = rest.split("/")[0]
                    if d not in seen: seen.add(d); ents.append({"path": d, "type": "tree", "sha": "t:" + ((p + "/") if p else "") + d})
                else: ents.append({"path": rest, "type": "blob", "sha": sha(v)})
            return ents
        def trees_get(self, ref):
            ents = self.tree_entries(urllib.parse.unquote(ref))
            if ents is None: return self.reply(404, {"message": "Not Found"})
            etag = 'W/"%s"' % sha(json.dumps(ents).encode())
            if self.headers.get("If-None-Match") == etag: return self.reply(304, headers={"ETag": etag})
            self.reply(200, {"sha": "x", "tree": ents, "truncated": False}, headers={"ETag": etag})
    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv

OK = FAIL = 0
def check(name, cond, extra=""):
    global OK, FAIL
    if cond: OK += 1; print("  PASS", name)
    else: FAIL += 1; print("  FAIL", name, extra)

def md5(b): return hashlib.md5(b).hexdigest()

def main():
    out = os.path.join(os.environ.get("TMPDIR", "/tmp"), "ghclient_out"); os.makedirs(out, exist_ok=True)
    kotlinc = os.path.join(KT_HOME, "bin", "kotlinc"); stdlib = os.path.join(KT_HOME, "lib", "kotlin-stdlib.jar")
    srcs = [os.path.join(STUBS, "org", "json", "J.kt"), os.path.join(STUBS, "android", "util", "B.kt"), os.path.join(HERE, "GhRepl.kt"), CLIENT]
    print("Biên dịch GitHubApiClient.kt + GhRepl.kt …"); sys.stdout.flush()
    r = subprocess.run([kotlinc, "-nowarn", "-d", out] + srcs, capture_output=True, text=True)
    if r.returncode != 0: print(r.stdout[-3000:], r.stderr[-3000:]); sys.exit(2)
    gh = GH(); srv = make_server(gh); base = "http://127.0.0.1:%d" % srv.server_address[1]
    p = subprocess.Popen(["java", "-Dfile.encoding=UTF-8", "-Dstdin.encoding=UTF-8", "-Dstdout.encoding=UTF-8", "-cp", out + os.pathsep + stdlib, "GhReplKt", base],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")
    def cmd(*a):
        p.stdin.write("\t".join(str(x) for x in a) + "\n"); p.stdin.flush()
        line = p.stdout.readline().rstrip("\n")
        if not line: raise RuntimeError("JVM kết thúc: " + p.stderr.read()[-1500:])
        f = line.split("\t"); ms = int(f[-1].split("=")[1]); f = f[:-1]
        return f, ms
    def reqs(pred=lambda e: True): return [e for e in gh.log if pred(e)]
    def kv(s): return dict(x.split("=", 1) for x in s.split(";") if "=" in x)

    print("== 1. Đọc file nhỏ + lớn (media type raw)")
    small = ("Nội dung nhỏ — tiếng Việt có dấu\n" * 3).encode(); big = (("Chương dài " * 40 + "\n") * 40).encode()
    gh.files["remote-jobs/a.json"] = small; gh.files["remote-jobs/a-checkpoint.json"] = big
    f, _ = cmd("get", "remote-jobs/a.json"); check("file nhỏ: đọc đúng nội dung (md5)", f[0] == "ok" and kv(f[1])["md5"] == md5(small), f)
    f, _ = cmd("get", "remote-jobs/a-checkpoint.json"); check("file > ngưỡng 1MB(giả): đọc đúng, KHÔNG lỗi 403", f[0] == "ok" and kv(f[1])["md5"] == md5(big) and kv(f[1])["len"] == str(len(big)), f)
    check("không có request JSON thường nào tới file lớn (reads_json_big=0)", gh.reads_json_big == 0)
    f, _ = cmd("get", "remote-jobs/none.json"); check("file chưa có => lỗi 404 đúng mã", f[0] == "err" and f[1] == "404", f)

    print("== 2. ETag / 304")
    cmd("clear"); gh.log.clear()
    cmd("get", "remote-jobs/a-checkpoint.json"); f, _ = cmd("get", "remote-jobs/a-checkpoint.json")
    g = reqs(lambda e: e["path"].endswith("a-checkpoint.json"))
    check("lần 2 gửi If-None-Match và nhận 304", len(g) == 2 and g[0]["inm"] is None and g[1]["inm"] and g[1]["code"] == 304, g)
    check("304 vẫn trả đúng nội dung (từ bộ nhớ đệm)", f[0] == "ok" and kv(f[1])["md5"] == md5(big), f)
    gh.files["remote-jobs/a-checkpoint.json"] = big + b"them"
    f, _ = cmd("get", "remote-jobs/a-checkpoint.json"); check("file đổi => 200 + nội dung MỚI (không dính cache cũ)", f[0] == "ok" and kv(f[1])["md5"] == md5(big + b"them"), f)
    cmd("clear"); gh.log.clear(); cmd("get", "remote-jobs/a-checkpoint.json")
    check("sau clearCache() không còn gửi If-None-Match", reqs()[0]["inm"] is None)
    gh.log.clear(); cmd("bytes", "remote-jobs/a.json"); cmd("bytes", "remote-jobs/a.json")
    check("getFileBytes (ảnh) không dùng bộ nhớ đệm", all(e["inm"] is None for e in reqs()))

    print("== 3. Ghi: file mới / ghi đè / file lớn / nhị phân / Unicode")
    f, _ = cmd("put", "remote-jobs/new.json", "{\"ten\":\"Truyện Việt\"}"); check("ghi file mới", f[0] == "ok" and gh.files["remote-jobs/new.json"] == "{\"ten\":\"Truyện Việt\"}".encode(), f)
    f, _ = cmd("put", "remote-jobs/new.json", "{\"ten\":\"đã sửa\"}"); check("ghi đè file nhỏ đã có (lấy sha tự động)", f[0] == "ok" and gh.files["remote-jobs/new.json"] == "{\"ten\":\"đã sửa\"}".encode(), f)
    f, _ = cmd("putbig", "remote-jobs/a-checkpoint.json", 7000); check("GHI ĐÈ file lớn > 1MB(giả): lấy sha bằng media type object => thành công", f[0] == "ok" and len(gh.files["remote-jobs/a-checkpoint.json"]) == 7000, f)
    f, _ = cmd("putbytes", "remote-jobs/a-images/img_1_1.png", 3000); want = bytes((i % 251) for i in range(3000))
    check("ghi nhị phân nguyên vẹn", f[0] == "ok" and gh.files["remote-jobs/a-images/img_1_1.png"] == want, f)
    f, _ = cmd("bytes", "remote-jobs/a-images/img_1_1.png"); check("đọc lại bytes nguyên vẹn", f[0] == "ok" and kv(f[1])["md5"] == md5(want), f)

    print("== 4. Ghi chen với runner khác (409) => đọc lại sha và ghi lại đúng 1 lần")
    gh.files["remote-jobs/race.json"] = b"v1"; gh.race_path = "remote-jobs/race.json"; gh.log.clear()
    f, _ = cmd("put", "remote-jobs/race.json", "v2")
    puts = reqs(lambda e: e["method"] == "PUT")
    check("lần ghi đầu 409, lần 2 thành công", f[0] == "ok" and [e["code"] for e in puts] == [409, 200] and gh.files["remote-jobs/race.json"] == b"v2", (f, [e["code"] for e in puts]))

    print("== 5. Liệt kê thư mục")
    for i in range(3): gh.files["remote-jobs/d1/f%d.png" % i] = b"x"
    gh.files["remote-jobs/d1/sub/deep.png"] = b"x"
    f, _ = cmd("list", "remote-jobs/d1"); check("thư mục nhỏ: 3 file (bỏ thư mục con)", f[0] == "ok" and kv(f[1])["count"] == "3", f)
    f, _ = cmd("list", "remote-jobs/khong-co"); check("thư mục không có => rỗng, không lỗi", f[0] == "ok" and kv(f[1])["count"] == "0", f)
    for i in range(1005): gh.files["remote-jobs/big-images/img_%04d.png" % i] = b"y"
    gh.log.clear(); f, _ = cmd("list", "remote-jobs/big-images")
    check("thư mục 1005 file: lấy ĐỦ 1005 (Contents API chỉ trả 1000 => chuyển Git Trees)", f[0] == "ok" and kv(f[1])["count"] == "1005" and kv(f[1])["distinct"] == "1005", f)
    check("có gọi Git Trees (đi từng cấp, không recursive)", any("/git/trees/" in e["path"] for e in gh.log) and not any("recursive" in e["path"] for e in gh.log), [e["path"] for e in gh.log])
    gh.log.clear(); f, _ = cmd("list", "remote-jobs/big-images")
    check("lần liệt kê thứ 2 dùng ETag/304 (không tải lại)", f[0] == "ok" and kv(f[1])["count"] == "1005" and any(e["code"] == 304 for e in gh.log), [(e["path"][-30:], e["code"]) for e in gh.log])

    print("== 6. Giới hạn tốc độ")
    gh.limit_n = 1; gh.log.clear(); f, ms = cmd("get", "remote-jobs/a.json")
    check("giới hạn phụ (403 + Retry-After:1): chờ rồi tự thử lại => thành công", f[0] == "ok" and [e["code"] for e in gh.log] == [403, 200] and ms >= 900, (f, ms, [e["code"] for e in gh.log]))
    gh.limit_long = True; gh.log.clear(); f, ms = cmd("get", "remote-jobs/a.json"); gh.limit_long = False
    check("hết hạn mức giờ (reset sau 1 giờ): KHÔNG treo luồng, trả lỗi rõ", f[0] == "err" and f[1] == "403" and "giới hạn tốc độ" in f[2] and ms < 3000 and len(gh.log) == 1, (f, ms, len(gh.log)))
    gh.limit_n = 99; gh.log.clear(); f, ms = cmd("put", "remote-jobs/x.json", "q"); gh.limit_n = 0
    check("bị giới hạn liên tục: mỗi request thử tối đa 3 lần (1 + 2 lần thử lại) rồi báo lỗi, không lặp vô hạn", f[0] == "err" and f[1] == "403" and len(gh.log) == 6, (f, len(gh.log)))

    print("== 7. Actions")
    f, _ = cmd("dispatch"); check("dispatchWorkflow (204)", f[0] == "ok", f)
    f, _ = cmd("latestrun"); check("findLatestRun đọc được conclusion=null", f[0] == "ok" and "id=42" in f[1] and "status=in_progress" in f[1], f)

    p.stdin.write("quit\n"); p.stdin.flush(); p.wait(timeout=10)
    print("\nKẾT QUẢ GitHubApiClient: %d pass, %d fail" % (OK, FAIL))
    sys.exit(1 if FAIL else 0)

main()
