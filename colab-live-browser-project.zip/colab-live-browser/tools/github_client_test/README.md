# Kiểm tra `GitHubApiClient.kt` THẬT bằng JVM (không cần Android, không cần mạng)

Biên dịch `remote/GitHubApiClient.kt` (mã thật của app) bằng kotlinc cùng stub Android tối thiểu, rồi chạy nó trên JVM với một máy chủ GitHub GIẢ viết bằng Python (`run.py`) — mô phỏng theo tài liệu GitHub:
file > 1 MB (media type `raw`/`object`), ETag + `If-None-Match` → 304, thư mục > 1000 mục (Git Trees), 403 + `Retry-After` (giới hạn phụ), hết hạn mức giờ không treo luồng, trượt `sha` (409/422) thử lại một lần, dispatch workflow.

    python3 tools/github_client_test/run.py <thư mục kotlinc>     # kỳ vọng: 25/25 PASS

`GhRepl.kt` là vòng lặp lệnh (REPL) trên stdin/stdout để `run.py` điều khiển client. Giới hạn: máy chủ giả mô phỏng THEO TÀI LIỆU, chưa phải GitHub thật; không kiểm các lớp dùng API Android (Handler, SharedPreferences, Keystore).
