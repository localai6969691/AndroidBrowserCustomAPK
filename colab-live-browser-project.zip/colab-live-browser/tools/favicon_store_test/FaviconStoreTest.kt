import com.colablive.keeper.core.FaviconStoreLogic as L
var fails = 0; var total = 0
fun check(n: String, ok: Boolean) { total++; if (!ok) { fails++; println("FAIL: $n") } else println("ok:   $n") }
fun main() {
    // 1. tên tệp theo URL (bỏ #fragment), ổn định, khác URL => khác tên
    val a = L.fileNameForUrl("https://claude.ai/chat/c6c2f86d#phan1"); val b = L.fileNameForUrl("https://claude.ai/chat/c6c2f86d#phan2")
    check("1a. bỏ #fragment: hai URL chỉ khác fragment dùng chung tệp", a == b)
    check("1b. URL khác => tên khác", a != L.fileNameForUrl("https://claude.ai/chat/8d7a90db"))
    check("1c. tên hợp lệ: 40 hex + .png, ổn định giữa các lần gọi", Regex("[0-9a-f]{40}\\.png").matches(a) && a == L.fileNameForUrl("https://claude.ai/chat/c6c2f86d"))
    check("1d. query KHÔNG bị bỏ (phân biệt trang)", L.fileNameForUrl("https://x.com/a?id=1") != L.fileNameForUrl("https://x.com/a?id=2"))
    // 2. targetSize
    check("2a. 512x512 -> 128x128", L.targetSize(512, 512) == Pair(128, 128))
    check("2b. 64x64 giữ nguyên, không phóng to", L.targetSize(64, 64) == Pair(64, 64))
    check("2c. 180x90 giữ tỉ lệ -> 128x64", L.targetSize(180, 90) == Pair(128, 64))
    check("2d. 1000x3 -> mỗi cạnh >= 1", L.targetSize(1000, 3).let { it.first == 128 && it.second >= 1 })
    check("2e. kích thước <=0 -> 1x1", L.targetSize(0, 10) == Pair(1, 1))
    // 3. selectDeletions
    val now = 10_000_000_000L; val day = 24L * 3600 * 1000
    val entries = listOf(
        L.Entry("open_old.png", now - 10 * day),      // tab đang mở dù cũ => GIỮ
        L.Entry("orphan_old.png", now - 5 * day),     // không mở, >3 ngày => XOÁ
        L.Entry("orphan_new.png", now - 1 * day),     // không mở, <3 ngày => giữ
        L.Entry("open_new.png", now - 1000))
    val keep = setOf("open_old.png", "open_new.png")
    val del = L.selectDeletions(entries, keep, now)
    check("3a. chỉ xoá tệp mồ côi quá 3 ngày", del == listOf("orphan_old.png"))
    check("3b. tệp của tab đang mở KHÔNG BAO GIỜ bị xoá (kể cả 10 ngày tuổi)", "open_old.png" !in del && "open_new.png" !in del)
    // 4. trần cứng
    val many = (0 until L.HARD_CAP + 50).map { L.Entry("f$it.png", now - it) }   // đều mới (<3 ngày), f0 mới nhất
    val keep2 = setOf("f${L.HARD_CAP + 10}.png")                                   // một tệp vượt trần nhưng thuộc tab đang mở
    val d2 = L.selectDeletions(many, keep2, now)
    check("4a. vượt trần: xoá đúng số tệp thừa trừ tệp đang mở (50-1)", d2.size == 49)
    check("4b. tệp mới nhất không bị xoá, tệp đang mở vượt trần vẫn giữ", "f0.png" !in d2 && "f${L.HARD_CAP + 10}.png" !in d2 && "f${L.HARD_CAP + 49}.png" in d2)
    check("4c. không có gì để xoá khi ít tệp", L.selectDeletions(listOf(L.Entry("a.png", now)), emptySet(), now).isEmpty())
    println("\n$total kiểm tra, $fails lỗi"); if (fails > 0) System.exit(1)
}
