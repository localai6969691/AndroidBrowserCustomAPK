#!/usr/bin/env bash
# Kiểm thử logic thuần của kho favicon (bản 7.114): tên tệp theo URL, kích thước lưu, dọn tệp mồ côi, trần cứng. Cần kotlinc + java + android.jar (chỉ để biên dịch FaviconStore.kt; KHÔNG chạy Bitmap).
#   ANDROID_JAR=/đường/dẫn/android.jar bash run.sh
set -e
cd "$(dirname "$0")"
OUT=$(mktemp -d)
kotlinc -cp "${ANDROID_JAR:-android.jar}" ../../app/src/main/java/com/colablive/keeper/core/FaviconStore.kt FaviconStoreTest.kt -include-runtime -d $OUT/t.jar 2>/dev/null && java -jar $OUT/t.jar
