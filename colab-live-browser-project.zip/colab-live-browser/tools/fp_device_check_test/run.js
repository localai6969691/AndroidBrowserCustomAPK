const fs=require('fs');
const src=fs.readFileSync('/home/claude/colab-live-browser/app/src/main/assets/fingerprint_spoof/content.js','utf8');
function grab(name){ const i=src.indexOf('function '+name+'('); if(i<0) throw new Error('không thấy '+name); let d=0,k=src.indexOf('{',i); for(;k<src.length;k++){ if(src[k]==='{')d++; else if(src[k]==='}'){d--; if(d===0)break;} } return src.slice(i,k+1); }
const fnDev=grab('deviceCheck'), fnApp=grab('appVersionFor');
let total=0,fails=0; function check(n,ok){ total++; if(!ok){fails++;console.log('FAIL:',n);} else console.log('ok:  ',n); }
function run(opts){
  const out=[];
  const port={postMessage:m=>out.push(m)};
  const gl={ getExtension:()=>({UNMASKED_VENDOR_WEBGL:1,UNMASKED_RENDERER_WEBGL:2}), getParameter:(p)=> p===1?opts.gpuVendor: p===2?opts.gpuRenderer: p==='MT'?8192:4096, MAX_TEXTURE_SIZE:'MT', MAX_RENDERBUFFER_SIZE:'MR', getSupportedExtensions:()=>new Array(30).fill('x') };
  const W={ navigator:{userAgent:opts.ua,platform:opts.platform,hardwareConcurrency:opts.cores,maxTouchPoints:opts.touch,appVersion:'5.0 (Android 14)',language:'vi-VN',oscpu:'Linux armv81'},
            screen:{width:396,height:880,availWidth:396,availHeight:880,colorDepth:24}, devicePixelRatio:2.727, innerWidth:396, innerHeight:700,
            document:{createElement:()=>({getContext:()=>gl})}, Intl:{DateTimeFormat:function(){return {resolvedOptions:()=>({timeZone:'Asia/Ho_Chi_Minh'})}}} };
  const ctx={ config:opts.config, canExport:true, W, window:{top:opts.top===false?{}:undefined}, location:{hostname:'browserleaks.com',protocol:'https:'}, myLayer:'n', earlyVerdict:'khớp', patched:new Array(14).fill(0), applyErrors:[], hostSkipped:()=>false, navigator:{}, screen:{} };
  ctx.window.top = opts.top===false ? {} : ctx.window; // window === window.top khi là khung trên cùng
  const f=new Function(...Object.keys(ctx), fnApp+'\n'+fnDev+'\nreturn deviceCheck;')(...Object.values(ctx));
  f(port,7); return out;
}
const baseCfg={enabled:true,hardware:true,screenSpoof:false,uaSync:true,spoofLocale:true,platform:'Linux armv8l',hardwareConcurrency:8,maxTouchPoints:5,
  userAgent:'Mozilla/5.0 (Android 14; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0',screenWidth:1080,screenHeight:2340,pixelRatio:2.6,colorDepth:24,
  webglVendor:'ARM',webglRenderer:'Mali-G68 MP5',language:'vi-VN',timezone:'Asia/Ho_Chi_Minh'};
// 1) hồ sơ di động Galaxy A55, mọi thứ giả đúng
let o=run({config:baseCfg,ua:baseCfg.userAgent,platform:'Linux armv8l',cores:8,touch:5,gpuVendor:'ARM',gpuRenderer:'Mali-G68 MP5'});
let rows=o[0].rows.join('\n'); console.log(rows.split('\n').slice(0,14).join('\n'));
check('1a. có đúng 1 bản tin devcheck mang reqId=7', o.length===1 && o[0].action==='devcheck' && o[0].reqId===7);
check('1b. platform/nhân/cảm ứng/GPU đúng cấu hình => OK', /platform = Linux armv8l → OK/.test(rows) && /số nhân\) = 8 → OK/.test(rows) && /maxTouchPoints = 5 → OK/.test(rows) && /UNMASKED_RENDERER \(GPU\) = Mali-G68 MP5 → OK/.test(rows));
check('1c. màn hình hồ sơ di động = THẬT, nêu rõ cấu hình bảo 1080x2340 (đây là chỗ "thiết bị lệch cài đặt")', /màn hình \(screen.width×height\) = 396x880 → THẬT \(hồ sơ DI ĐỘNG.*1080x2340/.test(rows));
check('1d. DPR thật, nêu cấu hình bảo 2.6', /devicePixelRatio = 2.727 → THẬT.*2.6/.test(rows));
check('1e. MAX_TEXTURE_SIZE ghi là THẬT, không giả được', /MAX_TEXTURE_SIZE = 8192 → THẬT/.test(rows));
// 2) tab ở chế độ máy tính: hardware=false => KHÔNG giả
let c2=Object.assign({},baseCfg,{hardware:false,uaSync:false});
o=run({config:c2,ua:'Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0',platform:'Linux x86_64',cores:8,touch:5,gpuVendor:'Qualcomm',gpuRenderer:'Adreno (TM) 740'});
rows=o[0].rows.join('\n');
check('2a. chế độ máy tính: platform THẬT kèm lý do', /platform = Linux x86_64 → THẬT \(tab đang ở chế độ máy tính/.test(rows));
check('2b. chế độ máy tính: GPU THẬT (Adreno 740) chứ không phải Mali của cấu hình', /UNMASKED_RENDERER \(GPU\) = Adreno \(TM\) 740 → THẬT/.test(rows));
check('2c. dòng tổng ghi giả thiết bị=false', /giả thiết bị \(hardware\)=false/.test(rows));
// 3) đang giả mà GPU thật lộ ra (spoof hỏng) => SAI
o=run({config:baseCfg,ua:baseCfg.userAgent,platform:'Linux armv8l',cores:8,touch:5,gpuVendor:'Qualcomm',gpuRenderer:'Adreno (TM) 740'});
rows=o[0].rows.join('\n');
check('3. cấu hình giả Mali nhưng trang thấy Adreno => SAI', /UNMASKED_RENDERER \(GPU\) = Adreno \(TM\) 740 → SAI \(cấu hình bảo Mali-G68 MP5\)/.test(rows));
// 4) addon tắt
o=run({config:Object.assign({},baseCfg,{enabled:false}),ua:baseCfg.userAgent,platform:'Linux armv8l',cores:8,touch:5,gpuVendor:'ARM',gpuRenderer:'x'});
check('4. addon tắt => mọi dòng THẬT (addon tắt)', /platform = Linux armv8l → THẬT \(addon tắt\)/.test(o[0].rows.join('\n')));
// 5) khung con không trả lời
o=run({config:baseCfg,ua:baseCfg.userAgent,platform:'Linux armv8l',cores:8,touch:5,gpuVendor:'ARM',gpuRenderer:'Mali-G68 MP5',top:false});
check('5. khung con (không phải top) không gửi gì', o.length===0);
console.log('\n'+total+' kiểm tra, '+fails+' lỗi'); process.exit(fails?1:0);
