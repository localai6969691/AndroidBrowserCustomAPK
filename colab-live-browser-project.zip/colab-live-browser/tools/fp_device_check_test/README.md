# Kiểm thử `deviceCheck` (bản 7.113)

`node run.js` — trích NGUYÊN VĂN hàm `deviceCheck` và `appVersionFor` từ `app/src/main/assets/fingerprint_spoof/content.js`, chạy với môi trường giả lập (không cần trình duyệt/Android).
Các ca: hồ sơ di động giả đúng; tab ở chế độ máy tính (không giả thiết bị); GPU thật lộ ra khi cấu hình bảo giả (SAI); addon tắt; khung con không trả lời.
Cần Node >= 16. Kết quả mong đợi: `11 kiểm tra, 0 lỗi`.
