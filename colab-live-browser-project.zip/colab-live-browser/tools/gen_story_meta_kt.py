"""Sinh StoryMetaJs.kt từ tools/story_meta/story_meta.js (nguồn DUY NHẤT của script trích thông tin truyện). Dùng: python3 tools/gen_story_meta_kt.py tools/story_meta/story_meta.js app/src/main/java/com/colablive/keeper/features/ebookleech/engine/StoryMetaJs.kt"""
import re, sys
js = open(sys.argv[1], encoding='utf-8').read()
assert '"""' not in js, 'script chứa """ — không đặt được trong raw string Kotlin'
assert not re.search(r'\$[A-Za-z_{]', js), 'script chứa $ + tên/{ — Kotlin sẽ coi là mẫu chuỗi'
assert all(ord(c) < 128 for c in js), 'script phải thuần ASCII (so khớp từng byte với Python/LeechDesk)'
kt = '''package com.colablive.keeper.features.ebookleech.engine

/**
 * Bản 7.104 — script trích THÔNG TIN TRUYỆN (tác giả, tóm tắt, thể loại, tag, tình trạng, đánh giá, bìa...) chạy TRONG trang.
 *
 * FILE SINH TỰ ĐỘNG từ `tools/story_meta/story_meta.js` (xem tools/gen_story_meta_kt.py) — KHÔNG sửa tay. GIỐNG HỆT từng byte bản trong `remote_runner/crawler.py` (STORY_META_JS)
 * và LeechDesk (`ld/storymeta.py`); có test so khớp ở tools/story_meta/story_meta_identity.py. Cách gọi: `"(" + STORY_META_JS + ")(" + cfgJson + ")"`, kết quả là chuỗi JSON
 * `{"meta":{...},"sources":{...}}` (xem [com.colablive.keeper.features.ebookleech.model.StoryMeta.fromExtractorJson]).
 */
object StoryMetaJs {
    const val STORY_META_JS = """''' + js + '''"""
}
'''
open(sys.argv[2], 'w', encoding='utf-8', newline='').write(kt)
print('ok', len(js))
