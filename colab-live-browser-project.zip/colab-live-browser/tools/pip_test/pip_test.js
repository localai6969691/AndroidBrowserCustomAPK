const { chromium } = require('playwright');
const fs = require('fs');
const js = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 360, height: 800 } });
  await page.setContent(`<!doctype html><html><head><style>
    body{margin:0;background:#222;color:#fff;font:14px sans-serif}
    #masthead{position:fixed;top:0;left:0;right:0;height:56px;background:#c00;z-index:2020}
    #outer{transform:translateZ(0);filter:brightness(1);overflow:hidden;position:relative;margin-top:60px;opacity:.99;z-index:5}
    #player{position:relative;width:360px;height:203px;contain:layout paint;will-change:transform}
    video{position:absolute;left:0;top:0;width:360px;height:203px;background:#123}
    .below{height:2000px}
  </style></head><body>
  <div id="masthead">masthead</div>
  <div id="outer"><div id="player" class="a b"><div class="wrap" style="transform:scale(1)"><video id="v"></video></div></div></div>
  <div class="below">page content</div>
  <video id="aud" style="width:10px;height:10px"></video>
  </body></html>`);
  // video giả đang chạy 1280x720
  await page.evaluate(() => {
    const v = document.getElementById('v');
    Object.defineProperty(v, 'paused', { get: () => false, configurable: true });
    Object.defineProperty(v, 'ended', { get: () => false });
    Object.defineProperty(v, 'readyState', { get: () => 4 });
    Object.defineProperty(v, 'videoWidth', { get: () => 1280 });
    Object.defineProperty(v, 'videoHeight', { get: () => 720 });
  });
  const rect = async () => page.evaluate(() => { const r = document.getElementById('v').getBoundingClientRect(); return [r.x, r.y, r.width, r.height].map(Math.round); });
  let ok = true; const check = (name, cond, extra) => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? ' ' + JSON.stringify(extra) : '')); if (!cond) ok = false; };

  const before = await rect();
  check('trước: video nằm trong player, không phủ kín', before[3] === 203 && before[1] > 50, before);
  check('probe thấy video đang chạy', (await page.evaluate(js.probe)) === 'V|1280|720');

  // viewport PiP 320x180
  await page.setViewportSize({ width: 320, height: 180 });
  const r1 = await page.evaluate(js.enter);
  check('enter trả OK', /^OK\|anc=\d+\|1280x720$/.test(r1), r1);
  const after = await rect();
  check('sau enter: phủ kín 320x180', after[0] === 0 && after[1] === 0 && after[2] === 320 && after[3] === 180, after);
  const top = await page.evaluate(() => { const e = document.elementFromPoint(160, 90); return e && e.id; });
  check('điểm giữa màn hình là video (không bị masthead/lớp khác che)', top === 'v', top);
  const topLeft = await page.evaluate(() => { const e = document.elementFromPoint(5, 5); return e && e.id; });
  check('góc trên trái (chỗ masthead) cũng là video', topLeft === 'v', topLeft);
  check('trang không cuộn (overflow hidden)', await page.evaluate(() => getComputedStyle(document.documentElement).overflow === 'hidden'));

  // khung phát ghi đè thuộc tính class => timer phải áp lại
  await page.evaluate(() => { document.getElementById('v').className = ''; document.getElementById('player').className = ''; });
  const broken = await rect();
  await page.waitForTimeout(1000);
  const healed = await rect();
  check('bị ghi đè class thì sau <1s tự áp lại', healed[2] === 320 && healed[3] === 180, { broken, healed });

  // thoát PiP
  await page.setViewportSize({ width: 360, height: 800 });
  const r2 = await page.evaluate(js.exit);
  check('exit trả OK', /^OK\|/.test(r2), r2);
  await page.waitForTimeout(1000);
  const restored = await rect();
  check('sau exit: về đúng vị trí/kích thước cũ', restored.join() === before.join(), { before, restored });
  const left = await page.evaluate(() => ({ style: !!document.getElementById('__lb_pip_style'), cls: document.querySelectorAll('.__lb_pip_anc,.__lb_pip_vid').length, html: document.documentElement.className }));
  check('không còn style/class dấu vết', !left.style && left.cls === 0 && !/__lb_pip/.test(left.html), left);

  // video tạm dừng => probe 'N'
  await page.evaluate(() => { Object.defineProperty(document.getElementById('v'), 'paused', { get: () => true, configurable: true }); });
  check('video tạm dừng => probe N', (await page.evaluate(js.probe)) === 'N');
  // không có video => NOVIDEO
  await page.evaluate(() => document.querySelectorAll('video').forEach(v => v.remove()));
  check('không có video => NOVIDEO', (await page.evaluate(js.enter)) === 'NOVIDEO');
  check('không có video => probe N', (await page.evaluate(js.probe)) === 'N');

  await browser.close();
  console.log(ok ? 'ALL PASS' : 'SOME FAIL'); process.exit(ok ? 0 : 1);
})();
