Kiểm tra đoạn JS "ép <video> phủ kín cửa sổ nổi" của GeckoViewEngine (bản 7.109, mục 234.5).
Cần Node + playwright (Chromium). Đây là kiểm trên Chromium với trang giả, KHÔNG phải Gecko/YouTube thật.
  python3 extract.py ../../app/src/main/java/com/colablive/keeper/core/GeckoViewEngine.kt /tmp/js.json
  NODE_PATH=$(npm root -g) node pip_test.js /tmp/js.json     # kỳ vọng: ALL PASS (11 kiểm tra)
extract.py dựng lại đúng chuỗi JS từ mã Kotlin (PIP_PROBE_JS / PIP_ENTER_JS / PIP_EXIT_JS) để test chạy trên chính chuỗi đó.
