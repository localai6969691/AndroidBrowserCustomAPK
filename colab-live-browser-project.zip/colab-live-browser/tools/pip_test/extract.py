import re,sys,json
src=open(sys.argv[1],encoding='utf-8').read()
seg=src[src.index("private val PIP_PICK_VIDEO_JS"):src.index("/** Tỉ lệ rộng/cao của <video> đang chạy")]
def kt_unescape(lit):
    out=[];i=0
    while i<len(lit):
        c=lit[i]
        if c=='\\':
            n=lit[i+1]; out.append({'n':'\n','t':'\t','"':'"','\\':'\\','$':'$',"'":"'"}.get(n,n)); i+=2
        else: out.append(c); i+=1
    return ''.join(out)
def strings(expr):
    # trả danh sách literal "..." (không raw) theo thứ tự trong biểu thức
    res=[];i=0
    while i<len(expr):
        if expr[i]=='"':
            j=i+1
            while expr[j]!='"' or expr[j-1]=='\\' and expr[j-2]!='\\': j+=1
            res.append(kt_unescape(expr[i+1:j])); i=j+1
        else: i+=1
    return res
def decl(name):
    m=re.search(r'private val '+name+r' = (.*?)\n\n',seg,re.S)
    return m.group(1)
# pick
m=re.search(r'private val PIP_PICK_VIDEO_JS = """\n(.*?)\n    """\.trimIndent\(\)',seg,re.S)
import textwrap
pick=textwrap.dedent(m.group(1))
css=''.join(strings(decl('PIP_CSS')))
def build(name):
    expr=decl(name)
    parts=[]
    # tách theo "..." giữ cả ký hiệu template
    for lit in re.findall(r'"((?:[^"\\]|\\.)*)"',expr):
        lit=lit.replace('$PIP_PICK_VIDEO_JS','\x00PICK\x00').replace('${org.json.JSONObject.quote(PIP_CSS)}','\x00CSS\x00')
        parts.append(kt_unescape(lit))
    t=''.join(parts).replace('\x00PICK\x00',pick).replace('\x00CSS\x00',json.dumps(css))
    return t
out={'probe':build('PIP_PROBE_JS'),'enter':build('PIP_ENTER_JS'),'exit':build('PIP_EXIT_JS'),'css':css}
json.dump(out,open(sys.argv[2],'w'),ensure_ascii=False)
print({k:len(v) for k,v in out.items()})
