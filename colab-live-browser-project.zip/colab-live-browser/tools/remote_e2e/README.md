# Chạy THẬT crawler cào từ xa trên web giả (không cần GitHub, không cần điện thoại)

`e2e.py` chạy `ebookleech/remote_runner/crawler.py` thật (Python + Playwright + Chromium + git push), với:
- một web giả cục bộ (trang tĩnh, trang dựng bằng JS sau 1,5 giây, trang chỉ hiện nội dung sau khi cuộn),
- một repo git "origin" là bare repo trên đĩa (thay cho GitHub),
- chạy dưới `xvfb-run` (đặt `E2E_NO_XVFB=1` để mô phỏng Colab không có màn hình ảo).

KHÔNG phải GitHub Actions/Colab thật, không có Cloudflare thật. Chỉ chứng minh logic của `crawler.py`.

Cần: python3, `pip install playwright beautifulsoup4 lxml`, `python3 -m playwright install chromium`, xvfb, git.

    python3 e2e.py <đường dẫn crawler.py> <kịch bản>

Kịch bản: `static`, `js`, `lazy` (không bật cuộn), `lazy_on` (bật cuộn), `rerun` (chạy lại job đã xong, site có thêm chương), `rerun_reset` (như rerun nhưng giữa hai lần ghi đè checkpoint bằng `reset_cp.json` do `CrawlCheckpoint.toJson()` của Kotlin sinh ra, giống app 7.101).

Kết quả bản 7.101 (xem PROJECT_STATUS.md mục 225): static 5/5, js 5/5, lazy_on 5/5, rerun_reset ra 8 chương. `rerun` (KHÔNG xoá checkpoint cũ) vẫn ra 5: đó là hành vi cũ, app 7.101 tránh nó bằng cách ghi đè checkpoint trước khi chạy mới.

Kiểm tra bước "Chuẩn bị mã crawler" của workflow: trích đoạn `run:` của bước đó từ `ebookleech/EBOOKLEECH_REMOTE_CRAWL_STEP.yml` (đặt `RUNNER_TEMP`, `GITHUB_ENV`) rồi chạy bằng bash trong một repo chỉ có file `colab-live-browser-project.zip`.

## Bản 7.102 — kịch bản "chỉ cào chương mới" (cào từ xa tăng dần)
Thêm các kịch bản (web giả có bộ đếm số lần mở từng trang chương; job bật `incrementalUpdate`):
- `noinc_rerun`: chạy lại job KHÔNG bật tăng dần, site 5 → 8 chương => vẫn cào lại toàn bộ, ra đủ 8 chương (không còn lỗi "ra lại dữ liệu cũ" của bản trước 7.101).
- `inc_rerun`: site 5 → 8 chương. Lần hai chỉ mở trang chương 6, 7, 8 (3 trang) và dùng lại 5 chương cũ; lần ba (không đổi) mở 0 trang. Kiểm `reusedCount/crawledCount/runnerVersion` trong checkpoint, `index` chương cũ giữ nguyên, `-archive.json` đã bị xoá khi xong.
- `inc_refresh`: `refreshLastN=2` — cào lại đúng 2 chương cuối (nội dung site đã sửa), phần còn lại dùng lại.
- `inc_foreign`: checkpoint "đã xong" do công cụ ngoài sửa: `index` TRÙNG (1,1,2,3,3) và một chương lỗi (`[loi]`) => lần chạy tăng dần dùng lại chương tốt, cào lại chương lỗi, bảo toàn `index` duy nhất (không đụng tên ảnh).
- `inc_resume`: site 14 chương, giết `crawler.py` giữa lúc chạy tăng dần (lần hai) rồi chạy tiếp; chương cũ vẫn lấy từ `-archive.json`. Biến môi trường: `E2E_KILL_AFTER` (giây trước khi giết, mặc định 24; nếu lần chạy xong trước khi bị giết thì giảm xuống, ví dụ 14), `E2E_DESC=1` (site liệt kê chương mới nhất trước, để chương cũ nằm SAU điểm bị giết — chứng minh archive được dùng thật).

Cùng hạn chế: web giả + git cục bộ, không phải GitHub Actions/Colab thật.

## Bản 7.103 — bỏ qua chương, chương nhiều trang, chuỗi ghi file của app
- `multi`: chương 2 gộp 3 trang; chương 5 có nút "Tiếp" trỏ sang chương 6 (KHÔNG được nối nhầm); lỗi trang ≥ 2 giữ phần đã có.
- `multi_max`: dừng ở `maxChapterPages`.
- `skip`: bỏ chương chứa cụm khoá (không phân biệt hoa thường) và chương quá ngắn; kiểm `index` liên tục, `skippedCount`, chương bị bỏ không vào ebook/kho.
- `skip_inc`: bỏ qua + tăng dần cùng lúc (chương bị bỏ không được lưu vào kho nên lần sau site mở khoá vẫn thử lại).
- `app_fresh`: giả lập ĐÚNG chuỗi ghi file của `RemoteCrawlRunner.prepareFreshRemoteRun` (checkpoint xong cũ → `-archive.json`; checkpoint rỗng; spec CUỐI kèm `runRequestedAt`) rồi chạy crawler; kỳ vọng: chỉ mở chương MỚI, `index` 1..N liên tục, archive bị xoá khi xong, có `runnerVersion`.
- `app_fresh_noinc`: như trên nhưng job không bật `incrementalUpdate` ⇒ cào lại đủ, không dính dữ liệu cũ.
Kèm kiểm `index` không đụng nhau sau `refreshLastN` (chương cào lại giữ `index` cũ).
Chạy: `xvfb-run -a python3 e2e.py <đường dẫn TUYỆT ĐỐI crawler.py> <kịch bản>` (đường dẫn tương đối làm lỗi exit=2).
Lưu ý khi chạy crawler.py ≤ 7.102 với `app_fresh`: kết quả đúng (đủ chương) nhưng kịch bản báo FAIL ở "chỉ mở chương mới" vì bản cũ không nạp kho — đó là hành vi đã biết (TAI_LIEU_KY_THUAT 6.4c mục 4).

## Bản 7.104 — kịch bản `fast_scan` (quét nhanh danh sách theo điểm neo + thông tin truyện)
Chạy `crawler.py` THẬT (Chromium + git cục bộ) trên web giả có trang danh sách phân trang (`/pg/list?page=N`), bìa (`/pg/cover.png`) và trang chương (`/pg/c/<n>`):

    cd tools/remote_e2e && xvfb-run -a python3 -I e2e.py ../../ebookleech/remote_runner/crawler.py fast_scan

Kiểm: lần 1 quét đầy đủ rồi ghi `listScan.lastPage`; lần 2 (site thêm 3 chương cuối) chỉ mở trang 1, 7, 8, 9, 10 và 3 chương mới, bìa KHÔNG tải lại; trang 1 trả rỗng dù kho có chương ⇒ coi như bị chặn, giữ danh sách cũ; chương chèn GIỮA danh sách ⇒ quét nhanh KHÔNG thấy (giới hạn có thật), quét đầy đủ thì thấy; `listFastScan=false` ⇒ quét đầy đủ; `storyMeta` có trong checkpoint/kho. STATE của máy chủ giả có thêm `ids, pages, page_mode, story_hits, cover_hits`. Kết quả bản 7.104: `fast_scan` ALL OK + 6 kịch bản cũ không hồi quy. Chưa chạy: GitHub thật, site thật.

