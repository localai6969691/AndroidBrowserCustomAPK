#!/usr/bin/env python3
"""
Chạy THẬT ebookleech/remote_runner/crawler.py (Playwright + Chromium + git push) trên web giả cục bộ.
Không phải GitHub Actions thật: repo "origin" là một bare repo trên đĩa, trình duyệt chạy dưới xvfb-run.
Dùng: e2e.py <crawler.py path> <scenario>
"""
import json, os, subprocess, sys, threading, time, shutil, tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CRAWLER = sys.argv[1]
SCENARIO = sys.argv[2]
STATE = {"chapters": 5, "hits": {}, "rev": {}, "locked": set(), "short": set(), "ids": list(range(1, 41)), "pages": {}, "page_mode": {}, "story_hits": 0, "cover_hits": 0}   # số chương hiện có trên "site" (tăng để mô phỏng chương mới); hits = số lần mỗi trang chương bị mở; rev = chương nào đã bị sửa nội dung

def chapter_body(n):
    return f"Noi dung that cua chuong {n}. " + ("lorem ipsum " * 20) + (f" SUA-LAN-{STATE['rev'][n]}" if n in STATE["rev"] else "")

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, html):
        b = html.encode("utf-8")
        self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def _send_bytes(self, b, ct):
        self.send_response(200); self.send_header("Content-Type", ct); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        p = self.path.split("?")[0]
        n = STATE["chapters"]
        if p == "/pg/list":      # bản 7.104: danh sách PHÂN TRANG (5 chương/trang) + JSON-LD thông tin truyện + ảnh bìa
            q = dict(kv.split("=", 1) for kv in (self.path.split("?", 1)[1].split("&") if "?" in self.path else []) if "=" in kv)
            if "page" not in q:
                STATE["story_hits"] += 1          # mở thẳng /pg/list = trang thông tin truyện (storyInfoUrl mặc định), KHÔNG phải lượt quét danh sách
            pg = int(q.get("page", 1))
            if "page" in q:
                STATE["pages"][pg] = STATE["pages"].get(pg, 0) + 1
            ids = [] if STATE["page_mode"].get(pg) == "empty" and "page" in q else STATE["ids"][(pg - 1) * 5: pg * 5]
            ld = json.dumps({"@context": "https://schema.org", "@type": "Book", "name": "Dau Pha Thuong Khung", "author": {"@type": "Person", "name": "Thien Tam Tho Dau"},
                             "description": "Tom tat dong mot.\nDong hai.", "genre": ["Tien hiep", "Huyen huyen"], "image": "/pg/cover.png", "inLanguage": "vi",
                             "aggregateRating": {"@type": "AggregateRating", "ratingValue": "4.5", "bestRating": "5", "ratingCount": "1234"}})
            links = "".join(f'<li><a class="ch" href="/pg/c/{i}">Chuong {i}</a></li>' for i in ids)
            return self._send(f'<html lang="vi"><head><meta charset="utf-8"><title>Dau Pha</title><script type="application/ld+json">{ld}</script></head><body><h1>Dau Pha Thuong Khung</h1><ul>{links}</ul></body></html>')
        if p == "/pg/cover.png":
            STATE["cover_hits"] += 1
            return self._send_bytes(bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000001e221bc330000000049454e44ae426082"), "image/png")
        if p.startswith("/pg/c/"):
            i = int(p.rsplit("/", 1)[1]); STATE["hits"][p] = STATE["hits"].get(p, 0) + 1
            return self._send(f'<html><body><h1 class="t">Chuong {i}</h1><div class="body">{chapter_body(i)}</div></body></html>')
        if "/c/" in p:
            STATE["hits"][p] = STATE["hits"].get(p, 0) + 1
        if p == "/static/list":
            order = range(n, 0, -1) if os.environ.get("E2E_DESC") == "1" else range(1, n + 1)   # E2E_DESC=1: site liệt kê chương MỚI NHẤT TRƯỚC (kiểu nhiều site truyện)
            links = "".join(f'<li><a class="ch" href="/static/c/{i}">Chuong {i}</a></li>' for i in order)
            self._send(f"<html><body><ul>{links}</ul></body></html>")
        elif p.startswith("/static/c/"):
            i = int(p.rsplit("/", 1)[1])
            self._send(f'<html><body><h1 class="t">Chuong {i}</h1><div class="body">{chapter_body(i)}</div></body></html>')
        elif p == "/js/list":     # danh sách do JS dựng SAU 1.5 giây (kiểu SPA)
            items = ",".join(f'"/js/c/{i}"' for i in range(1, n + 1))
            self._send("<html><body><ul id='u'></ul><script>setTimeout(function(){"
                       f"var a=[{items}];var u=document.getElementById('u');"
                       "a.forEach(function(h,i){var li=document.createElement('li');var e=document.createElement('a');"
                       "e.className='ch';e.href=h;e.textContent='Chuong '+(i+1);li.appendChild(e);u.appendChild(li);});"
                       "},1500);</script></body></html>")
        elif p.startswith("/js/c/"):   # nội dung chương do JS dựng SAU 1.5 giây
            i = int(p.rsplit("/", 1)[1])
            self._send("<html><body><h1 class='t' id='h'></h1><div id='root'></div><script>setTimeout(function(){"
                       f"document.getElementById('h').textContent='Chuong {i}';"
                       f"var d=document.createElement('div');d.className='body';d.textContent={json.dumps(chapter_body(i))};"
                       "document.getElementById('root').appendChild(d);},1500);</script></body></html>")
        elif p == "/multi/list":
            links = "".join(f'<li><a class="ch" href="/multi/c/{i}">Chuong {i}</a></li>' for i in range(1, n + 1))
            self._send(f"<html><body><ul>{links}</ul></body></html>")
        elif p.startswith("/multi/c/"):     # bản 7.103: chương nhiều trang (2, 4), nút "Tiếp" trỏ sang CHƯƠNG khác (1), vòng lặp (4p2→4, 5→5), chương bị khoá (3), chương quá ngắn (6)
            key = p.rsplit("/", 1)[1]
            num = int("".join(ch for ch in key if ch.isdigit()) if "p" not in key else key.split("p")[0])
            part = int(key.split("p")[1]) if "p" in key else 1
            nxt = ""
            if num == 1: nxt = "/multi/c/2"
            elif num == 2 and part < 3: nxt = f"/multi/c/2p{part + 1}"
            elif num == 4 and part == 1: nxt = "/multi/c/4p2"
            elif num == 4 and part == 2: nxt = "/multi/c/4"
            elif num == 5: nxt = "/multi/c/5"
            body = chapter_body(num) + f" TRANG{part}-CUA-{num}."
            if num in STATE["locked"]: body = "Chuong nay BI KHOA, hay mo khoa de doc."
            if num in STATE["short"]: body = "Ngan."
            nxt_html = f'<a class="next" href="{nxt}">Tiep</a>' if nxt else ""
            self._send(f'<html><body><h1 class="t">Chuong {num}</h1><div class="body">{body}</div>{nxt_html}</body></html>')
        elif p == "/lazy/list":
            links = "".join(f'<li><a class="ch" href="/lazy/c/{i}">Chuong {i}</a></li>' for i in range(1, n + 1))
            self._send(f"<html><body><ul>{links}</ul></body></html>")
        elif p.startswith("/lazy/c/"):   # nội dung CHỈ được thêm vào khi người đọc cuộn xuống (lazy-load kiểu IntersectionObserver/scroll)
            i = int(p.rsplit("/", 1)[1])
            self._send("<html><body style='margin:0'><h1 class='t'>Chuong %d</h1><div style='height:3000px'>spacer</div><div id='end'></div><script>"
                       "var done=false;function f(){if(done)return;if(window.scrollY>200){done=true;setTimeout(function(){"
                       "var d=document.createElement('div');d.className='body';d.textContent=%s;document.body.appendChild(d);},300);}}"
                       "window.addEventListener('scroll',f);</script></body></html>" % (i, json.dumps(chapter_body(i))))
        else:
            self.send_response(404); self.end_headers()

def start_server():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]

def sh(cmd, cwd=None, check=True):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"{cmd} -> {r.stdout}\n{r.stderr}")
    return r

def setup_repo(root):
    origin = os.path.join(root, "origin.git"); work = os.path.join(root, "work")
    sh(["git", "init", "--bare", "-b", "main", origin])
    sh(["git", "clone", origin, work])
    sh(["git", "config", "user.name", "t"], cwd=work); sh(["git", "config", "user.email", "t@t"], cwd=work)
    os.makedirs(os.path.join(work, "remote-jobs"), exist_ok=True)
    open(os.path.join(work, "README"), "w").write("x")
    sh(["git", "add", "-A"], cwd=work); sh(["git", "commit", "-m", "init"], cwd=work); sh(["git", "push", "-u", "origin", "main"], cwd=work)
    return work

def run_crawler(work, job_id, timeout=240):
    cmd = [sys.executable, CRAWLER, job_id]
    env = dict(os.environ)
    if os.environ.get("E2E_NO_XVFB") == "1":
        env.pop("DISPLAY", None)           # mô phỏng Colab: KHÔNG có màn hình ảo
    else:
        cmd = ["xvfb-run", "--auto-servernum", "--server-args=-screen 0 1280x800x24"] + cmd
    r = subprocess.run(cmd, cwd=work, capture_output=True, text=True, timeout=timeout, env=env)
    return r

def read_cp(work, job_id):
    p = os.path.join(work, "remote-jobs", f"{job_id}-checkpoint.json")
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None

def summarize(cp):
    if cp is None: return "KHONG co checkpoint"
    ch = cp["chaptersSoFar"]
    ok = [c for c in ch if "[loi]" not in c["title"]]
    return (f"remoteDone={cp.get('remoteDone')} links={len(cp['chapterLinks'])} chaptersSoFar={len(ch)} "
            f"hop_le={len(ok)} loi={len(ch)-len(ok)} tieu_de_dau={ch[0]['title'] if ch else None!r}")

def spec(base, kind, extra=None):
    d = {"id": "J1", "name": "Test", "listPageUrl": f"{base}/{kind}/list", "listPageUrlPattern": "", "maxPages": 1,
         "chapterLinkSelector": "a.ch", "chapterLinkAttribute": "href", "chapterTitleSelector": ".t",
         "chapterContentSelector": ".body", "delayBetweenPagesMs": 50, "autoDetectPagination": False,
         "regexRules": [], "downloadImages": False, "preListStages": [], "ajaxListMode": False, "ajaxContentMode": False}
    d.update(extra or {})
    return d

def chapter_hits():
    """Số trang CHƯƠNG đã bị mở kể từ lần reset gần nhất: (tổng lượt mở, danh sách số chương đã bị mở)."""
    hs = STATE["hits"]
    return sum(hs.values()), sorted((k.split("/c/")[1] for k in hs), key=lambda x: (len(x), x))

def indexes_of(cp):
    return [c["index"] for c in cp["chaptersSoFar"]] if cp else None

def report(tag, cp, extra=""):
    total, which = chapter_hits()
    print(f"[{tag}] {summarize(cp)} | trang chuong mo={total} {which} | index={indexes_of(cp)} | reused={cp.get('reusedCount') if cp else None} crawled={cp.get('crawledCount') if cp else None} runner={cp.get('runnerVersion') if cp else None} {extra}")

def archive_exists(work):
    return os.path.exists(os.path.join(work, "remote-jobs", "J1-archive.json"))

def run_incremental_scenarios(scn, work, jobp, base):
    inc = scn != "noinc_rerun"
    extra = {"incrementalUpdate": inc}
    if scn == "inc_refresh": extra["refreshLastN"] = 2
    json.dump(spec(base, "static", extra), open(jobp, "w"))
    if scn == "inc_resume":
        # lần chạy 2 bị GIẾT giữa chừng (mô phỏng runner sập/Actions timeout) rồi chạy lại: phải tiếp tục đúng chỗ, vẫn dùng lại kho chương cũ cho phần chưa xử lý
        os.environ["E2E_NO_XVFB"] = "1"
        run_crawler(work, "J1"); report("lan1 (site 5)", read_cp(work, "J1"))
        STATE["hits"].clear(); STATE["chapters"] = 14
        spec2 = spec(base, "static", {"incrementalUpdate": True, "delayBetweenPagesMs": 2500}); json.dump(spec2, open(jobp, "w"))
        sh(["git", "add", "-A"], cwd=work); sh(["git", "commit", "-m", "spec2"], cwd=work); sh(["git", "push"], cwd=work)
        kill_after = float(os.environ.get("E2E_KILL_AFTER", "24"))
        try:
            run_crawler(work, "J1", timeout=kill_after)
            print("   (lan 2 chay xong truoc khi kip bi giet - tang E2E_KILL_AFTER xuong)")
        except subprocess.TimeoutExpired:
            subprocess.run("pkill -9 -f chrom", shell=True)
            print(f"   >>> lan 2 bi GIET sau {kill_after}s")
        cp = read_cp(work, "J1")
        print("   sau khi bi giet: remoteDone=%s chaptersSoFar=%d progress=%s archive_con=%s" % (cp.get("remoteDone"), len(cp["chaptersSoFar"]), cp["chapterProgressIndex"], archive_exists(work)))
        before = dict(STATE["hits"])
        spec2["delayBetweenPagesMs"] = 50; json.dump(spec2, open(jobp, "w"))
        r = run_crawler(work, "J1"); cp = read_cp(work, "J1")
        report("lan2 chay lai (tiep tuc)", cp, f"exit={r.returncode} archive_con_lai={archive_exists(work)}")
        old_hits = {k: v for k, v in STATE["hits"].items() if int(k.rsplit("/", 1)[1]) <= 5}
        print("   chuong cu 1..5 bi mo lai:", old_hits or "KHONG (dung)", "| chuong moi bi mo >1 lan:", {k: v for k, v in STATE["hits"].items() if v > 1} or "khong")
        print("   index duy nhat:", len(set(indexes_of(cp))) == len(indexes_of(cp)))
        return
    if scn == "inc_foreign":
        # checkpoint "đã xong" do công cụ ngoài tạo: index 0-based, có chỉ số TRÙNG (1,1) và một chương lỗi => dùng lại có phải bảo toàn duy nhất + bỏ chương lỗi
        run_crawler(work, "J1"); cp = read_cp(work, "J1")
        for k, c in enumerate(cp["chaptersSoFar"]): c["index"] = [1, 1, 2, 3, 3][k]
        cp["chaptersSoFar"][4]["title"] = "Chuong 5 [loi]"; cp["chaptersSoFar"][4]["textContent"] = "[Khong lay duoc noi dung: x]"
        json.dump(cp, open(os.path.join(work, "remote-jobs", "J1-checkpoint.json"), "w", encoding="utf-8"))
        sh(["git", "add", "-A"], cwd=work); sh(["git", "commit", "-m", "foreign"], cwd=work); sh(["git", "push"], cwd=work)
        STATE["hits"].clear(); STATE["chapters"] = 8
        r = run_crawler(work, "J1"); report("sau lan 2 (foreign cp, site 8 chuong)", read_cp(work, "J1"), f"exit={r.returncode}")
        return
    r = run_crawler(work, "J1"); report("lan1 (site 5)", read_cp(work, "J1"), f"exit={r.returncode} archive={archive_exists(work)}")
    STATE["hits"].clear(); STATE["chapters"] = 8
    if scn == "inc_refresh": STATE["rev"][8] = 1; STATE["rev"][7] = 1
    r = run_crawler(work, "J1"); cp = read_cp(work, "J1")
    report("lan2 (site 8, KHONG reset checkpoint)", cp, f"exit={r.returncode} archive_con_lai={archive_exists(work)}")
    print("   chuong 1 giu nguyen:", cp["chaptersSoFar"][0]["htmlContent"][:60].replace("\n", " ") if cp else None)
    if scn in ("inc_rerun", "inc_refresh"):
        STATE["hits"].clear()
        r = run_crawler(work, "J1"); report("lan3 (site van 8, khong doi)", read_cp(work, "J1"), f"exit={r.returncode}")
        if scn == "inc_refresh":
            c8 = [c for c in read_cp(work, "J1")["chaptersSoFar"] if c["sourceUrl"].endswith("/8")][0]
            print("   chuong 8 sau refresh co 'SUA-LAN-1':", "SUA-LAN-1" in c8["textContent"])
            cp3 = read_cp(work, "J1")
            check("chuong cao lai GIU index cu (khong thung so thu tu)", indexes_of(cp3) == list(range(1, 9)), indexes_of(cp3))

FAILS = []
def check(name, cond, detail=""):
    print(("   OK   " if cond else "   FAIL ") + name + ("" if cond else f"  -> {detail}"))
    if not cond: FAILS.append(name)

def texts(cp):
    return {c["sourceUrl"].rsplit("/", 1)[1]: c["textContent"] for c in cp["chaptersSoFar"]}

def app_reset(work):
    """Như RemoteCrawlRunner.prepareFreshRemoteRun (job bật tăng dần): checkpoint xong của lần trước -> `-archive.json`, checkpoint đặt lại RỖNG, commit."""
    cpf = os.path.join(work, "remote-jobs", "J1-checkpoint.json")
    open(os.path.join(work, "remote-jobs", "J1-archive.json"), "w", encoding="utf-8").write(open(cpf, encoding="utf-8").read())
    open(cpf, "w", encoding="utf-8").write(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "reset_cp.json"), encoding="utf-8").read())
    sh(["git", "add", "-A"], cwd=work); sh(["git", "commit", "-m", "app reset"], cwd=work); sh(["git", "push"], cwd=work)

def run_fast_scan_scenario(work, jobp, base):
    """Bản 7.104: quét nhanh theo điểm neo + thông tin truyện + chốt "trang 1 rỗng = bị chặn" của crawler.py THẬT (Chromium + git)."""
    json.dump(spec(base, "pg", {"listPageUrlPattern": "{base}?page={page}", "maxPages": 30, "incrementalUpdate": True}), open(jobp, "w"))
    r = run_crawler(work, "J1"); cp = read_cp(work, "J1"); report("lan1 (40 chuong, 8 trang)", cp, f"exit={r.returncode}")
    if cp is None: check("co checkpoint", False, (r.stdout + r.stderr)[-800:]); return
    check("lan 1: du 40 chuong, remoteDone", cp.get("remoteDone") and len(cp["chaptersSoFar"]) == 40, summarize(cp))
    check("lan 1: quet DAY DU 8 trang + 1 trang rong, diem neo lastPage=8", cp.get("listScan", {}).get("mode") == "full" and cp["listScan"].get("lastPage") == 8 and sorted(STATE["pages"]) == list(range(1, 10)), (cp.get("listScan"), STATE["pages"]))
    sm = cp.get("storyMeta") or {}
    check("lan 1: thong tin truyen (ten/tac gia/the loai/danh gia/tom tat/ngon ngu) trong checkpoint", sm.get("title") == "Dau Pha Thuong Khung" and sm.get("author") == "Thien Tam Tho Dau" and sm.get("genres") == ["Tien hiep", "Huyen huyen"]
          and (sm.get("rating") or {}).get("count") == 1234 and "Dong hai" in (sm.get("summary") or "") and sm.get("language") == "vi", sm)
    img = os.path.join(work, "remote-jobs", "J1-images", sm.get("coverFile") or "x")
    check("lan 1: anh bia tai ve remote-jobs/J1-images/ (dung byte PNG)", sm.get("coverFile") and os.path.exists(img) and open(img, "rb").read()[:4] == b"\x89PNG" and STATE["cover_hits"] == 1, (sm.get("coverFile"), STATE["cover_hits"]))
    # ---- lan 2: +3 chuong o CUOI ----
    STATE["ids"] += [41, 42, 43]; STATE["hits"].clear(); STATE["pages"].clear(); STATE["cover_hits"] = 0
    app_reset(work)
    r = run_crawler(work, "J1"); cp = read_cp(work, "J1"); report("lan2 (+3 chuong cuoi, quet nhanh)", cp, f"exit={r.returncode} archive_con_lai={archive_exists(work)}")
    total, which = chapter_hits()
    check("lan 2: 43 chuong, index 1..43, remoteDone", cp.get("remoteDone") and indexes_of(cp) == list(range(1, 44)), summarize(cp))
    check("lan 2: chi mo 3 chuong MOI (41,42,43); 40 chuong cu dung lai tu kho", which == ["41", "42", "43"] and cp.get("reusedCount") == 40 and cp.get("crawledCount") == 3, (which, cp.get("reusedCount"), cp.get("crawledCount")))
    check("lan 2: QUET NHANH — chi mo trang 1,7,8,9,10 (bo qua 2..6)", sorted(STATE["pages"]) == [1, 7, 8, 9, 10], STATE["pages"])
    check("lan 2: diem neo moi: mode=fast, fastStreak=1, lastPage=9", cp["listScan"].get("mode") == "fast" and cp["listScan"].get("fastStreak") == 1 and cp["listScan"].get("lastPage") == 9, cp.get("listScan"))
    check("lan 2: thu tu danh sach 1..43 khong doi, thong tin truyen con, bia KHONG tai lai (URL khong doi)", [u.rsplit("/", 1)[1] for u in cp["chapterLinks"]] == [str(i) for i in range(1, 44)]
          and (cp.get("storyMeta") or {}).get("title") == "Dau Pha Thuong Khung" and STATE["cover_hits"] == 0, (cp.get("storyMeta") or {}).get("coverFile"))
    # ---- lan 3: trang 1 RONG (site doi giao dien/bi chan) => giu danh sach cu ----
    STATE["hits"].clear(); STATE["pages"].clear(); STATE["page_mode"][1] = "empty"
    app_reset(work)
    r = run_crawler(work, "J1"); cp = read_cp(work, "J1"); report("lan3 (trang 1 rong)", cp, f"exit={r.returncode}")
    total, which = chapter_hits()
    check("lan 3: van du 43 chuong (danh sach cu duoc giu), khong mo chuong nao, remoteDone", cp.get("remoteDone") and len(cp["chaptersSoFar"]) == 43 and not which, (summarize(cp), which))
    check("lan 3: nhat ky co 'Trang 1 rong'", "Trang 1 rong" in r.stdout, r.stdout[-600:])
    STATE["page_mode"].clear()
    # ---- lan 4: chen chuong GIUA danh sach — quet nhanh KHONG thay (gioi han da biet), tat listFastScan thi thay ----
    STATE["ids"].insert(22, 101); STATE["hits"].clear(); STATE["pages"].clear()
    app_reset(work)
    r = run_crawler(work, "J1"); cp = read_cp(work, "J1"); total, which = chapter_hits()
    check("lan 4 (chen giua, quet nhanh): KHONG thay chuong 101 — gioi han da biet cua che do nhanh", len(cp["chaptersSoFar"]) == 43 and "101" not in which, (summarize(cp), which))
    STATE["hits"].clear(); STATE["pages"].clear()
    json.dump(spec(base, "pg", {"listPageUrlPattern": "{base}?page={page}", "maxPages": 30, "incrementalUpdate": True, "listFastScan": False}), open(jobp, "w"))
    sh(["git", "add", "-A"], cwd=work); sh(["git", "commit", "-m", "spec nofast"], cwd=work); sh(["git", "push"], cwd=work)
    app_reset(work)
    r = run_crawler(work, "J1"); cp = read_cp(work, "J1"); total, which = chapter_hits()
    links = [u.rsplit("/", 1)[1] for u in cp["chapterLinks"]]
    check("lan 5 (tat listFastScan, quet day du): bat duoc chuong 101 dung vi tri giua, chi mo chuong do", len(cp["chaptersSoFar"]) == 44 and links[22] == "101" and which == ["101"] and sorted(STATE["pages"]) == list(range(1, 11)), (len(cp["chaptersSoFar"]), links[20:25], which, sorted(STATE["pages"])))

def run_multi_skip_scenarios(scn, work, jobp, base):
    STATE["chapters"] = 6
    extra = {"chapterNextPageSelector": ".next", "maxChapterPages": 10}
    if scn == "multi_max": extra["maxChapterPages"] = 2
    if scn in ("skip", "skip_inc"):
        extra = {"skipIfTextContains": ["Bi Khoa"], "minTextLength": 60, "incrementalUpdate": scn == "skip_inc"}
        STATE["locked"] = {3}; STATE["short"] = {6}
    json.dump(spec(base, "multi", extra), open(jobp, "w"))
    r = run_crawler(work, "J1"); cp = read_cp(work, "J1")
    report(f"{scn} lan1", cp, f"exit={r.returncode}")
    if cp is None: check("co checkpoint", False, r.stderr[-600:]); return
    t = texts(cp)
    if scn == "multi":
        check("6 chuong, khong nuot chuong khac", len(cp["chaptersSoFar"]) == 6, len(cp["chaptersSoFar"]))
        check("chuong 1 KHONG chua noi dung chuong 2 (nut Tiep tro sang chuong khac)", "TRANG1-CUA-2" not in t["1"], t["1"][-80:])
        check("chuong 2 gop du 3 trang", all(f"TRANG{k}-CUA-2" in t["2"] for k in (1, 2, 3)), t["2"][-120:])
        check("chuong 4 gop 2 trang roi dung (vong lap)", "TRANG2-CUA-4" in t["4"] and t["4"].count("TRANG1-CUA-4") == 1, t["4"][-120:])
        check("chuong 5 khong lap vo han (nut Tiep tro ve chinh no)", t["5"].count("TRANG1-CUA-5") == 1)
        check("tieu de lay o trang 1", cp["chaptersSoFar"][1]["title"] == "Chuong 2", cp["chaptersSoFar"][1]["title"])
        check("index lien tuc 1..6", indexes_of(cp) == [1, 2, 3, 4, 5, 6], indexes_of(cp))
    if scn == "multi_max":
        check("maxChapterPages=2: chuong 2 chi co trang 1-2", "TRANG2-CUA-2" in t["2"] and "TRANG3-CUA-2" not in t["2"], t["2"][-120:])
    if scn in ("skip", "skip_inc"):
        check("chuong bi khoa (3) va chuong ngan (6) bi bo qua => 4 chuong", len(cp["chaptersSoFar"]) == 4 and "3" not in t and "6" not in t, sorted(t))
        check("khong ton so thu tu: index 1..4", indexes_of(cp) == [1, 2, 3, 4], indexes_of(cp))
        check("skippedCount=2, crawledCount=6", cp.get("skippedCount") == 2 and cp.get("crawledCount") == 6, (cp.get("skippedCount"), cp.get("crawledCount")))
        check("remoteDone", cp.get("remoteDone") is True)
    if scn == "skip_inc":
        STATE["hits"].clear(); STATE["locked"] = set(); STATE["chapters"] = 7        # site mo khoa chuong 3, them chuong 7; chuong 6 van ngan
        r = run_crawler(work, "J1"); cp = read_cp(work, "J1")
        report("skip_inc lan2 (mo khoa chuong 3, them chuong 7)", cp, f"exit={r.returncode}")
        t = texts(cp)
        total, which = chapter_hits()
        check("lan 2: chuong 3 vao ebook, chuong 6 van bi bo qua => 6 chuong", len(cp["chaptersSoFar"]) == 6 and "3" in t and "6" not in t, sorted(t))
        check("lan 2: chi mo lai 3 (da bi bo qua), 6 (van bi bo qua), 7 (moi) - khong mo chuong cu", set(k for k in which if k.isdigit()) == {"3", "6", "7"}, which)
        check("lan 2: index duy nhat", len(set(indexes_of(cp))) == len(indexes_of(cp)), indexes_of(cp))
        check("lan 2: reusedCount=4 (1,2,4,5)", cp.get("reusedCount") == 4, cp.get("reusedCount"))

if __name__ == "__main__":
    srv, port = start_server()
    base = f"http://127.0.0.1:{port}"
    root = tempfile.mkdtemp(prefix="e2e_")
    work = setup_repo(root)
    jobp = os.path.join(work, "remote-jobs", "J1.json")
    try:
        if SCENARIO in ("static", "js", "lazy", "lazy_on"):
            kind = "lazy" if SCENARIO.startswith("lazy") else SCENARIO
            extra = {"simulateScrollForLazyLoad": True, "maxScrollAttempts": 6} if SCENARIO == "lazy_on" else {}
            json.dump(spec(base, kind, extra), open(jobp, "w")); 
            t0 = time.time(); r = run_crawler(work, "J1")
            print(f"[{SCENARIO}] exit={r.returncode} {time.time()-t0:.0f}s ->", summarize(read_cp(work, "J1")))
            if r.returncode != 0: print(r.stdout[-1500:], r.stderr[-1500:])
        elif SCENARIO == "rerun":       # chạy lần 1 (5 chương), site thêm 3 chương, chạy lần 2 CÙNG job id y như app làm
            json.dump(spec(base, "static"), open(jobp, "w"))
            run_crawler(work, "J1"); print("[lan1]", summarize(read_cp(work, "J1")))
            STATE["chapters"] = 8
            r = run_crawler(work, "J1"); print("[lan2, site co 8 chuong]", summarize(read_cp(work, "J1")))
            print(r.stdout[-600:])
        elif SCENARIO == "rerun_reset":  # như rerun, nhưng giữa 2 lần app GHI ĐÈ checkpoint cũ bằng bản rỗng do chính Kotlin CrawlCheckpoint.toJson() sinh ra (fix 7.101)
            json.dump(spec(base, "static"), open(jobp, "w"))
            run_crawler(work, "J1"); print("[lan1]", summarize(read_cp(work, "J1")))
            STATE["chapters"] = 8
            reset = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "reset_cp.json"), encoding="utf-8").read()
            open(os.path.join(work, "remote-jobs", "J1-checkpoint.json"), "w", encoding="utf-8").write(reset)
            sh(["git", "add", "-A"], cwd=work); sh(["git", "commit", "-m", "reset"], cwd=work); sh(["git", "push"], cwd=work)
            r = run_crawler(work, "J1"); print("[lan2 sau reset, site co 8 chuong]", summarize(read_cp(work, "J1")))
        elif SCENARIO in ("app_fresh", "app_fresh_noinc"):
            # Mô phỏng ĐÚNG những gì app 7.103 làm trên repo ở một lần chạy mới (RemoteCrawlRunner.prepareFreshRemoteRun):
            #   job bật "chỉ cào chương mới": ghi NGUYÊN checkpoint xong của lần trước vào `-archive.json`, rồi ghi đè checkpoint bằng bản RỖNG do Kotlin CrawlCheckpoint.toJson() sinh ra;
            #   job không bật: chỉ đặt lại checkpoint rỗng. Runner KHÔNG cần biết quy ước "checkpoint xong = lần trước".
            inc = SCENARIO == "app_fresh"
            json.dump(spec(base, "static", {"incrementalUpdate": inc}), open(jobp, "w"))
            r = run_crawler(work, "J1"); report("lan1 (site 5)", read_cp(work, "J1"), f"exit={r.returncode}")
            STATE["hits"].clear(); STATE["chapters"] = 8
            cpf = os.path.join(work, "remote-jobs", "J1-checkpoint.json")
            if inc: open(os.path.join(work, "remote-jobs", "J1-archive.json"), "w", encoding="utf-8").write(open(cpf, encoding="utf-8").read())
            open(cpf, "w", encoding="utf-8").write(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "reset_cp.json"), encoding="utf-8").read())
            sh(["git", "add", "-A"], cwd=work); sh(["git", "commit", "-m", "app reset"], cwd=work); sh(["git", "push"], cwd=work)
            r = run_crawler(work, "J1"); cp = read_cp(work, "J1")
            report("lan2 (site 8, app da dat lai checkpoint)", cp, f"exit={r.returncode} archive_con_lai={archive_exists(work)}")
            total, which = chapter_hits()
            check("lan 2 xong, du 8 chuong", r.returncode == 0 and cp and cp.get("remoteDone") and len(cp["chaptersSoFar"]) == 8, summarize(cp))
            check("index 1..8 duy nhat, lien tuc", indexes_of(cp) == list(range(1, 9)), indexes_of(cp))
            check("runnerVersion co mat", bool(cp.get("runnerVersion")), cp.get("runnerVersion"))
            check("kho -archive.json duoc xoa sau khi xong", not archive_exists(work))
            if inc:
                check("chi mo 3 chuong MOI (6,7,8), dung lai 5 chuong cu", which == ["6", "7", "8"] and cp.get("reusedCount") == 5 and cp.get("crawledCount") == 3, (which, cp.get("reusedCount"), cp.get("crawledCount")))
            else:
                check("khong bat incremental: cao lai du 8 chuong, dung lai 0", total >= 8 and cp.get("reusedCount") == 0, (total, cp.get("reusedCount")))
            if FAILS: print("FAILED:", FAILS); sys.exit(1)
            print("ALL OK")
        elif SCENARIO.startswith("inc_") or SCENARIO == "noinc_rerun":
            run_incremental_scenarios(SCENARIO, work, jobp, base)
            if FAILS: print("FAILED:", FAILS); sys.exit(1)
        elif SCENARIO == "fast_scan":
            run_fast_scan_scenario(work, jobp, base)
            if FAILS: print("FAILED:", FAILS); sys.exit(1)
            print("ALL OK")
        elif SCENARIO in ("multi", "multi_max", "skip", "skip_inc"):
            run_multi_skip_scenarios(SCENARIO, work, jobp, base)
            if FAILS: print("FAILED:", FAILS); sys.exit(1)
            print("ALL OK")
        else:
            print("kich ban la"); sys.exit(2)
    finally:
        shutil.rmtree(root, ignore_errors=True)
