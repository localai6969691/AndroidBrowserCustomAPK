package com.colablive.keeper.features.ebookleech.engine

import com.colablive.keeper.features.ebookleech.model.LeechChapter
import java.util.concurrent.ConcurrentHashMap

/**
 * ChapterCache — giữ danh sách LeechChapter đã cào xong TRONG RAM, dùng khi
 * job.manualTocReview=true: crawler dừng lại SAU Phase 2, KHÔNG tự xuất
 * ngay, để người dùng mở màn hình "Sắp xếp mục lục" (TocEditorDialog) chỉnh
 * sửa/gộp/loại chương rồi mới bấm Xuất.
 *
 * CHỦ ĐỘNG KHÔNG PERSIST xuống đĩa — nếu app bị kill giữa lúc đang chờ
 * review, dữ liệu cào mất, phải cào lại. Đây là đánh đổi chấp nhận được vì
 * bước review thường diễn ra ngay sau khi cào xong trong cùng phiên; ghi rõ
 * trong PROJECT_STATUS để không ai nhầm là đã persist.
 */
object ChapterCache {
    private val cache = ConcurrentHashMap<String, List<LeechChapter>>()

    private fun key(slotIndex: Int, jobId: String) = "$slotIndex:$jobId"

    fun put(slotIndex: Int, jobId: String, chapters: List<LeechChapter>) {
        cache[key(slotIndex, jobId)] = chapters
    }

    fun get(slotIndex: Int, jobId: String): List<LeechChapter>? = cache[key(slotIndex, jobId)]

    fun clear(slotIndex: Int, jobId: String) {
        cache.remove(key(slotIndex, jobId))
    }
}
