package com.colablive.keeper.features.ebookleech.engine

import com.colablive.keeper.core.GeckoViewEngine
import org.json.JSONObject

/**
 * ElementPickerBridge — BẢN SỬA sau khi đọc source thật.
 *
 * Bản trước dùng `GeckoSession.evaluateJS()` trực tiếp trên 1 session lấy
 * qua reflection (VisibleSessionAccessor, giờ đã XOÁ) — không cần nữa: vì
 * `engine.evaluateJs()` (API public đã có sẵn) LUÔN nhắm đúng tab đang
 * active — mà "tab đang active" CHÍNH LÀ tab người dùng đang nhìn thấy khi
 * họ bấm nút "🎯 Chọn trên trang". Dùng thẳng API đó, không cần
 * VisibleSessionAccessor, không cần GeckoSession trực tiếp ở tầng addon.
 *
 * Kết quả qua evaluateJs bọc "OK: "/"LOI: " (xem GeckoViewEngineExt.kt) —
 * dùng chung logic bóc tách qua hàm public unwrapForPicker() bên dưới.
 */
object ElementPickerBridge {

    fun startPicking(engine: GeckoViewEngine, mode: String, onError: (String) -> Unit) {
        engine.evaluateJs(buildPickerInjectJs(mode)) { raw ->
            val parsed = unwrap(raw)
            if (parsed == null || parsed.second) onError(parsed?.first ?: "Không tiêm được picker (không có phản hồi)")
        }
    }

    fun confirmPick(engine: GeckoViewEngine, onResult: (selector: String?, matchCount: Int) -> Unit) {
        engine.evaluateJs(
            "JSON.stringify(window.__ebookLeechPicker ? window.__ebookLeechPicker.getSelected() : null)"
        ) { raw ->
            val parsed = unwrap(raw)
            if (parsed == null || parsed.second) { onResult(null, 0); return@evaluateJs }
            try {
                val json = JSONObject(parsed.first)
                onResult(json.optString("selector", null), json.optInt("count", 0))
            } catch (e: Exception) {
                onResult(null, 0)  // "null" (chưa chọn gì) parse JSONObject sẽ ném lỗi ở đây — coi là chưa chọn
            }
        }
    }

    fun stopPicking(engine: GeckoViewEngine) {
        engine.evaluateJs("window.__ebookLeechPicker && window.__ebookLeechPicker.stop();", null)
    }

    /** @return (giá trị, isError) hoặc null nếu không có phản hồi */
    private fun unwrap(raw: String?): Pair<String, Boolean>? {
        if (raw == null) return null
        return when {
            raw.startsWith("OK: ") -> raw.removePrefix("OK: ") to false
            raw == "OK" -> "{}" to false
            raw.startsWith("LOI: ") -> raw.removePrefix("LOI: ") to true
            else -> raw to false
        }
    }

    // -------------------------------------------------------------------------
    // JS overlay — GIỮ NGUYÊN thuật toán tự sinh selector từ bản trước (không
    // liên quan tới lớp sai kiến trúc phía trên — phần leo cây DOM + test
    // querySelectorAll vẫn đúng, chỉ đổi CÁCH GỌI, không đổi NỘI DUNG JS).
    // -------------------------------------------------------------------------

    private fun buildPickerInjectJs(mode: String): String = """
        (function() {
            if (window.__ebookLeechPicker) { window.__ebookLeechPicker.stop(); }

            var MODE = '$mode';
            var overlay, tooltip, confirmBar;
            var selected = null;

            function computeSelector(el, preferMany) {
                if (!preferMany && el.id) return { selector: '#' + CSS.escape(el.id), count: 1 };
                var parts = [];
                var node = el;
                var best = null;
                while (node && node.nodeType === 1 && parts.length < 5) {
                    var part = node.tagName.toLowerCase();
                    if (node.className && typeof node.className === 'string') {
                        var cls = node.className.trim().split(/\s+/).filter(Boolean).slice(0, 2);
                        if (cls.length) part += '.' + cls.map(function(c){ return CSS.escape(c); }).join('.');
                    }
                    parts.unshift(part);
                    var candidate = parts.join(' ');
                    try {
                        var matches = document.querySelectorAll(candidate);
                        var count = matches.length;
                        if (preferMany) {
                            if (count >= 2 && count <= 2000) { best = { selector: candidate, count: count }; break; }
                        } else {
                            if (count === 1) { best = { selector: candidate, count: count }; break; }
                            if (count >= 1 && count <= 5 && !best) best = { selector: candidate, count: count };
                        }
                    } catch (e) {}
                    node = node.parentElement;
                }
                return best || { selector: parts.join(' '), count: 0 };
            }

            function injectStyles() {
                var style = document.createElement('style');
                style.id = '__ebookLeechPickerStyle';
                style.textContent =
                    '.__ebook-leech-hl{outline:2px solid #2563eb!important;background:rgba(37,99,235,0.15)!important;cursor:crosshair!important;}' +
                    '#__ebookLeechTooltip{position:fixed;z-index:2147483647;background:#111827;color:#fff;font:12px/1.4 sans-serif;' +
                    'padding:4px 8px;border-radius:4px;pointer-events:none;max-width:80vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}' +
                    '#__ebookLeechConfirmBar{position:fixed;left:0;right:0;bottom:0;z-index:2147483647;background:#111827;color:#fff;' +
                    'font:13px/1.4 sans-serif;padding:10px 14px;display:flex;align-items:center;gap:8px;box-shadow:0 -2px 8px rgba(0,0,0,.3);}' +
                    '#__ebookLeechConfirmBar button{font:13px sans-serif;padding:6px 12px;border-radius:4px;border:none;color:#fff;}' +
                    '#__ebookLeechConfirmBar .retry{background:#6b7280;}';
                document.head.appendChild(style);
            }

            function onMouseOver(e) {
                var el = e.target;
                if (el.closest('#__ebookLeechConfirmBar')) return;
                document.querySelectorAll('.__ebook-leech-hl').forEach(function(x){ x.classList.remove('__ebook-leech-hl'); });
                el.classList.add('__ebook-leech-hl');
                var res = computeSelector(el, MODE === 'list');
                if (!tooltip) {
                    tooltip = document.createElement('div');
                    tooltip.id = '__ebookLeechTooltip';
                    document.body.appendChild(tooltip);
                }
                tooltip.textContent = res.selector + '  (' + res.count + ' phần tử khớp)';
                tooltip.style.left = (e.clientX + 12) + 'px';
                tooltip.style.top = (e.clientY + 12) + 'px';
            }

            function onClick(e) {
                if (e.target.closest('#__ebookLeechConfirmBar')) return;
                e.preventDefault();
                e.stopPropagation();
                var res = computeSelector(e.target, MODE === 'list');
                selected = res;
                showConfirmBar(res);
            }

            function showConfirmBar(res) {
                if (!confirmBar) {
                    confirmBar = document.createElement('div');
                    confirmBar.id = '__ebookLeechConfirmBar';
                    document.body.appendChild(confirmBar);
                }
                confirmBar.innerHTML = '';
                var label = document.createElement('span');
                label.style.flex = '1';
                label.style.overflow = 'hidden';
                label.style.textOverflow = 'ellipsis';
                label.style.whiteSpace = 'nowrap';
                label.textContent = 'Đã chọn: ' + res.selector + ' — ' + res.count + ' phần tử. Bấm "Xác nhận" bên dưới app.';
                var retryBtn = document.createElement('button');
                retryBtn.className = 'retry';
                retryBtn.textContent = 'Chọn lại';
                retryBtn.onclick = function() {
                    selected = null;
                    confirmBar.remove(); confirmBar = null;
                    document.querySelectorAll('.__ebook-leech-hl').forEach(function(x){ x.classList.remove('__ebook-leech-hl'); });
                };
                confirmBar.appendChild(label);
                confirmBar.appendChild(retryBtn);
            }

            function stop() {
                document.removeEventListener('mouseover', onMouseOver, true);
                document.removeEventListener('click', onClick, true);
                document.querySelectorAll('.__ebook-leech-hl').forEach(function(x){ x.classList.remove('__ebook-leech-hl'); });
                if (tooltip) { tooltip.remove(); tooltip = null; }
                if (confirmBar) { confirmBar.remove(); confirmBar = null; }
                var st = document.getElementById('__ebookLeechPickerStyle');
                if (st) st.remove();
                window.__ebookLeechPicker = null;
            }

            injectStyles();
            document.addEventListener('mouseover', onMouseOver, true);
            document.addEventListener('click', onClick, true);

            window.__ebookLeechPicker = { getSelected: function() { return selected; }, stop: stop };

            return JSON.stringify({ started: true });
        })();
    """.trimIndent()
}
