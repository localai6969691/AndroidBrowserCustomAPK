package com.colablive.keeper.features.downloads

import android.content.Context
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.DebugLog
import org.json.JSONArray
import org.json.JSONObject

/**
 * Quản lý chính sách download theo domain.
 * Các chế độ:
 * - ASK: Hỏi trước khi tải (mặc định cho trang lạ)
 * - ALLOW: Tự động tải (cho trang tin cậy như Colab)
 * - BLOCK: Chặn hoàn toàn (cho trang độc hại)
 * - ALLOW_ALL: Tự động tải tất cả (nguy hiểm)
 */
class DownloadPolicy(private val context: Context) {

    enum class Policy {
        ASK,      // Hỏi trước khi tải
        ALLOW,    // Tự động tải
        BLOCK,    // Chặn hoàn toàn
        ALLOW_ALL // Tự động tải tất cả (không khuyến khích)
    }

    data class DomainRule(
        val domain: String,
        val policy: Policy,
        val description: String
    )

    // Rules mặc định
    private val defaultRules = listOf(
        DomainRule("colab.research.google.com", Policy.ALLOW, "Google Colab — cho phép tự động tải"),
        DomainRule("drive.google.com", Policy.ALLOW, "Google Drive — cho phép tự động tải"),
        DomainRule("github.com", Policy.ASK, "GitHub — hỏi trước khi tải"),
        DomainRule("", Policy.ASK, "Mặc định — hỏi trước khi tải")
    )

    /**
     * Kiểm tra policy cho URL.
     * Trả về: true = cho phép tải, false = chặn, null = cần hỏi user
     */
    fun checkPolicy(url: String): Boolean? {
        val domain = extractDomain(url).lowercase()
        val globalPolicy = getGlobalPolicy()

        // Nếu global = ALLOW_ALL → cho phép tất cả
        if (globalPolicy == Policy.ALLOW_ALL) {
            DebugLog.log("Download policy: ALLOW_ALL — $url")
            return true
        }
        // Mục 163: trước đây lựa chọn "Chặn TẤT CẢ download" được lưu nhưng KHÔNG BAO GIỜ được áp dụng (chỉ ALLOW_ALL được kiểm tra).
        if (globalPolicy == Policy.BLOCK) {
            DebugLog.log("Download policy: BLOCK toàn cục — $url")
            return false
        }

        // Mục 163: khớp domain ĐÚNG (bằng nhau hoặc là tên miền con có dấu chấm), chọn rule cụ thể nhất. Trước đây dùng `domain.contains(rule)`
        // nên host như "drive.google.com.evil.com" cũng khớp rule "drive.google.com" (tự động tải!).
        val all = getRules()
        val rule = all.filter { it.domain.isNotEmpty() && (domain == it.domain || domain.endsWith("." + it.domain)) }.maxByOrNull { it.domain.length }
            ?: all.find { it.domain.isEmpty() } // rule mặc định

        return when (rule?.policy) {
            Policy.ALLOW -> {
                DebugLog.log("Download policy: ALLOW — $domain")
                true
            }
            Policy.BLOCK -> {
                DebugLog.log("Download policy: BLOCK — $domain")
                false
            }
            else -> {
                DebugLog.log("Download policy: ASK — $domain")
                null // Cần hỏi user
            }
        }
    }

    /**
     * Thêm hoặc SỬA rule (ghi đè rule cùng domain, kể cả rule mặc định). Domain "" = rule mặc định cho mọi trang không có rule riêng.
     */
    fun addRule(domain: String, policy: Policy) {
        // Mục 163: thêm lại domain mặc định từng bị xoá thì bỏ nó khỏi danh sách "đã xoá".
        if (domain.isNotEmpty()) setRemovedDefaults(removedDefaults() - domain)
        val rules = getRules().toMutableList()
        rules.removeAll { it.domain == domain }
        rules.add(DomainRule(domain, policy, "Ngoại lệ của bạn — " + policyLabel(policy)))
        saveRules(rules)
    }

    /**
     * Xóa rule. Rule mặc định (github.com, drive.google.com...) cũng xoá được: ghi vào danh sách "đã xoá" để không tự hiện lại.
     * Rule mặc định chung (domain "") KHÔNG xoá được — chỉ sửa chính sách của nó.
     */
    fun removeRule(domain: String) {
        if (domain.isEmpty()) return
        val rules = getRules().toMutableList()
        rules.removeAll { it.domain == domain }
        saveRules(rules)
        if (defaultRules.any { it.domain == domain }) setRemovedDefaults(removedDefaults() + domain)
    }

    /** Xoá hết ngoại lệ tuỳ chỉnh và khôi phục các rule mặc định đã bị xoá/sửa. Chính sách toàn cục không đổi. */
    fun resetRules() {
        AppPrefs.setString(context, 0, "download_custom_rules", "[]")
        setRemovedDefaults(emptySet())
    }

    private fun policyLabel(p: Policy) = when (p) {
        Policy.ALLOW -> "cho phép tự động tải"
        Policy.BLOCK -> "chặn tải"
        else -> "hỏi trước khi tải"
    }

    private fun removedDefaults(): Set<String> = try {
        val arr = JSONArray(AppPrefs.getString(context, 0, "download_removed_default_rules", "[]"))
        (0 until arr.length()).map { arr.getString(it) }.toSet()
    } catch (e: Exception) { emptySet() }

    private fun setRemovedDefaults(set: Set<String>) {
        val arr = JSONArray(); set.forEach { arr.put(it) }
        AppPrefs.setString(context, 0, "download_removed_default_rules", arr.toString())
    }

    companion object {
        /** Chuẩn hoá chuỗi người dùng gõ (URL hoặc domain) thành domain; null nếu không hợp lệ. "www." và "*." ở đầu bị bỏ (khớp luôn cả tên miền con). */
        fun normalizeDomain(input: String): String? {
            var d = input.trim().lowercase().removePrefix("https://").removePrefix("http://")
            d = d.substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':')
            d = d.removePrefix("*.").removePrefix("www.")
            if (d.isEmpty() || d.length > 253 || !d.contains('.') || d.startsWith('.') || d.endsWith('.') || d.contains("..")) return null
            if (d.any { !(it in 'a'..'z' || it in '0'..'9' || it == '.' || it == '-') }) return null
            return d
        }
    }

    /**
     * Lấy global policy.
     */
    fun getGlobalPolicy(): Policy {
        val policyStr = AppPrefs.getString(context, 0, "download_global_policy", "ASK")
        return try {
            Policy.valueOf(policyStr)
        } catch (e: Exception) {
            Policy.ASK
        }
    }

    /**
     * Set global policy.
     */
    fun setGlobalPolicy(policy: Policy) {
        AppPrefs.setString(context, 0, "download_global_policy", policy.name)
    }

    /**
     * FIX BUG THẬT (phát hiện qua audit code, không phải người dùng báo):
     * `getRules()` trước đây LUÔN trả về `defaultRules` hardcode, HOÀN
     * TOÀN bỏ qua rule người dùng tự thêm — vì `saveRules()` (gọi từ
     * `addRule()`/`removeRule()`) là hàm RỖNG (TODO bỏ trống), không ghi
     * gì cả. Hệ quả: bấm "Thêm rule" cho 1 domain tưởng đã lưu, nhưng ngay
     * sau khi tải lại app (hoặc gọi `getRules()` lần tiếp theo), rule đó
     * biến mất — im lặng, không có thông báo lỗi nào.
     *
     * Sửa: lưu rule TUỲ CHỈNH (khác với `defaultRules` cứng) vào
     * `AppPrefs` dạng JSON, slot 0 (global — khớp đúng cách
     * `getGlobalPolicy()`/`setGlobalPolicy()` đã dùng slot 0 sẵn).
     * `getRules()` giờ MERGE: rule tuỳ chỉnh ưu tiên hơn (ghi đè) rule mặc
     * định cùng domain — đúng ý định gốc của `addRule()` (đã có sẵn logic
     * `removeAll { it.domain == domain }` trước khi add, chỉ là trước đây
     * kết quả không bao giờ được đọc lại).
     */
    fun getRules(): List<DomainRule> {
        val customRules = loadCustomRules()
        val customDomains = customRules.map { it.domain }.toSet()
        val removed = removedDefaults()
        val mergedDefaults = defaultRules.filter { it.domain !in customDomains && (it.domain.isEmpty() || it.domain !in removed) }
        return customRules + mergedDefaults
    }

    private fun loadCustomRules(): List<DomainRule> {
        val json = AppPrefs.getString(context, 0, "download_custom_rules", "[]")
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                DomainRule(
                    domain = obj.getString("domain"),
                    policy = Policy.valueOf(obj.getString("policy")),
                    description = obj.optString("description", "Custom rule")
                )
            }
        } catch (e: Exception) {
            DebugLog.log("DownloadPolicy: lỗi đọc custom rules đã lưu (${e.message}) — dùng danh sách rỗng")
            emptyList()
        }
    }

    private fun saveRules(rules: List<DomainRule>) {
        // Chỉ lưu rule KHÁC với defaultRules (đúng ý nghĩa "tuỳ chỉnh") —
        // rules truyền vào đây là TOÀN BỘ danh sách hiện có (custom cũ +
        // default), không phải chỉ phần mới thêm.
        val defaultDomains = defaultRules.map { it.domain }.toSet()
        val customOnly = rules.filter { it.domain !in defaultDomains || it.policy != defaultRules.find { d -> d.domain == it.domain }?.policy }
        val arr = JSONArray()
        customOnly.forEach { rule ->
            arr.put(JSONObject().apply {
                put("domain", rule.domain)
                put("policy", rule.policy.name)
                put("description", rule.description)
            })
        }
        AppPrefs.setString(context, 0, "download_custom_rules", arr.toString())
    }

    private fun extractDomain(url: String): String {
        return try {
            val uri = java.net.URI(url)
            uri.host ?: ""
        } catch (e: Exception) {
            ""
        }
    }
}
