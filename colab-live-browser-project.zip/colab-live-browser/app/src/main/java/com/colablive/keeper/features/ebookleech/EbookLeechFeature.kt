package com.colablive.keeper.features.ebookleech

import android.content.Context
import android.view.View
import com.colablive.keeper.core.BrowserFeature
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.features.ebookleech.service.EbookLeechServiceLogic
import com.colablive.keeper.features.ebookleech.service.EbookLeechSlotRegistry
import com.colablive.keeper.features.ebookleech.service.EbookLeechWorkScheduler
import com.colablive.keeper.features.ebookleech.ui.EbookLeechSettingsView

/**
 * EbookLeechFeature — Addon cào dữ liệu → ebook, tương tự KDN Auto Leech nhưng
 * chạy hoàn toàn trong GeckoView browser.
 *
 * Cơ chế chạy nền: khi bật ở slot N → khởi động EbookLeechService CỦA KHE N (foreground, ở tiến trình của khe, tự lặp mỗi 30s — xem ghi chú
 * trong file đó) + đăng ký WorkManager làm lưới an toàn. Tắt slot N → dừng service khe N; tắt ở TẤT CẢ slot → hủy luôn WorkManager.
 */
object EbookLeechFeature : BrowserFeature {

    override val id = "ebook_leech"
    override val displayName = "Ebook Leech"
    override val description =
        "Tự động cào nội dung trang web thành ebook EPUB/TXT — tương tự KDN Auto Leech"

    private const val PREF_ENABLED = "ebook_leech_enabled"

    /** Bản 7.98: cào bằng tab GeckoView thật của khe + tiến độ trong RAM => màn hình cài đặt/service phải ở tiến trình của khe (xem BrowserFeature.needsSlotProcess). */
    override val needsSlotProcess: Boolean get() = true

    override fun isEnabled(context: Context, slotIndex: Int): Boolean =
        AppPrefs.getBoolean(context, slotIndex, id, PREF_ENABLED, false)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {
        AppPrefs.setBoolean(context, slotIndex, id, PREF_ENABLED, enabled)

        if (enabled) {
            EbookLeechSlotRegistry.addSlot(context, slotIndex)
            EbookLeechServiceLogic.ensureStarted(context, slotIndex)
            EbookLeechWorkScheduler.schedule(context)
        } else {
            EbookLeechSlotRegistry.removeSlot(context, slotIndex)
            EbookLeechScheduler.cancelAllForSlot(context, slotIndex)
            // 7.98: service là THEO KHE — tắt khe nào thì dừng service của khe đó (trước đây chỉ dừng khi TẤT CẢ khe tắt).
            EbookLeechServiceLogic.stop(context, slotIndex)
            if (!EbookLeechSlotRegistry.hasAnyEnabledSlot(context)) {
                EbookLeechWorkScheduler.cancel(context)
            }
        }
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View =
        EbookLeechSettingsView(context, slotIndex)

    // KHÔNG override onPageFinished/onTick — chữ ký thật của BrowserFeature
    // (đọc từ source thật) là onPageFinished(context, slotIndex, engine,
    // url) / onTick(context, slotIndex, engine, url), CHỈ được gọi cho
    // trang khớp matchesUrl() — cơ chế này dành cho feature theo-dõi-1-URL-
    // cụ thể (như ColabLiveKeeperFeature theo dõi colab.research.google.com),
    // KHÔNG phù hợp cho 1 job scheduler chạy nền độc lập với trang đang mở.
    // EbookLeech dùng EbookLeechService (Handler tự lặp) làm vòng lặp chính
    // — xem service/EbookLeechService.kt — không cần móc vào cơ chế này.
}
