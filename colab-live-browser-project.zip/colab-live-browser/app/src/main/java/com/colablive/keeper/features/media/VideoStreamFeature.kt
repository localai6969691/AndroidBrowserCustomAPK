package com.colablive.keeper.features.media

import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature

/**
 * Mục 160: gom MỌI tuỳ chọn xem video/stream vào 1 màn hình cài đặt (theo từng khe).
 *  - Tự động phát video CÓ TIẾNG: mặc định TẮT (yêu cầu người dùng). Video tự phát KHÔNG tiếng (muted) luôn được phép — giống Chrome.
 *  - Tua dự phòng cho nút tua trên thông báo + số giây mỗi lần tua.
 *  - Picture-in-Picture khi rời app lúc đang xem video toàn màn hình.
 *  - Giữ màn hình sáng / tràn tai thỏ khi video toàn màn hình.
 * "Phát media nền" (chống trang tự tạm dừng) vẫn là tiện ích riêng ở BackgroundMediaFeature.
 */
object VideoStreamFeature : BrowserFeature {
    override val id = "video_stream"
    override val displayName = "🎬 Xem video / Stream"
    override val description =
        "Tuỳ chọn khi xem video: tự động phát, nút tua trên thông báo, Picture-in-Picture, " +
        "giữ màn hình sáng và tràn tai thỏ khi toàn màn hình. Áp dụng riêng cho từng khe."

    // Tiện ích này luôn "bật" (chỉ là nơi chứa tuỳ chọn); từng tuỳ chọn có công tắc riêng.
    override fun isEnabled(context: Context, slotIndex: Int) = true
    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) {}

    const val MIN_STEP = 5
    const val MAX_STEP = 60

    fun autoplayAudible(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, id, "autoplay_audible", false) // MẶC ĐỊNH TẮT
    fun seekFallback(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, id, "seek_fallback", true)
    fun drmEnabled(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, id, "drm", true)
    fun seekForceApp(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, id, "seek_force_app", false)
    fun seekStepSec(c: Context, slot: Int) = AppPrefs.getInt(c, slot, id, "seek_step_sec", 10).coerceIn(MIN_STEP, MAX_STEP)
    fun pipEnabled(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, id, "pip", true)
    fun keepScreenOnFullscreen(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, id, "keep_screen_on", true)
    fun cutoutFullscreen(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, id, "cutout", true)

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val pad = (16 * context.resources.displayMetrics.density).toInt()
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun note(text: String) = TextView(context).apply {
            this.text = text; textSize = 12f; setTextColor(Color.GRAY)
            setPadding(0, 0, 0, pad / 2)
        }
        fun sw(title: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(context).apply {
            text = title; isChecked = checked
            setPadding(0, pad / 2, 0, pad / 4)
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }

        root.addView(TextView(context).apply { text = description })

        root.addView(sw("Cho phép tự động phát video CÓ TIẾNG", autoplayAudible(context, slotIndex)) {
            AppPrefs.setBoolean(context, slotIndex, id, "autoplay_audible", it)
        })
        root.addView(note(
            "Mặc định TẮT: video có tiếng chỉ phát khi bạn chạm vào. Video tự phát không tiếng vẫn được phép. " +
            "Cần tải lại trang để có hiệu lực. Lưu ý: một số trang (như YouTube bản máy tính ở khe dùng chế độ desktop) " +
            "có thể cần bạn chạm nút phát; nếu video cứ quay vòng không chạy, hãy bật tuỳ chọn này."
        ))

        root.addView(sw("Nút tua trên thông báo luôn tua được (dự phòng)", seekFallback(context, slotIndex)) {
            AppPrefs.setBoolean(context, slotIndex, id, "seek_fallback", it)
        })
        root.addView(note("Trang không hỗ trợ lệnh tua thì app tự tua trực tiếp video/audio ở khung chính của trang."))

        val stepLabel = TextView(context).apply { setPadding(0, pad / 4, 0, 0) }
        fun renderStep(v: Int) { stepLabel.text = "Mỗi lần tua: $v giây" }
        val cur = seekStepSec(context, slotIndex)
        renderStep(cur)
        root.addView(stepLabel)
        root.addView(SeekBar(context).apply {
            max = MAX_STEP - MIN_STEP
            progress = cur - MIN_STEP
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { renderStep(p + MIN_STEP) }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    AppPrefs.setInt(context, slotIndex, id, "seek_step_sec", (sb?.progress ?: 5) + MIN_STEP)
                }
            })
        })
        root.addView(note("Mặc định chỉ áp dụng khi app tự tua dự phòng. Với trang tự xử lý lệnh tua, số giây do CODE CỦA TRANG quyết định " +
            "(Chrome cũng vậy: trình duyệt không áp được số giây của riêng nó lên trang)."))
        root.addView(sw("Luôn dùng số giây của app (bỏ qua số giây của trang)", seekForceApp(context, slotIndex)) {
            AppPrefs.setBoolean(context, slotIndex, id, "seek_force_app", it)
        })
        root.addView(note("Bật thì nút tua trên thông báo tua thẳng vào video/audio theo số giây ở trên, không gửi cho trang. " +
            "Áp dụng được cho mọi trang, nhưng trình phát tuỳ biến có thể không biết mình vừa bị tua nên vài trường hợp giao diện cập nhật chậm."))

        root.addView(sw("Cho phép video có bản quyền (DRM / Widevine)", drmEnabled(context, slotIndex)) {
            AppPrefs.setBoolean(context, slotIndex, id, "drm", it)
        })
        root.addView(note("GeckoView giao quyết định DRM cho app; tắt thì Netflix/Disney+... không phát. " +
            "Có chạy được hay không còn phụ thuộc bản GeckoView và máy có mô-đun Widevine; xem Debug Log dòng [DRM]. Cần tải lại trang."))

        root.addView(sw("Picture-in-Picture khi rời app", pipEnabled(context, slotIndex)) {
            AppPrefs.setBoolean(context, slotIndex, id, "pip", it)
        })
        root.addView(note("Đang xem video toàn màn hình và video đang phát, bấm Home/chuyển app thì thu nhỏ thành cửa sổ nổi."))

        root.addView(sw("Giữ màn hình sáng khi video toàn màn hình", keepScreenOnFullscreen(context, slotIndex)) {
            AppPrefs.setBoolean(context, slotIndex, id, "keep_screen_on", it)
        })
        root.addView(sw("Tràn cả vùng tai thỏ khi toàn màn hình", cutoutFullscreen(context, slotIndex)) {
            AppPrefs.setBoolean(context, slotIndex, id, "cutout", it)
        })
        root.addView(note("Có hiệu lực ở lần vào toàn màn hình kế tiếp."))

        return ScrollView(context).apply { addView(root) }
    }
}
