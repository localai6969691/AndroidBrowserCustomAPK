package com.colablive.keeper.core

import android.app.Service
import android.content.Intent

/**
 * PHÁT HIỆN QUAN TRỌNG khi rà lại kiến trúc plugin: Android chỉ có thể khởi
 * tạo `Service`/`Worker` từ đúng class đã KHAI BÁO TRONG MANIFEST + NẰM
 * SẴN trong dex của APK đã cài — hệ thống (PackageManager/WorkManager) khởi
 * tạo các component này bằng ClassLoader GỐC của app, KHÔNG BIẾT GÌ về
 * `DexClassLoader` mà `PluginLoader` tự tạo để nạp `.jar` plugin lúc chạy.
 *
 * → 1 `class XxxService : Service()` sống trong `:ebookleech` (build ra
 * `.jar`, KHÔNG merge vào APK) SẼ KHÔNG BAO GIỜ khởi động được qua
 * `startForegroundService(Intent(context, XxxService::class.java))` — ném
 * `ClassNotFoundException`/service không tồn tại theo góc nhìn hệ thống.
 *
 * GIẢI PHÁP (mẫu chuẩn của các framework plugin Android — "proxy
 * component"): 1 Service THẬT, biên dịch cứng vào `:core` (nên nằm sẵn
 * trong APK, có khai trong `AndroidManifest.xml`) — `PluginForegroundServiceProxy`
 * — đóng vai "vỏ" cố định. Logic THẬT của plugin (vd EbookLeechServiceLogic)
 * chỉ cần implement interface NÀY (không extend `Service` trực tiếp nữa) —
 * proxy tìm đúng instance qua `PluginLoader.findPluginClass()` (dùng lại
 * `DexClassLoader` đã nạp sẵn) rồi chuyển tiếp mọi lời gọi vòng đời sang.
 *
 * `host` = chính instance `PluginForegroundServiceProxy` đang chạy — dùng
 * để gọi `startForeground()`/`getSystemService()`/`stopSelf()` v.v (những
 * hàm chỉ gọi được trên 1 `Service` context thật).
 */
interface PluginServiceLogic {
    fun onCreate(host: Service)
    fun onStartCommand(host: Service, intent: Intent?, flags: Int, startId: Int): Int
    fun onDestroy(host: Service)
}
