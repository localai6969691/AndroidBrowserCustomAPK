package com.colablive.keeper.features.ebookleech.engine

import android.content.Context
import com.colablive.keeper.core.GeckoViewEngine
import com.colablive.keeper.features.ebookleech.model.ChapterArchiveRepository
import com.colablive.keeper.features.ebookleech.model.LeechJob
import org.json.JSONObject

/**
 * SelectorTester — "THỬ TRƯỚC KHI CÀO" (bản 7.100, học từ công cụ kiểm thử site của KDN Auto Leech; xem PROJECT_STATUS mục 224).
 *
 * Mở một tab crawl riêng, chạy ĐÚNG hai script mà crawler dùng ([EbookLeechCrawler.collectLinksJs]/[EbookLeechCrawler.extractChapterJs]) trên trang danh sách rồi
 * trên chương ĐẦU TIÊN, và báo cáo bằng chữ: bao nhiêu link khớp, link đầu/cuối, selector tiêu đề/nội dung có khớp phần tử thật không (script cào thật lặng lẽ rơi về
 * `document.title`/`body` khi không khớp nên nhìn kết quả cuối không biết), độ dài nội dung, đoạn đầu nội dung, chương này có bị luật "bỏ qua" bắt không, có link trang kế không.
 * KHÔNG ghi gì vào kho/ebook/job. Mục đích: thấy selector sai NGAY thay vì cào cả truyện rồi mới biết (đúng nỗi đau "sửa mù").
 *
 * GIỚI HẠN trung thực: chỉ thử trang danh sách TRANG 1 và chương đầu tiên (không bảo đảm mọi chương/mọi trang giống nhau); job dùng AJAX Leech (ajaxListMode/ajaxContentMode)
 * thì phần tương ứng bị bỏ qua; job có "bước phụ" (preListStages) thì thử thẳng URL danh sách đã nhập — nếu trang chứa link chương ở sau các bước phụ, kết quả sẽ rỗng.
 * Chưa chạy trên máy thật.
 */
object SelectorTester {

    fun run(context: Context, slotIndex: Int, engine: GeckoViewEngine, job: LeechJob, onStep: (String) -> Unit, onDone: (String) -> Unit) {
        val report = StringBuilder()
        val previousTabId = engine.getActiveTab()?.id
        val tab = engine.createTab(url = "about:blank", isPrivate = !job.useLoginSession)
        val tabId = tab.id
        var finished = false

        fun finish() {
            if (finished) return
            finished = true
            try {
                engine.closeTab(tabId)
                if (previousTabId != null && engine.getTabs().any { it.id == previousTabId }) engine.switchToTab(previousTabId)
            } catch (e: Exception) { /* tab có thể đã đóng */ }
            onDone(report.toString().trimEnd())
        }

        fun line(s: String) { report.append(s).append('\n') }

        fun testChapter(chapterUrl: String) {
            onStep("Đang mở chương đầu để thử selector tiêu đề/nội dung…")
            engine.evaluateJsOnTab(
                crawlTabId = tabId, url = chapterUrl,
                js = EbookLeechCrawler.extractChapterJs(job.chapterTitleSelector, job.chapterContentSelector, job.chapterNextPageSelector),
                // Giống lúc cào thật (bản 7.101): job bật "cuộn lazy-load" thì cuộn sau khi trang tải, trước khi lấy nội dung.
                timeoutMs = 15_000L + (if (job.simulateScrollForLazyLoad) job.maxScrollAttempts.coerceIn(1, 20) * 2_000L else 0L),
                scrollAttempts = if (job.simulateScrollForLazyLoad) job.maxScrollAttempts.coerceIn(1, 20) else 0,
                onResult = { raw ->
                    try {
                        val j = JSONObject(raw)
                        if (j.optBoolean("blocked", false)) {
                            line("✗ CHƯƠNG: trang bị chặn xác minh (${j.optString("blockReason", "?")}). Cần giải tay trên tab (xem Cloudflare/captcha) — selector chưa thử được.")
                        } else {
                            val title = j.optString("title", "")
                            val text = j.optString("text", "")
                            val html = j.optString("html", "")
                            val tm = j.optBoolean("tm", false)
                            val cm = j.optBoolean("cm", false)
                            line(if (tm) "✓ Selector tiêu đề KHỚP → \"${title.take(80)}\""
                                 else "✗ Selector tiêu đề KHÔNG khớp phần tử nào (đang rơi về tiêu đề tab: \"${title.take(60)}\")")
                            line(if (cm) "✓ Selector nội dung KHỚP → ${text.length} ký tự text, ${html.length} ký tự HTML"
                                 else "✗ Selector nội dung KHÔNG khớp phần tử nào (đang rơi về TOÀN BỘ body: ${text.length} ký tự — sẽ lẫn menu/quảng cáo)")
                            val preview = text.replace(Regex("\\s+"), " ").trim()
                            line("   Đầu nội dung: \"${preview.take(220)}${if (preview.length > 220) "…" else ""}\"")
                            val processed = ContentProcessor.apply(title, html, text, job.regexRules)
                            if (job.regexRules.isNotEmpty())
                                line("   Sau ${job.regexRules.count { it.enabled }} luật tìm & thay: ${processed.text.length} ký tự text" +
                                    (if (processed.errors.isNotEmpty()) " — luật lỗi: ${processed.errors.joinToString("; ")}" else ""))
                            val skip = EbookLeechCrawler.skipReason(job, text, processed.text)
                            line(if (skip != null) "⚠ Chương này SẼ BỊ BỎ QUA khi cào thật: $skip"
                                 else "✓ Chương này sẽ được giữ (không dính điều kiện bỏ qua)")
                            if (job.chapterNextPageSelector.isNotBlank()) {
                                val next = j.optString("next", "")
                                line(if (next.isNotBlank()) "✓ Link trang kế tìm thấy: $next (tối đa ${job.maxChapterPages} trang/chương)"
                                     else "— Không có link trang kế ở chương này (bình thường nếu chương chỉ 1 trang; nếu chương thật có nhiều trang thì selector trang kế sai)")
                            }
                        }
                    } catch (e: Exception) {
                        line("✗ CHƯƠNG: kết quả không đọc được (${e.message}) — raw: ${raw.take(160)}")
                    }
                    finish()
                },
                onError = { reason -> line("✗ CHƯƠNG: không mở/lấy được $chapterUrl — $reason"); finish() },
            )
        }

        if (job.ajaxListMode) {
            line("— Job dùng AJAX Leech cho danh sách chương: công cụ thử chưa hỗ trợ phần này.")
            finish()
            return
        }
        if (job.preListStages.isNotEmpty())
            line("ℹ Job có ${job.preListStages.size} bước phụ — đang thử thẳng URL danh sách đã nhập; nếu link chương nằm sau các bước phụ thì kết quả có thể rỗng.")
        val archived = if (job.incrementalUpdate) ChapterArchiveRepository.count(context, slotIndex, job.id) else -1
        if (archived >= 0) line("ℹ Cập nhật tăng dần BẬT — kho hiện có $archived chương đã lưu.")

        onStep("Đang mở trang danh sách…")
        engine.evaluateJsOnTab(
            crawlTabId = tabId, url = job.listPageUrl,
            js = EbookLeechCrawler.collectLinksJs(job.chapterLinkSelector, job.chapterLinkAttribute),
            onResult = { raw ->
                try {
                    val arr = JSONObject(raw).optJSONArray("links")
                    val links = if (arr == null) emptyList() else (0 until arr.length()).map { arr.getString(it).trim() }.filter { it.isNotEmpty() }
                    if (links.isEmpty()) {
                        line("✗ DANH SÁCH: selector link \"${job.chapterLinkSelector}\" KHÔNG khớp link nào trên ${job.listPageUrl}")
                        line("   Có thể: selector sai, nội dung render muộn (thử bật tự cuộn lazy-load), trang bị chặn, hoặc link chương nằm ở trang/bước khác.")
                        finish()
                    } else {
                        val unique = links.distinct().size
                        line("✓ DANH SÁCH: ${links.size} link khớp (${unique} khác nhau) trên trang 1")
                        line("   Đầu: ${links.first()}")
                        if (links.size > 1) line("   Cuối: ${links.last()}")
                        if (job.ajaxContentMode) {
                            line("— Job dùng AJAX Leech cho nội dung chương: bỏ qua bước thử chương.")
                            finish()
                        } else {
                            testChapter(links.first())
                        }
                    }
                } catch (e: Exception) {
                    line("✗ DANH SÁCH: kết quả không đọc được (${e.message}) — raw: ${raw.take(160)}")
                    finish()
                }
            },
            onError = { reason -> line("✗ DANH SÁCH: không mở/lấy được ${job.listPageUrl} — $reason"); finish() },
        )
    }
}
