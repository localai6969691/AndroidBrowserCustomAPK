package com.colablive.keeper.features.ebookleech.model

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Bản 7.104 — nơi lưu thông tin truyện + ảnh bìa theo từng job (key = job.id), để mọi đường xuất (cào tại máy, cào từ xa, xuất sau khi sắp xếp mục lục) đều lấy được
 * mà không phải đổi chữ ký các hàm xuất. Ghi bởi crawler cục bộ và RemoteCrawlRunner; đọc bởi EbookExporter; xoá khi xoá job.
 *
 * Bố cục: <filesDir>/ebookleech_story/<jobId>.json (StoryMeta) + <jobId>.cover (bytes ảnh bìa, đuôi suy ra từ meta.coverMime/coverFile).
 */
object StoryMetaStore {
    class Stored(val meta: StoryMeta, val cover: LeechImage?)

    private fun dir(context: Context): File = File(context.filesDir, "ebookleech_story").apply { if (!exists()) mkdirs() }
    private fun metaFile(context: Context, jobId: String) = File(dir(context), "$jobId.json")
    private fun coverFile(context: Context, jobId: String) = File(dir(context), "$jobId.cover")

    fun extensionFor(mime: String, nameOrUrl: String): String {
        val m = mime.lowercase()
        return when {
            m.contains("jpeg") || m.contains("jpg") -> "jpg"
            m.contains("png") -> "png"
            m.contains("webp") -> "webp"
            m.contains("gif") -> "gif"
            else -> nameOrUrl.substringAfterLast('.', "").substringBefore('?').lowercase().takeIf { it in listOf("jpg", "jpeg", "png", "webp", "gif") } ?: "jpg"
        }
    }

    /** JSON dùng để SO SÁNH "thông tin có đổi không": bỏ `fetchedAt` (đổi mỗi lần lấy dù nội dung y hệt). */
    internal fun comparableJson(meta: StoryMeta): String = meta.toJson().also { it.remove("fetchedAt") }.toString()

    /**
     * Lưu thông tin + bìa (bytes null/rỗng = giữ bìa cũ nếu có). Ghi qua file tạm để không để lại file dở; lỗi ghi không làm hỏng lần cào.
     * Trả true nếu NỘI DUNG khác bản đang lưu (thông tin đổi hoặc có bìa mới) — để chế độ cập nhật tăng dần biết phải xuất lại ebook dù không có chương mới.
     */
    fun save(context: Context, jobId: String, meta: StoryMeta, coverBytes: ByteArray?, coverMime: String = meta.coverMime): Boolean {
        try {
            val before = load(context, jobId)
            var m = meta
            if (coverBytes != null && coverBytes.isNotEmpty()) {
                val ext = extensionFor(coverMime, m.coverUrl.ifBlank { m.coverFile })
                m = m.copy(coverFile = "cover.$ext", coverMime = coverMime.ifBlank { "image/jpeg" })
                coverFile(context, jobId).writeBytes(coverBytes)
            } else if (!coverFile(context, jobId).exists()) {
                m = m.copy(coverFile = "", coverMime = "")
            }
            val tmp = File(dir(context), "$jobId.json.tmp")
            tmp.writeText(m.toJson().toString(), Charsets.UTF_8)
            if (!tmp.renameTo(metaFile(context, jobId))) { metaFile(context, jobId).writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8); tmp.delete() }
            val coverChanged = coverBytes != null && coverBytes.isNotEmpty() && (before?.cover == null || !before.cover.bytes.contentEquals(coverBytes))
            return if (before == null) (!m.isBlank() || m.coverFile.isNotBlank()) else (coverChanged || comparableJson(before.meta) != comparableJson(m))
        } catch (e: Exception) { /* thông tin truyện là phần phụ — không được làm hỏng lần cào */ return false }
    }

    fun load(context: Context, jobId: String): Stored? {
        val f = metaFile(context, jobId)
        if (!f.exists()) return null
        return try {
            val meta = StoryMeta.fromJson(JSONObject(f.readText(Charsets.UTF_8)))
            val cf = coverFile(context, jobId)
            val cover = if (cf.exists() && meta.coverFile.isNotBlank()) LeechImage(meta.coverUrl, meta.coverFile, meta.coverMime.ifBlank { "image/jpeg" }, cf.readBytes()) else null
            Stored(meta, cover)
        } catch (e: Exception) { null }
    }

    fun delete(context: Context, jobId: String) {
        try { metaFile(context, jobId).delete(); coverFile(context, jobId).delete() } catch (e: Exception) { }
    }
}
