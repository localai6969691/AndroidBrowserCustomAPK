package com.colablive.keeper

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.Spannable
import android.text.SpannableString
import android.text.TextWatcher
import android.text.format.DateUtils
import android.text.style.BackgroundColorSpan
import android.text.style.StyleSpan
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.BrowserHistory
import com.colablive.keeper.core.HistorySearch
import com.colablive.keeper.core.ProfileSlots

/**
 * Màn hình lịch sử duyệt web của một khe, có TÌM KIẾM NÂNG CAO (mục 107):
 *  - ô tìm kiếm với cú pháp: từ khoá (không phân biệt dấu), "cụm chính xác", -loại trừ, site:, title:, url:, after:, before:, last: (xem nút ?);
 *  - bộ lọc nhanh: khoảng thời gian, phạm vi (tiêu đề/URL), sắp xếp (mới nhất / cũ nhất / nhiều lượt nhất), gộp theo trang;
 *  - tô sáng từ khớp, đếm kết quả, và "Xoá các kết quả" hàng loạt.
 * Chạm một mục: trả `open_url` cho MainActivity mở như cũ; nhấn giữ: xoá một mục.
 */
class HistoryActivity : AppCompatActivity() {

    private var slotIndex = 0
    private lateinit var listLayout: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var countLabel: TextView
    private lateinit var deleteResultsBtn: Button
    private lateinit var rangeBtn: Button
    private lateinit var scopeBtn: Button
    private lateinit var sortBtn: Button
    private lateinit var groupBtn: Button

    private var displayLimit = 300
    private var allEntries: List<BrowserHistory.Entry> = emptyList()
    private var result: HistorySearch.Result? = null

    private var scope = HistorySearch.Scope.BOTH
    private var range = HistorySearch.Range.ALL
    private var sort = HistorySearch.Sort.NEWEST
    private var groupBySite = false

    private val handler = Handler(Looper.getMainLooper())
    private var pendingSearch: Runnable? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        slotIndex = intent.getIntExtra("slot_index", 0)
        buildUi()
        reload()
    }

    // ---------------------------------------------------------------- giao diện (dựng MỘT lần)
    private fun chip(onClick: () -> Unit) = Button(this).apply {
        isAllCaps = false
        textSize = 12f
        minHeight = 0; minimumHeight = 0
        setPadding(dp(10), dp(4), dp(10), dp(4))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36)).apply { rightMargin = dp(6) }
    }

    private fun buildUi() {
        val pad = dp(12)

        searchBox = EditText(this).apply {
            hint = "Tìm trong lịch sử…  vd: mat khau site:google.com -youtube last:7d"
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            textSize = 15f
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    // chờ 250ms sau lần gõ cuối rồi mới lọc (tránh lọc lại sau từng phím)
                    pendingSearch?.let { handler.removeCallbacks(it) }
                    val r = Runnable { applySearch() }
                    pendingSearch = r
                    handler.postDelayed(r, 250L)
                }
            })
        }
        val helpBtn = Button(this).apply {
            text = "?"
            setOnClickListener { showHelp() }
        }
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(pad, dp(4), pad, 0)
            addView(searchBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(helpBtn, LinearLayout.LayoutParams(dp(48), LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        rangeBtn = chip {
            val all = HistorySearch.Range.values()
            range = all[(range.ordinal + 1) % all.size]
            applySearch()
        }
        scopeBtn = chip {
            val all = HistorySearch.Scope.values()
            scope = all[(scope.ordinal + 1) % all.size]
            applySearch()
        }
        sortBtn = chip {
            val all = HistorySearch.Sort.values()
            sort = all[(sort.ordinal + 1) % all.size]
            applySearch()
        }
        groupBtn = chip {
            groupBySite = !groupBySite
            applySearch()
        }
        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(pad, dp(6), pad, dp(2))
            addView(rangeBtn); addView(scopeBtn); addView(sortBtn); addView(groupBtn)
        }
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }

        countLabel = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(pad, dp(4), pad, 0)
        }

        deleteResultsBtn = Button(this).apply {
            isAllCaps = false
            setOnClickListener { confirmDeleteResults() }
        }
        val clearButton = Button(this).apply {
            isAllCaps = false
            text = "🗑 Xoá toàn bộ lịch sử"
            setOnClickListener { confirmClear() }
        }
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(deleteResultsBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(clearButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }

        listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@HistoryActivity).apply {
                text = "Lịch sử — Khe $slotIndex (${ProfileSlots.getSlotAssignmentDisplay(this@HistoryActivity, slotIndex)})"
                textSize = 13f
                setTextColor(Color.GRAY)
                setPadding(pad, pad, pad, 0)
            })
            addView(searchRow)
            addView(chipScroll)
            addView(countLabel)
            addView(actionRow)
            addView(
                ScrollView(this@HistoryActivity).apply { addView(listLayout) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(root)
    }

    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle("Cú pháp tìm kiếm")
            .setMessage(
                "Các thành phần cách nhau bằng dấu cách, TẤT CẢ phải khớp.\n\n" +
                "• từ khoá — khớp tiêu đề hoặc URL, KHÔNG phân biệt hoa/thường và dấu (mat khau = Mật khẩu)\n" +
                "• \"cụm chính xác\" — khớp nguyên cụm\n" +
                "• -từ hoặc -\"cụm\" — loại trừ\n" +
                "• site:example.com — chỉ miền đó (gồm miền con); nhiều site: là HOẶC; -site:x để loại\n" +
                "• title:abc / url:abc — chỉ tìm trong tiêu đề / URL; -title:abc, -url:abc để loại\n" +
                "• after:2026-09-01 và before:2026-09-30 — khoảng ngày (cũng nhận 01/09/2026)\n" +
                "• last:24h, last:7d, last:2w, last:3m — gần đây (giờ, ngày, tuần, tháng)\n\n" +
                "Ví dụ: colab site:google.com last:7d -drive\n\n" +
                "Các nút bên dưới ô tìm: khoảng thời gian, phạm vi tìm, sắp xếp, gộp theo trang. " +
                "Nút “Xoá … lượt khớp” xoá đúng các mục đang hiện."
            )
            .setPositiveButton("Đã hiểu", null)
            .show()
    }

    // ---------------------------------------------------------------- dữ liệu
    private fun reload() {
        allEntries = BrowserHistory.readEntries(this, slotIndex)
        applySearch()
    }

    private fun filtering(): Boolean = searchBox.text.toString().isNotBlank() || range != HistorySearch.Range.ALL

    private fun applySearch() {
        displayLimit = 300
        result = HistorySearch.search(allEntries, searchBox.text.toString(), scope, range, sort)
        rangeBtn.text = "📅 ${range.label}"
        scopeBtn.text = "🔎 ${scope.label}"
        sortBtn.text = "↕ ${sort.label}"
        groupBtn.text = if (groupBySite) "☑ Theo trang" else "☐ Theo trang"
        buildRows()
    }

    private fun highlighted(text: String, terms: List<String>): CharSequence {
        val ranges = HistorySearch.highlightRanges(text, terms)
        if (ranges.isEmpty()) return text
        val sp = SpannableString(text)
        for (r in ranges) {
            val st = r.first.coerceIn(0, text.length)
            val en = (r.last + 1).coerceIn(st, text.length)
            if (en <= st) continue
            sp.setSpan(BackgroundColorSpan(0x66FFEB3B), st, en, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sp.setSpan(StyleSpan(Typeface.BOLD), st, en, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sp
    }

    private fun buildRows() {
        listLayout.removeAllViews()
        val res = result ?: return

        countLabel.text = when {
            allEntries.isEmpty() -> ""
            filtering() -> "${res.visitsMatched} lượt khớp / ${allEntries.size} lượt" +
                (if (sort == HistorySearch.Sort.MOST_VISITED) " • ${res.rows.size} trang" else "")
            else -> "${allEntries.size} lượt" + (if (sort == HistorySearch.Sort.MOST_VISITED) " • ${res.rows.size} trang" else "")
        }
        if (filtering() && res.visitsMatched > 0) {
            deleteResultsBtn.visibility = android.view.View.VISIBLE
            deleteResultsBtn.text = "🗑 Xoá ${res.visitsMatched} lượt khớp"
        } else {
            deleteResultsBtn.visibility = android.view.View.GONE
        }

        if (allEntries.isEmpty()) {
            listLayout.addView(TextView(this).apply { text = "Chưa có lịch sử nào."; setPadding(0, dp(24), 0, 0) })
            return
        }
        if (res.rows.isEmpty()) {
            listLayout.addView(TextView(this).apply {
                text = "Không có kết quả khớp.\nBấm nút ? để xem cú pháp tìm kiếm."
                setPadding(0, dp(24), 0, 0)
            })
            return
        }

        val terms = res.query.highlightTerms
        val shown = res.rows.take(displayLimit)
        if (groupBySite) {
            // gộp theo miền, giữ thứ tự theo lần xuất hiện đầu tiên (miền có lượt gần nhất/đầu bảng đứng trước)
            val groups = LinkedHashMap<String, MutableList<HistorySearch.Row>>()
            for (row in shown) groups.getOrPut(HistorySearch.siteOf(row.entry.url)) { ArrayList() }.add(row)
            for ((host, rows) in groups) {
                listLayout.addView(TextView(this).apply {
                    text = "$host  —  ${rows.sumOf { it.count }} lượt"
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.DKGRAY)
                    setBackgroundColor(0xFFEEEEEE.toInt())
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                })
                rows.forEach { addRow(it, terms) }
            }
        } else {
            shown.forEach { addRow(it, terms) }
        }
        if (res.rows.size > displayLimit) {
            listLayout.addView(Button(this).apply {
                text = "Xem thêm (còn ${res.rows.size - displayLimit} mục)"
                setOnClickListener {
                    displayLimit += 300
                    buildRows()
                }
            })
        }
    }

    private fun addRow(row: HistorySearch.Row, terms: List<String>) {
        val entry = row.entry
        val ripple = android.util.TypedValue().also {
            theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
        }.resourceId
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            isClickable = true
            isFocusable = true
            setBackgroundResource(ripple)
            setOnClickListener {
                setResult(RESULT_OK, Intent().putExtra("open_url", entry.url))
                finish()
            }
            setOnLongClickListener {
                confirmDeleteOne(entry)
                true
            }
        }
        view.addView(TextView(this).apply {
            text = highlighted(entry.title.ifBlank { entry.url }, terms)
            textSize = 15f
            setTextColor(Color.BLACK)
            maxLines = 1
        })
        view.addView(TextView(this).apply {
            text = highlighted(entry.url, terms)
            textSize = 12f
            setTextColor(Color.GRAY)
            maxLines = 1
        })
        view.addView(TextView(this).apply {
            val whenText = DateUtils.getRelativeTimeSpanString(entry.time).toString()
            text = if (row.count > 1) "$whenText  •  ${row.count} lượt" else whenText
            textSize = 11f
            setTextColor(Color.LTGRAY)
        })
        listLayout.addView(view)
    }

    // ---------------------------------------------------------------- xoá
    private fun confirmDeleteResults() {
        val res = result ?: return
        if (res.visitsMatched == 0) return
        AlertDialog.Builder(this)
            .setTitle("Xoá các kết quả đang hiện?")
            .setMessage("Sẽ xoá ${res.visitsMatched} lượt truy cập khớp bộ lọc hiện tại. Không thể hoàn tác.")
            .setPositiveButton("Xoá") { _, _ ->
                val n = BrowserHistory.deleteEntries(this, slotIndex, res.matchedKeys.toSet())
                Toast.makeText(this, "Đã xoá $n lượt", Toast.LENGTH_SHORT).show()
                reload()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun confirmDeleteOne(entry: BrowserHistory.Entry) {
        AlertDialog.Builder(this)
            .setMessage("Xoá mục lịch sử này?\n${entry.title.ifBlank { entry.url }}")
            .setPositiveButton("Xoá") { _, _ ->
                BrowserHistory.deleteEntry(this, slotIndex, entry.url, entry.time)
                Toast.makeText(this, "Đã xoá", Toast.LENGTH_SHORT).show()
                reload()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("Xoá toàn bộ lịch sử?")
            .setMessage("Không thể hoàn tác.")
            .setPositiveButton("Xoá hết") { _, _ ->
                BrowserHistory.clear(this, slotIndex)
                Toast.makeText(this, "Đã xoá lịch sử", Toast.LENGTH_SHORT).show()
                reload()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    override fun onDestroy() {
        pendingSearch?.let { handler.removeCallbacks(it) }
        super.onDestroy()
    }
}
