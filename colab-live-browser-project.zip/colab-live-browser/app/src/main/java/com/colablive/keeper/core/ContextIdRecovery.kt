package com.colablive.keeper.core

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File

/**
 * Mục 121: tìm lại "container" (contextId) đang giữ cookie đăng nhập của hồ sơ.
 *
 * GeckoView KHÔNG lưu contextId trong containers.json: chuỗi contextId của phiên được đổi thành `gvctx<hex byte>` và gắn vào
 * `originAttributes` của MỌI cookie/storage (`^geckoViewUserContextId=gvctx...`, xem OriginAttributes::CreateSuffix, bug 1501108). Cookie
 * lưu dưới contextId X mà phiên chạy bằng contextId Y thì Gecko coi là hai kho khác nhau => "bị văng đăng nhập" dù cookies.sqlite còn nguyên.
 * App dùng contextId = "profile_" + nội dung file `.context_id` (nếu thiếu thì lấy theo TÊN hồ sơ, xem ProfileSlots.getStableContextId).
 * Hồ sơ từng đổi tên / sao lưu từ bản cũ / import vào tên khác sẽ lệch => cookie nằm "kẹt" ở contextId cũ.
 *
 * Cách làm: TRƯỚC khi tạo GeckoRuntime (Gecko chưa mở cookies.sqlite), đọc bản sao của cookies.sqlite, thống kê cookie theo contextId, và nếu
 * contextId đang dùng KHÔNG có cookie nào mà một contextId khác có => ghi `.context_id` trỏ về contextId đó. Không bao giờ bỏ rơi một contextId
 * đang có dữ liệu.
 */
object ContextIdRecovery {
    private val RE = Regex("geckoViewUserContextId=gvctx([0-9a-fA-F]+)")

    private fun decode(hex: String): String? = try {
        val h = if (hex.length % 2 == 1) "0$hex" else hex
        val bytes = ByteArray(h.length / 2) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
        String(bytes, Charsets.UTF_8)
    } catch (e: Exception) { null }

    /** Trả chuỗi ghi vào `.context_id` nếu cần đổi; null nếu không cần/không xác định được. Luôn ghi log kết quả. */
    fun recover(context: Context, profileDir: File, currentContextId: String): String? {
        val cookies = File(profileDir, "cookies.sqlite")
        if (!cookies.isFile) {
            DebugLog.log("ContextIdRecovery: hồ sơ chưa có cookies.sqlite — không cần khớp contextId (hiện tại='$currentContextId')")
            return null
        }
        val tmp = File(context.cacheDir, "ctx_probe_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            // Sao chép CẢ BỘ WAL (cookies.sqlite + -wal + -shm) để đọc được cookie chưa checkpoint.
            listOf("cookies.sqlite", "cookies.sqlite-wal", "cookies.sqlite-shm").forEach { n ->
                val src = File(profileDir, n)
                if (src.isFile) src.copyTo(File(tmp, n), overwrite = true)
            }
            val db = SQLiteDatabase.openDatabase(File(tmp, "cookies.sqlite").absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            val stats = LinkedHashMap<String, IntArray>() // contextId -> [tổng, google]
            try {
                db.rawQuery(
                    "SELECT originAttributes, COUNT(*), SUM(CASE WHEN host LIKE '%google.com' OR host LIKE '%youtube.com' THEN 1 ELSE 0 END) " +
                        "FROM moz_cookies GROUP BY originAttributes", null
                ).use { c ->
                    while (c.moveToNext()) {
                        val attrs = c.getString(0) ?: ""
                        val m = RE.find(attrs)
                        val ctx = if (m != null) decode(m.groupValues[1]) ?: "?" else "(không có contextId)"
                        val arr = stats.getOrPut(ctx) { IntArray(2) }
                        arr[0] += c.getInt(1); arr[1] += c.getInt(2)
                    }
                }
            } finally { db.close() }
            DebugLog.log("ContextIdRecovery: contextId đang dùng='$currentContextId'; cookie theo contextId (tổng/google): " +
                stats.entries.joinToString(" ; ") { "'${it.key}'=${it.value[0]}/${it.value[1]}" })
            val cur = stats[currentContextId]
            if (cur != null && cur[0] > 0) return null // contextId hiện tại đã có dữ liệu — giữ nguyên
            val best = stats.entries
                .filter { it.key.startsWith("profile_") && it.value[0] > 0 }
                .maxWithOrNull(compareBy({ it.value[1] }, { it.value[0] }))
                ?: return null
            DebugLog.log("ContextIdRecovery: contextId '$currentContextId' KHÔNG có cookie nhưng '${best.key}' có ${best.value[0]} (google ${best.value[1]}) => chuyển sang '${best.key}' (khắc phục 'văng đăng nhập sau import/đổi tên')")
            return best.key.removePrefix("profile_")
        } catch (e: Throwable) {
            DebugLog.log("ContextIdRecovery: LỖI ${e.javaClass.simpleName}: ${e.message} — giữ contextId hiện tại")
            return null
        } finally {
            try { tmp.deleteRecursively() } catch (e: Throwable) {}
        }
    }
}
