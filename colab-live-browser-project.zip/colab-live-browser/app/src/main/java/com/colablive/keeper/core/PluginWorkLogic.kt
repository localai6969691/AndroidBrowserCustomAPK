package com.colablive.keeper.core

import android.content.Context

/**
 * Tương đương `PluginServiceLogic` nhưng cho `androidx.work.Worker` — cùng
 * lý do (Android/WorkManager chỉ khởi tạo được class có sẵn trong dex của
 * APK đã cài, không biết gì về `DexClassLoader` của plugin). Logic THẬT
 * (vd EbookLeechWorkLogic) implement interface này thay vì extend `Worker`
 * trực tiếp — `PluginWorker` (biên dịch cứng vào `:core`) là "vỏ" chung.
 */
interface PluginWorkLogic {
    /** `true` = coi như thành công (WorkManager `Result.success()`).
     * `false` = nên thử lại theo lịch retry mặc định (`Result.retry()`). */
    fun doWork(context: Context): Boolean
}
