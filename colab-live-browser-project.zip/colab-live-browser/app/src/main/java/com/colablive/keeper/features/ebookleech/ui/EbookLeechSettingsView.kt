package com.colablive.keeper.features.ebookleech.ui

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.content.FileProvider
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.FeatureRegistry
import com.colablive.keeper.core.FolderPickerBridge
import com.colablive.keeper.core.PluginLoader
import com.colablive.keeper.features.ebookleech.EbookLeechScheduler
import com.colablive.keeper.features.ebookleech.backup.EbookLeechBackupManager
import com.colablive.keeper.features.ebookleech.model.CrawlStage
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.model.LeechJobRepository
import com.colablive.keeper.features.ebookleech.model.LeechProject
import com.colablive.keeper.features.ebookleech.model.LeechProjectRepository
import com.colablive.keeper.features.ebookleech.model.RegexRule
import com.colablive.keeper.features.ebookleech.model.TocNode
import java.io.File

/**
 * Settings UI cho EbookLeechFeature.
 * Xây hoàn toàn bằng code (không cần layout XML) — nhất quán với các feature khác.
 *
 * Màn hình gồm 2 phần:
 *  A. Danh sách Job (scrollable) — mỗi job có: tên, trạng thái, tiến độ, nút hành động
 *  B. Nút "+ Thêm Job mới" → mở JobEditorDialog
 */
class EbookLeechSettingsView(
    private val ctx: Context,
    private val slotIndex: Int,
) : LinearLayout(ctx) {

    private val jobListLayout: LinearLayout
    private lateinit var proxyStatusText: TextView
    private lateinit var proxyPoolStatusText: TextView

    init {
        orientation = VERTICAL
        setPadding(dp(12), dp(8), dp(12), dp(16))

        // ── Header ──────────────────────────────────────────────────────────
        addView(TextView(ctx).apply {
            text = "📚 Ebook Leech"
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#1a1a1a"))
            setPadding(0, 0, 0, dp(4))
        })
        addView(TextView(ctx).apply {
            text = "Cấu hình job cào nội dung trang web → ebook EPUB/TXT/HTML"
            textSize = 13f
            setTextColor(Color.parseColor("#666666"))
            setPadding(0, 0, 0, dp(8))
        })

        // ── Hàng nút quản lý (Dự án / Sao lưu / Khôi phục) ──────────────────
        addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            setPadding(0, 0, 0, dp(10))
            addView(smallButton("🗂 Dự án", "#6b7280") { showProjectManagerDialog() })
            addView(smallButton("📤 Sao lưu", "#6b7280") { doBackup() })
            addView(smallButton("📥 Khôi phục", "#6b7280") { showRestoreDialog() })
        })

        // Bản 7.98 — chế độ NHÚNG: EbookLeech được biên dịch thẳng vào APK nên hàng nút "Nạp .jar mới / Nạp lại plugin" của bản plugin-jar bị GỠ khỏi giao diện:
        // DexClassLoader ưu tiên class đã có trong APK (parent-first), nên nạp .jar KHÔNG thay được mã đang chạy và toast "có hiệu lực ngay" sẽ nói sai.
        // (Hai hàm importPluginJar()/reloadPluginOnly() còn nguyên bên dưới để dùng lại nếu sau này tách module `:ebookleech`.)

        // ── ĐÃ THÊM — "Cào từ xa qua GitHub Actions": cấu hình DÙNG CHUNG
        // cho mọi job trong slot (xem GitHubRemoteConfig.kt). Bật/tắt CHO
        // TỪNG JOB nằm trong form tạo/sửa job (mục "Chạy ở đâu").
        addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            setPadding(0, 0, 0, dp(10))
            addView(smallButton("☁️ Cấu hình GitHub (cào từ xa)", "#6b7280") { showGitHubConfigDialog() })
        })

        // ── Trạng thái proxy của KHE này ─────────────────────────────────────
        // Cào EbookLeech chạy qua tab GeckoView THẬT của chính khe (eval_bridge),
        // nên TỰ ĐỘNG đi qua đúng proxy đã cấu hình cho khe đó (đăng ký lúc
        // GeckoRuntime tạo — GeckoRuntimeProvider.createRuntime() đọc
        // proxy_host/proxy_port/proxy_user/proxy_pass/proxy_type từ AppPrefs) —
        // KHÔNG cần EbookLeech tự implement proxy riêng. Chỉ cần hiện trạng
        // thái + cho đổi nhanh ngay tại đây (đỡ phải sang màn Cài đặt chính).
        proxyStatusText = TextView(ctx).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#666666"))
            setPadding(0, 0, 0, dp(4))
        }
        addView(proxyStatusText)
        addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            setPadding(0, 0, 0, dp(6))
            addView(smallButton("🌐 Tự tìm proxy mới cho khe này", "#0891b2") { autoFindProxyForSlot() })
        })
        // ĐÃ THÊM — "xoay nhiều proxy": xem giới hạn kiến trúc đầy đủ trong
        // ProxyPoolManager.kt (KHÔNG xoay được GIỮA CHỪNG 1 job đang chạy —
        // chỉ xoay được GIỮA CÁC LẦN job MỚI khởi động, có hiệu lực thật từ
        // lần khe khởi động lại kế tiếp).
        proxyPoolStatusText = TextView(ctx).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#666666"))
            setPadding(0, 0, 0, dp(4))
        }
        addView(proxyPoolStatusText)
        addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            setPadding(0, 0, 0, dp(10))
            addView(smallButton("🔁 Tìm 5 proxy dự phòng (xoay vòng)", "#0891b2") { buildProxyPool() })
            addView(smallButton("🗑 Xoá danh sách", "#6b7280") { clearProxyPool() })
        })
        refreshProxyStatus()
        refreshProxyPoolStatus()

        // ── Danh sách job ───────────────────────────────────────────────────
        jobListLayout = LinearLayout(ctx).apply { orientation = VERTICAL }
        addView(jobListLayout)

        // ── Nút thêm job ────────────────────────────────────────────────────
        addView(MaterialButton(ctx).apply {
            text = "+ Thêm Job mới"
            setBackgroundColor(Color.parseColor("#2563eb"))
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener { showJobEditor(null) }
        })

        refreshJobList()
    }

    // -------------------------------------------------------------------------
    // Danh sách job
    // -------------------------------------------------------------------------

    private fun refreshJobList() {
        jobListLayout.removeAllViews()
        val jobs = LeechJobRepository.loadAll(ctx, slotIndex)
        if (jobs.isEmpty()) {
            jobListLayout.addView(TextView(ctx).apply {
                text = "Chưa có job nào. Bấm \"+ Thêm Job mới\" để bắt đầu."
                textSize = 13f
                setTextColor(Color.parseColor("#888888"))
                setPadding(0, dp(8), 0, dp(16))
            })
            return
        }

        val projects = LeechProjectRepository.loadAll(ctx, slotIndex)
        val projectIds = projects.map { it.id }.toSet()
        val jobsByProject = jobs.groupBy { it.projectId }

        // Dự án có job → hiện theo đúng thứ tự tạo dự án trước
        projects.forEach { project ->
            val projectJobs = jobsByProject[project.id] ?: return@forEach
            jobListLayout.addView(buildProjectHeader(project, projectJobs.size))
            projectJobs.forEach { job -> jobListLayout.addView(buildJobCard(job)) }
        }

        // Job chưa phân nhóm HOẶC trỏ tới dự án đã bị xoá → nhóm "Chưa phân nhóm"
        val ungrouped = jobs.filter { it.projectId.isBlank() || it.projectId !in projectIds }
        if (ungrouped.isNotEmpty()) {
            jobListLayout.addView(buildProjectHeader(null, ungrouped.size))
            ungrouped.forEach { job -> jobListLayout.addView(buildJobCard(job)) }
        }
    }

    private fun buildProjectHeader(project: LeechProject?, jobCount: Int): View =
        LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(10), dp(2), dp(4))
            addView(View(ctx).apply {
                setBackgroundColor(Color.parseColor(project?.colorHex ?: "#9ca3af"))
                layoutParams = LinearLayout.LayoutParams(dp(4), dp(16)).apply { marginEnd = dp(8) }
            })
            addView(TextView(ctx).apply {
                text = "${project?.name ?: "Chưa phân nhóm"}  ($jobCount job)"
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#374151"))
            })
        }

    private fun buildJobCard(job: LeechJob): View {
        val card = LinearLayout(ctx).apply {
            orientation = VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.parseColor("#f0f4ff"))
            val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(10)
            layoutParams = lp
        }

        // Tên + trạng thái
        card.addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(ctx).apply {
                text = job.name
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#1a1a1a"))
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(TextView(ctx).apply {
                text = statusLabel(job.status)
                textSize = 12f
                setTextColor(statusColor(job.status))
                setPadding(dp(6), dp(2), dp(6), dp(2))
                setBackgroundColor(Color.parseColor("#e8eaf6"))
            })
        })

        // Thông tin tóm tắt
        val progressSuffix = if (job.status == LeechJob.JobStatus.RUNNING) {
            val snap = com.colablive.keeper.features.ebookleech.service.EbookLeechProgressStore
                .allActive().firstOrNull { it.jobName == job.name }
            if (snap != null && snap.total > 0) "  •  ${snap.percent}%" else ""
        } else ""
        card.addView(TextView(ctx).apply {
            text = "Format: ${job.outputFormat.name}  •  Lịch: ${scheduleSummary(job)}  •  Đã cào: ${job.chaptersCollected} chương$progressSuffix"
            textSize = 12f
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, dp(4), 0, dp(2))
        })
        val badges = mutableListOf<String>()
        if (job.downloadImages) badges.add("📷 Tải ảnh")
        if (job.regexRules.isNotEmpty()) badges.add("⚙ ${job.regexRules.size} luật")
        if (job.autoDetectPagination) badges.add("🔍 Auto phân trang")
        if (job.preListStages.isNotEmpty()) badges.add("🧭 ${job.preListStages.size} bước kịch bản")
        if (job.manualTocReview) badges.add("📑 Xem trước mục lục")
        if (job.useLoginSession) badges.add("🔐 Dùng đăng nhập")
        if (job.publishToWordPress) badges.add("📤 Đăng WordPress")
        if (job.simulateScrollForLazyLoad) badges.add("📜 Tự cuộn lazy-load")
        if (job.detectedAjaxEndpoints.isNotEmpty()) badges.add("📡 ${job.detectedAjaxEndpoints.size} AJAX")
        if (job.ajaxListMode || job.ajaxContentMode) badges.add("🔗 AJAX Leech")
        if (job.remoteBackend == "GITHUB") badges.add("☁️ Cào từ xa (GitHub)")
        if (job.remoteBackend == "COLAB") badges.add("📓 Cào từ xa (Colab)")
        if (badges.isNotEmpty()) {
            card.addView(TextView(ctx).apply {
                text = badges.joinToString("   ")
                textSize = 11f
                setTextColor(Color.parseColor("#2563eb"))
                setPadding(0, 0, 0, dp(6))
            })
        }

        // URL
        card.addView(TextView(ctx).apply {
            text = job.listPageUrl
            textSize = 11f
            setTextColor(Color.parseColor("#2563eb"))
            setPadding(0, 0, 0, dp(8))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })

        // ── Khối cảnh báo Cloudflare/captcha — chỉ hiện khi NEEDS_ACTION ──
        if (job.status == LeechJob.JobStatus.NEEDS_ACTION) {
            val isRemote = job.remoteBackend == "GITHUB"
            card.addView(LinearLayout(ctx).apply {
                orientation = VERTICAL
                setBackgroundColor(Color.parseColor("#fee2e2"))
                setPadding(dp(10), dp(8), dp(10), dp(8))
                val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(8)
                layoutParams = lp

                addView(TextView(ctx).apply {
                    text = "⚠️ Trang yêu cầu xác minh: ${job.pendingActionReason}"
                    textSize = 12f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#991b1b"))
                })

                if (isRemote) {
                    // ĐÃ THÊM — remote không có tab thật, hiện ảnh chụp màn
                    // hình Python gửi về (nếu tải được) thay cho "mở tab xem
                    // trực tiếp" như local.
                    if (job.pendingActionScreenshotPath.isNotEmpty() && File(job.pendingActionScreenshotPath).exists()) {
                        addView(android.widget.ImageView(ctx).apply {
                            setImageURI(Uri.fromFile(File(job.pendingActionScreenshotPath)))
                            adjustViewBounds = true
                            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(240)).apply { topMargin = dp(4); bottomMargin = dp(4) }
                        })
                    }
                    addView(TextView(ctx).apply {
                        // ĐÃ ĐỔI — trước đây chỉ có cách "mở URL trong trình
                        // duyệt CỦA BẠN rồi Chạy lại" (dispatch job MỚI, IP
                        // MỚI, thường phải giải lại captcha từ đầu — vô ích
                        // nếu site chặn theo IP). Giờ có cách tốt hơn: dùng
                        // khối "🖥️ Điều khiển trình duyệt từ xa" bên dưới để
                        // TỰ GIẢI NGAY trên phiên đang bị chặn (cùng IP, cùng
                        // cookie), rồi bấm nút xanh "Tiếp tục cào ngay" —
                        // không cần dispatch lại, không mất tiến trình.
                        text = "Dùng khối \"🖥️ Điều khiển trình duyệt từ xa\" bên dưới để xem màn hình và tự giải NGAY trên phiên đang chạy (Chụp màn hình → Click/Gõ text để giải → \"✅ Tiếp tục cào ngay\"). Nếu không giải được, có thể thử mở URL trong trình duyệt của bạn rồi \"Chạy lại\" — nhưng job mới sẽ chạy trên IP khác, thường phải giải lại từ đầu."
                        textSize = 11f
                        setTextColor(Color.parseColor("#7f1d1d"))
                        setPadding(0, dp(2), 0, dp(6))
                    })
                    addView(LinearLayout(ctx).apply {
                        orientation = HORIZONTAL
                        if (job.pendingActionUrl.isNotEmpty()) {
                            addView(smallButton("🌐 Mở URL này trong trình duyệt của bạn", "#0891b2") {
                                val slotEngine = com.colablive.keeper.core.GeckoViewEngine.forSlot(slotIndex)
                                if (slotEngine != null) {
                                    slotEngine.loadUrl(job.pendingActionUrl)
                                    Toast.makeText(ctx, "Đã mở trong tab của khe này", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(ctx, "Khe này chưa có tab nào đang chạy — mở app chính rồi thử lại", Toast.LENGTH_LONG).show()
                                }
                            })
                        }
                        addView(smallButton("🔄 Chạy lại (dispatch mới)", "#6b7280") {
                            EbookLeechScheduler.resumeAfterManualSolve(ctx, slotIndex, job.id)
                            refreshJobList()
                        })
                    })
                } else {
                    addView(TextView(ctx).apply {
                        text = "Mở tab của khe này để xem trang xác minh trực tiếp (tab đang mở sẵn đúng trang đó), giải xong bấm \"Đã giải xong\" bên dưới."
                        textSize = 11f
                        setTextColor(Color.parseColor("#7f1d1d"))
                        setPadding(0, dp(2), 0, dp(6))
                    })
                    addView(LinearLayout(ctx).apply {
                        orientation = HORIZONTAL
                        addView(smallButton("✅ Đã giải xong, tiếp tục", "#059669") {
                            EbookLeechScheduler.resumeAfterManualSolve(ctx, slotIndex, job.id)
                            refreshJobList()
                        })
                        addView(smallButton("⏭ Bỏ qua chương này", "#6b7280") {
                            EbookLeechScheduler.skipBlockedChapter(ctx, slotIndex, job.id)
                            refreshJobList()
                        })
                    })
                }
            })
        }

        // Nút hành động
        card.addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.START

            // Chạy / Dừng
            if (job.status != LeechJob.JobStatus.NEEDS_ACTION) {
                addView(smallButton(
                    label = if (job.status == LeechJob.JobStatus.RUNNING) "⏹ Dừng" else "▶ Chạy ngay",
                    colorHex = if (job.status == LeechJob.JobStatus.RUNNING) "#e53e3e" else "#2563eb"
                ) {
                    if (job.status == LeechJob.JobStatus.RUNNING) {
                        EbookLeechScheduler.cancelJob(ctx, slotIndex, job.id)
                    } else {
                        // ĐÃ SỬA — trước đây LUÔN cào lại từ đầu (resumeFromCheckpoint
                        // mặc định false) dù đã có checkpoint dở (từ lần
                        // "Dừng" trước, hoặc vừa đồng bộ về từ remote) —
                        // giờ tự nhận biết: có checkpoint thì TIẾP TỤC,
                        // không thì mới cào mới. Nhất quán với mục tiêu
                        // "không mất dữ liệu đã cào" dù đổi qua lại giữa
                        // local/remote.
                        val hasCheckpoint = com.colablive.keeper.features.ebookleech.model.CrawlCheckpointRepository.exists(ctx, slotIndex, job.id)
                        EbookLeechScheduler.startJob(ctx, slotIndex, job, resumeFromCheckpoint = hasCheckpoint)
                    }
                    refreshJobList()
                })
            }

            // ĐÃ THÊM — job Colab đang chạy: hiện lại link mở notebook bất
            // cứ lúc nào (không chỉ lúc job vừa dispatch — người dùng có
            // thể lỡ đóng tab Colab, cần mở lại link để tiếp tục theo dõi/
            // chạy lại notebook).
            if (job.remoteBackend == "COLAB" && job.status == LeechJob.JobStatus.RUNNING && job.pendingActionUrl.isNotEmpty()) {
                addView(smallButton("📓 Mở Colab", "#f59e0b") {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(job.pendingActionUrl)))
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Không mở được link — copy tay: ${job.pendingActionUrl}", Toast.LENGTH_LONG).show()
                    }
                })
            }

            // ĐÃ THÊM — trả lời câu hỏi "lỡ GitHub sập thì sao": checkpoint
            // đã TỰ đồng bộ về máy liên tục (poll định kỳ), nhưng bản đó
            // nằm trong bộ nhớ RIÊNG của app — 2 nút này cho người dùng chủ
            // động: (1) đảm bảo có dữ liệu MỚI NHẤT ngay lúc bấm, rồi (2)
            // ghi ra 1 bản ĐỘC LẬP hoàn toàn (Downloads, xem ngoài app được,
            // xuất đi Drive/email/USB tuỳ ý) — không phụ thuộc GitHub lẫn
            // bộ nhớ riêng của app.
            // ĐÃ THÊM — điều khiển trình duyệt đang chờ từ xa (chỉ khi NEEDS_ACTION
            // remote — khi này InteractiveCommandPoller đang chạy trên remote,
            // sẵn sàng nhận lệnh). Nút chính: chụp màn hình (xem tình hình) +
            // các nút nhanh (Enter, gõ cookie mới). Thiết kế tối giản — người
            // dùng thường chỉ cần: xem màn hình → dán cookie mới → nhấn Enter.
            if ((job.remoteBackend == "GITHUB" || job.remoteBackend == "COLAB") &&
                job.status == LeechJob.JobStatus.NEEDS_ACTION) {
                addView(sectionLabel("🖥️ Điều khiển trình duyệt từ xa"))

                addView(captionLabel("Session/cookie/IP vẫn giữ nguyên — dùng các nút bên dưới để tự giải (xem ảnh, click, gõ text), rồi bấm nút xanh để cào tiếp NGAY tại đây, không cần dispatch job mới."))

                // Hàm tiện ích nội bộ — gửi lệnh interactive và thông báo
                fun sendCmd(action: String, label: String) {
                    val scheduler = EbookLeechScheduler
                    val runner = scheduler.getActiveRemoteRunner(slotIndex, job.id)
                    if (runner == null) {
                        Toast.makeText(ctx, "Chưa có kết nối remote — thử 'Đồng bộ ngay' trước", Toast.LENGTH_SHORT).show()
                        return
                    }
                    runner.sendInteractiveAction(
                        context = ctx,
                        action = action,
                        onQueued = {
                            Toast.makeText(ctx, "✅ Đã gửi lệnh: $label — đang chờ kết quả (~5-10s)…", Toast.LENGTH_SHORT).show()
                        },
                        onError = { msg ->
                            Toast.makeText(ctx, "Gửi lệnh lỗi: $msg", Toast.LENGTH_LONG).show()
                        },
                    )
                }

                // ĐÃ THÊM — nút quan trọng nhất của cả khối: báo hiệu đã tự
                // giải xong (bằng các nút bên dưới, hoặc thậm chí không cần
                // dùng nút nào nếu site tự hết chặn) → Python thoát vòng chờ,
                // THỬ LẠI NGAY đúng chương đang bị chặn trên CÙNG session
                // (cùng cookie, cùng IP runner) — KHÔNG dispatch job mới.
                addView(smallButton("✅ Đã giải xong — Tiếp tục cào ngay", "#059669") {
                    sendCmd("resume_crawl", "tiếp tục cào")
                    Toast.makeText(ctx, "Đang thử lại chương đang bị chặn trên phiên hiện tại…", Toast.LENGTH_LONG).show()
                })

                // Chụp màn hình — xem tình hình trước khi thao tác
                addView(smallButton("📸 Chụp màn hình", "#7c3aed") { sendCmd("screenshot", "chụp màn hình") })

                // Nhấn phím nhanh
                addView(smallButton("↵ Enter", "#374151") { sendCmd("press:Enter", "Enter") })
                addView(smallButton("⭾ Tab", "#374151") { sendCmd("press:Tab", "Tab") })
                addView(smallButton("✕ Esc", "#374151") { sendCmd("press:Escape", "Esc") })

                // Cuộn trang
                addView(smallButton("⬇ Cuộn xuống", "#374151") { sendCmd("scroll:down", "cuộn xuống") })
                addView(smallButton("⬆ Cuộn lên", "#374151") { sendCmd("scroll:up", "cuộn lên") })

                // Gõ text — hiện dialog input
                addView(smallButton("⌨ Gõ text…", "#0891b2") {
                    val inputField = android.widget.EditText(ctx).apply {
                        hint = "Text cần gõ (vd: cookie mới, mật khẩu…)"
                        inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                        setSingleLine(false)
                        maxLines = 5
                        setPadding(32, 24, 32, 24)
                    }
                    android.app.AlertDialog.Builder(ctx)
                        .setTitle("Gõ text vào trình duyệt")
                        .setMessage("Text sẽ được gõ vào element đang focus (click element trước nếu cần)")
                        .setView(inputField)
                        .setPositiveButton("Gửi") { _, _ ->
                            val text = inputField.text.toString()
                            if (text.isNotBlank()) sendCmd("type:$text", "gõ text")
                        }
                        .setNegativeButton("Huỷ", null)
                        .show()
                })

                // Click CSS selector — dùng khi biết chính xác selector
                addView(smallButton("🎯 Click selector…", "#0891b2") {
                    val inputField = android.widget.EditText(ctx).apply {
                        hint = "CSS selector (vd: button.submit, #captcha-btn)"
                        setPadding(32, 24, 32, 24)
                    }
                    android.app.AlertDialog.Builder(ctx)
                        .setTitle("Click element")
                        .setView(inputField)
                        .setPositiveButton("Click") { _, _ ->
                            val sel = inputField.text.toString().trim()
                            if (sel.isNotBlank()) sendCmd("click:$sel", "click $sel")
                        }
                        .setNegativeButton("Huỷ", null)
                        .show()
                })

                // Chạy JavaScript tùy ý — nâng cao, ẩn sau confirm
                addView(smallButton("JS…", "#6b7280") {
                    android.app.AlertDialog.Builder(ctx)
                        .setTitle("Thực thi JavaScript")
                        .setMessage("⚠️ Nâng cao — JS sẽ chạy trực tiếp trong tab đang hiển thị.\nVD: document.getElementById('token').value='abc123'")
                        .setPositiveButton("Tiếp") { _, _ ->
                            val inputField = android.widget.EditText(ctx).apply {
                                hint = "JavaScript code"
                                setSingleLine(false)
                                maxLines = 8
                                setPadding(32, 24, 32, 24)
                            }
                            android.app.AlertDialog.Builder(ctx)
                                .setTitle("JavaScript")
                                .setView(inputField)
                                .setPositiveButton("Chạy") { _, _ ->
                                    val js = inputField.text.toString().trim()
                                    if (js.isNotBlank()) sendCmd("eval:$js", "eval JS")
                                }
                                .setNegativeButton("Huỷ", null)
                                .show()
                        }
                        .setNegativeButton("Huỷ", null)
                        .show()
                })

                // Hiển thị ảnh chụp màn hình mới nhất (nếu có) — tự đọc từ job
                if (job.pendingActionScreenshotPath.isNotEmpty()) {
                    val imgFile = java.io.File(job.pendingActionScreenshotPath)
                    if (imgFile.exists()) {
                        val imgView = android.widget.ImageView(ctx).apply {
                            try {
                                setImageBitmap(android.graphics.BitmapFactory.decodeFile(imgFile.absolutePath))
                            } catch (e: Exception) { /* ảnh hỏng — không hiện */ }
                            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                            adjustViewBounds = true
                            setPadding(0, 8, 0, 8)
                        }
                        addView(imgView)
                        addView(captionLabel("Màn hình từ xa (cập nhật sau mỗi lệnh)"))
                    }
                }
            }

            if ((job.remoteBackend == "GITHUB" || job.remoteBackend == "COLAB") &&
                (job.status == LeechJob.JobStatus.RUNNING || job.status == LeechJob.JobStatus.NEEDS_ACTION)) {
                addView(smallButton("🔄 Đồng bộ ngay", "#0891b2") {
                    EbookLeechScheduler.syncRemoteNow(slotIndex, job.id)
                    Toast.makeText(ctx, "Đang tải checkpoint/ảnh mới nhất…", Toast.LENGTH_SHORT).show()
                })
                addView(smallButton("💾 Sao lưu ngay", "#6b7280") {
                    Thread {
                        try {
                            val path = com.colablive.keeper.features.ebookleech.backup.EbookLeechBackupManager.exportToFile(ctx, slotIndex)
                            (ctx as? android.app.Activity)?.runOnUiThread {
                                Toast.makeText(ctx, "Đã sao lưu (kèm ảnh) ra:\n$path", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            (ctx as? android.app.Activity)?.runOnUiThread {
                                Toast.makeText(ctx, "Sao lưu lỗi: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                })
            }

            // Xem kịch bản (luồng các bước, chạm để sửa riêng từng bước)
            addView(smallButton("🗺️ Kịch bản", "#0891b2") {
                showScenarioView(job)
            })

            // Sửa
            addView(smallButton("✏ Sửa toàn bộ", "#6b7280") {
                showJobEditor(job)
            })

            // Sắp xếp mục lục (chỉ khi đã cào xong, chờ review)
            if (job.status == LeechJob.JobStatus.REVIEW_READY) {
                addView(smallButton("📑 Sắp xếp mục lục", "#7c3aed") {
                    showTocEditor(job)
                })
            }

            // Mở file (chỉ khi có output) — outputFilePath giờ có thể là
            // đường dẫn filesystem thật (Android < 10) HOẶC content:// URI
            // (Android 10+, ghi qua MediaStore — xem EbookExporter).
            if (job.outputFilePath.isNotEmpty() && outputFileExists(job.outputFilePath)) {
                addView(smallButton("📖 Mở ebook", "#059669") {
                    openFile(job.outputFilePath)
                })
            }

            // Xoá
            addView(smallButton("🗑 Xoá", "#9ca3af") {
                LeechJobRepository.deleteJob(ctx, slotIndex, job.id)
                EbookLeechScheduler.cancelJob(ctx, slotIndex, job.id)
                refreshJobList()
            })
        })

        return card
    }

    // -------------------------------------------------------------------------
    // Job Editor Dialog — form nhập cấu hình job
    // -------------------------------------------------------------------------

    private fun showJobEditor(existing: LeechJob?) {
        val form = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(16))
        }

        // Helper tạo field kiểu Material (nhãn nổi) thay TextView+EditText trần
        fun field(label: String, hint: String, value: String = "", multiline: Boolean = false): EditText {
            val layout = TextInputLayout(ctx).apply {
                this.hint = label
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
            }
            val et = TextInputEditText(ctx).apply {
                this.hint = hint
                setText(value)
                textSize = 14f
                if (multiline) { minLines = 2; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
            }
            layout.addView(et)
            form.addView(layout)
            return et
        }

        // Row field Material + nút "🎯 Chọn trên trang" — chạm vào phần tử thay
        // vì gõ tay CSS selector. mode="list" ưu tiên selector khớp nhiều phần
        // tử giống nhau (link chương); mode="single" ưu tiên khớp đúng 1.
        fun fieldWithPicker(label: String, hint: String, value: String, pickerMode: String): EditText {
            val row = LinearLayout(ctx).apply {
                orientation = HORIZONTAL
                gravity = Gravity.BOTTOM
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            val layout = TextInputLayout(ctx).apply {
                this.hint = label
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = dp(8) }
            }
            val et = TextInputEditText(ctx).apply { this.hint = hint; setText(value); textSize = 14f }
            layout.addView(et)
            row.addView(layout)
            row.addView(smallButton("🎯 Chọn", "#059669") {
                startElementPicking(pickerMode) { picked -> et.setText(picked) }
            }.apply { (layoutParams as LinearLayout.LayoutParams).bottomMargin = dp(8) })
            form.addView(row)
            return et
        }

        val nameEt = field("Tên job", "vd: Truyện Kiều - truyen.vn", existing?.name ?: "")

        // ── Dự án ──
        val projects = LeechProjectRepository.loadAll(ctx, slotIndex)
        val projectNames = listOf("— Chưa phân nhóm —") + projects.map { it.name }
        val projectSelIdx = projects.indexOfFirst { it.id == existing?.projectId }.let { if (it >= 0) it + 1 else 0 }
        val projectDropdown = materialDropdown(form, "Dự án", projectNames, projectSelIdx)

        val urlEt  = field("URL trang danh sách (trang 1)", "https://...", existing?.listPageUrl ?: "")
        val patternEt = field(
            "Pattern phân trang (tùy chọn)",
            "https://site.com/truyen?page={page} — bỏ trống nếu không có",
            existing?.listPageUrlPattern ?: ""
        )
        val maxPagesEt = field("Số trang danh sách tối đa", "50", existing?.maxPages?.toString() ?: "50")

        form.addView(divider())
        form.addView(sectionLabel("Kịch bản nhiều bước (tuỳ chọn)"))
        form.addView(TextView(ctx).apply {
            text = "Mặc định: URL ở trên đã LÀ trang danh sách chương. Nếu web của bạn " +
                "phải đi qua vài bước trung gian mới tới đó (vd: Trang chủ → Thể loại → " +
                "Sách → mới tới danh sách chương), thêm từng bước bên dưới theo đúng thứ tự."
            textSize = 11f
            setTextColor(Color.parseColor("#6b7280"))
            setPadding(0, 0, 0, dp(6))
        })
        val stagesContainer = LinearLayout(ctx).apply { orientation = VERTICAL }
        form.addView(stagesContainer)
        val currentStages = (existing?.preListStages ?: emptyList())
            .map { it }.toMutableList()
        fun rebuildStagesUi() {
            stagesContainer.removeAllViews()
            currentStages.forEachIndexed { idx, stage ->
                stagesContainer.addView(LinearLayout(ctx).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(TextView(ctx).apply {
                        text = "${idx + 1}. ${stage.label}: ${stage.linkSelector}"
                        textSize = 11f
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                    })
                    addView(smallButton("🗑", "#9ca3af") { currentStages.removeAt(idx); rebuildStagesUi() })
                })
            }
        }
        rebuildStagesUi()
        form.addView(MaterialButton(ctx).apply {
            text = "+ Thêm bước trung gian"
            textSize = 12f
            setOnClickListener { showAddStageDialog(currentStages) { rebuildStagesUi() } }
        })

        form.addView(divider())
        form.addView(sectionLabel("Selector CSS (trang danh sách)"))

        val chLinkEt  = fieldWithPicker("Selector link chương", ".chapter-list a", existing?.chapterLinkSelector ?: "", "list")
        val chAttrEt  = field("Thuộc tính href", "href", existing?.chapterLinkAttribute ?: "href")

        form.addView(divider())
        form.addView(sectionLabel("Selector CSS (trang chương)"))

        val chTitleEt   = fieldWithPicker("Selector tiêu đề chương", "h2.chapter-title", existing?.chapterTitleSelector ?: "", "single")
        val chContentEt = fieldWithPicker("Selector nội dung chương", "div.chapter-content", existing?.chapterContentSelector ?: "", "single")

        // ── ĐÃ THÊM — "Preset site phổ biến": lưu lại 4-5 selector CSS đã
        // dùng thành công cho 1 site, dùng lại nhanh khi tạo job mới cho
        // TRUYỆN KHÁC trên CÙNG site đó. KHÁC Sao lưu/Khôi phục — xem
        // docstring đầy đủ trong SitePreset.kt.
        form.addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            setPadding(0, dp(6), 0, dp(4))
            addView(smallButton("📋 Áp dụng preset đã lưu", "#0891b2") {
                showSitePresetPicker { preset ->
                    patternEt.setText(preset.listPageUrlPattern)
                    chLinkEt.setText(preset.chapterLinkSelector)
                    chAttrEt.setText(preset.chapterLinkAttribute)
                    chTitleEt.setText(preset.chapterTitleSelector)
                    chContentEt.setText(preset.chapterContentSelector)
                    Toast.makeText(ctx, "Đã áp dụng preset \"${preset.name}\" — nhớ điền lại URL truyện ở trên (preset không lưu URL cụ thể)", Toast.LENGTH_LONG).show()
                }
            })
            addView(smallButton("💾 Lưu selector này làm preset", "#6b7280") {
                showSavePresetDialog(patternEt, chLinkEt, chAttrEt, chTitleEt, chContentEt)
            })
        })

        form.addView(divider())
        form.addView(sectionLabel("Xuất ebook"))

        val formatOptions = listOf("EPUB", "TXT", "HTML")
        val formatSelIdx = when (existing?.outputFormat) {
            LeechJob.OutputFormat.TXT  -> 1
            LeechJob.OutputFormat.HTML -> 2
            else -> 0
        }
        val formatDropdown = materialDropdown(form, "Định dạng", formatOptions, formatSelIdx)

        // ── ĐÃ THÊM — "Cào từ xa qua GitHub Actions" ─────────────────────
        val remoteOptions = listOf("📱 Trên điện thoại (mặc định)", "☁️ GitHub Actions (từ xa)", "📓 Google Colab (thủ công)")
        val remoteSelIdx = when (existing?.remoteBackend) {
            "GITHUB" -> 1
            "COLAB" -> 2
            else -> 0
        }
        val remoteDropdown = materialDropdown(form, "Chạy ở đâu", remoteOptions, remoteSelIdx)
        form.addView(TextView(ctx).apply {
            text = "☁️ GitHub Actions: tự động hoàn toàn, có Chromium (chạy được JS, qua được phần lớn Cloudflare JS challenge), tải ảnh offline. " +
                "KHÔNG hỗ trợ đăng nhập có sẵn (chỉ cookie dán tay), CAPTCHA thật (cần người bấm) vẫn không qua được — xem chi tiết khi job cần xử lý thủ công. " +
                "Cần cấu hình GitHub trước (nút \"☁️ Cấu hình GitHub\" ở đầu màn hình).\n" +
                "📓 Google Colab: y hệt GitHub Actions về khả năng cào (dùng chung code) — KHÁC ở chỗ KHÔNG tự động, bạn phải TỰ mở link Colab + bấm \"Run all\" mỗi lần, " +
                "và giữ tab đó mở suốt quá trình cào (Colab tự ngắt sau ~90 phút không tương tác). Vẫn cần cấu hình GitHub trước (dùng chung hàng đợi/token)."
            textSize = 11f
            setTextColor(Color.parseColor("#666666"))
            setPadding(0, dp(2), 0, dp(6))
        })

        form.addView(divider())
        form.addView(sectionLabel("Lịch chạy tự động"))

        val scheduleOptions = listOf("Thủ công (MANUAL)", "Theo chu kỳ (INTERVAL)", "Mỗi ngày (DAILY)")
        val scheduleSelIdx = when (existing?.scheduleMode) {
            LeechJob.ScheduleMode.INTERVAL -> 1
            LeechJob.ScheduleMode.DAILY    -> 2
            else -> 0
        }
        val scheduleDropdown = materialDropdown(form, "Lịch chạy", scheduleOptions, scheduleSelIdx)
        val intervalEt = field("Chu kỳ (phút) — dùng khi chọn INTERVAL", "60", existing?.intervalMinutes?.toString() ?: "60")

        form.addView(divider())
        form.addView(sectionLabel("Anti-bot"))

        val delayEt  = field("Delay giữa các trang (ms)", "1500", existing?.delayBetweenPagesMs?.toString() ?: "1500")
        val cookieEt = field("Cookie header (tùy chọn)", "session=abc123; token=xyz", existing?.cookieHeader ?: "")

        form.addView(divider())
        form.addView(sectionLabel("Nâng cao"))

        // ── Dùng phiên đăng nhập có sẵn ──
        val useLoginSessionCb = MaterialCheckBox(ctx).apply {
            text = "Dùng đăng nhập có sẵn trong app (site cần login) — cookie tự lưu như tab thường"
            textSize = 13f
            isChecked = existing?.useLoginSession ?: false
            form.addView(this)
        }
        form.addView(TextView(ctx).apply {
            text = "Mặc định TẮT: tab cào chạy ẩn danh, không dùng được đăng nhập, không lưu gì. " +
                "BẬT nếu site yêu cầu login — sẽ dùng đúng cookie bạn đã đăng nhập trong app này, " +
                "không cần đăng nhập lại lần sau. Đánh đổi: URL từng chương sẽ vào lịch sử duyệt web."
            textSize = 11f
            setTextColor(Color.parseColor("#6b7280"))
            setPadding(0, 0, 0, dp(6))
        })

        // ── Tự cuộn cho site lazy-load ──
        val simulateScrollCb = MaterialCheckBox(ctx).apply {
            text = "Trang chỉ hiện nội dung khi cuộn xuống (lazy-load) — tự cuộn trước khi lấy nội dung"
            textSize = 13f
            isChecked = existing?.simulateScrollForLazyLoad ?: false
            form.addView(this)
        }

        // ── Đăng thẳng lên WordPress ──
        val publishWpCb = MaterialCheckBox(ctx).apply {
            text = "Đăng mỗi chương thành 1 bài viết WordPress (cấu hình chi tiết ở bước riêng trong Kịch bản)"
            textSize = 13f
            isChecked = existing?.publishToWordPress ?: false
            form.addView(this)
        }

        // ── Tải ảnh offline ──
        val downloadImagesCb = MaterialCheckBox(ctx).apply {
            text = "Tải ảnh về máy, nhúng offline vào ebook (chậm hơn, nặng hơn)"
            textSize = 13f
            isChecked = existing?.downloadImages ?: false
            form.addView(this)
        }
        val maxImagesEt = field("Số ảnh tối đa / chương", "30", existing?.maxImagesPerChapter?.toString() ?: "30")

        // ── Tự dò phân trang ──
        val autoPaginationCb = MaterialCheckBox(ctx).apply {
            text = "Tự dò cách phân trang (bỏ trống ô Pattern phía trên để dùng)"
            textSize = 13f
            isChecked = existing?.autoDetectPagination ?: false
            form.addView(this)
        }

        // ── AJAX sniff — KHÔI PHỤC sau khi tìm bằng chứng đủ mạnh ──
        // (đối chiếu assets/fingerprint_spoof/content.js thật — patch trực
        // tiếp navigator/window đã ship, chứng tỏ content script ở đây
        // không bị cô lập world khỏi trang thật, nên patch fetch/XHR tương
        // tự nhiều khả năng cũng hoạt động — NHƯNG đây là suy luận từ bằng
        // chứng gián tiếp, CHƯA tự chạy thử tính năng này, ghi rõ cho user)
        val ajaxSniffCb = MaterialCheckBox(ctx).apply {
            text = "Dò endpoint AJAX nghi vấn (gợi ý, không tự cào — CHƯA test thật trên máy)"
            textSize = 13f
            isChecked = existing?.suggestAjaxEndpoints ?: false
            form.addView(this)
        }
        if (!existing?.detectedAjaxEndpoints.isNullOrEmpty()) {
            form.addView(TextView(ctx).apply {
                text = "Đã phát hiện:\n" + existing!!.detectedAjaxEndpoints.joinToString("\n") { "• $it" }
                textSize = 11f
                setTextColor(Color.parseColor("#6b7280"))
                setPadding(0, dp(4), 0, dp(4))
            })
        }

        // ── ĐÃ THÊM — "AJAX Leech thật": DÙNG THẲNG JSON API làm nguồn dữ
        // liệu, khác hẳn "Dò endpoint AJAX" ở trên (cái đó chỉ gợi ý URL,
        // không tự cào). Các ô path dùng cú pháp đơn giản "a.b.c"/"a.b[0].c"
        // (xem JsonPathExtractor.kt) — luôn hiện, chỉ có tác dụng khi
        // checkbox tương ứng được bật.
        form.addView(TextView(ctx).apply {
            text = "── AJAX Leech thật (dùng thẳng JSON API làm nguồn) ──"
            textSize = 12f
            setTextColor(Color.parseColor("#0891b2"))
            setPadding(0, dp(8), 0, dp(4))
        })
        val ajaxListModeCb = MaterialCheckBox(ctx).apply {
            text = "Danh sách chương lấy từ JSON API (thay vì bóc HTML)"
            textSize = 13f
            isChecked = existing?.ajaxListMode ?: false
            form.addView(this)
        }
        val ajaxListUrlEt = field(
            "URL API danh sách chương (dùng {page}/{base})",
            "vd: https://x.com/api/chapters?novel=1&page={page}",
            existing?.ajaxListUrlTemplate ?: "",
        )
        val ajaxListItemsPathEt = field(
            "Path tới mảng chương trong JSON (để trống nếu mảng ở gốc)",
            "vd: data.items",
            existing?.ajaxListItemsPath ?: "",
        )
        val ajaxListUrlFieldEt = field(
            "Tên field chứa URL chương (trong mỗi phần tử mảng)",
            "url",
            existing?.ajaxListUrlField ?: "url",
        )
        val ajaxContentModeCb = MaterialCheckBox(ctx).apply {
            text = "Nội dung chương lấy từ JSON API (mỗi link chương LÀ 1 API, không phải trang HTML)"
            textSize = 13f
            isChecked = existing?.ajaxContentMode ?: false
            form.addView(this)
        }
        val ajaxContentTitleFieldEt = field(
            "Path field tiêu đề trong JSON của 1 chương",
            "title",
            existing?.ajaxContentTitleField ?: "title",
        )
        val ajaxContentFieldEt = field(
            "Path field nội dung (HTML hoặc text) trong JSON của 1 chương",
            "content",
            existing?.ajaxContentField ?: "content",
        )

        // ── Xem trước mục lục trước khi xuất ──
        val manualTocReviewCb = MaterialCheckBox(ctx).apply {
            text = "Cào xong thì DỪNG lại cho tôi sắp xếp mục lục trước khi xuất (gộp tập, đổi tên, loại chương, sắp lại thứ tự)"
            textSize = 13f
            isChecked = existing?.manualTocReview ?: false
            form.addView(this)
        }

        // ── Tìm & thay thế / Regex-Callback rules ──
        form.addView(sectionLabel("Tìm & thay thế trong nội dung cào"))
        form.addView(TextView(ctx).apply {
            text = "Lọc quảng cáo chèn giữa bài, đổi tên nhân vật, chuẩn hoá chính tả... " +
                "áp dụng lên tiêu đề/nội dung mỗi chương SAU KHI cào, TRƯỚC KHI lưu vào ebook."
            textSize = 11f
            setTextColor(Color.parseColor("#6b7280"))
            setPadding(0, 0, 0, dp(6))
        })
        val rulesContainer = LinearLayout(ctx).apply { orientation = VERTICAL }
        form.addView(rulesContainer)
        val currentRules = (existing?.regexRules ?: emptyList()).toMutableList()
        fun rebuildRulesUi() {
            rulesContainer.removeAllViews()
            currentRules.forEachIndexed { idx, rule ->
                rulesContainer.addView(LinearLayout(ctx).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(TextView(ctx).apply {
                        val targetLabel = when (rule.target) {
                            com.colablive.keeper.features.ebookleech.model.RegexRule.Target.TITLE -> "Tiêu đề"
                            com.colablive.keeper.features.ebookleech.model.RegexRule.Target.CONTENT_HTML -> "Nội dung HTML"
                            com.colablive.keeper.features.ebookleech.model.RegexRule.Target.CONTENT_TEXT -> "Nội dung Text"
                        }
                        text = when (rule.kind) {
                            com.colablive.keeper.features.ebookleech.model.RegexRule.Kind.PLAIN_REPLACE ->
                                "$targetLabel: tìm \"${rule.pattern}\" → thay \"${rule.replacement}\"" + (if (rule.caseInsensitive) " (ko phân biệt hoa/thường)" else "")
                            com.colablive.keeper.features.ebookleech.model.RegexRule.Kind.REGEX_REPLACE ->
                                "$targetLabel: regex /${rule.pattern}/ → \"${rule.replacement}\""
                            com.colablive.keeper.features.ebookleech.model.RegexRule.Kind.SPIN_INSERT_PREFIX ->
                                "$targetLabel: chèn đầu (spin) \"${rule.replacement}\""
                            com.colablive.keeper.features.ebookleech.model.RegexRule.Kind.SPIN_INSERT_SUFFIX ->
                                "$targetLabel: chèn cuối (spin) \"${rule.replacement}\""
                            else -> "$targetLabel: ${rule.kind}"
                        }
                        textSize = 11f
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                    })
                    addView(smallButton("🗑", "#9ca3af") {
                        currentRules.removeAt(idx)
                        rebuildRulesUi()
                    })
                })
            }
        }
        rebuildRulesUi()
        form.addView(MaterialButton(ctx).apply {
            text = "+ Thêm tìm & thay thế"
            textSize = 12f
            setOnClickListener { showAddRuleDialog(currentRules) { rebuildRulesUi() } }
        })

        // Nút Lưu
        showBottomSheet(
            title = if (existing == null) "Thêm Job mới" else "Sửa Job",
            content = form,
            maxHeightFraction = 0.85,  // form dài — cần nhiều chỗ hơn dialog 1 bước
            onSave = {
                val formatIdx = formatOptions.indexOf(formatDropdown.text.toString()).let { if (it < 0) 0 else it }
                val format = when (formatIdx) {
                    1    -> LeechJob.OutputFormat.TXT
                    2    -> LeechJob.OutputFormat.HTML
                    else -> LeechJob.OutputFormat.EPUB
                }
                val scheduleIdx = scheduleOptions.indexOf(scheduleDropdown.text.toString()).let { if (it < 0) 0 else it }
                val sched = when (scheduleIdx) {
                    1    -> LeechJob.ScheduleMode.INTERVAL
                    2    -> LeechJob.ScheduleMode.DAILY
                    else -> LeechJob.ScheduleMode.MANUAL
                }
                val job = (existing ?: LeechJob(
                    id = LeechJobRepository.newId(),
                    name = "",
                    listPageUrl = "",
                    listPageUrlPattern = "",
                    chapterLinkSelector = "",
                    chapterTitleSelector = "",
                    chapterContentSelector = "",
                )).copy(
                    name                  = nameEt.text.toString().trim().ifBlank { "Job không tên" },
                    projectId             = if (projectDropdown.text.toString() == projectNames[0]) "" else {
                        val idx = projectNames.indexOf(projectDropdown.text.toString())
                        if (idx > 0) projects[idx - 1].id else ""
                    },
                    listPageUrl           = urlEt.text.toString().trim(),
                    listPageUrlPattern    = patternEt.text.toString().trim(),
                    maxPages              = maxPagesEt.text.toString().toIntOrNull() ?: 50,
                    chapterLinkSelector   = chLinkEt.text.toString().trim(),
                    chapterLinkAttribute  = chAttrEt.text.toString().trim().ifBlank { "href" },
                    chapterTitleSelector  = chTitleEt.text.toString().trim(),
                    chapterContentSelector = chContentEt.text.toString().trim(),
                    outputFormat          = format,
                    scheduleMode          = sched,
                    intervalMinutes       = intervalEt.text.toString().toIntOrNull() ?: 60,
                    delayBetweenPagesMs   = delayEt.text.toString().toLongOrNull() ?: 1500L,
                    cookieHeader          = cookieEt.text.toString().trim(),
                    downloadImages        = downloadImagesCb.isChecked,
                    maxImagesPerChapter   = maxImagesEt.text.toString().toIntOrNull() ?: 30,
                    useLoginSession       = useLoginSessionCb.isChecked,
                    simulateScrollForLazyLoad = simulateScrollCb.isChecked,
                    publishToWordPress    = publishWpCb.isChecked,
                    autoDetectPagination  = autoPaginationCb.isChecked,
                    suggestAjaxEndpoints  = ajaxSniffCb.isChecked,
                    ajaxListMode          = ajaxListModeCb.isChecked,
                    ajaxListUrlTemplate   = ajaxListUrlEt.text.toString().trim(),
                    ajaxListItemsPath     = ajaxListItemsPathEt.text.toString().trim(),
                    ajaxListUrlField      = ajaxListUrlFieldEt.text.toString().trim().ifBlank { "url" },
                    ajaxContentMode       = ajaxContentModeCb.isChecked,
                    ajaxContentTitleField = ajaxContentTitleFieldEt.text.toString().trim().ifBlank { "title" },
                    ajaxContentField      = ajaxContentFieldEt.text.toString().trim().ifBlank { "content" },
                    remoteBackend         = when (remoteOptions.indexOf(remoteDropdown.text.toString())) {
                        1 -> "GITHUB"
                        2 -> "COLAB"
                        else -> "NONE"
                    },
                    regexRules            = currentRules.toList(),
                    preListStages         = currentStages.toList(),
                    manualTocReview       = manualTocReviewCb.isChecked,
                    status = existing?.status ?: LeechJob.JobStatus.IDLE,
                )
                if (existing == null) LeechJobRepository.addJob(ctx, slotIndex, job)
                else LeechJobRepository.updateJob(ctx, slotIndex, job)
                refreshJobList()
            }
        )
    }

    // -------------------------------------------------------------------------
    // Dialog thêm 1 luật Tìm & thay thế / Regex-Callback
    // -------------------------------------------------------------------------

    private fun showAddRuleDialog(
        rules: MutableList<com.colablive.keeper.features.ebookleech.model.RegexRule>,
        onAdded: () -> Unit,
    ) {
        val form = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(8))
        }

        form.addView(TextView(ctx).apply { text = "Áp dụng lên"; textSize = 12f; setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(4), 0, dp(2)) })
        val targetOptions = listOf("Tiêu đề chương", "Nội dung (HTML)", "Nội dung (Text thuần)")
        val targetDropdown = materialDropdown(form, "Áp dụng lên", targetOptions, 0)

        // Nhãn tiếng Việt dễ hiểu thay vì tên enum thô — PLAIN_REPLACE đặt
        // đầu tiên vì đây là lựa chọn phổ biến nhất, không cần biết regex.
        val kindOptions = RegexRule.Kind.values().toList()
        val kindLabels = kindOptions.map { k ->
            when (k) {
                RegexRule.Kind.PLAIN_REPLACE -> "Tìm & thay thế văn bản (đơn giản, không cần regex)"
                RegexRule.Kind.REGEX_REPLACE -> "Tìm & thay thế bằng Regex (nâng cao)"
                RegexRule.Kind.TRIM -> "Xoá khoảng trắng thừa đầu/cuối dòng"
                RegexRule.Kind.REMOVE_EMPTY_LINES -> "Gộp dòng trống thừa"
                RegexRule.Kind.TO_UPPERCASE -> "Viết HOA toàn bộ"
                RegexRule.Kind.TO_LOWERCASE -> "viết thường toàn bộ"
                RegexRule.Kind.CAPITALIZE_FIRST -> "Viết hoa đầu câu"
                RegexRule.Kind.STRIP_HTML_TAGS -> "Bỏ hết thẻ HTML"
                RegexRule.Kind.SPIN_INSERT_PREFIX -> "Chèn câu mở đầu ngẫu nhiên (chống trùng lặp — {a|b|c})"
                RegexRule.Kind.SPIN_INSERT_SUFFIX -> "Chèn câu kết thúc ngẫu nhiên (chống trùng lặp — {a|b|c})"
            }
        }
        val kindDropdown = materialDropdown(form, "Loại xử lý", kindLabels, 0)

        // Field tìm/thay chỉ thật sự cần cho PLAIN_REPLACE/REGEX_REPLACE —
        // vẫn hiện cho mọi loại để đơn giản hoá code, nhưng đổi hint theo
        // lựa chọn hiện tại để không gây hiểu lầm. Tự dựng TextInputLayout ở
        // đây (không dùng materialField()) để giữ được tham chiếu layout
        // thật — .parent của EditText không đảm bảo trỏ đúng TextInputLayout
        // (Material có thể bọc thêm FrameLayout nội bộ quản lý field).
        val patternLayout = TextInputLayout(ctx).apply {
            hint = "Tìm"
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        }
        val patternEt = TextInputEditText(ctx).apply { hint = "Văn bản cần tìm, vd: [Quảng cáo]"; textSize = 14f }
        patternLayout.addView(patternEt)
        form.addView(patternLayout)

        val replacementLayout = TextInputLayout(ctx).apply {
            hint = "Thay bằng"
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        }
        val replacementEt = TextInputEditText(ctx).apply { hint = "Để trống = xoá đoạn tìm được"; textSize = 14f }
        replacementLayout.addView(replacementEt)
        form.addView(replacementLayout)

        val caseInsensitiveCb = MaterialCheckBox(ctx).apply {
            text = "Không phân biệt hoa/thường khi tìm"
            textSize = 13f; minHeight = dp(44)
            form.addView(this)
        }

        fun updateFieldVisibility() {
            val kindIdx = kindLabels.indexOf(kindDropdown.text.toString()).let { if (it < 0) 0 else it }
            val kind = kindOptions[kindIdx]
            val needsPattern = kind == RegexRule.Kind.PLAIN_REPLACE || kind == RegexRule.Kind.REGEX_REPLACE
            val needsSpinTemplate = kind == RegexRule.Kind.SPIN_INSERT_PREFIX || kind == RegexRule.Kind.SPIN_INSERT_SUFFIX
            patternLayout.visibility = if (needsPattern) View.VISIBLE else View.GONE
            replacementLayout.visibility = if (needsPattern || needsSpinTemplate) View.VISIBLE else View.GONE
            caseInsensitiveCb.visibility = if (needsPattern) View.VISIBLE else View.GONE
            patternEt.hint = if (kind == RegexRule.Kind.REGEX_REPLACE)
                "Regex pattern, vd: \\[Quảng cáo\\].*" else "Văn bản cần tìm, vd: [Quảng cáo]"
            replacementLayout.hint = if (needsSpinTemplate) "Template spin" else "Thay bằng"
            replacementEt.hint = if (needsSpinTemplate)
                "vd: {Xin chào|Chào bạn|Kính chào} độc giả,\\n\\n — mỗi chương random 1 lựa chọn"
            else "Để trống = xoá đoạn tìm được"
        }
        kindDropdown.setOnItemClickListener { _, _, _, _ -> updateFieldVisibility() }
        updateFieldVisibility()

        showBottomSheet("Thêm tìm & thay thế", form, onSave = {
            val targetIdx = targetOptions.indexOf(targetDropdown.text.toString()).let { if (it < 0) 0 else it }
            val target = when (targetIdx) {
                1 -> RegexRule.Target.CONTENT_HTML
                2 -> RegexRule.Target.CONTENT_TEXT
                else -> RegexRule.Target.TITLE
            }
            val kindIdx = kindLabels.indexOf(kindDropdown.text.toString()).let { if (it < 0) 0 else it }
            val kind = kindOptions[kindIdx]
            rules.add(RegexRule(
                target = target,
                kind = kind,
                pattern = patternEt.text.toString(),
                replacement = replacementEt.text.toString(),
                caseInsensitive = caseInsensitiveCb.isChecked,
            ))
            onAdded()
        })
    }

    // -------------------------------------------------------------------------
    // Dialog thêm 1 bước trong kịch bản nhiều bước
    // -------------------------------------------------------------------------

    private fun showAddStageDialog(
        stages: MutableList<com.colablive.keeper.features.ebookleech.model.CrawlStage>,
        onAdded: () -> Unit,
    ) {
        val form = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(8))
        }
        val labelLayout = TextInputLayout(ctx).apply {
            hint = "Tên bước"
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        }
        val labelEt = TextInputEditText(ctx).apply { hint = "vd: Chọn thể loại"; textSize = 14f }
        labelLayout.addView(labelEt)
        form.addView(labelLayout)

        val selectorRow = LinearLayout(ctx).apply { orientation = HORIZONTAL; gravity = Gravity.BOTTOM }
        val selectorLayout = TextInputLayout(ctx).apply {
            hint = "Selector link ở bước này"
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = dp(8) }
        }
        val selectorEt = TextInputEditText(ctx).apply { hint = ".category-list a"; textSize = 14f }
        selectorLayout.addView(selectorEt)
        selectorRow.addView(selectorLayout)
        selectorRow.addView(smallButton("🎯 Chọn", "#059669") {
            startElementPicking("list") { picked -> selectorEt.setText(picked) }
        }.apply { (layoutParams as LinearLayout.LayoutParams).bottomMargin = dp(8) })
        form.addView(selectorRow)

        val attrLayout = TextInputLayout(ctx).apply {
            hint = "Thuộc tính chứa URL"
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        }
        val attrEt = TextInputEditText(ctx).apply { hint = "href"; setText("href"); textSize = 14f }
        attrLayout.addView(attrEt)
        form.addView(attrLayout)

        showBottomSheet("Thêm bước trung gian", form, onSave = {
            stages.add(CrawlStage(
                label = labelEt.text.toString().trim().ifBlank { "Bước ${stages.size + 1}" },
                linkSelector = selectorEt.text.toString().trim(),
                linkAttribute = attrEt.text.toString().trim().ifBlank { "href" },
            ))
            onAdded()
        })
    }

    // -------------------------------------------------------------------------
    // Element Picker — chạm vào phần tử trên trang thật thay vì gõ CSS tay
    // -------------------------------------------------------------------------

    private fun startElementPicking(mode: String, onPicked: (String) -> Unit) {
        val engine = com.colablive.keeper.core.GeckoViewEngine.forSlot(slotIndex)
        if (engine == null) {
            Toast.makeText(ctx, "Không tìm thấy engine đang chạy cho khe này — mở 1 tab bất kỳ trong khe này trước", Toast.LENGTH_LONG).show()
            return
        }

        Toast.makeText(ctx, "Điều hướng tới phần tử cần chọn trên trang, rồi chạm vào nó", Toast.LENGTH_LONG).show()

        val picker = com.colablive.keeper.features.ebookleech.engine.ElementPickerBridge
        picker.startPicking(engine, mode) { err ->
            Toast.makeText(ctx, "Lỗi khởi động picker: $err", Toast.LENGTH_LONG).show()
        }

        val message = TextView(ctx).apply {
            text = if (mode == "list")
                "Chạm vào MỘT link chương bất kỳ trong danh sách trên trang — tool sẽ tự tìm những phần tử giống nó. Xong thì bấm Xác nhận."
            else
                "Chạm vào phần tử chứa tiêu đề/nội dung trên trang. Xong thì bấm Xác nhận."
            textSize = 14f
            setPadding(dp(16), dp(4), dp(16), dp(8))
        }

        showBottomSheet(
            title = "Đang ở chế độ chọn phần tử",
            content = message,
            cancelable = false,
            saveLabel = "Xác nhận",
            onCancel = { picker.stopPicking(engine) },
            onSave = {
                picker.confirmPick(engine) { selector, count ->
                    picker.stopPicking(engine)
                    if (selector.isNullOrBlank()) {
                        Toast.makeText(ctx, "Chưa chọn phần tử nào trên trang", Toast.LENGTH_SHORT).show()
                    } else {
                        onPicked(selector)
                        Toast.makeText(ctx, "Đã lấy selector — khớp $count phần tử", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }

    // -------------------------------------------------------------------------
    // Toc Editor — xem trước & sắp xếp mục lục trước khi xuất (REVIEW_READY)
    // -------------------------------------------------------------------------

    private fun showTocEditor(job: LeechJob) {
        val chapters = com.colablive.keeper.features.ebookleech.engine.ChapterCache.get(slotIndex, job.id)
        if (chapters == null) {
            Toast.makeText(ctx, "Dữ liệu đã cào không còn trong bộ nhớ — cần chạy lại job", Toast.LENGTH_LONG).show()
            return
        }

        val workingList: MutableList<TocNode> = (
            job.tocOverride.ifEmpty {
                chapters.sortedBy { it.index }.map { TocNode(id = "n_${it.index}", label = it.title, chapterIndex = it.index) }
            }
        ).toMutableList()

        val selectedIds = mutableSetOf<String>()

        val outer = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(8)) }
        val listContainer = LinearLayout(ctx).apply { orientation = VERTICAL }

        outer.addView(TextView(ctx).apply {
            text = "${chapters.size} chương đã cào"
            textSize = 13f
            setTextColor(Color.parseColor("#6b7280"))
            setPadding(0, 0, 0, dp(4))
        })
        outer.addView(TextView(ctx).apply {
            text = "☰ giữ & kéo để đổi vị trí (hoặc dùng ▲▼)  •  ✏ đổi tên  •  🗑 loại khỏi ebook  •  Tick nhiều mục rồi bấm \"Gộp thành tập\" để nhóm lại"
            textSize = 11f
            setTextColor(Color.parseColor("#6b7280"))
            setPadding(0, 0, 0, dp(8))
        })
        outer.addView(listContainer)

        val groupBtn = MaterialButton(ctx).apply { text = "📁 Gộp mục đã chọn thành 1 Tập"; textSize = 13f; minHeight = dp(44) }
        outer.addView(groupBtn)

        // rebuild() vẽ lại toàn bộ danh sách hàng dựa trên workingList hiện tại.
        // Khai báo lateinit-style bằng var để các nút bên trong mỗi hàng gọi
        // ngược lại được chính rebuild() sau khi thay đổi workingList.
        lateinit var rebuild: () -> Unit
        rebuild = {
            listContainer.removeAllViews()
            workingList.forEachIndexed { idx, node ->
                val row = LinearLayout(ctx).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, dp(4))
                    tag = node.id  // dùng lúc xử lý ACTION_DROP để tìm đúng vị trí hàng theo id, không theo idx (idx đổi mỗi lần rebuild)
                }
                // Tay cầm kéo — chạm giữ để bắt đầu kéo-thả đổi vị trí. Dùng
                // Android Drag & Drop framework chuẩn (View.startDragAndDrop),
                // KHÔNG cần RecyclerView/ItemTouchHelper — danh sách này vốn
                // là LinearLayout dựng tay, đổi sang RecyclerView chỉ để có
                // kéo-thả là việc lớn không cần thiết.
                row.addView(TextView(ctx).apply {
                    text = "☰"
                    textSize = 16f
                    setTextColor(Color.parseColor("#9ca3af"))
                    setPadding(dp(4), 0, dp(8), 0)
                    setOnLongClickListener { v ->
                        val clipData = android.content.ClipData.newPlainText("toc_node_id", node.id)
                        val shadow = View.DragShadowBuilder(row)
                        v.startDragAndDrop(clipData, shadow, row, 0)
                        true
                    }
                })
                row.addView(MaterialCheckBox(ctx).apply {
                    isChecked = selectedIds.contains(node.id)
                    setOnCheckedChangeListener { _, checked ->
                        if (checked) selectedIds.add(node.id) else selectedIds.remove(node.id)
                    }
                })
                row.addView(TextView(ctx).apply {
                    text = if (node.isGroup) "📁 ${node.label} (${node.children.size} chương)" else node.label
                    textSize = 13f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                })
                row.addView(smallButton("✏", "#6b7280") {
                    showPromptBottomSheet("Đổi tên hiển thị", node.label) { newLabel ->
                        workingList[idx] = node.copy(label = newLabel.ifBlank { node.label })
                        rebuild()
                    }
                })
                if (idx > 0) row.addView(smallButton("▲", "#6b7280") {
                    val t = workingList[idx]; workingList[idx] = workingList[idx - 1]; workingList[idx - 1] = t
                    rebuild()
                })
                if (idx < workingList.size - 1) row.addView(smallButton("▼", "#6b7280") {
                    val t = workingList[idx]; workingList[idx] = workingList[idx + 1]; workingList[idx + 1] = t
                    rebuild()
                })
                row.addView(smallButton("🗑", "#9ca3af") {
                    selectedIds.remove(node.id)
                    workingList.removeAt(idx)
                    rebuild()
                })
                listContainer.addView(row)
            }
        }
        rebuild()

        // Xử lý thả — xác định vị trí thả dựa trên toạ độ Y so với các hàng
        // hiện có, tìm đúng node đang kéo qua `tag` (id, không phải idx —
        // idx đổi mỗi lần rebuild() nên không dùng làm khoá ổn định được).
        listContainer.setOnDragListener { _, event ->
            when (event.action) {
                android.view.DragEvent.ACTION_DRAG_STARTED -> true
                android.view.DragEvent.ACTION_DROP -> {
                    val draggedId = event.clipData?.getItemAt(0)?.text?.toString() ?: return@setOnDragListener false
                    val fromIdx = workingList.indexOfFirst { it.id == draggedId }
                    if (fromIdx < 0) return@setOnDragListener false

                    var toIdx = workingList.size - 1
                    for (i in 0 until listContainer.childCount) {
                        val child = listContainer.getChildAt(i)
                        if (event.y < child.top + child.height / 2f) { toIdx = i; break }
                    }
                    if (fromIdx != toIdx) {
                        val item = workingList.removeAt(fromIdx)
                        workingList.add(toIdx.coerceIn(0, workingList.size), item)
                        rebuild()
                    }
                    true
                }
                else -> true
            }
        }

        groupBtn.setOnClickListener {
            if (selectedIds.size < 2) {
                Toast.makeText(ctx, "Chọn ít nhất 2 mục để gộp", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            showPromptBottomSheet("Gộp thành Tập", "", hint = "Tên tập, vd: Tập 1") { groupNameRaw ->
                val groupName = groupNameRaw.trim().ifBlank { "Tập mới" }
                val firstIdx = workingList.indexOfFirst { it.id in selectedIds }.coerceAtLeast(0)
                val members = workingList.filter { it.id in selectedIds }
                workingList.removeAll { it.id in selectedIds }
                val groupNode = TocNode(id = "grp_${System.currentTimeMillis()}", label = groupName, children = members)
                workingList.add(firstIdx.coerceIn(0, workingList.size), groupNode)
                selectedIds.clear()
                rebuild()
            }
        }

        showBottomSheet(
            title = "Sắp xếp mục lục",
            content = outer,
            maxHeightFraction = 0.75,
            saveLabel = "🚀 Xuất ebook",
            cancelLabel = "Đóng (giữ nguyên chờ)",
            onSave = {
                val updatedJob = job.copy(tocOverride = workingList.toList())
                LeechJobRepository.updateJob(ctx, slotIndex, updatedJob)
                EbookLeechScheduler.exportFromReview(ctx, slotIndex, updatedJob,
                    onDone = { _ -> Toast.makeText(ctx, "Đã xuất ebook", Toast.LENGTH_SHORT).show(); refreshJobList() },
                    onError = { msg -> Toast.makeText(ctx, "Lỗi xuất: $msg", Toast.LENGTH_LONG).show() }
                )
            }
        )
    }

    /** Bottom sheet 1 field duy nhất — thay cho pattern `EditText` + `AlertDialog` lặp lại nhiều lần. */
    private fun showPromptBottomSheet(title: String, initialValue: String, hint: String = "", onConfirm: (String) -> Unit) {
        val layout = TextInputLayout(ctx).apply {
            this.hint = hint.ifBlank { title }
            setPadding(dp(16), dp(4), dp(16), dp(4))
        }
        val et = TextInputEditText(ctx).apply { setText(initialValue); textSize = 14f }
        layout.addView(et)
        showBottomSheet(title, layout, onSave = { onConfirm(et.text.toString()) })
    }

    // -------------------------------------------------------------------------
    // Quản lý Dự án — thêm/đổi tên/xoá nhóm
    // -------------------------------------------------------------------------

    private fun showProjectManagerDialog() {
        val listContainer = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }

        fun rebuild() {
            listContainer.removeAllViews()
            val projects = LeechProjectRepository.loadAll(ctx, slotIndex)
            if (projects.isEmpty()) {
                listContainer.addView(TextView(ctx).apply {
                    text = "Chưa có dự án nào."
                    textSize = 12f
                    setTextColor(Color.parseColor("#888888"))
                    setPadding(0, dp(6), 0, dp(6))
                })
            }
            projects.forEach { project ->
                listContainer.addView(LinearLayout(ctx).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, dp(4))
                    addView(TextView(ctx).apply {
                        text = project.name
                        textSize = 13f
                        layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                    })
                    addView(smallButton("✏", "#6b7280") {
                        showPromptBottomSheet("Đổi tên dự án", project.name) { newName ->
                            LeechProjectRepository.renameProject(ctx, slotIndex, project.id, newName.trim().ifBlank { project.name })
                            rebuild(); refreshJobList()
                        }
                    })
                    addView(smallButton("🗑", "#9ca3af") {
                        val msg = TextView(ctx).apply {
                            text = "Job trong dự án này KHÔNG bị xoá — chỉ chuyển về nhóm \"Chưa phân nhóm\"."
                            textSize = 13f
                            setPadding(dp(16), dp(4), dp(16), dp(4))
                        }
                        showBottomSheet("Xoá dự án \"${project.name}\"?", msg, saveLabel = "Xoá", onSave = {
                            LeechProjectRepository.deleteProject(ctx, slotIndex, project.id)
                            rebuild(); refreshJobList()
                        })
                    })
                })
            }
        }
        rebuild()

        val addBtn = MaterialButton(ctx).apply {
            text = "+ Thêm dự án"
            textSize = 13f; minHeight = dp(44)
            setOnClickListener {
                showPromptBottomSheet("Thêm dự án", "", hint = "Tên dự án, vd: Truyện Kiếm Hiệp") { name ->
                    if (name.trim().isNotEmpty()) {
                        LeechProjectRepository.addProject(ctx, slotIndex, LeechProject(id = LeechProjectRepository.newId(), name = name.trim()))
                        rebuild(); refreshJobList()
                    }
                }
            }
        }
        val scroll = ScrollView(ctx).apply { addView(listContainer) }
        val outer = LinearLayout(ctx).apply {
            orientation = VERTICAL
            addView(scroll)
            addView(addBtn)
        }

        showBottomSheet("Quản lý dự án", outer, onSave = null, cancelLabel = "Đóng", maxHeightFraction = 0.7)
    }

    // -------------------------------------------------------------------------
    // Trạng thái proxy của khe — dùng lại NGUYÊN VẸN cơ chế proxy per-slot đã
    // có sẵn trong app (AppPrefs "proxy_type"/"proxy_host"/"proxy_port"/...,
    // đăng ký thật trong GeckoRuntimeProvider.createRuntime()) — KHÔNG tạo cơ
    // chế proxy RIÊNG cho EbookLeech (sẽ trùng lặp, dễ lệch cấu hình so với
    // phần Fingerprint Spoof đã có UI y hệt).
    // -------------------------------------------------------------------------

    private fun refreshProxyStatus() {
        val type = AppPrefs.getInt(ctx, slotIndex, "proxy_type", 0)
        val host = AppPrefs.getString(ctx, slotIndex, "proxy_host", "")
        val port = AppPrefs.getString(ctx, slotIndex, "proxy_port", "")
        proxyStatusText.text = if (type == 0 || host.isEmpty()) {
            "🌐 Proxy khe này: Trực tiếp (không qua proxy) — job cào sẽ dùng thẳng IP máy"
        } else {
            val kind = if (type == 2) "SOCKS5" else "HTTP"
            "🌐 Proxy khe này: $kind $host:$port — job cào tự động đi qua proxy này (chung cấu hình với Fingerprint Spoof)"
        }
    }

    /** ĐÃ THÊM — "xoay nhiều proxy" (xem giới hạn kiến trúc đầy đủ trong
     * ProxyPoolManager.kt). */
    private fun refreshProxyPoolStatus() {
        val pool = com.colablive.keeper.features.ebookleech.engine.ProxyPoolManager.loadPool(ctx, slotIndex)
        proxyPoolStatusText.text = if (pool.isEmpty()) {
            "🔁 Danh sách xoay vòng: chưa có — mỗi job MỚI khởi động sẽ dùng đúng proxy ở trên (không xoay)"
        } else {
            "🔁 Danh sách xoay vòng: ${pool.size} proxy — mỗi job MỚI khởi động tự chuyển sang proxy tiếp theo (CHỈ có hiệu lực từ lần khe khởi động lại kế tiếp, không đổi được giữa chừng 1 job đang chạy)"
        }
    }

    private fun buildProxyPool() {
        Toast.makeText(ctx, "Đang tìm & kiểm tra 5 proxy dự phòng còn sống, nhanh nhất…", Toast.LENGTH_SHORT).show()
        Thread {
            val pool = com.colablive.keeper.features.ebookleech.engine.ProxyPoolManager.buildPool(ctx, slotIndex, size = 5)
            (ctx as? android.app.Activity)?.runOnUiThread {
                refreshProxyPoolStatus()
                if (pool.isEmpty()) {
                    Toast.makeText(ctx, "Không tìm được proxy nào còn sống lúc này — thử lại sau", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(ctx, "Đã lưu ${pool.size} proxy dự phòng — job MỚI sẽ xoay vòng qua danh sách này", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun clearProxyPool() {
        com.colablive.keeper.features.ebookleech.engine.ProxyPoolManager.clearPool(ctx, slotIndex)
        refreshProxyPoolStatus()
        Toast.makeText(ctx, "Đã xoá danh sách proxy dự phòng", Toast.LENGTH_SHORT).show()
    }

    private fun autoFindProxyForSlot() {
        Toast.makeText(ctx, "Đang tìm proxy free còn sống, nhanh nhất cho khe này…", Toast.LENGTH_SHORT).show()
        Thread {
            val candidates = com.colablive.keeper.core.proxy.ProxyScraper.fetchCandidates()
            val best = com.colablive.keeper.core.proxy.ProxyHealthChecker.findFastestAlive(candidates)
            (ctx as? android.app.Activity)?.runOnUiThread {
                if (best == null) {
                    Toast.makeText(ctx, "Không tìm được proxy free nào còn sống lúc này — thử lại sau", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                val c = best.candidate
                AppPrefs.setString(ctx, slotIndex, "proxy_host", c.host)
                AppPrefs.setString(ctx, slotIndex, "proxy_port", c.port.toString())
                AppPrefs.setInt(ctx, slotIndex, "proxy_type", if (c.type == "socks") 2 else 1)
                refreshProxyStatus()
                Toast.makeText(
                    ctx,
                    "Đã lưu proxy ${c.host}:${c.port} (${best.latencyMs}ms) cho khe này — ĐÓNG RỒI MỞ LẠI khe để có hiệu lực (giống mọi thay đổi proxy khác trong app, không riêng gì EbookLeech)",
                    Toast.LENGTH_LONG,
                ).show()
            }
        }.start()
    }

    // -------------------------------------------------------------------------
    // Quản lý plugin — nạp file .jar mới KHÔNG cần adb/PC (mục nợ kỹ thuật cũ)
    // -------------------------------------------------------------------------

    /**
     * Cho phép chọn trực tiếp file `.jar` vừa build (vd tải về từ GitHub
     * Actions Artifacts ngay trên điện thoại) qua SAF, copy vào đúng thư
     * mục `PluginLoader.pluginDir()`, rồi nạp lại — KHÔNG cần `adb push`,
     * KHÔNG cần khởi động lại app. Ghi đè đúng 1 tên file cố định để tránh
     * 2 bản EbookLeech cùng nạp song song (trùng entry-points → lỗi khó hiểu).
     */
    private fun importPluginJar() {
        FolderPickerBridge.requestFile(
            ctx,
            arrayOf("application/java-archive", "application/octet-stream", "application/zip", "*/*"),
        ) { uri ->
            if (uri == null) return@requestFile
            try {
                val destFile = File(PluginLoader.pluginDir(ctx), "ebookleech-plugin.jar")
                ctx.contentResolver.openInputStream(uri)?.use { input ->
                    destFile.outputStream().use { output -> input.copyTo(output) }
                } ?: throw java.io.IOException("Không đọc được file đã chọn")
                PluginLoader.reset()
                FeatureRegistry.init(ctx)
                Toast.makeText(ctx, "Đã nạp plugin mới — có hiệu lực ngay, không cần khởi động lại app", Toast.LENGTH_LONG).show()
                refreshJobList()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Lỗi nạp .jar: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Chỉ quét lại `PluginLoader.pluginDir()` — dùng khi file `.jar` đã được
     * đặt sẵn vào đúng thư mục bằng cách khác (vd trình quản lý file, adb). */
    private fun reloadPluginOnly() {
        PluginLoader.reset()
        FeatureRegistry.init(ctx)
        Toast.makeText(ctx, "Đã nạp lại plugin", Toast.LENGTH_SHORT).show()
        refreshJobList()
    }

    // -------------------------------------------------------------------------
    // Sao lưu / Khôi phục cấu hình
    // -------------------------------------------------------------------------

    private fun doBackup() {
        try {
            val path = EbookLeechBackupManager.exportToFile(ctx, slotIndex)
            val msg = TextView(ctx).apply {
                text = "Cấu hình (dự án + job, kèm trạng thái đang chạy dở nếu có) đã lưu vào:\n\n$path"
                textSize = 14f
                setPadding(dp(16), dp(4), dp(16), dp(4))
            }
            showBottomSheet("Đã sao lưu", msg, onSave = null, cancelLabel = "OK")
        } catch (e: Exception) {
            Toast.makeText(ctx, "Lỗi sao lưu: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * ĐÃ SỬA (mục nợ kỹ thuật 5.2 cũ): trước đây CHỈ liệt kê file trong
     * đúng `Downloads/EbookLeech/Backup` — không phục hồi được file backup
     * nằm chỗ khác (vd nhận qua Zalo/Drive tải về thư mục `Download` gốc,
     * hay copy từ máy khác vào USB-OTG). Giờ luôn có thêm nút chọn file
     * bất kỳ qua SAF, không phụ thuộc đúng 1 thư mục cố định.
     */
    // -------------------------------------------------------------------------
    // Preset site — xem docstring đầy đủ trong SitePreset.kt (khác Sao lưu/
    // Khôi phục thế nào)
    // -------------------------------------------------------------------------

    private fun showSitePresetPicker(onPicked: (com.colablive.keeper.features.ebookleech.model.SitePreset) -> Unit) {
        val presets = com.colablive.keeper.features.ebookleech.model.SitePresetRepository.loadAll(ctx, slotIndex)
        val listContainer = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        if (presets.isEmpty()) {
            listContainer.addView(TextView(ctx).apply {
                text = "Chưa có preset nào — cào 1 job thành công rồi bấm \"💾 Lưu selector này làm preset\" để dùng lại cho các truyện KHÁC cùng site (site cùng theme/CMS thường dùng chung 1 bộ selector)."
                textSize = 12f
                setTextColor(Color.parseColor("#666666"))
                setPadding(dp(4), dp(4), dp(4), dp(4))
            })
        } else {
            presets.forEach { p ->
                listContainer.addView(LinearLayout(ctx).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(MaterialButton(ctx).apply {
                        text = p.name
                        textSize = 13f
                        minHeight = dp(48)
                        layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                        setOnClickListener { onPicked(p) }
                    })
                    addView(smallButton("🗑", "#9ca3af") {
                        com.colablive.keeper.features.ebookleech.model.SitePresetRepository.delete(ctx, slotIndex, p.id)
                        Toast.makeText(ctx, "Đã xoá preset \"${p.name}\"", Toast.LENGTH_SHORT).show()
                        showSitePresetPicker(onPicked)  // mở lại danh sách đã cập nhật
                    })
                })
            }
        }
        showBottomSheet("Chọn preset site", listContainer, onSave = null, cancelLabel = "Đóng", maxHeightFraction = 0.6)
    }

    // -------------------------------------------------------------------------
    // Cấu hình GitHub (cào từ xa) — xem docstring RemoteCrawlRunner.kt cho
    // giới hạn đầy đủ của tính năng này.
    // -------------------------------------------------------------------------

    private fun showGitHubConfigDialog() {
        val cfg = com.colablive.keeper.features.ebookleech.remote.GitHubRemoteConfig.load(ctx, slotIndex)
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }

        val ownerEt = TextInputEditText(ctx).apply { setText(cfg.owner); textSize = 14f }
        form.addView(TextInputLayout(ctx).apply { hint = "Chủ repo (owner), vd: nguyenvana"; addView(ownerEt) })

        val repoEt = TextInputEditText(ctx).apply { setText(cfg.repo); textSize = 14f }
        form.addView(TextInputLayout(ctx).apply { hint = "Tên repo, vd: colab-live-browser-repo"; addView(repoEt) })

        val branchEt = TextInputEditText(ctx).apply { setText(cfg.branch); textSize = 14f }
        form.addView(TextInputLayout(ctx).apply { hint = "Nhánh (branch), mặc định main"; addView(branchEt) })

        val tokenEt = TextInputEditText(ctx).apply {
            hint = if (cfg.hasToken) "Đã lưu — để trống nếu không đổi" else "Personal Access Token (scope: repo, workflow)"
            textSize = 14f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        form.addView(TextInputLayout(ctx).apply {
            hint = if (cfg.hasToken) "Token (đã lưu — để trống nếu không đổi)" else "Personal Access Token"
            addView(tokenEt)
        })

        form.addView(TextView(ctx).apply {
            text = "Token cần quyền \"repo\" (đọc/ghi Contents API) và \"workflow\" (kích hoạt Actions). " +
                "Tạo tại github.com → Settings → Developer settings → Personal access tokens. " +
                "Token được mã hoá bằng khoá lưu trong AndroidKeyStore của máy — không gửi đi đâu ngoài đúng API GitHub."
            textSize = 11f
            setTextColor(Color.parseColor("#666666"))
            setPadding(0, dp(6), 0, dp(4))
        })

        showBottomSheet(
            "Cấu hình GitHub (cào từ xa)", form,
            onSave = {
                val owner = ownerEt.text.toString().trim()
                val repo = repoEt.text.toString().trim()
                val branch = branchEt.text.toString().trim()
                val tokenInput = tokenEt.text.toString().trim()
                if (owner.isEmpty() || repo.isEmpty()) {
                    Toast.makeText(ctx, "Cần nhập owner + tên repo", Toast.LENGTH_SHORT).show()
                    return@showBottomSheet
                }
                // null = giữ nguyên token cũ (không nhập gì) — xem GitHubRemoteConfig.save()
                val tokenToSave = if (tokenInput.isEmpty()) null else tokenInput
                com.colablive.keeper.features.ebookleech.remote.GitHubRemoteConfig.save(ctx, slotIndex, owner, repo, branch, tokenToSave)
                Toast.makeText(ctx, "Đã lưu cấu hình GitHub", Toast.LENGTH_SHORT).show()
            },
            extraButton = if (cfg.hasToken) "🗑 Xoá token" to {
                com.colablive.keeper.features.ebookleech.remote.SecureTokenStore.clear(ctx)
                Toast.makeText(ctx, "Đã xoá token", Toast.LENGTH_SHORT).show()
            } else null,
            maxHeightFraction = 0.75,
        )
    }

    private fun showSavePresetDialog(
        patternEt: EditText, chLinkEt: EditText, chAttrEt: EditText, chTitleEt: EditText, chContentEt: EditText,
    ) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val nameLayout = TextInputLayout(ctx).apply { hint = "Tên preset (vd: TruyenFull-style)" }
        val presetNameEt = TextInputEditText(ctx).apply { hint = "Tên preset (vd: TruyenFull-style)"; textSize = 14f }
        nameLayout.addView(presetNameEt)
        form.addView(nameLayout)
        form.addView(TextView(ctx).apply {
            text = "Lưu đúng 4 selector CSS ở trên (không lưu URL truyện) — dùng lại khi tạo job cho truyện khác CÙNG site này."
            textSize = 11f
            setTextColor(Color.parseColor("#666666"))
            setPadding(0, dp(4), 0, 0)
        })
        showBottomSheet("Lưu selector hiện tại làm preset", form, onSave = {
            val name = presetNameEt.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(ctx, "Chưa nhập tên preset", Toast.LENGTH_SHORT).show()
                return@showBottomSheet
            }
            com.colablive.keeper.features.ebookleech.model.SitePresetRepository.add(
                ctx, slotIndex,
                com.colablive.keeper.features.ebookleech.model.SitePreset(
                    name = name,
                    listPageUrlPattern = patternEt.text.toString().trim(),
                    chapterLinkSelector = chLinkEt.text.toString().trim(),
                    chapterLinkAttribute = chAttrEt.text.toString().trim().ifBlank { "href" },
                    chapterTitleSelector = chTitleEt.text.toString().trim(),
                    chapterContentSelector = chContentEt.text.toString().trim(),
                ),
            )
            Toast.makeText(ctx, "Đã lưu preset \"$name\"", Toast.LENGTH_SHORT).show()
        })
    }

    private fun showRestoreDialog() {
        val backupDir = File(
            android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS),
            "EbookLeech/Backup"
        )
        val files = backupDir.listFiles { f -> f.isFile && f.name.endsWith(".json") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()

        val listContainer = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        listContainer.addView(MaterialButton(ctx).apply {
            text = "📂 Chọn file backup khác…"
            textSize = 13f
            minHeight = dp(48)
            setOnClickListener { pickRestoreFileViaSaf() }
        })
        if (files.isEmpty()) {
            listContainer.addView(TextView(ctx).apply {
                text = "Không tìm thấy file nào trong Downloads/EbookLeech/Backup — dùng nút chọn file ở trên nếu file backup nằm chỗ khác."
                textSize = 12f
                setTextColor(Color.parseColor("#666666"))
                setPadding(dp(4), dp(8), dp(4), dp(4))
            })
        } else {
            files.forEach { f ->
                listContainer.addView(MaterialButton(ctx).apply {
                    text = f.name
                    textSize = 13f
                    minHeight = dp(48)
                    setOnClickListener { showRestoreModeSheet(f) }
                })
            }
        }
        showBottomSheet("Chọn file sao lưu để khôi phục", listContainer, onSave = null, cancelLabel = "Đóng", maxHeightFraction = 0.6)
    }

    /** Chọn 1 file JSON bất kỳ qua SAF, copy tạm vào cache riêng của app
     * (import cần đường dẫn filesystem thật, không dùng thẳng `content://`
     * được vì `EbookLeechBackupManager.importFromFile` đọc bằng `File`),
     * rồi mở đúng màn hình chọn Gộp/Thay thế như file liệt kê sẵn. */
    private fun pickRestoreFileViaSaf() {
        FolderPickerBridge.requestFile(ctx, arrayOf("application/json", "*/*")) { uri ->
            if (uri == null) return@requestFile
            try {
                val tmp = File(ctx.cacheDir, "ebookleech_restore_import.json")
                ctx.contentResolver.openInputStream(uri)?.use { input ->
                    tmp.outputStream().use { output -> input.copyTo(output) }
                } ?: throw java.io.IOException("Không đọc được file đã chọn")
                showRestoreModeSheet(tmp)
            } catch (e: Exception) {
                Toast.makeText(ctx, "Không đọc được file: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showRestoreModeSheet(file: File) {
        val content = LinearLayout(ctx).apply {
            orientation = VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(4))
            addView(TextView(ctx).apply {
                text = "GỘP: giữ job/dự án hiện có, chỉ thêm cái chưa tồn tại.\nTHAY THẾ: xoá hết cấu hình hiện tại, nạp hoàn toàn từ file."
                textSize = 13f
                setPadding(0, 0, 0, dp(8))
            })
        }
        showBottomSheet(
            title = "Cách khôi phục — ${file.name}",
            content = content,
            saveLabel = "Gộp",
            extraButton = "Thay thế" to { runImport(file.absolutePath, EbookLeechBackupManager.ImportMode.REPLACE) },
            onSave = { runImport(file.absolutePath, EbookLeechBackupManager.ImportMode.MERGE) }
        )
    }

    private fun runImport(path: String, mode: EbookLeechBackupManager.ImportMode) {
        val result = EbookLeechBackupManager.importFromFile(ctx, slotIndex, path, mode)
        if (result.error != null) {
            Toast.makeText(ctx, "Lỗi khôi phục: ${result.error}", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(ctx, "Đã khôi phục ${result.jobCount} job, ${result.projectCount} dự án", Toast.LENGTH_LONG).show()
            // Nếu file backup có job đang RUNNING/NEEDS_ACTION kèm checkpoint
            // (đã bật lưu trạng thái chạy vào backup) — cào tiếp NGAY, không
            // cần đợi app khởi động lại mới tự khôi phục.
            EbookLeechScheduler.resumeInterruptedJobs(ctx, slotIndex)
            refreshJobList()
        }
    }

    // -------------------------------------------------------------------------
    // Open file
    // -------------------------------------------------------------------------

    // -------------------------------------------------------------------------
    // Kịch bản cào — luồng các bước tường minh, chạm từng bước để sửa riêng
    // -------------------------------------------------------------------------

    /**
     * Hiện toàn bộ luồng hành động của 1 job dưới dạng danh sách bước có
     * đánh số, MỖI BƯỚC PHẢN ÁNH ĐÚNG cấu hình hiện tại (bước nào đang tắt
     * thì không hiện) — chạm vào 1 bước mở dialog sửa RIÊNG bước đó (không
     * phải form khổng lồ). Đây là lớp UI "dễ hiểu" nằm TRÊN cấu hình kỹ
     * thuật thật (LeechJob) — sửa ở đây tương đương sửa trong "✏ Sửa toàn
     * bộ", chỉ khác cách trình bày.
     */
    private fun showScenarioView(jobIn: LeechJob) {
        // Luôn đọc lại job mới nhất từ repo — tránh hiện dữ liệu cũ nếu vừa
        // sửa 1 bước rồi mở lại kịch bản.
        val job = LeechJobRepository.getJob(ctx, slotIndex, jobIn.id) ?: jobIn

        val container = LinearLayout(ctx).apply {
            orientation = VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(8))
        }

        container.addView(TextView(ctx).apply {
            text = "Chạm vào từng bước để xem & sửa riêng bước đó. Muốn bật thêm tính năng chưa có trong danh sách (kịch bản nhiều bước, tải ảnh...) → dùng \"Sửa toàn bộ\"."
            textSize = 11f
            setTextColor(Color.parseColor("#6b7280"))
            setPadding(0, 0, 0, dp(10))
        })

        var stepNo = 1
        fun step(title: String, summary: String, colorHex: String = "#2563eb", onEdit: () -> Unit) {
            container.addView(buildScenarioStepRow(stepNo++, title, summary, colorHex, onEdit))
        }

        job.preListStages.forEachIndexed { idx, stage ->
            step("Bước phụ: ${stage.label}", "Thu link qua selector: ${stage.linkSelector.ifBlank { "(chưa đặt)" }}", "#7c3aed") {
                showEditStageDialog(job, idx)
            }
        }

        step("Vào trang danh sách chương", job.listPageUrl.ifBlank { "(chưa đặt URL)" }) {
            showEditListPageDialog(job)
        }

        if (job.autoDetectPagination || job.listPageUrlPattern.isNotBlank()) {
            step(
                "Lật qua các trang danh sách (phân trang)",
                if (job.autoDetectPagination) "Tự dò cách phân trang, tối đa ${job.maxPages} trang"
                else "Pattern: ${job.listPageUrlPattern}, tối đa ${job.maxPages} trang"
            ) { showEditListPageDialog(job) }
        }

        step("Thu thập link từng chương trên mỗi trang", "Selector: ${job.chapterLinkSelector.ifBlank { "(chưa đặt)" }}") {
            showEditLinkSelectorDialog(job)
        }

        step("Mở lần lượt từng trang chương", "Delay ${job.delayBetweenPagesMs}ms giữa mỗi lần mở", "#6b7280") {
            showEditTimingDialog(job)
        }

        if (job.simulateScrollForLazyLoad) {
            step("Tự cuộn trang trước khi lấy nội dung (lazy-load)", "Tối đa ${job.maxScrollAttempts} lần cuộn", "#0891b2") {
                showEditLazyLoadDialog(job)
            }
        }

        step("Lấy tiêu đề chương", "Selector: ${job.chapterTitleSelector.ifBlank { "(chưa đặt)" }}") {
            showEditChapterFieldsDialog(job)
        }
        step("Lấy nội dung chương", "Selector: ${job.chapterContentSelector.ifBlank { "(chưa đặt)" }}") {
            showEditChapterFieldsDialog(job)
        }

        if (job.downloadImages) {
            step("Tải ảnh trong chương về máy", "Tối đa ${job.maxImagesPerChapter} ảnh/chương", "#059669") {
                showEditImagesDialog(job)
            }
        }

        step(
            "Áp luật tìm & thay thế lên tiêu đề/nội dung",
            if (job.regexRules.isEmpty()) "Chưa có luật nào" else "${job.regexRules.size} luật đang bật",
            "#d97706"
        ) { showEditRulesDialog(job) }

        if (job.suggestAjaxEndpoints) {
            step(
                "Dò endpoint AJAX (chỉ gợi ý — KHÔNG phải chọn selector)",
                if (job.detectedAjaxEndpoints.isEmpty()) "Chưa phát hiện endpoint nào lần cào gần nhất"
                else "${job.detectedAjaxEndpoints.size} URL nghi vấn — chạm để xem & mở từng cái",
                "#0891b2"
            ) { showAjaxEndpointsDialog(job) }
        }

        if (job.useLoginSession) {
            step("Dùng phiên đăng nhập có sẵn trong app", "Chia sẻ cookie với tab thường trong khe này", "#dc2626") {
                showEditLoginDialog(job)
            }
        }

        if (job.publishToWordPress) {
            step(
                "Đăng lên WordPress (mỗi chương = 1 bài)",
                job.wpSiteUrl.ifBlank { "(chưa đặt site)" } + " • trạng thái: ${job.wpPostStatus}",
                "#2271b1"  // màu xanh WordPress
            ) { showEditWordPressDialog(job) }
        }

        step(
            if (job.manualTocReview) "Dừng lại, chờ sắp xếp mục lục" else "Tự động xuất ebook ngay sau khi cào xong",
            "Định dạng: ${job.outputFormat.name}" + (job.outputFileName.let { if (it.isNotBlank()) " • Tên file: $it" else "" }),
            "#7c3aed"
        ) { showEditExportDialog(job) }

        showBottomSheet("🗺️ Kịch bản cào — ${job.name}", container, onSave = null, cancelLabel = "Đóng", maxHeightFraction = 0.7)
    }

    /** 1 hàng bước trong kịch bản: số thứ tự tròn + tiêu đề + tóm tắt + chevron, chạm cả hàng để sửa. */
    private fun buildScenarioStepRow(number: Int, title: String, summary: String, colorHex: String, onEdit: () -> Unit): View {
        val row = LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#f9fafb"))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isClickable = true
            isFocusable = true
            val lp = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(6)
            layoutParams = lp
            setOnClickListener { onEdit() }
        }
        row.addView(TextView(ctx).apply {
            text = number.toString()
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.parseColor(colorHex))
            }
            layoutParams = LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginEnd = dp(10) }
        })
        row.addView(LinearLayout(ctx).apply {
            orientation = VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
            addView(TextView(ctx).apply {
                text = title
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#1a1a1a"))
            })
            addView(TextView(ctx).apply {
                text = summary
                textSize = 11f
                setTextColor(Color.parseColor("#6b7280"))
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
        })
        row.addView(TextView(ctx).apply {
            text = "›"
            textSize = 20f
            setTextColor(Color.parseColor("#9ca3af"))
        })
        return row
    }

    // -------------------------------------------------------------------------
    // Helper Material Design cho UI Kịch bản — Bottom Sheet thay AlertDialog,
    // TextInputLayout thay EditText trần. Đây là phần trả lời trực tiếp câu
    // hỏi "UI kịch bản có tối ưu UX di động không" — trước đó KHÔNG (AlertDialog
    // giữa màn hình, field trần), giờ dùng đúng pattern di động chuẩn: Bottom
    // Sheet trượt lên từ đáy màn hình (dễ với tới bằng ngón cái khi cầm 1 tay),
    // TextInputLayout có nhãn nổi + đường viền rõ ràng hơn EditText trần.
    // -------------------------------------------------------------------------

    /**
     * Hiện `content` trong 1 Bottom Sheet có tiêu đề + hàng nút Lưu/Huỷ cố
     * định ở đáy (không cuộn theo nội dung — luôn với tới được dù nội dung
     * dài). Thay hoàn toàn cho `AlertDialog.Builder().setPositiveButton()`
     * trong toàn bộ UI Kịch bản.
     */
    private fun showBottomSheet(
        title: String,
        content: View,
        onSave: (() -> Unit)?,   // null = không có nút Lưu (dùng cho showScenarioView, chỉ có Đóng)
        extraButton: Pair<String, () -> Unit>? = null,  // vd nút "🗑 Xoá bước này"
        maxHeightFraction: Double = 0.55,  // form dài (vd "Sửa toàn bộ") truyền 0.85
        cancelable: Boolean = true,
        saveLabel: String = "Lưu",
        cancelLabel: String = "Huỷ",
        onCancel: (() -> Unit)? = null,  // gọi thêm khi bấm Huỷ, vd dừng element picker
    ) {
        val sheet = BottomSheetDialog(ctx)
        sheet.setCancelable(cancelable)
        val outer = LinearLayout(ctx).apply {
            orientation = VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        outer.addView(TextView(ctx).apply {
            text = title
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(16), dp(16), dp(16), dp(8))
        })

        val scrollableContent = ScrollView(ctx).apply {
            // Giới hạn chiều cao tối đa để hàng nút Lưu/Huỷ LUÔN hiện, không
            // bị đẩy ra ngoài màn hình bởi nội dung dài (khác lỗi thường gặp
            // của AlertDialog khi nội dung dài che mất nút).
            val maxH = (ctx.resources.displayMetrics.heightPixels * maxHeightFraction).toInt()
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            addView(content)
            post { if (height > maxH) layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH) }
        }
        outer.addView(scrollableContent)

        outer.addView(LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.END
            setPadding(dp(12), dp(8), dp(12), dp(16))

            // Nút hàng dưới dialog nên là dạng "text button" (nền trong suốt,
            // chỉ chữ màu) — KHÔNG dùng style resource cụ thể của Material
            // (vd R.attr.materialButtonOutlinedStyle) để tránh phụ thuộc đúng
            // version AAR chưa build thử (bài học từ compileOnly project(':app')
            // — ưu tiên an toàn hơn hoàn hảo). Tự đạt hiệu ứng tương đương bằng
            // cách set backgroundTint trong suốt + bỏ elevation, vẫn giữ được
            // ripple chạm (MaterialButton tự vẽ ripple riêng, không phụ thuộc
            // backgroundTint).
            fun textStyleButton() = MaterialButton(ctx).apply {
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.TRANSPARENT)
                elevation = 0f
                stateListAnimator = null
                minHeight = dp(44)
                textSize = 14f
            }

            if (extraButton != null) {
                addView(textStyleButton().apply {
                    text = extraButton.first
                    setTextColor(Color.parseColor("#dc2626"))
                    setOnClickListener { sheet.dismiss(); extraButton.second() }
                })
                addView(View(ctx).apply { layoutParams = LinearLayout.LayoutParams(0, 0, 1f) })  // đẩy nút chính sang phải
            }

            addView(textStyleButton().apply {
                text = cancelLabel
                setTextColor(Color.parseColor("#6b7280"))
                setOnClickListener { sheet.dismiss(); onCancel?.invoke() }
            })
            if (onSave != null) {
                addView(textStyleButton().apply {
                    text = saveLabel
                    setTextColor(Color.parseColor("#2563eb"))
                    setTypeface(typeface, Typeface.BOLD)
                    setOnClickListener { sheet.dismiss(); onSave() }
                })
            }
        })

        sheet.setContentView(outer)
        sheet.show()
    }

    /**
     * Dropdown kiểu Material ("Exposed Dropdown Menu") — thay `Spinner` mặc
     * định (widget cũ, không theo phong cách Material, không có nhãn nổi).
     * Trả về `AutoCompleteTextView` — dùng `options.indexOf(view.text.toString())`
     * lúc lưu để lấy lại vị trí đã chọn (thay `spinner.selectedItemPosition`).
     * KHÔNG dùng resource style ID cụ thể của Material (`R.style.Widget_...
     * ExposedDropdownMenu`) để tránh phụ thuộc đúng version AAR chưa build
     * thử — dựng thủ công bằng API chuẩn (`inputType=TYPE_NULL` chặn gõ tay,
     * `threshold=0` để bấm là hiện dropdown ngay) vẫn cho đúng hành vi, an
     * toàn hơn khi chưa xác nhận được trên máy thật.
     */
    private fun materialDropdown(container: LinearLayout, label: String, options: List<String>, selectedIndex: Int): AutoCompleteTextView {
        val layout = TextInputLayout(ctx).apply {
            hint = label
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            }
        }
        val actv = AutoCompleteTextView(ctx).apply {
            setAdapter(ArrayAdapter(ctx, android.R.layout.simple_list_item_1, options))
            setText(options.getOrElse(selectedIndex) { options.firstOrNull() ?: "" }, false)
            inputType = InputType.TYPE_NULL   // chặn bàn phím — chỉ chọn qua danh sách thả xuống
            keyListener = null
            threshold = 0
            textSize = 14f
            setOnClickListener { showDropDown() }
            setOnFocusChangeListener { _, hasFocus -> if (hasFocus) showDropDown() }
        }
        layout.addView(actv)
        container.addView(layout)
        return actv
    }

    /** Field kiểu Material — nhãn nổi (floating label) thay TextView rời phía trên. */
    private fun materialField(container: LinearLayout, label: String, hint: String, value: String): EditText {
        val layout = TextInputLayout(ctx).apply {
            this.hint = label
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            }
        }
        val et = TextInputEditText(ctx).apply {
            this.hint = hint
            setText(value)
            textSize = 14f
        }
        layout.addView(et)
        container.addView(layout)
        return et
    }

    /** Field Material + nút "🎯 Chọn" cạnh bên — dùng cho selector cần picker. */
    private fun materialPickerField(container: LinearLayout, label: String, hint: String, value: String, pickerMode: String): EditText {
        val row = LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.BOTTOM  // canh đáy vì TextInputLayout cao hơn nút do có label nổi phía trên
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val layout = TextInputLayout(ctx).apply {
            this.hint = label
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = dp(8) }
        }
        val et = TextInputEditText(ctx).apply { this.hint = hint; setText(value); textSize = 14f }
        layout.addView(et)
        row.addView(layout)
        row.addView(smallButton("🎯 Chọn", "#059669") {
            startElementPicking(pickerMode) { picked -> et.setText(picked) }
        }.apply { (layoutParams as LinearLayout.LayoutParams).bottomMargin = dp(8) })
        container.addView(row)
        return et
    }

    private fun saveStepAndRefresh(updated: LeechJob) {
        LeechJobRepository.updateJob(ctx, slotIndex, updated)
        refreshJobList()
        showScenarioView(updated)  // mở lại kịch bản để thấy ngay thay đổi
    }

    // -------------------------------------------------------------------------
    // Dialog sửa riêng từng bước — TOÀN BỘ dùng Bottom Sheet + field Material
    // -------------------------------------------------------------------------

    private fun showEditListPageDialog(job: LeechJob) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val urlEt = materialField(form, "URL trang danh sách (trang 1)", "https://...", job.listPageUrl)
        val patternEt = materialField(form, "Pattern phân trang (tuỳ chọn)", "https://site.com?page={page}", job.listPageUrlPattern)
        val maxPagesEt = materialField(form, "Số trang tối đa", "50", job.maxPages.toString())
        val autoCb = MaterialCheckBox(ctx).apply {
            text = "Tự dò cách phân trang (bỏ trống Pattern để dùng)"
            textSize = 13f; isChecked = job.autoDetectPagination
            minHeight = dp(44)
            form.addView(this)
        }
        showBottomSheet("Bước: Vào trang danh sách & phân trang", form, onSave = {
            saveStepAndRefresh(job.copy(
                listPageUrl = urlEt.text.toString().trim(),
                listPageUrlPattern = patternEt.text.toString().trim(),
                maxPages = maxPagesEt.text.toString().toIntOrNull() ?: job.maxPages,
                autoDetectPagination = autoCb.isChecked,
            ))
        })
    }

    private fun showEditLinkSelectorDialog(job: LeechJob) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val selEt = materialPickerField(form, "Selector link chương", ".chapter-list a", job.chapterLinkSelector, "list")
        val attrEt = materialField(form, "Thuộc tính chứa URL", "href", job.chapterLinkAttribute)
        showBottomSheet("Bước: Thu thập link chương", form, onSave = {
            saveStepAndRefresh(job.copy(
                chapterLinkSelector = selEt.text.toString().trim(),
                chapterLinkAttribute = attrEt.text.toString().trim().ifBlank { "href" },
            ))
        })
    }

    private fun showEditChapterFieldsDialog(job: LeechJob) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val titleEt = materialPickerField(form, "Selector tiêu đề chương", "h2.chapter-title", job.chapterTitleSelector, "single")
        val contentEt = materialPickerField(form, "Selector nội dung chương", "div.chapter-content", job.chapterContentSelector, "single")
        showBottomSheet("Bước: Lấy tiêu đề & nội dung chương", form, onSave = {
            saveStepAndRefresh(job.copy(
                chapterTitleSelector = titleEt.text.toString().trim(),
                chapterContentSelector = contentEt.text.toString().trim(),
            ))
        })
    }

    private fun showEditTimingDialog(job: LeechJob) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val delayEt = materialField(form, "Delay giữa các lần mở trang (ms)", "1500", job.delayBetweenPagesMs.toString())
        val uaEt = materialField(form, "User-Agent tuỳ chỉnh (tuỳ chọn)", "", job.customUserAgent)
        val cookieEt = materialField(form, "Cookie header tuỳ chỉnh (tuỳ chọn)", "session=abc123", job.cookieHeader)
        showBottomSheet("Bước: Mở từng trang chương", form, onSave = {
            saveStepAndRefresh(job.copy(
                delayBetweenPagesMs = delayEt.text.toString().toLongOrNull() ?: job.delayBetweenPagesMs,
                customUserAgent = uaEt.text.toString().trim(),
                cookieHeader = cookieEt.text.toString().trim(),
            ))
        })
    }

    private fun showEditLazyLoadDialog(job: LeechJob) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val enabledCb = MaterialCheckBox(ctx).apply {
            text = "Tự cuộn trang trước khi lấy nội dung"; textSize = 13f; minHeight = dp(44)
            isChecked = job.simulateScrollForLazyLoad
            form.addView(this)
        }
        val maxAttemptsEt = materialField(form, "Số lần cuộn tối đa", "6", job.maxScrollAttempts.toString())
        showBottomSheet("Bước: Tự cuộn cho site lazy-load", form, onSave = {
            saveStepAndRefresh(job.copy(
                simulateScrollForLazyLoad = enabledCb.isChecked,
                maxScrollAttempts = maxAttemptsEt.text.toString().toIntOrNull() ?: job.maxScrollAttempts,
            ))
        })
    }

    private fun showEditImagesDialog(job: LeechJob) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val enabledCb = MaterialCheckBox(ctx).apply {
            text = "Tải ảnh trong chương về máy, nhúng offline"; textSize = 13f; minHeight = dp(44)
            isChecked = job.downloadImages
            form.addView(this)
        }
        val maxImagesEt = materialField(form, "Số ảnh tối đa / chương", "30", job.maxImagesPerChapter.toString())
        showBottomSheet("Bước: Tải ảnh", form, onSave = {
            saveStepAndRefresh(job.copy(
                downloadImages = enabledCb.isChecked,
                maxImagesPerChapter = maxImagesEt.text.toString().toIntOrNull() ?: job.maxImagesPerChapter,
            ))
        })
    }

    private fun showAjaxEndpointsDialog(job: LeechJob) {
        val outer = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        outer.addView(TextView(ctx).apply {
            text = "⚠️ Đây CHỈ LÀ URL gợi ý — KHÔNG PHẢI CSS selector, không tự điền vào bất kỳ ô selector nào. " +
                "Muốn dùng, bạn cần tự mở URL xem nó trả về JSON gì, rồi tự quyết định có dùng được không " +
                "(hiện addon chưa có bước tự động parse JSON từ đây). Muốn chọn CSS selector để cào, dùng nút \"🎯 Chọn\" ở các bước khác."
            textSize = 12f
            setTextColor(Color.parseColor("#991b1b"))
            setPadding(0, 0, 0, dp(10))
        })

        val cb = MaterialCheckBox(ctx).apply {
            text = "Bật dò endpoint AJAX cho job này"
            textSize = 13f; minHeight = dp(44)
            isChecked = job.suggestAjaxEndpoints
            outer.addView(this)
        }

        if (job.detectedAjaxEndpoints.isEmpty()) {
            outer.addView(TextView(ctx).apply {
                text = "Chưa phát hiện endpoint nào — chạy job ít nhất 1 lần với ô trên đã tick để có kết quả."
                textSize = 12f
                setTextColor(Color.parseColor("#6b7280"))
                setPadding(0, dp(8), 0, 0)
            })
        } else {
            job.detectedAjaxEndpoints.forEach { url ->
                outer.addView(LinearLayout(ctx).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(6))
                    addView(TextView(ctx).apply {
                        text = url
                        textSize = 12f
                        maxLines = 2
                        ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                        layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                    })
                    addView(smallButton("🔗 Mở", "#2563eb") {
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "Không mở được URL này", Toast.LENGTH_SHORT).show()
                        }
                    })
                })
            }
        }

        showBottomSheet("Bước: Dò endpoint AJAX (gợi ý)", outer, onSave = {
            saveStepAndRefresh(job.copy(suggestAjaxEndpoints = cb.isChecked))
        })
    }

    private fun showEditLoginDialog(job: LeechJob) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val cb = MaterialCheckBox(ctx).apply {
            text = "Dùng đăng nhập có sẵn trong app (ghi vào lịch sử duyệt web)"; textSize = 13f; minHeight = dp(44)
            isChecked = job.useLoginSession
            form.addView(this)
        }
        showBottomSheet("Bước: Phiên đăng nhập", form, onSave = {
            saveStepAndRefresh(job.copy(useLoginSession = cb.isChecked))
        })
    }

    private fun showEditWordPressDialog(job: LeechJob) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }

        form.addView(TextView(ctx).apply {
            text = "Đăng mỗi chương thành 1 bài viết WordPress qua REST API. Lấy Application Password: " +
                "WP Admin → Users → Profile → mục \"Application Passwords\" → đặt tên tuỳ ý → Add New."
            textSize = 12f
            setTextColor(Color.parseColor("#6b7280"))
            setPadding(0, 0, 0, dp(6))
        })

        val enabledCb = MaterialCheckBox(ctx).apply {
            text = "Bật đăng WordPress cho job này"; textSize = 13f; minHeight = dp(44)
            isChecked = job.publishToWordPress
            form.addView(this)
        }

        val siteUrlEt = materialField(form, "URL site WordPress", "https://mysite.com (không có / cuối)", job.wpSiteUrl)
        val usernameEt = materialField(form, "Tên đăng nhập WP", "admin", job.wpUsername)
        val appPasswordEt = materialField(form, "Application Password", "xxxx xxxx xxxx xxxx xxxx xxxx", job.wpAppPassword)

        form.addView(TextView(ctx).apply {
            text = "⚠️ Đang lưu THÔ (không mã hoá) trong bộ nhớ app — không dùng chung máy với người khác nếu đã điền mục này."
            textSize = 11f
            setTextColor(Color.parseColor("#991b1b"))
            setPadding(0, dp(2), 0, dp(6))
        })

        val statusOptions = listOf("draft", "publish", "private", "pending")
        val statusLabels = listOf("Bản nháp (draft)", "Đăng công khai ngay (publish)", "Riêng tư (private)", "Chờ duyệt (pending)")
        val statusSelIdx = statusOptions.indexOf(job.wpPostStatus).let { if (it < 0) 0 else it }
        val statusDropdown = materialDropdown(form, "Trạng thái bài viết", statusLabels, statusSelIdx)

        val categoryIdEt = materialField(form, "ID Category (tuỳ chọn)", "0 = không gán", job.wpCategoryId.toString())
        val titleTemplateEt = materialField(form, "Mẫu tiêu đề bài viết", "{title} hoặc {bookName} - {title}", job.wpPostTitleTemplate)

        showBottomSheet("Bước: Đăng lên WordPress", form, onSave = {
            val statusIdx = statusLabels.indexOf(statusDropdown.text.toString()).let { if (it < 0) 0 else it }
            saveStepAndRefresh(job.copy(
                publishToWordPress = enabledCb.isChecked,
                wpSiteUrl = siteUrlEt.text.toString().trim().trimEnd('/'),
                wpUsername = usernameEt.text.toString().trim(),
                wpAppPassword = appPasswordEt.text.toString().trim(),
                wpPostStatus = statusOptions[statusIdx],
                wpCategoryId = categoryIdEt.text.toString().toIntOrNull() ?: 0,
                wpPostTitleTemplate = titleTemplateEt.text.toString().trim().ifBlank { "{title}" },
            ))
        })
    }

    private fun showEditExportDialog(job: LeechJob) {
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val formatOptions = listOf("EPUB", "TXT", "HTML")
        val formatSelIdx = when (job.outputFormat) { LeechJob.OutputFormat.TXT -> 1; LeechJob.OutputFormat.HTML -> 2; else -> 0 }
        val formatDropdown = materialDropdown(form, "Định dạng", formatOptions, formatSelIdx)
        val fileNameEt = materialField(form, "Tên file (tuỳ chọn)", "để trống = tự đặt theo tên job", job.outputFileName)
        val reviewCb = MaterialCheckBox(ctx).apply {
            text = "Dừng lại chờ sắp xếp mục lục trước khi xuất"; textSize = 13f; minHeight = dp(44)
            isChecked = job.manualTocReview
            form.addView(this)
        }
        showBottomSheet("Bước: Xuất ebook", form, onSave = {
            val formatIdx = formatOptions.indexOf(formatDropdown.text.toString()).let { if (it < 0) 0 else it }
            val format = when (formatIdx) {
                1 -> LeechJob.OutputFormat.TXT; 2 -> LeechJob.OutputFormat.HTML; else -> LeechJob.OutputFormat.EPUB
            }
            saveStepAndRefresh(job.copy(
                outputFormat = format,
                outputFileName = fileNameEt.text.toString().trim(),
                manualTocReview = reviewCb.isChecked,
            ))
        })
    }

    private fun showEditStageDialog(job: LeechJob, stageIndex: Int) {
        val stage = job.preListStages.getOrNull(stageIndex) ?: return
        val form = LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val labelEt = materialField(form, "Tên bước", "vd: Chọn thể loại", stage.label)
        val selEt = materialPickerField(form, "Selector link ở bước này", ".category-list a", stage.linkSelector, "list")
        val attrEt = materialField(form, "Thuộc tính chứa URL", "href", stage.linkAttribute)
        showBottomSheet(
            "Bước phụ #${stageIndex + 1}", form,
            onSave = {
                val updatedStages = job.preListStages.toMutableList()
                updatedStages[stageIndex] = stage.copy(
                    label = labelEt.text.toString().trim().ifBlank { stage.label },
                    linkSelector = selEt.text.toString().trim(),
                    linkAttribute = attrEt.text.toString().trim().ifBlank { "href" },
                )
                saveStepAndRefresh(job.copy(preListStages = updatedStages))
            },
            extraButton = "🗑 Xoá bước này" to {
                val updatedStages = job.preListStages.toMutableList().apply { removeAt(stageIndex) }
                saveStepAndRefresh(job.copy(preListStages = updatedStages))
            }
        )
    }

    private fun showEditRulesDialog(job: LeechJob) {
        val currentRules = job.regexRules.toMutableList()
        val listContainer = LinearLayout(ctx).apply { orientation = VERTICAL }
        val outer = LinearLayout(ctx).apply {
            orientation = VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(8))
            addView(listContainer)
        }
        fun rebuild() {
            listContainer.removeAllViews()
            currentRules.forEachIndexed { idx, rule ->
                listContainer.addView(LinearLayout(ctx).apply {
                    orientation = HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(6))
                    addView(TextView(ctx).apply {
                        text = if (rule.kind == com.colablive.keeper.features.ebookleech.model.RegexRule.Kind.PLAIN_REPLACE)
                            "Tìm \"${rule.pattern}\" → \"${rule.replacement}\""
                        else "${rule.kind}: /${rule.pattern}/ → \"${rule.replacement}\""
                        textSize = 12f; maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                    })
                    addView(smallButton("🗑", "#9ca3af") { currentRules.removeAt(idx); rebuild() })
                })
            }
        }
        rebuild()
        val addBtn = MaterialButton(ctx).apply {
            text = "+ Thêm tìm & thay thế"; textSize = 13f; minHeight = dp(44)
            setOnClickListener { showAddRuleDialog(currentRules) { rebuild() } }
        }
        outer.addView(addBtn)

        showBottomSheet("Bước: Tìm & thay thế", outer, onSave = {
            saveStepAndRefresh(job.copy(regexRules = currentRules.toList()))
        })
    }

    // -------------------------------------------------------------------------
    // Open file
    // -------------------------------------------------------------------------

    /** `path` có thể là đường dẫn filesystem thật hoặc `content://` URI
     * (bản ghi MediaStore.Downloads — xem `EbookExporter.publishOneFile`). */
    private fun outputFileExists(path: String): Boolean {
        if (path.startsWith("content://")) {
            return try {
                ctx.contentResolver.openInputStream(Uri.parse(path))?.use { true } ?: false
            } catch (e: Exception) {
                false  // MediaStore đã xoá/thu hồi quyền — coi như không còn, ẩn nút "Mở ebook"
            }
        }
        return File(path).exists()
    }

    private fun openFile(path: String) {
        val mime = when {
            path.endsWith(".epub") -> "application/epub+zip"
            path.endsWith(".html") -> "text/html"
            else -> "text/plain"
        }
        val uri: Uri = if (path.startsWith("content://")) {
            // Đã là content:// URI thật (MediaStore) — dùng thẳng, KHÔNG bọc
            // qua FileProvider (FileProvider chỉ dành cho File thật trên đĩa).
            Uri.parse(path)
        } else {
            val file = File(path)
            if (!file.exists()) return
            // ĐÃ SỬA: authority thật của FileProvider trong AndroidManifest.xml
            // của base app là "${applicationId}.fileprovider" (KHÔNG PHẢI
            // ".provider" — bản trước đoán sai, sẽ crash
            // IllegalArgumentException "Couldn't find meta-data for
            // provider..." nếu bấm "Mở ebook").
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(Intent.createChooser(intent, "Mở ebook bằng…"))
    }

    // -------------------------------------------------------------------------
    // View helpers
    // -------------------------------------------------------------------------

    private fun smallButton(label: String, colorHex: String, onClick: () -> Unit): MaterialButton =
        MaterialButton(ctx).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            // backgroundTintList (KHÔNG dùng setBackgroundColor) — MaterialButton
            // tự quản lý nền qua MaterialShapeDrawable nội bộ (bo góc + ripple khi
            // chạm); gọi setBackgroundColor trực tiếp sẽ THAY THẾ drawable đó,
            // làm mất bo góc lẫn hiệu ứng ripple, trông như 1 hình chữ nhật thô.
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(colorHex))
            cornerRadius = dp(8)
            insetTop = 0; insetBottom = 0  // bỏ khoảng đệm dọc mặc định của MaterialButton — nút nhỏ cần gọn
            val lp = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, dp(44))  // chuẩn touch target tối thiểu 44-48dp
            lp.marginEnd = dp(8)
            layoutParams = lp
            minWidth = dp(44)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { onClick() }
        }

    private fun divider(): View = View(ctx).apply {
        setBackgroundColor(Color.parseColor("#e5e7eb"))
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, 1)
        lp.topMargin = dp(10); lp.bottomMargin = dp(4)
        layoutParams = lp
    }

    private fun sectionLabel(text: String): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 12f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.parseColor("#6b7280"))
        setPadding(0, dp(2), 0, dp(4))
    }

    private fun captionLabel(text: String): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 11f
        setTextColor(Color.parseColor("#9ca3af"))
        setPadding(0, 2, 0, 8)
    }

    private fun statusLabel(s: LeechJob.JobStatus) = when (s) {
        LeechJob.JobStatus.IDLE          -> "Chờ"
        LeechJob.JobStatus.RUNNING       -> "▶ Đang chạy"
        LeechJob.JobStatus.REVIEW_READY  -> "📑 Chờ sắp xếp mục lục"
        LeechJob.JobStatus.NEEDS_ACTION  -> "⚠️ Cần giải xác minh thủ công"
        LeechJob.JobStatus.PAUSED        -> "⏸ Đã dừng"
        LeechJob.JobStatus.DONE          -> "✅ Xong"
        LeechJob.JobStatus.ERROR         -> "❌ Lỗi"
    }

    private fun statusColor(s: LeechJob.JobStatus) = Color.parseColor(when (s) {
        LeechJob.JobStatus.RUNNING      -> "#2563eb"
        LeechJob.JobStatus.REVIEW_READY -> "#7c3aed"
        LeechJob.JobStatus.NEEDS_ACTION -> "#dc2626"
        LeechJob.JobStatus.DONE         -> "#059669"
        LeechJob.JobStatus.ERROR        -> "#dc2626"
        LeechJob.JobStatus.PAUSED       -> "#d97706"
        else                            -> "#6b7280"
    })

    private fun scheduleSummary(job: LeechJob) = when (job.scheduleMode) {
        LeechJob.ScheduleMode.MANUAL   -> "Thủ công"
        LeechJob.ScheduleMode.INTERVAL -> "Mỗi ${job.intervalMinutes} phút"
        LeechJob.ScheduleMode.DAILY    -> "Mỗi ngày"
    }

    private fun dp(n: Int) = (n * ctx.resources.displayMetrics.density).toInt()
}
