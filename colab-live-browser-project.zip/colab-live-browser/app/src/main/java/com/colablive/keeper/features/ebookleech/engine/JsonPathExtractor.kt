package com.colablive.keeper.features.ebookleech.engine

import org.json.JSONArray
import org.json.JSONObject

/**
 * Điều hướng 1 cây JSON (đã parse bằng `org.json`) theo path dạng chuỗi
 * đơn giản kiểu "a.b.c" hoặc "a.b[2].c" — dùng chung cho MỌI chỗ cần
 * người dùng tự nhập đường dẫn tới field mong muốn trong JSON API của
 * họ ("AJAX Leech thật" — xem `EbookLeechCrawler.phase1CollectLinksAjax()`/
 * `extractChapterJsonViaAjax()`).
 *
 * CỐ Ý ĐƠN GIẢN — không phải JSONPath chuẩn đầy đủ (không hỗ trợ wildcard
 * `*`, filter `[?()]`, recursive descent `..`). Lý do: người dùng thực sự
 * dùng tính năng này chỉ cần trỏ tới 1 field cụ thể trong 1 cấu trúc JSON
 * CỐ ĐỊNH (API của 1 site cụ thể, không đổi cấu trúc giữa các lần gọi) —
 * JSONPath đầy đủ là thừa phức tạp cho nhu cầu này, và tự viết 1 parser
 * JSONPath chuẩn đúng đắn tốn công hơn nhiều so với lợi ích thực tế ở đây.
 */
object JsonPathExtractor {

    private val SEGMENT_REGEX = Regex("""^([a-zA-Z0-9_]*)((?:\[\d+])*)$""")
    private val INDEX_REGEX = Regex("""\[(\d+)]""")

    /**
     * @param root Kết quả `org.json.JSONTokener(text).nextValue()` — có thể
     * là `JSONObject` hoặc `JSONArray` tuỳ API trả về object hay mảng ở gốc.
     * @param path Rỗng ("") = trả về chính `root` (dùng khi mảng chương/nội
     * dung nằm NGAY Ở GỐC JSON, không lồng trong field nào).
     * @return `null` nếu path không khớp cấu trúc thật (field không tồn
     * tại, sai kiểu...) — KHÔNG throw, để nơi gọi tự quyết định cách báo
     * lỗi rõ ràng cho người dùng thay vì crash job.
     */
    fun resolve(root: Any?, path: String): Any? {
        if (path.isBlank()) return root
        var current: Any? = root
        for (seg in path.split(".")) {
            if (current == null || seg.isBlank()) return null
            val match = SEGMENT_REGEX.matchEntire(seg) ?: return null
            val (key, indicesRaw) = match.destructured
            if (key.isNotEmpty()) {
                current = (current as? JSONObject)?.opt(key)
                if (current == null) return null
            }
            for (m in INDEX_REGEX.findAll(indicesRaw)) {
                val i = m.groupValues[1].toIntOrNull() ?: return null
                current = (current as? JSONArray)?.opt(i)
                if (current == null) return null
            }
        }
        return current
    }

    fun resolveArray(root: Any?, path: String): JSONArray? = resolve(root, path) as? JSONArray

    /** Ép kiểu về String cho tiện dùng trực tiếp (title/url/content thường
     * là string, nhưng vài API trả số/bool cho vài field — ép luôn cho
     * người dùng đỡ phải quan tâm kiểu JSON gốc). */
    fun resolveString(root: Any?, path: String): String? = when (val v = resolve(root, path)) {
        null -> null
        JSONObject.NULL -> null
        is String -> v
        else -> v.toString()
    }
}
