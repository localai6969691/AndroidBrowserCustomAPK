package com.colablive.keeper.features.ebookleech.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.GradientDrawable
import android.os.Build
import androidx.core.widget.NestedScrollView
import com.colablive.keeper.core.DebugLog

/**
 * Bản 7.114 — `NestedScrollView` có thanh cuộn HIỆN SẴN mà KHÔNG làm app crash.
 *
 * LỖI ĐÃ GẶP (crash 22/11 23:02:49, bấm "Cào từ xa (GitHub / Colab)"): `NullPointerException: ScrollBarDrawable.mutate() on a null object reference` ở `View.onDrawScrollBars`.
 * NGUYÊN NHÂN (đối chiếu nguồn AOSP android-13.0.0_r3 `View.java`): ở 7.108 `showBottomSheet` đặt `isVerticalScrollBarEnabled = true` + `isScrollbarFadingEnabled = false` trên một view tạo BẰNG CODE.
 *  - `setVerticalScrollBarEnabled(true)` (dòng 20050) chỉ đổi cờ, KHÔNG tạo `ScrollBarDrawable`.
 *  - `setScrollbarFadingEnabled(false)` (dòng 20073) gọi `initScrollCache()` (tạo bộ nhớ đệm với `scrollBar == null`) rồi đặt `state = ON`.
 *  - `onDrawScrollBars` (dòng 20574): `state == ON` => `cache.scrollBar.mutate().setAlpha(255)` (dòng 20611) => NPE vì `scrollBar == null`.
 *  - `awakenScrollBars` chỉ tạo `scrollBar` khi `fadeScrollBars == true` (dòng 19153–19161) nên không cứu được khi tắt mờ dần.
 *  `scrollBar` chỉ được tạo ở: `initializeScrollbarsInternal` (đường XML), `awakenScrollBars` (khi mờ dần BẬT) và `initializeScrollBarDrawable` — hàm sau là đường CÔNG KHAI duy nhất cho view tạo bằng code,
 *  gọi qua `setVerticalScrollbarThumbDrawable` / `setVerticalScrollbarTrackDrawable` (API 29+; dòng 6849–6865).
 *  Vì `showBottomSheet` là hàm dùng chung cho mọi sheet của Ebook Leech nên MỌI sheet đều crash từ 7.108 ngay khi vẽ khung đầu.
 *
 * CÁCH SỬA: (1) API >= 29: đặt thumb drawable TRƯỚC (tạo `ScrollBarDrawable` hợp lệ) rồi mới tắt mờ dần; API 26–28 không có đường công khai nên GIỮ mặc định (thanh cuộn mờ dần, không crash);
 * (2) lưới an toàn: nếu vẫn gặp đúng NPE `ScrollBarDrawable` ở lúc vẽ (một số ROM sửa `View`) thì trả về trạng thái an toàn (bật lại mờ dần, tắt thanh cuộn) thay vì crash.
 */
class SafeNestedScrollView(ctx: Context, private val barWidthPx: Int) : NestedScrollView(ctx) {
    private var guardTripped = false

    init {
        isVerticalScrollBarEnabled = true
        scrollBarSize = barWidthPx
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val thumb = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = barWidthPx / 2f
                    setColor(0x99808080.toInt())
                    setSize(barWidthPx, barWidthPx * 8)
                }
                setVerticalScrollbarThumbDrawable(thumb)   // tạo ScrollBarDrawable hợp lệ (initializeScrollBarDrawable)
                isScrollbarFadingEnabled = false            // chỉ SAU khi scrollBar đã tồn tại
            } catch (e: Throwable) {
                isScrollbarFadingEnabled = true             // không chắc scrollBar đã tạo => để mặc định an toàn
                DebugLog.log("SafeNestedScrollView: không dựng được thanh cuộn hiện sẵn (${e.javaClass.simpleName}: ${e.message}) — dùng thanh cuộn mặc định")
            }
        }
    }

    override fun onDrawForeground(canvas: Canvas) {
        try {
            super.onDrawForeground(canvas)
        } catch (e: NullPointerException) {
            // Chỉ nuốt ĐÚNG lỗi này; lỗi khác vẫn ném tiếp.
            if (e.message?.contains("ScrollBarDrawable") != true) throw e
            if (!guardTripped) {
                guardTripped = true
                DebugLog.log("SafeNestedScrollView: gặp NPE ScrollBarDrawable lúc vẽ — chuyển về thanh cuộn mặc định (mờ dần) để không crash")
            }
            isScrollbarFadingEnabled = true   // state -> OFF nên onDrawScrollBars không chạm scrollBar nữa
            isVerticalScrollBarEnabled = false
        }
    }
}
