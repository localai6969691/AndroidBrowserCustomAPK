package com.colablive.keeper.features.ebookleech.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.colablive.keeper.core.PluginForegroundServiceProxy
import com.colablive.keeper.core.ProfileSlots
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.features.ebookleech.EbookLeechFeature
import com.colablive.keeper.core.PluginServiceLogic
import com.colablive.keeper.features.ebookleech.EbookLeechScheduler
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.model.LeechJobRepository

/**
 * EbookLeechServiceLogic — logic THẬT của foreground service, không còn
 * extend `Service` trực tiếp.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * ĐÃ SỬA (phát hiện lỗi kiến trúc khi soát lại project thật): file này
 * TRƯỚC ĐÂY là `class EbookLeechService : Service()` — SẼ KHÔNG BAO GIỜ
 * chạy được, vì Android chỉ khởi tạo Service từ class NẰM SẴN trong dex
 * của APK đã cài + có khai trong AndroidManifest.xml. Class trong file
 * này sống trong `.jar` nạp bằng `DexClassLoader` lúc chạy (module
 * `:ebookleech`, KHÔNG merge vào APK) — hệ thống không biết gì về
 * `DexClassLoader` đó, `startForegroundService(Intent(context,
 * EbookLeechService::class.java))` chắc chắn lỗi (`ClassNotFoundException`
 * / hệ thống báo không tìm thấy service).
 *
 * SỬA: `object EbookLeechServiceLogic` giờ implement `PluginServiceLogic`
 * (interface, định nghĩa trong `:core`) thay vì extend `Service`. Việc
 * thật sự là 1 `Service` (khai trong Manifest, biên dịch cứng vào APK)
 * do `PluginForegroundServiceProxy` (`:core`) đảm nhiệm — nó tìm đúng
 * object này qua `PluginLoader.findPluginInstance()` rồi CHUYỂN TIẾP mọi
 * lời gọi vòng đời (`onCreate`/`onStartCommand`/`onDestroy`) sang, kèm
 * theo chính nó (`host: Service`) để object này gọi được
 * `startForeground()`/`getSystemService()`/`stopSelf()` — những hàm chỉ
 * gọi được trên 1 Service context thật.
 *
 * KHÔNG đổi tên file (vẫn `EbookLeechService.kt`) để dễ đối chiếu lịch sử
 * — chỉ đổi tên type bên trong.
 * ═══════════════════════════════════════════════════════════════════════
 */
object EbookLeechServiceLogic : PluginServiceLogic {

    private const val CHANNEL_ID = "ebook_leech_channel"
    private const val ALERT_CHANNEL_ID = "ebook_leech_alert_channel"
    private const val NOTIF_ID = 8421
    private const val ALERT_NOTIF_ID_BASE = 8500  // + hash tên job để mỗi job có thông báo riêng
    private const val TICK_INTERVAL_MS = 30_000L
    const val ACTION_STOP = "com.colablive.keeper.ebookleech.action.STOP"

    @Volatile private var running = false
    fun isRunning(): Boolean = running

    /**
     * Bản 7.98 — MỖI KHE MỘT TIẾN TRÌNH. Khe 1..3 chạy ở `:slot1`..`:slot3`; `GeckoViewEngine.forSlot(n)` (cào bằng tab GeckoView thật), tiến độ trong RAM
     * (`EbookLeechProgressStore`) và AppPrefs đều là của tiến trình đó. Nên service ở ĐÂY chỉ phục vụ ĐÚNG khe của tiến trình nó đang chạy
     * (khe 0 = tiến trình chính) — trước đây một service duy nhất tick MỌI khe bật, nên với khe 1..3 `forSlot(n)` luôn rỗng trong tiến trình chính.
     */
    private fun slotOf(context: Context): Int = ProfileSlots.getCurrentSlotIndex(context.applicationContext)

    /** Mỗi tiến trình khe có thông báo riêng (cùng ID => thông báo của khe này đè/xoá thông báo của khe kia). */
    private fun notifId(context: Context): Int = NOTIF_ID + slotOf(context)

    /** Tên class CHÍNH XÁC dùng làm `EXTRA_DELEGATE_CLASS` khi start proxy
     * — lấy động qua `javaClass.name` thay vì hard-code chuỗi, tránh lệch
     * nếu sau này đổi tên package/class mà quên sửa chuỗi ở chỗ khác. */
    private val delegateClassName: String get() = EbookLeechServiceLogic.javaClass.name

    /** Khởi động service của khe [slotIndex] (đúng tiến trình của khe đó). Gọi từ tiến trình nào cũng được. Không ném ngoại lệ (Android 12+ có thể cấm start FGS từ nền). */
    fun ensureStarted(context: Context, slotIndex: Int = slotOf(context)) {
        if (running && slotIndex == slotOf(context)) return
        try {
            val intent = PluginForegroundServiceProxy.intentFor(context, delegateClassName, slotIndex)
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
        } catch (e: Exception) {
            DebugLog.log("EbookLeech: không khởi động được service nền cho khe $slotIndex: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    fun stop(context: Context, slotIndex: Int = slotOf(context)) {
        try {
            context.stopService(PluginForegroundServiceProxy.intentFor(context, delegateClassName, slotIndex))
        } catch (e: Exception) {
            DebugLog.log("EbookLeech: dừng service khe $slotIndex lỗi: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /**
     * Báo động RIÊNG (kênh IMPORTANCE_HIGH — có âm thanh/heads-up) khi 1
     * job cần giải Cloudflare/captcha thủ công. KHÁC hẳn notification tiến
     * độ chính (kênh IMPORTANCE_LOW, im lặng) — đây là lúc THẬT SỰ cần
     * người dùng chú ý ngay, không phải chỉ xem tiến độ thụ động.
     */
    fun postManualActionAlert(context: Context, jobName: String, url: String, reason: String) {
        createAlertChannelIfNeeded(context)
        val notifId = ALERT_NOTIF_ID_BASE + jobName.hashCode().and(0xFFFF)
        val notif = NotificationCompat.Builder(context, ALERT_CHANNEL_ID)
            .setContentTitle("⚠️ $jobName cần giải xác minh thủ công")
            .setContentText(reason)
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "$reason\n\nMở app, vào EbookLeech, bấm \"✅ Đã giải xong\" sau khi giải xong trên trang:\n$url"
            ))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(notifId, notif)
    }

    private fun createAlertChannelIfNeeded(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(ALERT_CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            ALERT_CHANNEL_ID, "Ebook Leech — Cần xử lý thủ công", NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Báo khi 1 job gặp Cloudflare/captcha cần giải tay" }
        nm.createNotificationChannel(channel)
    }

    private val handler = Handler(Looper.getMainLooper())

    private val tickRunnable = object : Runnable {
        override fun run() {
            runInternalTick(currentHost ?: return)
            handler.postDelayed(this, TICK_INTERVAL_MS)
        }
    }

    // Giữ tham chiếu Service hiện tại để tickRunnable (chạy theo Handler,
    // không nhận host qua tham số như các hàm khác) dùng được — CHỈ 1
    // service proxy chạy tại 1 thời điểm (ensureStarted() có guard
    // `running`), nên an toàn dùng biến đơn thay vì truyền xuyên suốt.
    @Volatile private var currentHost: Service? = null

    override fun onCreate(host: Service) {
        currentHost = host
        running = true
        createChannelIfNeeded(host)
        host.startForeground(notifId(host), buildIdleNotification(host))
        // Đăng ký nhận cập nhật tức thì mỗi khi có progress mới từ bất kỳ job nào
        EbookLeechProgressStore.setListener { refreshNotificationFromProgress(host) }
        // Service khởi động lại (app crash/bị kill lúc trước, hoặc lần đầu
        // mở app sau khi feature vẫn đang bật) — quét job nào bị bỏ dở giữa
        // chừng (status RUNNING/NEEDS_ACTION còn checkpoint) và cào tiếp
        // đúng chỗ, KHÔNG cào lại từ đầu.
        val slot = slotOf(host)
        if (EbookLeechFeature.isEnabled(host.applicationContext, slot)) {
            EbookLeechScheduler.resumeInterruptedJobs(host.applicationContext, slot)
        }
        handler.post(tickRunnable)
    }

    override fun onStartCommand(host: Service, intent: Intent?, flags: Int, startId: Int): Int {
        currentHost = host
        if (intent?.action == ACTION_STOP) {
            host.stopSelf()
            return Service.START_NOT_STICKY
        }
        return Service.START_STICKY
    }

    override fun onDestroy(host: Service) {
        running = false
        handler.removeCallbacks(tickRunnable)
        EbookLeechProgressStore.setListener(null)
        currentHost = null
    }

    // -------------------------------------------------------------------------
    // Vòng lặp 30s — vẫn cần để KHỞI ĐỘNG job đến hạn (progress store chỉ có
    // dữ liệu SAU KHI job đã bắt đầu chạy)
    // -------------------------------------------------------------------------

    private fun runInternalTick(host: Service) {
        val slot = slotOf(host)
        // Khe của tiến trình này đã tắt EbookLeech (hoặc AppPrefs của tiến trình này chưa thấy) => không còn gì để tick: dừng service.
        if (!EbookLeechFeature.isEnabled(host.applicationContext, slot)) { host.stopSelf(); return }
        EbookLeechScheduler.tick(host.applicationContext, slot)
        refreshNotificationFromProgress(host)
    }

    // -------------------------------------------------------------------------
    // Notification chi tiết
    // -------------------------------------------------------------------------

    private fun refreshNotificationFromProgress(host: Service) {
        val active = EbookLeechProgressStore.allActive()
        val nm = host.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (active.isEmpty()) {
            nm.notify(notifId(host), buildIdleNotification(host))
            return
        }

        if (active.size == 1) {
            val s = active[0]
            nm.notify(notifId(host), buildSingleJobNotification(host, s))
        } else {
            nm.notify(notifId(host), buildMultiJobNotification(host, active))
        }
    }

    private fun buildIdleNotification(host: Service): Notification {
        val slots = listOf(slotOf(host)) // 7.98: mỗi tiến trình khe chỉ thấy job của khe mình
        var doneCount = 0
        var errorCount = 0
        var needsActionCount = 0
        slots.forEach { slot ->
            val jobs = LeechJobRepository.loadAll(host.applicationContext, slot)
            doneCount += jobs.count { it.status == LeechJob.JobStatus.DONE }
            errorCount += jobs.count { it.status == LeechJob.JobStatus.ERROR }
            needsActionCount += jobs.count { it.status == LeechJob.JobStatus.NEEDS_ACTION }
        }
        val text = buildString {
            append("Đang theo dõi lịch cào")
            if (needsActionCount > 0) append("  •  ⚠️ $needsActionCount cần giải tay")
            if (doneCount > 0) append("  •  ✅ $doneCount xong")
            if (errorCount > 0) append("  •  ❌ $errorCount lỗi")
        }
        return baseBuilder(host)
            .setContentTitle("Ebook Leech")
            .setContentText(text)
            .setProgress(0, 0, false)
            .build()
    }

    private fun buildSingleJobNotification(host: Service, s: EbookLeechProgressStore.Snapshot): Notification {
        val etaText = s.etaSeconds()?.let { formatEta(it) } ?: "đang tính…"
        val subtitle = if (s.total > 0)
            "${s.percent}%  •  ${s.current}/${s.total} chương  •  còn lại: $etaText"
        else
            s.phaseLabel

        val builder = baseBuilder(host)
            .setContentTitle("📖 ${s.jobName}")
            .setContentText(subtitle)
            .setStyle(NotificationCompat.BigTextStyle().bigText("${s.phaseLabel}\n$subtitle"))

        if (s.total > 0) builder.setProgress(100, s.percent, false)
        else builder.setProgress(0, 0, true)   // indeterminate khi chưa biết tổng (đang ở Phase 1/0)

        return builder.build()
    }

    private fun buildMultiJobNotification(host: Service, list: List<EbookLeechProgressStore.Snapshot>): Notification {
        val lines = list.joinToString("\n") { s ->
            val pct = if (s.total > 0) "${s.percent}%" else "…"
            "📖 ${s.jobName}: $pct (${s.current}${if (s.total > 0) "/${s.total}" else ""})"
        }
        val avgPercent = list.filter { it.total > 0 }
            .map { it.percent }
            .let { if (it.isEmpty()) 0 else it.sum() / it.size }

        return baseBuilder(host)
            .setContentTitle("Ebook Leech — ${list.size} job đang chạy")
            .setContentText(lines.substringBefore("\n"))
            .setStyle(NotificationCompat.BigTextStyle().bigText(lines))
            .setProgress(100, avgPercent, false)
            .build()
    }

    private fun baseBuilder(host: Service): NotificationCompat.Builder {
        val stopIntent = PluginForegroundServiceProxy.intentFor(host, delegateClassName, slotOf(host)).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            host, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(host, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)  // TODO: icon riêng của app
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Dừng", stopPending)
    }

    private fun formatEta(seconds: Long): String = when {
        seconds < 60 -> "${seconds}s"
        seconds < 3600 -> "${seconds / 60} phút"
        else -> "${seconds / 3600}h${(seconds % 3600) / 60}p"
    }

    private fun createChannelIfNeeded(host: Service) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = host.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID, "Ebook Leech", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Tiến độ cào ebook nền — % chi tiết, ETA"
            setShowBadge(false)
        }
        nm.createNotificationChannel(channel)
    }
}
