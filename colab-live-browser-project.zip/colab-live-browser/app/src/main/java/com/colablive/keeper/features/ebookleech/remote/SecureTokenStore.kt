package com.colablive.keeper.features.ebookleech.remote

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * SecureTokenStore — mã hoá Personal Access Token (PAT) GitHub bằng khoá
 * lưu trong `AndroidKeyStore` (phần cứng bảo mật của thiết bị, nếu có —
 * hệ điều hành tự chọn phần cứng/phần mềm phù hợp) — KHÔNG lưu token dạng
 * chữ thường trong `SharedPreferences`.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * CỐ Ý KHÔNG dùng `androidx.security:security-crypto` (EncryptedSharedPreferences)
 * dù đó là cách "chuẩn" hay được khuyên — vì đó là 1 THƯ VIỆN NGOÀI, và
 * cách đóng gói `.jar` plugin của addon này (`packagePluginJar` trong
 * `build.gradle`) CHỈ dex đúng các class BIÊN DỊCH TỪ SOURCE của chính
 * module `:ebookleech` (xem `KOTLIN_CLASSES_DIR` trong `build_plugin.sh`)
 * — KHÔNG kéo theo class của thư viện phụ thuộc vào file `.jar` cuối
 * cùng. Muốn dùng `security-crypto` thật sự chạy được lúc runtime, phải
 * thêm chính thư viện đó vào `:core` (module merge vào APK, xem
 * `core/build.gradle`) — nghĩa là phải vá lại project gốc THÊM 1 LẦN NỮA
 * chỉ để có 1 tính năng phụ. Dùng thẳng `javax.crypto`/`android.security.keystore`
 * (framework Android, LUÔN có sẵn trong mọi APK, không cần khai
 * dependency nào) tránh được hoàn toàn việc đó — addon tự chứa được,
 * không đụng lại `:core`/patch nền tảng.
 * ═══════════════════════════════════════════════════════════════════════
 */
object SecureTokenStore {
    private const val KEYSTORE_ALIAS = "ebookleech_github_pat_key"
    private const val PREFS_NAME = "ebookleech_secure"
    private const val KEY_ENC = "enc_token"
    private const val KEY_IV = "iv"

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEYSTORE_ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(KEYSTORE_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return kg.generateKey()
    }

    fun save(context: Context, plainToken: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(plainToken.toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_ENC, Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString(KEY_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .apply()
    }

    fun load(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val encB64 = prefs.getString(KEY_ENC, null) ?: return null
        val ivB64 = prefs.getString(KEY_IV, null) ?: return null
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, Base64.decode(ivB64, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(encB64, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (e: Exception) {
            null  // Key bị xoá (reset app, đổi ROM...) hoặc dữ liệu hỏng — coi như chưa cấu hình, KHÔNG crash
        }
    }

    fun hasToken(context: Context): Boolean =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).contains(KEY_ENC)

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
