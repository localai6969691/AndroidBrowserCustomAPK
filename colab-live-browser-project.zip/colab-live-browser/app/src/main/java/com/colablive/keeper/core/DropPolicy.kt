package com.colablive.keeper.core

/**
 * Bản 7.104 — quyết định có chuyển ACTION_DROP cho Gecko (`PanZoomController.onDragEvent`) hay không.
 *
 * BẰNG CHỨNG (log 09:34 ngày 11/11, bản 7.98 + mã nguồn Gecko, commit "Bug 1586471 Part 2 – Implement nsDragService on GeckoView",
 * `GeckoDragAndDrop.createDropData`): ở ACTION_DROP, Gecko chỉ biết hai loại dữ liệu là text/html và text/plain. Nó lấy text bằng
 * `clip.getItemAt(0).coerceToText(context)`. `ClipData.Item.coerceToText()` với item mang URI `content://` có kiểu text (.py, .md, .txt...)
 * sẽ MỞ file và trả NỘI DUNG làm chuỗi; với file khác (pdf, zip) trả CHÍNH chuỗi URI. Gecko rồi chèn chuỗi đó vào ô nhập đang trỏ tới =>
 * thả 9 tài liệu vào ô chat thì ô chat bị dán ~30.690 ký tự (nội dung file đầu tiên) song song với việc app gắn file thật vào trang.
 * Trước 7.104 app luôn chuyển ACTION_DROP cho Gecko "chạy song song" (xem chú thích cũ ở `MainActivity.setupDragDrop`).
 *
 * Với cú thả có FILE (item mang URI content:/file:), Gecko không bao giờ làm được gì có ích (không tạo `File` cho trang — mục 126), chỉ gây
 * hại (dán chữ). Nên app tự nhận cú thả: đường gắn file (click input / chunk / tự chạm) giữ nguyên, ACTION_DROP không chuyển cho Gecko.
 * Cú thả chỉ có text thật (kéo đoạn chữ từ app khác) hoặc link http(s) vẫn chuyển cho Gecko như cũ.
 */
object DropPolicy {
    /** [schemes] = scheme URI của từng item trong ClipData (null khi item không có URI). true nếu có ít nhất một item là file cục bộ (content:/file:). */
    fun carriesFiles(schemes: List<String?>): Boolean =
        schemes.any { s -> s != null && (s.equals("content", ignoreCase = true) || s.equals("file", ignoreCase = true)) }

    /** true = chuyển ACTION_DROP cho Gecko như cũ; false = app tự xử lý, không chuyển. */
    fun shouldForwardDropToGecko(schemes: List<String?>): Boolean = !carriesFiles(schemes)
}
