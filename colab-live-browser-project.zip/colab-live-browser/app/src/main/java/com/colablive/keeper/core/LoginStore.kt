package com.colablive.keeper.core

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URI
import java.security.GeneralSecurityException
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Kho tài khoản + mật khẩu đã lưu của MỖI hồ sơ (mục 105, mã hoá bằng mật khẩu chủ ở mục 106).
 *
 * Lưu ở `gecko_profile_<hồ sơ>/colablive_logins.json` — CÙNG thư mục với bookmarks.json/history.json — nên file sao lưu hồ sơ
 * (ProfileExportImport nén cả thư mục) mang theo và khôi phục lại cùng cookie, không cần code backup riêng.
 *
 * Hai dạng file:
 *  - THUẦN:   {"version":1,"logins":[...],"never":[...]}                         (chưa đặt mật khẩu chủ)
 *  - MÃ HOÁ:  {"version":2,"enc":{"kdf","iter","salt","iv","ct"}}                (AES-256-GCM, khoá = PBKDF2-HMAC-SHA256(mật khẩu chủ, salt))
 * Dạng nào là do NỘI DUNG FILE quyết định (không phải một cờ riêng), nên file nhập từ máy khác vẫn tự đúng. Mật khẩu chủ KHÔNG được
 * lưu ở đâu cả; chỉ khoá dẫn xuất được giữ trong RAM (tự khoá lại sau 15 phút không dùng hoặc khi tiến trình app bị giết).
 * Quên mật khẩu chủ = không khôi phục được (chỉ có thể xoá sạch kho và bắt đầu lại).
 *
 * Khớp theo ORIGIN CHÍNH XÁC (scheme + host + port), không khớp mờ: tránh trang giả mạo lấy được mật khẩu của trang thật.
 */
object LoginStore {
    private val lock = Any()
    private const val FILE = "colablive_logins.json"
    private const val KDF = "PBKDF2WithHmacSHA256"
    private const val KDF_ITER = 250_000
    private const val AUTO_LOCK_MS = 15 * 60 * 1000L
    private val rng = SecureRandom()

    class LockedException : Exception("Kho mật khẩu đang khoá")

    data class Login(
        val id: String, val origin: String, val username: String, val password: String,
        val created: Long, val updated: Long, val lastUsed: Long
    )

    enum class Compare { NEW, UPDATE, SAME }
    data class CompareResult(val kind: Compare, val existingId: String?)

    private class CachedKey(val key: SecretKey, val salt: ByteArray, val iter: Int, val kdf: String, @Volatile var lastUsed: Long)
    private val keyCache = ConcurrentHashMap<String, CachedKey>()

    /** "https://Sub.Example.com:443/path?x" -> "https://sub.example.com" ; chỉ http/https, ngoài ra trả null. */
    fun normalizeOrigin(raw: String): String? {
        return try {
            val u = URI(raw.trim())
            val scheme = u.scheme?.lowercase() ?: return null
            if (scheme != "http" && scheme != "https") return null
            val host = u.host?.lowercase() ?: return null
            val defaultPort = if (scheme == "https") 443 else 80
            val port = if (u.port == -1 || u.port == defaultPort) "" else ":${u.port}"
            "$scheme://$host$port"
        } catch (e: Exception) { null }
    }

    // ---------------------------------------------------------------- file
    private fun dirName(namespace: String) = "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    private fun file(context: Context, slotIndex: Int): File {
        val ns = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, dirName(ns))
        dir.mkdirs()
        return File(dir, FILE)
    }

    private fun emptyRoot() = JSONObject().put("version", 1).put("logins", JSONArray()).put("never", JSONArray())

    /** Nội dung file trên đĩa (CHƯA giải mã). Hỏng/không đọc được => coi như rỗng. */
    private fun readTop(context: Context, slotIndex: Int): JSONObject {
        val f = file(context, slotIndex)
        if (!f.exists()) return emptyRoot()
        return try { JSONObject(f.readText()) } catch (e: Exception) {
            DebugLog.log("LoginStore: file mật khẩu hỏng/không đọc được (${e.javaClass.simpleName}) — coi như rỗng")
            emptyRoot()
        }
    }

    private fun writeTop(context: Context, slotIndex: Int, top: JSONObject) {
        val f = file(context, slotIndex)
        val tmp = File(f.parentFile, "$FILE.tmp")
        tmp.writeText(top.toString())
        if (!tmp.renameTo(f)) { f.writeText(top.toString()); tmp.delete() }
    }

    // ---------------------------------------------------------------- mật mã
    private fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

    /** Mật khẩu chủ -> khoá AES-256. Đổi mật khẩu sang Base64(UTF-8) trước (chỉ ASCII) để mọi nhà cung cấp mật mã cho CÙNG khoá. */
    private fun deriveKey(password: String, salt: ByteArray, iter: Int, kdf: String): SecretKey {
        val ascii = Base64.encodeToString(password.toByteArray(Charsets.UTF_8), Base64.NO_WRAP).toCharArray()
        val spec = PBEKeySpec(ascii, salt, iter, 256)
        try {
            val raw = SecretKeyFactory.getInstance(kdf).generateSecret(spec).encoded
            return SecretKeySpec(raw, "AES")
        } finally { spec.clearPassword() }
    }

    private fun encrypt(key: SecretKey, plain: ByteArray): Pair<ByteArray, ByteArray> {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key) // IV 12 byte NGẪU NHIÊN mới ở mỗi lần mã hoá
        return c.iv to c.doFinal(plain)
    }

    private fun decrypt(key: SecretKey, iv: ByteArray, ct: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return c.doFinal(ct)
    }

    private fun cachedKey(context: Context, slotIndex: Int): CachedKey? {
        val path = file(context, slotIndex).absolutePath
        val ck = keyCache[path] ?: return null
        val now = System.currentTimeMillis()
        if (now - ck.lastUsed > AUTO_LOCK_MS) { keyCache.remove(path); return null }
        ck.lastUsed = now
        return ck
    }

    // ---------------------------------------------------------------- trạng thái khoá
    fun isEncrypted(context: Context, slotIndex: Int): Boolean = synchronized(lock) { readTop(context, slotIndex).has("enc") }

    fun isLocked(context: Context, slotIndex: Int): Boolean = synchronized(lock) {
        readTop(context, slotIndex).has("enc") && cachedKey(context, slotIndex) == null
    }

    fun lock(context: Context, slotIndex: Int) { keyCache.remove(file(context, slotIndex).absolutePath) }

    /** CHẶN (PBKDF2 vài trăm ms tới vài giây) — gọi từ luồng nền. true = đúng mật khẩu (hoặc kho chưa mã hoá). */
    fun unlock(context: Context, slotIndex: Int, password: String): Boolean {
        val top = synchronized(lock) { readTop(context, slotIndex) }
        val enc = top.optJSONObject("enc") ?: return true
        return try {
            val salt = unb64(enc.getString("salt"))
            val iter = enc.getInt("iter")
            val kdf = enc.optString("kdf", KDF)
            val key = deriveKey(password, salt, iter, kdf) // ngoài lock: không chặn thao tác khác
            decrypt(key, unb64(enc.getString("iv")), unb64(enc.getString("ct")))
            keyCache[file(context, slotIndex).absolutePath] = CachedKey(key, salt, iter, kdf, System.currentTimeMillis())
            true
        } catch (e: GeneralSecurityException) { false } // sai mật khẩu => thẻ xác thực GCM không khớp
        catch (e: Exception) {
            DebugLog.log("LoginStore: unlock lỗi bất thường ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    /** Đặt hoặc ĐỔI mật khẩu chủ. Nếu kho đang mã hoá thì phải đã mở khoá. CHẶN — gọi từ luồng nền. */
    fun setMasterPassword(context: Context, slotIndex: Int, newPassword: String) {
        val root = synchronized(lock) { readRoot(context, slotIndex) } // ném LockedException nếu đang khoá
        val salt = ByteArray(16).also { rng.nextBytes(it) }
        val key = deriveKey(newPassword, salt, KDF_ITER, KDF)
        val ck = CachedKey(key, salt, KDF_ITER, KDF, System.currentTimeMillis())
        synchronized(lock) {
            writeEncrypted(context, slotIndex, root, ck)
            keyCache[file(context, slotIndex).absolutePath] = ck
        }
    }

    /** Tắt mật khẩu chủ: giải mã và ghi lại dạng thuần. Phải đã mở khoá. */
    fun removeMasterPassword(context: Context, slotIndex: Int) = synchronized(lock) {
        val root = readRoot(context, slotIndex)
        writeTop(context, slotIndex, root)
        keyCache.remove(file(context, slotIndex).absolutePath)
        Unit
    }

    /** Quên mật khẩu chủ: xoá sạch kho (không có cách khôi phục). */
    fun resetAll(context: Context, slotIndex: Int) = synchronized(lock) {
        file(context, slotIndex).delete()
        keyCache.remove(file(context, slotIndex).absolutePath)
        Unit
    }

    private fun writeEncrypted(context: Context, slotIndex: Int, root: JSONObject, ck: CachedKey) {
        val (iv, ct) = encrypt(ck.key, root.toString().toByteArray(Charsets.UTF_8))
        val top = JSONObject().put("version", 2).put("enc", JSONObject()
            .put("kdf", ck.kdf).put("iter", ck.iter).put("salt", b64(ck.salt)).put("iv", b64(iv)).put("ct", b64(ct)))
        writeTop(context, slotIndex, top)
    }

    /** Dữ liệu đã giải mã. Ném LockedException nếu kho mã hoá mà chưa mở khoá. */
    private fun readRoot(context: Context, slotIndex: Int): JSONObject {
        val top = readTop(context, slotIndex)
        val enc = top.optJSONObject("enc") ?: return top
        val ck = cachedKey(context, slotIndex) ?: throw LockedException()
        return try {
            JSONObject(String(decrypt(ck.key, unb64(enc.getString("iv")), unb64(enc.getString("ct"))), Charsets.UTF_8))
        } catch (e: Exception) {
            keyCache.remove(file(context, slotIndex).absolutePath) // khoá không còn khớp file (vd file bị thay) => bắt mở khoá lại
            throw LockedException()
        }
    }

    /** Ghi dữ liệu: file đang mã hoá thì mã hoá lại bằng khoá đang mở; ngược lại ghi thuần. */
    private fun writeRoot(context: Context, slotIndex: Int, root: JSONObject) {
        if (readTop(context, slotIndex).has("enc")) {
            val ck = cachedKey(context, slotIndex) ?: throw LockedException()
            writeEncrypted(context, slotIndex, root, ck)
        } else writeTop(context, slotIndex, root)
    }

    // ---------------------------------------------------------------- dữ liệu
    private fun toLogin(o: JSONObject) = Login(
        o.optString("id"), o.optString("origin"), o.optString("username"), o.optString("password"),
        o.optLong("created"), o.optLong("updated"), o.optLong("lastUsed")
    )

    /** Đang khoá thì trả danh sách rỗng (đọc không ném lỗi); GHI mà đang khoá thì ném LockedException. */
    fun all(context: Context, slotIndex: Int): List<Login> = synchronized(lock) {
        try {
            val arr = readRoot(context, slotIndex).optJSONArray("logins") ?: JSONArray()
            (0 until arr.length()).map { toLogin(arr.getJSONObject(it)) }
                .sortedWith(compareBy({ it.origin }, { it.username.lowercase() }))
        } catch (e: LockedException) { emptyList() }
    }

    fun forOrigin(context: Context, slotIndex: Int, origin: String): List<Login> =
        all(context, slotIndex).filter { it.origin == origin }.sortedByDescending { it.lastUsed }

    /** So sánh với dữ liệu đã lưu để biết nên hỏi "Lưu" hay "Cập nhật" hay im lặng. */
    fun compare(context: Context, slotIndex: Int, origin: String, username: String, password: String): CompareResult {
        val same = forOrigin(context, slotIndex, origin).firstOrNull { it.username == username }
        return when {
            same == null -> CompareResult(Compare.NEW, null)
            same.password == password -> CompareResult(Compare.SAME, same.id)
            else -> CompareResult(Compare.UPDATE, same.id)
        }
    }

    /** Thêm mới hoặc cập nhật mật khẩu của (origin, username). Trả id. Ném LockedException nếu đang khoá. */
    fun save(context: Context, slotIndex: Int, origin: String, username: String, password: String): String {
        return synchronized(lock) { saveLocked(context, slotIndex, origin, username, password) }
    }

    private fun saveLocked(context: Context, slotIndex: Int, origin: String, username: String, password: String): String {
        val root = readRoot(context, slotIndex)
        val arr = root.optJSONArray("logins") ?: JSONArray().also { root.put("logins", it) }
        val now = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("origin") == origin && o.optString("username") == username) {
                o.put("password", password).put("updated", now).put("lastUsed", now)
                writeRoot(context, slotIndex, root)
                return o.optString("id")
            }
        }
        val id = UUID.randomUUID().toString()
        arr.put(JSONObject().put("id", id).put("origin", origin).put("username", username).put("password", password)
            .put("created", now).put("updated", now).put("lastUsed", now))
        writeRoot(context, slotIndex, root)
        return id
    }

    fun touch(context: Context, slotIndex: Int, id: String) = synchronized(lock) {
        val root = readRoot(context, slotIndex)
        val arr = root.optJSONArray("logins") ?: return@synchronized
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") == id) { o.put("lastUsed", System.currentTimeMillis()); writeRoot(context, slotIndex, root); return@synchronized }
        }
    }

    fun delete(context: Context, slotIndex: Int, id: String) = synchronized(lock) {
        val root = readRoot(context, slotIndex)
        val arr = root.optJSONArray("logins") ?: return@synchronized
        val kept = JSONArray()
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); if (o.optString("id") != id) kept.put(o) }
        root.put("logins", kept)
        writeRoot(context, slotIndex, root)
    }

    fun isNever(context: Context, slotIndex: Int, origin: String): Boolean = synchronized(lock) {
        try {
            val arr = readRoot(context, slotIndex).optJSONArray("never") ?: return@synchronized false
            (0 until arr.length()).any { arr.optString(it) == origin }
        } catch (e: LockedException) { false }
    }

    fun setNever(context: Context, slotIndex: Int, origin: String) = synchronized(lock) {
        val root = readRoot(context, slotIndex)
        val arr = root.optJSONArray("never") ?: JSONArray().also { root.put("never", it) }
        if ((0 until arr.length()).none { arr.optString(it) == origin }) { arr.put(origin); writeRoot(context, slotIndex, root) }
    }
}
