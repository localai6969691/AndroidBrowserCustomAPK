package com.colablive.keeper.features.downloads

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.*
import android.widget.*
import com.colablive.keeper.core.FolderPickerBridge
import java.io.File

/**
 * Dialog hỏi lưu file ở đâu trước khi download.
 */
class SaveLocationDialog(private val context: Context) {

    data class SaveResult(
        val confirmed: Boolean,
        val fileName: String,
        val directory: String,
        val locationType: String = "downloads" // "downloads"/"documents"/"pictures"/"movies"/"music"/"custom" — DownloadEngine cần đúng giá trị NÀY, không phải path đã tính sẵn ở `directory` (Scoped Storage Android 10+ cần biết collection, không phải path)
    )

    fun show(
        url: String,
        suggestedFileName: String,
        // Bản 7.97: dùng khi người dùng chọn "Đổi tên…" ở cảnh báo trùng tên — mở lại hộp này với NƠI LƯU đã chọn (mọi nơi gọi cũ dùng cú pháp lambda cuối nên không đổi).
        presetLocation: String? = null,
        presetCustomPath: String = "",
        callback: (SaveResult) -> Unit
    ) {
        /**
         * BUG THẬT (crash log người dùng gửi, có stack trace đầy đủ):
         * `android.view.WindowManager$BadTokenException: ... token ...
         * is not valid; is your activity running?` ném ra ngay tại
         * `AlertDialog.Builder.show()`. Nguyên nhân: `context` (Activity)
         * được "chụp" (capture) vào lúc lượt tải BẮT ĐẦU (đóng gói trong
         * closure `onDownloadStartedListener`/`onDownloadBodyReadyListener`
         * ở MainActivity), nhưng dialog chỉ thật sự `.show()` sau đó — nếu
         * trong khoảng thời gian đó Android ĐÃ HUỶ HẲN (không chỉ
         * pause/stop) instance Activity này (dễ xảy ra khi thiết bị ít
         * RAM, nhiều khe chạy song song, hoặc app bị thu hồi bộ nhớ nền),
         * `context` đó trỏ tới 1 Activity ĐÃ CHẾT dù màn hình lúc đó có
         * thể đang hiện 1 Activity MỚI (instance khác) — token cửa sổ của
         * bản cũ không còn hợp lệ, `AlertDialog.Builder(contextCũ).show()`
         * ném đúng exception này.
         * SỬA 2 LỚP:
         * 1) Kiểm tra TRƯỚC khi dựng dialog — nếu context là Activity đã
         *    `isFinishing`/`isDestroyed`, KHÔNG cố hiện dialog nữa (chắc
         *    chắn sẽ crash) — tự ĐỘNG CHẤP NHẬN với tên/nơi lưu mặc định
         *    (Downloads + tên gợi ý) thay vì âm thầm mất file đã tải —
         *    người dùng vẫn nhận được file, chỉ là không được hỏi tên vì
         *    không còn màn hình nào hợp lệ để hỏi.
         * 2) Bọc `.show()` thật trong try-catch bắt riêng
         *    `WindowManager.BadTokenException` làm lưới an toàn cuối —
         *    phòng các race hiếm hơn kiểm tra ở (1) không bắt kịp (VD
         *    window bị gỡ đúng giữa lúc build dialog, giữa 2 dòng code).
         */
        if (context is android.app.Activity && (context.isFinishing || context.isDestroyed)) {
            com.colablive.keeper.core.DebugLog.log("SaveLocationDialog: Activity đã finishing/destroyed trước khi kịp hiện dialog cho '$suggestedFileName' — tự động lưu vào Downloads với tên gợi ý thay vì crash/mất file")
            callback(SaveResult(true, suggestedFileName, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath, "downloads"))
            return
        }
        val scrollView = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        // URL
        container.addView(TextView(context).apply {
            text = "🔗 $url"
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, 16)
        })

        // File name
        container.addView(TextView(context).apply {
            text = "📝 Tên file:"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })

        val fileNameInput = EditText(context).apply {
            setText(suggestedFileName)
            setSingleLine(true)
        }
        container.addView(fileNameInput)

        // Save location
        container.addView(TextView(context).apply {
            text = "📁 Lưu vào:"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 16, 0, 8)
        })

        val locationGroup = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
        }

        val locations = listOf(
            "downloads" to "📥 Downloads (mặc định)",
            "documents" to "📄 Documents",
            "pictures" to "🖼️ Pictures",
            "movies" to "🎬 Movies",
            "music" to "🎵 Music",
            "custom" to "📂 Tùy chọn..."
        )

        locations.forEachIndexed { index, (value, label) ->
            locationGroup.addView(RadioButton(context).apply {
                text = label
                id = index
                if (value == (presetLocation ?: "downloads")) isChecked = true
                tag = value
            })
        }
        container.addView(locationGroup)

        // Custom path input (ẩn mặc định)
        val customPathInput = EditText(context).apply {
            hint = "/storage/emulated/0/MyFolder"
            visibility = if (presetLocation == "custom") View.VISIBLE else View.GONE
            setSingleLine(true)
            if (presetLocation == "custom") setText(presetCustomPath)
        }
        container.addView(customPathInput)

        // BUG THẬT (người dùng phản ánh 2 lần): trước đây "Tuỳ chọn" bắt
        // gõ TAY đường dẫn — không có cách duyệt thư mục thật như trình
        // duyệt khác. Thêm nút chọn thư mục THẬT qua Storage Access
        // Framework (`FolderPickerBridge`) — kết quả trả về là 1 "tree
        // URI" (`content://...`), KHÔNG PHẢI đường dẫn file thường, ghi
        // thẳng vào `customPathInput` — `DownloadEngine` tự nhận diện
        // tiền tố `content://` để chọn đúng cách ghi (qua `DocumentFile`),
        // khác hẳn cách ghi file thường cho đường dẫn gõ tay kiểu cũ.
        val pickFolderButton = Button(context).apply {
            text = "📁 Chọn thư mục"
            visibility = if (presetLocation == "custom") View.VISIBLE else View.GONE
            setOnClickListener {
                FolderPickerBridge.requestFolder(context) { uri ->
                    if (uri != null) {
                        customPathInput.setText(uri.toString())
                    }
                }
            }
        }
        container.addView(pickFolderButton)

        locationGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = locations[checkedId]
            val isCustom = selected.first == "custom"
            customPathInput.visibility = if (isCustom) View.VISIBLE else View.GONE
            pickFolderButton.visibility = if (isCustom) View.VISIBLE else View.GONE
        }

        // File size (nếu biết)
        container.addView(TextView(context).apply {
            text = "ℹ️ Kích thước: Đang xác định..."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 8, 0, 0)
        })

        scrollView.addView(container)

        val builder = AlertDialog.Builder(context)
            .setTitle("⬇️ Tải File")
            .setView(scrollView)
            .setPositiveButton("Tải") { _, _ ->
                val fileName = fileNameInput.text.toString()
                val selectedLocation = locations[locationGroup.checkedRadioButtonId]
                val directory = when (selectedLocation.first) {
                    // CHỈ dùng để HIỂN THỊ cho người dùng xem + mkdirs() (cần
                    // trên Android ≤9) — nơi lưu THẬT SỰ trên Android 10+ do
                    // `DownloadEngine.copyToPublicDownloads()` quyết định qua
                    // MediaStore (đọc `locationType`, không đọc path này).
                    "downloads" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
                    "documents" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).absolutePath
                    "pictures" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                    "movies" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).absolutePath
                    "music" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).absolutePath
                    "custom" -> customPathInput.text.toString()
                    else -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
                }
                // Bản 7.97: trước đây bấm "Tải" là đi luôn — file trùng tên trong nơi đã chọn bị hệ điều hành/SAF âm thầm thêm "(1)", người dùng không được báo (6/11).
                confirmOrWarnClash(url, fileName, selectedLocation.first, customPathInput.text.toString().trim(), directory, callback)
            }
            .setNegativeButton("Huỷ") { _, _ ->
                callback(SaveResult(false, "", ""))
            }
            .setNeutralButton("Chặn domain") { _, _ ->
                // Chặn domain này
                callback(SaveResult(false, "", "BLOCK_DOMAIN"))
            }
        try {
            builder.show()
        } catch (e: android.view.WindowManager.BadTokenException) {
            // Lưới an toàn cuối — xem chú thích đầy đủ ở đầu hàm show().
            // Đường này hiếm khi chạy tới (đã chặn phần lớn ở kiểm tra
            // isFinishing/isDestroyed phía trên) nhưng vẫn giữ lại phòng
            // race hiếm hơn — tuyệt đối không để app crash vì 1 cái dialog.
            com.colablive.keeper.core.DebugLog.log("SaveLocationDialog: BadTokenException lúc show() (race hiếm, đã qua được kiểm tra isFinishing/isDestroyed) — tự động lưu vào Downloads với tên gợi ý: ${e.message}")
            callback(SaveResult(true, suggestedFileName, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath, "downloads"))
        }
    }

    // ===================== Bản 7.97 — CẢNH BÁO TRÙNG TÊN =====================
    /**
     * Người dùng báo (6/11): tải file có tên trùng một file đã có trong thư mục đã chọn thì không có cảnh báo gì, cứ tải tiếp.
     * Nguyên nhân (đọc từ code): nút "Tải" gọi thẳng `callback`; `DownloadEngine.copyToPublicDownloads` không kiểm tra, để MediaStore/SAF tự thêm "(1)" (và nhánh Android ≤9 tự thêm "(1)" theo cách khác).
     * Nay kiểm tra trước (nền, vì liệt kê thư mục SAF có thể chậm) rồi hỏi: "Giữ cả hai" (app tự chọn tên chưa dùng, vd "a (1).pdf"), "Đổi tên…" (mở lại hộp này) hoặc "Huỷ".
     * CỐ Ý KHÔNG có nút "Ghi đè": ghi đè nghĩa là xoá file cũ của người dùng, mà việc xoá qua SAF/MediaStore (scoped storage) chưa kiểm chứng được trên máy thật và nếu lượt tải sau đó hỏng thì mất cả hai.
     * Giới hạn nói thẳng: thư mục SAF ("Tuỳ chọn" > Chọn thư mục) thấy đủ mọi file. Downloads/Pictures/Movies/Music/Documents trên Android 10+: app KHÔNG có quyền đọc, chỉ thấy file do CHÍNH app này đã tạo — file của app khác trùng tên sẽ không được báo.
     * Không kiểm tra được (lỗi/quyền) thì coi như không trùng và tải như cũ (không chặn việc tải).
     */
    private fun confirmOrWarnClash(url: String, fileName: String, locationType: String, customPath: String, directory: String, callback: (SaveResult) -> Unit) {
        if (fileName.isBlank()) { callback(SaveResult(true, fileName, directory, locationType)); return }
        val worker = Thread({
            val existing = DownloadNameClash.find(context, locationType, customPath, fileName)
            val alt = if (existing != null) DownloadNameClash.uniqueName(context, locationType, customPath, fileName) else fileName
            Handler(Looper.getMainLooper()).post {
                if (existing == null) { callback(SaveResult(true, fileName, directory, locationType)); return@post }
                com.colablive.keeper.core.DebugLog.log("SaveLocationDialog: '$fileName' đã tồn tại ở nơi lưu ($locationType) — hỏi người dùng (tên thay thế nếu giữ cả hai: '$alt')")
                showClashDialog(url, fileName, alt, locationType, customPath, directory, existing, callback)
            }
        }, "download-name-check")
        worker.isDaemon = true
        worker.start()
    }

    private fun showClashDialog(url: String, fileName: String, altName: String, locationType: String, customPath: String, directory: String, existing: DownloadNameClash.Existing, callback: (SaveResult) -> Unit) {
        // Activity đã chết trong lúc kiểm tra: không dựng được hộp thoại => làm đúng điều hệ điều hành vốn làm (giữ cả hai, không ghi đè) thay vì mất lượt tải.
        if (context is android.app.Activity && (context.isFinishing || context.isDestroyed)) {
            callback(SaveResult(true, altName, directory, locationType)); return
        }
        val where = when (locationType) {
            "custom" -> if (customPath.startsWith("content://")) "thư mục bạn đã chọn" else customPath.ifBlank { "Downloads" }
            "pictures" -> "Pictures"; "movies" -> "Movies"; "music" -> "Music"; "documents" -> "Documents"
            else -> "Downloads"
        }
        val whenText = if (existing.modifiedMs > 0L) ", sửa lần cuối " + java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date(existing.modifiedMs)) else ""
        val msg = "Đã có file \"$fileName\" trong $where (${DownloadNameClash.sizeText(existing.sizeBytes)}$whenText).\n\n" +
            "• Giữ cả hai: lưu file mới thành \"$altName\", file cũ giữ nguyên.\n• Đổi tên…: quay lại để tự đặt tên khác.\n\nApp không ghi đè file cũ."
        try {
            AlertDialog.Builder(context)
                .setTitle("⚠️ File trùng tên")
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton("Giữ cả hai") { _, _ -> callback(SaveResult(true, altName, directory, locationType)) }
                .setNeutralButton("Đổi tên…") { _, _ -> show(url, fileName, locationType, customPath, callback) }
                .setNegativeButton("Huỷ") { _, _ -> callback(SaveResult(false, "", "")) }
                .show()
        } catch (e: android.view.WindowManager.BadTokenException) {
            com.colablive.keeper.core.DebugLog.log("SaveLocationDialog: BadTokenException lúc hiện cảnh báo trùng tên — giữ cả hai (tên '$altName'): ${e.message}")
            callback(SaveResult(true, altName, directory, locationType))
        }
    }
}

/**
 * Bản 7.97 — tìm file trùng tên ở ĐÚNG nơi `DownloadEngine.copyToPublicDownloads` sẽ ghi: thư mục SAF (`content://` cây thư mục), MediaStore (Android 10+) hoặc File (Android ≤9).
 * Mọi hàm đều chạy trên luồng nền (gọi từ `SaveLocationDialog.confirmOrWarnClash`), lỗi => coi như KHÔNG trùng.
 */
object DownloadNameClash {
    class Existing(val sizeBytes: Long, val modifiedMs: Long)

    private fun relDirFor(locationType: String): String = when (locationType) {
        "pictures" -> Environment.DIRECTORY_PICTURES
        "movies" -> Environment.DIRECTORY_MOVIES
        "music" -> Environment.DIRECTORY_MUSIC
        "documents" -> Environment.DIRECTORY_DOCUMENTS
        else -> Environment.DIRECTORY_DOWNLOADS // "downloads" và "custom" không phải URI SAF (DownloadEngine rơi về Downloads trên Android 10+)
    }

    fun find(context: Context, locationType: String, customPath: String, fileName: String): Existing? {
        return try {
            if (locationType == "custom" && customPath.startsWith("content://")) {
                val dir = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, Uri.parse(customPath)) ?: return null
                val f = dir.findFile(fileName) ?: return null
                Existing(f.length(), f.lastModified())
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rel = relDirFor(locationType)
                val sel = MediaStore.MediaColumns.DISPLAY_NAME + " = ? AND (" + MediaStore.MediaColumns.RELATIVE_PATH + " = ? OR " + MediaStore.MediaColumns.RELATIVE_PATH + " = ?)"
                context.contentResolver.query(
                    MediaStore.Files.getContentUri("external"),
                    arrayOf(MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED),
                    sel, arrayOf(fileName, rel, "$rel/"), null
                )?.use { c -> if (c.moveToFirst()) Existing(c.getLong(0), c.getLong(1) * 1000L) else null }
            } else {
                @Suppress("DEPRECATION")
                val dir = when (locationType) {
                    "pictures" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    "movies" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                    "music" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
                    "documents" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                    "custom" -> if (customPath.isNotBlank()) File(customPath) else Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    else -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                }
                val f = File(dir, fileName)
                if (f.exists()) Existing(f.length(), f.lastModified()) else null
            }
        } catch (_: Throwable) { null }
    }

    /** Tên chưa dùng kiểu Chrome: "a.pdf" -> "a (1).pdf", "a (2).pdf"... */
    fun uniqueName(context: Context, locationType: String, customPath: String, fileName: String): String {
        val dot = fileName.lastIndexOf('.')
        var base = if (dot > 0) fileName.substring(0, dot) else fileName
        var ext = if (dot > 0) fileName.substring(dot) else ""
        // "a.tar.gz" -> "a (1).tar.gz" (không phải "a.tar (1).gz")
        if (base.length > 4 && base.endsWith(".tar", ignoreCase = true)) { ext = base.substring(base.length - 4) + ext; base = base.substring(0, base.length - 4) }
        for (i in 1..999) {
            val candidate = "$base ($i)$ext"
            if (find(context, locationType, customPath, candidate) == null) return candidate
        }
        return "$base (${System.currentTimeMillis()})$ext"
    }

    fun sizeText(bytes: Long): String = when {
        bytes < 0L -> "không rõ dung lượng"
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
        else -> String.format(java.util.Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    }
}
