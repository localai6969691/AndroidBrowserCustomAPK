package com.colablive.keeper.core

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View

/**
 * DÁN THẬT (trusted) — đúng cách trình duyệt thật làm, thay cho việc giả lập
 * ClipboardEvent bằng JS (mục 99).
 *
 * Vì sao: `new ClipboardEvent('paste')` từ JS luôn có isTrusted=false. Log thật
 * chỉ ra `dispatched-handled-by-page` (có ai đó preventDefault) nhưng chữ KHÔNG
 * xuất hiện trong ô Monaco của Colab. Còn đường dán của trình duyệt là lệnh
 * paste native: Gecko đọc clipboard hệ thống và bắn sự kiện `paste` TRUSTED.
 * Cách gọi lệnh đó từ Android mà không cần API GeckoView riêng: gửi tổ hợp
 * Ctrl+V như một phím cứng vào chính GeckoView (giống bàn phím Bluetooth).
 *
 * TỰ KIỂM CHỨNG (không đoán): content script eval_bridge ghi
 * `window.__lbLastPaste = {trusted}` mỗi khi có sự kiện paste (capture).
 * Sau khi gửi phím, đọc lại; nếu KHÔNG thấy paste trusted thì báo `false` để
 * bên gọi tự rơi về đường cũ. Không bao giờ dán 2 lần.
 */
object NativePaste {
    private val handler = Handler(Looper.getMainLooper())

    private const val PREP_JS = """(function(){
        try {
            window.__lbLastPaste = null;
            function deepActive(root){ var el = root.activeElement;
                while (el && el.shadowRoot && el.shadowRoot.activeElement) el = el.shadowRoot.activeElement;
                return el; }
            function editable(x){ return !!x && !!x.tagName && (x.isContentEditable || x.tagName === 'TEXTAREA' || x.tagName === 'INPUT'); }
            var el = deepActive(document);
            if (!editable(el)) {
                var last = window.__lbLastEditable;
                if (last && last.isConnected && editable(last)) { try { last.focus(); } catch (e) {} return 'focus-restored'; }
                return 'no-editable-focus';
            }
            return 'focus-ok:' + el.tagName;
        } catch (e) { return 'ERR:' + e.message; }
    })()"""

    private const val CHECK_JS = """(function(){
        try { var p = window.__lbLastPaste; return p ? ('SEEN trusted=' + p.trusted) : 'NONE'; }
        catch (e) { return 'ERR:' + e.message; }
    })()"""

    /**
     * @param evalJs   chạy JS trên tab đang active (engine.evaluateJs)
     * @param onResult true = đã xác nhận có sự kiện paste TRUSTED (đã dán xong, KHÔNG được dán lại)
     */
    fun paste(
        context: Context,
        host: View,
        text: String,
        evalJs: (String, (String?) -> Unit) -> Unit,
        onResult: (Boolean) -> Unit
    ) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        evalJs(PREP_JS) { prep ->
            DebugLog.log("NativePaste: chuẩn bị focus → $prep")
            try {
                val cur = cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
                if (cur != text) cm.setPrimaryClip(ClipData.newPlainText("colablive", text))
            } catch (e: Exception) {
                DebugLog.log("NativePaste: setPrimaryClip lỗi ${e.javaClass.simpleName}: ${e.message}")
            }
            host.requestFocus()
            sendCtrlV(host)
            handler.postDelayed({
                evalJs(CHECK_JS) { r ->
                    val ok = r != null && r.contains("trusted=true")
                    DebugLog.log("NativePaste: kiểm chứng sau khi gửi Ctrl+V → $r (dán native ${if (ok) "THÀNH CÔNG" else "KHÔNG xác nhận được → sẽ rơi về đường dự phòng"})")
                    NativeClipKeys.probeResponsiveness("dán ${text.length} ký tự", evalJs)
                    onResult(ok)
                }
            }, 450)
        }
    }

    private fun sendCtrlV(host: View) {
        val t = SystemClock.uptimeMillis()
        val meta = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        fun ev(action: Int, code: Int, m: Int) =
            KeyEvent(t, SystemClock.uptimeMillis(), action, code, 0, m, -1, 0, 0, android.view.InputDevice.SOURCE_KEYBOARD)
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON))
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_V, meta))
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_V, meta))
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_CTRL_LEFT, 0))
    }
}
