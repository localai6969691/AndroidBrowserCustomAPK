package com.colablive.keeper.features.ebookleech.engine

import com.colablive.keeper.features.ebookleech.model.LeechJob
import org.json.JSONObject

/**
 * Bản 7.104 — dựng lệnh trích THÔNG TIN TRUYỆN cho một job (phần thuần, kiểm được trên JVM).
 *
 * `selectorsFromJob` làm ĐÚNG như `story_selectors_from_job` trong crawler.py (và LeechDesk): các trường cũ `bookTitleSelector` / `bookCoverSelector` / `authorSelector`
 * (trước đây có trong form nhưng chưa từng được dùng) + `storyMetaSelectors` (khoá `coverUrl` là tên khác của `cover`). Selector khai trong `storyMetaSelectors` thắng trường cũ cùng loại.
 */
object StoryMetaCollector {
    fun selectorsFromJob(job: LeechJob): Map<String, String> {
        val sel = LinkedHashMap<String, String>()
        for ((key, legacy) in listOf("title" to job.bookTitleSelector, "cover" to job.bookCoverSelector, "author" to job.authorSelector)) {
            if (legacy.trim().isNotEmpty()) sel[key] = legacy.trim()
        }
        job.storyMetaSelectors.forEach { (k, v) ->
            val kk = k.trim(); val vv = v.trim()
            if (kk.isNotEmpty() && vv.isNotEmpty()) sel[if (kk == "coverUrl") "cover" else kk] = vv
        }
        return sel
    }

    /** Biểu thức JS hoàn chỉnh: `(<STORY_META_JS>)({"selectors":{...}})` — trả chuỗi JSON `{"meta":{...},"sources":{...}}`. */
    fun scriptFor(job: LeechJob): String =
        "(" + StoryMetaJs.STORY_META_JS + ")(" + JSONObject().put("selectors", JSONObject(selectorsFromJob(job))).toString() + ")"
}
