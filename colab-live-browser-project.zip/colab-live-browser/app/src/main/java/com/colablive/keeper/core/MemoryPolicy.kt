package com.colablive.keeper.core

import android.app.ActivityManager
import android.content.Context

/**
 * Bản 7.84 — chính sách RAM TỰ THÍCH NGHI theo thiết bị. Không có con số MB nào lấy từ log của một máy cụ thể.
 *
 * Mọi quyết định dựa vào những gì CHÍNH THIẾT BỊ báo và số đo thật lúc chạy:
 *  - `MemoryInfo.totalMem`: tổng RAM máy.
 *  - `MemoryInfo.threshold`: ngưỡng "thiếu RAM" do Android đặt RIÊNG cho từng máy (máy 3GB và máy 16GB khác nhau). Dưới ngưỡng này hệ thống bắt đầu giết tiến trình.
 *  - `MemoryInfo.availMem`, `lowMemory`, `ActivityManager.isLowRamDevice()`.
 *  - PSS thật của từng tiến trình của app: tổng, và riêng nhóm tiến trình tab (`tab*`) => chi phí trung bình mỗi tab TRONG LÚC CHẠY.
 *
 * Mức áp lực (Level):
 *  - CRITICAL: `lowMemory` hoặc "khoảng trống" (availMem - threshold) hết/nhỏ hơn 1 lần ngưỡng của máy => hệ thống sắp giết; được phép giải phóng cả tab thuộc nhóm "N tab gần nhất".
 *  - HIGH: khoảng trống nhỏ hơn 3 lần ngưỡng của máy, hoặc app vượt NGÂN SÁCH RAM => giải phóng tab cũ ngoài nhóm giữ sống, sớm hơn.
 *  - NORMAL: chỉ giải phóng tab ngoài nhóm giữ sống khi rảnh đủ lâu.
 *
 * Hai con số mặc định (25% RAM máy làm ngân sách, sàn 1GB / 640MB cho máy RAM thấp, và 350MB/tab để ước N ban đầu) là HEURISTIC kỹ thuật, không phải số đo của máy nào;
 * người dùng đổi được cả hai ở Cài đặt > "Trang chạy nền khi chuyển tab" (bỏ trống = tự động).
 */
object MemoryPolicy {
    enum class Level { NORMAL, HIGH, CRITICAL }

    data class Snapshot(
        val totalMb: Long,
        val availMb: Long,
        val thresholdMb: Long,
        val lowMemory: Boolean,
        val lowRamDevice: Boolean,
        val appTotalMb: Long,
        val tabProcMb: Long
    ) {
        /** Còn bao nhiêu MB nữa thì hệ thống bắt đầu giết tiến trình. */
        val headroomMb: Long get() = (availMb - thresholdMb).coerceAtLeast(0L)
    }

    private const val FEATURE_ID = "background_keepalive_domains"
    private const val KEY_RECENT_LIVE = "recent_live_tabs"
    private const val KEY_RAM_BUDGET = "ram_budget_pct"

    /** Heuristic ban đầu: ước chi phí 1 tab nặng để suy N mặc định. Chỉ dùng khi người dùng chưa đặt N. */
    private const val ASSUMED_TAB_MB = 350L

    fun snapshot(context: Context): Snapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val mb = 1024L * 1024L
        var app = 0L
        var tab = 0L
        try {
            val pkg = context.packageName
            val procs = (am.runningAppProcesses ?: emptyList()).filter { it.processName == pkg || it.processName.startsWith("$pkg:") }
            if (procs.isNotEmpty()) {
                val infos = am.getProcessMemoryInfo(procs.map { it.pid }.toIntArray())
                for (i in procs.indices) {
                    if (i >= infos.size) break
                    val m = infos[i].totalPss.toLong() / 1024L
                    app += m
                    if (procs[i].processName.substringAfter(':', "").startsWith("tab")) tab += m
                }
            }
        } catch (_: Throwable) { /* thiếu số đo tiến trình thì chỉ dùng tín hiệu hệ thống */ }
        return Snapshot(mi.totalMem / mb, mi.availMem / mb, mi.threshold / mb, mi.lowMemory, am.isLowRamDevice, app, tab)
    }

    /** Ngân sách RAM tự động (MB): 25% RAM máy, nhưng không dưới sàn (1GB; 640MB với máy RAM thấp) và không quá nửa RAM máy. */
    fun autoBudgetMb(totalMb: Long, lowRam: Boolean): Long {
        val floor = if (lowRam) 640L else 1024L
        return (totalMb / 4L).coerceAtLeast(floor).coerceAtMost((totalMb / 2L).coerceAtLeast(floor))
    }

    /** % ngân sách tự động (để hiển thị gợi ý ở màn hình cài đặt). */
    fun autoBudgetPercent(context: Context): Int {
        val s = snapshot(context)
        if (s.totalMb <= 0L) return 25
        return ((autoBudgetMb(s.totalMb, s.lowRamDevice) * 100L) / s.totalMb).toInt().coerceIn(5, 80)
    }

    /** N tab dùng gần nhất giữ sống MẶC ĐỊNH: số tab "nặng" vừa trong ngân sách tự động, 2..8. */
    fun autoRecentLive(context: Context): Int {
        val s = snapshot(context)
        return (autoBudgetMb(s.totalMb, s.lowRamDevice) / ASSUMED_TAB_MB).toInt().coerceIn(2, 8)
    }

    /** N hiệu lực: giá trị người dùng đặt (>0), bỏ trống/<=0 => tự động. Tính cả tab đang xem. */
    fun recentLive(context: Context, slotIndex: Int): Int {
        val v = AppPrefs.getInt(context, slotIndex, FEATURE_ID, KEY_RECENT_LIVE, -1)
        return if (v > 0) v.coerceIn(1, 50) else autoRecentLive(context)
    }

    /** Ngân sách RAM hiệu lực (MB): người dùng đặt % thì theo %, không thì tự động. */
    fun budgetMb(context: Context, slotIndex: Int, s: Snapshot): Long {
        val pct = AppPrefs.getInt(context, slotIndex, FEATURE_ID, KEY_RAM_BUDGET, -1)
        return if (pct > 0) (s.totalMb * pct.coerceIn(5, 80)) / 100L else autoBudgetMb(s.totalMb, s.lowRamDevice)
    }

    /**
     * Bản 7.89 — MỨC ÁP LỰC CHỈ THEO ÁP LỰC RAM THẬT CỦA HỆ THỐNG (như Chrome), không theo "ngân sách riêng của app".
     * Bản 7.84 coi `app > ngân sách (25% RAM máy)` là HIGH ngay cả khi máy còn dư 3,5GB (log 08:55–08:59: "mức=HIGH; ... khoảng trống 3522MB; app 3907MB / ngân sách 3807MB"),
     * nên tab ngoài nhóm giữ sống bị giải phóng (=> tải lại khi quay về) dù hệ thống chưa hề thiếu RAM. Chrome không làm vậy: nó chỉ bỏ tab cũ nhất khi hệ thống thật sự cạn.
     * Nay: CRITICAL = lowMemory hoặc khoảng trống < 1x ngưỡng máy; HIGH = khoảng trống < max(3x ngưỡng máy, 8% tổng RAM);
     * vượt ngân sách chỉ góp phần khi khoảng trống đã xuống dưới 12% tổng RAM (máy không còn dư dả).
     */
    fun level(s: Snapshot, budgetMb: Long): Level {
        val th = s.thresholdMb.coerceAtLeast(128L)
        return when {
            s.lowMemory || s.headroomMb < th -> Level.CRITICAL
            s.headroomMb < maxOf(th * 3L, s.totalMb * 8L / 100L) -> Level.HIGH
            s.appTotalMb > budgetMb && s.headroomMb < s.totalMb * 12L / 100L -> Level.HIGH
            else -> Level.NORMAL
        }
    }

    /** Bản 7.89: số phút rảnh để tự giải phóng tab nền NGOÀI nhóm giữ sống khi RAM vẫn dư; 0 (mặc định) = KHÔNG giải phóng theo thời gian, chỉ khi hệ thống thiếu RAM (giống Chrome). */
    fun idleDiscardMinutes(context: Context, slotIndex: Int): Int =
        AppPrefs.getInt(context, slotIndex, FEATURE_ID, "idle_discard_min", 0).coerceIn(0, 24 * 60)

    /** Chi phí trung bình mỗi tab đang tải (MB), ĐO THẬT từ nhóm tiến trình tab; thiếu số đo thì dùng ước lượng ban đầu. */
    fun perTabMb(s: Snapshot, loadedTabs: Int): Long =
        if (loadedTabs > 0 && s.tabProcMb > 0L) (s.tabProcMb / loadedTabs).coerceAtLeast(50L) else ASSUMED_TAB_MB

    /** Mô tả một dòng để ghi log — cho thấy chính sách ra quyết định dựa trên số nào. */
    fun describe(s: Snapshot, budgetMb: Long, level: Level, perTab: Long): String =
        "mức=$level; máy ${s.totalMb}MB (còn ${s.availMb}MB, ngưỡng hệ thống ${s.thresholdMb}MB => khoảng trống ${s.headroomMb}MB, lowRam=${s.lowRamDevice}); " +
            "app ${s.appTotalMb}MB (nhóm tab ${s.tabProcMb}MB) / ngân sách ${budgetMb}MB; ước ~${perTab}MB/tab"
}
