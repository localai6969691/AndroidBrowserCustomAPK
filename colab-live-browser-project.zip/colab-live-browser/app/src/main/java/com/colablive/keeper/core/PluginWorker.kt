package com.colablive.keeper.core

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf

/**
 * Worker THẬT, biên dịch cứng vào `:core` — "vỏ" chung cho MỌI plugin cần
 * chạy `WorkManager` (thay vì mỗi plugin tự khai 1 class `Worker` riêng mà
 * WorkManager không khởi tạo được vì nó nằm trong `.jar` ngoài APK — xem
 * `PluginServiceLogic.kt` để hiểu đầy đủ vì sao). Logic thật implement
 * `PluginWorkLogic`, gói tên class vào `inputData` lúc enqueue.
 *
 * KHÔNG cần khai `WorkerFactory` tuỳ biến hay sửa gì trong
 * `AndroidManifest.xml` cho riêng Worker — WorkManager khởi tạo `PluginWorker`
 * bình thường qua constructor 2 tham số chuẩn (class này NẰM SẴN trong APK
 * vì thuộc `:core`), khác hẳn Service (Service THẬT SỰ cần khai
 * `<service>` trong Manifest).
 */
class PluginWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {

    companion object {
        const val KEY_DELEGATE_CLASS = "delegate_class"

        /** Helper cho code plugin dùng lúc build `PeriodicWorkRequestBuilder<PluginWorker>(...)`:
         * `.setInputData(PluginWorker.inputDataFor(EbookLeechWorkLogic::class.java.name))`. */
        fun inputDataFor(delegateClassName: String) = workDataOf(KEY_DELEGATE_CLASS to delegateClassName)
    }

    override fun doWork(): Result {
        val className = inputData.getString(KEY_DELEGATE_CLASS) ?: return Result.failure()
        val delegate = PluginLoader.findPluginInstance(className) as? PluginWorkLogic
            ?: return Result.failure()  // plugin chưa nạp/đã gỡ jar — không retry vô hạn vô ích
        return if (delegate.doWork(applicationContext)) Result.success() else Result.retry()
    }
}
