package com.colablive.keeper.features.ebookleech.engine

/**
 * Bản 7.104 — script trích THÔNG TIN TRUYỆN (tác giả, tóm tắt, thể loại, tag, tình trạng, đánh giá, bìa...) chạy TRONG trang.
 *
 * FILE SINH TỰ ĐỘNG từ `tools/story_meta/story_meta.js` (xem tools/gen_story_meta_kt.py) — KHÔNG sửa tay. GIỐNG HỆT từng byte bản trong `remote_runner/crawler.py` (STORY_META_JS)
 * và LeechDesk (`ld/storymeta.py`); có test so khớp ở tools/story_meta/story_meta_identity.py. Cách gọi: `"(" + STORY_META_JS + ")(" + cfgJson + ")"`, kết quả là chuỗi JSON
 * `{"meta":{...},"sources":{...}}` (xem [com.colablive.keeper.features.ebookleech.model.StoryMeta.fromExtractorJson]).
 */
object StoryMetaJs {
    const val STORY_META_JS = """function (cfg) {
  cfg = cfg || {};
  var sel = cfg.selectors || {};
  var out = {}, src = {};
  var LIST_FIELDS = { genres: 1, tags: 1, altTitles: 1 };
  var KNOWN = { title: 1, author: 1, summary: 1, genres: 1, tags: 1, status: 1, rating: 1, cover: 1, language: 1, altTitles: 1, series: 1, seriesIndex: 1, publishedAt: 1, updatedAt: 1, translator: 1, publisher: 1 };

  function clean(s) { return (s == null ? '' : String(s)).replace(/[\u00a0\u200b\u200c\u200d\ufeff]/g, ' ').replace(/\s+/g, ' ').trim(); }
  function has(f) { return Object.prototype.hasOwnProperty.call(out, f); }
  function put(f, v, from) {
    if (has(f) || v == null) return;
    if (typeof v === 'string') { v = v.trim(); if (!v) return; }
    if (Array.isArray(v)) { if (!v.length) return; }
    if (typeof v === 'object' && !Array.isArray(v) && !Object.keys(v).length) return;
    out[f] = v; src[f] = from;
  }
  function abs(u) {
    u = clean(u);
    if (!u || /^(data|javascript|blob):/i.test(u)) return '';
    try { return new URL(u, document.baseURI).href; } catch (e) { return u; }
  }
  function qAll(css) { try { return Array.prototype.slice.call(document.querySelectorAll(css)); } catch (e) { return []; } }
  function q1(css) { try { return document.querySelector(css); } catch (e) { return null; } }
  function metaC(attr, name) {
    var els = qAll('meta[' + attr + '="' + name + '"]'), r = [];
    for (var i = 0; i < els.length; i++) { var c = clean(els[i].getAttribute('content')); if (c) r.push(c); }
    return r;
  }
  function meta1(attr, name) { var r = metaC(attr, name); return r.length ? r[0] : ''; }
  function splitList(s) {
    var parts = clean(s).split(/\s*[,;|\u3001\uff0c\u00b7\u2022\n]\s*/), r = [], seen = {};
    for (var i = 0; i < parts.length; i++) { var p = parts[i].trim(); if (p && !seen[p.toLowerCase()]) { seen[p.toLowerCase()] = 1; r.push(p); } }
    return r;
  }
  function uniq(arr) {
    var r = [], seen = {};
    for (var i = 0; i < arr.length; i++) { var p = clean(arr[i]); if (p && !seen[p.toLowerCase()]) { seen[p.toLowerCase()] = 1; r.push(p); } }
    return r;
  }
  var LABEL_PREFIX = /^(t\u00e1c gi\u1ea3 |t\u00e1c gi\u1ea3|author|by|t\u00ecnh tr\u1ea1ng|tr\u1ea1ng th\u00e1i|status|th\u1ec3 lo\u1ea1i|genres?|categories|category|tags?|ngu\u1ed3n|source|d\u1ecbch gi\u1ea3|translator|\u4f5c\u8005|\u72b6\u6001|\u5206\u7c7b)\s*[:\uff1a]\s*/i;
  function stripLabel(s) { return clean(s).replace(LABEL_PREFIX, ''); }
  function blockText(el) {
    var t = '';
    try { t = el.innerText; } catch (e) { }
    if (!t) t = el.textContent || '';
    var lines = t.replace(/\r/g, '').split('\n'), r = [];
    for (var i = 0; i < lines.length; i++) { var l = clean(lines[i]); if (l) r.push(l); }
    return r.join('\n');
  }
  function textToLines(s) {
    var lines = String(s || '').replace(/\r/g, '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n').replace(/<[^>]+>/g, '').split('\n'), r = [];
    for (var i = 0; i < lines.length; i++) { var l = clean(lines[i]); if (l) r.push(l); }
    return r.join('\n');
  }

  function normStatus(s) {
    s = clean(s).toLowerCase();
    if (!s) return '';
    if (/(dropped|\bdrop\b|abandon|discontinued|cancel|b\u1ecf d\u1edf|\u0111\u00e3 drop|\u5f03\u5751)/.test(s)) return 'dropped';
    if (/(hiatus|t\u1ea1m ng\u01b0ng|t\u1ea1m d\u1eebng|t\u1ea1m ngh\u1ec9|on hold|on-hold|paused|\u6682\u505c|\u4f11\u8f09)/.test(s)) return 'hiatus';
    if (/(ch\u01b0a ho\u00e0n|ch\u01b0a full|\u0111ang|c\u00f2n ti\u1ebfp|ti\u1ebfp t\u1ee5c|ongoing|on-going|in progress|serializ|updating|not complete|incomplete|unfinished|\u8fde\u8f7d|\u9023\u8f09)/.test(s)) return 'ongoing';
    if (/(ho\u00e0n th\u00e0nh|ho\u00e0n t\u1ea5t|ho\u00e0n|\bfull\b|\u0111\u00e3 xong|k\u1ebft th\u00fac|complet|finished|ended|\u5b8c\u7ed3|\u5b8c\u7d50|\u5b8c\u672c)/.test(s)) return 'completed';
    return '';
  }
  function num(s) {
    s = String(s).trim();
    if (/^\d{1,3}([.,]\d{3})+$/.test(s)) return parseFloat(s.replace(/[.,]/g, ''));
    return parseFloat(s.replace(',', '.'));
  }
  function parseRating(s) {
    s = clean(s);
    var m = s.match(/(\d+(?:[.,]\d+)?)\s*(?:\/|tr\u00ean|out of|of)\s*(\d+(?:[.,]\d+)?)/i), v, sc = 0;
    if (m) { v = num(m[1]); sc = num(m[2]); }
    else { m = s.match(/(\d+(?:[.,]\d+)?)/); if (!m) return null; v = num(m[1]); }
    if (!isFinite(v)) return null;
    if (!sc || !isFinite(sc)) sc = v <= 5 ? 5 : (v <= 10 ? 10 : 100);
    var r = { value: v, scale: sc }, c = s.match(/(\d[\d.,]*)\s*(?:votes?|ratings?|reviews?|\u0111\u00e1nh gi\u00e1|l\u01b0\u1ee3t|ng\u01b0\u1eddi)/i) || s.match(/\((\d[\d.,]*)\)/);
    if (c) { var n = num(c[1]); if (isFinite(n)) r.count = n; }
    return r;
  }
  function ratingFrom(value, best, count) {
    var v = parseFloat(String(value).replace(',', '.'));
    if (!isFinite(v)) return null;
    var sc = parseFloat(String(best == null ? '' : best).replace(',', '.'));
    var r = { value: v, scale: isFinite(sc) && sc > 0 ? sc : (v <= 5 ? 5 : (v <= 10 ? 10 : 100)) };
    var n = parseFloat(String(count == null ? '' : count).replace(/[.,]/g, ''));
    if (isFinite(n)) r.count = n;
    return r;
  }
  function normDate(s) {
    s = clean(s);
    if (!s) return '';
    if (/^\d{4}-\d{2}-\d{2}([T ]|$)/.test(s)) return s.length > 10 ? s.replace(' ', 'T') : s;
    var m = s.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})(?:\s+.*)?$/);
    if (m) { var d = ('0' + m[1]).slice(-2), mo = ('0' + m[2]).slice(-2); return m[3] + '-' + mo + '-' + d; }
    var t = Date.parse(s);
    if (isFinite(t)) { try { return new Date(t).toISOString().slice(0, 10); } catch (e) { } }
    return s;
  }
  function normLang(s) {
    s = clean(s).toLowerCase().replace(/_/g, '-');
    var m = s.match(/^([a-z]{2,3})(?:-|$)/);
    return m ? m[1] : '';
  }

  var siteName = meta1('property', 'og:site_name');
  function trimSite(t) {
    t = clean(t);
    var seps = [' | ', ' - ', ' \u2013 ', ' \u2014 ', ' \u00bb ', ' :: '], i, k;
    for (i = 0; i < seps.length; i++) {
      k = t.lastIndexOf(seps[i]);
      if (k > 0) {
        var tail = t.slice(k + seps[i].length).toLowerCase(), host = (location.hostname || '').replace(/^www\./, '').toLowerCase();
        if ((siteName && tail === siteName.toLowerCase()) || (host && tail.replace(/\s+/g, '').indexOf(host.split('.')[0]) >= 0)) return t.slice(0, k).trim();
      }
    }
    return t;
  }
  function parseSel(s) {
    s = String(s || '').trim();
    var m = s.match(/^(.*\S)\s*@([A-Za-z_:][\w:.\-]*)\s*$/);
    return m ? { css: m[1], attr: m[2] } : { css: s, attr: '' };
  }
  function imgUrl(el, attr) {
    if (!el) return '';
    if (attr) return abs(el.getAttribute(attr));
    var names = ['content', 'src', 'data-src', 'data-lazy-src', 'data-original', 'data-cfsrc'], i, v;
    for (i = 0; i < names.length; i++) { v = el.getAttribute && el.getAttribute(names[i]); if (v && abs(v)) return abs(v); }
    v = el.getAttribute && (el.getAttribute('srcset') || el.getAttribute('data-srcset'));
    if (v) return abs(clean(v).split(',')[0].trim().split(' ')[0]);
    var inner = el.querySelector && el.querySelector('img');
    if (inner && inner !== el) return imgUrl(inner, '');
    var bg = '';
    try { bg = (el.style && el.style.backgroundImage) || window.getComputedStyle(el).backgroundImage || ''; } catch (e) { }
    var m = bg.match(/url\((['"]?)(.*?)\1\)/);
    return m ? abs(m[2]) : '';
  }
  function bySelector(field, spec) {
    var p = parseSel(spec);
    if (!p.css) return;
    var els = qAll(p.css), i;
    if (!els.length) return;
    function one(el) { return p.attr ? clean(el.getAttribute(p.attr)) : clean(el.textContent); }
    if (field === 'cover') { put('cover', imgUrl(els[0], p.attr), 'selector'); return; }
    if (field === 'summary') {
      var t = p.attr ? textToLines(els[0].getAttribute(p.attr)) : blockText(els[0]);
      var lines = t.split('\n');
      if (lines.length && LABEL_PREFIX.test(lines[0])) lines[0] = lines[0].replace(LABEL_PREFIX, '');
      put('summary', lines.join('\n').trim(), 'selector'); return;
    }
    if (LIST_FIELDS[field]) {
      var arr = [];
      for (i = 0; i < els.length; i++) { var v = stripLabel(one(els[i])); if (els.length === 1) arr = arr.concat(splitList(v)); else if (v) arr.push(v); }
      put(field, uniq(arr), 'selector'); return;
    }
    if (field === 'author' || field === 'translator') {
      var names = [];
      for (i = 0; i < els.length; i++) { var a = stripLabel(one(els[i])); if (a) names.push(a); }
      put(field, uniq(names).join(', '), 'selector'); return;
    }
    var val = stripLabel(one(els[0]));
    if (field === 'status') { put('status', normStatus(val), 'selector'); put('statusText', val, 'selector'); }
    else if (field === 'rating') { put('rating', parseRating(val), 'selector'); }
    else if (field === 'publishedAt' || field === 'updatedAt') { put(field, normDate(val), 'selector'); }
    else if (field === 'language') { put('language', normLang(val), 'selector'); }
    else if (field === 'seriesIndex') { var n = parseFloat(val.replace(',', '.')); if (isFinite(n)) put('seriesIndex', n, 'selector'); }
    else if (KNOWN[field]) { put(field, val, 'selector'); }
    else { out.extra = out.extra || {}; if (!out.extra[field]) out.extra[field] = val; }
  }
  for (var f in sel) { if (Object.prototype.hasOwnProperty.call(sel, f) && sel[f]) bySelector(f, sel[f]); }

  // ---- 2) JSON-LD ----
  function ldNodes() {
    var nodes = [], scripts = qAll('script[type="application/ld+json"]');
    function walk(x) {
      if (!x) return;
      if (Array.isArray(x)) { for (var i = 0; i < x.length; i++) walk(x[i]); return; }
      if (typeof x !== 'object') return;
      nodes.push(x);
      if (x['@graph']) walk(x['@graph']);
    }
    for (var i = 0; i < scripts.length; i++) { try { walk(JSON.parse(scripts[i].textContent)); } catch (e) { } }
    return nodes;
  }
  function typesOf(n) { var t = n['@type']; return (Array.isArray(t) ? t : [t]).map(function (x) { return String(x || ''); }); }
  function ldName(v) {
    if (v == null) return '';
    if (typeof v === 'string') return clean(v);
    if (Array.isArray(v)) return uniq(v.map(ldName)).join(', ');
    return clean(v.name || '');
  }
  function ldImage(v) {
    if (!v) return '';
    if (typeof v === 'string') return abs(v);
    if (Array.isArray(v)) return ldImage(v[0]);
    return abs(v.url || v.contentUrl || '');
  }
  function ldList(v) {
    if (v == null) return [];
    if (Array.isArray(v)) return uniq(v.map(function (x) { return typeof x === 'string' ? x : ldName(x); }));
    return splitList(typeof v === 'string' ? v : ldName(v));
  }
  (function () {
    var nodes = ldNodes(), book = null, other = null, i, t;
    for (i = 0; i < nodes.length; i++) {
      t = typesOf(nodes[i]);
      if (!book && t.some(function (x) { return /^(Book|Audiobook|CreativeWorkSeries|BookSeries)$/.test(x); })) book = nodes[i];
      if (!other && t.some(function (x) { return /^(Article|NewsArticle|BlogPosting|CreativeWork|WebPage|ItemPage)$/.test(x); })) other = nodes[i];
    }
    var n = book || other;
    if (!n) return;
    var isBook = !!book;
    put('title', trimSite(n.name || n.headline || ''), 'jsonld');
    if (isBook) put('author', ldName(n.author || n.creator), 'jsonld');
    put('summary', textToLines(n.description || ''), 'jsonld');
    put('cover', ldImage(n.image || n.thumbnailUrl), 'jsonld');
    put('genres', ldList(n.genre), 'jsonld');
    put('tags', ldList(n.keywords), 'jsonld');
    put('language', normLang(typeof n.inLanguage === 'string' ? n.inLanguage : ldName(n.inLanguage)), 'jsonld');
    put('publishedAt', normDate(n.datePublished || ''), 'jsonld');
    put('updatedAt', normDate(n.dateModified || ''), 'jsonld');
    if (n.aggregateRating) put('rating', ratingFrom(n.aggregateRating.ratingValue, n.aggregateRating.bestRating, n.aggregateRating.ratingCount || n.aggregateRating.reviewCount), 'jsonld');
    if (isBook) put('publisher', ldName(n.publisher), 'jsonld');
    if (isBook && n.isPartOf) put('series', ldName(n.isPartOf), 'jsonld');
    if (isBook && n.alternateName) put('altTitles', ldList(n.alternateName), 'jsonld');
  })();

  put('title', trimSite(meta1('property', 'og:title')), 'og');
  put('author', uniq(metaC('property', 'og:novel:author').concat(metaC('property', 'book:author').filter(function (a) { return !/^https?:/i.test(a); }))).join(', '), 'og');
  put('author', clean(meta1('name', 'author')), 'meta');
  put('summary', textToLines(meta1('property', 'og:description')), 'og');
  put('summary', textToLines(meta1('name', 'description')), 'meta');
  put('cover', abs(meta1('property', 'og:image') || meta1('property', 'og:image:url') || meta1('name', 'twitter:image') || meta1('property', 'twitter:image')), 'og');
  (function () { var l = q1('link[rel="image_src"]'); if (l) put('cover', abs(l.getAttribute('href')), 'link'); })();
  put('genres', uniq([].concat(metaC('property', 'og:novel:category'), metaC('property', 'og:novel:genre'), metaC('property', 'article:section')).reduce(function (a, s) { return a.concat(splitList(s)); }, [])), 'og');
  put('tags', uniq([].concat(metaC('property', 'book:tag'), metaC('property', 'article:tag'))), 'og');
  put('tags', splitList(meta1('name', 'keywords')), 'meta');
  var st = meta1('property', 'og:novel:status') || meta1('property', 'og:status');
  if (st) { put('status', normStatus(st), 'og'); put('statusText', st, 'og'); }
  put('language', normLang(meta1('property', 'og:locale')), 'og');
  put('publishedAt', normDate(meta1('property', 'article:published_time') || meta1('property', 'book:release_date') || meta1('property', 'og:novel:release_date')), 'og');
  put('updatedAt', normDate(meta1('property', 'article:modified_time') || meta1('property', 'og:updated_time') || meta1('property', 'og:novel:update_time')), 'og');
  put('publisher', siteName, 'og');

  // ---- 4) microdata (itemprop) ----
  (function () {
    var scope = q1('[itemtype*="Book"]') || document;
    function ip(name) { return Array.prototype.slice.call(scope.querySelectorAll('[itemprop="' + name + '"]')); }
    var e;
    if ((e = ip('name')[0])) put('title', clean(e.getAttribute('content') || e.textContent), 'itemprop');
    var au = ip('author').map(function (el) { var n = el.querySelector('[itemprop="name"]'); return clean(n ? n.textContent : (el.getAttribute('content') || el.textContent)); });
    put('author', uniq(au).join(', '), 'itemprop');
    if ((e = ip('description')[0])) put('summary', blockText(e), 'itemprop');
    if ((e = ip('image')[0])) put('cover', imgUrl(e, ''), 'itemprop');
    var g = ip('genre').map(function (el) { return clean(el.getAttribute('content') || el.textContent); });
    put('genres', uniq(g), 'itemprop');
    if ((e = ip('inLanguage')[0])) put('language', normLang(e.getAttribute('content') || e.textContent), 'itemprop');
    function tv(e) { return e ? (e.getAttribute('content') || e.textContent) : null; }
    var rv = ip('ratingValue')[0];
    if (rv) put('rating', ratingFrom(tv(rv), tv(ip('bestRating')[0]), tv(ip('ratingCount')[0] || ip('reviewCount')[0])), 'itemprop');
  })();

  var LABELS = {
    author: /^(t\u00e1c gi\u1ea3|author|authors|writer|\u4f5c\u8005)$/i,
    genres: /^(th\u1ec3 lo\u1ea1i|genres?|categor(?:y|ies)|\u5206\u7c7b|\u7c7b\u578b)$/i,
    tags: /^(tags?|t\u1eeb kh\u00f3a|keywords?|nh\u00e3n)$/i,
    status: /^(t\u00ecnh tr\u1ea1ng|tr\u1ea1ng th\u00e1i|status|\u72b6\u6001)$/i,
    translator: /^(d\u1ecbch gi\u1ea3|nh\u00f3m d\u1ecbch|translator|translated by)$/i,
    altTitles: /^(t\u00ean kh\u00e1c|t\u00ean g\u1ecdi kh\u00e1c|alternative names?|alternate names?|other names?|also known as|\u5225\u540d|\u522b\u540d)$/i,
    rating: /^(\u0111\u00e1nh gi\u00e1|rating|ratings|\u8bc4\u5206)$/i,
    publishedAt: /^(ng\u00e0y \u0111\u0103ng|ng\u00e0y t\u1ea1o|published|release date|\u0111\u0103ng ng\u00e0y)$/i,
    updatedAt: /^(c\u1eadp nh\u1eadt|c\u1eadp nh\u1eadt l\u1ea7n cu\u1ed1i|updated|last updated|ng\u00e0y c\u1eadp nh\u1eadt)$/i
  };
  (function () {
    var cands = qAll('li,p,div,span,dt,th,td,b,strong,label,h3,h4,h5,small'), i, j, el, t, m, rest, k, lab, anchors, sib;
    for (i = 0; i < cands.length; i++) {
      el = cands[i];
      t = clean(el.textContent);
      if (!t || t.length > 500) continue;
      m = t.match(/^([^:\uff1a]{2,24})\s*[:\uff1a]\s*(.*)$/);
      var label = null;
      if (m) { label = clean(m[1]); rest = clean(m[2]); }
      else if (t.length <= 24) { label = t.replace(/[:\uff1a]\s*$/, ''); rest = ''; if (label === t) continue; }
      else continue;
      for (k in LABELS) {
        if (!Object.prototype.hasOwnProperty.call(LABELS, k) || !LABELS[k].test(label)) continue;
        if (has(k)) break;
        var valueEl = el;
        if (!rest) {
          sib = el.nextElementSibling;
          if (!sib && el.parentElement && /^(dt|th)$/i.test(el.tagName)) sib = el.parentElement.nextElementSibling;
          if (!sib) break;
          valueEl = sib; rest = clean(sib.textContent);
          if (!rest || rest.length > 400) break;
        } else if (el.children && el.children.length > 8) break;
        anchors = Array.prototype.slice.call(valueEl.querySelectorAll('a')).map(function (a) { return clean(a.textContent); }).filter(Boolean);
        if (LIST_FIELDS[k]) put(k, uniq(anchors.length ? anchors : splitList(rest)), 'label');
        else if (k === 'author' || k === 'translator') put(k, uniq(anchors.length ? anchors : [rest]).join(', '), 'label');
        else if (k === 'status') { put('status', normStatus(rest), 'label'); put('statusText', rest, 'label'); }
        else if (k === 'rating') put('rating', parseRating(rest), 'label');
        else put(k, normDate(rest), 'label');
        break;
      }
    }
    if (!has('summary')) {
      var heads = qAll('h1,h2,h3,h4,h5,h6,strong,b,div,span,p');
      for (i = 0; i < heads.length; i++) {
        t = clean(heads[i].textContent);
        if (t.length > 30 || !/^(gi\u1edbi thi\u1ec7u|t\u00f3m t\u1eaft|n\u1ed9i dung|m\u00f4 t\u1ea3|synopsis|summary|description|overview|\u7b80\u4ecb|\u5185\u5bb9\u7b80\u4ecb)\s*[:\uff1a]?$/i.test(t)) continue;
        if (heads[i].children.length > 2) continue;
        var s2 = heads[i].nextElementSibling, body = '';
        while (s2 && !body) { var bt = blockText(s2); if (bt.length >= 40) body = bt; s2 = s2.nextElementSibling; }
        if (body) { put('summary', body, 'label'); break; }
      }
    }
  })();

  (function () {
    var h = q1('h1'); if (h) put('title', clean(h.textContent), 'h1');
    put('title', trimSite(document.title || ''), 'title');
    put('language', normLang(document.documentElement.getAttribute('lang') || document.documentElement.getAttribute('xml:lang') || ''), 'html');
  })();

  var canon = q1('link[rel="canonical"]');
  out.sourceUrl = abs((canon && canon.getAttribute('href')) || meta1('property', 'og:url') || location.href);
  out.sourceSite = siteName || (location.hostname || '').replace(/^www\./, '');
  src.sourceUrl = 'page';
  if (out.cover) { out.coverUrl = out.cover; src.coverUrl = src.cover; delete out.cover; delete src.cover; }
  if (out.summary && out.summary.length > 8000) out.summary = out.summary.slice(0, 8000);
  ['genres', 'tags', 'altTitles'].forEach(function (k) { if (out[k] && out[k].length > 60) out[k] = out[k].slice(0, 60); });
  if (out.summary) out.summaryHtml = out.summary.split('\n').map(function (l) { return '<p>' + l.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</p>'; }).join('');
  return JSON.stringify({ meta: out, sources: src });
}
"""
}
