package com.colablive.keeper.core

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.math.BigInteger

/**
 * Mục 130: CÀI ĐẶT COOKIE CỦA TRANG — xem dung lượng, xoá, LƯU bộ cookie có tiêu đề, THAY cookie bằng bộ đã lưu.
 *
 * - ĐỌC cookie: sao chép cookies.sqlite (+ -wal) vào cache rồi đọc bản sao (đọc được cả cookie HttpOnly mà `document.cookie` không thấy).
 * - XOÁ: `StorageController.clearDataFromBaseDomain` (Gecko tự xoá, có hiệu lực ngay).
 * - LƯU: ghi JSON vào `<hồ sơ>/colablive_cookies/<id>.json` => nằm trong thư mục hồ sơ nên ĐI THEO backup/import.
 * - THAY: Gecko giữ cookie trong bộ nhớ nên KHÔNG sửa cookies.sqlite lúc đang chạy; ghi cờ `cookie_replace_pending` rồi đóng khe, và
 *   `applyPending` (gọi trong GeckoRuntimeProvider TRƯỚC khi tạo runtime) xoá cookie của miền rồi chèn bộ đã lưu (có sao lưu cookies.sqlite.before_replace).
 */
object CookieVault {
    class Snap(val id: String, val title: String, val host: String, val base: String, val created: Long, val count: Int)

    fun profileDir(c: Context, slot: Int): File {
        val ns = ProfileSlots.getSlotAssignment(c, slot)
        return File(c.filesDir, "gecko_profile_" + ns.replace(Regex("[^a-zA-Z0-9_-]"), "_"))
    }
    private fun vaultDir(c: Context, slot: Int): File = File(profileDir(c, slot), "colablive_cookies").apply { mkdirs() }

    private val SLD = setOf("com", "net", "org", "gov", "edu", "co", "ac")
    /** Miền gốc xấp xỉ (eTLD+1): `accounts.google.com` -> `google.com`, `a.b.com.vn` -> `b.com.vn`. */
    fun baseDomain(host: String): String {
        val h = host.trim().trimStart('.').lowercase()
        if (!h.contains('.') || h.matches(Regex("[0-9.]+"))) return h
        val p = h.split(".")
        if (p.size <= 2) return h
        return if (p.last().length == 2 && p[p.size - 2] in SLD) p.takeLast(3).joinToString(".") else p.takeLast(2).joinToString(".")
    }
    private fun matches(cookieHost: String, base: String): Boolean {
        val h = cookieHost.trimStart('.').lowercase()
        return h == base || h.endsWith(".$base")
    }
    private fun encodeCtx(ctx: String) = "gvctx" + BigInteger(1, ctx.toByteArray(Charsets.UTF_8)).toString(16)

    private fun openCopy(c: Context, profileDir: File): Pair<SQLiteDatabase, File>? {
        val src = File(profileDir, "cookies.sqlite")
        if (!src.isFile) return null
        val tmp = File(c.cacheDir, "cookie_view_${System.nanoTime()}").apply { mkdirs() }
        src.copyTo(File(tmp, "cookies.sqlite"), overwrite = true)
        val wal = File(profileDir, "cookies.sqlite-wal")
        if (wal.isFile) try { wal.copyTo(File(tmp, "cookies.sqlite-wal"), overwrite = true) } catch (e: Exception) { /* ghi dở: bỏ qua */ }
        // Không sao chép -shm (sẽ được dựng lại từ -wal) để tránh lệch với WAL đang được Gecko ghi.
        return Pair(SQLiteDatabase.openDatabase(File(tmp, "cookies.sqlite").absolutePath, null, SQLiteDatabase.OPEN_READWRITE), tmp)
    }

    /**
     * Mục 136: tóm tắt (TUYỆT ĐỐI KHÔNG ghi giá trị) các cookie đăng nhập chính của Google trong vùng đang dùng: có/thiếu và hạn còn lại. Gọi lúc khởi động
     * (Gecko chưa mở cookies.sqlite) để lần "văng đăng nhập" sau tự trả lời: còn đủ cookie hợp lệ mà vẫn văng => Google từ chối phía máy chủ; thiếu => app/import làm mất.
     */
    fun googleAuthHealth(c: Context, profileDir: File, contextIdFull: String, shared: Boolean): String {
        val opened = try { openCopy(c, profileDir) } catch (e: Throwable) { null } ?: return "(không có cookies.sqlite)"
        val db = opened.first
        val tmp = opened.second
        try {
            val ctxTag = encodeCtx(contextIdFull)
            val want = listOf("SID", "HSID", "SSID", "APISID", "SAPISID", "LSID", "__Secure-1PSID", "__Secure-3PSID", "__Secure-1PSIDTS", "__Secure-3PSIDTS", "OSID", "__Secure-OSID", "__Host-GAPS")
            val found = LinkedHashMap<String, String>()
            val now = System.currentTimeMillis() / 1000
            db.rawQuery("SELECT name, host, expiry, originAttributes FROM moz_cookies WHERE host LIKE '%google.com'", null).use { cur ->
                while (cur.moveToNext()) {
                    val name = cur.getString(0) ?: continue
                    if (name !in want) continue
                    val oa = cur.getString(3) ?: ""
                    val inCtx = if (shared) oa.isEmpty() else oa.contains(ctxTag)
                    if (!inCtx) continue
                    var exp = cur.getLong(2)
                    if (exp > 100_000_000_000L) exp /= 1000L
                    val hoursLeft = (exp - now) / 3600
                    found[name + "@" + (cur.getString(1) ?: "").trimStart('.')] = if (hoursLeft < 0) "HẾT HẠN" else "còn ${hoursLeft}h"
                }
            }
            val missing = want.filter { n -> found.keys.none { it.startsWith("$n@") } }
            return "có ${found.size}: " + found.entries.joinToString(", ") { it.key + "=" + it.value } + " | thiếu: " + missing
        } catch (e: Throwable) {
            return "(lỗi đọc: ${e.message})"
        } finally {
            try { db.close() } catch (e2: Throwable) { /* đã đóng */ }
            try { tmp.deleteRecursively() } catch (e3: Throwable) { /* thư mục tạm */ }
        }
    }

    /** Cookie của miền gốc, chỉ trong vùng đang dùng (chung '' hoặc contextId hiện tại). Trả (các hàng, tên cột). */
    fun readSiteCookies(c: Context, slot: Int, host: String, contextIdFull: String, shared: Boolean): Pair<List<List<Any?>>, List<String>> {
        val base = baseDomain(host)
        val (db, tmp) = openCopy(c, profileDir(c, slot)) ?: return Pair(emptyList(), emptyList())
        try {
            val rows = ArrayList<List<Any?>>()
            var cols: List<String> = emptyList()
            val ctxTag = encodeCtx(contextIdFull)
            db.rawQuery("SELECT * FROM moz_cookies", null).use { cur ->
                cols = cur.columnNames.toList()
                val hostIdx = cur.getColumnIndex("host")
                val oaIdx = cur.getColumnIndex("originAttributes")
                while (cur.moveToNext()) {
                    if (!matches(cur.getString(hostIdx) ?: "", base)) continue
                    val oa = if (oaIdx >= 0) cur.getString(oaIdx) ?: "" else ""
                    if (oa.contains("privateBrowsingId")) continue
                    // Mục 131.2: cookie PHÂN VÙNG (CHIPS, `partitionKey=...`) thuộc về trang nhúng bên thứ ba; nếu lưu rồi chèn lại với
                    // originAttributes đã thay (mất khoá phân vùng) nó thành cookie thường và có thể ĐÈ cookie thật cùng (tên, host, path).
                    if (oa.contains("partitionKey")) continue
                    val inCurrent = if (shared) oa.isEmpty() else oa.contains(ctxTag)
                    if (!inCurrent) continue
                    val r = ArrayList<Any?>(cols.size)
                    for (i in cols.indices) r.add(when (cur.getType(i)) {
                        Cursor.FIELD_TYPE_INTEGER -> cur.getLong(i)
                        Cursor.FIELD_TYPE_FLOAT -> cur.getDouble(i)
                        Cursor.FIELD_TYPE_STRING -> cur.getString(i)
                        Cursor.FIELD_TYPE_BLOB -> android.util.Base64.encodeToString(cur.getBlob(i), android.util.Base64.NO_WRAP)
                        else -> null
                    })
                    rows.add(r)
                }
            }
            return Pair(rows, cols)
        } finally { try { db.close() } catch (e: Throwable) {}; tmp.deleteRecursively() }
    }

    /**
     * Bản 7.64 — cookie của MỘT tab đọc thẳng từ cookies.sqlite (có ĐẦY ĐỦ thuộc tính, kể cả HttpOnly) theo đúng kho của tab: vùng (contextId `zone_<id>`), hoặc kho của hồ sơ
     * (`profile_<id>`, hoặc kho mặc định khi khe bật "cookie chung"). Tab ẩn danh (privateBrowsingId) không có trên đĩa => null. Gecko ghi cookie ra đĩa chậm (WAL) nên cookie vừa
     * đặt có thể chưa thấy ngay. Chỉ đọc (bản sao trong cache), không sửa đĩa.
     */
    fun readCks(c: Context, slot: Int, host: String, zoneId: String): List<CookieFormats.Ck>? {
        val ctx = if (zoneId.isNotBlank()) IncognitoZones.contextIdFor(zoneId) else "profile_" + ProfileSlots.getStableContextId(c, slot)
        val shared = zoneId.isBlank() && CookieModeMigration.isShared(c, slot)
        val (rows, cols) = readSiteCookies(c, slot, host, ctx, shared)
        if (cols.isEmpty()) return null
        fun idx(n: String) = cols.indexOf(n)
        val iName = idx("name"); val iVal = idx("value"); val iHost = idx("host"); val iPath = idx("path"); val iExp = idx("expiry")
        val iSec = idx("isSecure"); val iHttp = idx("isHttpOnly"); val iSame = idx("sameSite")
        if (iName < 0 || iHost < 0) return null
        return rows.map { r ->
            fun str(i: Int) = if (i < 0) "" else (r[i]?.toString() ?: "")
            fun lng(i: Int): Long = if (i < 0) 0L else (r[i] as? Long ?: (r[i] as? Number)?.toLong() ?: 0L)
            var exp = lng(iExp); if (exp > 100_000_000_000L) exp /= 1000L
            val h = str(iHost)
            CookieFormats.Ck(
                str(iName), str(iVal), h, !h.startsWith("."),
                str(iPath).ifEmpty { "/" }, lng(iSec) != 0L, lng(iHttp) != 0L,
                when (lng(iSame)) { 0L -> "no_restriction"; 1L -> "lax"; 2L -> "strict"; else -> "" },
                exp <= 0L, exp.toDouble()
            )
        }
    }

    private fun dirSize(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

    /** "Dữ liệu đã lưu trữ": kích thước thư mục storage của miền (localStorage, IndexedDB, cache API) + dung lượng chữ của cookie. */
    fun siteDataBytes(c: Context, slot: Int, host: String, rows: List<List<Any?>>, cols: List<String>): Long {
        val base = baseDomain(host)
        var total = 0L
        val ni = cols.indexOf("name"); val vi = cols.indexOf("value")
        for (r in rows) {
            total += ((if (ni >= 0) r[ni] as? String else null)?.length ?: 0) + ((if (vi >= 0) r[vi] as? String else null)?.length ?: 0)
        }
        val re = Regex("^[a-z\\-]+\\+\\+\\+([^:^+]+)")
        File(profileDir(c, slot), "storage/default").listFiles()?.forEach { d ->
            val m = re.find(d.name) ?: return@forEach
            val h = m.groupValues[1].lowercase()
            if (h == base || h.endsWith(".$base")) total += dirSize(d)
        }
        return total
    }

    // ---------------- Bản lưu ----------------
    fun save(c: Context, slot: Int, title: String, host: String, rows: List<List<Any?>>, cols: List<String>): Snap {
        val id = System.currentTimeMillis().toString(36) + "_" + (1000..9999).random()
        val base = baseDomain(host)
        val created = System.currentTimeMillis()
        val j = JSONObject()
        j.put("id", id).put("title", title).put("host", host).put("base", base).put("created", created).put("count", rows.size)
        j.put("cols", JSONArray(cols))
        val arr = JSONArray()
        for (r in rows) { val a = JSONArray(); for (v in r) a.put(v ?: JSONObject.NULL); arr.put(a) }
        j.put("rows", arr)
        File(vaultDir(c, slot), "$id.json").writeText(j.toString())
        DebugLog.log("Khe $slot: [Cookie] đã LƯU bộ cookie '$title' ($base, ${rows.size} cookie) -> colablive_cookies/$id.json (đi theo backup)")
        return Snap(id, title, host, base, created, rows.size)
    }

    fun list(c: Context, slot: Int): List<Snap> {
        val out = ArrayList<Snap>()
        vaultDir(c, slot).listFiles { f -> f.name.endsWith(".json") }?.forEach { f ->
            try {
                val j = JSONObject(f.readText())
                out.add(Snap(j.getString("id"), j.optString("title", f.nameWithoutExtension), j.optString("host"), j.optString("base"), j.optLong("created"), j.optInt("count")))
            } catch (e: Exception) { /* file hỏng: bỏ qua */ }
        }
        return out
    }

    fun delete(c: Context, slot: Int, id: String) { File(vaultDir(c, slot), "$id.json").delete() }

    /**
     * Mục 133: bộ đã lưu -> JSON đúng định dạng nhập của Cookie-Editor (mảng {name,value,domain,path,secure,httpOnly,sameSite,expirationDate,...}).
     * Dùng để nạp cookie vào TAB ẨN DANH ngay lập tức (cookie ẩn danh nằm trong RAM nên không thay được qua cookies.sqlite). Chưa kiểm chứng trên máy thật.
     */
    fun toEditorJson(c: Context, slot: Int, id: String): String? {
        return try {
            val j = JSONObject(File(vaultDir(c, slot), "$id.json").readText())
            val cols = j.getJSONArray("cols").let { a -> (0 until a.length()).map { a.getString(it) } }
            val rows = j.getJSONArray("rows")
            val out = JSONArray()
            for (r in 0 until rows.length()) {
                val row = rows.getJSONArray(r)
                fun str(n: String): String? { val i = cols.indexOf(n); return if (i < 0 || row.isNull(i)) null else row.get(i).toString() }
                fun num(n: String): Long { val i = cols.indexOf(n); return if (i < 0 || row.isNull(i)) 0L else row.optLong(i, 0L) }
                val host = str("host") ?: continue
                val name = str("name") ?: continue
                val o = JSONObject()
                o.put("name", name)
                o.put("value", str("value") ?: "")
                o.put("domain", host)
                o.put("hostOnly", !host.startsWith("."))
                o.put("path", str("path") ?: "/")
                o.put("secure", num("isSecure") == 1L)
                o.put("httpOnly", num("isHttpOnly") == 1L)
                o.put("sameSite", when (num("sameSite")) { 1L -> "lax"; 2L -> "strict"; else -> "no_restriction" })
                var exp = num("expiry")
                if (exp > 100_000_000_000L) exp /= 1000L // một số bản Gecko lưu mili giây
                o.put("session", false)
                o.put("firstPartyDomain", "")      // Mục 139: đủ trường như bản xuất của Cookie-Editor 1.13 (người dùng gửi mẫu)
                o.put("partitionKey", JSONObject.NULL)
                o.put("storeId", JSONObject.NULL)
                o.put("expirationDate", exp)
                out.put(o)
            }
            out.toString()
        } catch (e: Throwable) { null }
    }

    fun rename(c: Context, slot: Int, id: String, newTitle: String) {
        val f = File(vaultDir(c, slot), "$id.json")
        val j = JSONObject(f.readText()); j.put("title", newTitle); f.writeText(j.toString())
    }

    fun queueReplace(c: Context, slot: Int, id: String) { AppPrefs.setString(c, slot, "cookie_replace_pending", id) }
    fun hasPending(c: Context, slot: Int) = AppPrefs.getString(c, slot, "cookie_replace_pending", "").isNotBlank()

    /** Gọi TRƯỚC khi tạo GeckoRuntime (Gecko chưa mở cookies.sqlite). Cờ luôn bị xoá để lỗi không lặp vô hạn. */
    fun applyPending(c: Context, slot: Int, profileDir: File, contextIdFull: String, shared: Boolean) {
        val id = AppPrefs.getString(c, slot, "cookie_replace_pending", "")
        if (id.isBlank()) return
        AppPrefs.setString(c, slot, "cookie_replace_pending", "")
        try {
            val f = File(vaultDir(c, slot), "$id.json")
            if (!f.isFile) { DebugLog.log("Khe $slot: [Cookie] THAY: không thấy bản lưu $id — bỏ qua"); return }
            val j = JSONObject(f.readText())
            val base = j.getString("base")
            val cols = j.getJSONArray("cols").let { a -> (0 until a.length()).map { a.getString(it) } }
            val rowsJ = j.getJSONArray("rows")
            val dbFile = File(profileDir, "cookies.sqlite")
            if (!dbFile.isFile) { DebugLog.log("Khe $slot: [Cookie] THAY: hồ sơ chưa có cookies.sqlite — bỏ qua"); return }
            val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
            try {
                db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { it.moveToFirst() }
                dbFile.copyTo(File(profileDir, "cookies.sqlite.before_replace"), overwrite = true)
                val tableCols = ArrayList<String>()
                db.rawQuery("PRAGMA table_info(moz_cookies)", null).use { cur -> while (cur.moveToNext()) tableCols.add(cur.getString(1)) }
                val targetOa = if (shared) "" else "^geckoViewUserContextId=" + encodeCtx(contextIdFull)
                var deleted = 0; var inserted = 0
                db.beginTransaction()
                try {
                    // Mục 131.2: chỉ xoá cookie đang nằm ĐÚNG vùng (`targetOa`) mà bộ lưu sẽ được chèn vào. Trước đây xoá cookie của miền ở MỌI vùng
                    // (trừ ẩn danh) — kể cả vùng khác mà bản lưu không chứa lại (cookie còn sót ở contextId cũ, cookie phân vùng) => mất vĩnh viễn.
                    deleted = db.delete("moz_cookies", "(host = ? OR host = ? OR host LIKE ?) AND originAttributes = ?", arrayOf(base, ".$base", "%.$base", targetOa))
                    for (ri in 0 until rowsJ.length()) {
                        val row = rowsJ.getJSONArray(ri)
                        val cv = ContentValues()
                        for (i in cols.indices) {
                            val col = cols[i]
                            if (col == "id" || col == "originAttributes" || col !in tableCols) continue
                            if (row.isNull(i)) { cv.putNull(col); continue }
                            when (val v = row.get(i)) {
                                is Int -> cv.put(col, v.toLong())
                                is Long -> cv.put(col, v)
                                is Double -> cv.put(col, v)
                                else -> cv.put(col, v.toString())
                            }
                        }
                        cv.put("originAttributes", targetOa)
                        if (db.insertWithOnConflict("moz_cookies", null, cv, SQLiteDatabase.CONFLICT_REPLACE) != -1L) inserted++
                    }
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
                DebugLog.log("Khe $slot: [Cookie] ĐÃ THAY cookie của '$base' bằng bộ '${j.optString("title")}': xoá $deleted, chèn $inserted (vùng='${if (shared) "chung" else targetOa}')")
            } finally { db.close() }
        } catch (e: Throwable) {
            DebugLog.log("Khe $slot: [Cookie] THAY THẤT BẠI ${e.javaClass.simpleName}: ${e.message} — cookie giữ nguyên (đã có cookies.sqlite.before_replace)")
        }
    }
}
