package com.colablive.keeper.core

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.math.BigInteger

/**
 * Mục 130: CÀI ĐẶT COOKIE CỦA TRANG — xem dung lượng, xoá, LƯU bộ cookie có tiêu đề, THAY cookie bằng bộ đã lưu.
 *
 * - ĐỌC cookie: sao chép cookies.sqlite (+ -wal) vào cache rồi đọc bản sao (đọc được cả cookie HttpOnly mà `document.cookie` không thấy).
 * - XOÁ: `StorageController.clearDataFromBaseDomain` (Gecko tự xoá, có hiệu lực ngay).
 * - LƯU: ghi JSON vào `<hồ sơ>/colablive_cookies/<id>.json` => nằm trong thư mục hồ sơ nên ĐI THEO backup/import.
 * - THAY: Gecko giữ cookie trong bộ nhớ nên KHÔNG sửa cookies.sqlite lúc đang chạy; ghi cờ `cookie_replace_pending` rồi đóng khe, và
 *   `applyPending` (gọi trong GeckoRuntimeProvider TRƯỚC khi tạo runtime) xoá cookie của miền rồi chèn bộ đã lưu (có sao lưu cookies.sqlite.before_replace).
 */
object CookieVault {
    class Snap(val id: String, val title: String, val host: String, val base: String, val created: Long, val count: Int)

    fun profileDir(c: Context, slot: Int): File {
        val ns = ProfileSlots.getSlotAssignment(c, slot)
        return File(c.filesDir, "gecko_profile_" + ns.replace(Regex("[^a-zA-Z0-9_-]"), "_"))
    }
    private fun vaultDir(c: Context, slot: Int): File = File(profileDir(c, slot), "colablive_cookies").apply { mkdirs() }

    private val SLD = setOf("com", "net", "org", "gov", "edu", "co", "ac")
    /** Miền gốc xấp xỉ (eTLD+1): `accounts.google.com` -> `google.com`, `a.b.com.vn` -> `b.com.vn`. */
    fun baseDomain(host: String): String {
        val h = host.trim().trimStart('.').lowercase()
        if (!h.contains('.') || h.matches(Regex("[0-9.]+"))) return h
        val p = h.split(".")
        if (p.size <= 2) return h
        return if (p.last().length == 2 && p[p.size - 2] in SLD) p.takeLast(3).joinToString(".") else p.takeLast(2).joinToString(".")
    }
    private fun matches(cookieHost: String, base: String): Boolean {
        val h = cookieHost.trimStart('.').lowercase()
        return h == base || h.endsWith(".$base")
    }
    private fun encodeCtx(ctx: String) = "gvctx" + BigInteger(1, ctx.toByteArray(Charsets.UTF_8)).toString(16)

    private fun openCopy(c: Context, profileDir: File): Pair<SQLiteDatabase, File>? {
        val src = File(profileDir, "cookies.sqlite")
        if (!src.isFile) return null
        val tmp = File(c.cacheDir, "cookie_view_${System.nanoTime()}").apply { mkdirs() }
        src.copyTo(File(tmp, "cookies.sqlite"), overwrite = true)
        val wal = File(profileDir, "cookies.sqlite-wal")
        if (wal.isFile) try { wal.copyTo(File(tmp, "cookies.sqlite-wal"), overwrite = true) } catch (e: Exception) { /* ghi dở: bỏ qua */ }
        // Không sao chép -shm (sẽ được dựng lại từ -wal) để tránh lệch với WAL đang được Gecko ghi.
        return Pair(SQLiteDatabase.openDatabase(File(tmp, "cookies.sqlite").absolutePath, null, SQLiteDatabase.OPEN_READWRITE), tmp)
    }

    /** Cookie của miền gốc, chỉ trong vùng đang dùng (chung '' hoặc contextId hiện tại). Trả (các hàng, tên cột). */
    fun readSiteCookies(c: Context, slot: Int, host: String, contextIdFull: String, shared: Boolean): Pair<List<List<Any?>>, List<String>> {
        val base = baseDomain(host)
        val (db, tmp) = openCopy(c, profileDir(c, slot)) ?: return Pair(emptyList(), emptyList())
        try {
            val rows = ArrayList<List<Any?>>()
            var cols: List<String> = emptyList()
            val ctxTag = encodeCtx(contextIdFull)
            db.rawQuery("SELECT * FROM moz_cookies", null).use { cur ->
                cols = cur.columnNames.toList()
                val hostIdx = cur.getColumnIndex("host")
                val oaIdx = cur.getColumnIndex("originAttributes")
                while (cur.moveToNext()) {
                    if (!matches(cur.getString(hostIdx) ?: "", base)) continue
                    val oa = if (oaIdx >= 0) cur.getString(oaIdx) ?: "" else ""
                    if (oa.contains("privateBrowsingId")) continue
                    val inCurrent = if (shared) oa.isEmpty() else oa.contains(ctxTag)
                    if (!inCurrent) continue
                    val r = ArrayList<Any?>(cols.size)
                    for (i in cols.indices) r.add(when (cur.getType(i)) {
                        Cursor.FIELD_TYPE_INTEGER -> cur.getLong(i)
                        Cursor.FIELD_TYPE_FLOAT -> cur.getDouble(i)
                        Cursor.FIELD_TYPE_STRING -> cur.getString(i)
                        Cursor.FIELD_TYPE_BLOB -> android.util.Base64.encodeToString(cur.getBlob(i), android.util.Base64.NO_WRAP)
                        else -> null
                    })
                    rows.add(r)
                }
            }
            return Pair(rows, cols)
        } finally { try { db.close() } catch (e: Throwable) {}; tmp.deleteRecursively() }
    }

    private fun dirSize(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

    /** "Dữ liệu đã lưu trữ": kích thước thư mục storage của miền (localStorage, IndexedDB, cache API) + dung lượng chữ của cookie. */
    fun siteDataBytes(c: Context, slot: Int, host: String, rows: List<List<Any?>>, cols: List<String>): Long {
        val base = baseDomain(host)
        var total = 0L
        val ni = cols.indexOf("name"); val vi = cols.indexOf("value")
        for (r in rows) {
            total += ((if (ni >= 0) r[ni] as? String else null)?.length ?: 0) + ((if (vi >= 0) r[vi] as? String else null)?.length ?: 0)
        }
        val re = Regex("^[a-z\\-]+\\+\\+\\+([^:^+]+)")
        File(profileDir(c, slot), "storage/default").listFiles()?.forEach { d ->
            val m = re.find(d.name) ?: return@forEach
            val h = m.groupValues[1].lowercase()
            if (h == base || h.endsWith(".$base")) total += dirSize(d)
        }
        return total
    }

    // ---------------- Bản lưu ----------------
    fun save(c: Context, slot: Int, title: String, host: String, rows: List<List<Any?>>, cols: List<String>): Snap {
        val id = System.currentTimeMillis().toString(36) + "_" + (1000..9999).random()
        val base = baseDomain(host)
        val created = System.currentTimeMillis()
        val j = JSONObject()
        j.put("id", id).put("title", title).put("host", host).put("base", base).put("created", created).put("count", rows.size)
        j.put("cols", JSONArray(cols))
        val arr = JSONArray()
        for (r in rows) { val a = JSONArray(); for (v in r) a.put(v ?: JSONObject.NULL); arr.put(a) }
        j.put("rows", arr)
        File(vaultDir(c, slot), "$id.json").writeText(j.toString())
        DebugLog.log("Khe $slot: [Cookie] đã LƯU bộ cookie '$title' ($base, ${rows.size} cookie) -> colablive_cookies/$id.json (đi theo backup)")
        return Snap(id, title, host, base, created, rows.size)
    }

    fun list(c: Context, slot: Int): List<Snap> {
        val out = ArrayList<Snap>()
        vaultDir(c, slot).listFiles { f -> f.name.endsWith(".json") }?.forEach { f ->
            try {
                val j = JSONObject(f.readText())
                out.add(Snap(j.getString("id"), j.optString("title", f.nameWithoutExtension), j.optString("host"), j.optString("base"), j.optLong("created"), j.optInt("count")))
            } catch (e: Exception) { /* file hỏng: bỏ qua */ }
        }
        return out
    }

    fun delete(c: Context, slot: Int, id: String) { File(vaultDir(c, slot), "$id.json").delete() }

    fun rename(c: Context, slot: Int, id: String, newTitle: String) {
        val f = File(vaultDir(c, slot), "$id.json")
        val j = JSONObject(f.readText()); j.put("title", newTitle); f.writeText(j.toString())
    }

    fun queueReplace(c: Context, slot: Int, id: String) { AppPrefs.setString(c, slot, "cookie_replace_pending", id) }
    fun hasPending(c: Context, slot: Int) = AppPrefs.getString(c, slot, "cookie_replace_pending", "").isNotBlank()

    /** Gọi TRƯỚC khi tạo GeckoRuntime (Gecko chưa mở cookies.sqlite). Cờ luôn bị xoá để lỗi không lặp vô hạn. */
    fun applyPending(c: Context, slot: Int, profileDir: File, contextIdFull: String, shared: Boolean) {
        val id = AppPrefs.getString(c, slot, "cookie_replace_pending", "")
        if (id.isBlank()) return
        AppPrefs.setString(c, slot, "cookie_replace_pending", "")
        try {
            val f = File(vaultDir(c, slot), "$id.json")
            if (!f.isFile) { DebugLog.log("Khe $slot: [Cookie] THAY: không thấy bản lưu $id — bỏ qua"); return }
            val j = JSONObject(f.readText())
            val base = j.getString("base")
            val cols = j.getJSONArray("cols").let { a -> (0 until a.length()).map { a.getString(it) } }
            val rowsJ = j.getJSONArray("rows")
            val dbFile = File(profileDir, "cookies.sqlite")
            if (!dbFile.isFile) { DebugLog.log("Khe $slot: [Cookie] THAY: hồ sơ chưa có cookies.sqlite — bỏ qua"); return }
            val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
            try {
                db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { it.moveToFirst() }
                dbFile.copyTo(File(profileDir, "cookies.sqlite.before_replace"), overwrite = true)
                val tableCols = ArrayList<String>()
                db.rawQuery("PRAGMA table_info(moz_cookies)", null).use { cur -> while (cur.moveToNext()) tableCols.add(cur.getString(1)) }
                val targetOa = if (shared) "" else "^geckoViewUserContextId=" + encodeCtx(contextIdFull)
                var deleted = 0; var inserted = 0
                db.beginTransaction()
                try {
                    deleted = db.delete("moz_cookies", "(host = ? OR host = ? OR host LIKE ?) AND originAttributes NOT LIKE '%privateBrowsingId%'", arrayOf(base, ".$base", "%.$base"))
                    for (ri in 0 until rowsJ.length()) {
                        val row = rowsJ.getJSONArray(ri)
                        val cv = ContentValues()
                        for (i in cols.indices) {
                            val col = cols[i]
                            if (col == "id" || col == "originAttributes" || col !in tableCols) continue
                            if (row.isNull(i)) { cv.putNull(col); continue }
                            when (val v = row.get(i)) {
                                is Int -> cv.put(col, v.toLong())
                                is Long -> cv.put(col, v)
                                is Double -> cv.put(col, v)
                                else -> cv.put(col, v.toString())
                            }
                        }
                        cv.put("originAttributes", targetOa)
                        if (db.insertWithOnConflict("moz_cookies", null, cv, SQLiteDatabase.CONFLICT_REPLACE) != -1L) inserted++
                    }
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
                DebugLog.log("Khe $slot: [Cookie] ĐÃ THAY cookie của '$base' bằng bộ '${j.optString("title")}': xoá $deleted, chèn $inserted (vùng='${if (shared) "chung" else targetOa}')")
            } finally { db.close() }
        } catch (e: Throwable) {
            DebugLog.log("Khe $slot: [Cookie] THAY THẤT BẠI ${e.javaClass.simpleName}: ${e.message} — cookie giữ nguyên (đã có cookies.sqlite.before_replace)")
        }
    }
}
