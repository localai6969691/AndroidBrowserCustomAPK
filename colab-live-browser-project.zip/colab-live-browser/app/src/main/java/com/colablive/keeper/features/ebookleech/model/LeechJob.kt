package com.colablive.keeper.features.ebookleech.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * Một Job cào — tương đương "Site" trong KDN Auto Leech.
 * Lưu dưới dạng JSON vào SharedPreferences.
 */
data class LeechJob(
    val id: String,
    val name: String,
    val projectId: String = "",         // "" = chưa phân nhóm dự án
    val listPageUrl: String,
    val listPageUrlPattern: String,     // Bỏ trống + bật autoDetectPagination để tự dò
    val maxPages: Int = 50,

    val chapterLinkSelector: String,
    val chapterLinkAttribute: String = "href",

    val chapterTitleSelector: String,
    val chapterContentSelector: String,

    val bookTitleSelector: String = "",
    val bookCoverSelector: String = "",
    val authorSelector: String = "",

    val outputFormat: OutputFormat = OutputFormat.EPUB,
    val outputFileName: String = "",

    val scheduleMode: ScheduleMode = ScheduleMode.MANUAL,
    val intervalMinutes: Int = 60,       // Lưu ý: WorkManager có sàn tối thiểu 15 phút

    val status: JobStatus = JobStatus.IDLE,
    val chaptersCollected: Int = 0,
    val lastRunAt: Long = 0L,
    val outputFilePath: String = "",

    val delayBetweenPagesMs: Long = 1500,
    val useJsRendering: Boolean = true,
    val customUserAgent: String = "",
    val cookieHeader: String = "",

    // ── Dùng phiên đăng nhập có sẵn (đọc source thật mới phát hiện: bản cũ
    //    tab crawl luôn isPrivate=true → chạy hoàn toàn trong RAM, KHÔNG
    //    ghi cookie/storage xuống đĩa, tự cô lập khỏi mọi session thường —
    //    nghĩa là KHÔNG BAO GIỜ dùng được đăng nhập có sẵn, mỗi lần cào là
    //    phiên trắng tinh. Bật cờ này → tab crawl dùng isPrivate=false,
    //    chia sẻ ĐÚNG cookie jar thật của slot đó — nếu bạn đã đăng nhập
    //    site đó trong app (ở tab thường), tab crawl sẽ mang theo đăng nhập
    //    đó, và Gecko tự lưu cookie xuống đĩa như mọi tab thường khác —
    //    không cần addon tự "lưu" gì thêm, đây là hành vi chuẩn có sẵn của
    //    trình duyệt. ĐÁNH ĐỔI: URL từng chương sẽ bị ghi vào lịch sử duyệt
    //    web + hiện tạm trên thanh địa chỉ trong lúc cào (nếu app đang mở
    //    đúng màn hình đó) — xem PROJECT_STATUS mục "đánh đổi kiến trúc". )
    val useLoginSession: Boolean = false,

    // ── Đăng thẳng lên WordPress, mỗi chương = 1 bài viết ────────────────
    // Dùng WP REST API (wp-json/wp/v2/posts) + Application Password (tính
    // năng lõi từ WordPress 5.6+, KHÔNG cần cài thêm plugin phía WP nếu
    // site chạy HTTPS — nếu HTTP thuần hoặc bản WP cũ hơn, cần plugin
    // "Application Passwords" cài thêm). Đăng NGAY sau mỗi chương cào xong
    // (giống đúng cách KDN Auto Leech hoạt động), không đợi cào hết cả job.
    val publishToWordPress: Boolean = false,
    val wpSiteUrl: String = "",          // vd https://mysite.com (KHÔNG có dấu / cuối)
    val wpUsername: String = "",
    val wpAppPassword: String = "",      // LƯU Ý BẢO MẬT: đang lưu THÔ (plaintext) trong SharedPreferences — xem PROJECT_STATUS
    val wpPostStatus: String = "draft",  // draft | publish | private | pending
    val wpCategoryId: Int = 0,           // 0 = không gán category
    val wpPostTitleTemplate: String = "{title}",  // hỗ trợ {title} và {bookName}

    // ── Trạng thái chờ xử lý thủ công (Cloudflare/captcha) ──────────────────
    val pendingActionUrl: String = "",
    val pendingActionReason: String = "",

    // ── Tự cuộn trang trước khi lấy nội dung — cho site lazy-load khi cuộn
    //    (ảnh/danh sách chỉ render khi cuộn tới, kiểu IntersectionObserver).
    //    Không bật thì trang tải xong + đợi 800ms là lấy ngay — đủ cho JS
    //    framework render bình thường (React/Vue) nhưng KHÔNG đủ cho nội
    //    dung chỉ xuất hiện khi thật sự cuộn tới.
    val simulateScrollForLazyLoad: Boolean = false,
    val maxScrollAttempts: Int = 6,

    // ── Tính năng 1: Regex/Callback pipeline ──────────────────────────────
    val regexRules: List<RegexRule> = emptyList(),

    // ── Tính năng 2: Tải ảnh offline ───────────────────────────────────────
    val downloadImages: Boolean = false,
    val maxImagesPerChapter: Int = 30,

    // ── Tính năng 4: Tự dò phân trang & AJAX endpoint (dò/gợi ý — KHÔNG tự dùng làm nguồn) ──
    val autoDetectPagination: Boolean = false,
    val suggestAjaxEndpoints: Boolean = false,
    val detectedAjaxEndpoints: List<String> = emptyList(),  // ghi lại để hiển thị cho user, không tự dùng
    val resolvedPaginationPattern: String = "",             // pattern đã dò ra, cache lại cho lần sau

    // ── ĐÃ THÊM — "AJAX Leech thật": DÙNG THẲNG 1 JSON API làm nguồn dữ
    // liệu (khác suggestAjaxEndpoints ở trên — cái đó chỉ DÒ & GỢI Ý, không
    // tự leech). Path dùng cú pháp JsonPathExtractor ("a.b.c", "a.b[0].c").
    val ajaxListMode: Boolean = false,               // Phase 1 (thu thập link chương) dùng JSON API thay vì bóc HTML
    val ajaxListUrlTemplate: String = "",            // URL API danh sách chương — hỗ trợ {page}/{base}, vd "https://x.com/api/ch?novel=1&page={page}"
    val ajaxListItemsPath: String = "",              // path TỚI mảng chương trong JSON trả về ("" = mảng nằm ngay ở gốc)
    val ajaxListUrlField: String = "url",            // field TRONG từng phần tử mảng chứa URL chương
    val ajaxContentMode: Boolean = false,            // Phase 2 (cào nội dung) coi mỗi link chương LÀ 1 endpoint JSON, không phải trang HTML
    val ajaxContentTitleField: String = "title",     // path field tiêu đề trong JSON của 1 chương
    val ajaxContentField: String = "content",        // path field nội dung (HTML hoặc text) trong JSON của 1 chương

    // ── ĐÃ THÊM — "Cào từ xa qua GitHub Actions": xem RemoteCrawlRunner.kt
    // (đầy đủ giới hạn/lý do) — "NONE" (mặc định, cào tại máy như cũ) /
    // "GITHUB" (đẩy job lên repo, Python trên Actions cào, đồng bộ
    // checkpoint 2 chiều) / "COLAB" (cũng đẩy job lên repo nhưng KHÔNG có API
    // trigger từ Colab nên người dùng tự mở notebook + Run all; xem
    // RemoteCrawlRunner nhánh COLAB và nút "Cào từ xa (GitHub / Colab)").
    val remoteBackend: String = "NONE",

    // ĐÃ THÊM — remote (GitHub) không có màn hình cho người dùng giải trực
    // tiếp như local (không có tab thật) — khi bị chặn dai dẳng, Python
    // chụp màn hình trang chặn, commit lên repo, app tải về hiển thị ở
    // đây thay cho "xem tab thật" như luồng NEEDS_ACTION cục bộ. Rỗng ở
    // job local (không cần, xem trực tiếp trang thật trong tab).
    val pendingActionScreenshotPath: String = "",

    // ── Kịch bản nhiều bước tuỳ biến (không hardcode 2 tầng list→chapter) ──
    val preListStages: List<CrawlStage> = emptyList(),

    // ── Mục lục tuỳ chỉnh: xem trước & sắp xếp trước khi xuất ───────────────
    val manualTocReview: Boolean = false,
    val tocOverride: List<TocNode> = emptyList(),

    // ── Bản 7.100 — học từ KDN Auto Leech (mục 224). TẤT CẢ mặc định TẮT/0 => job cũ chạy y như trước. Chỉ áp dụng khi cào TẠI MÁY
    //    (cào từ xa qua GitHub chạy script Python riêng, không đọc các trường này). ──────────────────────────────────────────────
    /** Cập nhật tăng dần: nhớ nội dung chương đã cào (theo URL) giữa các lần chạy, lần sau chỉ mở các chương MỚI rồi xuất lại cả sách. KDN gọi là lưu URL đã cào để chống trùng. */
    /** Bản 7.101: dòng tóm tắt lần chạy gần nhất của chế độ cập nhật tăng dần (vd "08/11 11:40 — không có chương mới…"), hiện trên thẻ job. Rỗng = chưa có. */
    val lastRunNote: String = "",
    val incrementalUpdate: Boolean = false,
    /** Khi cập nhật tăng dần: vẫn cào LẠI N chương CUỐI dù đã có trong kho (site hay sửa chương mới đăng). 0 = không cào lại. */
    val refreshLastN: Int = 0,
    /**
     * Bản 7.104 — QUÉT NHANH DANH SÁCH THEO ĐIỂM NEO (chỉ có tác dụng khi `incrementalUpdate` và đã có kho từ lần trước): chỉ đọc ĐẦU + CUỐI danh sách chương, phần giữa lấy thứ tự từ kho
     * (xem [com.colablive.keeper.features.ebookleech.engine.ListScanPlanner]). Cứ 10 lần nhanh liên tiếp thì quét ĐẦY ĐỦ một lần; mọi dấu hiệu bất thường tự quét đầy đủ. Tắt = luôn quét đủ.
     */
    val listFastScan: Boolean = true,
    /** Bỏ qua (không đưa vào ebook) chương có text chứa BẤT KỲ cụm nào ở đây (không phân biệt hoa/thường), vd "chương này bị khoá". */
    val skipIfTextContains: List<String> = emptyList(),
    /** Bỏ qua chương có text (sau khi áp luật tìm & thay) ngắn hơn N ký tự — bắt chương rỗng/chỉ có thông báo. 0 = tắt. */
    val minTextLength: Int = 0,
    /** Chương chia nhiều trang: selector của nút/link "trang kế" TRONG trang chương. Rỗng = chương 1 trang như cũ. */
    val chapterNextPageSelector: String = "",
    /** Số trang tối đa gộp cho MỘT chương (chặn vòng lặp vô tận khi site dùng link "trang kế" quay vòng). */
    val maxChapterPages: Int = 10,

    // ── Bản 7.102 (mục 226) ─────────────────────────────────────────────────────────────────────────────────────────────────
    /** Cập nhật Ở FILE CŨ: mỗi lần xuất ghi ĐÈ lên đúng file ebook của lần trước (tên cố định, không dấu thời gian) thay vì tạo file mới. File chứa cả truyện (cũ + chương mới). Mặc định TẮT. */
    val updateExistingFile: Boolean = false,
    /** Báo thông báo Android khi một lần chạy (không phải lần xuất đầu tiên) có chương MỚI so với lần xuất trước. Mặc định BẬT; chỉ báo khi thật sự có chương mới. */
    val notifyNewChapters: Boolean = true,

    // ── Bản 7.104 — THÔNG TIN TRUYỆN (tác giả, tóm tắt, thể loại, tag, tình trạng, đánh giá, bìa...) lưu cùng ebook làm nguyên liệu đăng lên web truyện. ─────────────────────────
    // Cùng tên trường với crawler.py/LeechDesk (cào từ xa đọc đúng các khoá này). Mặc định BẬT: trích tự động từ JSON-LD/Open Graph/meta/nhãn "Tác giả:..." của trang; lỗi không làm hỏng lần cào.
    /** Bật lấy thông tin truyện khi cào. */
    val storyMetaEnabled: Boolean = true,
    /** Trang chứa thông tin truyện; rỗng = dùng trang danh sách chương (listPageUrl). */
    val storyInfoUrl: String = "",
    /** Selector theo trường (khoá: title, author, summary, genres, tags, status, rating, cover, language, altTitles, series, translator, publisher, publishedAt, updatedAt; khoá lạ => trường `extra`). Thắng mọi nguồn tự động. */
    val storyMetaSelectors: Map<String, String> = emptyMap(),
    /** Thông tin người dùng NHẬP TAY — thắng tất cả (kể cả selector). null = không nhập. */
    val storyMetaManual: StoryMeta? = null,
    /**
     * Chờ thêm (ms) sau khi trang tải xong trước khi đọc thông tin truyện — trang dựng bằng JS cần thời gian. CHỈ runner từ xa (crawler.py / LeechDesk) đọc giá trị này; crawler trên
     * ĐIỆN THOẠI đọc sau độ trễ cố định của `evaluateJsOnTab` (~0,8 giây) và không có ô chỉnh trong giao diện. Giữ khoá trong JSON để một job chạy được ở cả hai nơi.
     */
    val storyMetaWaitMs: Int = 1200,
    /** Xuất kèm file `<tên ebook>.story.json` (+ `<tên ebook>.cover.<đuôi>`) — dữ liệu máy đọc được để đăng lên web truyện. */
    val storySidecar: Boolean = true,
) {

    enum class OutputFormat { EPUB, TXT, HTML }
    enum class ScheduleMode { MANUAL, INTERVAL, DAILY }
    enum class JobStatus { IDLE, RUNNING, REVIEW_READY, NEEDS_ACTION, PAUSED, DONE, ERROR }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("projectId", projectId)
        put("listPageUrl", listPageUrl)
        put("listPageUrlPattern", listPageUrlPattern)
        put("maxPages", maxPages)
        put("chapterLinkSelector", chapterLinkSelector)
        put("chapterLinkAttribute", chapterLinkAttribute)
        put("chapterTitleSelector", chapterTitleSelector)
        put("chapterContentSelector", chapterContentSelector)
        put("bookTitleSelector", bookTitleSelector)
        put("bookCoverSelector", bookCoverSelector)
        put("authorSelector", authorSelector)
        put("outputFormat", outputFormat.name)
        put("outputFileName", outputFileName)
        put("scheduleMode", scheduleMode.name)
        put("intervalMinutes", intervalMinutes)
        put("status", status.name)
        put("chaptersCollected", chaptersCollected)
        put("lastRunAt", lastRunAt)
        put("outputFilePath", outputFilePath)
        put("delayBetweenPagesMs", delayBetweenPagesMs)
        put("useJsRendering", useJsRendering)
        put("customUserAgent", customUserAgent)
        put("cookieHeader", cookieHeader)
        put("useLoginSession", useLoginSession)
        put("publishToWordPress", publishToWordPress)
        put("wpSiteUrl", wpSiteUrl)
        put("wpUsername", wpUsername)
        put("wpAppPassword", wpAppPassword)
        put("wpPostStatus", wpPostStatus)
        put("wpCategoryId", wpCategoryId)
        put("wpPostTitleTemplate", wpPostTitleTemplate)
        put("pendingActionUrl", pendingActionUrl)
        put("pendingActionReason", pendingActionReason)
        put("simulateScrollForLazyLoad", simulateScrollForLazyLoad)
        put("maxScrollAttempts", maxScrollAttempts)
        put("regexRules", RegexRule.listToJson(regexRules))
        put("downloadImages", downloadImages)
        put("maxImagesPerChapter", maxImagesPerChapter)
        put("autoDetectPagination", autoDetectPagination)
        put("suggestAjaxEndpoints", suggestAjaxEndpoints)
        put("detectedAjaxEndpoints", JSONArray(detectedAjaxEndpoints))
        put("resolvedPaginationPattern", resolvedPaginationPattern)
        put("ajaxListMode", ajaxListMode)
        put("ajaxListUrlTemplate", ajaxListUrlTemplate)
        put("ajaxListItemsPath", ajaxListItemsPath)
        put("ajaxListUrlField", ajaxListUrlField)
        put("ajaxContentMode", ajaxContentMode)
        put("ajaxContentTitleField", ajaxContentTitleField)
        put("ajaxContentField", ajaxContentField)
        put("remoteBackend", remoteBackend)
        put("pendingActionScreenshotPath", pendingActionScreenshotPath)
        put("preListStages", CrawlStage.listToJson(preListStages))
        put("manualTocReview", manualTocReview)
        put("tocOverride", TocNode.listToJson(tocOverride))
        put("incrementalUpdate", incrementalUpdate)
        put("lastRunNote", lastRunNote)
        put("refreshLastN", refreshLastN)
        put("listFastScan", listFastScan)
        put("skipIfTextContains", JSONArray(skipIfTextContains))
        put("minTextLength", minTextLength)
        put("chapterNextPageSelector", chapterNextPageSelector)
        put("maxChapterPages", maxChapterPages)
        put("updateExistingFile", updateExistingFile)
        put("notifyNewChapters", notifyNewChapters)
        put("storyMetaEnabled", storyMetaEnabled)
        put("storyInfoUrl", storyInfoUrl)
        put("storyMetaSelectors", JSONObject(storyMetaSelectors))
        if (storyMetaManual != null && !storyMetaManual.isBlank()) put("storyMetaManual", storyMetaManual.toJson())
        put("storyMetaWaitMs", storyMetaWaitMs)
        put("storySidecar", storySidecar)
    }

    companion object {
        fun fromJson(json: JSONObject): LeechJob = LeechJob(
            id = json.getString("id"),
            name = json.getString("name"),
            projectId = json.optString("projectId", ""),
            listPageUrl = json.getString("listPageUrl"),
            listPageUrlPattern = json.optString("listPageUrlPattern", ""),
            maxPages = json.optInt("maxPages", 50),
            chapterLinkSelector = json.getString("chapterLinkSelector"),
            chapterLinkAttribute = json.optString("chapterLinkAttribute", "href"),
            chapterTitleSelector = json.getString("chapterTitleSelector"),
            chapterContentSelector = json.getString("chapterContentSelector"),
            bookTitleSelector = json.optString("bookTitleSelector", ""),
            bookCoverSelector = json.optString("bookCoverSelector", ""),
            authorSelector = json.optString("authorSelector", ""),
            outputFormat = OutputFormat.valueOf(json.optString("outputFormat", "EPUB")),
            outputFileName = json.optString("outputFileName", ""),
            scheduleMode = ScheduleMode.valueOf(json.optString("scheduleMode", "MANUAL")),
            intervalMinutes = json.optInt("intervalMinutes", 60),
            status = JobStatus.valueOf(json.optString("status", "IDLE")),
            chaptersCollected = json.optInt("chaptersCollected", 0),
            lastRunAt = json.optLong("lastRunAt", 0L),
            outputFilePath = json.optString("outputFilePath", ""),
            delayBetweenPagesMs = json.optLong("delayBetweenPagesMs", 1500L),
            useJsRendering = json.optBoolean("useJsRendering", true),
            customUserAgent = json.optString("customUserAgent", ""),
            cookieHeader = json.optString("cookieHeader", ""),
            useLoginSession = json.optBoolean("useLoginSession", false),
            publishToWordPress = json.optBoolean("publishToWordPress", false),
            wpSiteUrl = json.optString("wpSiteUrl", ""),
            wpUsername = json.optString("wpUsername", ""),
            wpAppPassword = json.optString("wpAppPassword", ""),
            wpPostStatus = json.optString("wpPostStatus", "draft"),
            wpCategoryId = json.optInt("wpCategoryId", 0),
            wpPostTitleTemplate = json.optString("wpPostTitleTemplate", "{title}"),
            pendingActionUrl = json.optString("pendingActionUrl", ""),
            pendingActionReason = json.optString("pendingActionReason", ""),
            simulateScrollForLazyLoad = json.optBoolean("simulateScrollForLazyLoad", false),
            maxScrollAttempts = json.optInt("maxScrollAttempts", 6),
            regexRules = json.optJSONArray("regexRules")?.let { RegexRule.listFromJson(it) } ?: emptyList(),
            downloadImages = json.optBoolean("downloadImages", false),
            maxImagesPerChapter = json.optInt("maxImagesPerChapter", 30),
            autoDetectPagination = json.optBoolean("autoDetectPagination", false),
            suggestAjaxEndpoints = json.optBoolean("suggestAjaxEndpoints", false),
            detectedAjaxEndpoints = json.optJSONArray("detectedAjaxEndpoints")?.let { arr ->
                (0 until arr.length()).map { arr.getString(it) }
            } ?: emptyList(),
            resolvedPaginationPattern = json.optString("resolvedPaginationPattern", ""),
            ajaxListMode = json.optBoolean("ajaxListMode", false),
            ajaxListUrlTemplate = json.optString("ajaxListUrlTemplate", ""),
            ajaxListItemsPath = json.optString("ajaxListItemsPath", ""),
            ajaxListUrlField = json.optString("ajaxListUrlField", "url"),
            ajaxContentMode = json.optBoolean("ajaxContentMode", false),
            ajaxContentTitleField = json.optString("ajaxContentTitleField", "title"),
            ajaxContentField = json.optString("ajaxContentField", "content"),
            remoteBackend = json.optString("remoteBackend", "NONE"),
            pendingActionScreenshotPath = json.optString("pendingActionScreenshotPath", ""),
            preListStages = json.optJSONArray("preListStages")?.let { CrawlStage.listFromJson(it) } ?: emptyList(),
            manualTocReview = json.optBoolean("manualTocReview", false),
            tocOverride = json.optJSONArray("tocOverride")?.let { TocNode.listFromJson(it) } ?: emptyList(),
            incrementalUpdate = json.optBoolean("incrementalUpdate", false),
            lastRunNote = json.optString("lastRunNote", ""),
            refreshLastN = json.optInt("refreshLastN", 0),
            listFastScan = json.optBoolean("listFastScan", true),
            skipIfTextContains = json.optJSONArray("skipIfTextContains")?.let { arr ->
                (0 until arr.length()).map { arr.getString(it) }
            } ?: emptyList(),
            minTextLength = json.optInt("minTextLength", 0),
            chapterNextPageSelector = json.optString("chapterNextPageSelector", ""),
            maxChapterPages = json.optInt("maxChapterPages", 10),
            updateExistingFile = json.optBoolean("updateExistingFile", false),
            notifyNewChapters = json.optBoolean("notifyNewChapters", true),
            storyMetaEnabled = json.optBoolean("storyMetaEnabled", true),
            storyInfoUrl = json.optString("storyInfoUrl", ""),
            storyMetaSelectors = json.optJSONObject("storyMetaSelectors")?.let { o ->
                val m = LinkedHashMap<String, String>()
                val it = o.keys()
                while (it.hasNext()) { val k = it.next(); val v = o.optString(k, "").trim(); if (k.isNotBlank() && v.isNotEmpty()) m[k.trim()] = v }
                m
            } ?: emptyMap(),
            storyMetaManual = json.optJSONObject("storyMetaManual")?.let { StoryMeta.fromJson(it) }?.takeIf { !it.isBlank() },
            storyMetaWaitMs = json.optInt("storyMetaWaitMs", 1200).coerceIn(0, 30_000),
            storySidecar = json.optBoolean("storySidecar", true),
        )

        fun listFromJson(arr: JSONArray): List<LeechJob> =
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }

        fun listToJson(jobs: List<LeechJob>): JSONArray =
            JSONArray().also { arr -> jobs.forEach { arr.put(it.toJson()) } }
    }
}
