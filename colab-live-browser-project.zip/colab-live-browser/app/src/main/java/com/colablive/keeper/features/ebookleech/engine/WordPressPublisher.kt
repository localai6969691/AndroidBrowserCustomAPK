package com.colablive.keeper.features.ebookleech.engine

import com.colablive.keeper.features.ebookleech.model.LeechChapter
import com.colablive.keeper.features.ebookleech.model.LeechJob
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import android.util.Base64

/**
 * WordPressPublisher — đăng 1 chương thành 1 bài viết WordPress qua REST
 * API (`wp-json/wp/v2/posts`), dùng Application Password (tính năng lõi
 * WordPress ≥ 5.6, không cần plugin thêm NẾU site chạy HTTPS — site HTTP
 * thuần hoặc bản WP cũ hơn cần cài plugin "Application Passwords").
 *
 * Đây là mảnh còn thiếu để trả lời "có dùng lại được để đăng WP không" —
 * TRƯỚC ĐÂY không có, giờ đã có: dữ liệu `LeechChapter` (title + htmlContent)
 * vốn đã đúng hình dạng cần thiết, chỉ thiếu bước gọi API để đẩy lên.
 *
 * CÁCH LẤY Application Password: WP Admin → Users → Profile → mục
 * "Application Passwords" → đặt tên bất kỳ → Add New — WP tự sinh 1 chuỗi
 * dạng "xxxx xxxx xxxx xxxx xxxx xxxx", dùng CHUỖI ĐÓ (không phải mật khẩu
 * đăng nhập thật) làm `wpAppPassword`.
 *
 * CHẠY TRÊN BACKGROUND THREAD — có network I/O, gọi từ crawler qua
 * `Thread { ... }` giống pattern `ImageDownloader` đã dùng.
 */
object WordPressPublisher {

    data class PublishResult(val success: Boolean, val postUrl: String? = null, val error: String? = null)

    fun publishChapter(job: LeechJob, chapter: LeechChapter, bookName: String): PublishResult {
        if (job.wpSiteUrl.isBlank() || job.wpUsername.isBlank() || job.wpAppPassword.isBlank()) {
            return PublishResult(false, error = "Chưa đủ thông tin site/tài khoản WordPress")
        }

        val title = job.wpPostTitleTemplate
            .replace("{title}", chapter.title)
            .replace("{bookName}", bookName)

        val body = JSONObject().apply {
            put("title", title)
            put("content", chapter.htmlContent)
            put("status", job.wpPostStatus.ifBlank { "draft" })
            if (job.wpCategoryId > 0) put("categories", org.json.JSONArray().put(job.wpCategoryId))
        }

        var conn: HttpURLConnection? = null
        return try {
            val url = URL("${job.wpSiteUrl.trimEnd('/')}/wp-json/wp/v2/posts")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 15_000
                readTimeout = 15_000
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                val credentials = "${job.wpUsername}:${job.wpAppPassword}"
                val basicAuth = Base64.encodeToString(credentials.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                setRequestProperty("Authorization", "Basic $basicAuth")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code in 200..299) {
                val respText = conn.inputStream.bufferedReader().use { it.readText() }
                val respJson = JSONObject(respText)
                val link = respJson.optString("link", "")
                PublishResult(true, postUrl = link.ifBlank { null })
            } else {
                val errText = try { conn.errorStream?.bufferedReader()?.use { it.readText() } } catch (e: Exception) { null }
                PublishResult(false, error = "HTTP $code: ${errText?.take(200) ?: "không rõ lỗi"}")
            }
        } catch (e: Exception) {
            PublishResult(false, error = e.message ?: "Lỗi kết nối WordPress")
        } finally {
            conn?.disconnect()
        }
    }
}
