package com.colablive.keeper.features.ebookleech.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * Một node trong cây mục lục XUẤT RA — KHÁC với thứ tự cào thô. Cho phép:
 *  - Đổi tên hiển thị khác title gốc cào được (label)
 *  - Gộp nhiều chương vào 1 "Tập" / "Phần" (node không có chapterIndex, có children)
 *  - Sắp xếp lại thứ tự tuỳ ý (thứ tự trong list children chính là thứ tự xuất)
 *  - Loại chương khỏi ebook (chương nào không xuất hiện trong cây này thì bị bỏ)
 *
 * Nếu job.tocOverride rỗng → EbookExporter tự build cây mặc định: mỗi chương
 * một node phẳng theo đúng thứ tự cào (hành vi y hệt bản cũ).
 */
data class TocNode(
    val id: String,
    val label: String,
    val chapterIndex: Int? = null,     // có giá trị = node lá, trỏ tới 1 LeechChapter.index cụ thể
    val children: List<TocNode> = emptyList(),  // không rỗng = node nhóm (Volume/Part)
) {
    val isGroup: Boolean get() = chapterIndex == null

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("label", label)
        if (chapterIndex != null) put("chapterIndex", chapterIndex)
        if (children.isNotEmpty()) put("children", listToJson(children))
    }

    companion object {
        fun fromJson(json: JSONObject): TocNode = TocNode(
            id = json.optString("id", java.util.UUID.randomUUID().toString()),
            label = json.optString("label", ""),
            chapterIndex = if (json.has("chapterIndex")) json.getInt("chapterIndex") else null,
            children = json.optJSONArray("children")?.let { listFromJson(it) } ?: emptyList(),
        )

        fun listFromJson(arr: JSONArray): List<TocNode> =
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }

        fun listToJson(nodes: List<TocNode>): JSONArray =
            JSONArray().also { arr -> nodes.forEach { arr.put(it.toJson()) } }

        /** Duyệt DFS lấy toàn bộ chapterIndex theo đúng thứ tự xuất (để build spine EPUB). */
        fun flattenChapterOrder(nodes: List<TocNode>): List<Int> =
            nodes.flatMap { node ->
                if (node.chapterIndex != null) listOf(node.chapterIndex)
                else flattenChapterOrder(node.children)
            }
    }
}
