package com.colablive.keeper.core

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

/**
 * Lớp chọn văn bản cho Monaco/Colab: hai núm kéo + thanh Cắt/Sao chép/Dán/Chọn hết (mục 100).
 *
 * Bằng chứng thiết kế (tra web): Monaco KHÔNG có núm chọn cảm ứng trên bất kỳ trình duyệt nào
 * (microsoft/monaco-editor #246, #1504, #4622, #4860) và tự vẽ vùng chọn bằng <div class="selected-text">,
 * nên Gecko không có Selection để hiện núm. Vì vậy app tự làm:
 *  - vị trí núm lấy từ hình chữ nhật .selected-text (content script `__lbMon.rects()`),
 *  - kéo núm = nhấp đặt điểm cố định (đầu còn lại) + shift+nhấp tại điểm ngón tay (`place`/`extend`).
 */
class MonacoSelectionUi(
    private val context: Context,
    private val hostView: View,
    private val evalJs: (String, (String?) -> Unit) -> Unit,
    private val actions: Actions
) {
    interface Actions {
        fun onCut()
        fun onCopy()
        fun onPaste()
        fun onSelectAll()
    }

    data class Sel(
        val n: Int,
        val sx: Float, val sy: Float, val sbx: Float, val sby: Float,
        val ex: Float, val ey: Float, val ebx: Float, val eby: Float,
        val tx: Float, val ty: Float
    )

    private val handler = Handler(Looper.getMainLooper())
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = context.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private var startHandle: HandleView? = null
    private var endHandle: HandleView? = null
    private var popup: View? = null
    private var sel: Sel? = null
    private var dragging = false
    private var lastSend = 0L
    private var inFlight = false

    val isShowing: Boolean get() = startHandle != null || popup != null

    /**
     * Có vùng chọn Monaco đang tồn tại (kể cả khi núm đã ẩn vì người dùng chạm trang). Dùng để chặn phím Xoá của bàn phím ảo
     * (mục 103): bàn phím ảo xoá qua InputConnection nên Monaco không xoá vùng chọn của nó.
     */
    @Volatile var selectionActive: Boolean = false

    /** Đọc lại từ trang xem vùng chọn còn không (không vẽ lại UI). */
    fun verifySelection() {
        evalJs("(function(){ try { return window.__lbMon ? __lbMon.rects() : '{\"n\":0}'; } catch(e){ return '{\"n\":0}'; } })()") { r ->
            selectionActive = parse(r) != null
        }
    }

    // ---------- chuyển toạ độ phân số (theo viewport trang) <-> toạ độ màn hình ----------
    private val loc = IntArray(2)
    private fun sx(fx: Float): Float { hostView.getLocationOnScreen(loc); return loc[0] + fx * hostView.width }
    private fun sy(fy: Float): Float { hostView.getLocationOnScreen(loc); return loc[1] + fy * hostView.height }
    private fun fx(x: Float): Float { hostView.getLocationOnScreen(loc); return (x - loc[0]) / hostView.width }
    private fun fy(y: Float): Float { hostView.getLocationOnScreen(loc); return (y - loc[1]) / hostView.height }

    fun parse(raw: String?): Sel? {
        val r = unwrapBridge(raw) ?: return null
        return try {
            val o = JSONObject(r)
            if (o.optInt("n", 0) == 0) null else Sel(
                o.getInt("n"),
                o.getDouble("sx").toFloat(), o.getDouble("sy").toFloat(), o.getDouble("sbx").toFloat(), o.getDouble("sby").toFloat(),
                o.getDouble("ex").toFloat(), o.getDouble("ey").toFloat(), o.getDouble("ebx").toFloat(), o.getDouble("eby").toFloat(),
                o.getDouble("tx").toFloat(), o.getDouble("ty").toFloat()
            )
        } catch (e: Exception) {
            DebugLog.log("MonacoSelectionUi: parse lỗi '$raw' — ${e.message}")
            null
        }
    }

    /** Đọc lại vùng chọn từ trang rồi vẽ lại núm + thanh. */
    fun refresh() {
        evalJs("(function(){ try { return window.__lbMon ? __lbMon.rects() : '{\"n\":0}'; } catch(e){ return '{\"n\":0}'; } })()") { r ->
            val s = parse(r)
            selectionActive = s != null
            handler.post { if (s == null) dismiss() else show(s) }
        }
    }

    fun show(s: Sel) {
        sel = s
        selectionActive = true
        removeHandles()
        removePopup()
        startHandle = addHandle(isStart = true, screenX = sx(s.sbx), screenY = sy(s.sby))
        endHandle = addHandle(isStart = false, screenX = sx(s.ebx), screenY = sy(s.eby))
        showBar(sx(s.tx), sy(s.ty), sy(s.eby), withSelection = true)
        DebugLog.log("MonacoSelectionUi: hiện núm — ${s.n} hình chữ nhật chọn, đầu=(${"%.3f".format(s.sx)},${"%.3f".format(s.sy)}) cuối=(${"%.3f".format(s.ex)},${"%.3f".format(s.ey)})")
    }

    /** Không chọn được gì (vd nhấn giữ trên dòng trống): chỉ hiện Dán / Chọn hết. */
    fun showBarOnly(screenX: Float, screenY: Float) {
        removeHandles(); removePopup(); sel = null
        showBar(screenX, screenY, screenY, withSelection = false)
    }

    fun dismiss() {
        dragging = false
        removeHandles()
        removePopup()
        sel = null
    }

    // ---------- thanh nút ----------
    private fun showBar(anchorX: Float, anchorTop: Float, anchorBottom: Float, withSelection: Boolean) {
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF2B2B2B.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        fun item(label: String, click: () -> Unit) {
            box.addView(TextView(context).apply {
                text = label; setTextColor(Color.WHITE); textSize = 14f
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setOnClickListener { click() }
            })
        }
        if (withSelection) {
            item("Cắt") { dismiss(); actions.onCut() }
            item("Sao chép") { dismiss(); actions.onCopy() }
        }
        item("Dán") { dismiss(); actions.onPaste() }
        item("Chọn hết") { actions.onSelectAll() } // giữ UI; onSelectAll tự gọi refresh()
        box.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = box.measuredWidth
        val screenW = context.resources.displayMetrics.widthPixels
        val x = (anchorX - w / 2f).toInt().coerceIn(dp(4), (screenW - w - dp(4)).coerceAtLeast(dp(4)))
        var y = (anchorTop - box.measuredHeight - dp(14)).toInt()
        if (y < dp(40)) y = (anchorBottom + dp(44)).toInt() // không đủ chỗ phía trên => đặt dưới núm
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y; token = hostView.windowToken }
        try { wm.addView(box, lp); popup = box } catch (e: Exception) { DebugLog.log("MonacoSelectionUi: lỗi hiện thanh nút — ${e.message}") }
    }

    private fun removePopup() { popup?.let { try { wm.removeView(it) } catch (e: Exception) {} }; popup = null }
    private fun removeHandles() {
        startHandle?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        endHandle?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        startHandle = null; endHandle = null
    }

    // ---------- núm kéo ----------
    private inner class HandleView(val isStart: Boolean) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1A73E8.toInt(); style = Paint.Style.FILL }
        override fun onDraw(c: Canvas) {
            val r = dp(9).toFloat(); val cx = width / 2f; val cy = dp(20).toFloat()
            c.drawCircle(cx, cy, r, paint)
            val p = Path().apply { moveTo(cx, 0f); lineTo(cx - r * 0.75f, cy - r * 0.6f); lineTo(cx + r * 0.75f, cy - r * 0.6f); close() }
            c.drawPath(p, paint)
        }
    }

    private fun addHandle(isStart: Boolean, screenX: Float, screenY: Float): HandleView {
        val hv = HandleView(isStart)
        val size = dp(44)
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenX - size / 2f).toInt(); y = screenY.toInt(); token = hostView.windowToken
        }
        hv.setOnTouchListener { _, ev -> onHandleTouch(hv, lp, ev) }
        try { wm.addView(hv, lp) } catch (e: Exception) { DebugLog.log("MonacoSelectionUi: lỗi hiện núm — ${e.message}") }
        return hv
    }

    private fun onHandleTouch(hv: HandleView, lp: WindowManager.LayoutParams, ev: MotionEvent): Boolean {
        val s = sel ?: return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                removePopup()
                // Đầu còn lại là điểm cố định: nhấp đặt con trỏ tại đó
                val fixedX = if (hv.isStart) s.ex else s.sx
                val fixedY = if (hv.isStart) s.ey else s.sy
                evalJs("(function(){ try { return __lbMon.place($fixedX, $fixedY); } catch(e){ return 'ERR '+e.message; } })()") {}
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return true
                val size = dp(44)
                lp.x = (ev.rawX - size / 2f).toInt(); lp.y = (ev.rawY - dp(8)).toInt()
                try { wm.updateViewLayout(hv, lp) } catch (e: Exception) {}
                sendExtend(ev.rawX, ev.rawY - dp(34), force = false)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) return true
                dragging = false
                sendExtend(ev.rawX, ev.rawY - dp(34), force = true)
                handler.postDelayed({ refresh() }, 250)
                return true
            }
        }
        return true
    }

    private fun sendExtend(rawX: Float, textY: Float, force: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (!force && (inFlight || now - lastSend < 60)) return
        lastSend = now; inFlight = true
        val x = fx(rawX); val y = fy(textY)
        evalJs("(function(){ try { return __lbMon.extend($x, $y); } catch(e){ return 'ERR '+e.message; } })()") { inFlight = false }
    }

    companion object {
        /** Cầu nối luôn trả "OK: <giá trị>" hoặc "LOI: <lỗi>" (content.js). Trả null nếu lỗi/không có. */
        fun unwrapBridge(raw: String?): String? {
            if (raw == null) return null
            if (raw.startsWith("LOI")) return null
            if (raw == "OK") return ""
            if (raw.startsWith("OK: ")) return raw.substring(4)
            return raw
        }
    }
}
