package com.colablive.keeper.features.ebookleech.remote

import android.content.Context
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpoint
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpointRepository
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.model.LeechJobRepository
import com.colablive.keeper.features.ebookleech.remote.GitHubApiClient.ApiResult
import org.json.JSONObject

/**
 * LeechDeskHub — lớp dữ liệu để addon (1) THEO DÕI các máy LeechDesk (app cào chạy trên PC/VPS) và (2) NHẬN job do LeechDesk giao.
 *
 * Dùng LẠI đúng repo GitHub + token mà "Chạy từ xa" đã cấu hình (GitHubRemoteConfig + SecureTokenStore) và chỉ gọi các hàm GitHubApiClient có sẵn
 * (listDirectory / getFileContent / getFileBytes) → không thêm phụ thuộc nào. Bản 7.103: đọc file lớn / ETag / thư mục > 1000 mục do GitHubApiClient lo.
 *
 * Giao thức (khớp LeechDesk 1.3, xem TAI_LIEU_KY_THUAT.md mục "LeechDesk"):
 *  - `leechdesk-status/<instanceId>.json`: {id, name, kind:"leechdesk", version, ts(ms), jobs:[{id,name,status,done,total}]}
 *  - `remote-jobs/<jobId>.json` + `-checkpoint.json` + `-archive.json` + `-images/`: giống hệt thứ addon tự đẩy lên khi "Chạy từ xa".
 *
 * Bản 7.103 (mục 227): nạp vào bản dựng chính thức; thêm `version` của máy LeechDesk (cảnh báo bản cũ chưa biết "chạy lại / chỉ cào chương mới"), bỏ `-archive.json` khỏi hộp thư.
 * ⚠ Chưa chạy trên thiết bị; biên dịch cùng toàn dự án bằng kotlinc (xem PROJECT_STATUS mục 227).
 */
object LeechDeskHub {

    private const val STATUS_DIR = "leechdesk-status"
    private const val INBOX_DIR = "remote-jobs"
    private const val ONLINE_MS = 120_000L

    data class JobProgress(val id: String, val name: String, val status: String, val done: Int, val total: Int) {
        val percent: Int get() = if (total > 0) (100 * done / total) else 0
    }

    data class Instance(val id: String, val name: String, val ageMs: Long, val jobs: List<JobProgress>, val version: String = "") {
        val online: Boolean get() = ageMs < ONLINE_MS

        /** LeechDesk < 1.3 chưa hiểu "lần chạy mới" (-archive.json / runRequestedAt): vẫn chạy đúng nhưng cào lại toàn bộ, kết quả không có `runnerVersion`. */
        val needsUpdate: Boolean get() {
            val p = version.split('.')
            val major = p.getOrNull(0)?.toIntOrNull() ?: return version.isNotBlank()
            val minor = p.getOrNull(1)?.toIntOrNull() ?: 0
            return major < 1 || (major == 1 && minor < 3)
        }

        /** "vừa xong" / "5 phút trước" / "2 giờ trước" — tuổi của bản tin trạng thái gần nhất. */
        val ageText: String get() = when {
            ageMs < 60_000L -> "vừa xong"
            ageMs < 3_600_000L -> "${ageMs / 60_000L} phút trước"
            ageMs < 86_400_000L -> "${ageMs / 3_600_000L} giờ trước"
            else -> "${ageMs / 86_400_000L} ngày trước"
        }
    }

    data class InboxEntry(val jobId: String, val name: String, val alreadyLocal: Boolean)

    private class Creds(val owner: String, val repo: String, val branch: String, val token: String)

    private fun creds(context: Context, slotIndex: Int): ApiResult<Creds> {
        val cfg = GitHubRemoteConfig.load(context, slotIndex)
        if (cfg.owner.isBlank() || cfg.repo.isBlank()) return ApiResult.Err("Chưa cấu hình repo GitHub (Chạy từ xa)")
        val token = SecureTokenStore.load(context) ?: return ApiResult.Err("Chưa có token GitHub")
        return ApiResult.Ok(Creds(cfg.owner, cfg.repo, cfg.branch, token))
    }

    private fun text(c: Creds, path: String): String? =
        (GitHubApiClient.getFileContent(c.owner, c.repo, c.branch, c.token, path) as? ApiResult.Ok)?.value

    /** Danh sách các máy LeechDesk + tiến độ từng job đang chạy (đọc `leechdesk-status/`). Gọi từ luồng nền. Mỗi file trạng thái đọc bằng ETag: không đổi thì GitHub trả 304 (không tốn hạn mức). */
    fun fetchInstances(context: Context, slotIndex: Int): ApiResult<List<Instance>> {
        val c = when (val r = creds(context, slotIndex)) {
            is ApiResult.Ok -> r.value
            is ApiResult.Err -> return r
        }
        val names = when (val r = GitHubApiClient.listDirectory(c.owner, c.repo, c.branch, c.token, STATUS_DIR)) {
            is ApiResult.Ok -> r.value
            is ApiResult.Err -> return r
        }
        val now = System.currentTimeMillis()
        val out = mutableListOf<Instance>()
        for (n in names.filter { it.endsWith(".json") }) {
            val raw = text(c, "$STATUS_DIR/$n") ?: continue
            try {
                val j = JSONObject(raw)
                val arr = j.optJSONArray("jobs")
                val jobs = (0 until (arr?.length() ?: 0)).map { i ->
                    val o = arr!!.getJSONObject(i)
                    JobProgress(o.optString("id"), o.optString("name"), o.optString("status"), o.optInt("done"), o.optInt("total"))
                }
                out += Instance(j.optString("id", n.removeSuffix(".json")), j.optString("name", n), now - j.optLong("ts", 0L), jobs, j.optString("version", ""))
            } catch (e: Exception) {
                // file hỏng/đang ghi dở → bỏ qua, lần poll sau đọc lại
            }
        }
        return ApiResult.Ok(out.sortedByDescending { it.online })
    }

    /** Job LeechDesk đã "Giao cho addon" (hoặc mọi spec trong remote-jobs/). `alreadyLocal` = addon đã có job cùng id. */
    fun listInbox(context: Context, slotIndex: Int): ApiResult<List<InboxEntry>> {
        val c = when (val r = creds(context, slotIndex)) {
            is ApiResult.Ok -> r.value
            is ApiResult.Err -> return r
        }
        val names = when (val r = GitHubApiClient.listDirectory(c.owner, c.repo, c.branch, c.token, INBOX_DIR)) {
            is ApiResult.Ok -> r.value
            is ApiResult.Err -> return r
        }
        val suffixes = listOf("-checkpoint.json", "-heartbeat.json", "-cmd.json", "-storage-state.json", "-archive.json")
        val out = mutableListOf<InboxEntry>()
        for (n in names.filter { it.endsWith(".json") && suffixes.none { s -> it.endsWith(s) } }) {
            val id = n.removeSuffix(".json")
            val name = try { JSONObject(text(c, "$INBOX_DIR/$n") ?: continue).optString("name", id) } catch (e: Exception) { id }
            out += InboxEntry(id, name, LeechJobRepository.getJob(context, slotIndex, id) != null)
        }
        return ApiResult.Ok(out)
    }

    /**
     * Nhận 1 job từ repo về addon: thêm job (nếu chưa có), tải ảnh, nạp checkpoint → bấm "Chạy" là cào TIẾP từ chương dở.
     * Checkpoint cục bộ đang NHIỀU chương hơn bản trên repo sẽ được GIỮ (không ghi đè tiến độ mới hơn).
     */
    fun importFromInbox(context: Context, slotIndex: Int, jobId: String): ApiResult<LeechJob> {
        val c = when (val r = creds(context, slotIndex)) {
            is ApiResult.Ok -> r.value
            is ApiResult.Err -> return r
        }
        val spec = text(c, "$INBOX_DIR/$jobId.json") ?: return ApiResult.Err("Không đọc được job-spec trên repo")
        val job = try { LeechJob.fromJson(JSONObject(spec)) } catch (e: Exception) { return ApiResult.Err("Job-spec hỏng: ${e.message}") }
        if (LeechJobRepository.getJob(context, slotIndex, jobId) == null) LeechJobRepository.addJob(context, slotIndex, job)

        val cpRaw = text(c, "$INBOX_DIR/$jobId-checkpoint.json")
        if (cpRaw != null) {
            val imgs = GitHubApiClient.listDirectory(c.owner, c.repo, c.branch, c.token, "$INBOX_DIR/$jobId-images")
            if (imgs is ApiResult.Ok) {
                for (name in imgs.value) {
                    if (CrawlCheckpointRepository.loadImageBytes(context, slotIndex, jobId, name) != null) continue
                    val b = GitHubApiClient.getFileBytes(c.owner, c.repo, c.branch, c.token, "$INBOX_DIR/$jobId-images/$name")
                    if (b is ApiResult.Ok) CrawlCheckpointRepository.saveImageBytesIfMissing(context, slotIndex, jobId, name, b.value)
                }
            }
            val remote = try {
                CrawlCheckpoint.fromJson(JSONObject(cpRaw)) { f -> CrawlCheckpointRepository.loadImageBytes(context, slotIndex, jobId, f) }
            } catch (e: Exception) {
                return ApiResult.Err("Checkpoint trên repo hỏng: ${e.message}")
            }
            val local = CrawlCheckpointRepository.load(context, slotIndex, jobId)
            if (local == null || local.chaptersSoFar.size <= remote.chaptersSoFar.size) {
                CrawlCheckpointRepository.save(context, slotIndex, remote)
            }
        }
        return ApiResult.Ok(LeechJobRepository.getJob(context, slotIndex, jobId) ?: job)
    }
}
