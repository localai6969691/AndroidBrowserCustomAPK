package com.colablive.keeper.core

/**
 * Bản 7.116 — phép tính vị trí cuộn của dải tab tròn (HorizontalScrollView) để đưa tab đang xem vào tầm nhìn.
 *
 * Tách thành hàm THUẦN (chỉ nhận số, không đụng View/Android) để kiểm thử được bằng JVM thường — không cần máy/giả lập.
 * `MainActivity.scrollTabBarToActiveTab` lo phần lấy số đo thật từ View rồi gọi hàm này.
 */
object TabBarScroll {
    /**
     * @param currentScrollX  `scrollX` hiện tại của dải.
     * @param viewportWidth   bề rộng vùng nhìn thấy của dải (đã trừ padding của HorizontalScrollView).
     * @param contentWidth    bề rộng TOÀN BỘ nội dung (tabContainer, đã gồm padding của nó).
     * @param chipLeft        toạ độ trái của chip đích TRONG nội dung (đã cộng dồn qua khung nhóm nếu chip nằm trong nhóm).
     * @param chipWidth       bề rộng chip đích.
     * @param visibleMarginPx chip phải cách mép dải ít nhất bằng này mới coi là "nằm trọn trong tầm nhìn".
     * @param centerAlways    true = luôn đặt chip giữa dải (nút "◎"); false = chip đã nằm trọn trong tầm nhìn thì giữ nguyên.
     * @return `scrollX` mới, luôn nằm trong [0, contentWidth - viewportWidth] (HorizontalScrollView cũng kẹp như vậy).
     */
    fun computeScrollX(
        currentScrollX: Int,
        viewportWidth: Int,
        contentWidth: Int,
        chipLeft: Int,
        chipWidth: Int,
        visibleMarginPx: Int,
        centerAlways: Boolean
    ): Int {
        val maxX = (contentWidth - viewportWidth).coerceAtLeast(0)
        val cur = currentScrollX.coerceIn(0, maxX)
        if (!centerAlways) {
            val chipRight = chipLeft + chipWidth
            val fullyVisible = chipLeft >= cur + visibleMarginPx && chipRight <= cur + viewportWidth - visibleMarginPx
            if (fullyVisible) return cur
        }
        val centered = chipLeft + chipWidth / 2 - viewportWidth / 2
        return centered.coerceIn(0, maxX)
    }
}
