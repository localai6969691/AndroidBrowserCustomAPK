package com.colablive.keeper.features.ebookleech.engine

import android.content.Context
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.proxy.ProxyHealthChecker
import com.colablive.keeper.core.proxy.ProxyScraper
import org.json.JSONArray
import org.json.JSONObject

/**
 * ProxyPoolManager — "xoay nhiều proxy" cho EbookLeech.
 *
 * ⚠️ GIỚI HẠN KIẾN TRÚC PHẢI NÓI THẲNG TRƯỚC (đọc trước khi dùng): proxy
 * của GeckoView đăng ký DUY NHẤT 1 LẦN lúc `GeckoRuntime` khởi tạo — lúc
 * tiến trình của khe bắt đầu chạy (xem `GeckoRuntimeProvider.createRuntime()`
 * trong `:core`). KHÔNG có API để đổi proxy cho 1 `GeckoRuntime` ĐANG
 * CHẠY — ghi `proxy_host`/`proxy_port` mới vào `AppPrefs` trong lúc tiến
 * trình khe đang sống KHÔNG có tác dụng NGAY, chỉ có hiệu lực sau khi khe
 * được ĐÓNG RỒI MỞ LẠI (nút "🌐 Tự tìm proxy mới cho khe này" có sẵn từ
 * trước cũng chịu đúng giới hạn này).
 *
 * → "Xoay nhiều proxy TRONG 1 JOB" theo đúng nghĩa đen (đổi proxy giữa
 * chừng khi job đang cào, đổi theo từng chương/từng request) **LÀ KHÔNG
 * THỂ** với kiến trúc hiện tại — không phải chưa làm, mà KHÔNG LÀM ĐƯỢC
 * nếu không sửa sâu vào `GeckoRuntimeProvider`/hạ tầng proxy WebExtension
 * của `:core` (ngoài phạm vi 1 addon build riêng — cần vá `:core` nặng,
 * chưa kiểm chứng được vì không có môi trường build thật để thử).
 *
 * CÁI THẬT SỰ LÀM ĐƯỢC (và là thứ implement ở đây): xoay proxy GIỮA CÁC
 * LẦN JOB KHỞI ĐỘNG MỚI (mỗi khi `EbookLeechCrawler.start()` chạy cho 1
 * job MỚI — KHÔNG áp dụng khi resume job đang cào dở) — chọn proxy TIẾP
 * THEO trong danh sách dự phòng (round-robin), ghi vào đúng key mà
 * `GeckoRuntimeProvider` đọc. Có tác dụng THẬT nếu khe được khởi động lại
 * giữa 2 lần job chạy (bình thường xảy ra: Android hay kill tiến trình
 * nền, lịch INTERVAL/DAILY cách xa nhau, người dùng tự tắt mở app...) —
 * giúp CÁC LẦN CHẠY KHÁC NHAU dùng IP khác nhau, giảm rủi ro 1 IP tĩnh bị
 * site chặn vĩnh viễn. KHÔNG giúp gì cho 1 job đang chạy liên tục, không
 * gián đoạn từ đầu tới cuối.
 */
object ProxyPoolManager {
    private const val KEY_POOL = "proxy_pool_json"
    private const val KEY_INDEX = "proxy_pool_index"
    private const val FEATURE_ID = "ebook_leech"

    data class PoolEntry(val host: String, val port: Int, val type: String, val latencyMs: Long)

    fun loadPool(context: Context, slotIndex: Int): List<PoolEntry> {
        val raw = AppPrefs.getString(context, slotIndex, FEATURE_ID, KEY_POOL, "")
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                PoolEntry(o.getString("host"), o.getInt("port"), o.getString("type"), o.optLong("latencyMs", 0L))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun savePool(context: Context, slotIndex: Int, pool: List<PoolEntry>) {
        val arr = JSONArray()
        pool.forEach { e ->
            arr.put(JSONObject().apply {
                put("host", e.host); put("port", e.port); put("type", e.type); put("latencyMs", e.latencyMs)
            })
        }
        AppPrefs.setString(context, slotIndex, FEATURE_ID, KEY_POOL, arr.toString())
        AppPrefs.setString(context, slotIndex, FEATURE_ID, KEY_INDEX, "0")
    }

    /**
     * Dò + kiểm tra, giữ lại tối đa `size` proxy NHANH NHẤT còn sống —
     * BLOCKING (gọi trong background thread, giống `autoFindProxyForSlot()`
     * đã có). Ghép từ đúng API PUBLIC sẵn có của `:core`
     * (`ProxyHealthChecker.findFastestAlive()` chỉ trả 1 kết quả/lần gọi,
     * không có sẵn "top N") — gọi LẶP LẠI trên danh sách ứng viên TRỪ DẦN
     * proxy đã chọn, thay vì sửa `:core` chỉ để thêm 1 hàm. Hơi tốn thời
     * gian hơn 1 lần gọi trực tiếp — chấp nhận được vì đây là thao tác
     * người dùng CHỦ ĐỘNG bấm, không chạy nền liên tục.
     */
    fun buildPool(context: Context, slotIndex: Int, size: Int = 5): List<PoolEntry> {
        val remaining = ProxyScraper.fetchCandidates().toMutableList()
        val picked = mutableListOf<PoolEntry>()
        while (picked.size < size && remaining.isNotEmpty()) {
            val best = ProxyHealthChecker.findFastestAlive(remaining) ?: break
            picked.add(PoolEntry(best.candidate.host, best.candidate.port, best.candidate.type, best.latencyMs))
            remaining.removeAll { it.host == best.candidate.host && it.port == best.candidate.port }
        }
        savePool(context, slotIndex, picked)
        return picked
    }

    fun clearPool(context: Context, slotIndex: Int) = savePool(context, slotIndex, emptyList())

    /**
     * Gọi từ `EbookLeechCrawler.start()` (KHÔNG gọi từ `resumeFromCheckpoint()`
     * — đó là job ĐANG CHẠY DỞ, không phải job MỚI khởi động) — chọn proxy
     * TIẾP THEO trong pool (round-robin), ghi vào đúng key `proxy_host`/
     * `proxy_port`/`proxy_type` mà `GeckoRuntimeProvider` đọc. Không làm
     * gì nếu pool rỗng (tính năng opt-in — chưa từng bấm "tìm nhiều proxy"
     * thì không đụng gì tới cấu hình proxy hiện có của khe).
     */
    fun rotateToNext(context: Context, slotIndex: Int) {
        val pool = loadPool(context, slotIndex)
        if (pool.isEmpty()) return
        val idx = AppPrefs.getString(context, slotIndex, FEATURE_ID, KEY_INDEX, "0").toIntOrNull() ?: 0
        val next = pool[idx % pool.size]
        AppPrefs.setString(context, slotIndex, "proxy_host", next.host)
        AppPrefs.setString(context, slotIndex, "proxy_port", next.port.toString())
        AppPrefs.setInt(context, slotIndex, "proxy_type", if (next.type == "socks") 2 else 1)
        AppPrefs.setString(context, slotIndex, FEATURE_ID, KEY_INDEX, ((idx + 1) % pool.size).toString())
    }
}
