package com.colablive.keeper.features.ebookleech.remote

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpoint
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpointRepository
import com.colablive.keeper.features.ebookleech.model.LeechJob
import org.json.JSONObject

/**
 * RemoteCrawlRunner — thay thế `EbookLeechCrawler` khi `job.remoteBackend
 * == "GITHUB"`. KHÔNG dùng tab GeckoView — đẩy job-spec lên repo GitHub,
 * kích hoạt workflow Actions chạy Python (`remote_runner/crawler.py`,
 * gửi kèm addon — xem thư mục đó), rồi ĐỊNH KỲ tải checkpoint mà script
 * Python commit ngược lại repo, merge vào `CrawlCheckpointRepository` cục
 * bộ — TÁI SỬ DỤNG NGUYÊN VẸN checkpoint/resume đã có cho luồng cào tại
 * máy, không phát minh cơ chế lưu trữ riêng.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * DÙNG ĐỂ ĐÁP ỨNG YÊU CẦU "server sập không mất dữ liệu": script Python
 * commit checkpoint lên GIT (không phải chỉ giữ trong RAM của runner) sau
 * MỖI VÀI CHƯƠNG — nếu runner Actions bị timeout/kill giữa chừng, bản
 * checkpoint cuối cùng đã commit vẫn nằm trên GitHub, poll tiếp vẫn đọc
 * được. Nếu muốn cào tiếp: bấm "Chạy lại" — Python script tự đọc lại
 * đúng checkpoint cũ (nếu có) khi mới khởi động, KHÔNG cào lại từ đầu
 * (giống hệt logic resume cục bộ).
 *
 * GIỚI HẠN THẬT (khác cào tại máy, PHẢI biết trước khi dùng):
 * - KHÔNG dừng chờ giải Cloudflare/captcha thủ công được — Python chạy
 *   trên máy chủ GitHub, không có màn hình cho người dùng giải. Gặp chặn
 *   → script tự ghi chương đó là lỗi rồi cào tiếp, KHÔNG dừng cả job.
 * - KHÔNG hỗ trợ `useLoginSession` (không có phiên đăng nhập thật của
 *   trình duyệt để mượn) — job cần đăng nhập PHẢI cào tại máy.
 * - KHÔNG tải ảnh offline (`downloadImages` bị bỏ qua) — ảnh cào lại sau
 *   bằng cách chạy job đó tại máy nếu cần.
 * - Chỉ cào được site TRẢ VỀ HTML/JSON THẬT SỰ TỪ SERVER (không cần chạy
 *   JavaScript mới có nội dung) — site kiểu SPA cần JS render nội dung sẽ
 *   ra trang RỖNG khi Python tải bằng `requests` (không có engine JS).
 * ═══════════════════════════════════════════════════════════════════════
 */
class RemoteCrawlRunner(
    private val context: Context,
    private val slotIndex: Int,
    private val job: LeechJob,
    private val onProgress: (crawled: Int, total: Int, message: String) -> Unit,
    private val onDone: (outputPath: String) -> Unit,
    private val onError: (String) -> Unit,
    // ĐÃ THÊM — remote không có tab thật để người dùng xem/giải trực tiếp
    // như local (`EbookLeechCrawler.onNeedsManualAction`) — thay vào đó
    // Python chụp màn hình trang chặn, commit lên repo, app tải về đưa
    // qua callback này để hiển thị (đường dẫn file cục bộ đã tải, hoặc
    // rỗng nếu chụp màn hình thất bại — vẫn hiện được lý do bằng chữ).
    private val onNeedsManualAction: (screenshotLocalPath: String, reason: String, blockedUrl: String) -> Unit,
    /**
     * ĐÃ THÊM — hỗ trợ Colab: "GITHUB" (Actions tự động, có API dispatch +
     * tra cứu trạng thái run thật) hoặc "COLAB" (KHÔNG có API trigger nào
     * — Google Colab không cho gọi từ ngoài. Colab dùng LẠI NGUYÊN VẸN
     * hàng đợi GitHub này làm nơi trao đổi dữ liệu (cùng repo, cùng
     * `crawler.py`, cùng checkpoint) — chỉ khác Ở CHỖ CHẠY: người dùng tự
     * mở notebook `.ipynb` trong repo trên Colab, bấm "Run all" thay vì
     * app tự dispatch. App chỉ đẩy job-spec lên rồi CHỜ checkpoint xuất
     * hiện/cập nhật — không có "trạng thái lần chạy" nào để tra cứu như
     * Actions, chỉ biết job "còn sống" qua checkpoint còn được cập nhật
     * hay không (xem `pollOnce()` nhánh COLAB).
     */
    private val backend: String = "GITHUB",
    /** CHỈ dùng khi `backend == "COLAB"` — báo cho UI biết link Colab để
     * mở (kèm job_id đã đẩy xong lên GitHub, sẵn sàng để chạy). */
    private val onColabReady: (colabUrl: String) -> Unit = {},
    // ĐÃ THÊM — báo kết quả 1 lệnh interactive (screenshot/click/type/...)
    // vừa xử lý xong, KHÁC onNeedsManualAction (đó là báo lúc MỚI bị chặn,
    // còn cái này là báo lúc đã có ảnh MỚI sau khi người dùng chủ động
    // click/gõ gì đó). Tách callback riêng — theo ĐÚNG pattern
    // onNeedsManualAction/onColabReady đã có — để RemoteCrawlRunner KHÔNG
    // gọi thẳng LeechJobRepository (kiến trúc cố ý tách biệt, việc ghi job
    // luôn nằm ở nơi khởi tạo runner — EbookLeechScheduler.kt).
    private val onInteractiveResult: (screenshotLocalPath: String, message: String) -> Unit = { _, _ -> },
) {
    companion object {
        const val WORKFLOW_FILE = "ebookleech-remote-crawl.yml"
        const val COLAB_NOTEBOOK_PATH = "colab-live-browser/ebookleech/remote_runner/colab_notebook.ipynb"
        private const val POLL_INTERVAL_MS = 20_000L
        // Colab không có API trạng thái như Actions — ngưỡng này giờ dựa
        // trên HEARTBEAT riêng (ghi mỗi 45s, KHÔNG phụ thuộc tốc độ cào —
        // xem HeartbeatThread trong crawler.py), nên rút ngắn được nhiều so
        // với bản cũ dựa vào checkpoint (10 phút, dễ báo nhầm lúc cào chậm).
        private const val COLAB_STALE_WARNING_MS = 3 * 60 * 1000L
        // Khoảng thời gian poll khi đang chờ người dùng thực hiện hành động
        // tương tác từ xa (chạm/gõ) — ngắn hơn POLL_INTERVAL_MS thường vì
        // người dùng đang chờ phản hồi trực tiếp (đã bấm nút, mong thấy kết
        // quả sớm). Không cần ngắn hơn 5s vì git push→poll có độ trễ thật.
        private const val INTERACTIVE_POLL_INTERVAL_MS = 5_000L
        // ĐÃ THÊM — giới hạn số lần poll nhanh liên tiếp khi chờ kết quả 1
        // lệnh interactive trước khi TỰ DỪNG (phòng hờ Python crash/git push
        // lỗi liên tục khiến checkpoint không bao giờ cập nhật) — 36 lần *
        // 5s ≈ 3 phút, đủ dư dả cho 1 lệnh click/type bình thường (thường
        // xong trong vài giây) nhưng không để vòng lặp treo vô thời hạn.
        private const val MAX_INTERACTIVE_POLL_RETRIES = 36
    }

    private val handler = Handler(Looper.getMainLooper())
    private var cancelled = false
    private var runId: Long? = null

    fun start(resumeExisting: Boolean = false) {
        val cfg = GitHubRemoteConfig.load(context, slotIndex)
        if (!GitHubRemoteConfig.isConfigured(context, slotIndex)) {
            onError("Chưa cấu hình GitHub (repo/token) — vào \"⚙️ Cấu hình GitHub\" trong Cài đặt EbookLeech trước")
            return
        }
        val token = SecureTokenStore.load(context) ?: run {
            onError("Không đọc được token đã lưu — cấu hình lại GitHub")
            return
        }

        // resumeExisting = true khi app vừa khởi động lại giữa lúc đang
        // chờ 1 lần chạy Actions (EbookLeechScheduler.resumeInterruptedJobs())
        // — KHÔNG dispatch lần chạy MỚI (runId trong RAM đã mất do restart,
        // nhưng lần chạy CŨ trên GitHub vẫn đang chạy tiếp bên đó, dispatch
        // thêm 1 lần sẽ chạy TRÙNG, tốn phút Actions vô ích + 2 runner cùng
        // ghi checkpoint dễ rối) — chỉ tra cứu lại đúng lần chạy gần nhất
        // rồi poll tiếp.
        if (resumeExisting) {
            if (backend == "COLAB") {
                // Colab không có "lần chạy" nào để tra cứu — chỉ có thể
                // tiếp tục POLL checkpoint, hy vọng notebook người dùng mở
                // vẫn đang chạy (không có cách nào biết chắc từ phía app).
                onProgress(0, 0, "📓 Đang nối lại theo dõi checkpoint từ Colab…")
                schedulePoll()
                return
            }
            onProgress(0, 0, "☁️ Đang tìm lại lần chạy GitHub Actions đang chờ…")
            Thread {
                when (val runResult = GitHubApiClient.findLatestRun(cfg.owner, cfg.repo, token, WORKFLOW_FILE)) {
                    is GitHubApiClient.ApiResult.Ok -> {
                        runId = runResult.value.id
                        handler.post { onProgress(0, 0, "☁️ Đã nối lại — tiếp tục theo dõi tiến độ") }
                        schedulePoll()
                    }
                    is GitHubApiClient.ApiResult.Err -> postError("Không tìm lại được lần chạy cũ: ${runResult.message} — có thể job đã chạy xong hoặc chưa từng chạy, thử \"Chạy lại\" thủ công")
                }
            }.start()
            return
        }

        onProgress(0, 0, "☁️ Đang đẩy cấu hình job lên GitHub…")
        Thread {
            // Job-spec = toàn bộ config job (selector, regex rule, AJAX...)
            // — Python script đọc đúng field này để cào giống hệt logic
            // local. KHÔNG gửi qua workflow_dispatch inputs (giới hạn kích
            // thước) — ghi thẳng vào repo qua Contents API.
            val specPath = "remote-jobs/${job.id}.json"
            val putResult = GitHubApiClient.putFile(
                cfg.owner, cfg.repo, cfg.branch, token, specPath,
                job.toJson().toString(2), "EbookLeech: cấu hình job ${job.name} (${job.id})",
            )
            if (putResult is GitHubApiClient.ApiResult.Err) {
                postError("Đẩy job-spec lỗi: ${putResult.message}")
                return@Thread
            }

            // ĐÃ THÊM — sửa "khoảng hở nhỏ" đã biết: nếu app bị kill NGAY
            // sau lúc dispatch (trước khi kịp poll lần đầu), trước đây
            // `resumeInterruptedJobs()` không nhận diện được job này (chưa
            // có checkpoint cục bộ nào để `CrawlCheckpointRepository.exists()`
            // thấy) → job vẫn chạy bình thường ở remote nhưng app không tự
            // nối lại theo dõi khi mở lại. Giờ: tạo NGAY 1 checkpoint RỖNG
            // cục bộ (chưa có chương nào, chỉ đánh dấu "đang thu thập link")
            // trước khi dispatch — CHỈ khi job này CHƯA có checkpoint nào cả
            // (job mới hoàn toàn với remote; job đã có tiến độ từ trước thì
            // giữ nguyên, không ghi đè).
            if (CrawlCheckpointRepository.load(context, slotIndex, job.id) == null) {
                CrawlCheckpointRepository.save(context, slotIndex, CrawlCheckpoint(
                    jobId = job.id, phase = CrawlCheckpoint.Phase.COLLECTING_LINKS,
                    listPageEntries = emptyList(), listPageEntryIndex = 0,
                    chapterLinks = emptyList(), chapterProgressIndex = 0,
                    chaptersSoFar = emptyList(), blockedChapterCount = 0, pausedAtIndex = -1,
                ))
            }

            // ĐÃ THÊM — đóng nốt chiều đồng bộ CÒN THIẾU: nếu job này ĐÃ
            // từng cào TẠI MÁY trước đó (đổi từ local sang remote, hoặc
            // job cũ có checkpoint dở) — đẩy NGƯỢC checkpoint + ảnh cục bộ
            // lên GitHub TRƯỚC khi dispatch, để Python thấy đã có sẵn và
            // CÀO TIẾP đúng chỗ thay vì cào lại từ đầu (Python tự đọc
            // "remote-jobs/<id>-checkpoint.json" nếu đã tồn tại — xem đầu
            // crawler.py). Không có checkpoint cục bộ (job hoàn toàn mới)
            // thì bỏ qua bước này — dispatch bình thường, Python cào mới.
            val localCheckpoint = CrawlCheckpointRepository.load(context, slotIndex, job.id)
            if (localCheckpoint != null && localCheckpoint.chaptersSoFar.isNotEmpty()) {
                handler.post { onProgress(localCheckpoint.chaptersSoFar.size, localCheckpoint.chapterLinks.size, "☁️ Đang đẩy ${localCheckpoint.chaptersSoFar.size} chương đã cào tại máy lên GitHub…") }
                // Ảnh trước (checkpoint trỏ tới tên file ảnh — phải có ảnh
                // TRƯỚC khi Python đọc checkpoint, không thì rewrite src
                // trong HTML trỏ tới ảnh không tồn tại).
                CrawlCheckpointRepository.listLocalImageFiles(context, slotIndex, job.id).forEach { imgFile ->
                    GitHubApiClient.putFileBytes(
                        cfg.owner, cfg.repo, cfg.branch, token,
                        "remote-jobs/${job.id}-images/${imgFile.name}", imgFile.readBytes(),
                        "EbookLeech: đồng bộ ảnh cục bộ ${imgFile.name} (${job.id})",
                    )
                    // 1 ảnh lỗi upload không chặn cả quá trình — bỏ qua,
                    // tiếp tục ảnh khác (giống mọi chỗ khác trong hệ thống
                    // này coi 1 ảnh lỗi là chấp nhận được, không phải lỗi
                    // nghiêm trọng của cả job).
                }
                val checkpointPutResult = GitHubApiClient.putFile(
                    cfg.owner, cfg.repo, cfg.branch, token, "remote-jobs/${job.id}-checkpoint.json",
                    localCheckpoint.toJson().toString(2), "EbookLeech: đồng bộ checkpoint cục bộ (${localCheckpoint.chaptersSoFar.size} chương) lên GitHub trước khi cào tiếp từ xa",
                )
                if (checkpointPutResult is GitHubApiClient.ApiResult.Err) {
                    // Đẩy checkpoint lỗi — KHÔNG dispatch (Python sẽ cào lại
                    // từ đầu, trùng lặp công đã cào) — báo lỗi rõ, để người
                    // dùng thử lại thay vì âm thầm mất tiến độ.
                    postError("Đẩy checkpoint cũ lên GitHub lỗi: ${checkpointPutResult.message} — CHƯA dispatch để tránh cào trùng từ đầu, thử lại")
                    return@Thread
                }
            }

            // ĐÃ THÊM — nhánh Colab: KHÔNG có API dispatch, job-spec (+
            // checkpoint cũ nếu có) đã đẩy lên xong ở trên là ĐỦ — báo cho
            // UI biết link Colab để người dùng TỰ mở + bấm "Run all", rồi
            // bắt đầu poll checkpoint luôn (không có gì để "dispatch" hay
            // tra cứu trạng thái run — Colab không có API cho việc đó).
            if (backend == "COLAB") {
                val colabUrl = "https://colab.research.google.com/github/${cfg.owner}/${cfg.repo}/blob/${cfg.branch}/$COLAB_NOTEBOOK_PATH"
                handler.post {
                    onProgress(0, 0, "📓 Đã đẩy job lên GitHub — mở Colab và bấm \"Run all\" để bắt đầu")
                    onColabReady(colabUrl)
                }
                schedulePoll()
                return@Thread
            }

            val dispatchResult = GitHubApiClient.dispatchWorkflow(
                cfg.owner, cfg.repo, cfg.branch, token, WORKFLOW_FILE,
                mapOf("job_id" to job.id),
            )
            if (dispatchResult is GitHubApiClient.ApiResult.Err) {
                postError("Kích hoạt workflow lỗi: ${dispatchResult.message}")
                return@Thread
            }

            // workflow_dispatch không trả run id — chờ vài giây rồi tra
            // cứu lần chạy mới nhất (xem GitHubApiClient.findLatestRun()).
            Thread.sleep(5_000)
            when (val runResult = GitHubApiClient.findLatestRun(cfg.owner, cfg.repo, token, WORKFLOW_FILE)) {
                is GitHubApiClient.ApiResult.Ok -> {
                    runId = runResult.value.id
                    handler.post { onProgress(0, 0, "☁️ Đã kích hoạt trên GitHub Actions — đang chờ chạy…") }
                    schedulePoll()
                }
                is GitHubApiClient.ApiResult.Err -> postError("Không xác định được lần chạy: ${runResult.message}")
            }
        }.start()
    }

    private fun schedulePoll() {
        if (cancelled) return
        handler.postDelayed({ pollOnce() }, POLL_INTERVAL_MS)
    }

    /** ĐÃ THÊM — UI gọi khi người dùng bấm "🔄 Đồng bộ ngay": bỏ qua lịch
     * chờ POLL_INTERVAL_MS, tải checkpoint/ảnh mới nhất NGAY — hữu ích
     * trước khi bấm "💾 Sao lưu ngay" để chắc chắn bản sao lưu có dữ liệu
     * mới nhất, không phải đợi tới chu kỳ poll tiếp theo. An toàn gọi bất
     * cứ lúc nào job đang chạy — không tạo xung đột với vòng poll định kỳ
     * (chỉ ĐỌC dữ liệu, không có gì để race). */
    fun syncNow() {
        if (cancelled) return
        pollOnce()
    }

    /**
     * ĐÃ THÊM — gửi lệnh tương tác (click/type/screenshot) tới trình duyệt
     * đang chạy trên remote (GitHub Actions hoặc Colab) VIA GIT — không mở
     * tunnel nào cả (rủi ro bảo mật của tunnel đã giải quyết bằng cách dùng
     * lại chính kênh git+token đã xác thực).
     *
     * Cơ chế: app ghi file `remote-jobs/<id>-cmd.json` lên GitHub qua
     * Contents API (đã xác thực bằng PAT — chỉ người có token mới ghi
     * được). Python (`InteractiveCommandPoller` trong crawler.py) đang poll
     * file này trong vòng chờ NEEDS_ACTION — thấy file mới → thực thi lệnh
     * → chụp màn hình kết quả → ghi tên file ảnh + mốc thời gian vào
     * checkpoint (`lastInteractiveScreenshotFile`/`lastInteractiveAt`) → xoá
     * file lệnh → commit tất cả cùng lúc. App phát hiện "đã xong" qua
     * `lastInteractiveAt` mới hơn lần trước (xem pollOnce()) — KHÔNG dựa
     * vào việc file lệnh biến mất (đã sửa lỗi: trước đây dựa vào đó nhưng
     * đoạn code kiểm tra lại đặt sai vị trí, không bao giờ chạy tới lúc
     * đang paused).
     *
     * Các lệnh hỗ trợ (khớp với InteractiveCommandPoller trong crawler.py):
     *   "screenshot"                           — chụp màn hình hiện tại
     *   "click:<css_selector>"                 — click element
     *   "click_coord:<x>,<y>"                  — click toạ độ pixel
     *   "type:<text>"                           — gõ text vào element đang focus
     *   "press:<key>"                           — nhấn phím (Enter, Tab, Escape...)
     *   "scroll:<direction>"                    — cuộn trang (up/down/top/bottom)
     *   "wait:<ms>"                             — chờ ms milliseconds
     *   "eval:<js>"                             — thực thi JavaScript (nguy hiểm,
     *                                             chỉ dùng khi thực sự cần)
     *   "resume_crawl"                          — báo đã tự giải xong (bằng các
     *                                             lệnh trên hoặc thủ công), tiếp
     *                                             tục cào NGAY tại chương đang bị
     *                                             chặn, dùng lại session hiện có
     *                                             (xem handle_blocked_pause() —
     *                                             KHÔNG dispatch job mới).
     *
     * @param action lệnh dạng "type:verb:payload" — xem danh sách bên trên
     * @param onQueued gọi trên main thread sau khi ghi lệnh lên git thành công
     * @param onError gọi trên main thread nếu ghi lệnh thất bại
     */
    fun sendInteractiveAction(
        context: android.content.Context,
        action: String,
        onQueued: () -> Unit,
        onError: (String) -> Unit,
    ) {
        if (cancelled) { onError("Job đã bị huỷ"); return }
        val cfg = GitHubRemoteConfig.load(context, slotIndex)
        val token = SecureTokenStore.load(context) ?: run { handler.post { onError("Token bị mất — cấu hình lại GitHub") }; return }
        val cmdPath = "remote-jobs/${job.id}-cmd.json"
        Thread {
            val body = org.json.JSONObject().apply {
                put("action", action)
                put("sentAt", System.currentTimeMillis())
            }.toString(2)
            when (val result = GitHubApiClient.putFile(
                cfg.owner, cfg.repo, cfg.branch, token, cmdPath, body,
                "EbookLeech remote interactive: ${job.id} - $action",
            )) {
                is GitHubApiClient.ApiResult.Ok -> {
                    awaitingInteractiveResult = true
                    handler.post { onQueued() }
                    // Bắt đầu poll nhanh hơn để phát hiện kết quả sớm
                    scheduleInteractivePoll(retryCount = 0)
                }
                is GitHubApiClient.ApiResult.Err -> {
                    handler.post { onError("Gửi lệnh lên GitHub lỗi: ${result.message}") }
                }
            }
        }.start()
    }

    /** Poll nhanh (INTERACTIVE_POLL_INTERVAL_MS) khi đang chờ kết quả 1 lệnh
     * interactive — tự chuyển về poll thường khi awaitingInteractiveResult
     * đã false (Python đã ghi lastInteractiveAt mới hơn HOẶC pausedForManualReview
     * đã tắt — xem pollOnce()).
     * ĐÃ THÊM — giới hạn `MAX_INTERACTIVE_POLL_RETRIES` (phòng hờ, không nên
     * cần tới nếu Python hoạt động đúng): nếu quá nhiều lần vẫn chưa thấy kết
     * quả (vd Python crash giữa chừng, hoặc git push thất bại liên tục nên
     * checkpoint không bao giờ cập nhật), TỰ DỪNG poll nhanh thay vì lặp vô
     * thời hạn — tránh lặp lại đúng lỗi đã sửa (spam request/thông báo mãi
     * không dừng) nếu có tình huống nào đó ngoài dự tính. */
    private fun scheduleInteractivePoll(retryCount: Int) {
        if (cancelled) return
        if (retryCount >= MAX_INTERACTIVE_POLL_RETRIES) {
            awaitingInteractiveResult = false
            handler.post { onProgress(lastKnownChapterCount, 0, "⚠️ Không thấy phản hồi lệnh sau ${MAX_INTERACTIVE_POLL_RETRIES * INTERACTIVE_POLL_INTERVAL_MS / 1000}s — thử '📸 Chụp màn hình' lại để kiểm tra") }
            return
        }
        handler.postDelayed({
            if (awaitingInteractiveResult) {
                pollOnce()
                // pollOnce() tự set awaitingInteractiveResult = false khi thấy
                // kết quả mới — nếu vẫn còn true thì tiếp tục poll nhanh (tăng
                // retryCount lên 1 mỗi lần, tới ngưỡng thì tự dừng ở trên).
                if (awaitingInteractiveResult) scheduleInteractivePoll(retryCount = retryCount + 1)
                // Khi awaitingInteractiveResult = false thì vòng poll thường
                // (schedulePoll()) tiếp quản — không cần làm gì thêm
            }
        }, INTERACTIVE_POLL_INTERVAL_MS)
    }

    private fun pollOnce() {
        if (cancelled) return
        val cfg = GitHubRemoteConfig.load(context, slotIndex)
        val token = SecureTokenStore.load(context) ?: run { postError("Token bị mất giữa chừng — cấu hình lại GitHub"); return }
        // ĐÃ SỬA: Colab không bao giờ có runId (không có API dispatch để
        // lấy) — chỉ GitHub Actions mới bắt buộc có, dùng ở bước 2 bên dưới.
        val rid = if (backend == "GITHUB") (runId ?: return) else null

        Thread {
            // 0) ĐÃ THÊM — đồng bộ ẢNH MỚI trước (nếu job bật downloadImages):
            // liệt kê thư mục ảnh Python đã commit, tải về đúng file CHƯA
            // CÓ cục bộ (idempotent, giống persistImageBytes() cục bộ),
            // rồi mới parse checkpoint — để checkpoint parse xong có ĐỦ
            // bytes ảnh ngay, không phải chờ vòng poll sau.
            if (job.downloadImages) {
                val imagesDirPath = "remote-jobs/${job.id}-images"
                when (val listResult = GitHubApiClient.listDirectory(cfg.owner, cfg.repo, cfg.branch, token, imagesDirPath)) {
                    is GitHubApiClient.ApiResult.Ok -> {
                        listResult.value.forEach { fileName ->
                            if (CrawlCheckpointRepository.loadImageBytes(context, slotIndex, job.id, fileName) == null) {
                                val bytesResult = GitHubApiClient.getFileBytes(cfg.owner, cfg.repo, cfg.branch, token, "$imagesDirPath/$fileName")
                                if (bytesResult is GitHubApiClient.ApiResult.Ok) {
                                    CrawlCheckpointRepository.saveImageBytesIfMissing(context, slotIndex, job.id, fileName, bytesResult.value)
                                }
                            }
                        }
                    }
                    is GitHubApiClient.ApiResult.Err -> { /* chưa có ảnh nào / lỗi mạng — bỏ qua, thử lại lần poll sau */ }
                }
            }

            // 1) Tải checkpoint mới nhất Python đã commit (nếu có) — merge
            // vào checkpoint cục bộ NGAY (đây là phần đáp ứng "không mất
            // dữ liệu nếu server sập" — merge SỚM, không chờ tới lúc job
            // xong mới lấy 1 lần).
            val checkpointPath = "remote-jobs/${job.id}-checkpoint.json"
            when (val cpResult = GitHubApiClient.getFileContent(cfg.owner, cfg.repo, cfg.branch, token, checkpointPath)) {
                is GitHubApiClient.ApiResult.Ok -> {
                    try {
                        val rawJson = JSONObject(cpResult.value)
                        val remoteDone = rawJson.optBoolean("remoteDone", false)
                        val pausedForManualReview = rawJson.optBoolean("pausedForManualReview", false)
                        // ĐÃ SỬA: truyền imageLoader đọc từ đúng thư mục vừa
                        // đồng bộ ở bước 0 — trước đây dùng mặc định { null }
                        // nên ảnh LUÔN bị rớt hết khi parse checkpoint remote.
                        val checkpoint = CrawlCheckpoint.fromJson(rawJson) { localFileName ->
                            CrawlCheckpointRepository.loadImageBytes(context, slotIndex, job.id, localFileName)
                        }
                        CrawlCheckpointRepository.save(context, slotIndex, checkpoint)
                        // Số chương hiện tại — dùng hiển thị kèm cảnh báo
                        // "Colab có vẻ đã dừng" ở bước 2 (heartbeat riêng lo
                        // phần phát hiện còn sống hay không, xem bên dưới).
                        lastKnownChapterCount = checkpoint.chaptersSoFar.size
                        handler.post {
                            onProgress(
                                checkpoint.chaptersSoFar.size, checkpoint.chapterLinks.size.takeIf { it > 0 } ?: 0,
                                "☁️ Đồng bộ từ GitHub — đã cào ${checkpoint.chaptersSoFar.size} chương" +
                                    (if (checkpoint.blockedChapterCount > 0) " (${checkpoint.blockedChapterCount} lỗi/chặn)" else ""),
                            )
                        }
                        // ĐÃ SỬA LỖI — trước đây đoạn kiểm tra
                        // awaitingInteractiveResult nằm SAU nhánh
                        // pausedForManualReview bên dưới (return@Thread sớm)
                        // nên KHÔNG BAO GIỜ chạy tới trong lúc job đang tạm
                        // dừng (pausedForManualReview luôn = true suốt lúc
                        // đó) — hậu quả: scheduleInteractivePoll() tự gọi lại
                        // vô thời hạn (awaitingInteractiveResult không bao
                        // giờ reset), spam lại onNeedsManualAction (thông báo
                        // + backup) mỗi 5 giây; VÀ ảnh chụp màn hình của các
                        // lệnh interactive (click/type/screenshot...) không
                        // bao giờ hiện lên UI (chỉ đọc pausedScreenshotFile —
                        // field chỉ ghi 1 lần lúc mới chặn, không đổi nữa).
                        // Giờ đặt lên TRƯỚC + xử lý ĐỦ 2 trường hợp:
                        if (awaitingInteractiveResult) {
                            if (!pausedForManualReview) {
                                // Trường hợp lệnh "resume_crawl": Python đã xoá
                                // cờ pausedForManualReview (job tiếp tục cào) —
                                // coi như lệnh đã có kết quả, dừng vòng poll nhanh.
                                awaitingInteractiveResult = false
                                handler.post { onProgress(lastKnownChapterCount, 0, "✅ Đã tiếp tục cào — session cũ vẫn được giữ nguyên") }
                            } else {
                                // Vẫn đang paused — có thể là 1 lệnh interactive
                                // THƯỜNG (screenshot/click/type/...) vừa được
                                // Python xử lý xong (KHÔNG đổi pausedForManualReview,
                                // xem InteractiveCommandPoller._check_and_execute()
                                // trong crawler.py) — phát hiện qua mốc
                                // lastInteractiveAt MỚI HƠN lần trước ta đã thấy
                                // (so sánh > , không phải != — tránh xử lý lại
                                // đúng 1 kết quả nhiều lần).
                                val lastInteractiveAt = rawJson.optLong("lastInteractiveAt", 0L)
                                if (lastInteractiveAt > lastInteractiveResultSeenAt) {
                                    lastInteractiveResultSeenAt = lastInteractiveAt
                                    awaitingInteractiveResult = false
                                    val shotFile = rawJson.optString("lastInteractiveScreenshotFile", "")
                                    val interactiveErr = rawJson.optString("lastInteractiveError", "")
                                    var localShotPath = ""
                                    if (shotFile.isNotEmpty()) {
                                        val shotBytes = GitHubApiClient.getFileBytes(
                                            cfg.owner, cfg.repo, cfg.branch, token, "remote-jobs/${job.id}-images/$shotFile",
                                        )
                                        if (shotBytes is GitHubApiClient.ApiResult.Ok) {
                                            try {
                                                // ĐÃ THÊM — file riêng cho ảnh interactive
                                                // (khác ebookleech_remote_block_*.png của
                                                // ảnh chặn ban đầu) — GHI ĐÈ ĐÚNG 1 file mỗi
                                                // lần (chỉ ảnh MỚI NHẤT có ý nghĩa, không cần
                                                // giữ lịch sử từng ảnh cục bộ).
                                                val f = java.io.File(context.cacheDir, "ebookleech_remote_interactive_${job.id}.png")
                                                f.writeBytes(shotBytes.value)
                                                localShotPath = f.absolutePath
                                            } catch (e: Exception) { /* không tải/ghi được ảnh — vẫn báo lệnh xong bằng chữ */ }
                                        }
                                    }
                                    val resultMsg = if (interactiveErr.isNotEmpty()) "⚠️ Lệnh thực thi có lỗi: $interactiveErr" else "✅ Lệnh đã thực thi — xem ảnh kết quả"
                                    // ĐÃ SỬA — gọi callback onInteractiveResult (do
                                    // EbookLeechScheduler.kt cập nhật LeechJobRepository),
                                    // KHÔNG gọi thẳng LeechJobRepository từ đây (file này
                                    // không import LeechJobRepository — vi phạm kiến trúc
                                    // tách biệt cố ý của project, lỗi biên dịch nếu để vậy).
                                    handler.post {
                                        onInteractiveResult(localShotPath, resultMsg)
                                        onProgress(lastKnownChapterCount, 0, resultMsg)
                                    }
                                }
                                // Chưa có lastInteractiveAt mới hơn → Python vẫn
                                // chưa xử lý xong lệnh — KHÔNG làm gì thêm ở đây,
                                // scheduleInteractivePoll() sẽ tự gọi lại sau
                                // INTERACTIVE_POLL_INTERVAL_MS.
                            }
                        }

                        if (pausedForManualReview) {
                            // ĐÃ SỬA — job TỰ DỪNG bên Python (bị chặn dai
                            // dẳng). TRƯỚC ĐÂY đoạn này chạy VÔ ĐIỀU KIỆN mỗi
                            // lần poll → 2 hậu quả xấu khi kết hợp với
                            // scheduleInteractivePoll() (poll nhanh mỗi 5s lúc
                            // chờ 1 lệnh interactive thường xử lý xong): (a)
                            // spam lại thông báo + tự backup MỖI 5 GIÂY trong
                            // lúc chờ, (b) GHI ĐÈ pendingActionScreenshotPath
                            // về ảnh CHẶN BAN ĐẦU ngay sau khi nhánh phía trên
                            // vừa cập nhật đúng ảnh interactive mới — xoá mất
                            // kết quả vừa xong trong CÙNG 1 lần poll.
                            // Giờ chỉ thực sự "thông báo" (tải ảnh chặn +
                            // callback onNeedsManualAction) khi `savedAt` của
                            // checkpoint KHÁC lần thông báo trước — nghĩa là
                            // đây là 1 đợt TẠM DỪNG MỚI (savedAt chỉ đổi khi
                            // Python ghi checkpoint chặn mới hoặc checkpoint
                            // "đã resume" — cả 2 trường hợp đều đáng để xử lý
                            // lại; các lần đọc checkpoint TRÙNG savedAt (do
                            // InteractiveCommandPoller chỉ patch 3 field
                            // lastInteractive* mà không đụng savedAt) thì bỏ
                            // qua phần thông báo, chỉ return@Thread để dừng
                            // vòng poll thường như cũ.
                            val pausedSavedAt = rawJson.optLong("savedAt", 0L)
                            if (pausedSavedAt != lastNotifiedPausedSavedAt) {
                                lastNotifiedPausedSavedAt = pausedSavedAt
                                val reason = rawJson.optString("pausedReason", "Trang bị chặn — xem chi tiết trong log GitHub Actions")
                                val blockedUrl = rawJson.optString("pausedUrl", "")
                                val screenshotFile = rawJson.optString("pausedScreenshotFile", "")
                                var localScreenshotPath = ""
                                if (screenshotFile.isNotEmpty()) {
                                    val bytesResult = GitHubApiClient.getFileBytes(
                                        cfg.owner, cfg.repo, cfg.branch, token, "remote-jobs/${job.id}-images/$screenshotFile",
                                    )
                                    if (bytesResult is GitHubApiClient.ApiResult.Ok) {
                                        try {
                                            val f = java.io.File(context.cacheDir, "ebookleech_remote_block_${job.id}.png")
                                            f.writeBytes(bytesResult.value)
                                            localScreenshotPath = f.absolutePath
                                        } catch (e: Exception) { /* không tải được ảnh — vẫn báo lý do bằng chữ */ }
                                    }
                                }
                                handler.post { onNeedsManualAction(localScreenshotPath, reason, blockedUrl) }
                            }
                            return@Thread  // KHÔNG schedulePoll() — dừng hẳn poll thường, chờ resume() hoặc lệnh interactive
                        }
                        if (remoteDone) {
                            finishFromCheckpoint(checkpoint)
                            return@Thread
                        }
                    } catch (e: Exception) {
                        // Checkpoint đang được ghi dở (đọc trúng lúc Python
                        // đang commit) — bỏ qua lần poll này, thử lại lần sau,
                        // KHÔNG coi là lỗi job.
                    }
                }
                is GitHubApiClient.ApiResult.Err -> {
                    // 404 = Python chưa commit checkpoint lần nào (job vừa
                    // mới bắt đầu) — bình thường, không phải lỗi.
                }
            }

            // (ĐÃ XOÁ đoạn kiểm tra awaitingInteractiveResult cũ từng nằm ở
            // đây — SAI vị trí, nằm SAU nhánh pausedForManualReview nên
            // không bao giờ chạy tới lúc job đang tạm dừng. Logic ĐÚNG giờ
            // nằm TRƯỚC nhánh pausedForManualReview ở trên — xem đoạn "ĐÃ SỬA
            // LỖI" phía trên nhánh `if (pausedForManualReview)`.)

            // 2) Kiểm tra trạng thái lần chạy Actions — CHỈ áp dụng cho
            // GitHub Actions (có API tra cứu run thật). Colab KHÔNG có gì
            // tương đương — thay vào đó cảnh báo nếu checkpoint LÂU không
            // cập nhật (dấu hiệu notebook Colab đã bị đóng/ngắt phiên mà
            // app không có cách nào biết chắc chắn).
            if (rid != null) {
                when (val statusResult = GitHubApiClient.getRunStatus(cfg.owner, cfg.repo, token, rid)) {
                    is GitHubApiClient.ApiResult.Ok -> {
                        val info = statusResult.value
                        if (info.status == "completed") {
                            if (info.conclusion == "success") {
                                // Actions báo xong nhưng chưa thấy remoteDone ở
                                // bước 1 — đọc lại checkpoint 1 lần cuối rồi kết
                                // thúc với dữ liệu đang có (còn hơn treo mãi).
                                val finalCp = CrawlCheckpointRepository.load(context, slotIndex, job.id)
                                if (finalCp != null) finishFromCheckpoint(finalCp)
                                else postError("Actions báo hoàn tất nhưng không đọc được checkpoint cuối — kiểm tra log Actions")
                            } else {
                                postError("Lần chạy Actions kết thúc với lỗi (conclusion=${info.conclusion}) — xem log trên tab Actions của repo. Dữ liệu đã cào TỚI LÚC LỖI vẫn được giữ (đã đồng bộ checkpoint ở trên) — có thể \"Chạy lại\" để cào tiếp.")
                            }
                            return@Thread
                        }
                    }
                    is GitHubApiClient.ApiResult.Err -> { /* lỗi tra cứu trạng thái — bỏ qua lần poll này */ }
                }
            } else {
                // ĐÃ SỬA — backend == "COLAB": trước đây đoán qua checkpoint
                // (chỉ đổi mỗi 5 chương/120s, dễ báo NHẦM "có vẻ đã dừng"
                // trong lúc thực ra chỉ đang cào 1 trang nặng). Giờ đọc file
                // heartbeat RIÊNG, độc lập hoàn toàn với tốc độ cào — Python
                // (HeartbeatThread, xem crawler.py) ghi file này mỗi 45s bất
                // kể đang làm gì — heartbeat lâu không đổi mới THẬT SỰ đáng
                // tin là "đã ngắt phiên", không phải "đang cào chậm".
                when (val hbResult = GitHubApiClient.getFileContent(cfg.owner, cfg.repo, cfg.branch, token, "remote-jobs/${job.id}-heartbeat.json")) {
                    is GitHubApiClient.ApiResult.Ok -> {
                        try {
                            val aliveAt = JSONObject(hbResult.value).optLong("aliveAt", 0L)
                            if (aliveAt != lastKnownHeartbeatAt) {
                                lastKnownHeartbeatAt = aliveAt
                                lastKnownHeartbeatObservedAt = System.currentTimeMillis()
                            }
                        } catch (e: Exception) { /* heartbeat đang ghi dở — bỏ qua lần poll này */ }
                    }
                    is GitHubApiClient.ApiResult.Err -> { /* chưa có heartbeat lần nào (job vừa mở Colab, chưa kịp ghi) — bình thường */ }
                }
                val staleFor = System.currentTimeMillis() - lastKnownHeartbeatObservedAt
                if (lastKnownHeartbeatAt != null && staleFor > COLAB_STALE_WARNING_MS) {
                    handler.post {
                        onProgress(lastKnownChapterCount, 0, "⚠️ Colab không báo còn sống hơn ${COLAB_STALE_WARNING_MS / 60000} phút — có thể đã ngắt phiên. Dữ liệu đã cào TỚI ĐÓ không mất — mở lại tab Colab hoặc \"Dừng\" rồi \"Chạy lại\" để tiếp tục.")
                    }
                }
            }

            schedulePoll()
        }.start()
    }

    @Volatile private var lastKnownHeartbeatAt: Long? = null
    @Volatile private var lastKnownHeartbeatObservedAt: Long = System.currentTimeMillis()
    @Volatile private var lastKnownChapterCount: Int = 0
    // ĐÃ THÊM — cờ theo dõi trạng thái "đang chờ lệnh interactive được thực
    // thi bên remote": true sau khi sendInteractiveAction() ghi lệnh lên git,
    // false sau khi pollOnce() đọc thấy kết quả (cmd file biến mất = Python
    // đã thực thi xong). Dùng để scheduleInteractivePoll() thay vì poll
    // thường (chu kỳ ngắn hơn khi người dùng đang chờ kết quả trực tiếp).
    @Volatile private var awaitingInteractiveResult: Boolean = false
    // ĐÃ THÊM — mốc lastInteractiveAt (ms) đã XỬ LÝ gần nhất, dùng phân biệt
    // "kết quả lệnh MỚI vừa xong" với "checkpoint vẫn còn mang mốc CŨ từ
    // lệnh trước, Python chưa xử lý xong lệnh MỚI" — chỉ coi là "xong" khi
    // lastInteractiveAt đọc được > mốc này (xem sửa lỗi trong pollOnce()).
    @Volatile private var lastInteractiveResultSeenAt: Long = 0L
    // ĐÃ THÊM — mốc `savedAt` (ghi trong checkpoint) của lần TẠM DỪNG gần
    // nhất đã báo qua onNeedsManualAction — dùng tránh 2 hậu quả của việc
    // nhánh pausedForManualReview chạy KHÔNG ĐIỀU KIỆN mỗi lần poll (kể cả
    // do scheduleInteractivePoll() gọi liên tục lúc chờ 1 lệnh thường):
    // (a) spam lại thông báo + tự backup MỖI 5 GIÂY trong lúc chờ lệnh xử
    // lý xong, (b) tải lại + GHI ĐÈ pendingActionScreenshotPath về ảnh CHẶN
    // BAN ĐẦU, xoá mất ảnh interactive vừa cập nhật đúng trong CÙNG lần
    // poll đó. Khởi tạo -1L (khác mọi savedAt thật, luôn > 0) để LẦN ĐẦU
    // phát hiện paused vẫn báo bình thường.
    @Volatile private var lastNotifiedPausedSavedAt: Long = -1L

    private fun finishFromCheckpoint(checkpoint: CrawlCheckpoint) {
        handler.post {
            if (checkpoint.chaptersSoFar.isEmpty()) {
                onError("Job hoàn tất trên GitHub nhưng không cào được chương nào — kiểm tra lại selector/URL")
                return@post
            }
            Thread {
                try {
                    val path = com.colablive.keeper.features.ebookleech.export.EbookExporter.export(context, job, checkpoint.chaptersSoFar)
                    CrawlCheckpointRepository.delete(context, slotIndex, job.id)
                    handler.post { onDone(path) }
                } catch (e: Exception) {
                    handler.post { onError("Xuất ebook từ dữ liệu đã cào từ xa lỗi: ${e.message}") }
                }
            }.start()
        }
    }

    private fun postError(msg: String) {
        handler.post { onError(msg) }
    }

    fun cancel() {
        cancelled = true
        handler.removeCallbacksAndMessages(null)
        // CỐ Ý KHÔNG huỷ lần chạy Actions đang diễn ra (không gọi API huỷ
        // workflow run) — để nó chạy tiếp tới cùng và commit checkpoint,
        // job có thể "Chạy lại" sau để lấy nốt phần đã cào thêm được, thay
        // vì mất trắng phần đang cào dở khi người dùng chỉ đang xem màn
        // hình khác trong app (KHÔNG chủ động bấm "Huỷ hẳn job trên GitHub").
    }
}
