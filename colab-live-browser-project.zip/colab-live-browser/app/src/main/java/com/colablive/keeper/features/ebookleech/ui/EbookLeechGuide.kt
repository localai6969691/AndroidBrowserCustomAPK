package com.colablive.keeper.features.ebookleech.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Hộp thoại "📖 Hướng dẫn" của EbookLeech (bản 7.98).
 *
 * Nội dung nằm ở MỘT file duy nhất: `assets/ebookleech/huong_dan.md` (bản sao để đọc ngoài app: `ebookleech/HUONG_DAN_SU_DUNG.md`).
 * Sửa hướng dẫn chỉ cần sửa file đó, không động tới mã. Định dạng tối giản: dòng `## ` = tiêu đề mục, dòng `- ` = gạch đầu dòng,
 * còn lại là văn bản thường.
 */
object EbookLeechGuide {
    private const val ASSET_PATH = "ebookleech/huong_dan.md"

    fun show(ctx: Context) {
        val text = try {
            ctx.assets.open(ASSET_PATH).bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            "Không đọc được file hướng dẫn ($ASSET_PATH): ${e.message}"
        }
        val density = ctx.resources.displayMetrics.density
        fun dp(n: Int) = (n * density).toInt()

        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(6), dp(20), dp(12))
        }
        for (raw in text.lines()) {
            val line = raw.trimEnd()
            if (line.isBlank()) continue
            val tv = TextView(ctx)
            if (line.startsWith("## ")) {
                tv.text = line.removePrefix("## ")
                tv.textSize = 16f
                tv.setTypeface(tv.typeface, Typeface.BOLD)
                tv.setTextColor(Color.parseColor("#1f2937"))
                tv.setPadding(0, dp(16), 0, dp(4))
            } else {
                tv.text = if (line.startsWith("- ")) "•  " + line.removePrefix("- ") else line
                tv.textSize = 13.5f
                tv.setTextColor(Color.parseColor("#374151"))
                tv.setPadding(0, dp(2), 0, dp(2))
            }
            box.addView(tv)
        }
        val scroll = ScrollView(ctx).apply { addView(box) }
        android.app.AlertDialog.Builder(ctx)
            .setTitle("📖 Hướng dẫn EbookLeech")
            .setView(scroll)
            .setPositiveButton("Đóng", null)
            .show()
    }
}
