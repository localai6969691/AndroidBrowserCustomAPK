package com.colablive.keeper.core

import android.content.Context
import android.os.SystemClock
import java.io.File

/**
 * Bản 7.93 — CHỐT CHẶN VÒNG LẶP CRASH LÚC KHỞI ĐỘNG.
 *
 * Log crash 17:50 (người dùng báo "liên tục bị crash"): sau một lần thoát, MỖI lần mở app đều ném NullPointerException trong onCreate (xem GeckoViewEngine.activeSession),
 * tiến trình chết sau ~3 giây, mở lại vẫn thế — vòng lặp vô tận vì danh sách tab đã lưu (saved_tabs.json) trên đĩa KHÔNG đổi giữa các lần chết. Người dùng chỉ thoát được bằng
 * xoá dữ liệu app (mất đăng nhập). Bất kỳ lỗi nào sau này mà do trạng thái đã lưu gây ra cũng sẽ lặp y như vậy.
 *
 * Cơ chế (không phụ thuộc loại lỗi, không đoán theo thiết bị): handler exception chưa bắt (LiveBrowserApp) gọi [onUncaught]; nếu tiến trình mới sống chưa tới [EARLY_MS]
 * thì đếm 1 lần "chết lúc khởi động" vào tệp riêng của khe. MainActivity gọi [reset] khi app đã sống ổn định (xem MainActivity.onCreate). Khi khởi động lại
 * mà bộ đếm >= [LOOP_THRESHOLD] thì `restoreTabsIfAny` ĐỂ SANG MỘT BÊN tệp tab đã lưu (đổi tên, KHÔNG xoá) và khởi động sạch.
 * Chỉ đếm exception chưa bắt trong 30 giây đầu của tiến trình — người dùng vuốt tắt/Force stop hay hệ điều hành giết tiến trình KHÔNG bị tính.
 */
object StartupGuard {
    private const val EARLY_MS = 30_000L
    private const val LOOP_THRESHOLD = 2

    private fun file(context: Context, slot: Int) = File(context.filesDir, "startup_guard_slot$slot.txt")

    fun count(context: Context, slot: Int): Int =
        try { file(context, slot).readText().trim().toInt() } catch (_: Throwable) { 0 }

    /** Gọi từ handler exception chưa bắt, TRƯỚC khi tiến trình bị giết. */
    fun onUncaught(context: Context, slot: Int) {
        try {
            val aliveMs = SystemClock.elapsedRealtime() - android.os.Process.getStartElapsedRealtime()
            if (aliveMs > EARLY_MS) { reset(context, slot); return }
            file(context, slot).writeText((count(context, slot) + 1).toString())
        } catch (_: Throwable) { /* chỉ là chốt chặn phụ */ }
    }

    fun shouldQuarantine(context: Context, slot: Int): Boolean = count(context, slot) >= LOOP_THRESHOLD

    fun reset(context: Context, slot: Int) {
        try { file(context, slot).delete() } catch (_: Throwable) {}
    }
}
