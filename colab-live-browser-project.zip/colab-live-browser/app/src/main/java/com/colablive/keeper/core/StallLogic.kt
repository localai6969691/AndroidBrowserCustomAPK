package com.colablive.keeper.core

/**
 * Bản 7.110 — LOGIC THUẦN (không đụng Android) của bộ phát hiện "trình duyệt đơ do một luồng của tiến trình chính quay vòng".
 *
 * BẰNG CHỨNG (log 19/11 00:52–00:54, bốn lần `[tải lại][CHẨN ĐOÁN ĐƠ]` liên tiếp): `list()` của Gecko phần cha trả về sau 11–28ms (phần cha còn phục vụ),
 * content script của tab KHÔNG trả lời, các tiến trình tab gần như rảnh (tab20=20–30ms, tab29=0ms trong cửa sổ ~3s) — còn tiến trình CHÍNH có một luồng
 * `AudioIPC Server` dùng 2960ms / 2976ms, 2960/2964, 2990/2999, 2960/2976 (≈100% một nhân, suốt ≥ 56s). `AudioIPC Server` là vòng lặp sự kiện đơn luồng ở tiến trình cha
 * phục vụ MỌI lệnh âm thanh (cubeb) của các tiến trình nội dung dưới dạng RPC ĐỒNG BỘ (Mozilla bug 2034333) => khi nó kẹt/quay, tiến trình nội dung nào gọi âm thanh sẽ đứng theo.
 *
 * CHƯA BIẾT: vì sao luồng đó quay (không có bug Mozilla công khai khớp đúng "quay 100% CPU trên Android"). Bản này KHÔNG sửa Gecko; nó (a) nhận ra tình trạng sớm bằng số liệu thay vì
 * chờ người dùng bấm Tải lại 2 lần, (b) xác nhận bằng một lệnh thăm dò thật vào trang (tránh khởi động lại oan), (c) cho một đường phục hồi tự động có đếm ngược và nút Huỷ.
 */
object StallLogic {
    /** Một luồng được coi là "nóng" khi dùng >= ngần này % của một nhân trong một cửa sổ đo. */
    const val HOT_BUSY_PCT = 80
    /** `AudioIPC Server` nóng liên tục >= ngần này ms thì coi là quay vòng (log: ≥ 56s; bình thường luồng này nằm chờ epoll). */
    const val AUDIO_STREAK_MS = 15_000L
    /** Luồng KHÁC (ngoài giao diện/vẽ) nóng liên tục >= ngần này ms mới được xét (chỉ để MỜI khởi động lại, không tự làm). */
    const val GENERIC_STREAK_MS = 45_000L
    /** Tên luồng (comm, tối đa 15 ký tự) vốn có thể bận trong lúc cuộn/vẽ — không coi là quay vòng. */
    val BENIGN_NAMES = setOf("AndroidUI", "RenderThread", "main", "stall-watchdog")

    class Hot(val tid: Int, val name: String, val busyPct: Int, val streakMs: Long)

    /**
     * Theo dõi dải nóng của từng luồng qua các lần đo liên tiếp. [clkTck] = số tick CPU mỗi giây (sysconf _SC_CLK_TCK, thường 100).
     * `feed` nhận số tick (utime+stime) CỘNG DỒN của từng luồng tại thời điểm [atMs] và trả về các luồng đang nóng cùng độ dài dải nóng (ms).
     */
    class HotTracker(private val clkTck: Long) {
        private var hasLast = false
        private var lastAt = 0L
        private var last: Map<Int, Long> = emptyMap()
        private val streakStart = HashMap<Int, Long>()

        fun feed(atMs: Long, ticks: Map<Int, Long>, names: Map<Int, String>): List<Hot> {
            val out = ArrayList<Hot>()
            if (hasLast && atMs > lastAt) {
                val wall = atMs - lastAt
                val seen = HashSet<Int>()
                for ((tid, t) in ticks) {
                    val o = last[tid] ?: continue
                    val busyMs = (t - o).coerceAtLeast(0L) * 1000L / clkTck
                    val pct = (busyMs * 100L / wall).toInt()
                    if (pct >= HOT_BUSY_PCT) {
                        seen.add(tid)
                        val start = streakStart.getOrPut(tid) { lastAt }
                        out.add(Hot(tid, names[tid] ?: "tid$tid", pct, atMs - start))
                    }
                }
                streakStart.keys.retainAll(seen)
            }
            last = ticks
            lastAt = atMs
            hasLast = true
            return out
        }

        fun reset() { hasLast = false; lastAt = 0L; last = emptyMap(); streakStart.clear() }
    }

    enum class Kind { NONE, AUDIO_RUNAWAY, OTHER_RUNAWAY }
    class Verdict(val kind: Kind, val hot: Hot?)

    /** Chọn luồng đáng ngờ nhất. `AudioIPC*` được ưu tiên và có ngưỡng ngắn hơn vì đã có bằng chứng thực địa. */
    fun classify(hots: List<Hot>): Verdict {
        val audio = hots.filter { it.name.contains("AudioIPC", ignoreCase = true) && it.streakMs >= AUDIO_STREAK_MS }.maxByOrNull { it.streakMs }
        if (audio != null) return Verdict(Kind.AUDIO_RUNAWAY, audio)
        val other = hots.filter { it.name !in BENIGN_NAMES && it.streakMs >= GENERIC_STREAK_MS }.maxByOrNull { it.streakMs }
        if (other != null) return Verdict(Kind.OTHER_RUNAWAY, other)
        return Verdict(Kind.NONE, null)
    }

    /** Kết quả lệnh thăm dò thật vào một trang (eval `1`): trang trả lời / không trả lời trong hạn / không có tab nào thăm dò được. */
    enum class Probe { NOT_RUN, RESPONDED, NO_RESPONSE, CANNOT }

    enum class Action { NONE, PROBE, AUTO_RESTART_COUNTDOWN, OFFER_RESTART }

    /**
     * Quyết định hành động. KHÔNG khởi động lại nếu trang vẫn trả lời thăm dò (luồng nóng nhưng trình duyệt dùng được => chỉ ghi log).
     * Không có tab http(s) nào thăm dò được thì chỉ hành động khi trước đó đã có lệnh eval vào tab đang xem bị quá hạn ([recentEvalTimeouts] >= 1).
     * `AUDIO_RUNAWAY` => đếm ngược tự khởi động lại (có Huỷ); loại khác => chỉ mời.
     */
    fun decide(kind: Kind, probe: Probe, recentEvalTimeouts: Int): Action {
        if (kind == Kind.NONE) return Action.NONE
        val effective = when {
            probe == Probe.CANNOT && recentEvalTimeouts >= 1 -> Probe.NO_RESPONSE
            else -> probe
        }
        return when (effective) {
            Probe.NOT_RUN -> Action.PROBE
            Probe.RESPONDED, Probe.CANNOT -> Action.NONE
            Probe.NO_RESPONSE -> if (kind == Kind.AUDIO_RUNAWAY) Action.AUTO_RESTART_COUNTDOWN else Action.OFFER_RESTART
        }
    }

    // ===== Bản 7.111 — phục hồi theo bậc + pháp y =====

    /** Tiến trình nội dung `tabN`: nhãn, pid, RSS (kB). */
    class Proc(val label: String, val pid: Int, val rssKb: Long)

    /**
     * Thứ tự giết thử từng tiến trình nội dung: tiến trình có RSS TĂNG nhiều nhất kể từ lúc bắt đầu nghi đứng trước (log 19/11: tab20 tăng từ ~728MB lên ~848–1040MB đúng lúc đơ trong khi CPU ~0 —
     * hợp với "luồng chính của nó đứng, hàng đợi IPC dồn lại"; đây chỉ là gợi ý xếp thứ tự, KHÔNG phải bằng chứng), hoà thì RSS lớn hơn trước.
     */
    fun rankVictims(rssAtStart: Map<Int, Long>, now: List<Proc>): List<Proc> =
        now.sortedWith(compareByDescending<Proc> { (it.rssKb - (rssAtStart[it.pid] ?: it.rssKb)) }.thenByDescending { it.rssKb })

    private val SYS64 = mapOf(19 to "eventfd2", 21 to "epoll_ctl", 22 to "epoll_pwait", 29 to "ioctl", 56 to "openat", 57 to "close", 63 to "read", 64 to "write", 65 to "readv", 66 to "writev",
        72 to "pselect6", 73 to "ppoll", 98 to "futex", 101 to "nanosleep", 113 to "clock_gettime", 115 to "clock_nanosleep", 124 to "sched_yield", 206 to "sendto", 207 to "recvfrom",
        211 to "sendmsg", 212 to "recvmsg", 441 to "epoll_pwait2")
    private val SYS32 = mapOf(3 to "read", 4 to "write", 54 to "ioctl", 158 to "sched_yield", 162 to "nanosleep", 240 to "futex", 252 to "epoll_wait", 290 to "sendto", 292 to "recvfrom",
        296 to "sendmsg", 297 to "recvmsg", 336 to "ppoll", 346 to "epoll_pwait")

    /**
     * Rút gọn các lần đọc `/proc/self/task/<tid>/syscall`: dòng đầu mỗi mẫu là `running` (đang chạy ở không gian người dùng), `-1 ...` (không ở trong lệnh hệ thống) hoặc `<số lệnh> <đối số>...`.
     * Cách đọc: gần như toàn `running` => quay thuần CPU trong mã người dùng; nhiều `epoll_*`/`read`/`recvmsg` xen `running` => vòng lặp gọi lệnh hệ thống trả về ngay (vd epoll báo tức thì
     * trên một fd đã đóng/lỗi) — hai loại lỗi rất khác nhau.
     */
    fun summarizeSyscalls(samples: List<String>, is64: Boolean): String {
        if (samples.isEmpty()) return "không có mẫu"
        val table = if (is64) SYS64 else SYS32
        val hist = LinkedHashMap<String, Int>()
        for (raw in samples) {
            val first = raw.trim().substringBefore(' ')
            val key = when {
                first.isEmpty() -> "trống"
                first == "running" -> "running"
                first == "-1" -> "không-trong-syscall"
                else -> { val n = first.toIntOrNull(); if (n == null) first else (table[n] ?: "sys") + "($n)" }
            }
            hist[key] = (hist[key] ?: 0) + 1
        }
        return hist.entries.sortedByDescending { it.value }.joinToString(", ") { "${it.key}×${it.value}" } + " /${samples.size} mẫu (${if (is64) "64-bit" else "32-bit"})"
    }

    /**
     * Bản 7.112 — tóm tắt VÒNG ĐỜI ra/vào nền quanh lúc nghi đơ. Lý do: cả 3 lần đơ có số liệu gần đây đều xảy ra NGAY SAU khi quay lại app (7.93: 4 vòng ra/vào nền trong 3 phút trước đơ;
     * log 18/11 23:30: 4 vòng trong 1 phút; log 19/11 00:52: quay lại sau 1208s ở nền rồi đơ trong ~60s) — nhưng chưa từng được ghi lại có hệ thống để so sánh.
     * [events] = (uptimeMillis, true nếu VÀO trước/false nếu RA nền).
     */
    fun lifecycleSummary(events: List<Pair<Long, Boolean>>, now: Long): String {
        if (events.isEmpty()) return "vòng đời: chưa có sự kiện"
        val sorted = events.sortedBy { it.first }
        val last = sorted.last()
        val since = (now - last.first) / 1000
        val state = if (last.second) "đang ở TRƯỚC (quay lại app cách ${since}s)" else "đang ở NỀN (ra nền cách ${since}s)"
        val recent = sorted.count { now - it.first <= 300_000L }
        val prevDur = if (sorted.size >= 2 && sorted[sorted.size - 2].second != last.second)
            " | trạng thái ngay trước đó (${if (sorted[sorted.size - 2].second) "ở trước" else "ở nền"}) kéo dài ${(last.first - sorted[sorted.size - 2].first) / 1000}s" else ""
        return "vòng đời: $state | $recent lần đổi ra/vào nền trong 5 phút$prevDur"
    }
}
