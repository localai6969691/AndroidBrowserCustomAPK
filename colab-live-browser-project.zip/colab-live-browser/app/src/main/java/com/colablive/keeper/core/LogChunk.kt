package com.colablive.keeper.core

/**
 * Bản 7.112 — chia một dòng log DÀI thành nhiều dòng, KHÔNG làm mất chữ nào.
 *
 * Vì sao cần: `DebugLog.compact` cắt mọi dòng ở 1500 ký tự (`…(+N ký tự)`). Dòng `[CHẨN ĐOÁN ĐƠ]` từ 7.94 được ghép theo thứ tự `head | CPU/đóng băng/tiến trình | MemEvidence`
 * (MemEvidence = MemAvailable/Swap + PSI + `pgmajfault`/`pswpin`...) nên PHẦN QUYẾT ĐỊNH VỀ BỘ NHỚ NẰM CUỐI VÀ BỊ CẮT trong mọi log đơ (log 00:53–00:54: "…(+606 ký tự)"). Tệp `last_stall_slotN.txt`
 * có đủ nhưng khi in lại ở lần chạy sau cũng đi qua `DebugLog.log` nên lại bị cắt. Hậu quả: giả thuyết "đơ do áp lực bộ nhớ" chưa bao giờ được kiểm bằng số liệu thật dù code thu số liệu đã có.
 *
 * Quy tắc: ưu tiên cắt ở ranh giới " | " (không bẻ đôi một mục); mục dài hơn [max] thì cắt cứng. Mỗi mảnh có tiền tố `(i/n) ` để ghép lại; `Khe N: [nhãn]` đầu dòng được lặp lại ở các mảnh sau
 * để lọc theo nhãn vẫn thấy đủ.
 */
object LogChunk {
    fun split(message: String, max: Int = 1300): List<String> {
        if (message.length <= max) return listOf(message)
        // Tiền tố nhận dạng (vd "Khe 0: [đơ-watchdog]") lặp lại ở mỗi mảnh.
        val m = Regex("^(Khe \\d+: \\[[^\\]]+\\](?:\\[[^\\]]+\\])?)\\s").find(message)
        val prefix = m?.groupValues?.get(1) ?: ""
        val body = if (m != null) message.substring(m.value.length) else message
        val room = (max - prefix.length - 12).coerceAtLeast(200)
        val parts = ArrayList<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotEmpty()) { parts.add(cur.toString()); cur.setLength(0) } }
        for (seg in body.split(" | ")) {
            var s = seg
            while (s.length > room) {           // một mục quá dài: cắt cứng
                flush()
                parts.add(s.substring(0, room)); s = s.substring(room)
            }
            val add = if (cur.isEmpty()) s.length else s.length + 3
            if (cur.isNotEmpty() && cur.length + add > room) flush()
            if (cur.isNotEmpty()) cur.append(" | ")
            cur.append(s)
        }
        flush()
        val n = parts.size
        return parts.mapIndexed { i, p -> (if (prefix.isNotEmpty()) "$prefix " else "") + "(${i + 1}/$n) " + p }
    }
}
