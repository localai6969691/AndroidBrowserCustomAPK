package com.colablive.keeper.features.ebookleech.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * LeechProject — một "Dự án" chứa nhiều Job, giống cách KDN Auto Leech nhóm
 * nhiều site lại để quản lý chung (vd: "Dự án Truyện Kiếm Hiệp",
 * "Dự án Tin tức công nghệ"...). Trước đây addon chỉ có 1 danh sách job
 * phẳng — không phân biệt được job nào thuộc nhóm nào khi có hàng chục job.
 *
 * job.projectId rỗng ("") = chưa phân nhóm, hiển thị trong nhóm mặc định
 * "Chưa phân nhóm" ở UI — không phải lỗi, không bắt buộc phải gán dự án.
 */
data class LeechProject(
    val id: String,
    val name: String,
    val colorHex: String = "#2563eb",   // màu dải nhãn hiển thị trong UI, phân biệt nhanh bằng mắt
    val createdAt: Long = System.currentTimeMillis(),
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("colorHex", colorHex)
        put("createdAt", createdAt)
    }

    companion object {
        fun fromJson(json: JSONObject) = LeechProject(
            id = json.getString("id"),
            name = json.getString("name"),
            colorHex = json.optString("colorHex", "#2563eb"),
            createdAt = json.optLong("createdAt", System.currentTimeMillis()),
        )

        fun listFromJson(arr: JSONArray): List<LeechProject> =
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }

        fun listToJson(projects: List<LeechProject>): JSONArray =
            JSONArray().also { arr -> projects.forEach { arr.put(it.toJson()) } }
    }
}
