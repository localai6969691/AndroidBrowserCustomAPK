package com.colablive.keeper.features.ebookleech.model

import android.content.Context
import com.colablive.keeper.core.AppPrefs
import org.json.JSONArray
import java.util.UUID

object LeechProjectRepository {

    private const val FEATURE_ID = "ebook_leech"
    private const val KEY_PROJECTS = "projects_json"

    fun loadAll(context: Context, slotIndex: Int): MutableList<LeechProject> {
        val raw = AppPrefs.getString(context, slotIndex, FEATURE_ID, KEY_PROJECTS, "[]")
        return try {
            LeechProject.listFromJson(JSONArray(raw)).toMutableList()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, slotIndex: Int, projects: List<LeechProject>) {
        AppPrefs.setString(context, slotIndex, FEATURE_ID, KEY_PROJECTS, LeechProject.listToJson(projects).toString())
    }

    fun addProject(context: Context, slotIndex: Int, project: LeechProject) {
        val list = loadAll(context, slotIndex)
        list.add(project)
        save(context, slotIndex, list)
    }

    fun renameProject(context: Context, slotIndex: Int, projectId: String, newName: String) {
        val list = loadAll(context, slotIndex)
        val idx = list.indexOfFirst { it.id == projectId }
        if (idx >= 0) {
            list[idx] = list[idx].copy(name = newName)
            save(context, slotIndex, list)
        }
    }

    /**
     * Xoá 1 dự án. Job thuộc dự án này KHÔNG bị xoá theo — chỉ bị gỡ khỏi
     * nhóm (projectId reset về ""), quay lại nhóm "Chưa phân nhóm". Tránh
     * mất dữ liệu cào chỉ vì thao tác quản lý nhóm.
     */
    fun deleteProject(context: Context, slotIndex: Int, projectId: String) {
        val list = loadAll(context, slotIndex).filter { it.id != projectId }
        save(context, slotIndex, list)
        val jobs = LeechJobRepository.loadAll(context, slotIndex)
        jobs.filter { it.projectId == projectId }.forEach { job ->
            LeechJobRepository.updateJob(context, slotIndex, job.copy(projectId = ""))
        }
    }

    fun getProject(context: Context, slotIndex: Int, projectId: String): LeechProject? =
        loadAll(context, slotIndex).firstOrNull { it.id == projectId }

    fun newId(): String = UUID.randomUUID().toString()
}
