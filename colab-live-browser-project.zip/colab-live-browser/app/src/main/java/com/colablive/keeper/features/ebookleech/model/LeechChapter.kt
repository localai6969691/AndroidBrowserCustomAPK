package com.colablive.keeper.features.ebookleech.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * Một chương đã cào xong.
 * @param images Danh sách ảnh đã tải về (rỗng nếu job không bật downloadImages)
 */
data class LeechChapter(
    val index: Int,
    val title: String,
    val htmlContent: String,
    val textContent: String,
    val sourceUrl: String,
    val images: List<LeechImage> = emptyList(),
) {
    /**
     * Serialize cho checkpoint (CrawlCheckpoint).
     *
     * ĐÃ SỬA (nợ kỹ thuật cũ — checkpoint mất ảnh khi resume sau crash):
     * TRƯỚC ĐÂY bỏ hẳn field `images` (comment cũ giải thích: base64 hoá
     * bytes ảnh vào JSON sẽ làm checkpoint phình rất nhanh). Giờ VẪN
     * KHÔNG ghi bytes vào JSON (đúng lo ngại cũ, vẫn hợp lý) — nhưng ghi
     * ĐỦ METADATA (`originalUrl`/`localFileName`/`mimeType`) để khôi phục
     * lại link giữa chương và đúng file ảnh. Bytes THẬT được
     * `CrawlCheckpointRepository` ghi riêng ra file nhỏ cạnh checkpoint
     * (`persistImageBytes()`), đọc lại qua `imageLoader` truyền vào
     * `fromJson()` bên dưới lúc resume.
     */
    fun toJson(): JSONObject = JSONObject().apply {
        put("index", index)
        put("title", title)
        put("htmlContent", htmlContent)
        put("textContent", textContent)
        put("sourceUrl", sourceUrl)
        put("images", JSONArray().also { arr ->
            images.forEach { img ->
                arr.put(JSONObject().apply {
                    put("originalUrl", img.originalUrl)
                    put("localFileName", img.localFileName)
                    put("mimeType", img.mimeType)
                    // bytes CỐ Ý không ghi ở đây — xem CrawlCheckpointRepository.persistImageBytes()
                })
            }
        })
    }

    companion object {
        /**
         * @param imageLoader Đọc bytes ảnh thật từ đĩa theo `localFileName`
         * (do `CrawlCheckpointRepository` cung cấp lúc resume). Mặc định
         * `{ null }` — dùng khi gọi từ chỗ KHÔNG có quyền truy cập file ảnh
         * checkpoint (vd `EbookLeechBackupManager` phục hồi backup — backup
         * JSON không kèm theo file ảnh, ảnh rỗng lại là đúng hành vi, không
         * phải thiếu sót).
         */
        fun fromJson(json: JSONObject, imageLoader: (String) -> ByteArray? = { null }) = LeechChapter(
            index = json.getInt("index"),
            title = json.getString("title"),
            htmlContent = json.optString("htmlContent", ""),
            textContent = json.optString("textContent", ""),
            sourceUrl = json.optString("sourceUrl", ""),
            images = json.optJSONArray("images")?.let { arr ->
                (0 until arr.length()).mapNotNull { i ->
                    val o = arr.getJSONObject(i)
                    val localFileName = o.optString("localFileName", "")
                    val bytes = if (localFileName.isNotEmpty()) imageLoader(localFileName) else null
                    // Không đọc lại được bytes (file ảnh mất/lỗi/không có
                    // imageLoader) → bỏ qua ĐÚNG ảnH đó, KHÔNG làm hỏng cả
                    // chương hay chặn resume — ebook cuối cùng chỉ thiếu
                    // đúng ảnh đó, chữ vẫn đầy đủ.
                    if (bytes == null) null
                    else LeechImage(
                        originalUrl = o.optString("originalUrl", ""),
                        localFileName = localFileName,
                        mimeType = o.optString("mimeType", "image/jpeg"),
                        bytes = bytes,
                    )
                }
            } ?: emptyList(),
        )

        fun listFromJson(arr: JSONArray, imageLoader: (String) -> ByteArray? = { null }): List<LeechChapter> =
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it), imageLoader) }

        fun listToJson(chapters: List<LeechChapter>): JSONArray =
            JSONArray().also { arr -> chapters.forEach { arr.put(it.toJson()) } }
    }
}
