package com.colablive.keeper.core

import android.content.Context
import android.os.Build
import android.os.SystemClock
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Bản 7.110 — BỘ CANH "trình duyệt đơ vì một luồng của tiến trình chính quay vòng" (xem lý lẽ + số liệu thật trong [StallLogic]).
 *
 * Trước đây việc phát hiện đơ chỉ chạy SAU KHI người dùng bấm Tải lại 2 lần (7.94), nên người dùng phải tự chờ, tự bấm, rồi vẫn thường phải vuốt tắt app. Bộ canh này:
 *  1. mỗi 5s (nền: 10s) đọc CPU từng luồng của CHÍNH tiến trình (`/proc/self/task`), theo dõi dải "nóng" (>= 80% một nhân) của từng luồng — [StallLogic.HotTracker];
 *  2. khi `AudioIPC Server` nóng liên tục >= 15s (hoặc luồng lạ >= 45s) thì THĂM DÒ THẬT: gửi lệnh `1` vào một trang http(s) và chờ 5s. Trang vẫn trả lời => chỉ ghi log (không khởi động lại oan);
 *  3. trang im => XÁC NHẬN ĐƠ: ghi bằng chứng (CPU mọi tiến trình/luồng, âm thanh hệ thống, trạng thái app) ra log và `last_stall_slotN.txt`, rồi giao cho engine hiện hộp thoại
 *     (với `AudioIPC Server`: đếm ngược tự khởi động lại giữ tab, có nút Huỷ; luồng khác: chỉ mời).
 *
 * KHÔNG sửa nguyên nhân bên trong Gecko (chưa biết vì sao luồng đó quay). Khởi động lại tiến trình là cách DUY NHẤT dọn được một luồng native quay vòng ở tiến trình cha.
 */
object GeckoStallWatchdog {
    interface Host {
        /** Thăm dò thật một trang http(s); [cb] được gọi ĐÚNG MỘT LẦN (trên luồng bất kỳ). Tham số 2 = tab đã thăm dò ("-" nếu không có). */
        fun probeResponsive(timeoutMs: Long, cb: (StallLogic.Probe, String) -> Unit)
        /**
         * Đã xác nhận đơ. Host tự chuyển sang luồng chính. [auto] = được phép đếm ngược tự làm.
         * [stage] 1 = thử GIẾT tiến trình NỘI DUNG [victims] (đã xếp thứ tự) — tiến trình CHA giữ nguyên nên cookie chế độ riêng tư/ẩn danh còn; 2 = mời khởi động lại cả app (mất tab ẩn danh).
         */
        fun onRunaway(kind: StallLogic.Kind, auto: Boolean, headline: String, evidence: String, stage: Int, victims: List<StallLogic.Proc>)
        /** Một dòng mô tả trạng thái app (tab đang xem, ở nền?, media...) để ghi kèm. */
        fun contextLine(): String
        /** Cờ [isStalled] vừa đổi (để làm mới nhãn thông báo). */
        fun onStallStateChanged()
    }

    private const val FG_INTERVAL_MS = 5_000L
    private const val BG_INTERVAL_MS = 10_000L
    private const val PROBE_TIMEOUT_MS = 5_000L
    private const val PROBE_EVERY_MS = 10_000L
    private const val ACTION_COOLDOWN_MS = 180_000L
    private const val EVAL_TIMEOUT_WINDOW_MS = 60_000L

    @Volatile private var host: Host? = null
    private var appCtx: Context? = null
    private var slot = 0
    private var exec: ScheduledExecutorService? = null
    private var future: ScheduledFuture<*>? = null
    @Volatile private var foreground = true

    // Trạng thái dưới đây CHỈ được chạm trên luồng canh (exec), trừ khi ghi chú khác.
    private val names = HashMap<Int, String>()
    private var tracker: StallLogic.HotTracker? = null
    private var episodeId = 0
    private var episodeStartedAt = 0L
    private var episodeMark: GeckoHealthProbe.CpuMark? = null
    private var probeInFlight = false
    private var lastProbeAt = 0L
    private var probeLogs = 0
    private var lastKind = StallLogic.Kind.NONE
    @Volatile private var lastActionAt = 0L
    @Volatile private var suppressUntil = 0L
    // Bản 7.111: phục hồi theo bậc. softTried = đã thử giết tiến trình nội dung trong đợt này; softInProgress = đang giữa chừng (không được nhảy sang bậc 2).
    @Volatile private var softTried = false
    @Volatile private var softInProgress = false
    @Volatile private var hotNow = false
    private var rssAtStart: Map<Int, Long> = emptyMap()
    private var respondedHotLogged = false
    private var memMarkAtStart: MemEvidence.Mark? = null
    private var lastDiagAt = 0L
    private var audioTimelineRegistered = false

    /** uptimeMillis lúc XÁC NHẬN đơ; 0 = không đơ. Đọc từ luồng bất kỳ (nhãn thông báo Colab dùng để không báo nhầm "Colab mất tín hiệu"). */
    @Volatile var stalledSince = 0L
        private set
    fun isStalled(): Boolean = stalledSince != 0L

    private val evalTimeouts = ConcurrentLinkedDeque<Long>()

    @Synchronized
    fun start(context: Context, slotIndex: Int) {
        appCtx = context.applicationContext
        slot = slotIndex
        registerAudioTimeline(context.applicationContext)
        if (exec == null) {
            exec = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "stall-watchdog").apply { isDaemon = true } }
        }
        if (future == null) schedule()
    }

    @Synchronized
    private fun schedule() {
        val ex = exec ?: return
        future?.cancel(false)
        val iv = if (foreground) FG_INTERVAL_MS else BG_INTERVAL_MS
        future = ex.scheduleWithFixedDelay({ try { tick() } catch (e: Throwable) { try { DebugLog.log("Khe $slot: [đơ-watchdog] tick lỗi ${e.javaClass.simpleName}: ${e.message}") } catch (_: Throwable) {} } }, iv, iv, TimeUnit.MILLISECONDS)
    }

    fun attach(h: Host) { host = h }
    fun detach(h: Host) { if (host === h) host = null }

    fun setForeground(fg: Boolean) {
        if (foreground == fg) return
        foreground = fg
        // Quay lại app mà vẫn đang đơ => cho phép hộp thoại hiện NGAY ở lần xác nhận kế tiếp (lúc ở nền host không hiện hộp thoại).
        if (fg) lastActionAt = 0L
        synchronized(this) { if (future != null) schedule() }
    }

    /** Người dùng bấm Huỷ/Để sau: không hỏi lại trong [minutes] phút. */
    fun userDeclined(minutes: Int) { suppressUntil = SystemClock.uptimeMillis() + minutes * 60_000L }

    /** Luồng đáng ngờ còn nóng ở lần đo gần nhất (engine dùng để kiểm chứng sau khi giết một tiến trình nội dung). */
    fun isHotNow(): Boolean = hotNow
    /** Engine báo bắt đầu/kết thúc giết thử tiến trình nội dung. Thất bại => mở cooldown để lần xác nhận kế tiếp nhảy sang bậc 2 (khởi động lại). */
    fun softRecoveryStarted() { softInProgress = true; softTried = true }
    fun softRecoveryFinished(success: Boolean) { softInProgress = false; if (!success) lastActionAt = 0L }

    /** Engine báo một lệnh eval vào tab ĐANG XEM bị quá hạn 15s (bằng chứng phụ khi không có tab nào để thăm dò). */
    fun noteEvalTimeout() { evalTimeouts.addLast(SystemClock.uptimeMillis()) }

    private fun recentEvalTimeouts(now: Long): Int {
        while (true) {
            val first = evalTimeouts.peekFirst() ?: break
            if (now - first > EVAL_TIMEOUT_WINDOW_MS) evalTimeouts.pollFirst() else break
        }
        return evalTimeouts.size
    }

    /**
     * Bản 7.112 — DÒNG THỜI GIAN âm thanh/thiết bị (luôn bật, rất ít dòng): luồng `AudioIPC Server` quay trong lúc app có/không có luồng phát đang mở, hoặc ngay sau khi một thiết bị âm thanh
     * (tai nghe/Bluetooth) được thêm/rút, là manh mối trực tiếp tới nguyên nhân; các dòng `[âm thanh]` cũng nằm trong "14 sự kiện app NGAY TRƯỚC khi nghi". Số luồng phát là TOÀN MÁY
     * (có thể gồm app khác). Lỗi đăng ký chỉ ghi log, không ảnh hưởng gì khác.
     */
    private fun registerAudioTimeline(ctx: Context) {
        if (audioTimelineRegistered) return
        audioTimelineRegistered = true
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            val h = android.os.Handler(android.os.Looper.getMainLooper())
            if (Build.VERSION.SDK_INT >= 26) {
                am.registerAudioPlaybackCallback(object : android.media.AudioManager.AudioPlaybackCallback() {
                    override fun onPlaybackConfigChanged(configs: MutableList<android.media.AudioPlaybackConfiguration>?) {
                        val n = configs?.size ?: 0
                        val u = configs?.joinToString(",") { c -> try { "usage" + c.audioAttributes.usage } catch (_: Throwable) { "?" } } ?: ""
                        DebugLog.log("Khe $slot: [âm thanh] số luồng phát toàn máy đổi: $n [$u] (có thể gồm app khác)")
                    }
                }, h)
            }
            if (Build.VERSION.SDK_INT >= 23) {
                am.registerAudioDeviceCallback(object : android.media.AudioDeviceCallback() {
                    override fun onAudioDevicesAdded(added: Array<out android.media.AudioDeviceInfo>?) {
                        DebugLog.log("Khe $slot: [âm thanh] thiết bị THÊM: ${added?.joinToString(",") { "type" + it.type + (if (it.isSink) "(ra)" else "(vào)") } ?: "?"}")
                    }
                    override fun onAudioDevicesRemoved(removed: Array<out android.media.AudioDeviceInfo>?) {
                        DebugLog.log("Khe $slot: [âm thanh] thiết bị RÚT: ${removed?.joinToString(",") { "type" + it.type + (if (it.isSink) "(ra)" else "(vào)") } ?: "?"}")
                    }
                }, h)
            }
        } catch (e: Throwable) { DebugLog.log("Khe $slot: [âm thanh] không đăng ký được dòng thời gian: ${e.javaClass.simpleName}: ${e.message}") }
    }

    /**
     * Bản 7.112 — CHẨN ĐOÁN KHI ĐƠ MÀ KHÔNG CÓ LUỒNG QUAY VÒNG (vd log 18/11 23:30: 3 lệnh eval quá hạn ở tab claude.ai, RAM trống 4,4GB, không có lần Tải lại nên 7.94 không chụp gì).
     * Chỉ GHI LOG (không hành động): số liệu 3s của CPU mọi tiến trình/luồng, bộ nhớ (PSI/vmstat), fd, tuổi tiến trình, ngữ cảnh app, rồi thăm dò trang + `list()`.
     * Tối đa một lần / 5 phút. Chạy trên luồng canh.
     */
    private fun captureDiagnostics(ctx: Context, reason: String, now: Long) {
        lastDiagAt = now
        val cpuMark = try { GeckoHealthProbe.cpuMark(ctx) } catch (_: Throwable) { null }
        val memMark = try { MemEvidence.mark(now) } catch (_: Throwable) { null }
        DebugLog.logLong("Khe $slot: [đơ-watchdog] CHẨN ĐOÁN ĐƠ KHÔNG-QUAY-VÒNG ($reason) | ${host?.contextLine() ?: "-"} | ${GeckoHealthProbe.audioEvidence(ctx)}")
        try { Thread.sleep(3_000L) } catch (_: InterruptedException) {}
        val mem = try { MemEvidence.evidence(memMark, SystemClock.uptimeMillis()) } catch (e: Throwable) { "MemEvidence lỗi ${e.javaClass.simpleName}" }
        val sys = try { GeckoHealthProbe.stallEvidence(ctx, cpuMark) } catch (e: Throwable) { "stallEvidence lỗi ${e.javaClass.simpleName}" }
        val line = "Khe $slot: [đơ-watchdog] CHẨN ĐOÁN KHÔNG-QUAY-VÒNG số liệu 3s | $mem | $sys | ${GeckoHealthProbe.fdCensus()} | tuổi tiến trình: ${GeckoHealthProbe.processAges(ctx)}"
        DebugLog.logLong(line)
        try { java.io.File(ctx.filesDir, "last_stall_slot$slot.txt").writeText(java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + " " + line.take(9000)) } catch (_: Throwable) {}
        host?.probeResponsive(PROBE_TIMEOUT_MS) { res, tab ->
            DebugLog.log("Khe $slot: [đơ-watchdog] (chẩn đoán không-quay-vòng) thăm dò trang tab=$tab: $res")
        }
    }

    private fun tick() {
        val ctx = appCtx ?: return
        val now = SystemClock.uptimeMillis()
        val tr = tracker ?: StallLogic.HotTracker(GeckoHealthProbe.clockTick()).also { tracker = it }
        val hots = tr.feed(now, GeckoHealthProbe.selfThreadTicks(names), names)
        val v = StallLogic.classify(hots)
        hotNow = v.kind != StallLogic.Kind.NONE
        if (v.kind == StallLogic.Kind.NONE) {
            endEpisodeIfAny(now)
            // Bản 7.112: ít nhất 2 lệnh eval vào tab ĐANG XEM quá hạn trong 60s mà KHÔNG có luồng nóng => vẫn thu bằng chứng (không hành động), tối đa 1 lần/5 phút.
            if (foreground && now >= suppressUntil && now - lastDiagAt >= 300_000L && recentEvalTimeouts(now) >= 2) {
                captureDiagnostics(ctx, "${recentEvalTimeouts(now)} lệnh eval vào tab đang xem quá hạn trong 60s, chưa thấy luồng nóng", now)
            }
            return
        }
        val hot = v.hot ?: return
        lastKind = v.kind
        if (episodeStartedAt == 0L) {
            episodeStartedAt = now
            episodeId++
            probeLogs = 0
            lastProbeAt = 0L
            episodeMark = try { GeckoHealthProbe.cpuMark(ctx) } catch (_: Throwable) { null }
            respondedHotLogged = false
            softTried = false
            memMarkAtStart = try { MemEvidence.mark(now) } catch (_: Throwable) { null }
            val memNow = try { MemEvidence.evidence(null, now) } catch (e: Throwable) { "MemEvidence lỗi ${e.javaClass.simpleName}" }
            DebugLog.logLong("Khe $slot: [đơ-watchdog] BẮT ĐẦU NGHI (${v.kind}): luồng '${hot.name}' (tid ${hot.tid}) dùng ${hot.busyPct}% một nhân liên tục ${hot.streakMs / 1000}s | $memNow | ${host?.contextLine() ?: "(chưa gắn engine)"} | ${GeckoHealthProbe.audioEvidence(ctx)}")
            // Bản 7.111 — PHÁP Y để tìm gốc (không đổi hành vi): luồng quay kiểu nào, tiến trình nào mới sinh trước đó, rò fd, và những gì app vừa làm ngay trước lúc quay.
            val procs = try { GeckoHealthProbe.contentProcesses(ctx) } catch (_: Throwable) { emptyList() }
            rssAtStart = procs.associate { it.pid to it.rssKb }
            val forensic = GeckoHealthProbe.hotThreadForensics(hot.tid)   // ~0,6s trên luồng nền
            DebugLog.logLong("Khe $slot: [đơ-watchdog] PHÁP Y luồng '${hot.name}': $forensic | ${GeckoHealthProbe.fdCensus()} | tuổi tiến trình: ${GeckoHealthProbe.processAges(ctx)}")
            val noisy = Regex("bàn phím|zoom gộp|\\[RAM\\]|TaskDescription|\\[heap\\]|fp-selftest|fingerprint-spoof|ÁP LẠI giao diện|\\[geo\\]|\\[addon\\]|đơ-watchdog")
            val before = try { DebugLog.getAll().filterNot { noisy.containsMatchIn(it) }.takeLast(14).joinToString(" ¦ ") { it.take(150) } } catch (_: Throwable) { "?" }
            DebugLog.logLong("Khe $slot: [đơ-watchdog] 14 sự kiện app NGAY TRƯỚC khi nghi (cũ→mới): $before")
        }
        if (now < suppressUntil || probeInFlight || now - lastProbeAt < PROBE_EVERY_MS) return
        val h = host ?: return
        probeInFlight = true
        lastProbeAt = now
        val ep = episodeId
        val kind = v.kind
        h.probeResponsive(PROBE_TIMEOUT_MS) { res, tab ->
            try { exec?.execute { try { onProbe(ep, kind, hot, res, tab) } catch (e: Throwable) { DebugLog.log("Khe $slot: [đơ-watchdog] onProbe lỗi ${e.javaClass.simpleName}: ${e.message}") } } } catch (_: Throwable) {}
        }
    }

    private fun endEpisodeIfAny(now: Long) {
        if (episodeStartedAt == 0L) return
        val dur = (now - episodeStartedAt) / 1000
        val wasStalled = stalledSince != 0L
        DebugLog.log("Khe $slot: [đơ-watchdog] luồng đã HẾT quay sau ~${dur}s (đã xác nhận đơ=$wasStalled)")
        episodeStartedAt = 0L
        episodeMark = null
        episodeId++            // vô hiệu hoá mọi kết quả thăm dò còn đang bay của đợt cũ
        probeInFlight = false
        lastKind = StallLogic.Kind.NONE
        softTried = false
        softInProgress = false
        hotNow = false
        if (wasStalled) { stalledSince = 0L; try { host?.onStallStateChanged() } catch (_: Throwable) {} }
    }

    private fun onProbe(ep: Int, kind: StallLogic.Kind, hot: StallLogic.Hot, res: StallLogic.Probe, tab: String) {
        if (ep != episodeId || episodeStartedAt == 0L) return   // đợt đã kết thúc
        probeInFlight = false
        val now = SystemClock.uptimeMillis()
        if (probeLogs++ < 8) DebugLog.log("Khe $slot: [đơ-watchdog] thăm dò trang tab=$tab sau ${PROBE_TIMEOUT_MS / 1000}s: $res | eval quá hạn gần đây=${recentEvalTimeouts(now)} | luồng '${hot.name}' nóng ${(now - episodeStartedAt) / 1000}s")
        val action = StallLogic.decide(kind, res, recentEvalTimeouts(now))
        when (action) {
            StallLogic.Action.NONE, StallLogic.Action.PROBE -> {
                if (res == StallLogic.Probe.RESPONDED && !respondedHotLogged) {
                    respondedHotLogged = true
                    DebugLog.log("Khe $slot: [đơ-watchdog] trang TRẢ LỜI nhưng luồng '${hot.name}' vẫn quay (${(now - episodeStartedAt) / 1000}s) — trình duyệt còn dùng được nhưng hao pin/nóng máy; khởi động lại khi tiện")
                }
                if (res == StallLogic.Probe.RESPONDED && stalledSince != 0L) {
                    stalledSince = 0L
                    DebugLog.log("Khe $slot: [đơ-watchdog] trang đã TRẢ LỜI lại dù luồng còn nóng — gỡ cờ đơ")
                    try { host?.onStallStateChanged() } catch (_: Throwable) {}
                }
            }
            StallLogic.Action.AUTO_RESTART_COUNTDOWN, StallLogic.Action.OFFER_RESTART -> confirmed(kind, hot, tab, action == StallLogic.Action.AUTO_RESTART_COUNTDOWN)
        }
    }

    private fun confirmed(kind: StallLogic.Kind, hot: StallLogic.Hot, tab: String, auto: Boolean) {
        val ctx = appCtx ?: return
        val now = SystemClock.uptimeMillis()
        if (stalledSince == 0L) {
            stalledSince = now
            try { host?.onStallStateChanged() } catch (_: Throwable) {}
        }
        if (softInProgress) return   // đang giết thử từng tiến trình nội dung: chưa nhảy sang bậc 2
        if (now < suppressUntil || now - lastActionAt < ACTION_COOLDOWN_MS) return
        lastActionAt = now
        val procsNow = try { GeckoHealthProbe.contentProcesses(ctx) } catch (_: Throwable) { emptyList() }
        val victims = StallLogic.rankVictims(rssAtStart, procsNow)
        val softOn = try { AppPrefs.getBoolean(ctx, slot, "stall_soft_first", true) } catch (_: Throwable) { true }
        val stage = if (!softTried && softOn && victims.isNotEmpty()) 1 else 2
        val growth = victims.joinToString(", ") { "${it.label}(pid=${it.pid}) rss=${it.rssKb / 1024}MB(Δ${(it.rssKb - (rssAtStart[it.pid] ?: it.rssKb)) / 1024}MB)" }
        val sys = try { GeckoHealthProbe.stallEvidence(ctx, episodeMark) } catch (e: Throwable) { "stallEvidence lỗi ${e.javaClass.simpleName}: ${e.message}" }
        val memDelta = try { MemEvidence.evidence(memMarkAtStart, SystemClock.uptimeMillis()) } catch (e: Throwable) { "MemEvidence lỗi ${e.javaClass.simpleName}" }
        val line = "Khe $slot: [đơ-watchdog] XÁC NHẬN ĐƠ ($kind): luồng '${hot.name}' (tid ${hot.tid}) ${hot.busyPct}% một nhân suốt ${hot.streakMs / 1000}s, trang tab=$tab không trả lời thăm dò | " +
            "bậc=$stage | $memDelta | tiến trình nội dung (thứ tự giết thử): [$growth] | $sys | ${host?.contextLine() ?: "-"} | ${GeckoHealthProbe.audioEvidence(ctx)}"
        DebugLog.logLong(line)
        // Cùng tệp với dòng [CHẨN ĐOÁN ĐƠ] của 7.106: LiveBrowserApp in lại ở đầu lần chạy sau (nhật ký chung chỉ còn phần đuôi).
        try { java.io.File(ctx.filesDir, "last_stall_slot$slot.txt").writeText(java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + " " + line.take(9000)) } catch (_: Throwable) {}
        val headline = if (kind == StallLogic.Kind.AUDIO_RUNAWAY)
            "luồng âm thanh của trình duyệt (AudioIPC Server) đang quay vòng ${hot.busyPct}% CPU"
        else "luồng '${hot.name}' của trình duyệt đang quay vòng ${hot.busyPct}% CPU"
        try { host?.onRunaway(kind, auto, headline, line, stage, victims) } catch (e: Throwable) { DebugLog.log("Khe $slot: [đơ-watchdog] host.onRunaway lỗi ${e.javaClass.simpleName}: ${e.message}") }
    }
}
