package com.colablive.keeper.features.ebookleech.backup

import android.content.Context
import android.os.Environment
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpoint
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpointRepository
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.model.LeechJobRepository
import com.colablive.keeper.features.ebookleech.model.LeechProject
import com.colablive.keeper.features.ebookleech.model.LeechProjectRepository
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * EbookLeechBackupManager — xuất/nhập TOÀN BỘ cấu hình EbookLeech (dự án +
 * job, kể cả regex rules, kịch bản nhiều bước, mục lục đã sắp...) VÀ trạng
 * thái crawl đang dở (checkpoint) ra 1 file JSON — giống "Export/Import
 * Settings" của KDN Auto Leech, để chuyển qua máy khác / khôi phục sau khi
 * gỡ cài đặt mà KHÔNG mất tiến độ đang cào dở.
 *
 * ĐÃ ĐỔI QUYẾT ĐỊNH so với bản đầu (lúc đó chủ động KHÔNG backup trạng thái
 * runtime): người dùng yêu cầu rõ ràng phải backup được cả "trạng thái chạy"
 * — vì vậy job nào ĐANG CÓ checkpoint (đang cào dở/đang chờ giải xác minh)
 * sẽ backup NGUYÊN TRẠNG (status RUNNING/NEEDS_ACTION + checkpoint đi kèm),
 * KHÔNG reset về IDLE nữa. Job KHÔNG có checkpoint (đã xong/lỗi/chưa chạy
 * lần nào) vẫn reset các trường phiên làm việc như cũ — không có gì để giữ.
 */
object EbookLeechBackupManager {

    private const val BACKUP_FORMAT_VERSION = 2  // tăng version vì thêm checkpoints — file backup bản 1 (không có checkpoints) vẫn đọc được nhờ optJSONArray trả rỗng

    /** @return đường dẫn file backup đã tạo */
    fun exportToFile(context: Context, slotIndex: Int): String {
        val projects = LeechProjectRepository.loadAll(context, slotIndex)
        val jobs = LeechJobRepository.loadAll(context, slotIndex)

        val checkpointsJson = JSONArray()
        val sanitizedJobs = jobs.map { job ->
            val checkpoint = CrawlCheckpointRepository.load(context, slotIndex, job.id)
            if (checkpoint != null) {
                // ĐÃ SỬA — trước đây `checkpoint.toJson()` KHÔNG kèm bytes
                // ảnh (đúng thiết kế cho checkpoint TỰ ĐỘNG, tránh phình to
                // liên tục) — nhưng "Sao lưu" là hành động THỦ CÔNG, có chủ
                // đích của người dùng, kích thước lớn hơn 1 chút vì có ảnh
                // là hợp lý, đổi lại backup ĐẦY ĐỦ 100% (không mất ảnh nếu
                // phải khôi phục trên máy khác/sau khi mất app).
                checkpointsJson.put(checkpointToBackupJsonWithImages(context, slotIndex, checkpoint))
                job  // GIỮ NGUYÊN status/tiến độ — có checkpoint đi kèm để khôi phục đúng
            } else {
                sanitizeForBackup(job)
            }
        }

        val root = JSONObject().apply {
            put("formatVersion", BACKUP_FORMAT_VERSION)
            put("exportedAt", System.currentTimeMillis())
            put("projects", LeechProject.listToJson(projects))
            put("jobs", LeechJob.listToJson(sanitizedJobs))
            put("checkpoints", checkpointsJson)
        }

        val outDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "EbookLeech/Backup"
        )
        if (!outDir.exists()) outDir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outFile = File(outDir, "ebookleech_backup_$stamp.json")
        outFile.writeText(root.toString(2), Charsets.UTF_8)
        return outFile.absolutePath
    }

    /** ĐÃ THÊM — bọc `checkpoint.toJson()`, nhúng thêm bytes ảnh (base64)
     * vào từng `images[]` entry — CHỈ dùng cho backup thủ công (xem lý do
     * trong `exportToFile()`), KHÔNG dùng cho checkpoint tự động thường
     * ngày (`CrawlCheckpointRepository`/`RemoteCrawlRunner` vẫn giữ nguyên
     * quy ước không nhúng bytes vào JSON — đúng cho mục đích đó). */
    private fun checkpointToBackupJsonWithImages(context: Context, slotIndex: Int, checkpoint: CrawlCheckpoint): JSONObject {
        val cpJson = checkpoint.toJson()
        val chaptersArr = cpJson.optJSONArray("chaptersSoFar") ?: return cpJson
        for (i in 0 until chaptersArr.length()) {
            val chapterJson = chaptersArr.getJSONObject(i)
            val imagesArr = chapterJson.optJSONArray("images") ?: continue
            for (j in 0 until imagesArr.length()) {
                val imgJson = imagesArr.getJSONObject(j)
                val localFileName = imgJson.optString("localFileName", "")
                if (localFileName.isEmpty()) continue
                val bytes = CrawlCheckpointRepository.loadImageBytes(context, slotIndex, checkpoint.jobId, localFileName)
                if (bytes != null) {
                    imgJson.put("bytesBase64", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))
                }
                // bytes == null (file ảnh mất/lỗi cục bộ) → bỏ qua đúng ảnh
                // đó, không chặn cả backup — giống mọi chỗ khác trong hệ
                // thống này coi 1 ảnh lỗi là chấp nhận được.
            }
        }
        return cpJson
    }

    /** ĐÃ THÊM — ngược lại hàm trên: ghi bytes ảnh (nếu backup có) ra đúng
     * vị trí cục bộ TRƯỚC KHI parse checkpoint — để `CrawlCheckpoint.fromJson()`
     * (gọi ngay sau, dùng `imageLoader` đọc từ đúng chỗ này) khôi phục được
     * ảnh đầy đủ thay vì rỗng. */
    private fun restoreImagesFromBackupJson(context: Context, slotIndex: Int, jobId: String, checkpointJson: JSONObject) {
        val chaptersArr = checkpointJson.optJSONArray("chaptersSoFar") ?: return
        for (i in 0 until chaptersArr.length()) {
            val imagesArr = chaptersArr.getJSONObject(i).optJSONArray("images") ?: continue
            for (j in 0 until imagesArr.length()) {
                val imgJson = imagesArr.getJSONObject(j)
                val localFileName = imgJson.optString("localFileName", "")
                val b64 = imgJson.optString("bytesBase64", "")
                if (localFileName.isEmpty() || b64.isEmpty()) continue
                try {
                    val bytes = android.util.Base64.decode(b64, android.util.Base64.NO_WRAP)
                    CrawlCheckpointRepository.saveImageBytesIfMissing(context, slotIndex, jobId, localFileName, bytes)
                } catch (e: Exception) { /* 1 ảnh lỗi giải mã không chặn khôi phục phần còn lại */ }
            }
        }
    }

    /** Job KHÔNG có checkpoint — không có tiến độ đang dở nào đáng giữ, reset sạch. */
    private fun sanitizeForBackup(job: LeechJob): LeechJob = job.copy(
        status = LeechJob.JobStatus.IDLE,
        chaptersCollected = 0,
        lastRunAt = 0L,
        outputFilePath = "",
        detectedAjaxEndpoints = emptyList(),
        pendingActionUrl = "",
        pendingActionReason = "",
        // resolvedPaginationPattern GIỮ LẠI — kết quả dò được, hữu ích để
        // khôi phục không phải dò lại từ đầu; không phải trạng thái phiên.
    )

    /**
     * @param mode REPLACE = xoá hết cấu hình + checkpoint hiện tại rồi nạp
     *             từ file. MERGE = giữ job/dự án/checkpoint hiện có, chỉ
     *             thêm job/dự án CHƯA tồn tại (checkpoint chỉ ghi cho job
     *             MỚI thêm — không đè checkpoint của job đã có sẵn tại chỗ,
     *             tránh mất tiến độ đang cào dở tại máy hiện tại).
     */
    fun importFromFile(context: Context, slotIndex: Int, filePath: String, mode: ImportMode): ImportResult {
        val file = File(filePath)
        if (!file.exists()) return ImportResult(0, 0, "File không tồn tại: $filePath")

        val root = try {
            JSONObject(file.readText(Charsets.UTF_8))
        } catch (e: Exception) {
            return ImportResult(0, 0, "File backup không hợp lệ: ${e.message}")
        }

        val version = root.optInt("formatVersion", 0)
        if (version > BACKUP_FORMAT_VERSION) {
            return ImportResult(0, 0, "File backup từ bản addon MỚI HƠN ($version) — cập nhật addon trước khi khôi phục")
        }

        val importedProjects = root.optJSONArray("projects")?.let { LeechProject.listFromJson(it) } ?: emptyList()
        val importedJobs = root.optJSONArray("jobs")?.let { LeechJob.listFromJson(it) } ?: emptyList()
        // ĐÃ SỬA — trước đây parse thẳng `CrawlCheckpoint.fromJson(json)`
        // với imageLoader mặc định `{ null }` → ảnh trong backup (nếu bản
        // backup mới có nhúng, xem checkpointToBackupJsonWithImages()) BỊ
        // BỎ QUA hoàn toàn dù đã có trong file. Giờ: ghi bytes ra đĩa
        // TRƯỚC (restoreImagesFromBackupJson), rồi parse VỚI imageLoader
        // đọc đúng từ chỗ vừa ghi.
        val importedCheckpointsRaw = root.optJSONArray("checkpoints")
        val importedCheckpoints = importedCheckpointsRaw?.let { arr ->
            (0 until arr.length()).map { i ->
                val cpJson = arr.getJSONObject(i)
                val jobId = cpJson.optString("jobId", "")
                if (jobId.isNotEmpty()) restoreImagesFromBackupJson(context, slotIndex, jobId, cpJson)
                CrawlCheckpoint.fromJson(cpJson) { localFileName ->
                    CrawlCheckpointRepository.loadImageBytes(context, slotIndex, jobId, localFileName)
                }
            }
        } ?: emptyList()
        val checkpointByJobId = importedCheckpoints.associateBy { it.jobId }

        when (mode) {
            ImportMode.REPLACE -> {
                LeechProjectRepository.save(context, slotIndex, importedProjects)
                LeechJobRepository.save(context, slotIndex, importedJobs)
                // Xoá checkpoint cũ (nếu có) trước khi nạp bộ mới — REPLACE
                // nghĩa là "y hệt file backup", không giữ gì từ trước.
                CrawlCheckpointRepository.listJobIdsWithCheckpoint(context, slotIndex).forEach {
                    CrawlCheckpointRepository.delete(context, slotIndex, it)
                }
                importedJobs.forEach { job ->
                    checkpointByJobId[job.id]?.let { cp -> CrawlCheckpointRepository.save(context, slotIndex, cp) }
                }
            }
            ImportMode.MERGE -> {
                val existingProjects = LeechProjectRepository.loadAll(context, slotIndex)
                val existingProjectIds = existingProjects.map { it.id }.toSet()
                val mergedProjects = existingProjects + importedProjects.filter { it.id !in existingProjectIds }
                LeechProjectRepository.save(context, slotIndex, mergedProjects)

                val existingJobs = LeechJobRepository.loadAll(context, slotIndex)
                val existingJobIds = existingJobs.map { it.id }.toSet()
                val newJobs = importedJobs.filter { it.id !in existingJobIds }
                LeechJobRepository.save(context, slotIndex, existingJobs + newJobs)
                // Chỉ ghi checkpoint cho job THẬT SỰ MỚI — job đã tồn tại
                // sẵn ở máy này giữ nguyên checkpoint local, không bị đè.
                newJobs.forEach { job ->
                    checkpointByJobId[job.id]?.let { cp -> CrawlCheckpointRepository.save(context, slotIndex, cp) }
                }
            }
        }

        return ImportResult(importedJobs.size, importedProjects.size, null)
    }

    enum class ImportMode { REPLACE, MERGE }
    data class ImportResult(val jobCount: Int, val projectCount: Int, val error: String?)
}
