package com.colablive.keeper.core

/**
 * Bản 7.106 — CỔNG MẠNG TAB KHÔNG XEM (phía app). Phần giữ yêu cầu nằm ở addon `fingerprint_spoof/background.js` (webRequest.onBeforeRequest chặn bất đồng bộ).
 *
 * Yêu cầu của người dùng: tab KHÔNG đang xem và KHÔNG được bật chạy nền thì không được tự nạp trang / kết nối mạng (kể cả khi mạng máy đổi).
 * Tra cứu (Mozilla): `GeckoSession.setActive(false)` chỉ hạ ưu tiên tiến trình + bóp hẹn giờ/vẽ; Gecko KHÔNG khoá mạng của tab đó (bug "sleeping tabs" 1545701 chỉ bàn bóp timer/rAF;
 * bug 1815015: tab mở nền chưa từng xem còn mặc định "active"). Nên app tự làm: yêu cầu MỚI của tab không xem bị GIỮ ở tầng webRequest cho tới khi tab được xem — trang vẫn sống nguyên trạng
 * (khác với "xả tab theo giờ" ở 7.72/7.89 làm tab bị tải lại).
 *
 * Phía app chỉ quyết định (1) cổng bật hay tắt, (2) danh sách MIỀN được miễn (không được giữ) — vì GeckoView không cho app biết tabId số của một GeckoSession nên không miễn theo tab được,
 * giống cách danh sách "ghim chạy nền" đã làm theo tên miền; (3) thời gian ân hạn sau khi rời tab. Tập hợp dưới đây là hàm thuần để kiểm bằng JVM.
 */
object BgNetGate {
    const val DEFAULT_GRACE_S = 30
    const val PREF_ON = "bg_net_gate"
    const val PREF_GRACE_S = "bg_net_gate_grace_s"
    /** Chờ addon báo nhận sự kiện tabs.onActivated sau mỗi lần app gọi setTabActive; quá hạn => TẮT cổng (fail-open) vì không biết tab nào đang xem. */
    const val ACK_TIMEOUT_MS = 4000L

    /** Một tab của app, rút gọn những gì cổng cần biết. [loaded] = đang có GeckoSession thật. */
    class TabItem(
        @JvmField val url: String,
        @JvmField val loaded: Boolean,
        @JvmField val keepPinned: Boolean,        // miền thuộc danh sách "ghim chạy nền" của người dùng
        @JvmField val keepColab: Boolean,         // Colab (mục đích của app)
        @JvmField val mediaForeground: Boolean,   // tab giữ MediaSession đang phát khi app ĐANG MỞ (app ra nền thì media không phải lý do giữ — đúng yêu cầu cũ ở mục 158)
        @JvmField val uploadGrace: Boolean,       // vừa đưa file cho trang này (có thể đang tải lên, giữ tối đa 30 phút — xem UPLOAD_GRACE_MS)
        @JvmField val autoBehavior: Boolean,      // Auto Behavior / Colab Live đang chạy trên tab này
    ) {
        fun keepReason(): String? = when {
            keepPinned -> "ghim chạy nền"
            keepColab -> "Colab"
            uploadGrace -> "vừa đưa file (có thể đang tải lên)"
            autoBehavior -> "Auto Behavior/Colab Live"
            mediaForeground -> "đang phát media (app đang mở)"
            else -> null
        }
    }

    /** Tên miền thường (chữ thường) của URL http/https; "" nếu không phải hoặc hỏng. */
    fun hostOf(url: String): String {
        val u = url.trim()
        val scheme = when {
            u.startsWith("https://", true) -> 8
            u.startsWith("http://", true) -> 7
            else -> return ""
        }
        var end = u.length
        for (i in scheme until u.length) { val c = u[i]; if (c == '/' || c == '?' || c == '#') { end = i; break } }
        var h = u.substring(scheme, end)
        val at = h.lastIndexOf('@'); if (at >= 0) h = h.substring(at + 1)
        if (h.startsWith("[")) return ""            // IPv6 literal: không miễn theo miền
        val colon = h.indexOf(':'); if (colon >= 0) h = h.substring(0, colon)
        h = h.trim().trimEnd('.').lowercase()
        return if (h.isNotEmpty() && h.all { it.isLetterOrDigit() || it == '.' || it == '-' } && h.all { it.code < 128 }) h else ""
    }

    /** Danh sách miền được miễn (đã loại trùng, sắp xếp ổn định để so chữ ký). Chỉ lấy tab ĐÃ TẢI có ít nhất một lý do giữ. */
    fun exemptHosts(tabs: List<TabItem>): List<String> =
        tabs.asSequence().filter { it.loaded && it.keepReason() != null }.map { hostOf(it.url) }.filter { it.isNotEmpty() }.distinct().sorted().toList()

    /** Chữ ký trạng thái đã gửi — giống chữ ký thì không gửi lại (tránh ồn log và tin thừa). */
    fun signature(on: Boolean, graceMs: Long, exempt: List<String>): String = "${if (on) 1 else 0}|$graceMs|${exempt.joinToString(",")}"

    /** Ân hạn tính bằng mili giây từ pref giây; ngoài 0..600 thì dùng mặc định. */
    fun graceMs(prefSeconds: Int): Long = (if (prefSeconds in 0..600) prefSeconds else DEFAULT_GRACE_S) * 1000L

    /** Lần gọi setTabActive tại [callAtMs] chưa được addon báo nhận (gate_viewed) mà đã quá [timeoutMs]? */
    fun ackOverdue(callAtMs: Long, lastAckAtMs: Long, nowMs: Long, timeoutMs: Long = ACK_TIMEOUT_MS): Boolean =
        callAtMs > 0L && nowMs - callAtMs >= timeoutMs && lastAckAtMs < callAtMs

    /** Có nên BẬT cổng không: công tắc người dùng bật và chốt an toàn (watchdog) chưa ngắt. */
    fun wanted(prefOn: Boolean, watchdogTripped: Boolean): Boolean = prefOn && !watchdogTripped
}
