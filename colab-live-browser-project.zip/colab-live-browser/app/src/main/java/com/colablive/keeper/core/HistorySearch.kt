package com.colablive.keeper.core

import java.net.URI
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Tìm kiếm nâng cao trong lịch sử duyệt web (mục 107). Logic thuần (không dính Android UI) để dễ kiểm chứng.
 *
 * Cú pháp ô tìm kiếm (các thành phần cách nhau bằng dấu cách, TẤT CẢ phải khớp = AND):
 *   từ khoá            khớp trong tiêu đề hoặc URL (không phân biệt hoa/thường VÀ không phân biệt dấu: "mat khau" khớp "Mật khẩu")
 *   "cụm từ chính xác" khớp nguyên cụm
 *   -từ  hoặc  -"cụm"  loại trừ mọi mục có từ/cụm đó
 *   site:example.com   chỉ trang thuộc miền đó (kể cả miền con); nhiều site: là HOẶC; -site:x loại trừ miền
 *   title:abc  url:abc chỉ tìm trong tiêu đề / trong URL; -title:abc, -url:abc là loại trừ
 *   after:2026-09-01  before:2026-09-30   (yyyy-MM-dd hoặc dd-MM-yyyy; before là TRƯỚC ngày đó)
 *   last:24h | last:7d | last:2w | last:3m   trong khoảng thời gian gần đây (h giờ, d ngày, w tuần, m tháng=30 ngày)
 */
object HistorySearch {
    enum class Scope(val label: String) { BOTH("Tiêu đề + URL"), TITLE("Chỉ tiêu đề"), URL("Chỉ URL") }
    enum class Sort(val label: String) { NEWEST("Mới nhất"), OLDEST("Cũ nhất"), MOST_VISITED("Nhiều lượt nhất") }
    enum class Range(val label: String) { ALL("Mọi lúc"), TODAY("Hôm nay"), DAYS7("7 ngày"), DAYS30("30 ngày") }

    class Query(
        val include: List<String>,
        val exclude: List<String>,
        val sites: List<String>,
        val notSites: List<String>,
        val titleTerms: List<String>,
        val titleNo: List<String>,
        val urlTerms: List<String>,
        val urlNo: List<String>,
        val after: Long?,
        val before: Long?
    ) {
        val isEmpty: Boolean get() =
            include.isEmpty() && exclude.isEmpty() && sites.isEmpty() && notSites.isEmpty() && titleTerms.isEmpty() &&
                titleNo.isEmpty() && urlTerms.isEmpty() && urlNo.isEmpty() && after == null && before == null
        /** Các từ cần tô sáng trong kết quả (đã chuẩn hoá). */
        val highlightTerms: List<String> get() = include + titleTerms + urlTerms
    }

    data class Row(val entry: BrowserHistory.Entry, val count: Int)
    data class Result(val rows: List<Row>, val visitsMatched: Int, val query: Query, val matchedKeys: List<Pair<String, Long>>)

    // ------------------------------------------------------------------ chuẩn hoá (bỏ dấu, thường hoá)
    /** Chuỗi đã chuẩn hoá + bảng ánh xạ chỉ số chuẩn hoá -> chỉ số trong chuỗi gốc (để tô sáng đúng chỗ). */
    fun foldWithMap(s: String): Pair<String, IntArray> {
        val sb = StringBuilder()
        val map = ArrayList<Int>()
        for (i in s.indices) {
            val c = s[i]
            val lower = c.lowercaseChar()
            val d = Normalizer.normalize(lower.toString(), Normalizer.Form.NFD)
            for (ch in d) {
                if (Character.getType(ch) == Character.NON_SPACING_MARK.toInt()) continue
                sb.append(if (ch == 'đ') 'd' else ch)
                map.add(i)
            }
        }
        return sb.toString() to map.toIntArray()
    }

    fun fold(s: String): String = foldWithMap(s).first

    // ------------------------------------------------------------------ phân tích cú pháp
    private val tokenRe = Regex("""(-?)(?:([A-Za-z]+):)?(?:"([^"]*)"|(\S+))""")
    private val knownOps = setOf("site", "title", "url", "after", "before", "last")

    /**
     * Chọn mẫu theo HÌNH DẠNG chuỗi trước khi phân tích: SimpleDateFormat("yyyy-MM-dd") dù không lenient vẫn nhận năm 1 chữ số, nên
     * "01-10-2026" sẽ bị hiểu thành 20/10/0001 thay vì rơi sang mẫu dd-MM-yyyy.
     */
    private fun parseDate(raw: String): Long? {
        val s = raw.trim().replace('/', '-')
        val pattern = when {
            Regex("^\\d{4}-\\d{1,2}-\\d{1,2}$").matches(s) -> "yyyy-M-d"
            Regex("^\\d{1,2}-\\d{1,2}-\\d{4}$").matches(s) -> "d-M-yyyy"
            else -> return null
        }
        return try {
            val f = SimpleDateFormat(pattern, Locale.US)
            f.isLenient = false
            f.parse(s)?.time
        } catch (e: Exception) { null }
    }

    private fun parseLast(raw: String, now: Long): Long? {
        val m = Regex("^(\\d+)([hdwm])$").find(raw.trim().lowercase()) ?: return null
        val n = m.groupValues[1].toLongOrNull() ?: return null
        val unitMs = when (m.groupValues[2]) {
            "h" -> 3_600_000L
            "d" -> 86_400_000L
            "w" -> 7 * 86_400_000L
            else -> 30 * 86_400_000L
        }
        return now - n * unitMs
    }

    private fun normHost(h: String) = h.trim().lowercase().removePrefix("www.")

    fun parse(raw: String, now: Long = System.currentTimeMillis()): Query {
        val include = ArrayList<String>(); val exclude = ArrayList<String>()
        val sites = ArrayList<String>(); val notSites = ArrayList<String>()
        val titleTerms = ArrayList<String>(); val titleNo = ArrayList<String>()
        val urlTerms = ArrayList<String>(); val urlNo = ArrayList<String>()
        var after: Long? = null; var before: Long? = null
        for (m in tokenRe.findAll(raw)) {
            val neg = m.groupValues[1] == "-"
            var op = m.groupValues[2].lowercase()
            var value = if (m.groups[3] != null) m.groupValues[3] else m.groupValues[4]
            // "http://x" không phải toán tử: tiền tố lạ => coi cả "tiền tố:giá trị" là một từ thường.
            if (op.isNotEmpty() && op !in knownOps) { value = m.groupValues[2] + ":" + value; op = "" }
            value = value.trim()
            if (value.isEmpty()) continue
            when (op) {
                "site" -> if (neg) notSites.add(normHost(value)) else sites.add(normHost(value))
                "title" -> if (neg) titleNo.add(fold(value)) else titleTerms.add(fold(value))
                "url" -> if (neg) urlNo.add(fold(value)) else urlTerms.add(fold(value))
                "after" -> parseDate(value)?.let { after = maxOf(after ?: it, it) }
                "before" -> parseDate(value)?.let { before = minOf(before ?: it, it) }
                "last" -> parseLast(value, now)?.let { after = maxOf(after ?: it, it) }
                else -> if (neg) exclude.add(fold(value)) else include.add(fold(value))
            }
        }
        return Query(include, exclude, sites, notSites, titleTerms, titleNo, urlTerms, urlNo, after, before)
    }

    // ------------------------------------------------------------------ so khớp
    private fun hostOf(url: String): String? = try { URI(url).host?.let { normHost(it) } } catch (e: Exception) { null }

    private fun siteMatches(host: String?, site: String): Boolean =
        host != null && (host == site || host.endsWith(".$site"))

    fun matches(q: Query, scope: Scope, e: BrowserHistory.Entry): Boolean {
        if (q.after != null && e.time < q.after) return false
        if (q.before != null && e.time >= q.before) return false
        val t = fold(e.title)
        val u = fold(e.url)
        val hay = when (scope) { Scope.BOTH -> "$t\n$u"; Scope.TITLE -> t; Scope.URL -> u }
        if (!q.include.all { hay.contains(it) }) return false
        val both = "$t\n$u" // loại trừ luôn xét CẢ tiêu đề lẫn URL, không phụ thuộc phạm vi
        if (q.exclude.any { both.contains(it) }) return false
        if (!q.titleTerms.all { t.contains(it) } || q.titleNo.any { t.contains(it) }) return false
        if (!q.urlTerms.all { u.contains(it) } || q.urlNo.any { u.contains(it) }) return false
        if (q.sites.isNotEmpty() || q.notSites.isNotEmpty()) {
            val host = hostOf(e.url)
            if (q.sites.isNotEmpty() && q.sites.none { siteMatches(host, it) }) return false
            if (q.notSites.any { siteMatches(host, it) }) return false
        }
        return true
    }

    // ------------------------------------------------------------------ khoảng thời gian + tìm + sắp xếp
    private fun rangeStart(range: Range, now: Long): Long? = when (range) {
        Range.ALL -> null
        Range.TODAY -> Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        Range.DAYS7 -> now - 7 * 86_400_000L
        Range.DAYS30 -> now - 30 * 86_400_000L
    }

    /** `all` phải sắp MỚI NHẤT TRƯỚC (đúng như BrowserHistory.readEntries trả về). */
    fun search(all: List<BrowserHistory.Entry>, raw: String, scope: Scope, range: Range, sort: Sort,
               now: Long = System.currentTimeMillis()): Result {
        val q0 = parse(raw, now)
        val rs = rangeStart(range, now)
        // gộp mốc "từ" của bộ lọc thời gian với after:/last: trong câu truy vấn (lấy mốc muộn hơn)
        val q = if (rs == null) q0 else Query(q0.include, q0.exclude, q0.sites, q0.notSites, q0.titleTerms, q0.titleNo,
            q0.urlTerms, q0.urlNo, maxOf(q0.after ?: rs, rs), q0.before)
        val matched = all.filter { matches(q, scope, it) }
        val rows: List<Row> = when (sort) {
            Sort.NEWEST -> matched.map { Row(it, 1) }
            Sort.OLDEST -> matched.reversed().map { Row(it, 1) }
            Sort.MOST_VISITED -> {
                val counts = LinkedHashMap<String, Int>()
                val latest = LinkedHashMap<String, BrowserHistory.Entry>()
                for (e in matched) { counts[e.url] = (counts[e.url] ?: 0) + 1; if (!latest.containsKey(e.url)) latest[e.url] = e }
                latest.values.map { Row(it, counts[it.url] ?: 1) }.sortedByDescending { it.count }
            }
        }
        return Result(rows, matched.size, q, matched.map { it.url to it.time })
    }

    /** Các đoạn [start, end) trong `text` GỐC cần tô sáng cho `terms` (đã chuẩn hoá bằng `fold`). */
    fun highlightRanges(text: String, terms: List<String>): List<IntRange> {
        if (terms.isEmpty() || text.isEmpty()) return emptyList()
        val (folded, map) = foldWithMap(text)
        val out = ArrayList<IntRange>()
        for (term in terms) {
            if (term.isEmpty()) continue
            var from = 0
            while (true) {
                val idx = folded.indexOf(term, from)
                if (idx < 0) break
                val end = idx + term.length
                val s = map[idx]
                val e = (if (end - 1 < map.size) map[end - 1] else text.length - 1) + 1
                out.add(s until e)
                from = end
            }
        }
        return out
    }

    /** Miền (bỏ www.) để gộp theo trang; không lấy được thì trả "(khác)". */
    fun siteOf(url: String): String = hostOf(url) ?: "(khác)"
}
