package com.colablive.keeper.features.ebookleech.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * SitePreset — bộ selector CSS đã lưu sẵn cho 1 KIỂU site (không phải 1
 * truyện cụ thể) — dùng để tạo job MỚI nhanh hơn khi cào nhiều truyện
 * KHÁC NHAU nhưng CÙNG 1 site (selector thường giống hệt nhau giữa các
 * truyện trên cùng 1 site, vì cùng 1 theme/CMS).
 *
 * ═══════════════════════════════════════════════════════════════════════
 * KHÁC "Sao lưu/Khôi phục" (EbookLeechBackupManager) THẾ NÀO — dễ nhầm:
 *
 * - Sao lưu/Khôi phục: xuất/nhập TOÀN BỘ job CỦA CHÍNH BẠN đã cấu hình
 *   xong (tên, URL truyện cụ thể, selector, lịch chạy, checkpoint...) —
 *   dùng để CHUYỂN MÁY hoặc làm bản phòng hờ. Job trong đó đã SẴN SÀNG
 *   CHẠY NGAY, gắn với 1 TRUYỆN CỤ THỂ.
 *
 * - Preset site: CHỈ lưu 4-5 selector CSS (không có URL, không có tên
 *   job, không chạy được) — dùng làm ĐIỂM BẮT ĐẦU khi TẠO JOB MỚI cho 1
 *   truyện KHÁC trên CÙNG site đó, đỡ phải tự soi lại HTML tìm selector
 *   từ đầu. Không phải bản sao lưu — không có gì để "khôi phục", chỉ có
 *   "áp dụng" vào 1 job đang tạo.
 * ═══════════════════════════════════════════════════════════════════════
 */
data class SitePreset(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val listPageUrlPattern: String = "",
    val chapterLinkSelector: String,
    val chapterLinkAttribute: String = "href",
    val chapterTitleSelector: String,
    val chapterContentSelector: String,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("listPageUrlPattern", listPageUrlPattern)
        put("chapterLinkSelector", chapterLinkSelector)
        put("chapterLinkAttribute", chapterLinkAttribute)
        put("chapterTitleSelector", chapterTitleSelector)
        put("chapterContentSelector", chapterContentSelector)
    }

    companion object {
        fun fromJson(json: JSONObject) = SitePreset(
            id = json.optString("id", UUID.randomUUID().toString()),
            name = json.optString("name", "Preset"),
            listPageUrlPattern = json.optString("listPageUrlPattern", ""),
            chapterLinkSelector = json.optString("chapterLinkSelector", ""),
            chapterLinkAttribute = json.optString("chapterLinkAttribute", "href"),
            chapterTitleSelector = json.optString("chapterTitleSelector", ""),
            chapterContentSelector = json.optString("chapterContentSelector", ""),
        )

        fun listFromJson(arr: JSONArray): List<SitePreset> =
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }

        fun listToJson(list: List<SitePreset>): JSONArray =
            JSONArray().also { arr -> list.forEach { arr.put(it.toJson()) } }
    }
}
