package com.colablive.keeper.features.ebookleech.export

import com.colablive.keeper.features.ebookleech.model.LeechChapter
import com.colablive.keeper.features.ebookleech.model.LeechImage
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.model.StoryMeta
import com.colablive.keeper.features.ebookleech.model.TocNode
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Bản 7.104 — dựng file xuất ra THƯ MỤC TẠM (staging) cho cả ba định dạng, KHÔNG đụng Android (chỉ `java.io`), để kiểm được trên JVM (xem tools/ebookleech_sim).
 * [EbookExporter] gọi hàm này rồi mới chép cây thư mục tạm sang `Downloads/EbookLeech/...` (MediaStore).
 *
 * Mỗi lần xuất tạo: file chính (EPUB/TXT/HTML) + (nếu `job.storySidecar`) `<tên>.story.json` + `<tên>.cover.<đuôi>` nếu có bìa. Tên file phụ dùng đúng phần tên của file chính nên cặp
 * file luôn đi cùng nhau (kể cả chế độ ghi đè `updateExistingFile` dùng tên cố định).
 */
object EbookStaging {

    class Staged(val mainFile: File, val mainMime: String)

    fun stage(
        job: LeechJob, chapters: List<LeechChapter>, toc: List<TocNode>, story: StoryMeta, cover: LeechImage?,
        outDir: File, nowMs: Long, generator: String,
    ): Staged {
        outDir.mkdirs()
        val (main, mime) = when (job.outputFormat) {
            LeechJob.OutputFormat.EPUB -> stageEpub(job, chapters, toc, story, cover, outDir, nowMs) to "application/epub+zip"
            LeechJob.OutputFormat.TXT -> stageTxt(job, chapters, toc, story, outDir, nowMs) to "text/plain"
            LeechJob.OutputFormat.HTML -> stageHtml(job, chapters, toc, story, cover, outDir, nowMs) to "text/html"
        }
        if (job.storySidecar) {
            val base = main.name.substringBeforeLast('.')
            val coverName = if (cover != null) "$base.cover.${coverExtension(cover)}" else ""
            if (cover != null) File(outDir, coverName).writeBytes(cover.bytes)
            File(outDir, "$base.story.json").writeText(EbookMarkup.sidecarJson(job, story, chapters, main.name, coverName, nowMs, generator), Charsets.UTF_8)
        }
        return Staged(main, mime)
    }

    private fun coverExtension(cover: LeechImage): String {
        val ext = cover.localFileName.substringAfterLast('.', "").lowercase()
        return if (ext in listOf("jpg", "jpeg", "png", "webp", "gif")) ext else "jpg"
    }

    // ----------------------------------------------------------------- EPUB ----

    private fun stageEpub(job: LeechJob, chapters: List<LeechChapter>, toc: List<TocNode>, story: StoryMeta, cover: LeechImage?, outDir: File, nowMs: Long): File {
        val outFile = File(outDir, buildFileName(job, "epub", nowMs))
        FileOutputStream(outFile).use { EbookMarkup.writeEpub(it, EbookMarkup.epubEntries(job, chapters, toc, story, cover, nowMs)) }
        return outFile
    }

    // ------------------------------------------------------------------ TXT ----

    private fun stageTxt(job: LeechJob, chapters: List<LeechChapter>, toc: List<TocNode>, story: StoryMeta, outDir: File, nowMs: Long): File {
        val outFile = File(outDir, buildFileName(job, "txt", nowMs))
        val byIndex = chapters.associateBy { it.index }
        outFile.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write(EbookMarkup.txtHeader(job, story))
            writeTxtNodes(w, toc, byIndex, depth = 0)
        }
        return outFile
    }

    private fun writeTxtNodes(w: BufferedWriter, nodes: List<TocNode>, byIndex: Map<Int, LeechChapter>, depth: Int) {
        nodes.forEach { node ->
            if (node.chapterIndex != null) {
                val ch = byIndex[node.chapterIndex] ?: return@forEach
                w.write("${node.label}\n")
                w.write("-".repeat(40) + "\n")
                w.write(ch.textContent)
                w.write("\n\n\n")
            } else {
                w.write("\n${"#".repeat(depth + 1)} ${node.label}\n")
                w.write("=".repeat(50) + "\n\n")
                writeTxtNodes(w, node.children, byIndex, depth + 1)
            }
        }
    }

    // ----------------------------------------------------------------- HTML ----

    private fun stageHtml(job: LeechJob, chapters: List<LeechChapter>, toc: List<TocNode>, story: StoryMeta, cover: LeechImage?, outDir: File, nowMs: Long): File {
        val outFile = File(outDir, buildFileName(job, "html", nowMs))
        val byIndex = chapters.associateBy { it.index }

        val hasImages = chapters.any { it.images.isNotEmpty() } || cover != null
        if (hasImages) {
            val imgDir = File(outDir, "images")
            if (!imgDir.exists()) imgDir.mkdirs()
            chapters.forEach { ch -> ch.images.forEach { img -> File(imgDir, img.localFileName).writeBytes(img.bytes) } }
            if (cover != null) File(imgDir, cover.localFileName).writeBytes(cover.bytes)
        }
        val coverHref = if (cover != null) "images/${cover.localFileName}" else ""

        outFile.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write(
                "<!DOCTYPE html>\n<html lang=\"${EbookMarkup.escapeXml(story.language.ifBlank { "vi" })}\">\n<head>\n  <meta charset=\"UTF-8\">\n  <title>${EbookMarkup.escapeXml(EbookMarkup.bookTitle(job, story))}</title>\n" +
                    "  <style>\n" +
                    "    body { max-width: 720px; margin: 0 auto; padding: 2rem 1rem;\n           font-family: Georgia, serif; line-height: 1.8; color: #1a1a1a; }\n" +
                    "    h1 { font-size: 2em; }\n" +
                    "    h2 { font-size: 1.4em; margin-top: 3em; border-bottom: 1px solid #ddd;\n         padding-bottom: 0.3em; }\n" +
                    "    p { text-indent: 1.5em; margin: 0 0 0.7em 0; }\n" +
                    "    ul.story-info { list-style: none; padding: 0; }\n" +
                    "    .story-summary p { text-indent: 0; }\n" +
                    "    #toc { background: #f9f9f9; border: 1px solid #e0e0e0;\n           padding: 1rem 1.5rem; border-radius: 6px; margin-bottom: 3em; }\n" +
                    "    #toc a { text-decoration: none; color: #2563eb; }\n    #toc a:hover { text-decoration: underline; }\n    #toc ol ol { margin-left: 1em; }\n" +
                    "    #toc span.vol { font-weight: bold; display: block; margin-top: 0.5em; }\n" +
                    "  </style>\n</head>\n<body>\n"
            )
            w.write(EbookMarkup.htmlHeader(job, story, coverHref))
            w.write("  <div id=\"toc\">\n    <strong>Mục lục</strong>\n    <ol>\n      ${renderHtmlTocItems(toc)}\n    </ol>\n  </div>\n")
            writeHtmlChapterBodies(w, toc, byIndex)
            w.write("</body></html>")
        }
        return outFile
    }

    private fun renderHtmlTocItems(nodes: List<TocNode>): String =
        nodes.joinToString("\n") { node ->
            if (node.chapterIndex != null) "<li><a href=\"#ch${node.chapterIndex}\">${EbookMarkup.escapeXml(node.label)}</a></li>"
            else "<li><span class=\"vol\">${EbookMarkup.escapeXml(node.label)}</span><ol>${renderHtmlTocItems(node.children)}</ol></li>"
        }

    private fun writeHtmlChapterBodies(w: BufferedWriter, nodes: List<TocNode>, byIndex: Map<Int, LeechChapter>) {
        nodes.forEach { node ->
            if (node.chapterIndex != null) {
                val ch = byIndex[node.chapterIndex] ?: return@forEach
                w.write("  <h2 id=\"ch${ch.index}\">${EbookMarkup.escapeXml(node.label)}</h2>\n")
                // Bản 7.104: cùng bộ làm sạch với EPUB — bỏ script/sự kiện on*/iframe lấy từ trang nguồn (mở file HTML trên máy không được chạy mã của trang lạ) và sửa thẻ lệch.
                w.write("  " + EbookMarkup.xhtmlFix(ch.htmlContent) + "\n\n")
            } else {
                w.write("  <h1 style=\"margin-top:3em\">${EbookMarkup.escapeXml(node.label)}</h1>\n")
                writeHtmlChapterBodies(w, node.children, byIndex)
            }
        }
    }

    // -------------------------------------------------------------- helpers ----

    fun buildFileName(job: LeechJob, ext: String, nowMs: Long): String {
        val base = job.outputFileName.ifBlank { sanitizeFileName(job.name) }
        // Bản 7.102: chế độ ghi đè dùng TÊN CỐ ĐỊNH (không dấu thời gian) để lần sau tìm lại đúng file này.
        if (job.updateExistingFile) return "$base.$ext"
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date(nowMs))
        return "${base}_${stamp}.$ext"
    }

    /**
     * Chuẩn hoá tên file — GIỮ LẠI dấu tiếng Việt (bản cũ dùng \\w nên xoá mất dấu, chỉ còn khung xương không dấu). Chỉ loại ký tự thật sự không hợp lệ trong tên file
     * (/ \ : * ? " < > |) và khoảng trắng thừa.
     */
    fun sanitizeFileName(name: String): String =
        name.replace(Regex("""[/\\:*?"<>|]"""), "")
            .trim()
            .replace(Regex("\\s+"), "_")
            .ifBlank { "ebook" }
}
