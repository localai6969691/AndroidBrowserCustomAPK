package com.colablive.keeper.core

import java.io.File

/**
 * Bản 7.104 — bằng chứng ÁP LỰC BỘ NHỚ của hệ điều hành lúc trình duyệt "đơ" (chỉ ĐỌC, không đổi hành vi).
 *
 * Vì sao: log 09:15 ngày 11/11 (7.98) — lúc đơ app giữ 3,4GB qua 9–10 tab (hai tab claude.ai ~1,1–1,2GB mỗi tab), máy còn 1,7GB trống nhưng `lowMemory=false` (ngưỡng app 300MB),
 * 8 lệnh eval liên tiếp không có phản hồi, nút Tải lại không làm trang nào bắt đầu tải. Dữ liệu hiện có (CPU, đóng băng, trạng thái tiến trình — mục 218) KHÔNG phân biệt được
 * "tiến trình nội dung bị kẹt vì bộ nhớ (swap/refault)" với nguyên nhân khác. Thêm: MemAvailable/Swap, PSI bộ nhớ (nếu đọc được) và số gia các bộ đếm trang của nhân (`/proc/vmstat`)
 * trong cửa sổ đo. Cách đọc: `pswpin/pswpout` hoặc `workingset_refault_*`/`pgmajfault` tăng mạnh trong vài giây + PSI `some avg10` cao => máy đang đảo bộ nhớ (thrash), không phải lỗi logic của app.
 * Không đọc được (SELinux chặn /proc/pressure, v.v.) thì ghi rõ loại lỗi, KHÔNG suy diễn.
 */
object MemEvidence {
    /** Bộ đếm nhân quan tâm (khớp tên chính xác hoặc bắt đầu bằng `allocstall`). */
    private val VM_KEYS = setOf(
        "pgmajfault", "pswpin", "pswpout", "workingset_refault_anon", "workingset_refault_file", "workingset_refault",
        "pgscan_kswapd", "pgscan_direct", "oom_kill"
    )

    class Mark(val atMs: Long, val vm: Map<String, Long>)

    /** `/proc/meminfo` => khoá -> kB. */
    fun parseMeminfo(text: String): Map<String, Long> {
        val m = HashMap<String, Long>()
        for (line in text.lineSequence()) {
            val i = line.indexOf(':')
            if (i <= 0) continue
            val num = line.substring(i + 1).trim().substringBefore(' ').toLongOrNull() ?: continue
            m[line.substring(0, i)] = num
        }
        return m
    }

    /** `/proc/vmstat` => chỉ các khoá quan tâm. */
    fun parseVmstat(text: String): Map<String, Long> {
        val m = HashMap<String, Long>()
        for (line in text.lineSequence()) {
            val i = line.indexOf(' ')
            if (i <= 0) continue
            val k = line.substring(0, i)
            if (k in VM_KEYS || k.startsWith("allocstall")) line.substring(i + 1).trim().toLongOrNull()?.let { m[k] = it }
        }
        return m
    }

    /** `/proc/pressure/memory` => "some avg10=0.00 avg60=0.00 | full avg10=0.00 avg60=0.00" (bỏ total/avg300 cho gọn). */
    fun parsePsi(text: String): String {
        val parts = ArrayList<String>()
        for (line in text.lineSequence()) {
            val f = line.trim().split(' ').filter { it.isNotEmpty() }
            if (f.size < 3 || (f[0] != "some" && f[0] != "full")) continue
            val a10 = f.firstOrNull { it.startsWith("avg10=") } ?: continue
            val a60 = f.firstOrNull { it.startsWith("avg60=") } ?: ""
            parts.add("${f[0]} $a10 $a60".trim())
        }
        return if (parts.isEmpty()) "(trống)" else parts.joinToString(" | ")
    }

    private fun mb(kb: Long?): String = if (kb == null) "?" else "${kb / 1024}MB"

    /** Dòng bằng chứng. [from] là mốc đầu (null => không có số gia). [vmNow]/[meminfo]/[psi] truyền vào để kiểm thử không cần /proc thật. */
    fun describe(from: Mark?, vmNow: Map<String, Long>, nowMs: Long, meminfo: Map<String, Long>?, psi: String): String {
        val mi = if (meminfo == null) "meminfo không đọc được" else {
            val total = meminfo["MemTotal"]; val avail = meminfo["MemAvailable"]
            val st = meminfo["SwapTotal"]; val sf = meminfo["SwapFree"]
            val swap = if (st == null || st == 0L) "không có swap/zram" else "swap dùng ${mb(st - (sf ?: 0L))}/${mb(st)}"
            "MemAvailable=${mb(avail)}/${mb(total)} (${if (total != null && total > 0 && avail != null) avail * 100 / total else -1}%), $swap"
        }
        val delta = if (from == null) "(không có mốc đầu)" else {
            val w = (nowMs - from.atMs).coerceAtLeast(1L)
            val d = vmNow.entries.sortedBy { it.key }.mapNotNull { (k, v) ->
                val o = from.vm[k] ?: return@mapNotNull null
                val dv = v - o
                if (dv != 0L) "$k+$dv" else null
            }
            "trong ${w}ms: " + (if (d.isEmpty()) "mọi bộ đếm trang không đổi" else d.joinToString(","))
        }
        return "bộ nhớ hệ thống: $mi | PSI: $psi | nhân $delta"
    }

    private fun readOrNull(path: String): String? = try { File(path).readText() } catch (_: Throwable) { null }

    fun mark(nowMs: Long): Mark = Mark(nowMs, readOrNull("/proc/vmstat")?.let { parseVmstat(it) } ?: emptyMap())

    fun evidence(from: Mark?, nowMs: Long): String {
        val mi = readOrNull("/proc/meminfo")?.let { parseMeminfo(it) }
        val psi = try { parsePsi(File("/proc/pressure/memory").readText()) } catch (e: Throwable) { "không đọc được (${e.javaClass.simpleName})" }
        val vm = readOrNull("/proc/vmstat")?.let { parseVmstat(it) } ?: emptyMap()
        return describe(from, vm, nowMs, mi, psi)
    }
}
