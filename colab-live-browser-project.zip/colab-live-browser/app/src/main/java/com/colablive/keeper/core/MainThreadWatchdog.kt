package com.colablive.keeper.core

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Bản 7.57 — "chó canh" luồng giao diện: khi main thread KẸT > 600ms thì ghi vào DebugLog NGAY STACK TRACE của main thread lúc đó
 * (và lại ở mốc 1.5s, 3s nếu vẫn kẹt). Dùng để tìm thủ phạm thật của cảm giác "đứng máy" (mở lưới tab, chuyển tab, vẽ lại...) thay vì đoán.
 * Chỉ chạy khi Activity đang hiển thị (start ở onResume, stop ở onPause) nên không tốn pin lúc ở nền. Chi phí: 1 luồng ngủ 150ms + 1 tick/200ms.
 */
object MainThreadWatchdog {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var lastTick = 0L
    private var thread: Thread? = null
    private val levels = longArrayOf(600L, 1500L, 3000L)

    private val tick = object : Runnable {
        override fun run() {
            lastTick = SystemClock.uptimeMillis()
            if (running) main.postDelayed(this, 200L)
        }
    }

    @Synchronized fun start() {
        if (running) return
        running = true
        lastTick = SystemClock.uptimeMillis()
        // Bản 7.92: stop() rồi start() sát nhau (tạm dừng/tiếp tục Activity) trước đây có thể để SÓT một chuỗi tick 200ms cũ và một luồng canh cũ (cờ `running` đã lại là true nên
        // luồng cũ không thoát) => mỗi lần là thêm một chuỗi/luồng chạy mãi. Gỡ tick cũ và ngắt luồng cũ trước khi dựng mới.
        main.removeCallbacks(tick)
        thread?.interrupt()
        main.post(tick)
        thread = Thread({
            var stallStart = 0L
            var reported = 0
            while (running) {
                try { Thread.sleep(150L) } catch (e: InterruptedException) { break }
                val now = SystemClock.uptimeMillis()
                val lag = now - lastTick
                if (lag < levels[0]) { stallStart = 0L; reported = 0; continue }
                if (stallStart != lastTick) { stallStart = lastTick; reported = 0 }
                if (reported < levels.size && lag >= levels[reported]) {
                    reported++
                    try {
                        val st = Looper.getMainLooper().thread.stackTrace
                        val txt = st.take(16).joinToString(" <- ") { it.className.substringAfterLast('.') + "." + it.methodName + ":" + it.lineNumber }
                        DebugLog.log("[hiệu năng] luồng giao diện KẸT ${lag}ms — đang ở: $txt")
                    } catch (e: Throwable) { /* chỉ là chẩn đoán */ }
                }
            }
        }, "lb-main-watchdog").also { it.isDaemon = true; it.start() }
    }

    @Synchronized fun stop() {
        running = false
        thread?.interrupt(); thread = null
        main.removeCallbacks(tick)
    }
}
