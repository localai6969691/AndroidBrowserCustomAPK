package com.colablive.keeper.core

import android.content.Context
import android.net.Uri
import com.colablive.keeper.features.fingerprint.DeviceProfiles
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Xuất/nhập 1 hồ sơ (dữ liệu trình duyệt Gecko + cấu hình fingerprint/proxy
 * trong AppPrefs) thành 1 file .zip di động được — trả lời câu hỏi "mỗi
 * profile là 1 dữ liệu độc lập... có restore được khi gỡ cài lại, hoặc
 * mang qua máy khác không". TRƯỚC ĐÂY: hoàn toàn KHÔNG — dữ liệu chỉ nằm
 * trong bộ nhớ riêng của app (`/data/user/0/.../files`), Android tự xoá
 * sạch khi gỡ cài, không có cách nào lấy ra/đưa vào.
 *
 * Cấu trúc file .zip xuất ra:
 *   profile_data/...           toàn bộ thư mục hồ sơ Gecko (cookie, đăng
 *                               nhập, cache, lịch sử — places.sqlite nằm ở
 *                               đây, xem câu hỏi về lịch sử)
 *   app_prefs.json              cấu hình fingerprint/proxy/... của hồ sơ
 *   manifest.json                tên hồ sơ gốc + thời điểm xuất (tham khảo)
 *
 * CHỈ dùng java.util.zip (thư viện Java chuẩn, luôn có sẵn, không phụ
 * thuộc thư viện ngoài) — không đụng API GeckoView nào, nên không có rủi ro
 * đoán sai API như các phần MediaSession đã từng nói.
 */
/**
 * Ném ra khi import trùng tên hồ sơ ĐÃ ĐĂNG KÝ và người gọi CHƯA xác nhận
 * ghi đè (`overwrite=false`) — UI (`ProfilePickerActivity`) bắt riêng
 * exception này để hiện dialog hỏi "Ghi đè?" thay vì báo lỗi chung chung.
 */
class ProfileAlreadyExistsException(message: String) : Exception(message)


object ProfileExportImport {

    /**
     * Xuất hồ sơ `profileName` ra `destUri` (URI người dùng chọn qua
     * Storage Access Framework — xem `ProfilePickerActivity`). Chạy trên
     * luồng nền (I/O có thể chậm với hồ sơ lớn).
     */
    fun exportProfile(context: Context, profileName: String, destUri: Uri, options: BackupSyncOptions = BackupSyncOptions()): Result<ExportSummary> {
        /**
         * FIX THIẾU LOG (người dùng yêu cầu đúng: "export profile vẫn lỗi
         * 0B mà không hề có log chẩn đoán nào để tra tiếp" — trước đây
         * hàm này gần như câm lặng, chỉ log khi CATCH được exception, còn
         * trường hợp "chạy xong không lỗi gì nhưng zip vẫn rỗng/thiếu dữ
         * liệu" thì hoàn toàn không có manh mối). Thêm log ở TỪNG bước —
         * đủ để lần test tới trả lời dứt điểm: profileDir có tồn tại
         * không, có bao nhiêu file trong đó, mỗi entry ghi được bao nhiêu
         * byte, tổng cộng file zip ra bao nhiêu byte — không còn phải đoán.
         */
        val profileDir = File(context.filesDir, safeDirNameFor(profileName))
        val dirFileCount = if (profileDir.exists()) profileDir.walkTopDown().count { it.isFile } else -1
        DebugLog.log("ProfileExportImport.exportProfile BẮT ĐẦU: profileName='$profileName' profileDir=${profileDir.absolutePath} exists=${profileDir.exists()} soFileBenTrong=$dirFileCount destUri=$destUri")
        var totalBytesWritten = 0L
        var totalEntriesWritten = 0
        var skippedFiles = listOf<String>()
        return try {
            // Bản 7.61: KHÔNG xuất nếu cookies.sqlite NGUỒN đang hỏng bên trong (bộ nhớ máy lỗi) — nếu không, bản backup "tốt về CRC, hỏng về nội dung"
            // sẽ ghi đè mất hồ sơ tốt khi nhập lại (đúng sự cố 'vpscolab691').
            File(profileDir, "cookies.sqlite").takeIf { it.exists() }?.let { ck ->
                val bad = sqliteProvenCorrupt(ck, false)
                if (bad != null) {
                    DebugLog.log("ProfileExportImport.exportProfile: HUỶ XUẤT — cookies.sqlite nguồn hỏng bên trong: $bad")
                    return Result.failure(IllegalStateException("Dữ liệu đăng nhập (cookies.sqlite) của hồ sơ đang HỎNG bên trong ($bad) — thường do bộ nhớ máy lỗi. Không xuất để tránh tạo bản backup hỏng. Hãy khởi động lại máy rồi thử lại."))
                }
            }
            val profileDirLocal = profileDir
            context.contentResolver.openOutputStream(destUri)?.use { out ->
                CountingOutputStream(out) { totalBytesWritten = it }.let { counting ->
                ZipOutputStream(counting).use { zip ->
                    // 1) Cấu hình AppPrefs (fingerprint/proxy/...) của hồ sơ này
                    val prefsJson = JSONObject()
                    // Mục 145: gói đồng bộ. Không kèm dấu vân tay -> bỏ mọi khoá fp_*. Kèm dấu vân tay -> GHI RÕ danh tính hiệu lực
                    // (seed/mẫu phần cứng/locale vốn có thể chỉ tồn tại dưới dạng "mặc định theo tên", không nằm trong prefs) để khôi phục
                    // dưới BẤT KỲ tên hồ sơ nào vẫn ra đúng dấu vân tay cũ.
                    val prefsMap = AppPrefs.exportNamespace(context, profileName).toMutableMap()
                    if (!options.fingerprint) {
                        prefsMap.keys.filter { FingerprintIdentity.isFingerprintKey(it) }.forEach { prefsMap.remove(it) }
                    } else if (prefsMap["fp_fresh"] != true) {
                        if (!prefsMap.containsKey("fp_noise_seed")) prefsMap["fp_noise_seed"] = FingerprintIdentity.defaultSeedFor(profileName).toString()
                        if (!prefsMap.containsKey("fp_hw_idx")) prefsMap["fp_hw_idx"] = DeviceProfiles.defaultHwIndexForProfile(profileName)
                        if (!prefsMap.containsKey("fp_locale_idx")) prefsMap["fp_locale_idx"] = DeviceProfiles.defaultLocaleIndexForProfile(profileName)
                    }
                    prefsMap.forEach { (k, v) -> prefsJson.put(k, v) }
                    val prefsBytes = prefsJson.toString().toByteArray()
                    writeZipEntry(zip, "app_prefs.json", prefsBytes)
                    totalEntriesWritten++
                    DebugLog.log("ProfileExportImport.exportProfile: đã ghi app_prefs.json (${prefsBytes.size} byte, ${AppPrefs.exportNamespace(context, profileName).size} key)")

                    // 2) Thông tin tham khảo
                    val manifest = JSONObject().apply {
                        put("profile_name", profileName)
                        put("exported_at", System.currentTimeMillis())
                        put("app_version", BuildMarker.VERSION)
                        put("format_version", 2)
                        put("contains_profile_data", options.data)
                        put("contains_fingerprint", options.fingerprint)
                        if (options.fingerprint) put("fingerprint_summary", JSONObject().apply {
                            put("seed_hash", (prefsMap["fp_noise_seed"] as? String)?.let { FingerprintIdentity.seedHash(it) } ?: "")
                            put("hw_idx", prefsMap["fp_hw_idx"]?.toString() ?: "")
                            put("locale_idx", prefsMap["fp_locale_idx"]?.toString() ?: "")
                            put("fresh_each_open", prefsMap["fp_fresh"] == true)
                        })
                    }
                    DebugLog.log("ProfileExportImport.exportProfile: GÓI ĐỒNG BỘ — dữ liệu đăng nhập/trang=${options.data}, dấu vân tay=${options.fingerprint}")
                    val manifestBytes = manifest.toString().toByteArray()
                    writeZipEntry(zip, "manifest.json", manifestBytes)
                    totalEntriesWritten++
                    DebugLog.log("ProfileExportImport.exportProfile: đã ghi manifest.json (${manifestBytes.size} byte)")

                    // 3) Toàn bộ thư mục dữ liệu trình duyệt (nếu có)
                    if (options.data && profileDirLocal.exists()) {
                        val (filesZipped, bytesZipped, skipped) = zipDirRecursive(zip, profileDirLocal, "profile_data")
                        totalEntriesWritten += filesZipped
                        skippedFiles = skipped
                        DebugLog.log("ProfileExportImport.exportProfile: đã ghi profile_data/ ($filesZipped file, ~$bytesZipped byte trước nén — số byte SAU nén xem ở dòng tổng kết cuối, BỎ QUA ${skipped.size} file: ${skipped.joinToString(", ")})")
                    } else {
                        if (!options.data) DebugLog.log("ProfileExportImport.exportProfile: BỎ QUA profile_data theo lựa chọn người dùng (chỉ xuất dấu vân tay)") else DebugLog.log("ProfileExportImport.exportProfile: profileDir KHÔNG TỒN TẠI ('${profileDirLocal.absolutePath}') — zip xuất ra sẽ CHỈ có app_prefs.json + manifest.json, KHÔNG có dữ liệu duyệt web nào (cookie/lịch sử/đăng nhập) — đây rất có thể là nguyên nhân 0B/gần-0B nếu tên hồ sơ không khớp thư mục thật")
                    }
                }
                }
            } ?: run {
                DebugLog.log("ProfileExportImport.exportProfile: openOutputStream(destUri) trả về NULL — không mở được nơi lưu, có thể quyền SAF đã bị thu hồi")
                return Result.failure(IllegalStateException("Không mở được nơi lưu file"))
            }
            /**
             * FIX MỚI (liên quan trực tiếp tới bug "ghi đè mất dữ liệu" —
             * xem chú thích lớn ở `importProfile`): TRƯỚC ĐÂY việc file bị
             * khoá (sqlite -wal/-shm khi khe đang chạy lúc export) chỉ ghi
             * vào DebugLog, người dùng KHÔNG CÓ CÁCH NÀO biết bản backup
             * vừa tạo ra bị THIẾU dữ liệu — dễ dẫn tới việc sau này dùng
             * chính bản backup thiếu đó để "ghi đè" (import overwrite),
             * tưởng đang khôi phục lại nhưng thực chất đang THAY dữ liệu
             * ĐẦY ĐỦ hiện tại bằng dữ liệu THIẾU. Trả kèm `skippedFiles`
             * trong kết quả để UI (`ProfilePickerActivity`) hiện cảnh báo
             * RÕ RÀNG ngay lúc export xong, thay vì im lặng.
             */
            DebugLog.log("ProfileExportImport.exportProfile HOÀN TẤT: tổng $totalEntriesWritten entry, TỔNG CỘNG $totalBytesWritten byte đã ghi thật vào file zip, BỎ QUA ${skippedFiles.size} file (${skippedFiles.joinToString(", ")}) — đây là con số quyết định (nếu số byte = 0 hoặc rất nhỏ dù các bước trên báo ghi thành công, khả năng cao OutputStream bị đóng/cắt ngang bởi hệ thống TRƯỚC KHI dữ liệu được flush xuống đĩa thật, xem thêm ExportBackupService.kt)")
            val verifyErr = verifyBackupReadable(context, destUri)
            if (verifyErr != null) {
                DebugLog.log("ProfileExportImport.exportProfile: XÁC MINH SAU XUẤT THẤT BẠI — $verifyErr")
                return Result.failure(IllegalStateException("File backup vừa ghi KHÔNG đọc lại được trọn vẹn ($verifyErr) — bộ nhớ/thẻ có thể đang lỗi. ĐỪNG dùng file này; khởi động lại máy rồi xuất lại."))
            }
            DebugLog.log("ProfileExportImport.exportProfile: xác minh sau xuất OK — đọc lại trọn vẹn, CRC đúng")
            Result.success(ExportSummary(totalEntriesWritten, totalBytesWritten, skippedFiles))
        } catch (e: Exception) {
            DebugLog.log("ProfileExportImport.exportProfile LỖI (đã ghi được $totalEntriesWritten entry / $totalBytesWritten byte trước khi lỗi): ${e.javaClass.simpleName}: ${e.message}")
            Result.failure(e)
        }
    }

    /** Tóm tắt kết quả export — `skippedFiles` không rỗng nghĩa là có file
     * bị bỏ qua đúng lúc đọc (thường -wal/-shm đang ghi dở, xem mục 12:
     * rủi ro thật rất nhỏ nhờ SQLite WAL an toàn để copy khi đang mở). */
    data class ExportSummary(val entriesWritten: Int, val bytesWritten: Long, val skippedFiles: List<String>)

    /** Đếm số byte thật sự chảy qua OutputStream — để biết chính xác zip
     * cuối cùng nặng bao nhiêu, không phải suy đoán từ kích thước file gốc
     * (nén có thể làm nhỏ đi nhiều, và đây là con số THẬT NẰM TRÊN ĐĨA). */
    private class CountingOutputStream(
        private val delegate: OutputStream,
        private val onCount: (Long) -> Unit
    ) : OutputStream() {
        private var count = 0L
        override fun write(b: Int) { delegate.write(b); count++; onCount(count) }
        override fun write(b: ByteArray, off: Int, len: Int) { delegate.write(b, off, len); count += len; onCount(count) }
        override fun flush() = delegate.flush()
        override fun close() = delegate.close()
    }

    /**
     * Nhập 1 file .zip đã xuất trước đó thành hồ sơ TÊN MỚI `targetProfileName`
     * (không ghi đè hồ sơ đang tồn tại — để an toàn, người gọi tự kiểm tra
     * tên chưa trùng trước khi gọi hàm này, xem `ProfilePickerActivity`).
     *
     * BUG THẬT (người dùng báo: nhập "vpscolab691" liên tục báo "Đã có dữ
     * liệu cho tên hồ sơ này rồi" dù chưa từng nhập thành công lần nào —
     * xác nhận qua ảnh chụp màn hình: hồ sơ này KHÔNG hề xuất hiện trong
     * danh sách profile đã gán, tức `ProfileSlots` chưa từng đăng ký nó):
     * code CŨ ghi file trực tiếp vào `targetDir` ngay trong lúc giải nén —
     * nếu bất kỳ bước nào giữa chừng ném exception (file zip lỗi, hết
     * dung lượng, `AppPrefs.importNamespace`/`ProfileSlots.addProfile` lỗi,
     * v.v.), hàm trả `Result.failure` NHƯNG `targetDir` đã có sẵn 1 phần
     * dữ liệu rồi — không hề dọn dẹp. Lần thử lại SAU đó luôn bị chặn ngay
     * từ `if (targetDir.exists())`, dù dữ liệu thật KHÔNG đầy đủ/hợp lệ —
     * đúng như người dùng mô tả "báo có mà thực tế chưa có".
     *
     * Sửa theo mô hình TRANSACTION ATOMIC: giải nén vào 1 thư mục TẠM
     * riêng, chỉ đổi tên (rename — thao tác tức thời, không copy lại) thành
     * `targetDir` thật SAU KHI mọi bước (giải nén + AppPrefs +
     * ProfileSlots.addProfile) đã thành công hoàn toàn. Bất kỳ lỗi nào
     * giữa chừng đều tự xoá sạch thư mục tạm — `targetDir` CHỈ tồn tại khi
     * import thật sự xong xuôi, khớp đúng ý nghĩa của thông báo lỗi.
     *
     * Đồng thời DỌN RÁC MỒ CÔI: nếu `targetDir` đã tồn tại từ MỘT LẦN THỬ
     * LỖI TRƯỚC (từ bản cũ chưa có fix này) nhưng tên hồ sơ đó CHƯA TỪNG
     * được đăng ký trong `ProfileSlots.listProfiles()`, coi đó là rác mồ
     * côi — tự xoá rồi cho phép import lại, thay vì chặn vĩnh viễn buộc
     * người dùng phải tự vào file manager xoá thủ công.
     */
    /**
     * BUG THIẾT KẾ THẬT (người dùng chỉ ra đúng, rất gay gắt và có lý):
     * trước đây `importProfile()` CHẶN CỨNG nếu tên hồ sơ đích ĐÃ đăng ký
     * — không có cách nào ghi đè, buộc người dùng phải GỠ CÀI ĐẶT TOÀN BỘ
     * APP (xóa sạch mọi hồ sơ khác, mọi dữ liệu khác) chỉ để "test" hoặc
     * thực sự dùng chức năng import — vô lý cho 1 tính năng có tên là
     * "backup/restore". Sửa: thêm tham số `overwrite` — mặc định vẫn
     * `false` (an toàn, không âm thầm ghi đè ngoài ý muốn), nhưng CHO PHÉP
     * gọi lại với `overwrite=true` sau khi người dùng xác nhận qua dialog
     * cảnh báo rõ ràng (xem `ProfilePickerActivity.kt`), không cần xóa gì
     * ở tầng hệ điều hành cả.
     */
    /** Bản 7.60: cảnh báo của lần nhập gần nhất (vd bỏ qua vài tệp hỏng không quan trọng); null = không có. ImportBackupService gửi kèm broadcast. */
    @Volatile var lastImportWarning: String? = null

    fun importProfile(context: Context, srcUri: Uri, targetProfileName: String, overwrite: Boolean = false, options: BackupSyncOptions = BackupSyncOptions()): Result<Unit> {
        lastImportWarning = null
        if (!options.data) return importFingerprintOnly(context, srcUri, targetProfileName)
        if (!options.fingerprint) DebugLog.log("ProfileExportImport.importProfile: CẢNH BÁO — khôi phục dữ liệu đăng nhập KHÔNG kèm dấu vân tay: phiên có thể bị Google/trang web huỷ nếu dấu vân tay của hồ sơ đích khác lúc đăng nhập")
        val targetDir = File(context.filesDir, safeDirNameFor(targetProfileName))
        val tmpDir = File(context.filesDir, safeDirNameFor(targetProfileName) + ".importing_tmp")
        return try {
            var willOverwriteExisting = false
            if (targetDir.exists()) {
                val isRegistered = ProfileSlots.listProfiles(context).contains(targetProfileName)
                if (isRegistered && !overwrite) {
                    return Result.failure(
                        ProfileAlreadyExistsException("Đã có dữ liệu cho tên hồ sơ này rồi")
                    )
                }
                /**
                 * BUG THẬT NGHIÊM TRỌNG đã sửa (người dùng báo, hoàn toàn
                 * đúng: "khi restore ghi đè profile cùng tên thì gần như
                 * tất cả mọi dữ liệu đều bị mất hết"): code CŨ gọi
                 * `targetDir.deleteRecursively()` NGAY TẠI ĐÂY — tức XOÁ
                 * SẠCH dữ liệu TỐT hiện có TRƯỚC KHI biết chắc file zip
                 * đang nhập có đầy đủ/hợp lệ hay không. Nếu file zip backup
                 * bị thiếu dữ liệu (chính hàm `zipDirRecursive` đã tự ghi
                 * chú: khi xuất LÚC khe đang chạy, các file sqlite khoá
                 * `-wal`/`-shm` bị BỎ QUA ÂM THẦM, chỉ ghi log — không báo
                 * cho người dùng biết bản backup không đầy đủ), hoặc quá
                 * trình giải nén bị lỗi giữa chừng (hết dung lượng, file
                 * zip hỏng, v.v.) — dữ liệu CŨ đã bị xoá mất VĨNH VIỄN,
                 * trong khi dữ liệu MỚI từ bản backup lại không đầy đủ
                 * bằng — đúng khớp triệu chứng "mất gần hết dữ liệu" dù
                 * thao tác "restore" tưởng như đã thành công.
                 *
                 * Đây CHÍNH LÀ việc vi phạm nguyên tắc ATOMIC mà hàm này ĐÃ
                 * áp dụng ĐÚNG cho nhánh import thường (giải nén vào thư
                 * mục TẠM trước, chỉ rename thành thật SAU KHI mọi bước
                 * thành công) — nhưng lại BỎ SÓT áp dụng cho đúng bước xoá
                 * dữ liệu CŨ khi ghi đè. Sửa: KHÔNG xoá `targetDir` ở đây
                 * nữa — chỉ đánh dấu `willOverwriteExisting = true`, để
                 * việc xoá dữ liệu cũ dời tới NGAY TRƯỚC bước rename cuối
                 * cùng (xem bên dưới) — tại đó, thư mục tạm đã giải nén
                 * XONG HẲN và chắc chắn hợp lệ, giảm tối đa khoảng thời
                 * gian dữ liệu cũ có thể bị mất mà không có gì thay thế.
                 */
                DebugLog.log(
                    if (isRegistered) "ProfileExportImport.importProfile: sẽ ghi đè hồ sơ '$targetProfileName' theo yêu cầu người dùng (overwrite=true) — dữ liệu CŨ sẽ CHỈ bị xoá SAU KHI giải nén dữ liệu MỚI xong xuôi hoàn toàn (an toàn hơn xoá ngay từ đầu)"
                    else "ProfileExportImport.importProfile: '$targetProfileName' có thư mục trên đĩa nhưng CHƯA đăng ký trong ProfileSlots — coi là rác mồ côi từ lần import lỗi trước, sẽ tự xoá SAU KHI giải nén dữ liệu mới xong (không phải ngay bây giờ)"
                )
                willOverwriteExisting = true
            }
            // Dọn thư mục tạm còn sót từ lần thử TRƯỚC ĐÓ nữa (nếu app bị
            // kill giữa chừng, không kịp chạy tới catch/finally dọn dẹp).
            if (tmpDir.exists()) tmpDir.deleteRecursively()

            var profileDataFilesExtracted = 0
            /**
             * BUG LOG THẬT vừa tự phát hiện (đúng như phê bình: "tại sao
             * không tự làm log mà đẩy qua cho người dùng"): nhánh
             * `openInputStream() == null` TRƯỚC ĐÂY hoàn toàn IM LẶNG —
             * return luôn, không hề gọi DebugLog. Nếu URI hết quyền truy
             * cập (SAF permission bị thu hồi — rất hay gặp khi người dùng
             * bấm "Ghi đè" NHIỀU LẦN liên tiếp dùng LẠI cùng 1 URI đã chọn
             * từ trước, thay vì chọn file lại mỗi lần), hàm sẽ thất bại
             * NGAY TỪ ĐÂY mà không có gì trong log để biết — đúng khớp
             * hiện tượng "bấm ghi đè nhiều lần liền, dữ liệu vẫn không đổi
             * gì cả" quan sát được. Thêm log rõ ràng + bắt riêng
             * SecurityException (dấu hiệu chắc chắn nhất của mất quyền
             * SAF) để lần test tới trả lời DỨT ĐIỂM, không phải đoán.
             */
            val inputStream = try {
                context.contentResolver.openInputStream(srcUri)
            } catch (e: SecurityException) {
                DebugLog.log("ProfileExportImport.importProfile: openInputStream() NÉM SecurityException — URI đã MẤT QUYỀN TRUY CẬP (rất có thể do dùng lại URI cũ từ lần chọn file trước, hoặc bấm 'ghi đè' nhiều lần liên tiếp không chọn lại file) — srcUri=$srcUri : ${e.message}")
                if (tmpDir.exists()) tmpDir.deleteRecursively()
                return Result.failure(e)
            }
            if (inputStream == null) {
                DebugLog.log("ProfileExportImport.importProfile: openInputStream() trả về NULL (không ném exception, chỉ đơn giản null) — srcUri=$srcUri không mở được, DỪNG LẠI, KHÔNG đụng gì tới dữ liệu cũ")
                if (tmpDir.exists()) tmpDir.deleteRecursively()
                return Result.failure(IllegalStateException("Không mở được file đã chọn"))
            }
            DebugLog.log("ProfileExportImport.importProfile: openInputStream() THÀNH CÔNG, bắt đầu giải nén zip vào thư mục tạm '${tmpDir.name}'")
            // Bản 7.60 — LỖI GỐC của "invalid code lengths set" (log: nhập 'vpscolab691' thất bại 4 lần liên tiếp, 'vpscolab692' thì OK): ZipInputStream đọc TUẦN TỰ
            // trên luồng của ContentResolver; chỉ MỘT tệp nén hỏng (tải/chép dở, Drive/trình quản lý tệp trả dữ liệu lỗi) là Inflater ném ZipException và BỎ CẢ BẢN NHẬP,
            // dù hàng trăm tệp còn lại nguyên vẹn. Giờ: (1) chép nguồn về file thật trong cache rồi mở bằng ZipFile (đọc ngẫu nhiên theo danh mục);
            // (2) lỗi từng tệp được cô lập — tệp hỏng bị bỏ và ghi tên vào log; (3) chỉ DỪNG khi tệp hỏng là tệp QUAN TRỌNG (cookies.sqlite, key4.db, logins.json, app_prefs.json).
            val srcCopy = File(context.cacheDir, "import_src_${System.nanoTime()}.zip")
            var copiedBytes = 0L
            try {
                inputStream.use { ins -> srcCopy.outputStream().use { o -> copiedBytes = ins.copyTo(o) } }
            } catch (e: Exception) {
                srcCopy.delete()
                throw IllegalStateException("Không đọc trọn được file backup (đọc được $copiedBytes byte rồi lỗi: ${e.message}) — file có thể đang tải dở hoặc nằm trên dịch vụ đám mây chưa tải xong. Hãy tải file về máy rồi chọn lại.")
            }
            DebugLog.log("ProfileExportImport.importProfile: đã sao chép file nguồn về bộ nhớ đệm — $copiedBytes byte")
            val failedEntries = ArrayList<String>()
            var prefsJsonText: String? = null
            var manifestJsonText: String? = null
            val zf = try { java.util.zip.ZipFile(srcCopy) } catch (e: Exception) {
                srcCopy.delete(); if (tmpDir.exists()) tmpDir.deleteRecursively()
                DebugLog.log("ProfileExportImport.importProfile: ZipFile() không mở được ($copiedBytes byte) — ${e.javaClass.simpleName}: ${e.message}")
                return Result.failure(IllegalStateException("File backup bị hỏng hoặc bị cắt cụt ($copiedBytes byte; không đọc được danh mục zip: ${e.message}). Thường do tải/chép chưa xong — hãy xuất lại hoặc tải lại file rồi nhập lần nữa."))
            }
            try {
                zf.use { z ->
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val entry = en.nextElement()
                        val name = entry.name
                        try {
                            when {
                                name == "app_prefs.json" -> prefsJsonText = z.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) }
                                name == "manifest.json" -> manifestJsonText = z.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) }
                                name.startsWith("profile_data/") -> {
                                    val relPath = name.removePrefix("profile_data/")
                                    if (relPath.isNotBlank()) {
                                        val outFile = File(tmpDir, relPath)
                                        if (entry.isDirectory) {
                                            outFile.mkdirs()
                                        } else {
                                            outFile.parentFile?.mkdirs()
                                            z.getInputStream(entry).use { ins2 -> outFile.outputStream().use { ins2.copyTo(it) } }
                                            profileDataFilesExtracted++
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            failedEntries.add("$name (${e.message})")
                            if (name.startsWith("profile_data/")) try { File(tmpDir, name.removePrefix("profile_data/")).delete() } catch (_: Exception) {}
                        }
                    }
                }
            } finally {
                srcCopy.delete()
            }
            if (failedEntries.isNotEmpty()) {
                DebugLog.log("ProfileExportImport.importProfile: ${failedEntries.size} tệp trong zip BỊ HỎNG, đã bỏ qua: ${failedEntries.take(15).joinToString(" ; ")}")
                val essential = failedEntries.firstOrNull { it.startsWith("profile_data/cookies.sqlite") || it.startsWith("profile_data/key4.db") || it.startsWith("profile_data/logins.json") || it.startsWith("app_prefs.json") }
                if (essential != null) {
                    if (tmpDir.exists()) tmpDir.deleteRecursively()
                    return Result.failure(IllegalStateException("File backup hỏng đúng ở tệp quan trọng: $essential. Không nhập để tránh mất đăng nhập — hãy xuất lại hoặc tải lại file backup."))
                }
                lastImportWarning = "Đã bỏ qua ${failedEntries.size} tệp hỏng không quan trọng (ví dụ ${failedEntries.first().substringBefore(" (")})"
            }
            run {
                // Log tuổi file backup — phiên đăng nhập Google trong cookie có hạn dùng
                    // (Google xoay cookie phiên khoảng vài chục phút/lần), backup càng cũ
                    // càng dễ bị Google từ chối; có con số này trong log thì không phải đoán.
                    val exportedAtMs = try {
                        manifestJsonText?.let { JSONObject(it).optLong("exported_at", 0L) } ?: 0L
                    } catch (e: Exception) { 0L }
                    if (exportedAtMs > 0L) {
                        val ageHours = (System.currentTimeMillis() - exportedAtMs) / 3_600_000.0
                        DebugLog.log("ProfileExportImport.importProfile: file backup xuất lúc ${java.util.Date(exportedAtMs)} — TUỔI ≈ ${"%.1f".format(ageHours)} giờ tính tới lúc import")
                    } else {
                        DebugLog.log("ProfileExportImport.importProfile: file backup KHÔNG có/không đọc được manifest.json — không biết tuổi")
                    }
                    prefsJsonText?.let { text ->
                        val json = JSONObject(text)
                        val map = mutableMapOf<String, Any?>()
                        json.keys().forEach { k -> map[k] = json.get(k) }
                        if (!options.fingerprint) {
                            map.keys.filter { FingerprintIdentity.isFingerprintKey(it) }.forEach { map.remove(it) }
                        } else if (map["fp_fresh"] != true && !map.containsKey("fp_noise_seed")) {
                            // backup cũ không có seed: ghim seed XÁC ĐỊNH theo tên đích (cùng công thức engine) thay vì để lần chạy đầu quyết định
                            map["fp_noise_seed"] = FingerprintIdentity.defaultSeedFor(targetProfileName).toString()
                        }
                        val (restored, dropped) = AppPrefs.importNamespace(context, targetProfileName, map)
                        val hasSeed = map.containsKey("fp_noise_seed")
                        DebugLog.log("ProfileExportImport.importProfile: trong backup fp_fresh=${map["fp_fresh"]} (true = dấu vân tay đổi ngẫu nhiên MỖI lần mở, dễ làm Google huỷ phiên), fp_hw_idx=${map["fp_hw_idx"]}, fp_locale_idx=${map["fp_locale_idx"]}")
                        DebugLog.log(
                            "ProfileExportImport.importProfile: app_prefs.json — khôi phục $restored/${map.size} khoá" +
                                (if (dropped.isNotEmpty()) ", BỎ SÓT ${dropped.size} khoá (kiểu không hỗ trợ): ${dropped.joinToString()}" else "") +
                                "; fp_noise_seed trong file backup = " +
                                (if (hasSeed) "CÓ" else "KHÔNG CÓ (lần chạy đầu trên bản cài mới sẽ sinh seed NGẪU NHIÊN khác gốc → dấu vân tay canvas/audio/WebGL đổi)")
                        )
                    } ?: DebugLog.log("ProfileExportImport.importProfile: file backup KHÔNG có app_prefs.json")
            }
            DebugLog.log("ProfileExportImport.importProfile: giải nén XONG — $profileDataFilesExtracted file profile_data/ (willOverwriteExisting=$willOverwriteExisting)")

            /**
             * KIỂM TRA AN TOÀN THÊM (theo đúng tinh thần "không đoán mù" —
             * nếu bản backup rõ ràng RỖNG hoặc gần rỗng trong khi SẮP xoá
             * dữ liệu cũ để thay bằng nó, dừng lại và báo lỗi rõ ràng thay
             * vì âm thầm tiến hành ghi đè bằng dữ liệu thiếu). Chỉ áp dụng
             * khi CÓ ghi đè — nếu là hồ sơ hoàn toàn mới (targetDir chưa hề
             * tồn tại), 0 file profile_data vẫn hợp lệ (hồ sơ mới tinh chưa
             * từng duyệt web gì cả).
             */
            run {
                val (sqlBad, sqlRemoved) = validateExtractedSqlite(tmpDir)
                if (sqlBad != null) {
                    if (tmpDir.exists()) tmpDir.deleteRecursively()
                    return Result.failure(IllegalStateException("Dữ liệu đăng nhập trong file backup bị HỎNG BÊN TRONG ($sqlBad) — thường do bộ nhớ máy lỗi lúc xuất. ĐÃ HUỶ, dữ liệu hiện có của hồ sơ giữ nguyên. Hãy dùng file backup khác hoặc xuất lại."))
                }
                if (sqlRemoved.isNotEmpty()) lastImportWarning = listOfNotNull(lastImportWarning, "Đã bỏ ${sqlRemoved.size} cơ sở dữ liệu hỏng không quan trọng (${sqlRemoved.joinToString()}) — Gecko tự tạo lại").joinToString(" — ")
            }
            if (willOverwriteExisting && profileDataFilesExtracted == 0) {
                DebugLog.log("ProfileExportImport.importProfile: DỪNG LẠI TRƯỚC KHI GHI ĐÈ — file zip giải nén ra 0 file profile_data/ nào (rất có thể export lỗi/rỗng, hoặc export lúc khe đang chạy khiến toàn bộ file bị khoá và bỏ qua) — KHÔNG xoá dữ liệu cũ để tránh mất trắng")
                tmpDir.deleteRecursively()
                return Result.failure(IllegalStateException("File backup có vẻ rỗng (0 file dữ liệu duyệt web) — đã HUỶ để tránh xoá mất dữ liệu hiện có. Kiểm tra lại file backup, hoặc đảm bảo khe đã đóng hẳn lúc export."))
            }

            // COMMIT ATOMIC: mọi bước giải nén + AppPrefs đã xong xuôi.
            // CHỈ TỚI ĐÂY mới xoá dữ liệu CŨ (nếu ghi đè) — ngay trước khi
            // đổi tên thư mục tạm thành thư mục thật, giảm tối đa khoảng
            // thời gian "không còn dữ liệu cũ mà cũng chưa có dữ liệu mới".
            // Bản 7.61: GHI ĐÈ KHÔNG BAO GIỜ XOÁ dữ liệu cũ nữa — đổi tên thành hồ sơ riêng '<tên>_cu' (hiện trong danh sách hồ sơ, dùng lại qua "Đổi").
            // Trước đây xoá hẳn rồi mới đổi tên bản mới => bản backup hỏng ("tốt về CRC, hỏng nội dung") làm mất cả hồ sơ cũ lẫn mới.
            var preservedAs: String? = null
            var preservedDir: File? = null
            if (willOverwriteExisting && targetDir.exists()) {
                Thread.sleep(2500) // giữ nguyên độ trễ chờ Gecko nhả file (mục 13)
                val keepName = uniquePreservedName(context, targetProfileName)
                val keepDir = File(context.filesDir, safeDirNameFor(keepName))
                var moved = targetDir.renameTo(keepDir)
                if (!moved) { Thread.sleep(300); moved = targetDir.renameTo(keepDir) }
                if (!moved) {
                    DebugLog.log("ProfileExportImport.importProfile: KHÔNG giữ lại được dữ liệu cũ (rename '${targetDir.name}' → '${keepDir.name}' thất bại) — HUỶ ghi đè, dữ liệu cũ nguyên vẹn")
                    if (tmpDir.exists()) tmpDir.deleteRecursively()
                    return Result.failure(IllegalStateException("Không giữ lại được dữ liệu cũ (có tệp đang bị khoá) — đã HUỶ ghi đè, dữ liệu cũ còn nguyên. Đóng khe đang dùng hồ sơ này rồi thử lại."))
                }
                try {
                    ProfileSlots.addProfile(context, keepName)
                    AppPrefs.importNamespace(context, keepName, AppPrefs.exportNamespace(context, targetProfileName))
                } catch (e: Throwable) { DebugLog.log("ProfileExportImport.importProfile: đăng ký hồ sơ giữ lại '$keepName' lỗi: ${e.javaClass.simpleName}: ${e.message}") }
                preservedAs = keepName; preservedDir = keepDir
                DebugLog.log("ProfileExportImport.importProfile: dữ liệu CŨ được GIỮ LẠI thành hồ sơ '$keepName' (KHÔNG xoá)")
            }
            if (!tmpDir.renameTo(targetDir)) {
                try { preservedDir?.let { if (!targetDir.exists()) it.renameTo(targetDir) } } catch (_: Throwable) {} // hoàn tác: trả dữ liệu cũ về chỗ cũ
                DebugLog.log("ProfileExportImport.importProfile: renameTo() THẤT BẠI — tmpDir='${tmpDir.absolutePath}' exists=${tmpDir.exists()}, targetDir='${targetDir.absolutePath}' exists=${targetDir.exists()} (nếu willOverwriteExisting=true và đã xoá targetDir ở trên mà rename vẫn lỗi, dữ liệu MỚI vẫn còn nguyên trong tmpDir, CHƯA bị mất — chỉ là chưa được đổi tên thành hồ sơ thật)")
                throw IllegalStateException("Không đổi tên được thư mục tạm sang hồ sơ thật (rename thất bại)")
            }
            ProfileSlots.addProfile(context, targetProfileName)
            preservedAs?.let { lastImportWarning = listOfNotNull(lastImportWarning, "Dữ liệu cũ được GIỮ thành hồ sơ '$it' (vào \"Đổi\" để dùng lại; xoá khi chắc chắn không cần)").joinToString(" — ") }
            /**
             * FIX LOG THẬT (đúng phê bình của người dùng): TRƯỚC ĐÂY nhánh
             * THÀNH CÔNG hoàn toàn IM LẶNG — không có dòng log nào xác nhận
             * "đã ghi đè/import xong", khiến không thể phân biệt qua log
             * giữa "đã chạy xong đúng" và "im lặng thất bại ở đâu đó chưa
             * bắt được". Log rõ số file cuối cùng + xác nhận đã gọi
             * addProfile() — nếu bấm ghi đè mà KHÔNG thấy đúng dòng này
             * trong log lần test tới, chắc chắn lỗi nằm ở TRƯỚC bước này
             * (đã có đủ log ở trên để biết chính xác chỗ nào).
             */
            DebugLog.log("ProfileExportImport.importProfile: HOÀN TẤT THÀNH CÔNG — '$targetProfileName' giờ có $profileDataFilesExtracted file profile_data/ tại '${targetDir.absolutePath}', đã đăng ký vào ProfileSlots")
            Result.success(Unit)
        } catch (e: Exception) {
            DebugLog.log("ProfileExportImport.importProfile lỗi: ${e.javaClass.simpleName}: ${e.message}")
            // Dọn sạch thư mục TẠM nếu còn — đảm bảo lần thử lại SAU không
            // bị chặn bởi rác của lần lỗi NÀY (đây chính là nguyên nhân gốc
            // của bug "báo có mà thực tế chưa có" — xem chú thích ở đầu hàm).
            // LƯU Ý: nhờ sửa đổi ở trên, nếu lỗi xảy ra TRƯỚC bước xoá
            // targetDir (tức trong lúc giải nén/AppPrefs), dữ liệu CŨ vẫn
            // CÒN NGUYÊN — không bị mất, đúng tinh thần "atomic" cho cả 2
            // nhánh import mới VÀ ghi đè.
            try {
                if (tmpDir.exists()) tmpDir.deleteRecursively()
            } catch (cleanupError: Throwable) {
                // Mở rộng từ Exception sang Throwable — đây CHÍNH XÁC là
                // dòng đã crash thật (AssertionError từ deleteRecursively()
                // khi 2 luồng import cùng tên đua nhau xoá/đổi tên cùng thư
                // mục giữa chừng — xem fix gốc ở ImportBackupService chặn
                // trùng tên). AssertionError là Error, không phải Exception,
                // nên catch cũ không bắt được, crash lọt thẳng ra ngoài.
                DebugLog.log("ProfileExportImport.importProfile: dọn tmpDir lỗi (không nghiêm trọng): ${cleanupError.javaClass.simpleName}: ${cleanupError.message}")
            }
            Result.failure(if (e is java.util.zip.ZipException) IllegalStateException("File backup bị hỏng (${e.message}) — thường do tải/chép chưa xong. Hãy xuất lại hoặc tải lại file rồi nhập lần nữa.") else e)
        }
    }

    // ===== Bản 7.61 — chống "ghi đè bằng bản backup hỏng làm chết cả hồ sơ cũ lẫn mới" (sự cố: máy lỗi bộ nhớ lúc xuất 'vpscolab691') =====
    private val CORRUPT_RE = Regex("(?i)malformed|corrupt|not a database|disk image|disk i/o|file is encrypted")

    /** null = ổn HOẶC chưa kết luận được (khoá/không mở được vì lý do khác); chuỗi = BẰNG CHỨNG file SQLite hỏng bên trong. */
    private fun sqliteProvenCorrupt(f: File, readWrite: Boolean): String? {
        var db: android.database.sqlite.SQLiteDatabase? = null
        return try {
            db = android.database.sqlite.SQLiteDatabase.openDatabase(
                f.absolutePath, null,
                if (readWrite) android.database.sqlite.SQLiteDatabase.OPEN_READWRITE else android.database.sqlite.SQLiteDatabase.OPEN_READONLY
            )
            db.rawQuery("PRAGMA quick_check(1)", null).use { c ->
                if (!c.moveToFirst()) null
                else { val r = c.getString(0) ?: ""; if (r.equals("ok", true)) null else r.take(120) }
            }
        } catch (e: Throwable) {
            val m = (e.javaClass.simpleName + ": " + (e.message ?: ""))
            if (CORRUPT_RE.containsMatchIn(m)) m.take(160) else { DebugLog.log("ProfileExportImport: kiểm SQLite '${f.name}' chưa kết luận được (${m.take(120)}) — coi như ổn"); null }
        } finally { try { db?.close() } catch (_: Throwable) {} }
    }

    /** Kiểm các .sqlite ở gốc thư mục profile đã giải nén. Trả (lỗi tệp quan trọng cookies.sqlite hoặc null, danh sách tệp KHÔNG quan trọng đã xoá vì hỏng). */
    private fun validateExtractedSqlite(dir: File): Pair<String?, List<String>> {
        var essentialBad: String? = null
        val removed = mutableListOf<String>()
        dir.listFiles()?.filter { it.isFile && it.name.endsWith(".sqlite") }?.forEach { f ->
            val err = sqliteProvenCorrupt(f, true)
            if (err != null) {
                DebugLog.log("ProfileExportImport.importProfile: ${f.name} HỎNG BÊN TRONG — $err")
                if (f.name == "cookies.sqlite") essentialBad = "${f.name}: $err"
                else { f.delete(); File(f.path + "-wal").delete(); File(f.path + "-shm").delete(); removed.add(f.name) } // Gecko tự tạo lại
            }
        }
        return essentialBad to removed
    }

    /** Đọc lại TOÀN BỘ file backup vừa ghi (ZipInputStream kiểm CRC từng tệp). null = đọc lại trọn vẹn. */
    private fun verifyBackupReadable(context: Context, uri: Uri): String? {
        return try {
            var n = 0
            val ins = context.contentResolver.openInputStream(uri) ?: return "không mở lại được file vừa ghi"
            ins.use {
                ZipInputStream(it).use { z ->
                    val buf = ByteArray(65536)
                    var e = z.nextEntry
                    while (e != null) { while (z.read(buf) >= 0) { /* chỉ để kiểm CRC */ }; n++; e = z.nextEntry }
                }
            }
            if (n == 0) "file zip không có tệp nào" else null
        } catch (e: Exception) { "${e.javaClass.simpleName}: ${e.message}" }
    }

    private fun uniquePreservedName(context: Context, base: String): String {
        val existing = ProfileSlots.listProfiles(context).toSet()
        var cand = base + "_cu"
        var i = 2
        while (cand in existing || File(context.filesDir, safeDirNameFor(cand)).exists()) { cand = base + "_cu" + i; i++ }
        return cand
    }

    /** Mục 145: chỉ khôi phục DẤU VÂN TAY (khoá fp_*) vào hồ sơ đích — KHÔNG đụng thư mục dữ liệu/cookie hiện có. */
    private fun importFingerprintOnly(context: Context, srcUri: Uri, targetProfileName: String): Result<Unit> {
        return try {
            val input = context.contentResolver.openInputStream(srcUri) ?: return Result.failure(IllegalStateException("Không mở được file đã chọn"))
            var fpMap: Map<String, Any?>? = null
            var contains: Boolean? = null
            input.use { ins ->
                ZipInputStream(ins).use { zip ->
                    var e: ZipEntry? = zip.nextEntry
                    while (e != null) {
                        when (e.name) {
                            "app_prefs.json" -> {
                                val json = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                                val m = mutableMapOf<String, Any?>()
                                json.keys().forEach { k -> if (FingerprintIdentity.isFingerprintKey(k)) m[k] = json.get(k) }
                                fpMap = m
                            }
                            "manifest.json" -> contains = try { JSONObject(zip.readBytes().toString(Charsets.UTF_8)).optBoolean("contains_fingerprint", true) } catch (ex: Exception) { null }
                        }
                        zip.closeEntry()
                        if (fpMap != null && contains != null) break
                        e = zip.nextEntry
                    }
                }
            }
            val m = fpMap
            if (m == null || m.isEmpty() || contains == false) {
                return Result.failure(IllegalStateException("File backup này KHÔNG chứa dấu vân tay (xuất với tuỳ chọn không kèm dấu vân tay, hoặc bản sao quá cũ)."))
            }
            val (restored, dropped) = AppPrefs.importNamespace(context, targetProfileName, m)
            if (!ProfileSlots.listProfiles(context).contains(targetProfileName)) ProfileSlots.addProfile(context, targetProfileName)
            DebugLog.log("ProfileExportImport.importFingerprintOnly: '$targetProfileName' khôi phục $restored khoá dấu vân tay (bỏ sót ${dropped.size}); KHÔNG đụng dữ liệu/cookie hiện có")
            Result.success(Unit)
        } catch (e: Exception) {
            DebugLog.log("ProfileExportImport.importFingerprintOnly lỗi: ${e.javaClass.simpleName}: ${e.message}")
            Result.failure(e)
        }
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, bytes: ByteArray) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(bytes)
        zip.closeEntry()
    }

    /** Trả về (số file đã zip, tổng byte GỐC trước nén, DANH SÁCH TÊN file
     * BỊ BỎ QUA vì khoá) để hàm gọi log tổng kết + hiện rõ TÊN file thiếu
     * cho người dùng (thay vì chỉ đếm số lượng — theo đúng yêu cầu:
     * "cái gì xuất thiếu, cái gì xuất rồi"). */
    private fun zipDirRecursive(zip: ZipOutputStream, dir: File, entryPrefix: String): Triple<Int, Long, List<String>> {
        val files = dir.listFiles() ?: run {
            DebugLog.log("ProfileExportImport.zipDirRecursive: listFiles() trả về NULL cho '${dir.absolutePath}' (không có quyền đọc, hoặc không phải thư mục) — bỏ qua toàn bộ nhánh này")
            return Triple(0, 0L, emptyList())
        }
        var fileCount = 0
        var byteCount = 0L
        val skippedNames = mutableListOf<String>()

        /**
         * BUG THẬT tìm ra (người dùng báo lại: "cùng 1 hồ sơ, trước import
         * vẫn đăng nhập Google được, giờ bị văng — nhưng hồ sơ KHÁC import
         * vẫn giữ đăng nhập bình thường"): chính mục 12 (đã tra cứu đúng —
         * SQLite WAL an toàn để copy trực tiếp lúc đang mở) đã tự nêu rõ
         * ĐIỀU KIỆN DUY NHẤT: "phải copy CẢ 3 FILE CÙNG LÚC (.sqlite +
         * .sqlite-wal + .sqlite-shm) — không được tách rời". Nhưng vòng
         * lặp bên dưới (trước khi sửa) thử lại + bỏ qua TỪNG FILE ĐỘC LẬP
         * — nếu đúng lúc `cookies.sqlite-wal` bị khoá LÂU HƠN 4 lần thử (~
         * 600ms, có thể xảy ra nếu phiên đăng nhập vừa xong dồn nhiều ghi
         * chưa checkpoint), nó bị BỎ QUA MỘT MÌNH trong khi
         * `cookies.sqlite`/`cookies.sqlite-shm` vẫn xuất được bình thường
         * — kết quả: đúng cái "2/3 file, tách rời" mà mục 12 tự nói là
         * KHÔNG ĐƯỢC XẢY RA, mất TOÀN BỘ phần ghi chưa checkpoint (có thể
         * là NGUYÊN phiên đăng nhập, không phải "tối đa 1 thao tác" như
         * mục 12 ước tính cho trường hợp cả 3 file cùng xuất được).
         *
         * Sửa: xác định các "bộ 3" WAL (`X.sqlite` + `X.sqlite-wal` +
         * `X.sqlite-shm`, nếu có tồn tại) và coi TOÀN BỘ 1 bộ là 1 ĐƠN VỊ
         * — thử lại CẢ BỘ cùng lúc, chỉ chấp nhận nếu TẤT CẢ thành viên
         * đang có mặt đều copy được trong CÙNG 1 lượt thử; nếu hết số lần
         * thử mà vẫn có thành viên lỗi, BỎ QUA CẢ BỘ (không xuất file
         * `.sqlite` chính một mình mà thiếu `-wal` đi kèm) — đúng yêu cầu
         * "cùng lúc hoặc không cái nào" mục 12 đã nêu, tránh bản chụp
         * nửa vời.
         */
        val handledAsWalGroup = mutableSetOf<String>()
        val byName = files.associateBy { it.name }
        for (f in files) {
            if (f.name in handledAsWalGroup) continue
            if (f.isDirectory) continue
            if (f.name.endsWith(".sqlite-wal") || f.name.endsWith(".sqlite-shm")) continue // xử lý khi gặp đúng file .sqlite gốc, không xử lý riêng ở đây
            if (!f.name.endsWith(".sqlite")) continue
            val walFile = byName["${f.name}-wal"]
            val shmFile = byName["${f.name}-shm"]
            if (walFile == null && shmFile == null) continue // .sqlite thường (không ở chế độ WAL/không có ghi dở) — xử lý như file thường ở nhánh dưới

            val group = listOfNotNull(f, walFile, shmFile)
            group.forEach { handledAsWalGroup.add(it.name) }
            var groupSucceeded = false
            var lastGroupException: Exception? = null
            for (attempt in 1..4) {
                val entriesWrittenThisAttempt = mutableListOf<Pair<String, Long>>()
                try {
                    for (member in group) {
                        val entryName = "$entryPrefix/${member.name}"
                        zip.putNextEntry(ZipEntry(entryName))
                        member.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                        entriesWrittenThisAttempt.add(entryName to member.length())
                    }
                    entriesWrittenThisAttempt.forEach { (_, len) -> byteCount += len; fileCount++ }
                    groupSucceeded = true
                    break
                } catch (e: Exception) {
                    lastGroupException = e
                    // 1 thành viên trong bộ lỗi giữa chừng — zip đã ghi dở entry
                    // của các thành viên TRƯỚC đó trong CÙNG lượt thử này, cần
                    // bỏ luôn để không lẫn với lượt thử SAU (ghi lại từ đầu).
                    // ZipOutputStream không hỗ trợ "xoá entry đã ghi", nên chấp
                    // nhận file zip xuất ra có thể có 1-2 entry trùng tên nếu
                    // lượt sau ghi lại — hành vi đọc lại zip (unzip chuẩn) vẫn
                    // lấy đúng entry SAU CÙNG nếu trùng tên, không hỏng dữ liệu.
                    if (attempt < 4) Thread.sleep(150L)
                }
            }
            if (!groupSucceeded) {
                DebugLog.log(
                    "Bỏ qua CẢ BỘ WAL khi xuất (đã thử lại 4 lần, vẫn có thành viên bị khoá): " +
                        group.joinToString(", ") { it.name } +
                        " — ${lastGroupException?.javaClass?.simpleName}: ${lastGroupException?.message} " +
                        "(xem mục 94 — bỏ CẢ BỘ thay vì bỏ riêng .sqlite-wal để không tạo bản chụp nửa vời)"
                )
                skippedNames.addAll(group.map { it.name })
            }
        }

        for (f in files) {
            if (f.name in handledAsWalGroup) continue
            val entryName = "$entryPrefix/${f.name}"
            if (f.isDirectory) {
                val (c, b, s) = zipDirRecursive(zip, f, entryName)
                fileCount += c
                byteCount += b
                skippedNames.addAll(s)
            } else {
                var lastException: Exception? = null
                var succeeded = false
                // Thử lại vài lần cách nhau ngắn TRƯỚC KHI chấp nhận bỏ qua —
                // khoá file do Gecko đang ghi dở thường chỉ tồn tại trong
                // khoảnh khắc rất ngắn (vài chục ms), thử lại có cơ hội thật
                // sự đọc được bản đã ổn định. (File .sqlite KHÔNG ở chế độ
                // WAL/không có -wal-shm đi kèm — xử lý riêng lẻ như cũ vẫn an
                // toàn, rủi ro "bản chụp nửa vời" ở mục 94 chỉ áp dụng cho bộ
                // 3 file WAL, đã tách xử lý riêng ở vòng lặp phía trên.)
                for (attempt in 1..4) {
                    try {
                        zip.putNextEntry(ZipEntry(entryName))
                        f.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                        fileCount++
                        byteCount += f.length()
                        succeeded = true
                        break
                    } catch (e: Exception) {
                        lastException = e
                        if (attempt < 4) Thread.sleep(150L)
                    }
                }
                if (!succeeded) {
                    // Gecko có thể đang khoá 1 vài file nếu hồ sơ đang chạy —
                    // bỏ qua file đó, không làm hỏng cả gói xuất.
                    DebugLog.log("Bỏ qua file khi xuất (đã thử lại 4 lần, vẫn bị khoá đúng lúc đọc): ${f.path} (${f.length()} byte) — ${lastException?.javaClass?.simpleName}: ${lastException?.message}")
                    skippedNames.add(f.name)
                }
            }
        }
        return Triple(fileCount, byteCount, skippedNames)
    }

    /** PHẢI khớp CHÍNH XÁC với `GeckoRuntimeProvider.safeDirNameFor` — trùng
     * logic vì đây là 2 lớp khác nhau, không dùng chung được (tránh vòng
     * phụ thuộc core<->core không cần thiết); nếu sửa 1 bên nhớ sửa bên kia. */
    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")
}
