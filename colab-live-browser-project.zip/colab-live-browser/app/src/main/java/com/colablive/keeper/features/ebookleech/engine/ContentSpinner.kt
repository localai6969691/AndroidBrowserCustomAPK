package com.colablive.keeper.features.ebookleech.engine

import java.util.Random

/**
 * ContentSpinner — "quay vòng nội dung" chống trùng lặp kiểu spinner
 * truyền thống: `{lựa chọn 1|lựa chọn 2|lựa chọn 3}` → mỗi lần gọi
 * `spin()`, mỗi cụm `{...}` được thay bằng 1 lựa chọn CHỌN NGẪU NHIÊN
 * trong đó (độc lập cho từng cụm nếu có nhiều cụm trong cùng 1 template).
 *
 * Dùng bởi `ContentProcessor` — 2 loại luật `RegexRule.Kind.SPIN_INSERT_PREFIX`/
 * `SPIN_INSERT_SUFFIX` (xem file đó), gọi lại `spin()` MỖI CHƯƠNG nên mỗi
 * chương ra 1 kết quả khác nhau, dù dùng chung 1 template cấu hình sẵn
 * trong job.
 *
 * CỐ Ý KHÔNG hỗ trợ lồng nhau (`{a|{b|c}}`) — cú pháp phẳng đã đủ cho nhu
 * cầu thật (chèn 1 câu mở/kết đa dạng cho mỗi chương) — hỗ trợ lồng nhau
 * cần 1 parser đệ quy phức tạp hơn nhiều cho lợi ích nhỏ so với nhu cầu.
 *
 * AN TOÀN: cụm `{...}` KHÔNG chứa dấu `|` bên trong bị bỏ qua (giữ nguyên
 * văn) — tránh nuốt nhầm dấu ngoặc `{ }` thường xuất hiện tự nhiên trong
 * CSS/JSON lẫn trong nội dung cào được, chỉ coi là cú pháp spin khi rõ
 * ràng có từ 2 lựa chọn trở lên.
 */
object ContentSpinner {
    private val SPIN_GROUP = Regex("""\{([^{}]*)}""")

    fun spin(template: String, random: Random = Random()): String {
        if (template.isBlank() || !template.contains('{')) return template
        return SPIN_GROUP.replace(template) { match ->
            val options = match.groupValues[1].split("|")
            if (options.size <= 1) match.value
            else options[random.nextInt(options.size)]
        }
    }
}
