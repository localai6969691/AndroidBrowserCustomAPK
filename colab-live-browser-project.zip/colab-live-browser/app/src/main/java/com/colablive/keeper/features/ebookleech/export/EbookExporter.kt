package com.colablive.keeper.features.ebookleech.export

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.colablive.keeper.features.ebookleech.model.LeechChapter
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.model.TocNode
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Xuất danh sách LeechChapter thành file ebook.
 * Hỗ trợ: EPUB (chuẩn, mục lục lồng nhau kiểu Volume/Part), TXT, HTML.
 *
 * MỤC LỤC: nếu job.tocOverride không rỗng (người dùng đã tự sắp xếp qua màn
 * hình "Xem trước & sắp xếp mục lục"), dùng đúng cấu trúc đó — kể cả việc
 * gộp nhóm (Volume), đổi tên hiển thị, và LOẠI chương không có trong cây ra
 * khỏi ebook hoàn toàn. Nếu rỗng → mặc định phẳng theo đúng thứ tự cào
 * (hành vi y hệt bản gốc, không phá vỡ tương thích ngược).
 *
 * Output thư mục: Downloads/EbookLeech/<job_name>/
 */
object EbookExporter {

    /**
     * ĐÃ SỬA (mục nợ kỹ thuật 5.2 cũ): trước đây ghi thẳng bằng `File` API
     * vào thư mục công khai `Downloads/EbookLeech/...` — hoạt động trên
     * Android < 10, nhưng bị Scoped Storage CHẶN trên targetSdk ≥ 30 (ghi
     * thất bại âm thầm hoặc `SecurityException` tuỳ thiết bị). Giờ LUÔN
     * ghi ra thư mục cache RIÊNG của app trước (không cần quyền, hoạt động
     * mọi phiên bản Android), rồi `publishStagingTree()` chuyển vào đích
     * thật — chọn đường ghi đúng theo API level (xem hàm đó).
     */
    fun export(context: Context, job: LeechJob, chapters: List<LeechChapter>): String {
        val toc = resolveToc(job, chapters)
        val orderedIndexes = TocNode.flattenChapterOrder(toc)
        val chaptersByIndex = chapters.associateBy { it.index }
        val includedChapters = orderedIndexes.mapNotNull { chaptersByIndex[it] }

        val stagingRoot = File(context.cacheDir, "ebookleech_staging/${job.id}_${System.currentTimeMillis()}")
        stagingRoot.mkdirs()

        val (stagedMainFile, mainMime) = when (job.outputFormat) {
            LeechJob.OutputFormat.EPUB -> File(exportEpub(job, includedChapters, toc, stagingRoot)) to "application/epub+zip"
            LeechJob.OutputFormat.TXT  -> File(exportTxt(job, includedChapters, toc, stagingRoot)) to "text/plain"
            LeechJob.OutputFormat.HTML -> File(exportHtml(job, includedChapters, toc, stagingRoot)) to "text/html"
        }

        val relativeSubDir = "EbookLeech/${sanitizeFileName(job.name)}"
        val publishedMainPath = publishStagingTree(context, stagingRoot, relativeSubDir, stagedMainFile, mainMime)
        stagingRoot.deleteRecursively()  // dọn cache — bản thật đã nằm ở đích (thư mục công khai hoặc MediaStore)
        return publishedMainPath
    }

    /**
     * Publish TOÀN BỘ cây thư mục tạm (file xuất chính + mọi file phụ, vd
     * `images/` của bản HTML) sang đích cuối cùng, giữ đúng cấu trúc thư
     * mục con tương đối (`images/x.jpg` vẫn nằm dưới `images/` ở đích, nên
     * link ảnh tương đối trong HTML không bị hỏng). Trả về đường dẫn/URI
     * của đúng file CHÍNH (khớp `mainFile`) — vd để hiện trong UI/notification.
     */
    private fun publishStagingTree(
        context: Context, stagingRoot: File, relativeSubDir: String, mainFile: File, mainMime: String,
    ): String {
        var mainDest = ""
        stagingRoot.walkTopDown().filter { it.isFile }.forEach { f ->
            val relPath = f.relativeTo(stagingRoot).path.replace(File.separatorChar, '/')
            val subDir = if (relPath.contains('/')) "$relativeSubDir/${relPath.substringBeforeLast('/')}" else relativeSubDir
            val mime = if (f == mainFile) mainMime else guessMime(f.name)
            val dest = publishOneFile(context, subDir, f, mime)
            if (f == mainFile) mainDest = dest
        }
        return mainDest
    }

    /**
     * Ghi 1 file từ staging (cache riêng của app) vào đích cuối cùng.
     *
     * - Android < 10 (API < 29): Scoped Storage CHƯA áp dụng — `File` API
     *   ghi thẳng vào thư mục công khai vẫn hoạt động, giữ nguyên hành vi
     *   cũ (trả về đường dẫn filesystem thật, `File(path).exists()` dùng
     *   được như trước).
     * - Android 10+ (API ≥ 29, BẮT BUỘC với targetSdk ≥ 30): PHẢI qua
     *   `MediaStore.Downloads` — insert 1 bản ghi với `RELATIVE_PATH` giữ
     *   đúng cấu trúc thư mục con, rồi copy byte qua `ContentResolver`.
     *   Trả về `content://` URI dạng chuỗi thay vì đường dẫn filesystem —
     *   `EbookLeechSettingsView.openFile()`/kiểm tra tồn tại đã được sửa
     *   để nhận diện và xử lý đúng cả 2 dạng (xem hàm đó).
     */
    private fun publishOneFile(context: Context, relativeSubDir: String, stagedFile: File, mimeType: String): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val legacyDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), relativeSubDir)
            if (!legacyDir.exists()) legacyDir.mkdirs()
            val dest = File(legacyDir, stagedFile.name)
            stagedFile.copyTo(dest, overwrite = true)
            return dest.absolutePath
        }
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, stagedFile.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$relativeSubDir")
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw java.io.IOException("MediaStore từ chối tạo file ${stagedFile.name} (insert trả về null)")
        resolver.openOutputStream(uri)?.use { out -> stagedFile.inputStream().use { input -> input.copyTo(out) } }
            ?: throw java.io.IOException("Không mở được OutputStream cho $uri")
        return uri.toString()
    }

    private fun guessMime(name: String): String = when {
        name.endsWith(".jpg", true) || name.endsWith(".jpeg", true) -> "image/jpeg"
        name.endsWith(".png", true) -> "image/png"
        name.endsWith(".gif", true) -> "image/gif"
        name.endsWith(".webp", true) -> "image/webp"
        else -> "application/octet-stream"
    }

    /** Mặc định (không có tocOverride): 1 node phẳng / chương, đúng thứ tự cào. */
    private fun resolveToc(job: LeechJob, chapters: List<LeechChapter>): List<TocNode> =
        job.tocOverride.ifEmpty {
            chapters.map { TocNode(id = "auto_${it.index}", label = it.title, chapterIndex = it.index) }
        }

    // -------------------------------------------------------------------------
    // EPUB — định dạng chuẩn, mở được trên mọi ebook reader
    // -------------------------------------------------------------------------

    private fun exportEpub(job: LeechJob, chapters: List<LeechChapter>, toc: List<TocNode>, outDir: File): String {
        val fileName = buildFileName(job, "epub")
        val outFile = File(outDir, fileName)

        ZipOutputStream(FileOutputStream(outFile)).use { zip ->

            zip.putNextEntry(ZipEntry("mimetype").apply { method = ZipEntry.STORED; size = 20; crc = crcOf("application/epub+zip") })
            zip.write("application/epub+zip".toByteArray())
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("META-INF/container.xml"))
            zip.write(containerXml().toByteArray())
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("OEBPS/content.opf"))
            zip.write(contentOpf(job, chapters).toByteArray())
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("OEBPS/toc.ncx"))
            zip.write(tocNcx(job, toc).toByteArray())
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("OEBPS/nav.xhtml"))
            zip.write(navXhtml(job, toc).toByteArray())
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("OEBPS/css/style.css"))
            zip.write(epubCss().toByteArray())
            zip.closeEntry()

            // Chỉ ghi chương thực sự nằm trong cây mục lục (chương bị loại
            // qua màn hình sắp xếp sẽ KHÔNG có mặt trong file EPUB luôn)
            chapters.forEach { ch ->
                zip.putNextEntry(ZipEntry("OEBPS/chapter_${ch.index}.xhtml"))
                zip.write(chapterXhtml(ch).toByteArray())
                zip.closeEntry()
            }

            chapters.forEach { ch ->
                ch.images.forEach { img ->
                    zip.putNextEntry(ZipEntry("OEBPS/images/${img.localFileName}"))
                    zip.write(img.bytes)
                    zip.closeEntry()
                }
            }
        }

        return outFile.absolutePath
    }

    private fun containerXml() = """
        <?xml version="1.0" encoding="UTF-8"?>
        <container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
          <rootfiles>
            <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
          </rootfiles>
        </container>
    """.trimIndent()

    private fun contentOpf(job: LeechJob, chapters: List<LeechChapter>): String {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val manifestItems = chapters.joinToString("\n    ") { ch ->
            """<item id="chapter_${ch.index}" href="chapter_${ch.index}.xhtml" media-type="application/xhtml+xml"/>"""
        }
        val imageManifestItems = chapters.flatMap { it.images }.joinToString("\n    ") { img ->
            """<item id="img_${img.localFileName.replace(".", "_")}" href="images/${img.localFileName}" media-type="${img.mimeType}"/>"""
        }
        // Thứ tự spine = đúng thứ tự trong "chapters" đã được sắp theo cây TOC
        // (đã flatten DFS ở export()) — đây chính là chỗ "mục lục theo yêu
        // cầu khi cào" tác động tới trải nghiệm đọc thật, không chỉ hiển thị.
        val spineItems = chapters.joinToString("\n    ") { ch ->
            """<itemref idref="chapter_${ch.index}"/>"""
        }
        return """
            <?xml version="1.0" encoding="UTF-8"?>
            <package version="3.0" xmlns="http://www.idpf.org/2007/opf" unique-identifier="uid">
              <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
                <dc:title>${escapeXml(job.name)}</dc:title>
                <dc:language>vi</dc:language>
                <dc:date>$date</dc:date>
                <dc:identifier id="uid">${job.id}</dc:identifier>
                <meta property="dcterms:modified">${date}T00:00:00Z</meta>
              </metadata>
              <manifest>
                <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
                <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
                <item id="css" href="css/style.css" media-type="text/css"/>
                $manifestItems
                $imageManifestItems
              </manifest>
              <spine toc="ncx">
                $spineItems
              </spine>
            </package>
        """.trimIndent()
    }

    /** NCX hỗ trợ navPoint LỒNG NHAU — Volume là navPoint cha chứa các navPoint chương con. */
    private fun tocNcx(job: LeechJob, toc: List<TocNode>): String {
        val playOrderCounter = intArrayOf(1)
        val navPoints = renderNcxNavPoints(toc, playOrderCounter)
        return """
            <?xml version="1.0" encoding="UTF-8"?>
            <ncx version="2005-1" xmlns="http://www.daisy.org/z3986/2005/ncx/">
              <head>
                <meta name="dtb:uid" content="${job.id}"/>
                <meta name="dtb:depth" content="${tocDepth(toc)}"/>
                <meta name="dtb:totalPageCount" content="0"/>
                <meta name="dtb:maxPageNumber" content="0"/>
              </head>
              <docTitle><text>${escapeXml(job.name)}</text></docTitle>
              <navMap>
                $navPoints
              </navMap>
            </ncx>
        """.trimIndent()
    }

    private fun renderNcxNavPoints(nodes: List<TocNode>, counter: IntArray): String =
        nodes.joinToString("\n") { node ->
            val order = counter[0]++
            if (node.chapterIndex != null) {
                """
                <navPoint id="np_${node.id}" playOrder="$order">
                  <navLabel><text>${escapeXml(node.label)}</text></navLabel>
                  <content src="chapter_${node.chapterIndex}.xhtml"/>
                </navPoint>
                """.trimIndent()
            } else {
                // Node nhóm (Volume): trỏ content vào chương đầu tiên bên
                // trong nó để reader không lỗi khi bấm vào tên Volume.
                val firstLeaf = TocNode.flattenChapterOrder(listOf(node)).firstOrNull()
                val childrenXml = renderNcxNavPoints(node.children, counter)
                """
                <navPoint id="np_${node.id}" playOrder="$order">
                  <navLabel><text>${escapeXml(node.label)}</text></navLabel>
                  <content src="${if (firstLeaf != null) "chapter_$firstLeaf.xhtml" else "nav.xhtml"}"/>
                  $childrenXml
                </navPoint>
                """.trimIndent()
            }
        }

    private fun tocDepth(nodes: List<TocNode>, current: Int = 1): Int {
        val childDepths = nodes.filter { it.children.isNotEmpty() }.map { tocDepth(it.children, current + 1) }
        return (childDepths + current).max()
    }

    /** nav.xhtml (EPUB3) — <ol><li> lồng nhau, Volume hiện dạng <span> không click được. */
    private fun navXhtml(job: LeechJob, toc: List<TocNode>): String {
        return """
            <?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE html>
            <html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
            <head><title>Mục lục</title></head>
            <body>
              <nav epub:type="toc">
                <h1>${escapeXml(job.name)} — Mục lục</h1>
                <ol>
                  ${renderNavItems(toc)}
                </ol>
              </nav>
            </body>
            </html>
        """.trimIndent()
    }

    private fun renderNavItems(nodes: List<TocNode>): String =
        nodes.joinToString("\n        ") { node ->
            if (node.chapterIndex != null) {
                """<li><a href="chapter_${node.chapterIndex}.xhtml">${escapeXml(node.label)}</a></li>"""
            } else {
                """<li><span>${escapeXml(node.label)}</span><ol>${renderNavItems(node.children)}</ol></li>"""
            }
        }

    private fun chapterXhtml(ch: LeechChapter): String = """
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE html>
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
          <title>${escapeXml(ch.title)}</title>
          <link rel="stylesheet" type="text/css" href="css/style.css"/>
        </head>
        <body>
          <h2>${escapeXml(ch.title)}</h2>
          ${ch.htmlContent}
        </body>
        </html>
    """.trimIndent()

    private fun epubCss() = """
        body { font-family: Georgia, serif; line-height: 1.8; margin: 1em 1.5em; color: #222; }
        h2 { font-size: 1.3em; border-bottom: 1px solid #ccc; padding-bottom: 0.3em; margin-bottom: 1em; }
        p { margin: 0 0 0.8em 0; text-indent: 1.5em; }
        img { max-width: 100%; }
    """.trimIndent()

    // -------------------------------------------------------------------------
    // TXT — plain text, giữ cấu trúc Volume bằng heading đơn giản
    // -------------------------------------------------------------------------

    private fun exportTxt(job: LeechJob, chapters: List<LeechChapter>, toc: List<TocNode>, outDir: File): String {
        val fileName = buildFileName(job, "txt")
        val outFile = File(outDir, fileName)
        val chaptersByIndex = chapters.associateBy { it.index }
        outFile.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("${job.name}\n")
            w.write("=".repeat(60) + "\n\n")
            writeTxtNodes(w, toc, chaptersByIndex, depth = 0)
        }
        return outFile.absolutePath
    }

    private fun writeTxtNodes(w: java.io.BufferedWriter, nodes: List<TocNode>, byIndex: Map<Int, LeechChapter>, depth: Int) {
        nodes.forEach { node ->
            if (node.chapterIndex != null) {
                val ch = byIndex[node.chapterIndex] ?: return@forEach
                w.write("${node.label}\n")
                w.write("-".repeat(40) + "\n")
                w.write(ch.textContent)
                w.write("\n\n\n")
            } else {
                w.write("\n${"#".repeat(depth + 1)} ${node.label}\n")
                w.write("=".repeat(50) + "\n\n")
                writeTxtNodes(w, node.children, byIndex, depth + 1)
            }
        }
    }

    // -------------------------------------------------------------------------
    // HTML — single file, mục lục lồng nhau bằng <ol> nested
    // -------------------------------------------------------------------------

    private fun exportHtml(job: LeechJob, chapters: List<LeechChapter>, toc: List<TocNode>, outDir: File): String {
        val fileName = buildFileName(job, "html")
        val outFile = File(outDir, fileName)
        val chaptersByIndex = chapters.associateBy { it.index }

        val hasImages = chapters.any { it.images.isNotEmpty() }
        if (hasImages) {
            val imgDir = File(outDir, "images")
            if (!imgDir.exists()) imgDir.mkdirs()
            chapters.forEach { ch -> ch.images.forEach { img -> File(imgDir, img.localFileName).writeBytes(img.bytes) } }
        }

        outFile.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("""
                <!DOCTYPE html>
                <html lang="vi">
                <head>
                  <meta charset="UTF-8">
                  <title>${escapeXml(job.name)}</title>
                  <style>
                    body { max-width: 720px; margin: 0 auto; padding: 2rem 1rem;
                           font-family: Georgia, serif; line-height: 1.8; color: #1a1a1a; }
                    h1 { font-size: 2em; }
                    h2 { font-size: 1.4em; margin-top: 3em; border-bottom: 1px solid #ddd;
                         padding-bottom: 0.3em; }
                    p { text-indent: 1.5em; margin: 0 0 0.7em 0; }
                    #toc { background: #f9f9f9; border: 1px solid #e0e0e0;
                           padding: 1rem 1.5rem; border-radius: 6px; margin-bottom: 3em; }
                    #toc a { text-decoration: none; color: #2563eb; }
                    #toc a:hover { text-decoration: underline; }
                    #toc ol ol { margin-left: 1em; }
                    #toc span.vol { font-weight: bold; display: block; margin-top: 0.5em; }
                  </style>
                </head>
                <body>
                  <h1>${escapeXml(job.name)}</h1>
                  <div id="toc">
                    <strong>Mục lục</strong>
                    <ol>
                      ${renderHtmlTocItems(toc)}
                    </ol>
                  </div>
            """.trimIndent())

            writeHtmlChapterBodies(w, toc, chaptersByIndex)

            w.write("</body></html>")
        }
        return outFile.absolutePath
    }

    private fun renderHtmlTocItems(nodes: List<TocNode>): String =
        nodes.joinToString("\n") { node ->
            if (node.chapterIndex != null)
                """<li><a href="#ch${node.chapterIndex}">${escapeXml(node.label)}</a></li>"""
            else
                """<li><span class="vol">${escapeXml(node.label)}</span><ol>${renderHtmlTocItems(node.children)}</ol></li>"""
        }

    private fun writeHtmlChapterBodies(w: java.io.BufferedWriter, nodes: List<TocNode>, byIndex: Map<Int, LeechChapter>) {
        nodes.forEach { node ->
            if (node.chapterIndex != null) {
                val ch = byIndex[node.chapterIndex] ?: return@forEach
                w.write("""  <h2 id="ch${ch.index}">${escapeXml(node.label)}</h2>""" + "\n")
                w.write("  " + ch.htmlContent + "\n\n")
            } else {
                w.write("""  <h1 style="margin-top:3em">${escapeXml(node.label)}</h1>""" + "\n")
                writeHtmlChapterBodies(w, node.children, byIndex)
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private fun buildFileName(job: LeechJob, ext: String): String {
        val base = job.outputFileName.ifBlank { sanitizeFileName(job.name) }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        return "${base}_${stamp}.$ext"
    }

    /**
     * Chuẩn hoá tên file — GIỮ LẠI dấu tiếng Việt (bản cũ dùng \\w nên xoá
     * mất dấu, chỉ còn khung xương không dấu). Chỉ loại ký tự thật sự không
     * hợp lệ trong tên file (/ \ : * ? " < > |) và khoảng trắng thừa.
     */
    private fun sanitizeFileName(name: String): String =
        name.replace(Regex("""[/\\:*?"<>|]"""), "")
            .trim()
            .replace(Regex("\\s+"), "_")
            .ifBlank { "ebook" }

    private fun escapeXml(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
         .replace("\"", "&quot;").replace("'", "&apos;")

    private fun crcOf(s: String): Long {
        val crc = java.util.zip.CRC32()
        crc.update(s.toByteArray())
        return crc.value
    }
}
