package com.colablive.keeper.features.ebookleech.export

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.colablive.keeper.features.ebookleech.model.LeechChapter
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.model.StoryMeta
import com.colablive.keeper.features.ebookleech.model.StoryMetaStore
import com.colablive.keeper.features.ebookleech.model.TocNode
import com.colablive.keeper.core.BuildMarker
import java.io.File

/**
 * Xuất danh sách LeechChapter thành file ebook.
 * Hỗ trợ: EPUB (chuẩn, mục lục lồng nhau kiểu Volume/Part), TXT, HTML.
 *
 * MỤC LỤC: nếu job.tocOverride không rỗng (người dùng đã tự sắp xếp qua màn
 * hình "Xem trước & sắp xếp mục lục"), dùng đúng cấu trúc đó — kể cả việc
 * gộp nhóm (Volume), đổi tên hiển thị, và LOẠI chương không có trong cây ra
 * khỏi ebook hoàn toàn. Nếu rỗng → mặc định phẳng theo đúng thứ tự cào
 * (hành vi y hệt bản gốc, không phá vỡ tương thích ngược).
 *
 * Output thư mục: Downloads/EbookLeech/<job_name>/
 *
 * Bản 7.104 — thêm THÔNG TIN TRUYỆN (tác giả, tóm tắt, thể loại, tag, tình trạng, đánh giá, bìa): EPUB có siêu dữ liệu OPF + bìa + trang "Giới thiệu", TXT/HTML có phần đầu, và file kèm
 * `<tên>.story.json` (+ `<tên>.cover.<đuôi>`) để đăng lên web truyện. Chi tiết: EbookMarkup / EbookStaging.
 *
 * Bản 7.102 — `job.updateExistingFile`: file có TÊN CỐ ĐỊNH (không dấu thời gian) và mỗi lần xuất GHI ĐÈ lên file cùng tên ở cùng thư mục (tìm lại qua MediaStore), thay vì tạo file mới.
 * Ebook luôn được dựng lại TOÀN BỘ từ danh sách chương (cũ + mới) rồi ghi đè — kết quả giống hệt "nối thêm chương vào file cũ" (EPUB là file zip, "nối" thật cũng phải ghi lại
 * zip và mục lục). Không ghi đè được (file không còn, hoặc thuộc bản cài app khác) thì tạo file mới như bình thường.
 */
object EbookExporter {

    /**
     * ĐÃ SỬA (mục nợ kỹ thuật 5.2 cũ): trước đây ghi thẳng bằng `File` API
     * vào thư mục công khai `Downloads/EbookLeech/...` — hoạt động trên
     * Android < 10, nhưng bị Scoped Storage CHẶN trên targetSdk ≥ 30 (ghi
     * thất bại âm thầm hoặc `SecurityException` tuỳ thiết bị). Giờ LUÔN
     * ghi ra thư mục cache RIÊNG của app trước (không cần quyền, hoạt động
     * mọi phiên bản Android), rồi `publishStagingTree()` chuyển vào đích
     * thật — chọn đường ghi đúng theo API level (xem hàm đó).
     */
    fun export(context: Context, job: LeechJob, chapters: List<LeechChapter>): String {
        val toc = resolveToc(job, chapters)
        val orderedIndexes = TocNode.flattenChapterOrder(toc)
        val chaptersByIndex = chapters.associateBy { it.index }
        val includedChapters = orderedIndexes.mapNotNull { chaptersByIndex[it] }

        val stagingRoot = File(context.cacheDir, "ebookleech_staging/${job.id}_${System.currentTimeMillis()}")
        stagingRoot.mkdirs()

        // Bản 7.104: thông tin truyện + bìa lưu theo job (do crawler cục bộ / RemoteCrawlRunner ghi) — không có thì xuất như trước (không trang giới thiệu).
        val stored = try { StoryMetaStore.load(context, job.id) } catch (e: Exception) { null }
        val staged = EbookStaging.stage(
            job, includedChapters, toc, stored?.meta ?: StoryMeta(), stored?.cover, stagingRoot, System.currentTimeMillis(),
            generator = "colab-live-browser/EbookLeech ${BuildMarker.VERSION}",
        )

        val relativeSubDir = "EbookLeech/${EbookStaging.sanitizeFileName(job.name)}"
        val publishedMainPath = publishStagingTree(context, stagingRoot, relativeSubDir, staged.mainFile, staged.mainMime, replaceExisting = job.updateExistingFile)
        stagingRoot.deleteRecursively()  // dọn cache — bản thật đã nằm ở đích (thư mục công khai hoặc MediaStore)
        return publishedMainPath
    }

    /**
     * Publish TOÀN BỘ cây thư mục tạm (file xuất chính + mọi file phụ, vd
     * `images/` của bản HTML) sang đích cuối cùng, giữ đúng cấu trúc thư
     * mục con tương đối (`images/x.jpg` vẫn nằm dưới `images/` ở đích, nên
     * link ảnh tương đối trong HTML không bị hỏng). Trả về đường dẫn/URI
     * của đúng file CHÍNH (khớp `mainFile`) — vd để hiện trong UI/notification.
     */
    private fun publishStagingTree(
        context: Context, stagingRoot: File, relativeSubDir: String, mainFile: File, mainMime: String, replaceExisting: Boolean = false,
    ): String {
        var mainDest = ""
        stagingRoot.walkTopDown().filter { it.isFile }.forEach { f ->
            val relPath = f.relativeTo(stagingRoot).path.replace(File.separatorChar, '/')
            val subDir = if (relPath.contains('/')) "$relativeSubDir/${relPath.substringBeforeLast('/')}" else relativeSubDir
            val mime = if (f == mainFile) mainMime else guessMime(f.name)
            val dest = publishOneFile(context, subDir, f, mime, replaceExisting)
            if (f == mainFile) mainDest = dest
        }
        return mainDest
    }

    /**
     * Ghi 1 file từ staging (cache riêng của app) vào đích cuối cùng.
     *
     * - Android < 10 (API < 29): Scoped Storage CHƯA áp dụng — `File` API
     *   ghi thẳng vào thư mục công khai vẫn hoạt động, giữ nguyên hành vi
     *   cũ (trả về đường dẫn filesystem thật, `File(path).exists()` dùng
     *   được như trước).
     * - Android 10+ (API ≥ 29, BẮT BUỘC với targetSdk ≥ 30): PHẢI qua
     *   `MediaStore.Downloads` — insert 1 bản ghi với `RELATIVE_PATH` giữ
     *   đúng cấu trúc thư mục con, rồi copy byte qua `ContentResolver`.
     *   Trả về `content://` URI dạng chuỗi thay vì đường dẫn filesystem —
     *   `EbookLeechSettingsView.openFile()`/kiểm tra tồn tại đã được sửa
     *   để nhận diện và xử lý đúng cả 2 dạng (xem hàm đó).
     */
    private fun publishOneFile(context: Context, relativeSubDir: String, stagedFile: File, mimeType: String, replaceExisting: Boolean = false): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val legacyDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), relativeSubDir)
            if (!legacyDir.exists()) legacyDir.mkdirs()
            val dest = File(legacyDir, stagedFile.name)
            stagedFile.copyTo(dest, overwrite = true)
            return dest.absolutePath
        }
        val resolver = context.contentResolver
        if (replaceExisting) {
            // Bản 7.102: tìm bản ghi cùng tên + cùng thư mục do CHÍNH app này đã tạo rồi ghi đè ("wt" = cắt về 0 rồi ghi). Không thấy / không ghi được => rơi xuống tạo mới bên dưới.
            val existing = findExistingDownload(resolver, "${Environment.DIRECTORY_DOWNLOADS}/$relativeSubDir", stagedFile.name)
            if (existing != null) {
                try {
                    resolver.openOutputStream(existing, "wt")?.use { out -> stagedFile.inputStream().use { input -> input.copyTo(out) } }
                        ?: throw java.io.IOException("Không mở được OutputStream để ghi đè $existing")
                    return existing.toString()
                } catch (e: Exception) { /* không ghi đè được (file bị khoá/không còn quyền) — tạo file mới thay vì mất lần xuất này */ }
            }
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, stagedFile.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$relativeSubDir")
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw java.io.IOException("MediaStore từ chối tạo file ${stagedFile.name} (insert trả về null)")
        resolver.openOutputStream(uri)?.use { out -> stagedFile.inputStream().use { input -> input.copyTo(out) } }
            ?: throw java.io.IOException("Không mở được OutputStream cho $uri")
        return uri.toString()
    }

    /** Tìm trong MediaStore.Downloads bản ghi (của chính app) có đúng tên + thư mục tương đối; RELATIVE_PATH có thể được lưu kèm hoặc không kèm dấu `/` cuối nên thử cả hai. */
    private fun findExistingDownload(resolver: ContentResolver, relativePath: String, displayName: String): Uri? {
        val trimmed = relativePath.trimEnd('/')
        val selection = "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH} IN (?, ?)"
        val args = arrayOf(displayName, trimmed, "$trimmed/")
        return try {
            resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.MediaColumns._ID), selection, args, null)?.use { c ->
                if (c.moveToFirst()) ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0)) else null
            }
        } catch (e: Exception) { null }
    }

    private fun guessMime(name: String): String = when {
        name.endsWith(".jpg", true) || name.endsWith(".jpeg", true) -> "image/jpeg"
        name.endsWith(".png", true) -> "image/png"
        name.endsWith(".gif", true) -> "image/gif"
        name.endsWith(".webp", true) -> "image/webp"
        name.endsWith(".json", true) -> "application/json"
        else -> "application/octet-stream"
    }

    /** Mặc định (không có tocOverride): 1 node phẳng / chương, đúng thứ tự cào. */
    private fun resolveToc(job: LeechJob, chapters: List<LeechChapter>): List<TocNode> =
        job.tocOverride.ifEmpty {
            chapters.map { TocNode(id = "auto_${it.index}", label = it.title, chapterIndex = it.index) }
        }

    // Việc DỰNG file (EPUB/TXT/HTML + file kèm thông tin truyện) nằm ở EbookStaging/EbookMarkup (thuần java.io, kiểm được trên JVM) — bản 7.104.
}
