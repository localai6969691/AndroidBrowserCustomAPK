package com.colablive.keeper.features.ebookleech.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * Bản 7.104 — THÔNG TIN TRUYỆN lưu cùng ebook (tác giả, tóm tắt, thể loại, tag, tình trạng, đánh giá, bìa...), để ebook làm nguyên liệu đăng lên web truyện.
 *
 * Lược đồ GIỐNG HỆT bản Python (crawler.py / LeechDesk): cùng tên trường JSON, nên checkpoint từ runner Python đọc thẳng được và job gửi lên runner Python mang theo được.
 * Mọi trường đều TUỲ CHỌN (rỗng = chưa biết). `sources` ghi nguồn của từng trường (selector / jsonld / og / meta / itemprop / label / h1 / manual) để bên nhập liệu biết độ tin cậy.
 *
 * Thứ tự gộp ([merge]): lần trước (lấp chỗ trống) < mới trích được < người dùng nhập tay (thắng tất cả).
 */
data class StoryRating(val value: Double, val scale: Double, val count: Long? = null) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("value", value); put("scale", scale)
        if (count != null) put("count", count)
    }
    companion object {
        fun fromJson(o: JSONObject?): StoryRating? {
            if (o == null || !o.has("value")) return null
            val v = o.optDouble("value", Double.NaN)
            if (v.isNaN()) return null
            val sc = o.optDouble("scale", 0.0).let { if (it > 0.0) it else if (v <= 5.0) 5.0 else if (v <= 10.0) 10.0 else 100.0 }
            val c = if (o.has("count")) o.optLong("count", -1L).takeIf { it >= 0L } else null
            return StoryRating(v, sc, c)
        }
    }
}

data class StoryMeta(
    val title: String = "",
    val author: String = "",
    val summary: String = "",          // văn bản thuần, các dòng cách nhau bằng \n
    val summaryHtml: String = "",      // <p>...</p> đã escape (sinh từ summary)
    val genres: List<String> = emptyList(),
    val tags: List<String> = emptyList(),
    val status: String = "",           // ongoing | completed | hiatus | dropped | "" (chưa rõ)
    val statusText: String = "",       // nguyên văn trên trang ("Đang ra"...)
    val rating: StoryRating? = null,
    val language: String = "",         // mã 2-3 chữ: vi, en...
    val sourceUrl: String = "",
    val sourceSite: String = "",
    val coverUrl: String = "",
    val coverFile: String = "",        // tên file ảnh bìa đã tải (cover.jpg...) — nằm cạnh ảnh chương ở runner Python
    val coverMime: String = "",
    val altTitles: List<String> = emptyList(),
    val series: String = "",
    val seriesIndex: Double? = null,
    val publishedAt: String = "",      // ISO (yyyy-mm-dd hoặc đầy đủ) nếu đọc được
    val updatedAt: String = "",
    val translator: String = "",
    val publisher: String = "",
    val extra: Map<String, String> = emptyMap(),    // trường tuỳ ý người dùng khai báo bằng selector (lượt xem, số theo dõi...)
    val sources: Map<String, String> = emptyMap(),
    val fetchedAt: Long = 0L,
) {
    /** Không có trường nội dung nào (bỏ qua sourceUrl/sourceSite/language/sources/fetchedAt vì trang nào cũng có). */
    fun isBlank(): Boolean = title.isBlank() && author.isBlank() && summary.isBlank() && genres.isEmpty() && tags.isEmpty() && status.isBlank() &&
        rating == null && coverUrl.isBlank() && coverFile.isBlank() && altTitles.isEmpty() && series.isBlank() && translator.isBlank() &&
        publisher.isBlank() && publishedAt.isBlank() && updatedAt.isBlank() && extra.isEmpty()

    fun toJson(): JSONObject = JSONObject().apply {
        fun s(k: String, v: String) { if (v.isNotBlank()) put(k, v) }
        fun l(k: String, v: List<String>) { if (v.isNotEmpty()) put(k, JSONArray(v)) }
        s("title", title); s("author", author); s("summary", summary); s("summaryHtml", summaryHtml)
        l("genres", genres); l("tags", tags); s("status", status); s("statusText", statusText)
        if (rating != null) put("rating", rating.toJson())
        s("language", language); s("sourceUrl", sourceUrl); s("sourceSite", sourceSite)
        s("coverUrl", coverUrl); s("coverFile", coverFile); s("coverMime", coverMime)
        l("altTitles", altTitles); s("series", series)
        if (seriesIndex != null) put("seriesIndex", seriesIndex)
        s("publishedAt", publishedAt); s("updatedAt", updatedAt); s("translator", translator); s("publisher", publisher)
        if (extra.isNotEmpty()) put("extra", JSONObject(extra))
        if (sources.isNotEmpty()) put("sources", JSONObject(sources))
        if (fetchedAt > 0L) put("fetchedAt", fetchedAt)
        put("schema", SCHEMA)
    }

    companion object {
        const val SCHEMA = 1

        private fun strList(a: JSONArray?): List<String> =
            if (a == null) emptyList() else (0 until a.length()).map { a.getString(it).trim() }.filter { it.isNotEmpty() }

        private fun strMap(o: JSONObject?): Map<String, String> {
            if (o == null) return emptyMap()
            val out = LinkedHashMap<String, String>()
            val it = o.keys()
            while (it.hasNext()) { val k = it.next(); val v = o.optString(k, "").trim(); if (v.isNotEmpty()) out[k] = v }
            return out
        }

        fun fromJson(o: JSONObject?): StoryMeta {
            if (o == null) return StoryMeta()
            return StoryMeta(
                title = o.optString("title", "").trim(), author = o.optString("author", "").trim(),
                summary = o.optString("summary", "").trim(), summaryHtml = o.optString("summaryHtml", "").trim(),
                genres = strList(o.optJSONArray("genres")), tags = strList(o.optJSONArray("tags")),
                status = o.optString("status", "").trim(), statusText = o.optString("statusText", "").trim(),
                rating = StoryRating.fromJson(o.optJSONObject("rating")),
                language = o.optString("language", "").trim(), sourceUrl = o.optString("sourceUrl", "").trim(), sourceSite = o.optString("sourceSite", "").trim(),
                coverUrl = o.optString("coverUrl", "").trim(), coverFile = o.optString("coverFile", "").trim(), coverMime = o.optString("coverMime", "").trim(),
                altTitles = strList(o.optJSONArray("altTitles")), series = o.optString("series", "").trim(),
                seriesIndex = if (o.has("seriesIndex")) o.optDouble("seriesIndex", Double.NaN).takeIf { !it.isNaN() } else null,
                publishedAt = o.optString("publishedAt", "").trim(), updatedAt = o.optString("updatedAt", "").trim(),
                translator = o.optString("translator", "").trim(), publisher = o.optString("publisher", "").trim(),
                extra = strMap(o.optJSONObject("extra")), sources = strMap(o.optJSONObject("sources")), fetchedAt = o.optLong("fetchedAt", 0L),
            )
        }

        /** Kết quả của STORY_META_JS (`{"meta":{...},"sources":{...}}`) => StoryMeta (đã gắn `sources`, `fetchedAt`). */
        fun fromExtractorJson(root: JSONObject, nowMs: Long): StoryMeta {
            val meta = root.optJSONObject("meta") ?: JSONObject()
            val srcs = root.optJSONObject("sources")
            if (srcs != null) meta.put("sources", srcs)
            return fromJson(meta).copy(fetchedAt = nowMs)
        }

        /** lần trước (lấp chỗ trống) < [fresh] < [manual] (thắng tất cả). Danh sách/chuỗi rỗng ở phía trên KHÔNG xoá giá trị phía dưới. */
        fun merge(prev: StoryMeta?, fresh: StoryMeta?, manual: StoryMeta?): StoryMeta {
            var cur = prev ?: StoryMeta()
            fun over(base: StoryMeta, top: StoryMeta?, tag: String?): StoryMeta {
                if (top == null) return base
                val srcs = LinkedHashMap(base.sources)
                fun <T> pick(name: String, a: T, b: T, blank: (T) -> Boolean): T {
                    if (blank(b)) return a
                    if (tag != null) srcs[name] = tag else if (top.sources[name] != null) srcs[name] = top.sources[name]!!
                    return b
                }
                val sb = { x: String -> x.isBlank() }
                val lb = { x: List<String> -> x.isEmpty() }
                return base.copy(
                    title = pick("title", base.title, top.title, sb), author = pick("author", base.author, top.author, sb),
                    summary = pick("summary", base.summary, top.summary, sb), summaryHtml = if (top.summary.isNotBlank()) top.summaryHtml.ifBlank { htmlOf(top.summary) } else base.summaryHtml,
                    genres = pick("genres", base.genres, top.genres, lb), tags = pick("tags", base.tags, top.tags, lb),
                    status = pick("status", base.status, top.status, sb), statusText = if (top.status.isNotBlank() || top.statusText.isNotBlank()) top.statusText.ifBlank { base.statusText } else base.statusText,
                    rating = pick("rating", base.rating, top.rating) { it == null },
                    language = pick("language", base.language, top.language, sb), sourceUrl = pick("sourceUrl", base.sourceUrl, top.sourceUrl, sb), sourceSite = pick("sourceSite", base.sourceSite, top.sourceSite, sb),
                    coverUrl = pick("coverUrl", base.coverUrl, top.coverUrl, sb), coverFile = if (top.coverFile.isNotBlank()) top.coverFile else base.coverFile,
                    coverMime = if (top.coverMime.isNotBlank()) top.coverMime else base.coverMime,
                    altTitles = pick("altTitles", base.altTitles, top.altTitles, lb), series = pick("series", base.series, top.series, sb),
                    seriesIndex = pick("seriesIndex", base.seriesIndex, top.seriesIndex) { it == null },
                    publishedAt = pick("publishedAt", base.publishedAt, top.publishedAt, sb), updatedAt = pick("updatedAt", base.updatedAt, top.updatedAt, sb),
                    translator = pick("translator", base.translator, top.translator, sb), publisher = pick("publisher", base.publisher, top.publisher, sb),
                    extra = base.extra + top.extra, sources = srcs,
                    fetchedAt = if (top.fetchedAt > 0L) top.fetchedAt else base.fetchedAt,
                )
            }
            cur = over(cur, fresh, null)
            cur = over(cur, manual, "manual")
            return cur
        }

        /** Chữ người dùng gõ ("Đang ra", "Hoàn thành", "full", "tạm ngưng"...) => ongoing | completed | hiatus | dropped | "" (không nhận ra thì để trống, giữ nguyên văn ở statusText). */
        fun normalizeStatus(text: String): String {
            val t = text.trim().lowercase()
            if (t.isEmpty()) return ""
            return when {
                t == "ongoing" || t == "completed" || t == "hiatus" || t == "dropped" -> t
                Regex("(chưa hoàn|chua hoan|not complete|incomplete|not finished|unfinished)").containsMatchIn(t) -> "ongoing"
                Regex("(hoàn|hoan|complet|finish|full)").containsMatchIn(t) -> "completed"
                Regex("(tạm|tam |tam$|hiatus|pause)").containsMatchIn(t) -> "hiatus"
                Regex("(drop|bỏ|abandon|cancel)").containsMatchIn(t) -> "dropped"
                Regex("(đang|dang|ongoing|updating|còn tiếp|con tiep|serial)").containsMatchIn(t) -> "ongoing"
                else -> ""
            }
        }

        /** "a, b; c | d\n e" => [a, b, c, d, e] (bỏ trống/trùng, giữ thứ tự). */
        fun splitList(text: String): List<String> =
            text.split(',', ';', '|', '\n').map { it.trim() }.filter { it.isNotEmpty() }.distinct()

        /** `<p>` cho từng dòng, đã escape. */
        fun htmlOf(summary: String): String = summary.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
            .joinToString("") { "<p>" + it.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") + "</p>" }
    }
}
