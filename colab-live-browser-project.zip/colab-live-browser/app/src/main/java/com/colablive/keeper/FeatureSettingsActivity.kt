package com.colablive.keeper

import android.content.Intent
import android.os.Bundle
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.FeatureRegistry
import com.colablive.keeper.core.FolderPickerBridge

/**
 * Màn hình riêng cho ĐÚNG 1 feature — nhận feature_id + slot_index qua
 * Intent, tìm feature trong FeatureRegistry, hiển thị buildSettingsView()
 * của riêng nó chiếm toàn màn hình. Thêm feature mới KHÔNG cần sửa file này.
 */
open class FeatureSettingsActivity : AppCompatActivity() {
    companion object {
        /**
         * Bản 7.98 — feature có `needsSlotProcess = true` (vd EbookLeech: cào bằng tab GeckoView thật của khe)
         * phải mở màn hình cài đặt Ở ĐÚNG TIẾN TRÌNH CỦA KHE (`:slot1`..`:slot3`), vì `GeckoViewEngine.forSlot(n)`,
         * tiến độ (RAM) và SharedPreferences đang dùng đều là của tiến trình đó. Cùng mẫu `MainActivitySlotN`.
         */
        fun classForSlot(slotIndex: Int): Class<out FeatureSettingsActivity> = when (slotIndex) {
            1 -> FeatureSettingsActivitySlot1::class.java
            2 -> FeatureSettingsActivitySlot2::class.java
            3 -> FeatureSettingsActivitySlot3::class.java
            else -> FeatureSettingsActivity::class.java
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val slotIndex = intent.getIntExtra("slot_index", 0)
        val featureId = intent.getStringExtra("feature_id")
        val feature = FeatureRegistry.features.firstOrNull { it.id == featureId }

        if (feature == null) {
            Toast.makeText(this, "Không tìm thấy feature", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        title = feature.displayName
        setContentView(ScrollView(this).apply { addView(feature.buildSettingsView(this@FeatureSettingsActivity, slotIndex)) })
    }

    /** Màn hình cài đặt của feature (vd EbookLeech "Khôi phục") có thể gọi `FolderPickerBridge.requestFile/requestFolder` —
     * kết quả về Activity này, chuyển tiếp cho cầu nối như MainActivity vẫn làm. */
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        FolderPickerBridge.handleActivityResult(this, requestCode, resultCode, data)
    }
}

// Bản sao RỖNG theo khe — chỉ để khai báo <activity> riêng có android:process (xem AndroidManifest.xml).
class FeatureSettingsActivitySlot1 : FeatureSettingsActivity()
class FeatureSettingsActivitySlot2 : FeatureSettingsActivity()
class FeatureSettingsActivitySlot3 : FeatureSettingsActivity()
