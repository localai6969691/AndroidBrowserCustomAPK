package com.colablive.keeper.core

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * Bản 7.56 — công cụ xem/sửa cookie ĐỌC QUA TRANG ĐANG MỞ (hoạt động ở MỌI tab, kể cả vùng ẩn danh có contextId mà Cookie-Editor không với tới).
 *  - Cookie JS thấy được: document.cookie (xem/sửa/xoá được).
 *  - Cookie HttpOnly: nền của eval_bridge quan sát header Cookie/Set-Cookie (xem tên+giá trị; thuộc tính khi quan sát được lúc đặt cookie).
 *    Ghi/xoá HttpOnly: chèn Set-Cookie vào phản hồi kế tiếp của tab — THỬ NGHIỆM (CHƯA kiểm chứng trên máy; kết quả hiện ngay sau khi thử).
 *  - Nhập/xuất: JSON/Netscape/Header string của Cookie-Editor (xem CookieFormats).
 */
class CookieTool(private val act: Activity, private val engine: BrowserEngine, private val slotIndex: Int = 0) {

    private val ui = Handler(Looper.getMainLooper())
    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()
    private fun toast(s: String) = act.runOnUiThread { Toast.makeText(act, s, Toast.LENGTH_LONG).show() }

    private var host = ""
    private var pageUrl = ""
    private var cookies: List<CookieFormats.Ck> = emptyList()
    private var inferred = HashSet<String>()
    private var dlg: AlertDialog? = null
    private var listBox: LinearLayout? = null
    private var status: TextView? = null

    // ----- gọi JS bất đồng bộ qua cầu eval (kết quả để ở window.__lbCkRes, đọc lại bằng lệnh thứ hai) -----
    private fun callAsync(name: String, args: JSONArray, cb: (JSONObject?, String?) -> Unit) {
        val start = "(window.__lbCk?window.__lbCk.run(${JSONObject.quote(name)},${args}):'NOCK')"
        engine.evaluateJs(start) { r ->
            if (r == null || r.startsWith("LOI") || r.contains("NOCK")) {
                DebugLog.log("[cookie-tool] gọi '$name' KHÔNG chạy được trong trang: ${r ?: "không phản hồi"} (tab cần là trang http/https đã nạp eval_bridge)")
                ui.post { cb(null, "Trang chưa sẵn sàng cho công cụ cookie (tải lại trang rồi thử lại). Chi tiết: ${r ?: "không phản hồi"}") }
                return@evaluateJs
            }
            poll(0, cb)
        }
    }

    private fun poll(n: Int, cb: (JSONObject?, String?) -> Unit) {
        if (n > 30) { ui.post { cb(null, "Hết giờ chờ trang trả kết quả (12s)") }; return }
        ui.postDelayed({
            engine.evaluateJs("((window.__lbCkRes===null||window.__lbCkRes===undefined)?'':window.__lbCkRes)") { r ->
                val v = r?.removePrefix("OK")?.removePrefix(":")?.trim() ?: ""
                if (v.isEmpty()) { poll(n + 1, cb); return@evaluateJs }
                ui.post {
                    try {
                        if (v == "null") cb(JSONObject(), null)
                        else {
                            val o = JSONObject(v)
                            if (o.has("error")) cb(null, o.optString("error")) else cb(o, null)
                        }
                    } catch (e: Exception) { cb(null, "Kết quả không đọc được: ${e.message}") }
                }
            }
        }, 400L)
    }

    private fun isRelevant(domain: String): Boolean {
        val d = domain.trimStart('.').lowercase()
        return d.isEmpty() || host == d || host.endsWith(".$d")
    }

    // ----- hộp thoại chính -----
    fun show() {
        val url = engine.currentUrl() ?: ""
        val h = try { java.net.URI(url).host?.lowercase() } catch (e: Exception) { null }
        if (h.isNullOrBlank() || !url.startsWith("http")) { toast("Hãy mở một trang web (http/https) trước"); return }
        host = h; pageUrl = url
        val pad = dp(14)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        col.addView(TextView(act).apply { text = "🍪 Cookie của $host"; textSize = 18f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
        status = TextView(act).apply { textSize = 12f; text = "Đang đọc…"; setPadding(0, dp(4), 0, dp(8)) }
        col.addView(status)
        val bar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, f: () -> Unit) = Button(act).apply { text = t; isAllCaps = false; textSize = 12f; setOnClickListener { f() } }
            .also { bar.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
        btn("↻") { refresh() }
        btn("＋") { editDialog(null) }
        btn("⬇ Nhập") { importDialog() }
        btn("⬆ Xuất") { exportDialog() }
        col.addView(bar)
        listBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        col.addView(ScrollView(act).apply { addView(listBox) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)))
        dlg = AlertDialog.Builder(act).setView(col).setNegativeButton("Đóng", null).show()
        refresh()
    }

    private fun refresh() {
        status?.text = "Đang đọc cookie (HttpOnly qua header + đọc đĩa)…"
        callAsync("list", JSONArray()) { o, err ->
            if (o == null) { status?.text = "Lỗi: $err"; return@callAsync }
            val arr = o.optJSONArray("cookies") ?: JSONArray()
            val list = ArrayList<CookieFormats.Ck>()
            inferred = HashSet()
            val https = pageUrl.startsWith("https")
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                val name = c.optString("name")
                val exp = c.optDouble("expirationDate", 0.0).let { if (it.isNaN()) 0.0 else it }
                val dom = c.optString("domain", host)
                list.add(CookieFormats.Ck(name, c.optString("value"), dom.ifEmpty { host }, c.optBoolean("hostOnly", true), c.optString("path", "/").ifEmpty { "/" },
                    c.optBoolean("secure", https), c.optBoolean("httpOnly", false), c.optString("sameSite", ""), exp <= 0.0, exp))
                if (c.optBoolean("inferred", false)) inferred.add(name)
            }
            // Bản 7.64: đọc THÊM từ cookies.sqlite theo đúng kho của tab (vùng bền / hồ sơ) — thuộc tính THẬT, thấy cả cookie HttpOnly mà header chưa lộ.
            // Tab ẩn danh không có trên đĩa. Việc đọc đĩa chạy luồng nền rồi quay lại UI.
            val tab = engine.getActiveTab()
            if (tab != null && !tab.isPrivate) {
                val zone = tab.zoneId
                Thread {
                    val disk = try { CookieVault.readCks(act, slotIndex, host, zone) } catch (e: Throwable) { DebugLog.log("[cookie-tool] đọc đĩa lỗi ${e.javaClass.simpleName}: ${e.message}"); null }
                    ui.post { finishRefresh(list, o, disk) }
                }.start()
            } else finishRefresh(list, o, null)
        }
    }

    private fun finishRefresh(list: ArrayList<CookieFormats.Ck>, o: JSONObject, disk: List<CookieFormats.Ck>?) {
        var diskMatched = 0; var diskAdded = 0
        if (disk != null) {
            val merged = ArrayList<CookieFormats.Ck>(list)
            for (d in disk) {
                if (!isRelevant(d.domain)) continue
                val i = merged.indexOfFirst { it.name == d.name && (it.value == d.value || it.value.isEmpty()) }
                if (i >= 0) { merged[i] = d; inferred.remove(d.name); diskMatched++ }
                else { merged.add(d); diskAdded++ }
            }
            list.clear(); list.addAll(merged)
        }
        cookies = list
        val ho = list.count { it.httpOnly }
        val bg = o.optBoolean("bg", false)
        val apiNote = if (bg) " — API addon: ${o.optInt("apiMatched")}" else ""
        val diskNote = if (disk != null) " — đĩa: khớp $diskMatched, thêm $diskAdded (${disk.size} cookie của kho này)" else " — (tab ẩn danh: không có trên đĩa)"
        DebugLog.log("[cookie-tool] $host: ${list.size} cookie, HttpOnly=$ho, API khớp ${o.optInt("apiMatched")}, đĩa=${disk?.size ?: -1} (khớp $diskMatched, thêm $diskAdded) lỗiAPI=${o.optString("apiError", "")}")
        status?.text = "${list.size} cookie (HttpOnly: $ho)" + apiNote + diskNote + if (bg) "" else " — ⚠ chưa quan sát được header (${o.optString("bgError", "")})"
        render()
    }

    private fun render() {
        val box = listBox ?: return
        box.removeAllViews()
        if (cookies.isEmpty()) { box.addView(TextView(act).apply { text = "Trang chưa có cookie."; setPadding(0, dp(12), 0, 0) }); return }
        for (c in cookies) {
            val tags = (if (c.httpOnly) " [HttpOnly${if (c.name in inferred) "?" else ""}]" else "") + (if (c.secure) " [Secure]" else "")
            box.addView(TextView(act).apply {
                text = c.name + tags + "\n" + (if (c.value.length > 70) c.value.take(70) + "…" else c.value)
                textSize = 13f; setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { editDialog(c) }
            })
        }
    }

    private fun copy(label: String, text: String) {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    // ----- sửa / thêm / xoá -----
    private fun editDialog(c: CookieFormats.Ck?) {
        val pad = dp(16)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(8), pad, 0) }
        val name = EditText(act).apply { hint = "Tên"; setText(c?.name ?: ""); isEnabled = c == null }
        val value = EditText(act).apply { hint = "Giá trị"; setText(c?.value ?: ""); minLines = 2; gravity = Gravity.TOP }
        val path = EditText(act).apply { hint = "Path"; setText(c?.path ?: "/") }
        col.addView(name); col.addView(value); col.addView(path)
        val chkHttp = android.widget.CheckBox(act).apply { text = "HttpOnly (ghi qua Set-Cookie — thử nghiệm)"; isChecked = c?.httpOnly ?: false }
        val chkSecure = android.widget.CheckBox(act).apply { text = "Secure"; isChecked = c?.secure ?: pageUrl.startsWith("https") }
        col.addView(chkHttp); col.addView(chkSecure)
        val b = AlertDialog.Builder(act).setTitle(if (c == null) "Thêm cookie" else "Sửa cookie").setView(ScrollView(act).apply { addView(col) })
            .setPositiveButton("Lưu") { _, _ ->
                val nn = name.text.toString().trim()
                if (nn.isEmpty()) { toast("Tên trống"); return@setPositiveButton }
                val nc = CookieFormats.Ck(nn, value.text.toString(), c?.domain ?: host, c?.hostOnly ?: true, path.text.toString().ifBlank { "/" },
                    chkSecure.isChecked, chkHttp.isChecked, c?.sameSite ?: "", c?.session ?: true, c?.expirationDate ?: 0.0)
                applyCookies(listOf(nc))
            }
            .setNegativeButton("Hủy", null)
        if (c != null) b.setNeutralButton("Xoá") { _, _ -> delete(c) }
        b.show()
    }

    private fun applyCookies(list: List<CookieFormats.Ck>) {
        val arr = JSONArray(); list.forEach { arr.put(it.toJs()) }
        status?.text = "Đang ghi…"
        callAsync("setMany", JSONArray().put(arr)) { o, err ->
            if (o == null) {
                DebugLog.log("[cookie-tool] GHI LỖI: $err")
                AlertDialog.Builder(act).setTitle("Ghi cookie lỗi").setMessage(err ?: "không rõ").setPositiveButton("Đóng", null).show()
                refresh(); return@callAsync
            }
            val inj = o.optJSONObject("injected")
            val hoCount = o.optInt("httpOnlyCount")
            val hoUsed = inj?.optInt("used", 0) ?: 0
            val injErr = inj?.optString("error", "") ?: ""
            DebugLog.log("[cookie-tool] GHI: ok=${o.optInt("ok")} lỗi=${o.optInt("failed")} httpOnly=$hoCount chèn được=$hoUsed lỗiChèn='$injErr'")
            val note = if (hoCount > 0) {
                if (injErr.isNotEmpty() && injErr != "null") " (HttpOnly lỗi: $injErr)" else " (HttpOnly chèn được $hoUsed/$hoCount — kiểm lại bằng ↻)"
            } else ""
            toast("Đã ghi ${o.optInt("ok")}, lỗi ${o.optInt("failed")}$note — tải lại trang để áp dụng")
            refresh()
            // Bản 7.69: chèn Set-Cookie chưa chắc chạy trên GeckoView; còn cookie HttpOnly chưa vào được thì đề nghị ghi thẳng cookies.sqlite lúc khởi động lại khe (tab thường/vùng bền).
            val tab = engine.getActiveTab()
            val pending = list.filter { it.httpOnly }
            if (hoCount > 0 && hoUsed < hoCount && tab != null && !tab.isPrivate && pending.isNotEmpty()) {
                AlertDialog.Builder(act).setTitle("Cookie HttpOnly chưa ghi được ngay")
                    .setMessage("${hoCount - hoUsed} cookie HttpOnly không chèn trực tiếp được. Có thể xếp hàng để ghi thẳng vào kho cookie của " +
                        (if (tab.zoneId.isNotBlank()) "vùng này" else "hồ sơ") + " lúc khởi động lại khe (không xoá cookie hiện có). Khe sẽ đóng ngay; bạn mở lại khe.")
                    .setPositiveButton("Xếp hàng & đóng khe") { _, _ ->
                        try {
                            val id = CookieVault.queueImport(act, slotIndex, host, tab.zoneId, list)
                            CookieVault.queueReplace(act, slotIndex, id)
                            act.sendBroadcast(android.content.Intent(ProfileSlots.gracefulCloseAction(slotIndex)).apply { setPackage(act.packageName) })
                        } catch (e: Throwable) { toast("Không xếp hàng được: ${e.message}") }
                    }
                    .setNegativeButton("Để sau", null).show()
            }
        }
    }

    private fun delete(c: CookieFormats.Ck) {
        if (!c.httpOnly) {
            callAsync("del", JSONArray().put(c.name).put(if (c.hostOnly) "" else c.domain).put(c.path)) { o, err ->
                toast(if (o != null && o.optBoolean("deleted")) "Đã xoá ${c.name}" else "Không xoá được: ${err ?: "cookie còn tồn tại (path/domain khác?)"}")
                refresh()
            }
        } else {
            // HttpOnly: chèn Set-Cookie đã hết hạn (thử cả dạng host-only lẫn Domain= vì thuộc tính gốc có thể chưa quan sát được).
            val a = c.copy(value = "", session = false, expirationDate = 1.0)
            // Thuộc tính đã biết CHÍNH XÁC (đọc từ đĩa/Set-Cookie) => một Set-Cookie hết hạn; chỉ khi mới suy luận (nhãn HttpOnly?) mới thử cả host-only lẫn Domain=.
            if (c.name in inferred) applyCookies(listOf(a.copy(hostOnly = true, domain = host), a.copy(hostOnly = false, domain = host)))
            else applyCookies(listOf(a))
        }
    }

    // ----- nhập / xuất -----
    private fun importDialog() {
        val pad = dp(16)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(8), pad, 0) }
        col.addView(TextView(act).apply { text = "Dán cookie xuất từ Cookie-Editor: JSON, Netscape (cookies.txt) hoặc chuỗi Header (a=b; c=d). Tự nhận dạng."; textSize = 12f })
        val et = EditText(act).apply { minLines = 6; gravity = Gravity.TOP; hint = "[{\"name\":…}]" }
        col.addView(et)
        col.addView(Button(act).apply {
            text = "Dán từ bộ nhớ tạm"; isAllCaps = false
            setOnClickListener {
                val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                et.setText(cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(act)?.toString() ?: "")
            }
        })
        AlertDialog.Builder(act).setTitle("Nhập cookie").setView(ScrollView(act).apply { addView(col) })
            .setPositiveButton("Nhập") { _, _ ->
                val (fmt, all) = CookieFormats.parse(et.text.toString(), host)
                if (all.isEmpty()) { toast("Không nhận dạng được cookie nào (định dạng: $fmt)"); return@setPositiveButton }
                val ok = all.filter { isRelevant(it.domain) }
                val skipped = all.size - ok.size
                AlertDialog.Builder(act).setTitle("Xác nhận nhập")
                    .setMessage("Định dạng: $fmt\nTìm thấy ${all.size} cookie; áp dụng ${ok.size} cookie của $host (HttpOnly: ${ok.count { it.httpOnly }})" +
                        (if (skipped > 0) "\nBỏ qua $skipped cookie của tên miền khác (trang này không ghi được)." else "") +
                        "\n\nCookie trùng tên sẽ bị ghi đè.")
                    .setPositiveButton("Áp dụng") { _, _ -> applyCookies(ok) }.setNegativeButton("Hủy", null).show()
            }.setNegativeButton("Hủy", null).show()
    }

    private fun exportDialog() {
        if (cookies.isEmpty()) { toast("Chưa có cookie để xuất"); return }
        // Bản 7.62: lỗi cũ — AlertDialog đặt cả setMessage() lẫn setItems() thì Android CHỈ hiện message, danh sách định dạng biến mất (chỉ còn nút "Hủy",
        // không chép được gì). Nay dùng view tự dựng: dòng cảnh báo + 3 nút định dạng.
        val pad = dp(16)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(8), pad, 0) }
        col.addView(TextView(act).apply { text = "⚠ Cookie chứa phiên đăng nhập — ai có chúng đều vào được tài khoản. Chỉ dán ở nơi tin cậy."; textSize = 13f; setPadding(0, 0, 0, dp(8)) })
        var d: AlertDialog? = null
        fun fmtBtn(label: String, make: () -> String) = Button(act).apply {
            text = label; isAllCaps = false
            setOnClickListener {
                copy("cookies", make())
                toast("Đã chép ${cookies.size} cookie ($label) vào bộ nhớ tạm — dán ở nơi cần nhập")
                d?.dismiss()
            }
        }.also { col.addView(it) }
        fmtBtn("JSON (Cookie-Editor)") { CookieFormats.toJson(cookies) }
        fmtBtn("Netscape (cookies.txt)") { CookieFormats.toNetscape(cookies) }
        fmtBtn("Header string (a=b; c=d)") { CookieFormats.toHeader(cookies) }
        d = AlertDialog.Builder(act).setTitle("Xuất ${cookies.size} cookie → bộ nhớ tạm").setView(col).setNegativeButton("Hủy", null).show()
    }
}
