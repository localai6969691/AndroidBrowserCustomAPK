package com.colablive.keeper.core

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * Bản 7.56 — công cụ xem/sửa cookie ĐỌC QUA TRANG ĐANG MỞ (hoạt động ở MỌI tab, kể cả vùng ẩn danh có contextId mà Cookie-Editor không với tới).
 *  - Cookie JS thấy được: document.cookie (xem/sửa/xoá được).
 *  - Cookie HttpOnly: nền của eval_bridge quan sát header Cookie/Set-Cookie (xem tên+giá trị; thuộc tính khi quan sát được lúc đặt cookie).
 *    Ghi/xoá HttpOnly: chèn Set-Cookie vào phản hồi kế tiếp của tab — THỬ NGHIỆM (CHƯA kiểm chứng trên máy; kết quả hiện ngay sau khi thử).
 *  - Nhập/xuất: JSON/Netscape/Header string của Cookie-Editor (xem CookieFormats).
 */
class CookieTool(private val act: Activity, private val engine: BrowserEngine) {

    private val ui = Handler(Looper.getMainLooper())
    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()
    private fun toast(s: String) = act.runOnUiThread { Toast.makeText(act, s, Toast.LENGTH_LONG).show() }

    private var host = ""
    private var pageUrl = ""
    private var cookies: List<CookieFormats.Ck> = emptyList()
    private var inferred = HashSet<String>()
    private var dlg: AlertDialog? = null
    private var listBox: LinearLayout? = null
    private var status: TextView? = null

    // ----- gọi JS bất đồng bộ qua cầu eval (kết quả để ở window.__lbCkRes, đọc lại bằng lệnh thứ hai) -----
    private fun callAsync(name: String, args: JSONArray, cb: (JSONObject?, String?) -> Unit) {
        val start = "(window.__lbCk?window.__lbCk.run(${JSONObject.quote(name)},${args}):'NOCK')"
        engine.evaluateJs(start) { r ->
            if (r == null || r.startsWith("LOI") || r.contains("NOCK")) {
                ui.post { cb(null, "Trang chưa sẵn sàng cho công cụ cookie (tải lại trang rồi thử lại). Chi tiết: ${r ?: "không phản hồi"}") }
                return@evaluateJs
            }
            poll(0, cb)
        }
    }

    private fun poll(n: Int, cb: (JSONObject?, String?) -> Unit) {
        if (n > 30) { ui.post { cb(null, "Hết giờ chờ trang trả kết quả (12s)") }; return }
        ui.postDelayed({
            engine.evaluateJs("((window.__lbCkRes===null||window.__lbCkRes===undefined)?'':window.__lbCkRes)") { r ->
                val v = r?.removePrefix("OK")?.removePrefix(":")?.trim() ?: ""
                if (v.isEmpty()) { poll(n + 1, cb); return@evaluateJs }
                ui.post {
                    try {
                        if (v == "null") cb(JSONObject(), null)
                        else {
                            val o = JSONObject(v)
                            if (o.has("error")) cb(null, o.optString("error")) else cb(o, null)
                        }
                    } catch (e: Exception) { cb(null, "Kết quả không đọc được: ${e.message}") }
                }
            }
        }, 400L)
    }

    private fun isRelevant(domain: String): Boolean {
        val d = domain.trimStart('.').lowercase()
        return d.isEmpty() || host == d || host.endsWith(".$d")
    }

    // ----- hộp thoại chính -----
    fun show() {
        val url = engine.currentUrl() ?: ""
        val h = try { java.net.URI(url).host?.lowercase() } catch (e: Exception) { null }
        if (h.isNullOrBlank() || !url.startsWith("http")) { toast("Hãy mở một trang web (http/https) trước"); return }
        host = h; pageUrl = url
        val pad = dp(14)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        col.addView(TextView(act).apply { text = "🍪 Cookie của $host"; textSize = 18f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
        status = TextView(act).apply { textSize = 12f; text = "Đang đọc…"; setPadding(0, dp(4), 0, dp(8)) }
        col.addView(status)
        val bar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, f: () -> Unit) = Button(act).apply { text = t; isAllCaps = false; textSize = 12f; setOnClickListener { f() } }
            .also { bar.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
        btn("↻") { refresh() }
        btn("＋") { editDialog(null) }
        btn("⬇ Nhập") { importDialog() }
        btn("⬆ Xuất") { exportDialog() }
        col.addView(bar)
        listBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        col.addView(ScrollView(act).apply { addView(listBox) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)))
        dlg = AlertDialog.Builder(act).setView(col).setNegativeButton("Đóng", null).show()
        refresh()
    }

    private fun refresh() {
        status?.text = "Đang đọc cookie (kể cả HttpOnly qua header)…"
        callAsync("list", JSONArray()) { o, err ->
            if (o == null) { status?.text = "Lỗi: $err"; return@callAsync }
            val arr = o.optJSONArray("cookies") ?: JSONArray()
            val list = ArrayList<CookieFormats.Ck>()
            inferred = HashSet()
            val https = pageUrl.startsWith("https")
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                val name = c.optString("name")
                val exp = c.optDouble("expirationDate", 0.0).let { if (it.isNaN()) 0.0 else it }
                val dom = c.optString("domain", host)
                list.add(CookieFormats.Ck(name, c.optString("value"), dom.ifEmpty { host }, c.optBoolean("hostOnly", true), c.optString("path", "/").ifEmpty { "/" },
                    c.optBoolean("secure", https), c.optBoolean("httpOnly", false), c.optString("sameSite", ""), exp <= 0.0, exp))
                if (c.optBoolean("inferred", false)) inferred.add(name)
            }
            cookies = list
            val ho = list.count { it.httpOnly }
            val bg = o.optBoolean("bg", false)
            status?.text = "${list.size} cookie (HttpOnly: $ho)" + if (bg) "" else " — ⚠ chưa quan sát được header (${o.optString("bgError", "")}); chỉ thấy cookie JS đọc được"
            render()
        }
    }

    private fun render() {
        val box = listBox ?: return
        box.removeAllViews()
        if (cookies.isEmpty()) { box.addView(TextView(act).apply { text = "Trang chưa có cookie."; setPadding(0, dp(12), 0, 0) }); return }
        for (c in cookies) {
            val tags = (if (c.httpOnly) " [HttpOnly${if (c.name in inferred) "?" else ""}]" else "") + (if (c.secure) " [Secure]" else "")
            box.addView(TextView(act).apply {
                text = c.name + tags + "\n" + (if (c.value.length > 70) c.value.take(70) + "…" else c.value)
                textSize = 13f; setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { editDialog(c) }
            })
        }
    }

    private fun copy(label: String, text: String) {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    // ----- sửa / thêm / xoá -----
    private fun editDialog(c: CookieFormats.Ck?) {
        val pad = dp(16)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(8), pad, 0) }
        val name = EditText(act).apply { hint = "Tên"; setText(c?.name ?: ""); isEnabled = c == null }
        val value = EditText(act).apply { hint = "Giá trị"; setText(c?.value ?: ""); minLines = 2; gravity = Gravity.TOP }
        val path = EditText(act).apply { hint = "Path"; setText(c?.path ?: "/") }
        col.addView(name); col.addView(value); col.addView(path)
        val chkHttp = android.widget.CheckBox(act).apply { text = "HttpOnly (ghi qua Set-Cookie — thử nghiệm)"; isChecked = c?.httpOnly ?: false }
        val chkSecure = android.widget.CheckBox(act).apply { text = "Secure"; isChecked = c?.secure ?: pageUrl.startsWith("https") }
        col.addView(chkHttp); col.addView(chkSecure)
        val b = AlertDialog.Builder(act).setTitle(if (c == null) "Thêm cookie" else "Sửa cookie").setView(ScrollView(act).apply { addView(col) })
            .setPositiveButton("Lưu") { _, _ ->
                val nn = name.text.toString().trim()
                if (nn.isEmpty()) { toast("Tên trống"); return@setPositiveButton }
                val nc = CookieFormats.Ck(nn, value.text.toString(), c?.domain ?: host, c?.hostOnly ?: true, path.text.toString().ifBlank { "/" },
                    chkSecure.isChecked, chkHttp.isChecked, c?.sameSite ?: "", c?.session ?: true, c?.expirationDate ?: 0.0)
                applyCookies(listOf(nc))
            }
            .setNegativeButton("Hủy", null)
        if (c != null) b.setNeutralButton("Xoá") { _, _ -> delete(c) }
        b.show()
    }

    private fun applyCookies(list: List<CookieFormats.Ck>) {
        val arr = JSONArray(); list.forEach { arr.put(it.toJs()) }
        status?.text = "Đang ghi…"
        callAsync("setMany", JSONArray().put(arr)) { o, err ->
            if (o == null) { toast("Ghi lỗi: $err"); refresh(); return@callAsync }
            val inj = o.optJSONObject("injected")
            val note = if (o.optInt("httpOnlyCount") > 0) {
                if (inj != null && inj.has("error")) " (HttpOnly lỗi: ${inj.optString("error")})"
                else " (HttpOnly chèn được ${inj?.optInt("used") ?: 0}/${o.optInt("httpOnlyCount")} — kiểm lại bằng ↻)"
            } else ""
            toast("Đã ghi ${o.optInt("ok")}, lỗi ${o.optInt("failed")}$note — tải lại trang để áp dụng")
            refresh()
        }
    }

    private fun delete(c: CookieFormats.Ck) {
        if (!c.httpOnly) {
            callAsync("del", JSONArray().put(c.name).put(if (c.hostOnly) "" else c.domain).put(c.path)) { o, err ->
                toast(if (o != null && o.optBoolean("deleted")) "Đã xoá ${c.name}" else "Không xoá được: ${err ?: "cookie còn tồn tại (path/domain khác?)"}")
                refresh()
            }
        } else {
            // HttpOnly: chèn Set-Cookie đã hết hạn (thử cả dạng host-only lẫn Domain= vì thuộc tính gốc có thể chưa quan sát được).
            val a = c.copy(value = "", session = false, expirationDate = 1.0)
            applyCookies(listOf(a.copy(hostOnly = true, domain = host), a.copy(hostOnly = false, domain = host)))
        }
    }

    // ----- nhập / xuất -----
    private fun importDialog() {
        val pad = dp(16)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(8), pad, 0) }
        col.addView(TextView(act).apply { text = "Dán cookie xuất từ Cookie-Editor: JSON, Netscape (cookies.txt) hoặc chuỗi Header (a=b; c=d). Tự nhận dạng."; textSize = 12f })
        val et = EditText(act).apply { minLines = 6; gravity = Gravity.TOP; hint = "[{\"name\":…}]" }
        col.addView(et)
        col.addView(Button(act).apply {
            text = "Dán từ bộ nhớ tạm"; isAllCaps = false
            setOnClickListener {
                val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                et.setText(cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(act)?.toString() ?: "")
            }
        })
        AlertDialog.Builder(act).setTitle("Nhập cookie").setView(ScrollView(act).apply { addView(col) })
            .setPositiveButton("Nhập") { _, _ ->
                val (fmt, all) = CookieFormats.parse(et.text.toString(), host)
                if (all.isEmpty()) { toast("Không nhận dạng được cookie nào (định dạng: $fmt)"); return@setPositiveButton }
                val ok = all.filter { isRelevant(it.domain) }
                val skipped = all.size - ok.size
                AlertDialog.Builder(act).setTitle("Xác nhận nhập")
                    .setMessage("Định dạng: $fmt\nTìm thấy ${all.size} cookie; áp dụng ${ok.size} cookie của $host (HttpOnly: ${ok.count { it.httpOnly }})" +
                        (if (skipped > 0) "\nBỏ qua $skipped cookie của tên miền khác (trang này không ghi được)." else "") +
                        "\n\nCookie trùng tên sẽ bị ghi đè.")
                    .setPositiveButton("Áp dụng") { _, _ -> applyCookies(ok) }.setNegativeButton("Hủy", null).show()
            }.setNegativeButton("Hủy", null).show()
    }

    private fun exportDialog() {
        if (cookies.isEmpty()) { toast("Chưa có cookie để xuất"); return }
        AlertDialog.Builder(act).setTitle("Xuất cookie → bộ nhớ tạm")
            .setMessage("⚠ Cookie chứa phiên đăng nhập — ai có chúng đều vào được tài khoản. Chỉ dán ở nơi tin cậy.")
            .setItems(arrayOf("JSON (Cookie-Editor)", "Netscape (cookies.txt)", "Header string")) { _, which ->
                val txt = when (which) { 0 -> CookieFormats.toJson(cookies); 1 -> CookieFormats.toNetscape(cookies); else -> CookieFormats.toHeader(cookies) }
                copy("cookies", txt)
                toast("Đã chép ${cookies.size} cookie vào bộ nhớ tạm")
            }.setNegativeButton("Hủy", null).show()
    }
}
