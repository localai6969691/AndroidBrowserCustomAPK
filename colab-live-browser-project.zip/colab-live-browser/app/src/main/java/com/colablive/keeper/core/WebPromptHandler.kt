package com.colablive.keeper.core

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Typeface
import android.graphics.Color
import android.text.InputType
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import org.mozilla.geckoview.AllowOrDeny
import java.util.Calendar
import java.util.Locale
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Mục 165: HỘP THOẠI CỦA TRANG WEB (`<select>` dropdown, alert(), confirm(), prompt()).
 *
 * GeckoView KHÔNG tự vẽ các hộp thoại này — mọi prompt đều giao cho `GeckoSession.PromptDelegate` của app (tài liệu Mozilla: "applications implement this
 * interface to handle prompts triggered by content ... such as alerts, authentication dialogs, and select list pickers"). Trước đây app chỉ cài
 * `onFilePrompt` và `onLoginSelect` nên `onChoicePrompt` trả mặc định `null` => prompt bị huỷ => chạm vào mọi ô chọn (dropdown) trên MỌI trang đều
 * không hiện gì (đúng lỗi ở popup FastTube và hộp thoại FastTube chèn vào YouTube); alert()/confirm()/prompt() của trang cũng không hiện.
 *
 * Mọi hàm trả `GeckoResult` hoàn tất đúng 1 lần (AtomicBoolean) dù người dùng bấm nút, chạm ra ngoài hay Activity bị đóng.
 */
object WebPromptHandler {

    private fun activityOf(ctx: Context): Activity? {
        var c: Context? = ctx
        while (c is ContextWrapper) {
            if (c is Activity) return c
            c = c.baseContext
        }
        return null
    }

    private fun usable(a: Activity?) = a != null && !a.isFinishing && !a.isDestroyed

    private class Row(val choice: GeckoSession.PromptDelegate.ChoicePrompt.Choice?, val label: String, val enabled: Boolean, val header: Boolean, val selected: Boolean)

    fun choice(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.ChoicePrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        if (!usable(act)) return GeckoResult.fromValue(prompt.dismiss())
        val a: Activity = act!!
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish(resp: GeckoSession.PromptDelegate.PromptResponse) { if (done.compareAndSet(false, true)) result.complete(resp) }

        val multiple = prompt.type == GeckoSession.PromptDelegate.ChoicePrompt.Type.MULTIPLE
        val rows = ArrayList<Row>()
        fun flatten(arr: Array<GeckoSession.PromptDelegate.ChoicePrompt.Choice>, indent: Boolean) {
            for (c in arr) {
                if (c.separator) continue
                val sub = c.items
                if (sub != null) {
                    if (!multiple) rows.add(Row(null, c.label, false, true, false)) // tiêu đề nhóm <optgroup>
                    flatten(sub, true)
                } else {
                    rows.add(Row(c, (if (indent && !multiple) "    " else "") + c.label, !c.disabled, false, c.selected))
                }
            }
        }
        flatten(prompt.choices, false)
        DebugLog.log("Khe $slotIndex: [prompt] hộp chọn (select) ${if (multiple) "nhiều lựa chọn" else "một lựa chọn"}, ${rows.size} mục")
        if (rows.isEmpty()) return GeckoResult.fromValue(prompt.dismiss())

        val title = (prompt.title?.takeIf { it.isNotBlank() } ?: prompt.message?.takeIf { it.isNotBlank() })
        val builder = AlertDialog.Builder(a)
        if (title != null) builder.setTitle(title)

        if (multiple) {
            val labels = rows.map { it.label }.toTypedArray()
            val checked = BooleanArray(rows.size) { rows[it].selected }
            builder.setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            builder.setPositiveButton("OK") { _, _ ->
                val chosen = rows.indices.filter { checked[it] && rows[it].choice != null && rows[it].enabled }.mapNotNull { rows[it].choice }
                finish(prompt.confirm(chosen.toTypedArray()))
            }
            builder.setNegativeButton("Huỷ") { _, _ -> finish(prompt.dismiss()) }
        } else {
            val adapter = object : ArrayAdapter<String>(a, android.R.layout.simple_list_item_1, rows.map { (if (it.selected) "✓ " else "") + it.label }) {
                override fun isEnabled(position: Int) = rows[position].enabled
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val v = super.getView(position, convertView, parent)
                    (v as? TextView)?.apply {
                        alpha = if (rows[position].enabled) 1f else 0.55f
                        setTypeface(null, if (rows[position].header || rows[position].selected) Typeface.BOLD else Typeface.NORMAL)
                    }
                    return v
                }
            }
            builder.setAdapter(adapter) { _, which ->
                val r = rows.getOrNull(which)
                if (r?.choice != null && r.enabled) finish(prompt.confirm(r.choice)) else finish(prompt.dismiss())
            }
        }
        builder.setOnCancelListener { finish(prompt.dismiss()) }
        builder.setOnDismissListener { finish(prompt.dismiss()) }
        try { builder.show() } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [prompt] không hiện được hộp chọn: ${e.javaClass.simpleName} ${e.message}")
            finish(prompt.dismiss())
        }
        return result
    }

    fun alert(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.AlertPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        if (!usable(act)) return GeckoResult.fromValue(prompt.dismiss())
        val a: Activity = act!!
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish() { if (done.compareAndSet(false, true)) result.complete(prompt.dismiss()) }
        DebugLog.log("Khe $slotIndex: [prompt] alert() của trang")
        try {
            AlertDialog.Builder(a)
                .setTitle(prompt.title?.takeIf { it.isNotBlank() } ?: "Thông báo từ trang")
                .setMessage(prompt.message ?: "")
                .setPositiveButton("OK") { _, _ -> finish() }
                .setOnCancelListener { finish() }
                .setOnDismissListener { finish() }
                .show()
        } catch (e: Throwable) { finish() }
        return result
    }

    fun button(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.ButtonPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        if (!usable(act)) return GeckoResult.fromValue(prompt.dismiss())
        val a: Activity = act!!
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish(resp: GeckoSession.PromptDelegate.PromptResponse) { if (done.compareAndSet(false, true)) result.complete(resp) }
        DebugLog.log("Khe $slotIndex: [prompt] confirm() của trang")
        try {
            AlertDialog.Builder(a)
                .setTitle(prompt.title?.takeIf { it.isNotBlank() } ?: "Xác nhận từ trang")
                .setMessage(prompt.message ?: "")
                .setPositiveButton("OK") { _, _ -> finish(prompt.confirm(GeckoSession.PromptDelegate.ButtonPrompt.Type.POSITIVE)) }
                .setNegativeButton("Huỷ") { _, _ -> finish(prompt.confirm(GeckoSession.PromptDelegate.ButtonPrompt.Type.NEGATIVE)) }
                .setOnCancelListener { finish(prompt.dismiss()) }
                .setOnDismissListener { finish(prompt.dismiss()) }
                .show()
        } catch (e: Throwable) { finish(prompt.dismiss()) }
        return result
    }

    fun text(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.TextPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        if (!usable(act)) return GeckoResult.fromValue(prompt.dismiss())
        val a: Activity = act!!
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish(resp: GeckoSession.PromptDelegate.PromptResponse) { if (done.compareAndSet(false, true)) result.complete(resp) }
        DebugLog.log("Khe $slotIndex: [prompt] prompt() của trang")
        try {
            val input = EditText(a).apply {
                inputType = InputType.TYPE_CLASS_TEXT
                setText(prompt.defaultValue ?: "")
                setSelection(text.length)
            }
            AlertDialog.Builder(a)
                .setTitle(prompt.title?.takeIf { it.isNotBlank() } ?: "Trang yêu cầu nhập")
                .setMessage(prompt.message ?: "")
                .setView(input)
                .setPositiveButton("OK") { _, _ -> finish(prompt.confirm(input.text.toString())) }
                .setNegativeButton("Huỷ") { _, _ -> finish(prompt.dismiss()) }
                .setOnCancelListener { finish(prompt.dismiss()) }
                .setOnDismissListener { finish(prompt.dismiss()) }
                .show()
        } catch (e: Throwable) { finish(prompt.dismiss()) }
        return result
    }

    // ======================= Mục 166: các hộp thoại còn lại =======================

    private fun parseYmd(s: String?): IntArray? {
        if (s == null || s.length < 10) return null
        val p = s.substring(0, 10).split('-')
        if (p.size != 3) return null
        val y = p[0].toIntOrNull() ?: return null
        val m = p[1].toIntOrNull() ?: return null
        val d = p[2].toIntOrNull() ?: return null
        return intArrayOf(y, m - 1, d)
    }

    private fun parseHm(s: String?): IntArray? {
        if (s.isNullOrBlank()) return null
        val t = if (s.contains('T')) s.substringAfter('T') else s
        val p = t.split(':')
        if (p.size < 2) return null
        val h = p[0].toIntOrNull() ?: return null
        val m = p[1].take(2).toIntOrNull() ?: return null
        return intArrayOf(h, m)
    }

    private fun dayMillis(ymd: IntArray, endOfDay: Boolean): Long {
        val c = Calendar.getInstance()
        c.clear()
        if (endOfDay) c.set(ymd[0], ymd[1], ymd[2], 23, 59, 59) else c.set(ymd[0], ymd[1], ymd[2], 0, 0, 0)
        return c.timeInMillis
    }

    /** `<input type=date|time|datetime-local|month|week>`. Ngày/giờ dùng bộ chọn của Android; tháng/tuần nhập tay theo định dạng HTML. */
    fun dateTime(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.DateTimePrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        if (!usable(act)) return GeckoResult.fromValue(prompt.dismiss())
        val a: Activity = act!!
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish(resp: GeckoSession.PromptDelegate.PromptResponse) { if (done.compareAndSet(false, true)) result.complete(resp) }
        val type = prompt.type
        DebugLog.log("Khe $slotIndex: [prompt] chọn ngày/giờ (type=$type, mặc định='${prompt.defaultValue}')")
        val now = Calendar.getInstance()
        try {
            fun showTime(datePart: String?) {
                val hm = parseHm(prompt.defaultValue) ?: intArrayOf(now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE))
                val dlg = android.app.TimePickerDialog(a, { _, h, m ->
                    val t = String.format(Locale.US, "%02d:%02d", h, m)
                    finish(prompt.confirm(if (datePart != null) datePart + "T" + t else t))
                }, hm[0], hm[1], true)
                dlg.setOnCancelListener { finish(prompt.dismiss()) }
                dlg.setOnDismissListener { finish(prompt.dismiss()) }
                dlg.show()
            }
            fun showDate(thenTime: Boolean) {
                val ymd = parseYmd(prompt.defaultValue) ?: intArrayOf(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH))
                val dlg = android.app.DatePickerDialog(a, { _, y, m, d ->
                    val ds = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                    if (thenTime) showTime(ds) else finish(prompt.confirm(ds))
                }, ymd[0], ymd[1], ymd[2])
                parseYmd(prompt.minValue)?.let { try { dlg.datePicker.minDate = dayMillis(it, false) } catch (_: Throwable) {} }
                parseYmd(prompt.maxValue)?.let { try { dlg.datePicker.maxDate = dayMillis(it, true) } catch (_: Throwable) {} }
                dlg.setOnCancelListener { finish(prompt.dismiss()) }
                // Chọn ngày xong còn phải chọn giờ (datetime-local): đừng coi việc đóng hộp ngày là huỷ.
                if (!thenTime) dlg.setOnDismissListener { finish(prompt.dismiss()) }
                dlg.show()
            }
            when (type) {
                GeckoSession.PromptDelegate.DateTimePrompt.Type.DATE -> showDate(false)
                GeckoSession.PromptDelegate.DateTimePrompt.Type.TIME -> showTime(null)
                GeckoSession.PromptDelegate.DateTimePrompt.Type.DATETIME_LOCAL -> showDate(true)
                else -> {
                    // MONTH ("2026-10") / WEEK ("2026-W42"): không có bộ chọn sẵn của Android => nhập tay đúng định dạng HTML.
                    val isWeek = type == GeckoSession.PromptDelegate.DateTimePrompt.Type.WEEK
                    val input = EditText(a).apply {
                        inputType = InputType.TYPE_CLASS_TEXT
                        hint = if (isWeek) "yyyy-Www, ví dụ 2026-W42" else "yyyy-MM, ví dụ 2026-10"
                        setText(prompt.defaultValue ?: "")
                    }
                    AlertDialog.Builder(a)
                        .setTitle(if (isWeek) "Chọn tuần" else "Chọn tháng")
                        .setView(input)
                        .setPositiveButton("OK") { _, _ -> finish(prompt.confirm(input.text.toString().trim())) }
                        .setNegativeButton("Huỷ") { _, _ -> finish(prompt.dismiss()) }
                        .setOnCancelListener { finish(prompt.dismiss()) }
                        .setOnDismissListener { finish(prompt.dismiss()) }
                        .show()
                }
            }
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [prompt] không hiện được hộp chọn ngày/giờ: ${e.javaClass.simpleName} ${e.message}")
            finish(prompt.dismiss())
        }
        return result
    }

    private val BASIC_COLORS = arrayOf("#000000", "#ffffff", "#808080", "#ff0000", "#ff9800", "#ffeb3b", "#4caf50", "#00bcd4", "#2196f3", "#9c27b0", "#e91e63", "#795548")

    /** `<input type=color>`: dãy ô màu dựng sẵn (hoặc màu trong `<datalist>`) + ô nhập mã #RRGGBB. */
    fun color(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.ColorPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        if (!usable(act)) return GeckoResult.fromValue(prompt.dismiss())
        val a: Activity = act!!
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish(resp: GeckoSession.PromptDelegate.PromptResponse) { if (done.compareAndSet(false, true)) result.complete(resp) }
        DebugLog.log("Khe $slotIndex: [prompt] chọn màu (mặc định='${prompt.defaultValue}')")
        try {
            val density = a.resources.displayMetrics.density
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * density).toInt(), (8 * density).toInt(), (20 * density).toInt(), 0) }
            val input = EditText(a).apply {
                inputType = InputType.TYPE_CLASS_TEXT
                hint = "#RRGGBB"
                setText(prompt.defaultValue?.takeIf { it.isNotBlank() } ?: "#000000")
            }
            val palette = (prompt.predefinedValues?.filter { it.matches(Regex("#[0-9a-fA-F]{6}")) }?.takeIf { it.isNotEmpty() } ?: BASIC_COLORS.toList()).take(24)
            val rowSize = 6
            palette.chunked(rowSize).forEach { chunk ->
                val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
                chunk.forEach { hex ->
                    val sw = View(a).apply {
                        setBackgroundColor(Color.parseColor(hex))
                        layoutParams = LinearLayout.LayoutParams((40 * density).toInt(), (40 * density).toInt()).apply { setMargins(4, 4, 4, 4) }
                        setOnClickListener { input.setText(hex) }
                    }
                    row.addView(sw)
                }
                box.addView(row)
            }
            box.addView(input)
            AlertDialog.Builder(a)
                .setTitle(prompt.title?.takeIf { it.isNotBlank() } ?: "Chọn màu")
                .setView(box)
                .setPositiveButton("OK") { _, _ ->
                    val v = input.text.toString().trim()
                    val ok = if (v.matches(Regex("#[0-9a-fA-F]{6}"))) v.lowercase() else (prompt.defaultValue ?: "#000000")
                    finish(prompt.confirm(ok))
                }
                .setNegativeButton("Huỷ") { _, _ -> finish(prompt.dismiss()) }
                .setOnCancelListener { finish(prompt.dismiss()) }
                .setOnDismissListener { finish(prompt.dismiss()) }
                .show()
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [prompt] không hiện được hộp chọn màu: ${e.javaClass.simpleName} ${e.message}")
            finish(prompt.dismiss())
        }
        return result
    }

    /** Đăng nhập HTTP (Basic/Digest) của trang hoặc của PROXY (vd proxy có tài khoản). */
    fun auth(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.AuthPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        if (!usable(act)) return GeckoResult.fromValue(prompt.dismiss())
        val a: Activity = act!!
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish(resp: GeckoSession.PromptDelegate.PromptResponse) { if (done.compareAndSet(false, true)) result.complete(resp) }
        val opts = prompt.authOptions
        val onlyPassword = (opts.flags and GeckoSession.PromptDelegate.AuthPrompt.AuthOptions.Flags.ONLY_PASSWORD) != 0
        val isProxy = (opts.flags and GeckoSession.PromptDelegate.AuthPrompt.AuthOptions.Flags.PROXY) != 0
        val failedBefore = (opts.flags and GeckoSession.PromptDelegate.AuthPrompt.AuthOptions.Flags.PREVIOUS_FAILED) != 0
        DebugLog.log("Khe $slotIndex: [prompt] yêu cầu đăng nhập HTTP (${if (isProxy) "PROXY" else "máy chủ"}, chỉ mật khẩu=$onlyPassword, lần trước sai=$failedBefore, uri=${opts.uri})")
        try {
            val density = a.resources.displayMetrics.density
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * density).toInt(), (8 * density).toInt(), (20 * density).toInt(), 0) }
            if (failedBefore) box.addView(TextView(a).apply { text = "Lần đăng nhập trước không đúng."; setTextColor(Color.RED) })
            val user = EditText(a).apply { inputType = InputType.TYPE_CLASS_TEXT; hint = "Tên đăng nhập"; setText(opts.username ?: "") }
            val pass = EditText(a).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; hint = "Mật khẩu"; setText(opts.password ?: "") }
            if (!onlyPassword) box.addView(user)
            box.addView(pass)
            AlertDialog.Builder(a)
                .setTitle(prompt.title?.takeIf { it.isNotBlank() } ?: (if (isProxy) "Proxy yêu cầu đăng nhập" else "Trang yêu cầu đăng nhập"))
                .setMessage(prompt.message ?: opts.uri ?: "")
                .setView(box)
                .setPositiveButton("Đăng nhập") { _, _ ->
                    finish(if (onlyPassword) prompt.confirm(pass.text.toString()) else prompt.confirm(user.text.toString(), pass.text.toString()))
                }
                .setNegativeButton("Huỷ") { _, _ -> finish(prompt.dismiss()) }
                .setOnCancelListener { finish(prompt.dismiss()) }
                .setOnDismissListener { finish(prompt.dismiss()) }
                .show()
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [prompt] không hiện được hộp đăng nhập: ${e.javaClass.simpleName} ${e.message}")
            finish(prompt.dismiss())
        }
        return result
    }

    /** onbeforeunload: trang hỏi có rời đi khi còn thay đổi chưa lưu. */
    fun beforeUnload(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.BeforeUnloadPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        // Không hiện được hộp thoại => CHO rời đi (chặn điều hướng mãi thì kẹt trang).
        if (!usable(act)) return GeckoResult.fromValue(prompt.confirm(AllowOrDeny.ALLOW))
        val a: Activity = act!!
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish(allow: Boolean) { if (done.compareAndSet(false, true)) result.complete(prompt.confirm(if (allow) AllowOrDeny.ALLOW else AllowOrDeny.DENY)) }
        DebugLog.log("Khe $slotIndex: [prompt] onbeforeunload của trang")
        try {
            AlertDialog.Builder(a)
                .setTitle("Rời khỏi trang này?")
                .setMessage("Các thay đổi bạn đã thực hiện có thể không được lưu.")
                .setPositiveButton("Rời đi") { _, _ -> finish(true) }
                .setNegativeButton("Ở lại") { _, _ -> finish(false) }
                .setOnCancelListener { finish(false) }
                .setOnDismissListener { finish(false) }
                .show()
        } catch (e: Throwable) { finish(true) }
        return result
    }

    /** Tải lại/quay lại trang đã gửi biểu mẫu (POST): hỏi trước khi gửi lại dữ liệu. */
    fun repost(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.RepostConfirmPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        if (!usable(act)) return GeckoResult.fromValue(prompt.confirm(AllowOrDeny.DENY))
        val a: Activity = act!!
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish(allow: Boolean) { if (done.compareAndSet(false, true)) result.complete(prompt.confirm(if (allow) AllowOrDeny.ALLOW else AllowOrDeny.DENY)) }
        DebugLog.log("Khe $slotIndex: [prompt] xác nhận gửi lại dữ liệu biểu mẫu (POST)")
        try {
            AlertDialog.Builder(a)
                .setTitle("Gửi lại biểu mẫu?")
                .setMessage("Trang này cần gửi lại dữ liệu bạn đã nhập trước đó. Việc này có thể lặp lại một thao tác (ví dụ đặt hàng, đăng bài).")
                .setPositiveButton("Gửi lại") { _, _ -> finish(true) }
                .setNegativeButton("Huỷ") { _, _ -> finish(false) }
                .setOnCancelListener { finish(false) }
                .setOnDismissListener { finish(false) }
                .show()
        } catch (e: Throwable) { finish(false) }
        return result
    }

    /**
     * Mục 169: trang đòi mở cửa sổ bật lên (window.open không do người dùng chạm) => Gecko chặn và hỏi app.
     * Không dùng hộp thoại chặn màn hình (quảng cáo sẽ làm phiền liên tục): chỉ hiện thanh thông báo nhỏ ở đáy "Đã chặn cửa sổ bật lên" kèm nút "Cho phép".
     * Hết thời gian / vuốt bỏ / có thông báo mới thay thế => TỪ CHỐI (an toàn mặc định).
     */
    fun popup(ctx: Context, slotIndex: Int, prompt: GeckoSession.PromptDelegate.PopupPrompt): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val act = activityOf(ctx)
        if (!usable(act)) return GeckoResult.fromValue(prompt.confirm(AllowOrDeny.DENY))
        val a: Activity = act!!
        val root: View? = a.findViewById(android.R.id.content)
        if (root == null) return GeckoResult.fromValue(prompt.confirm(AllowOrDeny.DENY))
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val done = AtomicBoolean(false)
        fun finish(allow: Boolean) { if (done.compareAndSet(false, true)) result.complete(prompt.confirm(if (allow) AllowOrDeny.ALLOW else AllowOrDeny.DENY)) }
        val host = try { android.net.Uri.parse(prompt.targetUri ?: "").host } catch (_: Throwable) { null }
        DebugLog.log("Khe $slotIndex: [prompt] trang đòi mở cửa sổ bật lên -> ${prompt.targetUri} (hiện thanh thông báo nhỏ, mặc định chặn)")
        try {
            Snackbar.make(root, "Đã chặn cửa sổ bật lên" + (if (!host.isNullOrBlank()) " ($host)" else ""), Snackbar.LENGTH_LONG)
                .setAction("Cho phép") { finish(true) }
                .addCallback(object : Snackbar.Callback() {
                    override fun onDismissed(transientBottomBar: Snackbar?, event: Int) { finish(false) }
                })
                .show()
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [prompt] không hiện được thông báo popup: ${e.javaClass.simpleName} ${e.message}")
            finish(false)
        }
        return result
    }

    /** Bộ xử lý đầy đủ cho các session phụ (popup của addon...) không có PromptDelegate riêng của app. */
    fun delegateFor(ctx: Context, slotIndex: Int): GeckoSession.PromptDelegate = object : GeckoSession.PromptDelegate {
        override fun onChoicePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ChoicePrompt) = choice(ctx, slotIndex, prompt)
        override fun onAlertPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.AlertPrompt) = alert(ctx, slotIndex, prompt)
        override fun onButtonPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ButtonPrompt) = button(ctx, slotIndex, prompt)
        override fun onTextPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.TextPrompt) = text(ctx, slotIndex, prompt)
        override fun onDateTimePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.DateTimePrompt) = dateTime(ctx, slotIndex, prompt)
        override fun onColorPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ColorPrompt) = color(ctx, slotIndex, prompt)
        override fun onAuthPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.AuthPrompt) = auth(ctx, slotIndex, prompt)
        override fun onBeforeUnloadPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.BeforeUnloadPrompt) = beforeUnload(ctx, slotIndex, prompt)
        override fun onRepostConfirmPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.RepostConfirmPrompt) = repost(ctx, slotIndex, prompt)
        override fun onPopupPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.PopupPrompt) = popup(ctx, slotIndex, prompt)
    }
}
