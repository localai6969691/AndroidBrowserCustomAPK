package com.colablive.keeper.core

import android.graphics.Bitmap
import android.util.LruCache

/**
 * Bản 7.83 — bộ nhớ đệm ảnh xem trước tab CÓ GIỚI HẠN BYTE.
 *
 * Trước đây `tabThumbnails` là `mutableMapOf<String, Bitmap>()` không giới hạn: mỗi ảnh tới ~1,2MB (480x624 ARGB_8888) và mọi ảnh giải mã từ đĩa khi mở lưới tab
 * đều bị giữ lại mãi => hàng trăm tab = hàng trăm MB..GB Java heap. Chrome giữ một bộ đệm ảnh có hạn, ảnh nào bị đẩy ra thì giải mã lại từ đĩa khi cần.
 * Giao diện giữ nguyên các thao tác cũ (get/set/putIfAbsent/remove) để không phải sửa nơi dùng.
 */
class ThumbCache(maxBytes: Int) {
    private val lru = object : LruCache<String, Bitmap>(maxBytes.coerceAtLeast(1 shl 20)) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.allocationByteCount.coerceAtLeast(1)
    }

    operator fun get(key: String): Bitmap? = lru.get(key)

    operator fun set(key: String, value: Bitmap) {
        lru.put(key, value)
    }

    fun putIfAbsent(key: String, value: Bitmap) {
        if (lru.get(key) == null) lru.put(key, value)
    }

    fun remove(key: String): Bitmap? = lru.remove(key)
}
