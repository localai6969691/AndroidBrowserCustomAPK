package com.colablive.keeper.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.Pattern

/**
 * Lấy favicon THEO URL trang, bằng HTTP — không hỏi JS trong trang (mục 99).
 *
 * Vì sao: cách cũ hỏi trang qua cầu nối content script, nhưng khi nhiều tab
 * cùng tải (session mới chưa kịp kết nối port) app phải "broadcast" lệnh tới
 * MỌI port và ai trả lời trước thì thắng => icon của tab này gán sang tab
 * khác (log: icon deepseek xuất hiện khi tải Google/Colab/Drive). Thêm nữa, cách
 * cũ bỏ hẳn tab nền ("không còn là tab active") nên tab tải nền không có icon.
 * Trình duyệt thật (Fenix/android-components BrowserIcons) làm khác: kết quả
 * chỉ phụ thuộc vào URL trang, không phụ thuộc trạng thái tab nào đang active.
 */
object FaviconResolver {
    private val cache = ConcurrentHashMap<String, Bitmap>()
    private val linkTag = Pattern.compile("<link\\b[^>]*>", Pattern.CASE_INSENSITIVE)
    private val relAttr = Pattern.compile("\\brel\\s*=\\s*[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE)
    private val hrefAttr = Pattern.compile("\\bhref\\s*=\\s*[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE)
    private val sizesAttr = Pattern.compile("\\bsizes\\s*=\\s*[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE)
    private const val UA = "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0"

    fun originOf(pageUrl: String): String? = try {
        val u = URL(pageUrl)
        if (u.protocol != "http" && u.protocol != "https") null else u.protocol + "://" + u.host
    } catch (e: Exception) { null }

    fun cached(pageUrl: String): Bitmap? = originOf(pageUrl)?.let { cache[it] }

    /** Chạy trên luồng nền. `plausible(iconHost)` do bên gọi cung cấp (chặn icon sai miền). */
    fun resolve(pageUrl: String, plausible: (String) -> Boolean, log: (String) -> Unit): Bitmap? {
        val origin = originOf(pageUrl) ?: return null
        cache[origin]?.let { return it }
        val candidates = ArrayList<Pair<String, Int>>() // url, điểm
        try {
            val conn = URL(pageUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 5000; conn.readTimeout = 5000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept", "text/html,*/*")
            val code = conn.responseCode
            val finalHost = conn.url.host
            // Nếu bị chuyển sang miền khác (vd đăng nhập accounts.google.com) thì HTML đó KHÔNG phải của trang này.
            val sameSite = finalHost.equals(URL(pageUrl).host, ignoreCase = true)
            if (code in 200..299 && sameSite) {
                val buf = ByteArray(256 * 1024)
                var n = 0
                conn.inputStream.use { ins ->
                    while (n < buf.size) { val r = ins.read(buf, n, buf.size - n); if (r <= 0) break; n += r }
                }
                val html = String(buf, 0, n, Charsets.UTF_8)
                val base = conn.url
                val m = linkTag.matcher(html)
                while (m.find()) {
                    val tag = m.group()
                    val relM = relAttr.matcher(tag)
                    if (!relM.find()) continue
                    val rel = relM.group(1).lowercase()
                    if (!rel.contains("icon") || rel.contains("mask-icon")) continue
                    val hrefM = hrefAttr.matcher(tag)
                    if (!hrefM.find()) continue
                    val href = hrefM.group(1)
                    if (href.isBlank() || href.startsWith("data:")) continue
                    val abs = try { URL(base, href).toString() } catch (e: Exception) { null }
                    if (abs == null) continue
                    var score = 16
                    val sm = sizesAttr.matcher(tag)
                    if (sm.find()) {
                        val sz = sm.group(1).lowercase()
                        score = if (sz.contains("any")) 64
                        else (Regex("(\\d+)x(\\d+)").find(sz)?.groupValues?.get(1)?.toIntOrNull() ?: 16)
                    }
                    if (rel.contains("apple-touch")) score = minOf(score, 64)
                    candidates.add(abs to score)
                }
            } else {
                log("[favicon] bỏ qua HTML (HTTP $code, host cuối=$finalHost, cùng site=$sameSite) — dùng /favicon.ico của $origin")
            }
            conn.disconnect()
        } catch (e: Exception) {
            log("[favicon] lỗi lấy HTML $pageUrl: ${e.javaClass.simpleName}: ${e.message}")
        }
        val ordered = candidates.sortedByDescending { it.second }.map { it.first }.distinct().take(3).toMutableList()
        ordered.add("$origin/favicon.ico")
        for (iconUrl in ordered) {
            val host = try { URL(iconUrl).host } catch (e: Exception) { continue }
            if (!plausible(host)) { log("[favicon] bỏ icon $iconUrl — miền không hợp lý với trang $pageUrl"); continue }
            val bmp = download(iconUrl, log) ?: continue
            cache[origin] = bmp
            log("[favicon] OK $iconUrl (${bmp.width}x${bmp.height}) cho $origin")
            return bmp
        }
        return null
    }

    private fun download(iconUrl: String, log: (String) -> Unit): Bitmap? {
        return try {
            val c = URL(iconUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            if (c.responseCode !in 200..299) { log("[favicon] $iconUrl → HTTP ${c.responseCode}"); c.disconnect(); return null }
            val bytes = c.inputStream.use { it.readBytes() }
            c.disconnect()
            if (bytes.isEmpty() || bytes.size > 2 * 1024 * 1024) return null
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: try {
                val svg = com.caverock.androidsvg.SVG.getFromString(String(bytes, Charsets.UTF_8))
                svg.setDocumentWidth(64f); svg.setDocumentHeight(64f)
                val b = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
                svg.renderToCanvas(Canvas(b)); b
            } catch (e: Exception) { null }
        } catch (e: Exception) {
            log("[favicon] tải $iconUrl lỗi ${e.javaClass.simpleName}: ${e.message}"); null
        }
    }
}
