package com.colablive.keeper.features.ebookleech.model

import android.content.Context
import com.colablive.keeper.core.AppPrefs
import org.json.JSONArray
import java.util.UUID

/**
 * Repository lưu danh sách LeechJob vào SharedPreferences theo slotIndex.
 * Mỗi slot (instance browser) có danh sách job riêng biệt.
 */
object LeechJobRepository {

    private const val FEATURE_ID = "ebook_leech"
    private const val KEY_JOBS = "jobs_json"

    // -------------------------------------------------------------------------
    // CRUD
    // -------------------------------------------------------------------------

    fun loadAll(context: Context, slotIndex: Int): MutableList<LeechJob> {
        val raw = AppPrefs.getString(context, slotIndex, FEATURE_ID, KEY_JOBS, "[]")
        return try {
            LeechJob.listFromJson(JSONArray(raw)).toMutableList()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, slotIndex: Int, jobs: List<LeechJob>) {
        AppPrefs.setString(
            context, slotIndex, FEATURE_ID, KEY_JOBS,
            LeechJob.listToJson(jobs).toString()
        )
    }

    fun addJob(context: Context, slotIndex: Int, job: LeechJob) {
        val jobs = loadAll(context, slotIndex)
        jobs.add(job)
        save(context, slotIndex, jobs)
    }

    fun updateJob(context: Context, slotIndex: Int, updated: LeechJob) {
        val jobs = loadAll(context, slotIndex)
        val idx = jobs.indexOfFirst { it.id == updated.id }
        if (idx >= 0) jobs[idx] = updated else jobs.add(updated)
        save(context, slotIndex, jobs)
    }

    fun deleteJob(context: Context, slotIndex: Int, jobId: String) {
        val jobs = loadAll(context, slotIndex).filter { it.id != jobId }
        save(context, slotIndex, jobs)
    }

    fun getJob(context: Context, slotIndex: Int, jobId: String): LeechJob? =
        loadAll(context, slotIndex).firstOrNull { it.id == jobId }

    fun newId(): String = UUID.randomUUID().toString()
}
