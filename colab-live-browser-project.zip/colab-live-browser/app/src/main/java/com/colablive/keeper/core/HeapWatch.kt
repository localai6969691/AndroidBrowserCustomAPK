package com.colablive.keeper.core

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Bản 7.92 — THEO DÕI HEAP JAVA CỦA CẢ TIẾN TRÌNH (không phụ thuộc Activity).
 *
 * Log crash 20:39 (OutOfMemoryError, giới hạn heap 256MB): `java=` trong dòng [RAM] tăng đều ~3,5MB/phút khi máy thức, 138MB -> 198MB trong 60 phút, và tiếp tục
 * sau khi Activity bị huỷ (vòng giám sát của Activity đã dừng) cho tới khi hết heap. Vòng giám sát cũ nằm trong MainActivity nên KHÔNG nhìn thấy gì sau onDestroy, và
 * dòng [RAM] chỉ có con số PSS thô — không nói được thứ gì đang giữ bộ nhớ. Lớp này chạy theo tiến trình (luồng riêng, tính theo uptime nên không đánh thức máy):
 *  1. mỗi 5 phút ghi `[heap] đang dùng/giới hạn + xu hướng MB/phút` (xu hướng lấy theo MỨC THẤP NHẤT của nửa trước/nửa sau để bỏ nhiễu răng cưa của GC);
 *  2. khi heap (sau khi ép GC) vượt 50% / 65% / 80% / 88% giới hạn: ghi `[heap] THỐNG KÊ` gồm kích thước mọi cấu trúc sống lâu đã đăng ký (engine...), số luồng theo tên;
 *  3. từ 80%: yêu cầu engine LƯU TRẠNG THÁI TAB xuống đĩa ngay (nếu tiến trình chết vì OOM thì lần mở sau khôi phục đúng các tab);
 *  4. từ 88% (một lần mỗi tiến trình, tắt được bằng pref `heap_dump_auto`): ghi một tệp .hprof vào thư mục dữ liệu ngoài của app để TRUY RA đúng đối tượng đang giữ bộ nhớ.
 * Không đổi hành vi nào khác của app.
 */
object HeapWatch {
    private const val MB = 1024L * 1024L
    private const val TICK_MS = 60_000L
    private const val LOG_EVERY_TICKS = 5
    private const val MAX_SAMPLES = 60

    private var thread: HandlerThread? = null
    private var worker: Handler? = null
    @Volatile private var started = false
    private var appCtx: Context? = null
    private var slot = 0
    private var onHigh: (() -> Unit)? = null
    private val census = ConcurrentHashMap<String, () -> String>()
    private val samples = ArrayDeque<LongArray>() // [uptimeMs, usedMb]
    private var tick = 0
    private var levelDone = 0
    private var dumped = false

    private val tickRunnable = object : Runnable {
        override fun run() {
            try { onTick() } catch (_: Throwable) { /* chỉ là chẩn đoán */ }
            worker?.postDelayed(this, TICK_MS)
        }
    }

    fun usedMb(): Long { val rt = Runtime.getRuntime(); return (rt.totalMemory() - rt.freeMemory()) / MB }
    fun maxMb(): Long = (Runtime.getRuntime().maxMemory() / MB).coerceAtLeast(1L)

    /** Đăng ký một hàm trả về chuỗi thống kê kích thước các cấu trúc sống lâu của một thành phần (gọi ở thời điểm khởi tạo thành phần). */
    fun addCensus(name: String, fn: () -> String) { census[name] = fn }

    @Synchronized fun start(context: Context, slotIndex: Int, onHighCallback: () -> Unit) {
        if (started) return
        started = true
        appCtx = context.applicationContext
        slot = slotIndex
        onHigh = onHighCallback
        val t = HandlerThread("lb-heapwatch")
        t.isDaemon = true
        t.start()
        thread = t
        val h = Handler(t.looper)
        worker = h
        h.postDelayed(tickRunnable, TICK_MS)
        DebugLog.log("Khe $slotIndex: [heap] bắt đầu theo dõi heap Java của tiến trình (giới hạn ${maxMb()}MB)")
    }

    /** Một đoạn ngắn cho dòng [RAM]: "heap Java dùng 120MB/256MB (46%), xu hướng +3.5MB/phút". */
    fun describe(): String {
        val used = usedMb(); val max = maxMb()
        val tr = trendMbPerMin()
        val trText = if (tr == null) "" else ", xu hướng " + String.format(Locale.US, "%+.1f", tr) + "MB/phút"
        return "heap Java dùng ${used}MB/${max}MB (${used * 100 / max}%)$trText"
    }

    @Synchronized private fun trendMbPerMin(): Double? {
        if (samples.size < 6) return null
        val list = samples.toList()
        val half = list.size / 2
        val a = list.subList(0, half).minByOrNull { it[1] } ?: return null
        val b = list.subList(half, list.size).minByOrNull { it[1] } ?: return null
        val dtMin = (b[0] - a[0]) / 60_000.0
        if (dtMin < 1.0) return null
        return (b[1] - a[1]) / dtMin
    }

    private fun onTick() {
        tick++
        val used = usedMb(); val max = maxMb()
        synchronized(this) {
            samples.addLast(longArrayOf(SystemClock.uptimeMillis(), used))
            while (samples.size > MAX_SAMPLES) samples.removeFirst()
        }
        val rawPct = (used * 100 / max).toInt()
        if (tick % LOG_EVERY_TICKS == 0) DebugLog.log("Khe $slot: [heap] ${describe()}")
        if (rawPct < 45) return
        // "Đang dùng" gồm cả rác chưa thu; ép GC rồi đo lại để biết phần SỐNG thật sự.
        try { System.gc() } catch (_: Throwable) {}
        val live = usedMb()
        val pct = (live * 100 / max).toInt()
        val level = when { pct >= 88 -> 4; pct >= 80 -> 3; pct >= 65 -> 2; pct >= 50 -> 1; else -> 0 }
        if (level <= levelDone) return
        levelDone = level
        DebugLog.log("Khe $slot: [heap] ⚠ phần SỐNG sau GC = ${live}MB/${max}MB ($pct%, mức $level/4) — ${describe()} | THỐNG KÊ: ${censusText()}")
        if (level >= 3) {
            try { onHigh?.invoke() } catch (_: Throwable) {}
            DebugLog.log("Khe $slot: [heap] heap sắp cạn — đã yêu cầu lưu trạng thái tab xuống đĩa để lần mở sau khôi phục được nếu tiến trình chết vì hết bộ nhớ")
        }
        if (level >= 4 && !dumped) {
            dumped = true
            DebugLog.log("Khe $slot: [heap] dump heap: ${dumpHprof()}")
        }
    }

    private fun censusText(): String {
        val sb = StringBuilder()
        for ((name, fn) in census) {
            val txt = try { fn() } catch (e: Throwable) { "lỗi ${e.javaClass.simpleName}" }
            sb.append(name).append(": ").append(txt).append(" | ")
        }
        sb.append("DebugLog dòng=").append(DebugLog.entryCount()).append(" | ").append(threadSummary())
        return sb.toString()
    }

    private fun threadSummary(): String {
        val names = Thread.getAllStackTraces().keys.map { it.name.replace(Regex("[0-9]+"), "#") }
        val top = names.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(6)
        return "luồng=${names.size} [" + top.joinToString(", ") { it.key + "×" + it.value } + "]"
    }

    private fun dumpHprof(): String {
        val c = appCtx ?: return "bỏ qua: chưa có context"
        if (!AppPrefs.getBoolean(c, slot, "heap_dump_auto", true)) return "bỏ qua: pref heap_dump_auto đang tắt"
        return try {
            val dir = c.getExternalFilesDir(null) ?: c.filesDir
            val free = dir.usableSpace / MB
            if (free < 600L) return "bỏ qua: chỉ còn ${free}MB trống (cần >= 600MB)"
            val f = java.io.File(dir, "heap_near_oom_khe$slot.hprof")
            android.os.Debug.dumpHprofData(f.absolutePath)
            "đã ghi ${f.absolutePath} (${f.length() / MB}MB) — nén zip rồi gửi để truy đối tượng giữ bộ nhớ"
        } catch (e: Throwable) {
            "LỖI ${e.javaClass.simpleName}: ${e.message}"
        }
    }
}
