package com.colablive.keeper.features.downloads

import android.content.Context
import android.net.Uri
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.ProfileSlots
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * LỊCH SỬ FILE ĐÃ TẢI XUỐNG — tính năng thiếu thật (người dùng yêu cầu:
 * "hiện những file đã tải xuống").
 *
 * BUG GỐC đã xác định trước khi thêm file này: `DownloadEngine.getAllDownloads()`
 * (dùng bởi cả `IDMDownloadDialog` lẫn `DownloadManagerFeature.showDownloadList()`
 * cũ) chỉ đọc từ 1 `ConcurrentHashMap` SỐNG TRONG BỘ NHỚ (RAM) của
 * `DownloadEngine` — KHÔNG hề được ghi xuống đĩa ở đâu cả. Vì app này bị
 * RESTART RẤT THƯỜNG XUYÊN trong thực tế sử dụng (xem PROJECT_STATUS.md —
 * ghi đè/xoá hồ sơ, chuyển khe, crash... đều khởi động lại tiến trình),
 * danh sách download hiện trong 2 dialog trên BIẾN MẤT HOÀN TOÀN mỗi lần
 * app restart — dù file THẬT SỰ vẫn còn nguyên trên máy (đã copy công
 * khai qua MediaStore/SAF ở `DownloadEngine.finalizeDownload()` từ trước
 * khi restart xảy ra). Đây chính là nguyên nhân hiện tượng "không hiện
 * file đã tải xuống" — không phải file bị mất, mà là DANH SÁCH hiển thị
 * chưa từng được lưu lại.
 *
 * Sửa bằng cách LƯU BỀN 1 bản ghi nhẹ (tên file, URI công khai thật, MIME,
 * dung lượng, thời điểm, nơi lưu) MỖI KHI 1 download hoàn tất thành công.
 * Chỉ cần gọi `record()` từ ĐÚNG 1 CHỖ DUY NHẤT
 * (`DownloadEngine.finalizeDownload()`, nơi ĐÃ XÁC NHẬN copy công khai
 * xong, có URI thật trong tay) — không cần sửa từng nơi gọi
 * `startDownload()`/`startDownloadFromLocalFile()` rải rác khắp codebase
 * (YouTube, HLS, sniffed link, ebook, web archive...).
 *
 * Ghi trực tiếp JSON ra `context.filesDir` (KHÔNG dùng SharedPreferences —
 * tránh giới hạn kích thước XML thường gặp nếu danh sách dài, và để dễ
 * đọc/debug bằng mắt qua `adb pull` nếu cần) — cùng kỹ thuật atomic
 * tmp-file-rồi-rename đã dùng ở `BrowserHistory` (tránh file half-written
 * nếu app bị kill giữa lúc ghi — đúng loại bug đã gặp nhiều lần với
 * `saved_tabs.json`/`history.json` trước đây).
 *
 * MỤC 109 — ĐỔI THIẾT KẾ theo yêu cầu người dùng ("lịch sử download không được backup trong profile"):
 * trước đây file này nằm ở `filesDir/download_history.json`, DÙNG CHUNG mọi khe/hồ sơ và KHÔNG nằm trong thư mục hồ sơ nên
 * xuất/nhập hồ sơ không mang theo. Giờ lưu NGAY TRONG thư mục hồ sơ Gecko (`gecko_profile_<hồ sơ>/download_history.json`,
 * cùng chỗ với `history.json`, `bookmarks.json`, `saved_tabs.json`) — `ProfileExportImport.zipDirRecursive` nén mọi file
 * trong thư mục nên nó tự đi theo backup, và mỗi hồ sơ có danh sách tải riêng (tải ở hồ sơ A không hiện ở hồ sơ B).
 *
 * Di chuyển dữ liệu cũ: lần đầu có một hồ sơ đọc/ghi mà chưa có file riêng, nếu file chung cũ còn thì CHUYỂN NÓ VÀO hồ sơ đó
 * (đổi tên file cũ thành `.migrated`, chỉ một hồ sơ nhận — danh sách cũ vốn là của chung nên không thể biết mục nào thuộc hồ sơ
 * nào, nhân bản cho mọi hồ sơ sẽ gây trùng lặp). Hồ sơ nào mở trước thì nhận (thường là khe 0).
 *
 * Lưu ý khi khôi phục sang máy khác: mục chỉ là bản ghi (tên + URI công khai); file thật không đi theo backup. Mục trỏ tới file
 * không còn tồn tại sẽ mở lỗi chứ không làm hỏng gì — danh sách vẫn xoá được từng mục.
 */
object DownloadHistoryStore {
    private const val MAX_ENTRIES = 500
    private val lock = Any()

    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    private fun storeFile(context: Context, slotIndex: Int): File {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, safeDirNameFor(profileNamespace))
        dir.mkdirs()
        return File(dir, "download_history.json")
    }

    /** File chung CŨ (trước mục 109) — chỉ còn dùng để chuyển dữ liệu sang hồ sơ đầu tiên đụng tới. */
    private fun legacyFile(context: Context): File = File(context.filesDir, "download_history.json")

    private fun readArray(context: Context, slotIndex: Int): JSONArray {
        val f = storeFile(context, slotIndex)
        if (!f.exists()) {
            // Chuyển dữ liệu cũ vào hồ sơ này (một lần, một hồ sơ duy nhất nhận).
            val legacy = legacyFile(context)
            if (legacy.exists()) {
                val arr = try { JSONArray(legacy.readText()) } catch (e: Exception) { JSONArray() }
                try {
                    writeArray(context, slotIndex, arr)
                    legacy.renameTo(File(legacy.parentFile, "download_history.json.migrated"))
                    DebugLog.log("DownloadHistoryStore: đã chuyển ${arr.length()} mục lịch sử tải cũ (dùng chung) vào hồ sơ của khe $slotIndex — từ nay lịch sử tải đi theo backup hồ sơ")
                } catch (e: Exception) {
                    DebugLog.log("DownloadHistoryStore: chuyển lịch sử cũ lỗi (${e.message}) — giữ nguyên file cũ")
                }
                return arr
            }
            return JSONArray()
        }
        return try { JSONArray(f.readText()) } catch (e: Exception) { JSONArray() }
    }

    private fun writeArray(context: Context, slotIndex: Int, arr: JSONArray) {
        val f = storeFile(context, slotIndex)
        val tmp = File(f.parentFile, "download_history.json.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(f)) {
            // Một số hệ thống file không cho rename đè — ghi thẳng làm dự phòng.
            f.writeText(arr.toString())
            tmp.delete()
        }
    }

    data class Entry(
        val fileName: String,
        val uri: String,
        val mimeType: String,
        val sizeBytes: Long,
        val timestamp: Long,
        val saveLocation: String
    )

    /**
     * Gọi NGAY SAU KHI 1 download đã copy công khai xong thành công
     * (`uri != null` ở `DownloadEngine.finalizeDownload()`). Chạy đồng bộ
     * — hàm gọi (`finalizeDownload`) đã ở trên luồng nền của executor
     * riêng, không có rủi ro chặn UI thread.
     */
    fun record(context: Context, slotIndex: Int, fileName: String, uri: Uri, mimeType: String, sizeBytes: Long, saveLocation: String) {
        synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                arr.put(JSONObject().apply {
                    put("fileName", fileName)
                    put("uri", uri.toString())
                    put("mimeType", mimeType)
                    put("sizeBytes", sizeBytes)
                    put("timestamp", System.currentTimeMillis())
                    put("saveLocation", saveLocation)
                })
                // Giới hạn số bản ghi — bài học từ bug "cache phình vô hạn"
                // (mục 8s trong PROJECT_STATUS.md), không lặp lại lỗi đó ở
                // đây. Cắt bớt bản ghi CŨ NHẤT, giữ lại MAX_ENTRIES bản mới
                // nhất.
                val trimmed = if (arr.length() > MAX_ENTRIES) {
                    JSONArray().also {
                        for (i in (arr.length() - MAX_ENTRIES) until arr.length()) it.put(arr.get(i))
                    }
                } else arr
                writeArray(context, slotIndex, trimmed)
            } catch (e: Exception) {
                DebugLog.log("DownloadHistoryStore.record lỗi: ${e.message}")
            }
        }
    }

    /** Mới nhất trước — giống Chrome Downloads: file tải gần đây nhất nằm
     * trên cùng danh sách. */
    fun getAll(context: Context, slotIndex: Int): List<Entry> {
        synchronized(lock) {
            return try {
                val arr = readArray(context, slotIndex)
                val list = mutableListOf<Entry>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Entry(
                            fileName = o.optString("fileName"),
                            uri = o.optString("uri"),
                            mimeType = o.optString("mimeType", "application/octet-stream"),
                            sizeBytes = o.optLong("sizeBytes", -1),
                            timestamp = o.optLong("timestamp", 0),
                            saveLocation = o.optString("saveLocation", "downloads")
                        )
                    )
                }
                list.sortedByDescending { it.timestamp }
            } catch (e: Exception) {
                DebugLog.log("DownloadHistoryStore.getAll lỗi: ${e.message}")
                emptyList()
            }
        }
    }

    /**
     * Xoá 1 bản ghi khỏi LỊCH SỬ HIỂN THỊ — KHÔNG tự xoá file thật trên
     * máy (xoá file thật cần API khác nhau tuỳ URI là MediaStore hay SAF
     * hay file:// thường, xem
     * `DownloadManagerFeature.showDownloadedFilesList()` — nơi gọi tự lo
     * xoá file thật TRƯỚC rồi mới gọi hàm này để dọn bản ghi).
     */
    fun remove(context: Context, slotIndex: Int, uri: String) {
        synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                val newArr = JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("uri") != uri) newArr.put(o)
                }
                writeArray(context, slotIndex, newArr)
            } catch (e: Exception) {
                DebugLog.log("DownloadHistoryStore.remove lỗi: ${e.message}")
            }
        }
    }
}
