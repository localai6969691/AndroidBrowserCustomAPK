package com.colablive.keeper.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Bản 7.114 — LOGIC THUẦN của kho favicon trên đĩa (không đụng Android; kiểm thử được).
 *
 * VÌ SAO: tab chưa có favicon vẽ chấm tròn màu theo khe (xanh dương ở khe 0 — `createTabChip`). `FaviconResolver.cache` và `BrowserTab.favicon` chỉ nằm trong RAM theo tiến trình nên sau khi app chết
 * (crash 22/11 23:02:49, vuốt tắt, hệ thống giết) mọi tab khôi phục quay về chấm xanh, trong khi tiêu đề (saved_tabs.json) và ảnh xem trước (colablive_tab_thumbs, 7.109) vẫn còn và đi theo hồ sơ khi xuất/nhập.
 * Favicon lưu cùng thư mục hồ sơ nên đi theo gói xuất/nhập y như hai thứ kia (`ProfileExportImport.zipDirRecursive` nén đệ quy mọi tệp không phải .sqlite).
 */
object FaviconStoreLogic {
    /** Cạnh dài tối đa khi lưu (apple-touch-icon có thể 180–512px; chip chỉ vẽ 24dp). Không bao giờ phóng to. */
    const val MAX_EDGE = 128
    /** Favicon của URL không còn tab nào mở và quá ngần này thì dọn (giống ảnh xem trước: tab vừa đóng vẫn giữ vài ngày cho "đóng gần đây"). */
    const val ORPHAN_MS = 3L * 24 * 3600 * 1000
    /** Trần cứng số tệp; chỉ xoá tệp của URL không còn tab mở. */
    const val HARD_CAP = 4000

    /** Tên tệp theo URL (bỏ #fragment) — cùng quy ước khoá với ảnh xem trước nên không phụ thuộc id tab (id tab không sống qua lần khởi động). */
    fun fileNameForUrl(url: String): String {
        val key = url.substringBefore('#')
        val h = MessageDigest.getInstance("SHA-1").digest(key.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        return "$h.png"
    }

    /** Kích thước lưu: giữ tỉ lệ, cạnh dài <= [maxEdge], không phóng to, mỗi cạnh >= 1. */
    fun targetSize(w: Int, h: Int, maxEdge: Int = MAX_EDGE): Pair<Int, Int> {
        if (w <= 0 || h <= 0) return Pair(1, 1)
        val longest = maxOf(w, h)
        if (longest <= maxEdge) return Pair(w, h)
        val f = maxEdge.toDouble() / longest
        return Pair(maxOf(1, Math.round(w * f).toInt()), maxOf(1, Math.round(h * f).toInt()))
    }

    class Entry(val name: String, val lastModified: Long)

    /** Tệp cần xoá: (1) không thuộc tab đang mở và quá [ORPHAN_MS]; (2) vượt [HARD_CAP] (mới nhất trước) và không thuộc tab đang mở. Tệp của tab đang mở KHÔNG BAO GIỜ bị xoá. */
    fun selectDeletions(entries: List<Entry>, keep: Set<String>, now: Long): List<String> {
        val out = ArrayList<String>()
        val rest = ArrayList<Entry>()
        for (e in entries) {
            if (e.name !in keep && e.lastModified < now - ORPHAN_MS) out.add(e.name) else rest.add(e)
        }
        rest.sortedByDescending { it.lastModified }.forEachIndexed { i, e -> if (i >= HARD_CAP && e.name !in keep) out.add(e.name) }
        return out
    }
}

/** Phần có Android: đọc/ghi PNG. Gọi ở LUỒNG NỀN. [dir] do bên gọi cho (thư mục hồ sơ `colablive_tab_favicons`). */
class FaviconStore(private val dir: () -> File) {
    /** Lưu favicon của [url]. Ghi ra tệp tạm rồi đổi tên (xuất hồ sơ đang nén thư mục này không đọc phải ảnh ghi dở). */
    fun save(url: String, bmp: Bitmap, keepNames: Set<String>, doCleanup: Boolean) {
        try {
            val d = dir(); d.mkdirs()
            val (w, h) = FaviconStoreLogic.targetSize(bmp.width, bmp.height)
            val toSave = if (w == bmp.width && h == bmp.height) bmp else Bitmap.createScaledBitmap(bmp, w, h, true)
            val file = File(d, FaviconStoreLogic.fileNameForUrl(url))
            val tmp = File(d, file.name + ".tmp")
            FileOutputStream(tmp).use { toSave.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
            if (toSave !== bmp) toSave.recycle()
            if (doCleanup) {
                val entries = d.listFiles()?.filter { it.isFile && it.name.endsWith(".png") }?.map { FaviconStoreLogic.Entry(it.name, it.lastModified()) } ?: return
                for (n in FaviconStoreLogic.selectDeletions(entries, keepNames, System.currentTimeMillis())) try { File(d, n).delete() } catch (_: Exception) {}
            }
        } catch (_: Exception) { /* chỉ là bộ nhớ đệm hiển thị */ }
    }

    fun load(url: String): Bitmap? = try {
        val f = File(dir(), FaviconStoreLogic.fileNameForUrl(url))
        if (f.isFile && f.length() > 0L) BitmapFactory.decodeFile(f.absolutePath) else null
    } catch (_: Throwable) { null }
}
