package com.colablive.keeper.features.ebookleech.engine

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.colablive.keeper.core.GeckoViewEngine

/**
 * ═══════════════════════════════════════════════════════════════════════
 * BẢN SỬA SAU KHI ĐỌC SOURCE THẬT (colab-live-browser) — bản trước đây SAI
 * ở giả định gốc rễ:
 *
 *   Trước đây giả định: GeckoSession có `evaluateJS(js)` gọi trực tiếp,
 *   dùng 1 GeckoSession ẨN riêng cho crawl, tách biệt hoàn toàn với tab
 *   người dùng thấy.
 *
 *   SỰ THẬT (đọc trực tiếp GeckoViewEngine.kt): project này KHÔNG dùng
 *   `session.evaluateJS()` ở bất kỳ đâu. Toàn bộ `evaluateJs()` chạy qua 1
 *   WebExtension nội bộ tên "eval_bridge" (native messaging port,
 *   content script `document_idle`, xem assets/eval_bridge/content.js) —
 *   và `GeckoViewEngine.evaluateJs()` (public, đúng interface BrowserEngine)
 *   LUÔN nhắm vào `activeTabId` — KHÔNG có cách nào (qua API public) nhắm
 *   một session không phải tab đang active.
 *
 * THIẾT KẾ MỚI: dùng đúng API public đã có sẵn —
 *   `engine.createTab(url, isPrivate)` → tạo 1 tab RIÊNG cho việc crawl
 *   `engine.switchToTab(tabId)` → biến tab đó thành active (bắt buộc, vì
 *      evaluateJs chỉ nhắm active tab)
 *   `engine.loadUrl(url)` → điều hướng tab đang active
 *   `engine.evaluateJs(script, callback)` → chạy qua eval_bridge thật
 *   `engine.closeTab(tabId)` → dọn dẹp khi xong
 *
 * ĐÁNH ĐỔI PHẢI NÓI THẲNG: vì evaluateJs chỉ nhắm active tab, quá trình
 * crawl sẽ làm TAB CỦA SLOT ĐÓ NHẢY QUA TAB CRAWL trong lúc chạy — nếu
 * người dùng đang thật sự nhìn vào browser lúc đó (không phải màn hình
 * tắt/app nền), họ sẽ THẤY tab nhảy tới nhảy lui. Code bên dưới tự động
 * chuyển về đúng tab người dùng đang xem TRƯỚC KHI bắt đầu crawl, ngay khi
 * crawl xong (xem `restoreActiveTabAfter`), nhưng khoảng thời gian ĐANG
 * crawl vẫn hiển thị tab crawl nếu app đang mở màn hình đó. Đây là giới
 * hạn kiến trúc thật, không phải lỗi có thể sửa nhẹ — muốn tránh hẳn cần
 * GeckoViewEngine.kt hỗ trợ true headless session (thay đổi core project,
 * ngoài phạm vi 1 addon).
 *
 * Kết quả trả về từ `evaluateJs()` KHÔNG phải JSON thô — content.js của
 * eval_bridge bọc thành chuỗi `"OK: " + String(value)` hoặc `"LOI: " +
 * message` (xem content.js thật) — PHẢI bóc tiền tố này trước khi
 * `JSONObject(...)`, bản trước đây parse thẳng nên chắc chắn lỗi.
 *
 * DÒ AJAX: bản trước dùng 1 WebExtension riêng (`ebook_ajax_sniffer`)
 * đóng gói cứng trong APK vì cần content script `document_start` — đây là
 * NGOẠI LỆ DUY NHẤT từng khiến addon không thể 100% tách rời khỏi APK.
 * ĐÃ BỎ: chuyển sang tiêm `AJAX_PATCH_SCRIPT` qua chính `evaluateJs()`
 * ngay khi trang vừa "readyState complete" — mất khả năng bắt request
 * TRONG LÚC trang tải ban đầu (đổi lại), nhưng loại bỏ hoàn toàn nhu cầu
 * đóng gói bất kỳ file nào vào APK — giờ 100% EbookLeech nằm trong 1 file
 * `.jar` plugin, không còn ngoại lệ nào.
 * ═══════════════════════════════════════════════════════════════════════
 */
private const val TAG = "EbookLeechEval"
private val handler = Handler(Looper.getMainLooper())

/**
 * Chạy 1 script trên 1 URL, trong tab crawl riêng (đã tạo từ trước qua
 * `openCrawlTab`). KHÔNG tự tạo/đóng tab ở đây — crawler quản lý vòng đời
 * tab 1 lần cho cả job (tạo lúc bắt đầu, đóng lúc kết thúc), tránh chi phí
 * tạo/huỷ session liên tục cho từng chương.
 */
fun GeckoViewEngine.evaluateJsOnTab(
    crawlTabId: String,
    url: String,
    js: String,
    timeoutMs: Long = 15_000L,
    installAjaxPatchFirst: Boolean = false,
    onResult: (String) -> Unit,
    onError: (String) -> Unit,
) {
    if (Looper.myLooper() != Looper.getMainLooper()) {
        handler.post { evaluateJsOnTab(crawlTabId, url, js, timeoutMs, installAjaxPatchFirst, onResult, onError) }
        return
    }

    switchToTab(crawlTabId)
    loadUrl(url)

    var done = false
    val timeoutRunnable = Runnable {
        if (!done) { done = true; onError("Timeout sau ${timeoutMs}ms: $url") }
    }
    handler.postDelayed(timeoutRunnable, timeoutMs)

    // Không có API public để biết "trang tải xong" theo tabId cụ thể
    // (onPageLoadedListener là 1 listener DUY NHẤT cho cả engine, dùng cho
    // UI — hijack nó ở đây sẽ đá văng listener thật của MainActivity, KHÔNG
    // làm vậy). Thay bằng polling document.readyState qua chính evaluateJs
    // — tự chứa, không đụng gì tới listener sẵn có.
    pollUntilReady(this, remainingMs = timeoutMs) { ready ->
        if (done) return@pollUntilReady
        if (!ready) {
            done = true
            handler.removeCallbacks(timeoutRunnable)
            onError("Trang không tải xong trong ${timeoutMs}ms: $url")
            return@pollUntilReady
        }

        // Dò AJAX (nếu bật): tiêm script patch fetch/XHR NGAY LÚC NÀY —
        // sớm nhất có thể qua evaluateJs public, KHÔNG cần content script
        // đóng gói sẵn trong APK nữa (bản trước dùng 1 WebExtension riêng
        // document_start cho việc này — bỏ hẳn, xem chú thích cuối file).
        // ĐÁNH ĐỔI PHẢI NÓI RÕ: patch cài SAU khi trang đã "readyState
        // complete", nên fetch/XHR trang gọi TRONG LÚC tải ban đầu (trước
        // khi ta kịp patch) sẽ KHÔNG bắt được — chỉ bắt được request xảy ra
        // SAU thời điểm này (vd do ta tự cuộn/lazy-load kích hoạt, hoặc
        // trang tự gọi thêm sau khi render xong).
        if (installAjaxPatchFirst) {
            evaluateJs(AJAX_PATCH_SCRIPT) { /* fire-and-forget, không cần chờ kết quả cài đặt */ }
        }

        // Đợi thêm 800ms cho JS framework (React/Vue...) render xong sau
        // khi readyState đã "complete" — DOM tĩnh xong không có nghĩa nội
        // dung động đã render. Khoảng đợi này cũng chính là "cửa sổ" để
        // patch AJAX ở trên có cơ hội bắt được request nào đó nếu có.
        handler.postDelayed({
            if (done) return@postDelayed
            evaluateJs(js) { raw ->
                if (done) return@evaluateJs
                done = true
                handler.removeCallbacks(timeoutRunnable)
                val parsed = unwrapEvalBridgeResult(raw)
                when {
                    parsed == null -> onError("Không nhận được phản hồi từ eval_bridge (có thể content script chưa connect kịp)")
                    parsed.isError -> onError(parsed.value)
                    else -> onResult(parsed.value)
                }
            }
        }, 800L)
    }
}

/**
 * Script patch `window.fetch`/`XMLHttpRequest` — TIÊM QUA evaluateJs LÚC
 * CHẠY, không còn nằm trong file JS đóng gói sẵn trong APK nữa (khác bản
 * trước dùng WebExtension riêng `ebook_ajax_sniffer` với content script
 * `document_start`). Đây là lý do TOÀN BỘ EbookLeech giờ nằm gọn trong 1
 * file `.jar` plugin — không còn NGOẠI LỆ nào cần đụng vào APK cả.
 *
 * Idempotent — gọi nhiều lần trên cùng 1 trang không patch chồng lần 2
 * (check `window.__ebookLeechAjaxLog` đã tồn tại thì bỏ qua).
 */
private const val AJAX_PATCH_SCRIPT = """
    (function() {
        if (window.__ebookLeechAjaxLog) return;
        window.__ebookLeechAjaxLog = [];
        var MAX_ENTRIES = 40;
        var hints = ['api', 'ajax', '.json', 'graphql', 'endpoint', 'data', 'list', 'chapter'];
        function looksInteresting(u) {
            var l = String(u).toLowerCase();
            return hints.some(function(h) { return l.indexOf(h) !== -1; });
        }
        function record(u, ct, m) {
            if (window.__ebookLeechAjaxLog.length >= MAX_ENTRIES) return;
            if (!looksInteresting(u)) return;
            window.__ebookLeechAjaxLog.push({ url: String(u), contentType: ct || '', method: m || 'GET' });
        }
        var origFetch = window.fetch;
        if (origFetch) {
            window.fetch = function(input, init) {
                var url = typeof input === 'string' ? input : (input && input.url) || '';
                var method = (init && init.method) || 'GET';
                var result = origFetch.apply(this, arguments);
                try { result.then(function(r) { try { record(url, r.headers ? r.headers.get('content-type') : '', method); } catch(e){} }); } catch(e){}
                return result;
            };
        }
        var OrigOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url) {
            this.__ebookLeechUrl = url; this.__ebookLeechMethod = method;
            return OrigOpen.apply(this, arguments);
        };
        var OrigSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.send = function() {
            var xhr = this;
            xhr.addEventListener('loadend', function() {
                try { record(xhr.__ebookLeechUrl || '', xhr.getResponseHeader ? xhr.getResponseHeader('content-type') : '', xhr.__ebookLeechMethod || 'GET'); } catch(e){}
            });
            return OrigSend.apply(this, arguments);
        };
    })();
"""

/**
 * Poll `document.readyState` qua chính evaluateJs cho tới khi "complete"
 * hoặc hết thời gian. Không dùng onPageLoadedListener (lý do: xem chú
 * thích ở trên).
 */
private fun pollUntilReady(engine: GeckoViewEngine, remainingMs: Long, onDone: (Boolean) -> Unit) {
    if (remainingMs <= 0) { onDone(false); return }
    engine.evaluateJs("document.readyState") { raw ->
        val parsed = unwrapEvalBridgeResult(raw)
        if (parsed != null && !parsed.isError && parsed.value.contains("complete")) {
            onDone(true)
        } else {
            handler.postDelayed({ pollUntilReady(engine, remainingMs - 500L, onDone) }, 500L)
        }
    }
}

private data class EvalResult(val value: String, val isError: Boolean)

/**
 * Bóc tiền tố "OK: "/"LOI: " mà content.js thật của eval_bridge luôn gắn
 * vào (xem assets/eval_bridge/content.js — `result: "OK" + (...) `). Script
 * Kotlin gửi đi luôn là `(function(){...return JSON.stringify(...);})()`
 * nên giá trị sau "OK: " chính là chuỗi JSON cần `JSONObject(...)`.
 */
private fun unwrapEvalBridgeResult(raw: String?): EvalResult? {
    if (raw == null) return null
    return when {
        raw.startsWith("OK: ") -> EvalResult(raw.removePrefix("OK: "), isError = false)
        raw == "OK" -> EvalResult("{}", isError = false)  // script không return gì
        raw.startsWith("LOI: ") -> EvalResult(raw.removePrefix("LOI: "), isError = true)
        else -> {
            Log.w(TAG, "Định dạng kết quả lạ từ eval_bridge (không có tiền tố OK:/LOI:): $raw")
            EvalResult(raw, isError = false)  // vẫn thử dùng nguyên văn, có thể format đổi ở bản content.js sau
        }
    }
}
