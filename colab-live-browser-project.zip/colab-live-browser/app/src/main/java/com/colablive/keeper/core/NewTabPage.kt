package com.colablive.keeper.core

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * TÍNH NĂNG MỚI (người dùng yêu cầu): nút "Tab mới" trước đây luôn mở
 * thẳng `https://www.google.com` (trang tìm kiếm Google, cần mạng, không
 * có gì để bấm ngoài ô tìm kiếm) — thay bằng 1 trang "Tab mới" kiểu Chrome
 * thật: có ô tìm kiếm Google GIỐNG HỆT + lưới "Trang hay truy cập" (Most
 * Visited) tự tính từ lịch sử duyệt web của đúng hồ sơ đang dùng.
 *
 * Trang HTML thật nằm ở `assets/new_tab/index.html` — 1 file tĩnh, mở qua
 * scheme `resource://android/assets/...` của GeckoView (xem chú thích ở
 * `PAGE_PREFIX` bên dưới vì sao KHÔNG PHẢI `file:///android_asset/...` —
 * đó là quy ước riêng của Android WebView, không phải GeckoView; không
 * cần mạng để HIỆN RA, chỉ cần mạng khi người dùng bấm tìm kiếm hoặc bấm
 * vào 1 shortcut). Danh sách shortcut được
 * TÍNH SẴN Ở KOTLIN (nhóm lịch sử theo domain, đếm tần suất, lấy top N —
 * đúng kiểu "Most Visited" của Chrome) rồi truyền vào trang qua query
 * string `?shortcuts=<json>` — cách này ĐƠN GIẢN HƠN hẳn so với việc trang
 * tự gọi ngược lại app qua cầu `eval_bridge`/WebExtension đã dùng cho các
 * việc khác trong app: không cần thêm port, không cần lo tab-routing (đúng
 * lớp bug đã từng gặp nhiều lần ở tính năng kéo-thả — xem PROJECT_STATUS.md
 * mục 77/78), vì toàn bộ dữ liệu đã có sẵn NGAY LÚC tạo tab, không cần hỏi
 * lại trang sau khi đã load.
 */
object NewTabPage {
    private const val MAX_SHORTCUTS = 8
    // Domain của chính app này (Colab/Drive/trang tìm kiếm) không tính là
    // "khám phá được nhờ lịch sử" — luôn nằm trong luồng dùng chính, tự
    // thêm thủ công khi lịch sử còn trống để trang không trơ trọi ở lần
    // đầu dùng (trước khi có lịch sử thật để thay thế dần).
    private val DEFAULT_SHORTCUTS = listOf(
        "Google Colab" to "https://colab.research.google.com/",
        "Google Drive" to "https://drive.google.com/",
        "Google" to "https://www.google.com/",
    )

    /**
     * TIỀN TỐ URL của trang "Tab mới" — dùng chung ở đây và ở
     * `MainActivity.displayHostOnly()` để tránh gõ tay 2 nơi lệch nhau.
     *
     * BUG THẬT đã gặp (build thật, log `Page error... code=85` +
     * `onLoadError`): `file:///android_asset/...` là quy ước RIÊNG của
     * Android WebView cổ điển (`WebViewAssetLoader`) — GeckoView (engine
     * app này đang dùng) KHÔNG có khái niệm "android_asset" trong scheme
     * `file:`, nó tìm 1 thư mục thật tên `android_asset` dưới gốc
     * filesystem (không tồn tại) → lỗi tải → tab rơi về `about:blank` →
     * hiện màn đen trơn, không phải bug hiển thị mà là TRANG CHƯA TỪNG TẢI
     * ĐƯỢC. GeckoView có cơ chế riêng để load file trong thư mục
     * `assets/` của APK: scheme `resource://android/assets/<đường dẫn>`
     * (đã xác nhận qua tài liệu/thảo luận chính thức của dự án GeckoView,
     * không phải suy đoán).
     */
    private const val PAGE_PREFIX = "resource://android/assets/new_tab/index.html"

    // Scheme giả dùng để trang "Tab mới" báo lại cho app khi người dùng
    // thêm/xoá shortcut — trang này KHÔNG có content script/eval_bridge
    // (WebExtension content script không được tiêm vào các trang nội bộ
    // dạng resource của GeckoView, đã xác nhận qua tài liệu GeckoView),
    // nên không có cầu nối 2 chiều nào khác ngoài việc chặn 1 điều hướng
    // giả ở onLoadRequest (nơi app ĐÃ chặn điều hướng cho nhiều việc
    // khác — đúng khuôn mẫu có sẵn, không phải cơ chế mới lạ).
    //
    // BUG BUILD THẬT đã gặp (GitHub Actions báo lỗi cú pháp "thiếu dấu
    // đóng ngoặc nhọn" và "comment chưa đóng"): comment kiểu /**...*/ ở
    // đây trước kia có nhắc tới đường dẫn thư mục "assets" kèm dấu hoa
    // thị đứng ngay sau dấu gạch chéo (ý định chỉ là ký hiệu đại diện
    // "mọi file con") — Kotlin CHO PHÉP comment kiểu này LỒNG NHAU, nên
    // đúng 2 ký tự đó (gạch chéo rồi tới hoa thị, liền nhau, không có gì
    // ở giữa) đứng NGAY TRONG 1 khối comment đang mở sẽ tự mở thêm 1 lớp
    // comment lồng bên trong; dấu đóng gần nhất sau đó chỉ đóng đúng lớp
    // lồng vừa mở, còn khối comment NGOÀI CÙNG vẫn coi như chưa đóng —
    // "nuốt" toàn bộ phần code thật phía sau (kể cả tới hết file) vào
    // trong comment, y hệt lỗi compiler báo. Bài học: dùng comment 1 dòng
    // (2 gạch chéo, không lồng được) thay vì comment khối /**...*/ cho
    // MỌI đoạn có nhắc tới cú pháp/ký hiệu đường dẫn, để không bao giờ
    // vô tình gõ lại đúng 2 ký tự mở comment nằm cạnh nhau trong nội dung.
    private const val SCHEME_PREFIX = "colablive:/"

    /**
     * URL thật để đưa vào `engine.createTab(...)` khi mở "Tab mới".
     *
     * Ghép 2 nguồn shortcut, ghim (`PinnedShortcuts`, người dùng chủ ý
     * thêm qua dấu "+") LUÔN đứng trước và không bao giờ bị thế chỗ, sau
     * đó mới tới "hay truy cập" tự tính từ lịch sử để lấp chỗ còn lại —
     * lọc trùng theo URL (ghim rồi thì không hiện lại bản tự tính của
     * đúng URL đó). Mỗi mục có cờ `pinned` để trang biết có vẽ nút xoá
     * (chỉ ghim mới xoá được, tự tính thì không).
     */
    fun homeUrl(context: Context, slotIndex: Int): String {
        val pinned = try { PinnedShortcuts.list(context, slotIndex) } catch (e: Exception) { emptyList() }
        val pinnedUrls = pinned.map { it.url }.toSet()
        val auto = mostVisited(context, slotIndex).filter { it.second !in pinnedUrls }
        val remaining = (MAX_SHORTCUTS - pinned.size).coerceAtLeast(0)

        val json = JSONArray().apply {
            pinned.forEach { p ->
                put(JSONObject().apply { put("title", p.title); put("url", p.url); put("pinned", true) })
            }
            auto.take(remaining).forEach { (title, url) ->
                put(JSONObject().apply { put("title", title); put("url", url); put("pinned", false) })
            }
        }
        val encoded = Uri.encode(json.toString())
        return "$PAGE_PREFIX?shortcuts=$encoded"
    }

    /** `colablive://add-shortcut?title=...&url=...` — chặn ở `onLoadRequest`. */
    fun tryHandleAddShortcut(context: Context, slotIndex: Int, uri: String): Boolean {
        if (!uri.startsWith("$SCHEME_PREFIX/add-shortcut")) return false
        val parsed = Uri.parse(uri)
        val url = parsed.getQueryParameter("url") ?: return true
        val title = parsed.getQueryParameter("title") ?: ""
        PinnedShortcuts.add(context, slotIndex, title, normalizeUserUrl(url))
        return true
    }

    /** `colablive://remove-shortcut?url=...` — chặn ở `onLoadRequest`. Chỉ dùng cho shortcut ĐÃ GHIM. */
    fun tryHandleRemoveShortcut(context: Context, slotIndex: Int, uri: String): Boolean {
        if (!uri.startsWith("$SCHEME_PREFIX/remove-shortcut")) return false
        val parsed = Uri.parse(uri)
        val url = parsed.getQueryParameter("url") ?: return true
        PinnedShortcuts.remove(context, slotIndex, url)
        return true
    }

    /**
     * `colablive://hide-auto-shortcut?url=...` — người dùng yêu cầu: dấu
     * "x" cũng phải xoá được cho shortcut TỰ TÍNH từ lịch sử (không chỉ
     * shortcut đã ghim). Không xoá được 1 dòng lịch sử cụ thể (shortcut
     * này đại diện CẢ 1 origin, gộp từ nhiều lượt ghé) — ẩn theo ORIGIN,
     * xem chú thích đầy đủ ở `PinnedShortcuts.hideOrigin()`.
     */
    fun tryHandleHideAutoShortcut(context: Context, slotIndex: Int, uri: String): Boolean {
        if (!uri.startsWith("$SCHEME_PREFIX/hide-auto-shortcut")) return false
        val parsed = Uri.parse(uri)
        val url = parsed.getQueryParameter("url") ?: return true
        originOf(url)?.let { PinnedShortcuts.hideOrigin(context, slotIndex, it) }
        return true
    }

    /**
     * `colablive://edit-shortcut?originalUrl=...&pinned=0|1&title=...&url=...`
     * — người dùng yêu cầu: nhấn giữ BẤT KỲ shortcut nào (ghim hay tự
     * tính) đều có mục "Sửa" để đổi tiêu đề + URL.
     *
     * Với shortcut ĐÃ GHIM: chỉ đơn giản thay bằng bản ghi ghim mới (xoá
     * bản cũ theo `originalUrl`, thêm bản mới).
     *
     * Với shortcut TỰ TÍNH (chưa ghim): "sửa" 1 thứ không phải bản ghi cố
     * định (nó tự tính lại mỗi lần) chỉ có 1 cách hợp lý — ẨN origin gốc
     * đi (như "x") RỒI thêm 1 shortcut GHIM MỚI với tiêu đề/URL đã sửa,
     * để từ nay nó luôn hiện đúng như người dùng muốn thay vì bị tính lại
     * tự động mỗi lần và có thể trôi mất khỏi top nếu ngừng ghé.
     */
    fun tryHandleEditShortcut(context: Context, slotIndex: Int, uri: String): Boolean {
        if (!uri.startsWith("$SCHEME_PREFIX/edit-shortcut")) return false
        val parsed = Uri.parse(uri)
        val originalUrl = parsed.getQueryParameter("originalUrl") ?: return true
        val wasPinned = parsed.getQueryParameter("pinned") == "1"
        val newUrl = normalizeUserUrl(parsed.getQueryParameter("url") ?: originalUrl)
        val newTitle = parsed.getQueryParameter("title") ?: ""
        if (!wasPinned) {
            originOf(originalUrl)?.let { PinnedShortcuts.hideOrigin(context, slotIndex, it) }
        }
        PinnedShortcuts.remove(context, slotIndex, originalUrl)
        PinnedShortcuts.add(context, slotIndex, newTitle, newUrl)
        return true
    }

    /** Người dùng có thể gõ thiếu `https://` khi tự thêm shortcut — cùng logic "gõ gì đoán nấy" đã dùng ở thanh địa chỉ/ô tìm kiếm của trang này. */
    private fun normalizeUserUrl(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return trimmed
        return if (Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(trimmed)) trimmed else "https://$trimmed"
    }

    /** Dùng ở `displayHostOnly()` để nhận diện trang này và hiện ô địa chỉ trống. */
    fun isNewTabUrl(url: String): Boolean = url.startsWith(PAGE_PREFIX)

    /**
     * Nhóm lịch sử theo (scheme://host) — không tính riêng từng đường dẫn
     * con (VD `drive.google.com/drive/folders/A` và `.../folders/B` gộp
     * chung 1 shortcut "Google Drive"), đếm số lần xuất hiện, lấy top
     * [MAX_SHORTCUTS] theo tần suất giảm dần. Tiêu đề hiển thị: dùng tiêu
     * đề trang GẦN NHẤT ghi nhận được cho đúng domain đó (thường đúng/dễ
     * đọc hơn tự bịa tên từ hostname), rơi về hostname nếu domain đó chưa
     * từng có tiêu đề nào (trang chưa tải xong tiêu đề lúc ghi lịch sử).
     */
    private fun mostVisited(context: Context, slotIndex: Int): List<Pair<String, String>> {
        val entries = try {
            BrowserHistory.readEntries(context, slotIndex)
        } catch (e: Exception) {
            emptyList()
        }
        // Danh sách origin người dùng đã bấm "x" hoặc "Sửa" trên shortcut
        // tự tính — không bao giờ tự đề xuất lại (xem PinnedShortcuts.hideOrigin()).
        val hidden = try { PinnedShortcuts.hiddenOrigins(context, slotIndex) } catch (e: Exception) { emptySet() }
        if (entries.isEmpty()) return DEFAULT_SHORTCUTS.filter { it.second !in hidden }

        data class Agg(var count: Int = 0, var latestTitle: String = "", var sampleUrl: String = "")
        val byOrigin = LinkedHashMap<String, Agg>()

        entries.forEach { entry ->
            val origin = originOf(entry.url) ?: return@forEach
            if (origin in hidden) return@forEach
            val agg = byOrigin.getOrPut(origin) { Agg() }
            agg.count++
            if (agg.sampleUrl.isEmpty()) agg.sampleUrl = origin
            // `readEntries()` trả về MỚI NHẤT TRƯỚC (đã `.reversed()` sẵn ở
            // BrowserHistory) — entry gặp SỚM NHẤT trong vòng lặp này ứng
            // với tiêu đề GẦN NHẤT của domain đó, chỉ gán 1 lần.
            if (agg.latestTitle.isEmpty() && entry.title.isNotBlank()) agg.latestTitle = entry.title
        }

        val ranked = byOrigin.entries
            .sortedByDescending { it.value.count }
            .take(MAX_SHORTCUTS)
            .map { (origin, agg) ->
                val title = agg.latestTitle.ifBlank { hostnameOf(origin) ?: origin }
                title to origin
            }

        return if (ranked.isEmpty()) DEFAULT_SHORTCUTS.filter { it.second !in hidden } else ranked
    }

    /** "https://colab.research.google.com/drive/abc?x=1" → "https://colab.research.google.com" */
    fun originOf(url: String): String? {
        return try {
            val u = Uri.parse(url)
            val scheme = u.scheme ?: return null
            val host = u.host ?: return null
            if (scheme != "http" && scheme != "https") return null
            "$scheme://$host"
        } catch (e: Exception) {
            null
        }
    }

    private fun hostnameOf(origin: String): String? = try {
        Uri.parse(origin).host
    } catch (e: Exception) {
        null
    }
}
