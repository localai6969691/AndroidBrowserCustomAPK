package com.colablive.keeper.core

import java.net.URLEncoder

/**
 * Bản 7.88 — quyết định thứ người dùng gõ vào ô địa chỉ / ô tìm kiếm là URL hay từ khoá, THEO CÁCH CỦA CHROME/FIREFOX.
 *
 * Lỗi cũ (log 08:55–08:59): gõ "happynable-8b-nsfw-en-v0.2-full" bị coi là URL chỉ vì có dấu "." => tải https://happynable-8b-nsfw-en-v0.2-full => lỗi mạng,
 * trang không đổi, người dùng thấy "gõ vào mà không có gì xảy ra". Cả ô địa chỉ (MainActivity) lẫn ô tìm kiếm trang Tab mới (assets/new_tab/index.html) đều dùng luật "có dấu chấm
 * và không có khoảng trắng". Luật đúng: là URL khi có scheme (xxx://), hoặc là localhost / địa chỉ IPv4 / tên miền mà nhãn CUỐI (TLD) hợp lệ — hai chữ cái (mã quốc gia) hoặc một TLD
 * chung phổ biến. "v0.2-full" có TLD "2-full" (bắt đầu bằng chữ số, có dấu gạch) => không phải tên miền => tìm kiếm.
 *
 * Giới hạn: không có danh sách TLD đầy đủ (PSL) nên TLD chung hiếm không có trong danh sách sẽ bị coi là từ khoá; muốn vào thì gõ kèm "https://".
 * Bản JavaScript trong assets/new_tab/index.html PHẢI giữ cùng luật này.
 */
object UrlInput {
    private val GENERIC_TLDS = setOf(
        "com", "net", "org", "edu", "gov", "mil", "int", "info", "biz", "name", "pro", "mobi", "xyz", "online", "site", "tech", "store", "shop", "app", "dev",
        "io", "ai", "cloud", "club", "live", "news", "blog", "top", "vip", "win", "work", "space", "website", "fun", "link", "page", "art", "icu", "asia", "tel",
        "travel", "jobs", "museum", "coop", "aero", "wiki", "today", "world", "life", "media", "studio", "design", "agency", "email", "digital", "network",
        "systems", "solutions", "company", "group", "center", "services", "tools", "zone", "click", "download", "games", "video", "music", "photo", "host", "one", "plus"
    )
    private val SCHEME = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://")
    private val IPV4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")
    private val LABEL = Regex("^[a-zA-Z0-9\\u00a1-\\uffff]([a-zA-Z0-9\\u00a1-\\uffff-]*[a-zA-Z0-9\\u00a1-\\uffff])?$")

    private fun validTld(tld: String): Boolean {
        val t = tld.lowercase()
        if (t.startsWith("xn--")) return t.length > 4
        return t.length >= 2 && t.all { it.isLetter() } && (t.length == 2 || t in GENERIC_TLDS)
    }

    /** true nếu chuỗi (đã bỏ khoảng trắng hai đầu) nên được mở như một địa chỉ, false nếu nên tìm kiếm. */
    fun looksLikeUrl(raw: String): Boolean {
        val s = raw.trim()
        if (s.isEmpty() || s.any { it.isWhitespace() }) return false
        if (SCHEME.containsMatchIn(s)) return true
        if (s.startsWith("about:") || s.startsWith("view-source:") || s.startsWith("data:") || s.startsWith("file:")) return true
        if (s.startsWith("[")) return true // IPv6 [::1]:8080
        val hostPort = s.substringBefore('/').substringBefore('?').substringBefore('#')
        val host: String
        if (hostPort.contains(':')) {
            val port = hostPort.substringAfterLast(':')
            if (port.isEmpty() || !port.all { it.isDigit() }) return false // "ghi chu:abc" => từ khoá
            host = hostPort.substringBeforeLast(':')
        } else host = hostPort
        if (host.isEmpty()) return false
        if (host.equals("localhost", ignoreCase = true)) return true
        if (IPV4.matches(host)) return host.split('.').all { (it.toIntOrNull() ?: 999) in 0..255 }
        val labels = host.split('.')
        if (labels.size < 2 || labels.any { it.isEmpty() || !LABEL.matches(it) }) return false
        return validTld(labels.last())
    }

    /** URL cần tải cho chuỗi người dùng gõ: giữ nguyên nếu đã có scheme, thêm https:// (http:// cho localhost/IP) nếu là địa chỉ, ngược lại là URL tìm kiếm Google. */
    fun resolve(raw: String): String {
        val s = raw.trim()
        if (s.startsWith("http://") || s.startsWith("https://")) return s
        if (!looksLikeUrl(s)) return "https://www.google.com/search?q=" + URLEncoder.encode(s, "UTF-8")
        if (SCHEME.containsMatchIn(s) || s.startsWith("about:") || s.startsWith("view-source:") || s.startsWith("data:") || s.startsWith("file:")) return s
        val hp = s.substringBefore('/').substringBefore('?').substringBefore('#')
        val hostOnly = if (hp.contains(':')) hp.substringBeforeLast(':') else hp
        val local = hostOnly.equals("localhost", ignoreCase = true) || IPV4.matches(hostOnly)
        return (if (local) "http://" else "https://") + s
    }
}
