package com.colablive.keeper.features.downloads

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import com.colablive.keeper.core.DebugLog
import java.io.File
import java.nio.ByteBuffer
import java.util.UUID

/**
 * Tách audio-only CỤC BỘ bằng MediaExtractor + MediaMuxer của Android (bản 7.56: thay FFmpegKit, gỡ ~31MB khỏi APK).
 *
 * Chỉ dùng khi NewPipeExtractor không có audio stream riêng (xem DownloadManagerFeature.downloadYouTubeAudio()).
 * Cách làm GIỐNG đường chính của FFmpeg cũ (`-vn -acodec copy`): lấy NGUYÊN track audio (AAC) ra khỏi mp4, KHÔNG giải mã/mã hoá lại
 * => không mất chất lượng, nhanh (vài giây), không tốn CPU/pin. Khác biệt: bản cũ còn có dự phòng re-encode AAC 192k khi copy lỗi;
 * bản này KHÔNG re-encode — nếu track không phải AAC thì báo lỗi rõ ràng (video mp4 YouTube dạng muxed luôn có AAC nên hiếm khi gặp).
 *
 * File tạm (video gốc + output trung gian) luôn bị xoá bằng try/finally, như yêu cầu "không để rác phình bộ nhớ".
 */
object AudioExtractor {

    private fun tempDir(context: Context): File {
        val dir = File(context.cacheDir, "audio_extract_tmp")
        dir.mkdirs()
        return dir
    }

    fun cleanupOrphanedTempFiles(context: Context) {
        try {
            val files = tempDir(context).listFiles() ?: return
            var count = 0
            files.forEach { if (it.delete()) count++ }
            if (count > 0) DebugLog.log("AudioExtractor: dọn $count file tạm mồ côi từ lần chạy trước")
        } catch (e: Exception) {
            DebugLog.log("AudioExtractor.cleanupOrphanedTempFiles lỗi: ${e.message}")
        }
    }

    /** Ghi track audio đầu tiên của [src] vào [out] (.m4a). Trả null nếu OK, hoặc chuỗi lỗi. */
    private fun copyAudioTrack(src: File, out: File): String? {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        try {
            extractor.setDataSource(src.absolutePath)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) { track = i; format = f; break }
            }
            if (track < 0 || format == null) return "File không có track audio"
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime != MediaFormat.MIMETYPE_AUDIO_AAC) return "Track audio là '$mime', không phải AAC — bản không-FFmpeg không re-encode được"

            extractor.selectTrack(track)
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val dstTrack = muxer.addTrack(format)
            muxer.start(); muxerStarted = true

            var cap = 1 shl 18
            var buf = ByteBuffer.allocate(cap)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val n = extractor.readSampleData(buf, 0)
                if (n < 0) break
                if (n >= cap - 16) { cap *= 2; buf = ByteBuffer.allocate(cap); continue } // hiếm: mẫu lớn hơn bộ đệm (chưa advance nên đọc lại)
                info.offset = 0
                info.size = n
                info.presentationTimeUs = extractor.sampleTime
                info.flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                muxer.writeSampleData(dstTrack, buf, info)
                extractor.advance()
            }
            return null
        } catch (e: Exception) {
            return e.message ?: e.javaClass.simpleName
        } finally {
            try { if (muxerStarted) muxer?.stop() } catch (e: Exception) { DebugLog.log("AudioExtractor: muxer.stop lỗi: ${e.message}") }
            try { muxer?.release() } catch (e: Exception) {}
            try { extractor.release() } catch (e: Exception) {}
        }
    }

    fun extractAudio(context: Context, sourceVideoFile: File, destFile: File, onResult: (success: Boolean, error: String?) -> Unit) {
        val tempOutput = File(tempDir(context), "${UUID.randomUUID()}.m4a")
        try {
            val err = copyAudioTrack(sourceVideoFile, tempOutput)
            if (err == null && tempOutput.exists() && tempOutput.length() > 0) {
                destFile.parentFile?.mkdirs()
                tempOutput.copyTo(destFile, overwrite = true)
                onResult(true, null)
            } else {
                DebugLog.log("AudioExtractor: tách audio thất bại: $err")
                onResult(false, err ?: "file đầu ra rỗng")
            }
        } catch (e: Exception) {
            DebugLog.log("AudioExtractor.extractAudio lỗi: ${e.message}")
            onResult(false, e.message)
        } finally {
            tempOutput.delete()
            sourceVideoFile.delete()
        }
    }
}
