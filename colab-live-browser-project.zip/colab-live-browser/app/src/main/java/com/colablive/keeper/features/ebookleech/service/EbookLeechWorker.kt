package com.colablive.keeper.features.ebookleech.service

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.colablive.keeper.core.PluginWorkLogic
import com.colablive.keeper.core.PluginWorker
import java.util.concurrent.TimeUnit

/**
 * EbookLeechWorkLogic — LƯỚI AN TOÀN, không phải cơ chế chạy chính.
 *
 * Vòng lặp thật (tick 30s) nằm trong `EbookLeechServiceLogic.tickRunnable`.
 * Worker này chỉ chạy tối đa mỗi 15 phút (sàn cứng của WorkManager) để
 * kiểm tra: nếu còn slot bật EbookLeech mà service KHÔNG chạy (bị OEM
 * diệt), thì khởi động lại.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * ĐÃ SỬA (cùng phát hiện kiến trúc như EbookLeechService.kt — đọc ghi chú
 * đầy đủ ở đó): TRƯỚC ĐÂY `class EbookLeechWorker : Worker(...)` — SẼ
 * KHÔNG BAO GIỜ chạy được, WorkManager không khởi tạo được class trong
 * `.jar` ngoài APK. SỬA: `object EbookLeechWorkLogic` implement
 * `PluginWorkLogic` (interface). `PluginWorker` (`:core`, biên dịch cứng
 * vào APK — WorkManager khởi tạo ĐƯỢC vì nằm sẵn trong dex, KHÔNG cần
 * WorkerFactory tuỳ biến hay sửa AndroidManifest.xml gì thêm cho phần
 * Worker — khác Service, không cần khai `<service>` cho từng Worker) đọc
 * tên class delegate từ `inputData`, tự tìm qua `PluginLoader`, gọi
 * `doWork()`.
 * ═══════════════════════════════════════════════════════════════════════
 */
object EbookLeechWorkLogic : PluginWorkLogic {
    override fun doWork(context: Context): Boolean {
        // Bản 7.98: service chạy THEO KHE (mỗi khe một tiến trình) nên khởi động lại service của TỪNG khe còn bật; ensureStarted tự nuốt lỗi
        // (Android 12+ có thể từ chối start foreground service từ nền) — lưới an toàn không được làm worker thất bại.
        EbookLeechSlotRegistry.enabledSlots(context).forEach { slot -> EbookLeechServiceLogic.ensureStarted(context, slot) }
        return true
    }
}

object EbookLeechWorkScheduler {
    private const val WORK_NAME = "ebook_leech_resurrection_check"

    /** Gọi một lần khi feature được bật ở bất kỳ slot nào. */
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<PluginWorker>(15, TimeUnit.MINUTES)
            .setInputData(PluginWorker.inputDataFor(EbookLeechWorkLogic.javaClass.name))
            .setConstraints(
                Constraints.Builder()
                    .setRequiresBatteryNotLow(false)
                    .build()
            )
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request
        )
    }

    /** Gọi khi feature bị tắt ở TẤT CẢ slot — không cần lưới an toàn nữa. */
    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }
}
