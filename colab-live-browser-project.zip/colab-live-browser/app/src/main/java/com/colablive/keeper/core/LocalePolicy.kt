package com.colablive.keeper.core

import com.colablive.keeper.features.fingerprint.DeviceProfiles
import com.colablive.keeper.features.fingerprint.DeviceProfiles.LocaleProfile

/**
 * Bản 7.107 — "HỒ SƠ NGÔN NGỮ CỐ ĐỊNH" KHÔNG BAO GIỜ LÀ MỘT QUỐC GIA NGẪU NHIÊN.
 *
 * Nguyên tắc dự án (người dùng nhắc lại 11/16): fingerprint (quốc gia / múi giờ / ngôn ngữ) phải ĐỒNG BỘ với IP đang đi ra; IP đổi thì quốc gia đổi theo.
 * Cơ chế chính là "tự khớp IP" (`fp_t_locale_auto`, mặc định BẬT). Hồ sơ ngôn ngữ cố định chỉ là phương án thay thế khi người dùng CHỦ ĐỘNG tắt tự khớp.
 *
 * LỖI GỐC (đọc từ mã, bản ≤7.106): hồ sơ cố định mặc định được chọn bằng BĂM TÊN HỒ SƠ (`defaultLocaleIndexForProfile`) => một hồ sơ tên bất kỳ có thể ra 'Trung Quốc'
 * (zh-CN, Asia/Shanghai) dù IP ở Việt Nam. Tệ hơn, ô chọn Locale Profile trong Cài đặt giả lập fingerprint gọi `onItemSelected` ngay lúc dựng màn hình và GHI giá trị mặc định đó vào
 * `fp_locale_idx` như thể người dùng đã chọn; bản xuất backup còn "đóng băng" giá trị đó vào gói. Nên một giá trị không ai chọn trở thành "lựa chọn" đi theo hồ sơ.
 *
 * Cơ chế sửa (tổng quát, không gắn thiết bị/quốc gia nào):
 *  1. Mặc định của hồ sơ cố định = giá trị THẬT của máy (múi giờ + danh sách ngôn ngữ hệ thống) => khớp IP thật khi không dùng VPN/proxy.
 *  2. Chỉ khi có dấu ý định `fp_locale_idx_by_user` (do chính ô chọn ghi khi người dùng THỰC SỰ đổi lựa chọn) thì `fp_locale_idx` mới được coi là lựa chọn của người dùng.
 *  3. Ô chọn bỏ qua sự kiện dựng ban đầu và có mục cuối "Theo máy thật" để quay về mặc định.
 * Mọi hàm ở đây là hàm thuần (không Android) để kiểm bằng JVM.
 */
object LocalePolicy {
    const val PREF_IDX = "fp_locale_idx"
    const val PREF_IDX_BY_USER = "fp_locale_idx_by_user"
    const val DEVICE_NAME = "Theo máy thật"

    /** Hồ sơ dựng từ giá trị thật của máy. Danh sách ngôn ngữ thêm en-US/en nếu thiếu — cùng luật với `deviceLanguages()` của động cơ (đó là thứ Gecko thật gửi khi không giả). */
    fun deviceProfile(timezoneId: String, tags: List<String>): LocaleProfile {
        val clean = tags.map { it.trim().replace('_', '-') }.filter { it.isNotEmpty() && it != "und" }.distinct().toMutableList()
        if (clean.isEmpty()) clean.add("en-US")
        if (clean.none { it.startsWith("en", ignoreCase = true) }) { clean.add("en-US"); clean.add("en") }
        val primary = clean[0]
        val tz = timezoneId.trim().ifEmpty { "UTC" }
        return LocaleProfile(DEVICE_NAME, tz, primary, clean.distinct(), primary)
    }

    /** Chỉ số hồ sơ do NGƯỜI DÙNG chọn; -1 nếu không có dấu ý định hoặc chỉ số hỏng. */
    fun explicitIndex(storedIdx: Int, byUser: Boolean): Int =
        if (byUser && storedIdx in DeviceProfiles.localeProfiles.indices) storedIdx else -1

    fun isExplicit(storedIdx: Int, byUser: Boolean): Boolean = explicitIndex(storedIdx, byUser) >= 0

    /** Hồ sơ cố định hiệu lực: lựa chọn của người dùng nếu có, không thì hồ sơ máy thật. */
    fun resolve(storedIdx: Int, byUser: Boolean, device: LocaleProfile): LocaleProfile {
        val i = explicitIndex(storedIdx, byUser)
        return if (i >= 0) DeviceProfiles.localeProfiles[i] else device
    }

    fun sourceLabel(storedIdx: Int, byUser: Boolean): String =
        if (isExplicit(storedIdx, byUser)) "người dùng CHỌN TAY trong Cài đặt" else "máy thật (không có lựa chọn của người dùng)"

    // ===== Ô chọn trong Cài đặt =====
    /** Các nhãn của ô chọn: các hồ sơ có sẵn (giữ nguyên thứ tự/chỉ số cũ) + mục cuối "Theo máy thật". */
    fun spinnerLabels(): List<String> = DeviceProfiles.localeProfiles.map { it.name } + "$DEVICE_NAME (mặc định)"

    fun spinnerPosition(storedIdx: Int, byUser: Boolean): Int {
        val i = explicitIndex(storedIdx, byUser)
        return if (i >= 0) i else DeviceProfiles.localeProfiles.size
    }

    /** Spinner bắn `onItemSelected` cả lúc dựng (vị trí ban đầu): chỉ coi là thay đổi thật khi vị trí KHÁC vị trí đang hiện. */
    fun isRealChange(position: Int, shownPosition: Int): Boolean = position != shownPosition

    /** Giá trị cần ghi cho một vị trí được chọn: (chỉ số, có dấu ý định). Mục "Theo máy thật" => (-1, false). */
    class Choice(@JvmField val idx: Int, @JvmField val byUser: Boolean)
    fun choiceFor(position: Int): Choice =
        if (position in DeviceProfiles.localeProfiles.indices) Choice(position, true) else Choice(-1, false)
}
