package com.colablive.keeper.features.ebookleech.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * Một BƯỚC trung gian trong kịch bản cào, đứng TRƯỚC bước cuối (thu thập
 * link chương + cào nội dung, vốn luôn cố định).
 *
 * Trước đây addon cứng 2 tầng: [trang danh sách] → [trang chương]. Với
 * preListStages, người dùng tự định nghĩa kịch bản dài tuỳ ý, ví dụ:
 *
 *   job.listPageUrl = "https://site.com/"                (trang chủ)
 *   stage 1 "Chọn thể loại" : selector ".category-list a"
 *   stage 2 "Chọn sách"     : selector ".book-grid a"
 *   → kết quả mỗi URL "trang sách" thu được ở stage cuối sẽ được coi là
 *     MỘT "trang danh sách chương" riêng, chạy tiếp chapterLinkSelector như
 *     bình thường trên từng URL đó.
 *
 * Để trống preListStages (mặc định) → hành vi y hệt bản cũ, 1 tầng duy nhất.
 */
data class CrawlStage(
    val label: String,               // Tên hiển thị, vd "Chọn thể loại"
    val linkSelector: String,
    val linkAttribute: String = "href",
    val maxLinksPerPage: Int = 0,    // 0 = không giới hạn; >0 chỉ lấy N link đầu (test nhanh, hoặc site có hàng nghìn mục)
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("label", label)
        put("linkSelector", linkSelector)
        put("linkAttribute", linkAttribute)
        put("maxLinksPerPage", maxLinksPerPage)
    }

    companion object {
        fun fromJson(json: JSONObject) = CrawlStage(
            label = json.optString("label", "Bước"),
            linkSelector = json.getString("linkSelector"),
            linkAttribute = json.optString("linkAttribute", "href"),
            maxLinksPerPage = json.optInt("maxLinksPerPage", 0),
        )

        fun listFromJson(arr: JSONArray): List<CrawlStage> =
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }

        fun listToJson(stages: List<CrawlStage>): JSONArray =
            JSONArray().also { arr -> stages.forEach { arr.put(it.toJson()) } }
    }
}
