package com.colablive.keeper.features.ebookleech.model

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * CrawlCheckpointRepository — lưu checkpoint xuống FILE (không phải
 * SharedPreferences) trong bộ nhớ nội bộ app (`filesDir`, không cần quyền,
 * người dùng không thấy trong Downloads) — vì nội dung chương (HTML) có
 * thể khá lớn, không hợp để nhồi vào SharedPreferences.
 *
 * Đường dẫn JSON checkpoint: <filesDir>/ebookleech_checkpoints/<slotIndex>_<jobId>.json
 * Đường dẫn bytes ảnh (MỚI):  <filesDir>/ebookleech_checkpoints/<slotIndex>_<jobId>_images/<localFileName>
 *
 * ĐÃ SỬA (nợ kỹ thuật cũ — checkpoint không lưu bytes ảnh, resume sau
 * crash mất ảnh của các chương cào trước đó): giờ MỖI LẦN `save()`, bytes
 * ảnh của các chương trong `chaptersSoFar` được ghi ra file riêng (idempotent
 * — bỏ qua ảnh đã có file từ lần save trước, nên KHÔNG ghi lại toàn bộ ảnh
 * mỗi lần checkpoint, chỉ tốn công cho ảnh MỚI của chương vừa cào xong).
 * JSON checkpoint vẫn KHÔNG chứa bytes (đúng lo ngại ban đầu — base64 hoá
 * ảnh vào JSON sẽ làm file phình rất nhanh) — chỉ chứa metadata trỏ tới
 * đúng file ảnh tương ứng (xem `LeechChapter.toJson()`/`fromJson()`).
 */
object CrawlCheckpointRepository {

    private fun dir(context: Context): File =
        File(context.filesDir, "ebookleech_checkpoints").apply { if (!exists()) mkdirs() }

    private fun file(context: Context, slotIndex: Int, jobId: String): File =
        File(dir(context), "${slotIndex}_${jobId}.json")

    private fun imagesDir(context: Context, slotIndex: Int, jobId: String): File =
        File(dir(context), "${slotIndex}_${jobId}_images").apply { if (!exists()) mkdirs() }

    /** ĐÃ THÊM — public, dùng bởi `RemoteCrawlRunner` để ghi bytes ảnh tải
     * được TỪ GITHUB vào ĐÚNG vị trí mà checkpoint cục bộ đang dùng (cùng
     * thư mục `persistImageBytes()` ghi khi cào TẠI MÁY) — nhờ vậy
     * `EbookExporter.export()` sau này đọc ảnh y hệt nhau bất kể job cào
     * tại máy hay từ xa, không cần phân biệt 2 luồng. Idempotent — bỏ qua
     * nếu file đã có (khớp `persistImageBytes()`). */
    fun saveImageBytesIfMissing(context: Context, slotIndex: Int, jobId: String, localFileName: String, bytes: ByteArray) {
        val f = File(imagesDir(context, slotIndex, jobId), localFileName)
        if (!f.exists()) {
            try { f.writeBytes(bytes) } catch (e: Exception) { /* 1 ảnh lỗi không chặn đồng bộ phần còn lại */ }
        }
    }

    /** ĐÃ THÊM — public, dùng làm `imageLoader` khi gọi `CrawlCheckpoint.fromJson()`
     * từ `RemoteCrawlRunner` (cùng cơ chế `load()` bên dưới dùng nội bộ). */
    fun loadImageBytes(context: Context, slotIndex: Int, jobId: String, localFileName: String): ByteArray? {
        val f = File(imagesDir(context, slotIndex, jobId), localFileName)
        return if (f.exists()) try { f.readBytes() } catch (e: Exception) { null } else null
    }

    /** ĐÃ THÊM — dùng bởi `RemoteCrawlRunner` khi chuyển 1 job từ cào TẠI
     * MÁY sang cào TỪ XA: cần đẩy NGƯỢC ảnh đã tải cục bộ lên GitHub
     * trước khi dispatch, để Python thấy đã có sẵn (không tải lại). */
    fun listLocalImageFiles(context: Context, slotIndex: Int, jobId: String): List<File> =
        imagesDir(context, slotIndex, jobId).listFiles()?.filter { it.isFile } ?: emptyList()

    fun save(context: Context, slotIndex: Int, checkpoint: CrawlCheckpoint) {
        try {
            persistImageBytes(context, slotIndex, checkpoint)
            file(context, slotIndex, checkpoint.jobId).writeText(checkpoint.toJson().toString(), Charsets.UTF_8)
        } catch (e: Exception) {
            // Lỗi ghi checkpoint không được làm crash job đang chạy — bỏ
            // qua, lần sau có cơ hội ghi lại (không phải checkpoint nào
            // cũng bắt buộc phải thành công).
        }
    }

    /**
     * Ghi bytes ảnh của MỌI chương hiện có trong checkpoint xuống file
     * riêng — CHỈ ghi ảnh CHƯA CÓ file (kiểm tra `exists()` trước) để mỗi
     * lần `save()` (sau MỖI CHƯƠNG ở Phase 2) không phải ghi lại hàng trăm
     * ảnh của các chương đã xong từ trước, chỉ tốn công cho vài ảnh MỚI
     * của đúng chương vừa cào xong.
     *
     * 1 ảnh lỗi khi ghi (đĩa đầy, quyền...) KHÔNG được chặn việc ghi
     * checkpoint JSON — bỏ qua, coi như ảnh đó tạm thời mất khi resume,
     * còn hơn mất TOÀN BỘ checkpoint vì 1 ảnh lỗi.
     */
    private fun persistImageBytes(context: Context, slotIndex: Int, checkpoint: CrawlCheckpoint) {
        if (checkpoint.chaptersSoFar.none { it.images.isNotEmpty() }) return  // job không bật downloadImages — bỏ qua nhanh, không tạo thư mục thừa
        val dir = imagesDir(context, slotIndex, checkpoint.jobId)
        checkpoint.chaptersSoFar.forEach { chapter ->
            chapter.images.forEach { img ->
                val f = File(dir, img.localFileName)
                if (!f.exists()) {
                    try {
                        f.writeBytes(img.bytes)
                    } catch (e: Exception) {
                        // Bỏ qua đúng ảnh này — xem docstring hàm
                    }
                }
            }
        }
    }

    fun load(context: Context, slotIndex: Int, jobId: String): CrawlCheckpoint? {
        val f = file(context, slotIndex, jobId)
        if (!f.exists()) return null
        return try {
            val imgDir = imagesDir(context, slotIndex, jobId)
            CrawlCheckpoint.fromJson(JSONObject(f.readText(Charsets.UTF_8))) { localFileName ->
                val imgFile = File(imgDir, localFileName)
                if (imgFile.exists()) {
                    try { imgFile.readBytes() } catch (e: Exception) { null }
                } else {
                    null  // File ảnh mất/chưa từng ghi được — LeechChapter.fromJson() tự bỏ qua đúng ảnh này
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    fun exists(context: Context, slotIndex: Int, jobId: String): Boolean =
        file(context, slotIndex, jobId).exists()

    fun delete(context: Context, slotIndex: Int, jobId: String) {
        val f = file(context, slotIndex, jobId)
        if (f.exists()) f.delete()
        // ĐÃ THÊM: dọn luôn thư mục ảnh checkpoint khi job xong/huỷ — nếu
        // không, thư mục ảnh của MỌI job đã từng chạy dồn lại vô hạn trong
        // bộ nhớ riêng của app, không ai dọn (khác thư mục Downloads mà
        // người dùng tự thấy và tự xoá được).
        imagesDir(context, slotIndex, jobId).deleteRecursively()
    }

    /** Liệt kê toàn bộ jobId có checkpoint trong 1 slot — dùng cho backup + resume-on-boot. */
    fun listJobIdsWithCheckpoint(context: Context, slotIndex: Int): List<String> {
        val prefix = "${slotIndex}_"
        return dir(context).listFiles { f -> f.name.startsWith(prefix) && f.name.endsWith(".json") }
            ?.map { it.name.removePrefix(prefix).removeSuffix(".json") }
            ?: emptyList()
    }
}
