package com.colablive.keeper.features.ebookleech.model

import android.content.Context
import com.colablive.keeper.core.AppPrefs
import org.json.JSONArray

/**
 * SitePresetRepository — lưu qua `AppPrefs` (giống mọi kho dữ liệu khác
 * của EbookLeech), namespace theo HỒ SƠ đang gán cho khe (tự động, xem
 * `AppPrefs.kt`) — preset đi theo hồ sơ, không dính cứng vào số khe.
 *
 * Danh sách preset dùng CHUNG cho MỌI job trong slot (khác `LeechJobRepository`
 * lưu riêng từng job) — hợp lý vì preset đại diện cho 1 KIỂU SITE, không
 * phải 1 job cụ thể.
 */
object SitePresetRepository {
    private const val FEATURE_ID = "ebook_leech"
    private const val KEY = "site_presets_json"

    fun loadAll(context: Context, slotIndex: Int): List<SitePreset> {
        val raw = AppPrefs.getString(context, slotIndex, FEATURE_ID, KEY, "")
        if (raw.isBlank()) return emptyList()
        return try {
            SitePreset.listFromJson(JSONArray(raw))
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveAll(context: Context, slotIndex: Int, list: List<SitePreset>) {
        AppPrefs.setString(context, slotIndex, FEATURE_ID, KEY, SitePreset.listToJson(list).toString())
    }

    fun add(context: Context, slotIndex: Int, preset: SitePreset) {
        saveAll(context, slotIndex, loadAll(context, slotIndex) + preset)
    }

    fun delete(context: Context, slotIndex: Int, presetId: String) {
        saveAll(context, slotIndex, loadAll(context, slotIndex).filterNot { it.id == presetId })
    }
}
