package com.colablive.keeper.core

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

/**
 * Service THẬT, biên dịch cứng vào `:core` (nên nằm sẵn trong APK) — khai
 * trong `AndroidManifest.xml`. Đây là "vỏ" cố định mà MỌI plugin cần chạy
 * foreground service đều dùng chung — không cần khai thêm `<service>` mới
 * trong Manifest mỗi khi có plugin mới, chỉ cần start đúng Intent với extra
 * `EXTRA_DELEGATE_CLASS` trỏ đúng tên class logic của plugin đó.
 *
 * Xem giải thích đầy đủ lý do cần lớp này trong `PluginServiceLogic.kt`.
 */
open class PluginForegroundServiceProxy : Service() {

    companion object {
        private const val TAG = "PluginServiceProxy"
        const val EXTRA_DELEGATE_CLASS = "delegate_class"

        /** Helper cho code plugin dùng: build đúng Intent để khởi động
         * service này với đúng delegate. VD trong EbookLeechServiceLogic:
         * `PluginForegroundServiceProxy.intentFor(context, EbookLeechServiceLogic::class.java.name)`. */
        fun intentFor(context: android.content.Context, delegateClassName: String, slotIndex: Int = 0): Intent =
            Intent(context, serviceClassFor(slotIndex))
                .putExtra(EXTRA_DELEGATE_CLASS, delegateClassName)

        /**
         * Bản 7.98 — mỗi khe (1..3) chạy ở TIẾN TRÌNH RIÊNG (`:slot1`..`:slot3`, xem 4 activity trong
         * AndroidManifest). `GeckoViewEngine.forSlot(n)` chỉ có trong tiến trình của khe n, nên plugin
         * cần engine của khe (như EbookLeech cào bằng tab GeckoView thật) phải chạy service ở ĐÚNG
         * tiến trình đó — cùng mẫu với `KeepAliveService.serviceClassFor()`. Khe 0 = tiến trình chính.
         */
        fun serviceClassFor(slotIndex: Int): Class<out PluginForegroundServiceProxy> = when (slotIndex) {
            1 -> PluginForegroundServiceProxySlot1::class.java
            2 -> PluginForegroundServiceProxySlot2::class.java
            3 -> PluginForegroundServiceProxySlot3::class.java
            else -> PluginForegroundServiceProxy::class.java
        }
    }

    private var delegate: PluginServiceLogic? = null
    private var delegateClassName: String? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Chỉ resolve delegate 1 LẦN — các Intent sau (vd action ACTION_STOP
        // gửi qua PendingIntent từ notification) KHÔNG kèm lại extra này,
        // nhưng vẫn cần chuyển tiếp đúng tới delegate đã resolve từ trước.
        if (delegate == null) {
            val className = intent?.getStringExtra(EXTRA_DELEGATE_CLASS)
            if (className == null) {
                Log.e(TAG, "onStartCommand không có $EXTRA_DELEGATE_CLASS và chưa có delegate — dừng ngay, không biết chuyển tiếp đi đâu")
                stopSelf()
                return START_NOT_STICKY
            }
            delegateClassName = className
            val resolved = PluginLoader.findPluginInstance(className) as? PluginServiceLogic
            if (resolved == null) {
                Log.e(TAG, "Không tìm thấy plugin class $className (implement PluginServiceLogic) — plugin chưa nạp, hoặc đã gỡ jar")
                stopSelf()
                return START_NOT_STICKY
            }
            delegate = resolved
            resolved.onCreate(this)
        }
        return delegate?.onStartCommand(this, intent, flags, startId) ?: START_NOT_STICKY
    }

    override fun onDestroy() {
        delegate?.onDestroy(this)
        delegate = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

// Bản sao RỖNG theo khe — chỉ để mỗi khai báo <service> trong Manifest có `android:process` riêng.
class PluginForegroundServiceProxySlot1 : PluginForegroundServiceProxy()
class PluginForegroundServiceProxySlot2 : PluginForegroundServiceProxy()
class PluginForegroundServiceProxySlot3 : PluginForegroundServiceProxy()
