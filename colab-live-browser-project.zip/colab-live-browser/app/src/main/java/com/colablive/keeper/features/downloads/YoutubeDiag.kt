package com.colablive.keeper.features.downloads

import com.colablive.keeper.core.DebugLog

/**
 * Bản 7.82 — chẩn đoán lỗi tải YouTube để LOG TỰ CHO KẾT LUẬN.
 *
 * Trước đây catch chỉ ghi `e.message` ("YouTube error: ..."): không biết lỗi loại gì, nguyên nhân gốc là gì, hỏng ở bước nào.
 * Giờ mỗi lỗi ghi: bước nào, URL đã chuẩn hoá, CHUỖI nguyên nhân (lớp + thông điệp, tối đa 5 tầng) và một NHÓM nguyên nhân suy từ tên lớp/thông điệp.
 * Phân loại bằng TÊN LỚP dạng chuỗi (không import lớp ngoại lệ cụ thể của NewPipeExtractor) để không phụ thuộc phiên bản thư viện.
 */
object YoutubeDiag {

    fun chain(e: Throwable): String {
        val parts = ArrayList<String>()
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 5) {
            parts.add("${t.javaClass.simpleName}: ${(t.message ?: "").take(160)}")
            val c = t.cause
            t = if (c === t) null else c
            n++
        }
        return parts.joinToString("  <=  ")
    }

    /** Nhóm nguyên nhân dễ đọc, suy từ tên lớp + thông điệp của TOÀN BỘ chuỗi nguyên nhân. */
    fun classify(e: Throwable): String {
        val all = StringBuilder()
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 5) {
            all.append(t.javaClass.name).append(' ').append(t.message ?: "").append(' ')
            val c = t.cause
            t = if (c === t) null else c
            n++
        }
        val s = all.toString()
        return when {
            s.contains("SignInConfirmNotBot", true) || (s.contains("confirm you", true) && s.contains("bot", true)) ->
                "YOUTUBE CHẶN 'xác nhận không phải bot' — theo IP/mạng đang dùng (đường tải đi THẲNG từ máy, không qua VPN/proxy)"
            s.contains("ReCaptcha", true) || s.contains(" 429", true) ->
                "YOUTUBE đòi reCAPTCHA / giới hạn tốc độ (429) theo IP/mạng"
            s.contains("AgeRestricted", true) -> "video giới hạn độ tuổi (cần đăng nhập)"
            s.contains("Geographic", true) -> "video bị chặn theo quốc gia (IP của máy, không phải IP VPN)"
            s.contains("PrivateContent", true) -> "video riêng tư"
            s.contains("PaidContent", true) || s.contains("Premium", true) -> "nội dung trả phí/Premium"
            s.contains("ContentNotAvailable", true) -> "video không khả dụng (xoá/ẩn/chặn)"
            s.contains("UnknownHost", true) || s.contains("SocketTimeout", true) || s.contains("ConnectException", true) ||
                s.contains("SSL", true) || s.contains("Unable to resolve", true) -> "LỖI MẠNG của máy (DNS/timeout/SSL) — chưa tới được YouTube"
            s.contains("not accepted", true) || s.contains("UnsupportedURL", true) -> "URL không được extractor chấp nhận (chuẩn hoá URL sai)"
            s.contains("ParsingException", true) || s.contains("ExtractionException", true) || s.contains("JsonParser", true) ||
                s.contains("Could not get", true) -> "KHÔNG PHÂN TÍCH được phản hồi YouTube — nhiều khả năng YouTube đổi cấu trúc, cần nâng NewPipeExtractor"
            else -> "chưa phân loại được — xem chuỗi nguyên nhân"
        }
    }

    fun start(stage: String, rawUrl: String, normalizedUrl: String) {
        DebugLog.log("YouTube[$stage] BẮT ĐẦU: url=${rawUrl.take(90)} -> chuẩn hoá=${normalizedUrl.take(90)}")
    }

    fun ok(stage: String, ms: Long, videoStreams: Int, audioStreams: Int, name: String?) {
        DebugLog.log("YouTube[$stage] OK sau ${ms}ms: video=$videoStreams audio=$audioStreams tiêu đề='${(name ?: "").take(50)}'")
    }

    fun fail(stage: String, rawUrl: String, ms: Long, e: Throwable) {
        DebugLog.log("YouTube[$stage] THẤT BẠI sau ${ms}ms — NHÓM: ${classify(e)} | url=${rawUrl.take(90)} | chuỗi: ${chain(e)}")
    }
}
