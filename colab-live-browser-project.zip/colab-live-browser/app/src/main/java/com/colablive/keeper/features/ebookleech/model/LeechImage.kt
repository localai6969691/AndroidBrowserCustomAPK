package com.colablive.keeper.features.ebookleech.model

/**
 * Một ảnh đã tải về cho một chương — dùng để nhúng offline vào EPUB/HTML.
 */
data class LeechImage(
    val originalUrl: String,
    val localFileName: String,  // vd: "img_3_1.jpg" — duy nhất trong toàn bộ ebook
    val mimeType: String,       // vd: "image/jpeg"
    val bytes: ByteArray,
) {
    override fun equals(other: Any?): Boolean =
        other is LeechImage && other.localFileName == localFileName
    override fun hashCode(): Int = localFileName.hashCode()
}
