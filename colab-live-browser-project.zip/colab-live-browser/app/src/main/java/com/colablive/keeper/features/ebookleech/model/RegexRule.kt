package com.colablive.keeper.features.ebookleech.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * Một luật xử lý nội dung sau khi cào — tương đương "Callback" trong KDN Auto Leech.
 * Áp dụng theo thứ tự trong list, luật sau chạy trên kết quả của luật trước.
 */
data class RegexRule(
    val target: Target,          // Áp dụng lên đâu
    val kind: Kind,               // Loại xử lý
    val pattern: String = "",     // Chuỗi cần tìm (PLAIN_REPLACE) hoặc regex (REGEX_REPLACE)
    val replacement: String = "", // Chuỗi thay thế — PLAIN_REPLACE thay nguyên văn, REGEX_REPLACE hỗ trợ $1 $2...
    val caseInsensitive: Boolean = false,  // Không phân biệt hoa/thường khi tìm (áp dụng cho cả 2 kiểu thay thế)
    val enabled: Boolean = true,
) {
    enum class Target { TITLE, CONTENT_HTML, CONTENT_TEXT }

    enum class Kind {
        PLAIN_REPLACE,       // Tìm & thay thế văn bản thường — KHÔNG cần biết regex, tìm nguyên văn
        REGEX_REPLACE,       // Tìm pattern (regex), thay bằng replacement — cho người rành regex
        TRIM,                // Xoá khoảng trắng đầu/cuối mỗi dòng
        REMOVE_EMPTY_LINES,  // Xoá dòng trống thừa (>2 dòng trống liên tiếp → 1)
        TO_UPPERCASE,
        TO_LOWERCASE,
        CAPITALIZE_FIRST,    // Viết hoa chữ cái đầu câu
        STRIP_HTML_TAGS,     // Bỏ hết thẻ HTML (chỉ hợp lý khi target = CONTENT_HTML)
        // ĐÃ THÊM — "spinner nội dung chống trùng lặp": `replacement` là 1
        // TEMPLATE spin cú pháp "{lựa chọn 1|lựa chọn 2|...}" (xem
        // ContentSpinner.kt) — MỖI CHƯƠNG tự chọn ngẫu nhiên 1 phương án
        // KHÁC NHAU, chèn vào đầu/cuối nội dung. Dùng để mỗi bài đăng
        // WordPress có câu mở/kết khác nhau, giảm rủi ro bị chấm điểm
        // "nội dung trùng lặp" khi đăng hàng loạt chương tự động.
        SPIN_INSERT_PREFIX,  // Chèn `replacement` (đã quay spin) vào ĐẦU nội dung
        SPIN_INSERT_SUFFIX,  // Chèn `replacement` (đã quay spin) vào CUỐI nội dung
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("target", target.name)
        put("kind", kind.name)
        put("pattern", pattern)
        put("replacement", replacement)
        put("caseInsensitive", caseInsensitive)
        put("enabled", enabled)
    }

    companion object {
        fun fromJson(json: JSONObject) = RegexRule(
            target = Target.valueOf(json.getString("target")),
            kind = Kind.valueOf(json.getString("kind")),
            pattern = json.optString("pattern", ""),
            replacement = json.optString("replacement", ""),
            caseInsensitive = json.optBoolean("caseInsensitive", false),
            enabled = json.optBoolean("enabled", true),
        )

        fun listFromJson(arr: JSONArray): List<RegexRule> =
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }

        fun listToJson(rules: List<RegexRule>): JSONArray =
            JSONArray().also { arr -> rules.forEach { arr.put(it.toJson()) } }
    }
}
