package com.colablive.keeper.features.ebookleech.engine

import com.colablive.keeper.features.ebookleech.model.RegexRule

/**
 * ContentProcessor — áp dụng chuỗi RegexRule lên tiêu đề/nội dung cào được,
 * tương đương hệ thống "Callback" của KDN Auto Leech.
 *
 * Luật chạy tuần tự theo thứ tự trong list; luật lỗi (regex sai cú pháp) sẽ
 * bị bỏ qua thay vì làm crash cả job — ghi log để người dùng biết luật nào sai.
 */
object ContentProcessor {

    /** Kết quả sau khi áp toàn bộ rule — kèm danh sách lỗi (nếu có) để hiển thị cho user. */
    data class Result(val title: String, val html: String, val text: String, val errors: List<String>)

    fun apply(
        rawTitle: String,
        rawHtml: String,
        rawText: String,
        rules: List<RegexRule>,
    ): Result {
        var title = rawTitle
        var html = rawHtml
        var text = rawText
        val errors = mutableListOf<String>()

        rules.filter { it.enabled }.forEach { rule ->
            try {
                when (rule.target) {
                    RegexRule.Target.TITLE -> title = applyOne(title, rule, isHtml = false)
                    RegexRule.Target.CONTENT_HTML -> html = applyOne(html, rule, isHtml = true)
                    RegexRule.Target.CONTENT_TEXT -> text = applyOne(text, rule, isHtml = false)
                }
            } catch (e: Exception) {
                errors.add("Luật '${rule.kind}' trên '${rule.target}' lỗi: ${e.message}")
            }
        }

        return Result(title, html, text, errors)
    }

    // -------------------------------------------------------------------------

    private fun applyOne(input: String, rule: RegexRule, isHtml: Boolean): String = when (rule.kind) {
        RegexRule.Kind.PLAIN_REPLACE -> {
            // Tìm & thay thế văn bản THƯỜNG — không cần biết regex, tìm
            // đúng nguyên văn `pattern` (không hiểu ký tự đặc biệt regex
            // như . * [ ] ( ) — an toàn cho người không rành kỹ thuật).
            if (rule.pattern.isEmpty()) input
            else input.replace(rule.pattern, rule.replacement, ignoreCase = rule.caseInsensitive)
        }
        RegexRule.Kind.REGEX_REPLACE -> {
            if (rule.pattern.isBlank()) input
            else {
                val options = if (rule.caseInsensitive) setOf(RegexOption.IGNORE_CASE) else emptySet()
                Regex(rule.pattern, options).replace(input, rule.replacement)
            }
        }
        RegexRule.Kind.TRIM ->
            input.lines().joinToString("\n") { it.trim() }.trim()
        RegexRule.Kind.REMOVE_EMPTY_LINES ->
            input.replace(Regex("\n{3,}"), "\n\n")
        RegexRule.Kind.TO_UPPERCASE -> input.uppercase()
        RegexRule.Kind.TO_LOWERCASE -> input.lowercase()
        RegexRule.Kind.CAPITALIZE_FIRST ->
            input.split(". ").joinToString(". ") { s ->
                s.replaceFirstChar { c -> c.uppercaseChar() }
            }
        RegexRule.Kind.STRIP_HTML_TAGS ->
            if (isHtml) input.replace(Regex("<[^>]*>"), "") else input
        RegexRule.Kind.SPIN_INSERT_PREFIX ->
            ContentSpinner.spin(rule.replacement) + input
        RegexRule.Kind.SPIN_INSERT_SUFFIX ->
            input + ContentSpinner.spin(rule.replacement)
    }
}
