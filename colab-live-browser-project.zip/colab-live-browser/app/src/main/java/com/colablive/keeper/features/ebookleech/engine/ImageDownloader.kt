package com.colablive.keeper.features.ebookleech.engine

import com.colablive.keeper.features.ebookleech.model.LeechImage
import java.net.HttpURLConnection
import java.net.URL

/**
 * ImageDownloader — tải ảnh trong <img src="..."> của nội dung chương về, đổi
 * src thành đường dẫn local ("images/xxx.jpg"), để ebook xem được offline
 * (mất mạng không mất ảnh, khác với việc chỉ giữ nguyên URL gốc).
 *
 * Chạy trên background thread (không phải main thread) — gọi từ
 * EbookLeechCrawler.phase2CrawlChapter sau khi đã có HTML chương.
 */
object ImageDownloader {

    private const val MAX_IMAGE_BYTES = 6 * 1024 * 1024   // 6MB / ảnh
    private const val CONNECT_TIMEOUT_MS = 8_000
    private const val READ_TIMEOUT_MS = 12_000

    private val imgSrcRegex = Regex("""<img[^>]+src\s*=\s*["']([^"']+)["'][^>]*>""", RegexOption.IGNORE_CASE)

    /**
     * @param html          Nội dung HTML gốc của chương (đã có src tuyệt đối)
     * @param chapterIndex  Số thứ tự chương, dùng để đặt tên file duy nhất
     * @param userAgent     UA tuỳ chỉnh của job (nếu có) để tránh bị chặn hotlink
     * @param maxImages     Giới hạn số ảnh tải/chương (chống job "nổ" dung lượng)
     * @return HTML đã thay src → local, kèm danh sách ảnh đã tải thành công
     */
    fun processChapterImages(
        html: String,
        chapterIndex: Int,
        userAgent: String,
        maxImages: Int = 30,
    ): Pair<String, List<LeechImage>> {
        val downloaded = mutableListOf<LeechImage>()
        val urlToLocal = mutableMapOf<String, String>()
        var counter = 0

        val matches = imgSrcRegex.findAll(html).map { it.groupValues[1] }.distinct().toList()

        for (srcUrl in matches) {
            if (counter >= maxImages) break
            if (srcUrl.startsWith("data:")) continue  // đã là base64 inline, bỏ qua

            val bytesAndType = downloadImage(srcUrl, userAgent) ?: continue
            counter++
            val ext = guessExtension(bytesAndType.second, srcUrl)
            val localName = "img_${chapterIndex}_${counter}.$ext"
            downloaded.add(LeechImage(srcUrl, localName, bytesAndType.second, bytesAndType.first))
            urlToLocal[srcUrl] = localName
        }

        var newHtml = html
        urlToLocal.forEach { (original, local) ->
            newHtml = newHtml.replace(original, "images/$local")
        }

        return newHtml to downloaded
    }

    // -------------------------------------------------------------------------

    /** @return (bytes, mimeType) hoặc null nếu tải lỗi/quá lớn */
    private fun downloadImage(urlStr: String, userAgent: String): Pair<ByteArray, String>? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlStr)
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                if (userAgent.isNotBlank()) setRequestProperty("User-Agent", userAgent)
                else setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"
                )
                setRequestProperty("Referer", urlStr)
                instanceFollowRedirects = true
            }
            if (conn.responseCode !in 200..299) return null

            val contentLength = conn.contentLength
            if (contentLength > MAX_IMAGE_BYTES) return null

            val mimeType = conn.contentType?.substringBefore(";")?.trim().orEmpty()
                .ifBlank { "image/jpeg" }

            val bytes = conn.inputStream.use { it.readBytes() }
            if (bytes.size > MAX_IMAGE_BYTES) return null
            if (!mimeType.startsWith("image/")) return null

            bytes to mimeType
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun guessExtension(mimeType: String, url: String): String {
        val fromMime = when {
            mimeType.contains("jpeg") || mimeType.contains("jpg") -> "jpg"
            mimeType.contains("png") -> "png"
            mimeType.contains("webp") -> "webp"
            mimeType.contains("gif") -> "gif"
            else -> null
        }
        if (fromMime != null) return fromMime
        val fromUrl = url.substringAfterLast('.', "").substringBefore('?').lowercase()
        return if (fromUrl in listOf("jpg", "jpeg", "png", "webp", "gif")) fromUrl else "jpg"
    }
}
