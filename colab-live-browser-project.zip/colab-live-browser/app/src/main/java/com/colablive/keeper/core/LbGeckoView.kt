package com.colablive.keeper.core

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputConnectionWrapper
import org.mozilla.geckoview.GeckoView

/**
 * GeckoView có chặn "dán văn bản LỚN qua bàn phím ảo" (mục 99).
 *
 * Bàn phím ảo (Gboard...) chèn mục clipboard bằng InputConnection.commitText()
 * — với Gecko đó là chuỗi thao tác IME (đồng bộ toàn bộ Editable Java <-> Gecko,
 * rồi Monaco của Colab xử lý như gõ phím). Văn bản lớn đi đường này làm đơ
 * cả trang. Trình duyệt thật xử lý "dán" bằng lệnh paste native (1 sự kiện),
 * không qua IME. Ở đây: commitText quá lớn -> chuyển thành dán native
 * (NativePaste); nếu không xác nhận được dán native thì mới commit như cũ.
 */
class LbGeckoView(context: Context) : GeckoView(context) {

    /** (text, onNativePasteResult) -> thực hiện dán native. Gán từ MainActivity. */
    var largeCommitHandler: ((String, (Boolean) -> Unit) -> Unit)? = null

    /** Trả true nếu đã tự xử lý lệnh Xoá (đang có vùng chọn Monaco). Gán từ MainActivity. */
    var deleteHandler: (() -> Boolean)? = null
    private var swallowDelUp = false

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val base = super.onCreateInputConnection(outAttrs) ?: return null
        return object : InputConnectionWrapper(base, true) {
            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                if (beforeLength <= 1 && afterLength == 0 && deleteHandler?.invoke() == true) return true
                return super.deleteSurroundingText(beforeLength, afterLength)
            }

            override fun sendKeyEvent(event: android.view.KeyEvent): Boolean {
                if (event.keyCode == android.view.KeyEvent.KEYCODE_DEL) {
                    if (event.action == android.view.KeyEvent.ACTION_DOWN && deleteHandler?.invoke() == true) {
                        swallowDelUp = true
                        return true
                    }
                    if (event.action == android.view.KeyEvent.ACTION_UP && swallowDelUp) {
                        swallowDelUp = false
                        return true
                    }
                }
                return super.sendKeyEvent(event)
            }

            override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
                if (text != null && text.length >= 1000) DebugLog.log("LbGeckoView: setComposingText ${text.length} ký tự (bàn phím gửi qua đường soạn thảo)")
                return super.setComposingText(text, newCursorPosition)
            }

            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                if (text != null && text.length >= 1000) {
                    val clipLen = try {
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                            .primaryClip?.getItemAt(0)?.coerceToText(context)?.length ?: -1
                    } catch (e: Exception) { -2 }
                    DebugLog.log("LbGeckoView: commitText ${text.length} ký tự; clipboard hệ thống lúc này = $clipLen ký tự")
                }
                val h = largeCommitHandler
                if (h != null && text != null && text.length >= LARGE_COMMIT_THRESHOLD) {
                    var s = text.toString()
                    // Gboard giới hạn mục clipboard của NÓ ở 20.000 ký tự (log: commitText đúng 20000 =>
                    // chữ bị cắt). Clipboard HỆ THỐNG thường vẫn giữ bản đầy đủ: nếu nó bắt đầu bằng đúng
                    // chuỗi vừa commit mà dài hơn, thì dán bản đầy đủ.
                    try {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val full = cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
                        if (full != null && full.length > s.length && full.startsWith(s)) {
                            DebugLog.log("LbGeckoView: bàn phím chỉ đưa ${s.length}/${full.length} ký tự (bị cắt ở phía bàn phím) — dán bản đầy đủ từ clipboard hệ thống")
                            s = full
                        } else if (full != null && full == s) {
                            DebugLog.log("LbGeckoView: chuỗi bàn phím KHỚP hoàn toàn clipboard hệ thống (${s.length} ký tự) — không bị cắt trước app")
                        } else if (full != null && full != s) {
                            DebugLog.log("LbGeckoView: clipboard hệ thống (${full.length} ký tự) không khớp phần đầu của chuỗi bàn phím (${s.length}) — dán đúng chuỗi bàn phím")
                        }
                    } catch (e: Exception) {
                        DebugLog.log("LbGeckoView: không đọc được clipboard hệ thống — ${e.javaClass.simpleName}")
                    }
                    DebugLog.log("LbGeckoView: commitText ${s.length} ký tự (>= $LARGE_COMMIT_THRESHOLD) — đổi sang dán native thay vì đường IME")
                    Handler(Looper.getMainLooper()).post {
                        h(s) { ok ->
                            if (!ok) {
                                DebugLog.log("LbGeckoView: dán native không xác nhận được — commit qua IME như cũ")
                                try { base.commitText(s, newCursorPosition) } catch (e: Exception) {
                                    DebugLog.log("LbGeckoView: commit dự phòng lỗi ${e.javaClass.simpleName}: ${e.message}")
                                }
                            }
                        }
                    }
                    return true
                }
                return super.commitText(text, newCursorPosition)
            }
        }
    }

    companion object {
        const val LARGE_COMMIT_THRESHOLD = 4000
    }
}
