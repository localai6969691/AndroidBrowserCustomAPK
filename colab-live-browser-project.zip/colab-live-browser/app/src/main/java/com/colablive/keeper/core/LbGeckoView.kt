package com.colablive.keeper.core

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputConnectionWrapper
import org.mozilla.geckoview.GeckoView

/**
 * GeckoView có chặn "dán văn bản LỚN qua bàn phím ảo" (mục 99).
 *
 * Bàn phím ảo (Gboard...) chèn mục clipboard bằng InputConnection.commitText()
 * — với Gecko đó là chuỗi thao tác IME (đồng bộ toàn bộ Editable Java <-> Gecko,
 * rồi Monaco của Colab xử lý như gõ phím). Văn bản lớn đi đường này làm đơ
 * cả trang. Trình duyệt thật xử lý "dán" bằng lệnh paste native (1 sự kiện),
 * không qua IME. Ở đây: commitText quá lớn -> chuyển thành dán native
 * (NativePaste); nếu không xác nhận được dán native thì mới commit như cũ.
 */
class LbGeckoView(context: Context) : GeckoView(context) {

    /** (text, onNativePasteResult) -> thực hiện dán native. Gán từ MainActivity. */
    var largeCommitHandler: ((String, (Boolean) -> Unit) -> Unit)? = null

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val base = super.onCreateInputConnection(outAttrs) ?: return null
        return object : InputConnectionWrapper(base, true) {
            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                val h = largeCommitHandler
                if (h != null && text != null && text.length >= LARGE_COMMIT_THRESHOLD) {
                    val s = text.toString()
                    DebugLog.log("LbGeckoView: commitText ${s.length} ký tự (>= $LARGE_COMMIT_THRESHOLD) — đổi sang dán native thay vì đường IME")
                    Handler(Looper.getMainLooper()).post {
                        h(s) { ok ->
                            if (!ok) {
                                DebugLog.log("LbGeckoView: dán native không xác nhận được — commit qua IME như cũ")
                                try { base.commitText(s, newCursorPosition) } catch (e: Exception) {
                                    DebugLog.log("LbGeckoView: commit dự phòng lỗi ${e.javaClass.simpleName}: ${e.message}")
                                }
                            }
                        }
                    }
                    return true
                }
                return super.commitText(text, newCursorPosition)
            }
        }
    }

    companion object {
        const val LARGE_COMMIT_THRESHOLD = 4000
    }
}
