package com.colablive.keeper.features.ebookleech.remote

import android.content.Context
import com.colablive.keeper.core.AppPrefs

/**
 * GitHubRemoteConfig — cấu hình repo GitHub dùng để cào từ xa, DÙNG CHUNG
 * cho mọi job trong slot (khác cấu hình riêng từng job) — 1 khe = 1 repo
 * GitHub cào từ xa, hợp lý vì đây là tài khoản/repo của người dùng, không
 * phải thuộc tính của 1 truyện cụ thể.
 *
 * Token PAT lưu RIÊNG qua `SecureTokenStore` (mã hoá) — file này chỉ lưu
 * owner/repo (không nhạy cảm) qua `AppPrefs` như mọi cấu hình khác.
 */
object GitHubRemoteConfig {
    private const val FEATURE_ID = "ebook_leech"
    private const val KEY_OWNER = "gh_repo_owner"
    private const val KEY_REPO = "gh_repo_name"
    private const val KEY_BRANCH = "gh_repo_branch"

    data class Config(val owner: String, val repo: String, val branch: String, val hasToken: Boolean)

    fun load(context: Context, slotIndex: Int): Config = Config(
        owner = AppPrefs.getString(context, slotIndex, FEATURE_ID, KEY_OWNER, ""),
        repo = AppPrefs.getString(context, slotIndex, FEATURE_ID, KEY_REPO, ""),
        branch = AppPrefs.getString(context, slotIndex, FEATURE_ID, KEY_BRANCH, "main"),
        hasToken = SecureTokenStore.hasToken(context),
    )

    fun save(context: Context, slotIndex: Int, owner: String, repo: String, branch: String, token: String?) {
        AppPrefs.setString(context, slotIndex, FEATURE_ID, KEY_OWNER, owner.trim())
        AppPrefs.setString(context, slotIndex, FEATURE_ID, KEY_REPO, repo.trim())
        AppPrefs.setString(context, slotIndex, FEATURE_ID, KEY_BRANCH, branch.trim().ifBlank { "main" })
        // token null = giữ nguyên token cũ (form "sửa cấu hình" không bắt
        // buộc nhập lại token mỗi lần) — chuỗi rỗng = XOÁ token hiện có.
        if (token != null) {
            if (token.isBlank()) SecureTokenStore.clear(context) else SecureTokenStore.save(context, token.trim())
        }
    }

    fun isConfigured(context: Context, slotIndex: Int): Boolean {
        val c = load(context, slotIndex)
        return c.owner.isNotBlank() && c.repo.isNotBlank() && c.hasToken
    }
}
