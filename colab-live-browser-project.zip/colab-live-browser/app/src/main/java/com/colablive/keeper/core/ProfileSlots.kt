package com.colablive.keeper.core

import android.app.ActivityManager
import android.content.Context
import android.os.Process

object ProfileSlots {
    // 3 khe PHỤ thật sự có backing (MainActivitySlot1/2/3, xem AndroidManifest.xml)
    // + khe 0 (chính) = 4 khe chạy song song thật. Trước đây giá trị này là
    // 4 nhưng chỉ 3 khe phụ có Activity thật — khe thứ 4 (phantom) bấm vào
    // sẽ mở NHẦM về khe 0 (rơi vào nhánh else của componentClassNameForSlot).
    const val SLOT_COUNT = 3

    private const val KEY_PROFILES = "profiles"

    /**
     * BUG THẬT đã sửa (người dùng phát hiện: sau khi "đặt tên hồ sơ" cho Khe
     * 1 thành "abc", thanh URL đúng là hiện "Khe 1 — abc", nhưng màn hình
     * "Chuyển Khe" lại KHÔNG thấy "abc" trong danh sách, như chưa tồn tại).
     *
     * Nguyên nhân: `SharedPreferences` của Android giữ 1 bộ nhớ đệm TRONG
     * BỘ NHỚ RIÊNG CHO TỪNG TIẾN TRÌNH — gọi `getSharedPreferences()` nhiều
     * lần trong CÙNG 1 tiến trình luôn trả về CÙNG 1 object đã cache, chỉ
     * đọc file từ đĩa ĐÚNG 1 LẦN (lần đầu tiên). Khi Khe 1 (tiến trình
     * `:slot1`) ghi hồ sơ "abc" mới, Android KHÔNG hề báo cho tiến trình
     * MẶC ĐỊNH (nơi `ProfilePickerActivity`/"Chuyển Khe" chạy) biết để làm
     * mới bộ nhớ đệm — nếu tiến trình mặc định đã từng đọc trước đó (RẤT
     * hay xảy ra vì `KeepAliveService` cố tình giữ tiến trình mặc định sống
     * liên tục hàng giờ, xem mục 8g/8i), nó cứ tưởng danh sách hồ sơ vẫn y
     * như lúc đọc lần đầu — không hề "trùng" mà THẬT SỰ KHÔNG THẤY dữ liệu
     * mới từ tiến trình khác. Đây là giới hạn ĐÃ ĐƯỢC BIẾT của
     * SharedPreferences (tài liệu Android ghi rõ class này KHÔNG hỗ trợ
     * dùng an toàn giữa nhiều tiến trình).
     *
     * Sửa: dữ liệu THẬT SỰ cần đúng giữa MỌI tiến trình (danh sách hồ sơ +
     * khe nào gán hồ sơ nào) chuyển sang đọc/ghi TRỰC TIẾP 1 file JSON trên
     * đĩa mỗi lần cần — không qua SharedPreferences, nên không bị cache
     * theo tiến trình, tiến trình nào đọc cũng thấy đúng dữ liệu mới nhất
     * đã ghi. Ghi qua file tạm rồi đổi tên (rename là thao tác NGUYÊN TỬ
     * trên hệ thống file Android) để tránh đọc phải file ghi dở nếu 2 tiến
     * trình đọc/ghi cùng lúc.
     */
    private fun storeFile(context: Context) = java.io.File(context.filesDir, "profile_slots_store.json")

    private fun readStore(context: Context): org.json.JSONObject {
        val f = storeFile(context)
        if (!f.exists()) return org.json.JSONObject()
        return try {
            org.json.JSONObject(f.readText())
        } catch (e: Exception) {
            org.json.JSONObject()
        }
    }

    // Bản 7.92: AppPrefs.getXxx gọi getSlotAssignment() ở MỌI lần đọc pref (hàng chục lần/giây ở onLoadRequest, vòng giám sát, MemoryPolicy...), mỗi lần đọc LẠI cả file JSON từ đĩa
    // + phân tích thành JSONObject mới => tạo rất nhiều rác + I/O đĩa trên luồng chính. Nay bản ĐỌC-CHỈ được nhớ đệm theo dấu (lastModified, độ dài) của file: tiến trình khác ghi đè file
    // (rename nguyên tử đổi lastModified) thì lần đọc kế tiếp tự đọc lại. KHÔNG được sửa JSONObject trả về — đường GHI vẫn dùng readStore() (bản mới, của riêng người gọi).
    @Volatile private var sharedStamp: Long = Long.MIN_VALUE
    @Volatile private var sharedStore: org.json.JSONObject? = null

    private fun readStoreShared(context: Context): org.json.JSONObject {
        val f = storeFile(context)
        if (!f.exists()) { sharedStore = null; sharedStamp = Long.MIN_VALUE; return org.json.JSONObject() }
        val stamp = f.lastModified() * 31L + f.length()
        val cached = sharedStore
        if (cached != null && stamp == sharedStamp) return cached
        val fresh = readStore(context)
        sharedStore = fresh
        sharedStamp = stamp
        return fresh
    }

    private fun writeStore(context: Context, obj: org.json.JSONObject) {
        val f = storeFile(context)
        val tmp = java.io.File(context.filesDir, "profile_slots_store.json.tmp")
        tmp.writeText(obj.toString())
        tmp.renameTo(f) // atomic — tránh file dở dang nếu process chết giữa chừng ghi
    }

    /** Namespace nội bộ RIÊNG BIỆT cho từng khe khi CHƯA gán hồ sơ nào — 
     * KHÔNG dùng 1 chuỗi mặc định DÙNG CHUNG cho mọi khe (bug thật đã sửa:
     * trước đây mọi khe chưa gán đều rơi về cùng 1 hằng số "Mặc định", nếu
     * dùng làm namespace lưu trữ sẽ khiến 4 khe GỘP CHUNG dữ liệu — ngược
     * hẳn với mục đích cô lập). */
    private fun defaultNamespaceForSlot(slotIndex: Int) = "__slot_default_$slotIndex"

    /**
     * Action broadcast riêng cho từng khe — dùng để báo cho ĐÚNG Activity
     * của khe đó "hãy tự đóng cho đàng hoàng" trước khi bị buộc phải kill
     * process, xem giải thích lớn ở `restartSlot()` trong ProfilePickerActivity.
     */
    fun gracefulCloseAction(slotIndex: Int) = "com.colablive.keeper.ACTION_GRACEFUL_CLOSE_SLOT_$slotIndex"

    /** Khe báo lại "tôi đã đóng phiên Gecko xong thật rồi" — dùng thay cho
     * việc đoán mù 1 khoảng thời gian cố định, xem `MainActivity.onDestroy()`
     * và `ProfilePickerActivity.restartSlot()`. */
    fun gracefulCloseAckAction(slotIndex: Int) = "com.colablive.keeper.ACTION_GRACEFUL_CLOSE_ACK_SLOT_$slotIndex"

    /**
     * Tên class Activity tương ứng với khe — PHẢI khớp chính xác với
     * AndroidManifest.xml (khe 0 = MainActivity chạy process chính, khe 1-3
     * = MainActivitySlot1/2/3, mỗi cái là 1 <activity> THẬT riêng — không
     * dùng activity-alias nữa vì alias không hỗ trợ taskAffinity, xem giải
     * thích trong AndroidManifest.xml). Dùng để build Intent mở đúng khe.
     */
    fun componentClassNameForSlot(slotIndex: Int): String {
        return when (slotIndex) {
            1 -> "com.colablive.keeper.MainActivitySlot1"
            2 -> "com.colablive.keeper.MainActivitySlot2"
            3 -> "com.colablive.keeper.MainActivitySlot3"
            else -> "com.colablive.keeper.MainActivity"
        }
    }

    fun listProfiles(context: Context): List<String> {
        val arr = readStore(context).optJSONArray(KEY_PROFILES) ?: return emptyList()
        return (0 until arr.length()).map { arr.getString(it) }
    }

    fun addProfile(context: Context, name: String) {
        if (name.startsWith("__slot_default_")) return // tên dành riêng nội bộ, không cho trùng
        val current = listProfiles(context)
        if (current.contains(name)) return
        val store = readStore(context)
        val arr = org.json.JSONArray()
        current.forEach { arr.put(it) }
        arr.put(name)
        store.put(KEY_PROFILES, arr)
        writeStore(context, store)
    }

    /** Gỡ tên hồ sơ khỏi danh sách hiển thị (KHÔNG đụng tới dữ liệu trên
     * đĩa — dùng nội bộ bởi `deleteProfileCompletely`, hoặc tự nó nếu chỉ
     * muốn gỡ khỏi danh sách mà giữ lại dữ liệu). */
    fun removeProfile(context: Context, name: String) {
        val current = listProfiles(context)
        if (!current.contains(name)) return
        val store = readStore(context)
        val arr = org.json.JSONArray()
        current.filter { it != name }.forEach { arr.put(it) }
        store.put(KEY_PROFILES, arr)
        writeStore(context, store)
    }

    /**
     * TÍNH NĂNG MỚI (người dùng yêu cầu) — xoá HẲN 1 hồ sơ: dữ liệu Gecko
     * thật trên đĩa (cookies/lịch sử/bookmark/tab đã lưu — tất cả nằm
     * chung 1 thư mục `gecko_profile_<tên>`, xem `safeDirNameFor` dùng
     * thống nhất ở GeckoRuntimeProvider/BrowserBookmarks/BrowserHistory/
     * ProfileExportImport), gỡ khỏi danh sách hồ sơ, VÀ gỡ gán khỏi bất kỳ
     * khe nào đang trỏ tới nó (khe đó quay về namespace mặc định riêng
     * của chính nó — KHÔNG đụng dữ liệu khe khác).
     *
     * AN TOÀN: hàm này chỉ xoá thư mục — KHÔNG tự đóng khe đang chạy hồ
     * sơ đó. Nơi gọi (`ProfilePickerActivity.deleteProfileNow`) PHẢI tự
     * `closeSlotGracefullyThen` trước nếu hồ sơ đang được 1 khe thật sự
     * chạy — tái dùng đúng pattern đã kiểm chứng ở export/ghi đè, tránh
     * đúng lớp bug đã từng xảy ra (xoá thư mục dưới chân tiến trình đang
     * mở file).
     *
     * @return true nếu có thư mục dữ liệu thật để xoá, false nếu hồ sơ
     * chưa từng có dữ liệu (VD mới `addProfile` nhưng chưa từng dùng).
     */
    fun deleteProfileCompletely(context: Context, name: String): Boolean {
        for (slot in 0..SLOT_COUNT) {
            if (getSlotAssignment(context, slot) == name) {
                unassignSlot(context, slot)
            }
        }
        removeProfile(context, name)
        val dir = java.io.File(context.filesDir, safeDirNameForProfile(name))
        return if (dir.exists()) {
            dir.deleteRecursively()
        } else {
            false
        }
    }

    /** PHẢI khớp CHÍNH XÁC với `safeDirNameFor` ở GeckoRuntimeProvider/
     * BrowserBookmarks/BrowserHistory/ProfileExportImport — cùng 1 công
     * thức đặt tên thư mục, lặp lại độc lập ở từng nơi để tránh phụ thuộc
     * chéo module không cần thiết (xem chú thích tương tự ở ProfileExportImport.kt). */
    private fun safeDirNameForProfile(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    /**
     * BUG THẬT ĐÃ SỬA (người dùng báo: "đặt tên hồ sơ cho dữ liệu đang có
     * sẵn trong khe" — ban đầu đang đăng nhập Google, sau khi đặt tên thì
     * BỊ ĐĂNG XUẤT). Xem `GeckoViewEngine.createSessionUnopened()`:
     * `contextId()` — cơ chế cô lập cookie/storage của Gecko mà chính
     * comment trong code đã ghi rõ là "CHẮC CHẮN có tác dụng" (khác hẳn
     * lớp `-profile` vật lý, "CHƯA XÁC NHẬN có ăn thật") — TRƯỚC ĐÂY được
     * tính TRỰC TIẾP từ TÊN HỒ SƠ (`profile_${getSlotAssignment(...)}`).
     *
     * Khi hồ sơ bị đổi tên (namespace đổi từ `__slot_default_N` sang tên
     * người dùng đặt, qua `schedulePromoteSlotData`/`renameProfileDir`),
     * giá trị contextId ĐỔI THEO — Gecko coi đây là 1 "container" cô lập
     * HOÀN TOÀN MỚI. Cookie/session đăng nhập Google (và mọi storage
     * khác) vẫn NẰM NGUYÊN trong container CŨ, không còn namespace nào
     * trỏ tới nữa — dù thư mục vật lý `-profile` đã được
     * `GeckoRuntimeProvider.renameProfileDir()` đổi tên ĐÚNG CÁCH (file
     * cookies.sqlite... thật sự vẫn còn nguyên trong thư mục mới, chỉ là
     * Gecko không đọc storage theo đường dẫn thư mục cho lớp cô lập này).
     *
     * SỬA: contextId phải là 1 ĐỊNH DANH ỔN ĐỊNH không đổi theo tên hiển
     * thị — sinh 1 UUID DUY NHẤT LƯU NGAY TRONG chính thư mục hồ sơ vật
     * lý (`gecko_profile_<namespace>/.context_id`) thay vì suy ra từ tên.
     * Vì file này NẰM BÊN TRONG thư mục bị `renameProfileDir()` đổi tên,
     * nó TỰ ĐỘNG đi theo khi thư mục được rename (rename thư mục = di
     * chuyển nguyên vẹn mọi file con bên trong, hành vi chuẩn của
     * `File.renameTo()`/`rename(2)` trên mọi filesystem POSIX) — không
     * cần thêm logic đồng bộ riêng nào, contextId GIỮ NGUYÊN xuyên suốt
     * mọi lần đổi tên hồ sơ sau này.
     *
     * LƯU Ý: chỉ sửa được cho các hồ sơ MỚI hoặc lần đổi tên TIẾP THEO
     * sau bản vá này. Hồ sơ nào đã bị đổi tên TRƯỚC bản vá (dữ liệu đăng
     * nhập đã "kẹt" lại trong container cũ ứng với contextId cũ) không
     * có cách khôi phục lại qua code — dữ liệu đó vẫn tồn tại vật lý
     * nhưng không có contextId nào trỏ tới nữa.
     */
    fun getStableContextId(context: Context, slotIndex: Int): String {
        val namespace = getSlotAssignment(context, slotIndex)
        val dir = java.io.File(context.filesDir, safeDirNameForProfile(namespace))
        dir.mkdirs()
        val idFile = java.io.File(dir, ".context_id")
        if (idFile.exists()) {
            val existing = try { idFile.readText().trim() } catch (e: Exception) { "" }
            if (existing.isNotEmpty()) return existing
        }
        // BUG THẬT ĐÃ SỬA (nghiêm trọng — người dùng báo: SAU KHI VÁ BUG
        // "đổi tên mất đăng nhập", TOÀN BỘ hồ sơ (kể cả hồ sơ CHƯA TỪNG đổi
        // tên) đều bị đăng xuất Google ngay lần chạy đầu tiên với bản vá).
        //
        // Nguyên nhân: dòng code CŨ ở đây (đã xoá) sinh 1
        // `UUID.randomUUID()` HOÀN TOÀN NGẪU NHIÊN làm giá trị khởi tạo cho
        // BẤT KỲ hồ sơ nào chưa có file `.context_id` — tức là MỌI hồ sơ đã
        // tồn tại TRƯỚC bản vá (100% trong số đó, vì file này chưa từng
        // được tạo ra trước khi tính năng này có mặt). Nhưng contextId THẬT
        // SỰ đã dùng cho các hồ sơ đó TỪ TRƯỚC (ở bản build cũ hơn nữa,
        // trước cả bug "đổi tên") lại là `profile_<namespace>` — suy trực
        // tiếp từ TÊN namespace, KHÔNG PHẢI UUID ngẫu nhiên. Sinh UUID mới
        // ngẫu nhiên ở đây chắc chắn KHÔNG khớp với contextId cũ đó → với
        // Gecko, đây là 1 container HOÀN TOÀN MỚI (như đã giải thích trong
        // JavaDoc ở trên) → session/cookie cũ vẫn "kẹt" ở container ứng với
        // tên namespace, container mới (theo UUID) trống trơn — y hệt loại
        // bug đang cố sửa, chỉ khác là xảy ra cho MỌI hồ sơ thay vì chỉ hồ
        // sơ vừa đổi tên.
        //
        // SỬA: giá trị khởi tạo PHẢI LÀ chính `namespace` hiện tại (không
        // phải UUID ngẫu nhiên) — giá trị này TRÙNG KHỚP với contextId
        // (`profile_<namespace>`) mà `GeckoViewEngine` đã dùng ở MỌI bản
        // build trước đây, nên phiên đăng nhập/cookie hiện có được GIỮ
        // NGUYÊN đúng như kỳ vọng. Từ đây trở đi, giá trị này được ghi CỐ
        // ĐỊNH vào `.context_id` — các lần đổi tên hồ sơ SAU NÀY không làm
        // nó đổi theo nữa (đây chính là mục tiêu ban đầu của bản vá), vì
        // `renameProfileDir()` di chuyển nguyên vẹn file này theo thư mục.
        val newId = namespace
        try {
            idFile.writeText(newId)
        } catch (e: Exception) {
            DebugLog.log("getStableContextId: ghi .context_id lỗi (${e.message}) — dùng ID tạm không lưu bền cho phiên này")
        }
        return newId
    }

    /**
     * Tên hồ sơ ĐANG GÁN cho khe này — nếu chưa gán hồ sơ nào, trả về
     * namespace RIÊNG BIỆT của chính khe đó (không dùng chung cho khe khác).
     */
    fun getSlotAssignment(context: Context, slotIndex: Int): String {
        return readStoreShared(context).optString("slot_assignment_$slotIndex", null) ?: defaultNamespaceForSlot(slotIndex)
    }

    /** Tên hiển thị TRONG UI cho phần gán của khe — khác `getSlotAssignment`
     * (namespace lưu trữ nội bộ) ở chỗ không lộ ra chuỗi `__slot_default_N`. */
    fun getSlotAssignmentDisplay(context: Context, slotIndex: Int): String {
        val raw = readStoreShared(context).optString("slot_assignment_$slotIndex", null)
        return raw ?: "(chưa gán hồ sơ — dữ liệu riêng của ${getSlotName(slotIndex)})"
    }

    /**
     * Ghi TRỰC TIẾP xuống file (không qua SharedPreferences, xem giải thích
     * lớn ở đầu file) — bản thân việc ghi file (`writeStore`) đã đồng bộ,
     * không cần `.commit()` như SharedPreferences nữa; an toàn dù process
     * chết ngay sau khi hàm return (kể cả trường hợp Khe 0 tự kill process
     * ngay sau khi gọi hàm này, trong `restartSlot(0)`).
     */
    fun setSlotAssignment(context: Context, slotIndex: Int, name: String) {
        val store = readStore(context)
        store.put("slot_assignment_$slotIndex", name)
        writeStore(context, store)
    }

    /** Bỏ gán hồ sơ — khe quay về dùng namespace RIÊNG của chính nó, không
     * còn chung với bất kỳ hồ sơ nào khác. */
    fun unassignSlot(context: Context, slotIndex: Int) {
        val store = readStore(context)
        store.remove("slot_assignment_$slotIndex")
        writeStore(context, store)
    }

    /** Khe khác (không phải `slotIndex`) đang được gán hồ sơ `profileName`
     * không — nếu có, trả về số khe đó; không thì trả về null. Dùng để
     * cảnh báo/khoá việc gán trùng 1 hồ sơ vào 2 khe CÙNG chạy song song. */
    fun findOtherSlotUsingProfile(context: Context, slotIndex: Int, profileName: String): Int? {
        val store = readStore(context)
        for (other in 0..SLOT_COUNT) {
            if (other == slotIndex) continue
            if (store.optString("slot_assignment_$other", null) == profileName) return other
        }
        return null
    }

    /**
     * Đặt tên cho dữ liệu ĐANG CÓ SẴN trong 1 khe (khi khe đó CHƯA từng
     * gán hồ sơ nào — vẫn đang dùng namespace riêng `__slot_default_N`)
     * thành 1 hồ sơ có tên, để dùng lại/di động được như hồ sơ khác. Tính
     * năng này TRƯỚC ĐÂY CHƯA TỒN TẠI: "Thêm profile mới" chỉ thêm 1 TÊN
     * vào danh sách, không hề đụng tới dữ liệu đang chạy trong khe — nếu
     * gán tên mới đó vào khe qua "Đổi" thì Gecko sẽ tạo hồ sơ TRẮNG hoàn
     * toàn mới (tên namespace khác → thư mục khác, xem GeckoRuntimeProvider),
     * MẤT hết cookie/đăng nhập đang có trong khe.
     *
     * KHÔNG đổi tên thư mục hồ sơ Gecko trên đĩa NGAY tại đây — nếu Khe đó
     * đang có GeckoRuntime sống (rất có thể, vì bạn thường mở
     * ProfilePickerActivity ngay TỪ trong khe đang chạy) thì đổi tên thư
     * mục dưới chân 1 tiến trình Gecko đang sống là rủi ro thật (Gecko vẫn
     * nhớ đường dẫn CŨ để ghi file mới). Thay vào đó LƯU Ý ĐỊNH đổi tên rồi
     * khởi động lại đúng khe đó — khi tiến trình MỚI (sạch, chưa đụng
     * Gecko) khởi động, `LiveBrowserApp.onCreate()` sẽ áp dụng đổi tên thật
     * (đổi cả SharedPreferences lẫn thư mục trên đĩa) TRƯỚC KHI bất kỳ
     * GeckoRuntime nào được tạo — an toàn.
     */
    private const val PENDING_PROMOTE_PREFS = "pending_profile_promote"

    /**
     * Mục 116: `replaceExisting = true` = đưa dữ liệu của khe VÀO một hồ sơ ĐÃ CÓ SẴN trong danh sách (vd hồ sơ trắng vừa tạo bằng
     * "Tạo profile mới"): dữ liệu cũ của hồ sơ đích (nếu có) bị XOÁ và thay bằng dữ liệu của khe. Trước đây chỉ làm được với tên MỚI
     * (tên đã tồn tại bị từ chối) nên hồ sơ tạo sẵn không có đường nào nhận dữ liệu.
     */
    fun schedulePromoteSlotData(context: Context, slotIndex: Int, newProfileName: String, replaceExisting: Boolean = false) {
        val oldNamespace = getSlotAssignment(context, slotIndex)
        context.getSharedPreferences(PENDING_PROMOTE_PREFS, Context.MODE_PRIVATE).edit()
            .putInt("slot", slotIndex)
            .putBoolean("replace", replaceExisting)
            .putString("old_ns", oldNamespace)
            .putString("new_name", newProfileName)
            .commit() // đồng bộ — Khe 0 có thể tự kill process ngay sau lệnh gọi hàm này
    }

    /** Gọi ở `LiveBrowserApp.onCreate()` — sớm nhất có thể trong vòng đời
     * tiến trình, TRƯỚC khi bất kỳ GeckoRuntime nào được tạo. Chỉ áp dụng
     * nếu lệnh đổi tên đang chờ ĐÚNG là dành cho khe của TIẾN TRÌNH hiện
     * tại (so `getCurrentSlotIndex`) — 1 tiến trình khác có thể đọc trúng
     * SharedPreferences này nhưng không phải khe được nhắm tới thì bỏ qua,
     * không tự xoá cờ (khe đúng sẽ tự đọc và xoá khi nó thật sự khởi động). */
    data class PendingPromote(val slot: Int, val oldNs: String, val newName: String, val replaceExisting: Boolean)

    fun consumePendingPromoteForCurrentProcess(context: Context): PendingPromote? {
        val p = context.getSharedPreferences(PENDING_PROMOTE_PREFS, Context.MODE_PRIVATE)
        val pendingSlot = p.getInt("slot", -1)
        if (pendingSlot == -1) return null
        if (pendingSlot != getCurrentSlotIndex(context)) return null
        val oldNs = p.getString("old_ns", null) ?: return null
        val newName = p.getString("new_name", null) ?: return null
        val replace = p.getBoolean("replace", false)
        p.edit().clear().commit()
        return PendingPromote(pendingSlot, oldNs, newName, replace)
    }

    /**
     * BUG THẬT tìm ra (người dùng báo: "restore profile mất open tabs" —
     * gán 1 hồ sơ ĐÃ CÓ SẴN tab riêng vào 1 khe, hoặc bỏ gán 1 khe, thì
     * đúng hồ sơ đó SAU NÀY mở lại lại mất tab): `showReassignDialog()`
     * (ProfilePickerActivity) TRƯỚC ĐÂY gọi thẳng `setSlotAssignment()`/
     * `unassignSlot()` NGAY LẬP TỨC, TRƯỚC KHI gọi `restartSlot()` — khác
     * hẳn với luồng "đặt tên cho dữ liệu" (`schedulePromoteSlotData`) vốn
     * CHỈ LƯU Ý ĐỊNH, áp dụng thật SAU KHI khe cũ đã đóng đàng hoàng.
     *
     * Hậu quả cụ thể: `restartSlot()` gửi broadcast "đóng đàng hoàng" tới
     * khe đang chạy — khe đó (`MainActivity.gracefulCloseReceiver`) gọi
     * `engine.saveTabsState()` để lưu tab HIỆN TẠI trước khi đóng. Nhưng
     * `saveTabsState()`/`tabStateFile()` tính đường dẫn file BẰNG CÁCH GỌI
     * LẠI `ProfileSlots.getSlotAssignment()` NGAY LÚC ĐÓ — nếu assignment
     * đã bị đổi (bước 1 ở trên) TRƯỚC KHI broadcast này được xử lý, hàm sẽ
     * ghi NHẦM tab của hồ sơ CŨ (đang đóng) đè lên đúng file
     * `saved_tabs.json` của hồ sơ MỚI vừa được gán — XÓA MẤT tab thật sự
     * thuộc về hồ sơ mới đó.
     *
     * Sửa đúng theo pattern ĐÃ CÓ SẴN và ĐÃ ĐÚNG của `schedulePromoteSlotData`:
     * không đổi assignment ngay — chỉ LƯU Ý ĐỊNH, áp dụng thật ở
     * `LiveBrowserApp.onCreate()` của TIẾN TRÌNH MỚI (sau khi khe cũ chắc
     * chắn đã đóng xong, đã lưu tab đúng theo assignment CŨ). `newName ==
     * null` dùng làm cờ báo "bỏ gán" (khác trường hợp "gán hồ sơ có tên"),
     * tránh phải thêm 1 bộ SharedPreferences/hàm riêng chỉ cho unassign.
     */
    private const val PENDING_REASSIGN_PREFS = "pending_slot_reassign"

    fun schedulePendingReassign(context: Context, slotIndex: Int, newProfileNameOrNullForUnassign: String?) {
        context.getSharedPreferences(PENDING_REASSIGN_PREFS, Context.MODE_PRIVATE).edit()
            .putInt("slot", slotIndex)
            .putBoolean("has_name", newProfileNameOrNullForUnassign != null)
            .putString("new_name", newProfileNameOrNullForUnassign ?: "")
            .commit() // đồng bộ — process gọi hàm này có thể sắp bị đóng/kill ngay sau đó
    }

    /** Gọi ở `LiveBrowserApp.onCreate()`, cùng thời điểm/lý do với
     * `consumePendingPromoteForCurrentProcess` — xem giải thích lớn ở
     * `schedulePendingReassign()`. Trả về (slotIndex, newNameOrNull);
     * `newNameOrNull == null` nghĩa là "bỏ gán". */
    fun consumePendingReassignForCurrentProcess(context: Context): Pair<Int, String?>? {
        val p = context.getSharedPreferences(PENDING_REASSIGN_PREFS, Context.MODE_PRIVATE)
        val pendingSlot = p.getInt("slot", -1)
        if (pendingSlot == -1) return null
        if (pendingSlot != getCurrentSlotIndex(context)) return null
        val hasName = p.getBoolean("has_name", false)
        val newName = if (hasName) p.getString("new_name", null) else null
        p.edit().clear().commit()
        return pendingSlot to newName
    }

    fun getSlotIndexFromProcess(processName: String?): Int {
        if (processName == null) return 0
        return when {
            processName.endsWith(":slot1") -> 1
            processName.endsWith(":slot2") -> 2
            processName.endsWith(":slot3") -> 3
            else -> 0
        }
    }

    fun getCurrentSlotIndex(context: Context): Int {
        // BUG THẬT đã sửa: `ActivityManager.getRunningAppProcesses()` có thể
        // trả về null hoặc danh sách RỖNG khi gọi QUÁ SỚM trong vòng đời
        // tiến trình (vd từ `LiveBrowserApp.Application.onCreate()`) — ở thời
        // điểm này tiến trình chưa đăng ký xong với system_server, IPC chưa
        // sẵn sàng. Hậu quả: mọi khe đều trả về 0 → ghi log sai file (khe 1
        // ghi vào debug_log_slot0.txt thay vì debug_log_slot1.txt).
        //
        // Sửa: dùng `Application.getProcessName()` (API 28, Android 9+) —
        // đọc thẳng từ `/proc/self/cmdline` (không qua IPC, không phụ thuộc
        // system_server), đáng tin cậy ở bất kỳ thời điểm nào trong vòng đời
        // tiến trình. App này yêu cầu minSdk 26, nhưng API 28 vẫn cần guard.
        // Fallback về ActivityManager cho API 26-27 (rất hiếm, chấp nhận được).
        val processName: String? = if (android.os.Build.VERSION.SDK_INT >= 28) {
            android.app.Application.getProcessName()
        } else {
            // Fallback API 26-27: ActivityManager — có thể không đáng tin ở
            // Application.onCreate() nhưng không còn lựa chọn nào tốt hơn.
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val myPid = Process.myPid()
            am.runningAppProcesses?.firstOrNull { it.pid == myPid }?.processName
        }
        return getSlotIndexFromProcess(processName)
    }

    fun getSlotName(slotIndex: Int): String {
        return when (slotIndex) {
            0 -> "Khe chính"
            1 -> "Khe 1"
            2 -> "Khe 2"
            3 -> "Khe 3"
            else -> "Khe $slotIndex"
        }
    }

    /**
     * BUG THẬT đã sửa: nút "Tự động tìm proxy nhanh nhất" trước đây chọn
     * đúng 1 proxy nhanh nhất DUY NHẤT trong toàn danh sách cào được, không
     * biết gì về việc khe khác đã dùng proxy nào. 4 khe chạy song song,
     * cùng bấm nút gần nhau, cùng nguồn cào, cùng mạng máy → gần như chắc
     * chắn ra cùng 1 proxy nhanh nhất → 4 hồ sơ lộ ra CÙNG 1 IP, y hệt kiểu
     * leak lo ngại ban đầu (dù fingerprint/cookie mỗi hồ sơ vẫn cô lập).
     *
     * Trả về tập (host, port) đang được các khe KHÁC (không phải khe đang
     * gọi hàm) sử dụng — dùng để loại các proxy này khỏi danh sách ứng viên
     * trước khi tìm "nhanh nhất", tránh 2 khe trùng IP khi cùng tự động tìm.
     * Chỉ xét các khe vật lý đang tồn tại (0..SLOT_COUNT) vì đây là phạm vi
     * thật sự có thể chạy song song cùng lúc trên máy.
     */
    fun proxiesInUseByOtherSlots(context: Context, currentSlotIndex: Int): Set<Pair<String, Int>> {
        val result = mutableSetOf<Pair<String, Int>>()
        for (slot in 0..SLOT_COUNT) {
            if (slot == currentSlotIndex) continue
            val host = AppPrefs.getString(context, slot, "proxy_host", "")
            val portStr = AppPrefs.getString(context, slot, "proxy_port", "")
            val port = portStr.toIntOrNull() ?: continue
            if (host.isNotBlank()) {
                result.add(host to port)
            }
        }
        return result
    }

    /** Xoá dữ liệu của HỒ SƠ đang gán cho khe này (không phải "khe" — khe chỉ
     * là chỗ chạy, dữ liệu thuộc về hồ sơ, xem AppPrefs/GeckoRuntimeProvider). */
    fun clearSlotData(context: Context, slotIndex: Int) {
        AppPrefs.clearSlot(context, slotIndex)
        GeckoRuntimeProvider.clearSlotData(context, slotIndex)
        DebugLog.log("Cleared data for profile '${getSlotAssignment(context, slotIndex)}' (mounted in slot $slotIndex)")
    }
}
