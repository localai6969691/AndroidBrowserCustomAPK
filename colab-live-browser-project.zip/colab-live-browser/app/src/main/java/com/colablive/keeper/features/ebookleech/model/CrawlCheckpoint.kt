package com.colablive.keeper.features.ebookleech.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * CrawlCheckpoint — "ảnh chụp" trạng thái crawl của 1 job tại 1 thời điểm,
 * đủ để `EbookLeechCrawler` khôi phục lại và cào TIẾP thay vì cào lại từ
 * đầu — kể cả khi app bị kill/crash giữa chừng.
 *
 * ĐỘ CHI TIẾT resume theo từng phase (không đều nhau, ghi rõ để không hiểu
 * lầm là "resume chính xác tuyệt đối mọi lúc"):
 *  - Phase -1 (kịch bản nhiều bước): checkpoint CHỈ lưu SAU KHI xong toàn
 *    bộ kịch bản — nếu crash giữa lúc đang duyệt kịch bản, resume = chạy
 *    lại kịch bản từ đầu (ít tốn kém vì kịch bản thường nhanh hơn nhiều so
 *    với cào nội dung chương).
 *  - Phase 0/1 (thu thập link chương): checkpoint lưu SAU KHI xong toàn bộ
 *    link của 1 "entry" — nếu crash giữa lúc đang phân trang thu link,
 *    resume = quét lại link từ trang 1 của ĐÚNG entry đang dở (không phải
 *    từ đầu toàn bộ job nếu đã có entry trước đó xong).
 *  - Phase 2 (cào nội dung chương): checkpoint lưu SAU MỖI CHƯƠNG — đây là
 *    phase tốn thời gian nhất (network + delay mỗi chương), nên đây là chỗ
 *    granularity CHÍNH XÁC NHẤT — crash giữa job dài 500 chương, resume
 *    đúng chương đang dở, KHÔNG cào lại các chương đã xong.
 *  - Đang NEEDS_ACTION (chờ giải Cloudflare/captcha): checkpoint lưu ngay
 *    lúc đó — resume mở lại đúng URL đang chặn.
 */
data class CrawlCheckpoint(
    val jobId: String,
    val phase: Phase,
    val listPageEntries: List<String>,
    val listPageEntryIndex: Int,
    val chapterLinks: List<String>,
    val chapterProgressIndex: Int,      // đã cào xong tới link thứ mấy trong chapterLinks (0-based)
    val chaptersSoFar: List<LeechChapter>,  // TOÀN BỘ chương đã cào từ đầu job (không riêng entry hiện tại) — ĐÃ SỬA: ảnh của các chương này giờ khôi phục được đầy đủ khi resume, xem CrawlCheckpointRepository.persistImageBytes()
    val blockedChapterCount: Int,
    val pausedAtIndex: Int,             // -1 = không pause; >=0 = đang chờ giải xác minh tại chapterLinks[pausedAtIndex]
    val savedAt: Long = System.currentTimeMillis(),
) {
    enum class Phase { COLLECTING_LINKS, CRAWLING_CHAPTERS }

    fun toJson(): JSONObject = JSONObject().apply {
        put("jobId", jobId)
        put("phase", phase.name)
        put("listPageEntries", JSONArray(listPageEntries))
        put("listPageEntryIndex", listPageEntryIndex)
        put("chapterLinks", JSONArray(chapterLinks))
        put("chapterProgressIndex", chapterProgressIndex)
        put("chaptersSoFar", LeechChapter.listToJson(chaptersSoFar))
        put("blockedChapterCount", blockedChapterCount)
        put("pausedAtIndex", pausedAtIndex)
        put("savedAt", savedAt)
    }

    companion object {
        /** @param imageLoader Xem `LeechChapter.fromJson()` — truyền xuống
         * nguyên vẹn để khôi phục đúng bytes ảnh của từng chương. */
        fun fromJson(json: JSONObject, imageLoader: (String) -> ByteArray? = { null }): CrawlCheckpoint = CrawlCheckpoint(
            jobId = json.getString("jobId"),
            phase = Phase.valueOf(json.optString("phase", "COLLECTING_LINKS")),
            listPageEntries = json.optJSONArray("listPageEntries")?.let { arr ->
                (0 until arr.length()).map { arr.getString(it) }
            } ?: emptyList(),
            listPageEntryIndex = json.optInt("listPageEntryIndex", 0),
            chapterLinks = json.optJSONArray("chapterLinks")?.let { arr ->
                (0 until arr.length()).map { arr.getString(it) }
            } ?: emptyList(),
            chapterProgressIndex = json.optInt("chapterProgressIndex", 0),
            chaptersSoFar = json.optJSONArray("chaptersSoFar")?.let { LeechChapter.listFromJson(it, imageLoader) } ?: emptyList(),
            blockedChapterCount = json.optInt("blockedChapterCount", 0),
            pausedAtIndex = json.optInt("pausedAtIndex", -1),
            savedAt = json.optLong("savedAt", 0L),
        )
    }
}
