package com.colablive.keeper.core

import java.net.URI
import java.net.URLDecoder

/**
 * Bản 7.104 — nhận diện và HOÃN cú chuyển trang sang "thử thách" (captcha) của Cloudflare/claude.ai khi nó xảy ra ở TAB NỀN.
 *
 * Bằng chứng (log 12/11 21:31–21:33, bản 7.98): sau khi mở lại app (ra nền 11947s), bốn tab claude.ai KHÔNG đang xem tự chuyển tới `https://claude.ai/api/challenge_redirect?to=<trang chat>`
 * từng tab một, bắt đầu ~21 giây sau khi quay lại app; tab đang xem không bị. Địa chỉ này do claude.ai/Cloudflare tạo (không có dòng code nào của app dựng ra nó) — trang tự chuyển hướng khi
 * một lời gọi API của nó bị Cloudflare trả `403 cf-mitigated: challenge`. Cùng thời điểm IP ra đổi từ VN (103.199.57.12) sang US (207.244.71.82), nên giấy thông hành `cf_clearance` cũ (gắn với IP) hết giá trị.
 * CHƯA chứng minh được: cái gì khiến trang nền gọi API đúng lúc đó (hẹn giờ của trang sau khi tiến trình được đánh thức, hay thứ khác) — vì vậy bản này cũng GHI RÕ cờ nguồn (isDirectNavigation / isRedirect / triggerUri).
 *
 * Cách xử lý (cơ chế chung, không riêng thiết bị): tab KHÔNG đang được xem, không thuộc danh sách ghim chạy nền, và cú điều hướng do TRANG (không phải app) khởi tạo => chặn tại onLoadRequest,
 * nhớ trang đích, và chỉ nạp lại trang đích khi người dùng MỞ tab đó (lúc ấy thử thách, nếu còn, diễn ra trước mắt người dùng với IP đã ổn định). Không đọc được cờ nguồn => KHÔNG hoãn (giữ hành vi cũ).
 */
object ChallengeNav {
    /** Điểm khởi đầu thử thách của claude.ai. Thêm mẫu khác ở đây nếu gặp site có cùng kiểu. */
    private val START_MARKERS = listOf("/api/challenge_redirect")

    fun isChallengeUrl(uri: String): Boolean {
        val path = try { URI(uri).path ?: "" } catch (e: Exception) { uri.substringBefore('?') }
        return START_MARKERS.any { path.contains(it) }
    }

    /** Trang đích mà thử thách sẽ quay về (`to=` — chỉ nhận https cùng host), không có thì [fallback] (URL cuối của tab). */
    fun targetOf(uri: String, fallback: String?): String? {
        try {
            val u = URI(uri)
            val q = u.rawQuery ?: return fallback
            for (part in q.split('&')) {
                if (part.startsWith("to=")) {
                    val dec = URLDecoder.decode(part.removePrefix("to="), "UTF-8")
                    val t = URI(dec)
                    if (t.scheme == "https" && t.host != null && t.host.equals(u.host, ignoreCase = true)) return dec
                }
            }
        } catch (e: Exception) { /* dùng fallback */ }
        return fallback
    }

    /** Hoãn khi: bật, tab không được xem, không phải tab ghim chạy nền, và BIẾT CHẮC cú điều hướng do trang khởi tạo (isDirectNavigation == false). */
    fun shouldDefer(enabled: Boolean, tabShown: Boolean, tabKeptAlive: Boolean, isDirectNavigation: Boolean?): Boolean =
        enabled && !tabShown && !tabKeptAlive && isDirectNavigation == false

    class Origin(val isDirect: Boolean?, val isRedirect: Boolean?, val trigger: String?) {
        fun note(): String = "nguồn: ${when (isDirect) { true -> "APP gọi loadUri"; false -> "TRANG tự chuyển"; null -> "không đọc được cờ" }}" +
            (if (isRedirect != null) ", redirect=$isRedirect" else "") + (if (!trigger.isNullOrBlank()) ", kích bởi ${trigger.take(80)}" else "")
    }

    /** Đọc cờ nguồn của GeckoSession.NavigationDelegate.LoadRequest bằng reflection (không phụ thuộc phiên bản API lúc biên dịch; lỗi => null = không biết). */
    fun originOf(request: Any): Origin {
        fun b(n: String): Boolean? = try { request.javaClass.getField(n).getBoolean(request) } catch (e: Throwable) { null }
        val trig = try { request.javaClass.getField("triggerUri").get(request) as? String } catch (e: Throwable) { null }
        return Origin(b("isDirectNavigation"), b("isRedirect"), trig)
    }
}
