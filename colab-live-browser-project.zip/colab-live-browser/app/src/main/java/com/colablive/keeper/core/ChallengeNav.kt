package com.colablive.keeper.core

import java.net.URI
import java.net.URLDecoder

/**
 * Bản 7.104/7.105 — nhận diện và HOÃN những cú TỰ chuyển trang của TAB NỀN (trước hết là trang "thử thách"/captcha của Cloudflare/claude.ai, từ 7.105 là mọi cú chuyển trang do trang tự khởi tạo).
 *
 * Bằng chứng (log 12/11 21:31–21:33, bản 7.98): app ra nền 11947 s rồi quay lại với 14/24 tab còn session sống (`đang tải=14` là số tab có session, KHÔNG phải số tab đang tải).
 * Lúc 21:32:10 người dùng mở tab 53bf0af7 (dòng `ÁP LẠI giao diện di động` không kèm onLoadRequest = đúng dấu của switchToTab). Trong 21:32:11–21:32:12 BA tab khác (57a3d8bf, 652fa5ca, 99fe125e)
 * phát onLoadRequest tới `https://claude.ai/api/challenge_redirect?to=<trang chat>` mà trước đó KHÔNG có lần chuyển tab nào tới chúng (mọi lần chuyển tới tab đã đánh dấu di động đều để lại dòng `ÁP LẠI`).
 * Địa chỉ `challenge_redirect` do claude.ai/Cloudflare tạo, không có dòng code nào của app dựng ra nó. Rồi chính app GIỮ cú chuyển đó (cổng danh tính) và NẠP LẠI nó khi nhả
 * (`[proxy FAIL-CLOSED] nhả điều hướng đã giữ … nạp lại`, 21:32:12/16/19) — tức là app biến một cú tự chuyển của trang nền thành kết nối thật cho tab người dùng chưa xem.
 *
 * ĐÃ BỎ một suy diễn sai của bản 7.104: "IP đổi VN→US nên cf_clearance gắn với IP hết giá trị". Log cho thấy các cú chuyển trang xảy ra lúc 21:32:11–12, TRƯỚC phép đo IP đầu tiên ra US (21:32:22), và tài liệu
 * Cloudflare chỉ nói clearance "gắn với khách và thiết bị đã được cấp" (không nói IP). Nguyên nhân khiến trang nền gọi API/bị thử thách đúng lúc đó CHƯA chứng minh được (ứng viên: hẹn giờ của trang sau
 * khi tiến trình được đánh thức, clearance hết hạn sau 3,3 giờ, IP đổi).
 *
 * Cách xử lý (cơ chế chung, không riêng thiết bị/site): tab KHÔNG đang được xem, không thuộc danh sách ghim chạy nền, và cú điều hướng do TRANG (không phải app) khởi tạo => chặn tại onLoadRequest,
 * nhớ trang đích, và chỉ nạp lại trang đích khi người dùng MỞ tab đó. Không đọc được cờ nguồn => KHÔNG hoãn (giữ hành vi cũ).
 *  - 7.104: chỉ trang thử thách (`isChallengeUrl`), có tính cả lúc app ở nền (`shouldDefer`).
 *  - 7.105: mọi cú tự chuyển trang http(s) ở cửa sổ hiện tại của tab KHÔNG phải tab đang xem, không phải redirect của lần tải đang dở, không có thao tác người dùng (`shouldDeferNav`).
 *    Giới hạn có chủ ý: chỉ chặn việc TẢI TRANG mới; XHR/fetch/WebSocket của trang nền vẫn chạy (Gecko không có API đóng băng mạng; `setActive(false)` chỉ bóp hẹn giờ và ngừng vẽ).
 */
object ChallengeNav {
    /** Điểm khởi đầu thử thách của claude.ai. Thêm mẫu khác ở đây nếu gặp site có cùng kiểu. */
    private val START_MARKERS = listOf("/api/challenge_redirect")

    fun isChallengeUrl(uri: String): Boolean {
        val path = try { URI(uri).path ?: "" } catch (e: Exception) { uri.substringBefore('?') }
        return START_MARKERS.any { path.contains(it) }
    }

    /** Trang đích mà thử thách sẽ quay về (`to=` — chỉ nhận https cùng host), không có thì [fallback] (URL cuối của tab). */
    fun targetOf(uri: String, fallback: String?): String? {
        try {
            val u = URI(uri)
            val q = u.rawQuery ?: return fallback
            for (part in q.split('&')) {
                if (part.startsWith("to=")) {
                    val dec = URLDecoder.decode(part.removePrefix("to="), "UTF-8")
                    val t = URI(dec)
                    if (t.scheme == "https" && t.host != null && t.host.equals(u.host, ignoreCase = true)) return dec
                }
            }
        } catch (e: Exception) { /* dùng fallback */ }
        return fallback
    }

    /** Hoãn khi: bật, tab không được xem, không phải tab ghim chạy nền, và BIẾT CHẮC cú điều hướng do trang khởi tạo (isDirectNavigation == false). */
    fun shouldDefer(enabled: Boolean, tabShown: Boolean, tabKeptAlive: Boolean, isDirectNavigation: Boolean?): Boolean =
        enabled && !tabShown && !tabKeptAlive && isDirectNavigation == false

    /**
     * Bản 7.105 — hoãn MỌI cú tự chuyển trang của tab nền (không riêng captcha). Chỉ hoãn khi BIẾT CHẮC cả bốn điều: không phải app gọi (isDirectNavigation=false), không phải redirect của lần tải đang dở
     * (isRedirect=false), không có thao tác người dùng (hasUserGesture=false) và đích là cửa sổ HIỆN TẠI của tab (không phải cửa sổ mới/popup). Cờ nào không đọc được (null) => KHÔNG hoãn.
     */
    fun shouldDeferNav(enabled: Boolean, tabActive: Boolean, tabKeptAlive: Boolean, isDirectNavigation: Boolean?, isRedirect: Boolean?, hasUserGesture: Boolean?, currentWindow: Boolean): Boolean =
        enabled && currentWindow && !tabActive && !tabKeptAlive && isDirectNavigation == false && isRedirect == false && hasUserGesture == false

    class Origin(val isDirect: Boolean?, val isRedirect: Boolean?, val trigger: String?, val hasGesture: Boolean? = null) {
        fun note(): String = "nguồn: ${when (isDirect) { true -> "APP gọi loadUri"; false -> "TRANG tự chuyển"; null -> "không đọc được cờ" }}" +
            (if (isRedirect != null) ", redirect=$isRedirect" else "") + (if (hasGesture != null) ", thao tác người dùng=$hasGesture" else "") +
            (if (!trigger.isNullOrBlank()) ", kích bởi ${trigger.take(80)}" else "")
    }

    /** Đọc cờ nguồn của GeckoSession.NavigationDelegate.LoadRequest bằng reflection (không phụ thuộc phiên bản API lúc biên dịch; lỗi => null = không biết). */
    fun originOf(request: Any): Origin {
        fun b(n: String): Boolean? = try { request.javaClass.getField(n).getBoolean(request) } catch (e: Throwable) { null }
        val trig = try { request.javaClass.getField("triggerUri").get(request) as? String } catch (e: Throwable) { null }
        return Origin(b("isDirectNavigation"), b("isRedirect"), trig, b("hasUserGesture"))
    }
}
