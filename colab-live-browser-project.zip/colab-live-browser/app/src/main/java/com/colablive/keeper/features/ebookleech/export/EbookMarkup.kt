package com.colablive.keeper.features.ebookleech.export

import com.colablive.keeper.features.ebookleech.model.LeechChapter
import com.colablive.keeper.features.ebookleech.model.LeechImage
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.model.StoryMeta
import com.colablive.keeper.features.ebookleech.model.TocNode
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Bản 7.104 — phần THUẦN (không đụng Android) của việc dựng EPUB/TXT/HTML + file kèm `.story.json`, tách khỏi [EbookExporter] để kiểm được trên JVM (xem tools/ebookleech_sim).
 *
 * Sửa hai lỗi cũ của EPUB do app xuất ra: (1) `content.opf` và trang chương bắt đầu bằng khoảng trắng TRƯỚC dòng `<?xml ...?>` (do `trimIndent()` trên chuỗi có nội dung chèn vào) —
 * XML chuẩn không cho phép, trình đọc/trình phân tích nghiêm ngặt từ chối; (2) nội dung chương là HTML (`innerHTML`: `<br>`, `<img ...>` không đóng, `&nbsp;`) đặt thẳng vào XHTML nên không
 * phải XML hợp lệ — [xhtmlFix] đưa về XHTML hợp lệ khi xuất (cả dữ liệu cũ trong kho/checkpoint).
 *
 * Thêm: siêu dữ liệu OPF (tác giả, tóm tắt, thể loại/tag, ngôn ngữ, nguồn, bộ truyện, người dịch, điểm Calibre), ảnh bìa, trang "Giới thiệu", và file `.story.json` (xem [sidecarJson]).
 */
object EbookMarkup {

    const val DECL = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
    private val VOID_TAGS = setOf("area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr")
    /** Thẻ bị bỏ hẳn (giữ nội dung bên trong): thẻ khung tài liệu không được nằm trong thân chương. */
    private val DROP_TAGS = setOf("html", "head", "body", "title", "meta", "link", "base")
    /** Mở thẻ khoá => HTML ngầm đóng các thẻ giá trị đang mở ở ĐỈNH ngăn xếp (vd `<p>a<p>b`, `<td>1<td>2`, `<tr>..<tr>`). */
    private val AUTO_CLOSES = mapOf(
        "p" to setOf("p"), "li" to setOf("li"), "dt" to setOf("dt", "dd"), "dd" to setOf("dt", "dd"), "option" to setOf("option"),
        "td" to setOf("td", "th"), "th" to setOf("td", "th"), "tr" to setOf("td", "th", "tr"),
    )
    private val XML_NAME = Regex("^[A-Za-z_][A-Za-z0-9_.-]*$")
    private val dropBlocks = Regex("<(script|style|noscript|iframe|object|title)\\b[\\s\\S]*?</\\1\\s*>", RegexOption.IGNORE_CASE)
    private val comments = Regex("<!--[\\s\\S]*?-->")
    private val ctrlChars = Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F\\uFFFE\\uFFFF]")
    private val bareAmp = Regex("&(?!(?:#[0-9]+|#[xX][0-9a-fA-F]+|[A-Za-z][A-Za-z0-9]*);)")
    private val namedEntity = Regex("&([A-Za-z][A-Za-z0-9]*);")
    private val numericEntity = Regex("&#([0-9]+|[xX][0-9a-fA-F]+);")
    private val XML_ENTITIES = setOf("amp", "lt", "gt", "quot", "apos")
    // Thực thể HTML hay gặp mà XML KHÔNG có (XML chỉ có 5 cái ở trên) => mã số. Thực thể lạ khác => giữ chữ, bỏ ý nghĩa ("&amp;name;").
    private val HTML_ENTITIES = mapOf(
        "nbsp" to 160, "iexcl" to 161, "cent" to 162, "pound" to 163, "yen" to 165, "sect" to 167, "copy" to 169, "laquo" to 171, "reg" to 174, "deg" to 176, "plusmn" to 177,
        "micro" to 181, "para" to 182, "middot" to 183, "raquo" to 187, "frac12" to 189, "times" to 215, "divide" to 247, "ndash" to 8211, "mdash" to 8212, "lsquo" to 8216,
        "rsquo" to 8217, "sbquo" to 8218, "ldquo" to 8220, "rdquo" to 8221, "bdquo" to 8222, "dagger" to 8224, "bull" to 8226, "hellip" to 8230, "permil" to 8240, "prime" to 8242,
        "euro" to 8364, "trade" to 8482, "larr" to 8592, "rarr" to 8594, "hearts" to 9829, "ensp" to 8194, "emsp" to 8195, "thinsp" to 8201, "zwnj" to 8204, "zwj" to 8205,
        "shy" to 173, "acute" to 180, "cedil" to 184, "ordf" to 170, "ordm" to 186, "not" to 172, "macr" to 175, "sup2" to 178, "sup3" to 179, "frac14" to 188, "frac34" to 190,
    )

    /**
     * HTML (kiểu `innerHTML`, có thể bị người dùng/regex làm hỏng) => đoạn XHTML LUÔN là XML hợp lệ. Bản 7.104 viết lại bằng bộ tách thẻ + ngăn xếp (bản regex cũ chỉ đóng thẻ rỗng và sửa thực thể
     * nên vẫn sinh XML hỏng với `<` trần, thuộc tính không nháy/không giá trị, tên thuộc tính của Vue/Angular như `@click` `:class`, thẻ đóng lệch/thừa...). Một chương hỏng làm trình đọc
     * nghiêm ngặt từ chối CẢ cuốn, nên hàm này phải "ép" về hợp lệ thay vì tin dữ liệu.
     *
     * Việc làm: bỏ script/style/noscript/iframe/object + comment + doctype + ký tự điều khiển; thẻ viết thường; thuộc tính: tên hợp lệ XML (bỏ tên lạ, bỏ `on*`, bỏ có `:` trừ xml:lang), luôn có
     * nháy kép, bỏ trùng, thuộc tính không giá trị => `ten="ten"`; ảnh luôn có `alt`; thẻ rỗng đóng `<br/>`; thẻ đóng thừa bị bỏ, thẻ đóng lệch đóng luôn thẻ con, cuối chuỗi đóng nốt thẻ còn mở;
     * `<` không mở thẻ => `&lt;`; thực thể HTML => mã số; `&` trần => `&amp;`; mã số ngoài miền XML bị bỏ.
     */
    fun xhtmlFix(html: String): String {
        var s = dropBlocks.replace(html, "")
        s = comments.replace(s, "")
        s = ctrlChars.replace(s, "")
        val out = StringBuilder(s.length + 64)
        val stack = ArrayList<String>()
        val n = s.length
        var i = 0
        while (i < n) {
            val c = s[i]
            if (c != '<') {
                var j = i
                while (j < n && s[j] != '<') j++
                out.append(fixText(s.substring(i, j)))
                i = j
                continue
            }
            val next = if (i + 1 < n) s[i + 1] else ' '
            when {
                next == '!' || next == '?' -> { val e = s.indexOf('>', i); i = if (e < 0) n else e + 1 }          // doctype, <?xml?>, CDATA: bỏ
                next == '/' && i + 2 < n && s[i + 2].isLetter() -> {
                    var j = i + 2
                    while (j < n && s[j] != '>' && !s[j].isWhitespace()) j++
                    val name = s.substring(i + 2, j).lowercase()
                    val e = s.indexOf('>', j); i = if (e < 0) n else e + 1
                    val at = stack.lastIndexOf(name)
                    if (at >= 0) { while (stack.size > at) out.append("</").append(stack.removeAt(stack.size - 1)).append('>') }
                    // không có thẻ mở tương ứng, hoặc là thẻ bị bỏ/thẻ rỗng => bỏ qua
                }
                next.isLetter() -> {
                    var j = i + 1
                    while (j < n && (s[j].isLetterOrDigit() || s[j] == ':' || s[j] == '-' || s[j] == '_' || s[j] == '.')) j++
                    val rawName = s.substring(i + 1, j)
                    val name = rawName.lowercase()
                    val attrs = LinkedHashMap<String, String>()
                    var selfClose = false
                    var closed = false
                    val keepCase = stack.contains("svg") || name == "svg"
                    while (j < n && !closed) {
                        while (j < n && s[j].isWhitespace()) j++
                        if (j >= n) break
                        when (s[j]) {
                            '>' -> { j++; closed = true }
                            '/' -> { if (j + 1 < n && s[j + 1] == '>') { selfClose = true; j += 2; closed = true } else j++ }
                            else -> {
                                val ns = j
                                while (j < n && !s[j].isWhitespace() && s[j] != '=' && s[j] != '>' && !(s[j] == '/' && j + 1 < n && s[j + 1] == '>')) j++
                                val an = s.substring(ns, j)
                                var k = j
                                while (k < n && s[k].isWhitespace()) k++
                                var value: String? = null
                                if (k < n && s[k] == '=') {
                                    k++
                                    while (k < n && s[k].isWhitespace()) k++
                                    if (k < n && (s[k] == '"' || s[k] == '\'')) {
                                        val q = s[k]; val e = s.indexOf(q, k + 1)
                                        if (e < 0) { value = s.substring(k + 1); k = n } else { value = s.substring(k + 1, e); k = e + 1 }
                                    } else {
                                        val vs = k
                                        while (k < n && !s[k].isWhitespace() && s[k] != '>') k++
                                        value = s.substring(vs, k)
                                        if (value.endsWith("/") && k < n && s[k] == '>') { value = value.dropLast(1); selfClose = true }
                                    }
                                    j = k
                                }
                                val key = if (keepCase) an else an.lowercase()
                                val okName = XML_NAME.matches(key) || key == "xml:lang"
                                if (okName && !key.startsWith("on", ignoreCase = true) && !attrs.containsKey(key)) {
                                    attrs[key] = attrValue(value ?: key)
                                }
                            }
                        }
                    }
                    i = j
                    if (name.contains(':') || name in DROP_TAGS) continue
                    AUTO_CLOSES[name]?.let { closes -> while (stack.isNotEmpty() && stack.last() in closes) out.append("</").append(stack.removeAt(stack.size - 1)).append('>') }
                    if (name == "img" && !attrs.containsKey("alt")) attrs["alt"] = ""
                    out.append('<').append(name)
                    attrs.forEach { (k, v) -> out.append(' ').append(k).append("=\"").append(v).append('"') }
                    if (name in VOID_TAGS) out.append("/>")
                    else if (selfClose) out.append("></").append(name).append('>')
                    else { out.append('>'); stack.add(name) }
                }
                else -> { out.append("&lt;"); i++ }
            }
        }
        while (stack.isNotEmpty()) out.append("</").append(stack.removeAt(stack.size - 1)).append('>')
        return out.toString()
    }

    /** Văn bản (ngoài thẻ) => XML hợp lệ: `&` trần, thực thể HTML, mã số ngoài miền XML, `>` giữ nguyên (hợp lệ), `<` đã bị tách ra ở trên. */
    private fun fixText(t: String): String {
        var s = bareAmp.replace(t, "&amp;")
        s = namedEntity.replace(s) { m ->
            val name = m.groupValues[1]
            when {
                name in XML_ENTITIES -> m.value
                HTML_ENTITIES.containsKey(name) -> "&#" + HTML_ENTITIES[name] + ";"
                else -> "&amp;$name;"
            }
        }
        s = numericEntity.replace(s) { m ->
            val g = m.groupValues[1]
            val cp = (if (g[0] == 'x' || g[0] == 'X') g.substring(1).toLongOrNull(16) else g.toLongOrNull()) ?: -1L
            val ok = cp == 9L || cp == 10L || cp == 13L || cp in 0x20L..0xD7FFL || cp in 0xE000L..0xFFFDL || cp in 0x10000L..0x10FFFFL
            if (ok) m.value else ""
        }
        return s.replace(">", "&gt;")   // `]]>` trần trong nội dung là lỗi XML; escape mọi `>` cho an toàn
    }

    /** Giá trị thuộc tính: như [fixText] + escape `<` và `"` (luôn bọc nháy kép). */
    private fun attrValue(v: String): String = fixText(v).replace("<", "&lt;").replace("\"", "&quot;")

    fun escapeXml(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

    fun statusLabel(status: String, raw: String = ""): String = when (status) {
        "ongoing" -> "Đang ra"; "completed" -> "Hoàn thành"; "hiatus" -> "Tạm ngưng"; "dropped" -> "Ngừng/bỏ dở"
        else -> raw
    }

    private fun num(d: Double): String = if (d == Math.floor(d) && !d.isInfinite()) d.toLong().toString() else String.format(Locale.US, "%.2f", d).trimEnd('0').trimEnd('.')

    fun ratingText(story: StoryMeta): String {
        val r = story.rating ?: return ""
        return num(r.value) + "/" + num(r.scale) + (if (r.count != null) " (${r.count} lượt)" else "")
    }

    /** Số "từ" xấp xỉ (tách theo khoảng trắng — đúng cho tiếng Việt/Anh, chỉ là ước lượng cho tiếng Trung/Nhật). */
    fun wordCount(text: String): Int = text.trim().split(Regex("\\s+")).count { it.isNotEmpty() }

    private fun isoNow(nowMs: Long): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(nowMs))

    /** Trang "Giới thiệu" chỉ khi có gì NGOÀI tên truyện (trang nào cũng có h1/title nên chỉ-có-tên không đáng một trang riêng) hoặc có bìa. */
    fun hasInfoPage(story: StoryMeta, cover: LeechImage?): Boolean = !story.copy(title = "").isBlank() || cover != null
    fun bookTitle(job: LeechJob, story: StoryMeta): String = story.title.ifBlank { job.name }

    // ---------------------------------------------------------------- EPUB ----

    fun contentOpf(job: LeechJob, chapters: List<LeechChapter>, story: StoryMeta, cover: LeechImage?, nowMs: Long): String {
        val iso = isoNow(nowMs)
        val date = story.publishedAt.takeIf { Regex("^\\d{4}-\\d{2}-\\d{2}").containsMatchIn(it) }?.substring(0, 10) ?: iso.substring(0, 10)
        val lang = story.language.ifBlank { "vi" }
        val sb = StringBuilder()
        sb.append(DECL)
        sb.append("<package version=\"3.0\" xmlns=\"http://www.idpf.org/2007/opf\" unique-identifier=\"uid\">\n")
        sb.append("  <metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\">\n")
        sb.append("    <dc:identifier id=\"uid\">${escapeXml(job.id)}</dc:identifier>\n")
        sb.append("    <dc:title>${escapeXml(bookTitle(job, story))}</dc:title>\n")
        if (story.author.isNotBlank()) {
            sb.append("    <dc:creator id=\"creator\">${escapeXml(story.author)}</dc:creator>\n")
            sb.append("    <meta refines=\"#creator\" property=\"role\" scheme=\"marc:relators\">aut</meta>\n")
        }
        if (story.translator.isNotBlank()) {
            sb.append("    <dc:contributor id=\"translator\">${escapeXml(story.translator)}</dc:contributor>\n")
            sb.append("    <meta refines=\"#translator\" property=\"role\" scheme=\"marc:relators\">trl</meta>\n")
        }
        sb.append("    <dc:language>${escapeXml(lang)}</dc:language>\n")
        if (story.summary.isNotBlank()) sb.append("    <dc:description>${escapeXml(story.summary)}</dc:description>\n")
        (story.genres + story.tags).distinctBy { it.lowercase() }.forEach { sb.append("    <dc:subject>${escapeXml(it)}</dc:subject>\n") }
        if (story.publisher.isNotBlank()) sb.append("    <dc:publisher>${escapeXml(story.publisher)}</dc:publisher>\n")
        if (story.sourceUrl.isNotBlank()) sb.append("    <dc:source>${escapeXml(story.sourceUrl)}</dc:source>\n")
        sb.append("    <dc:date>$date</dc:date>\n")
        sb.append("    <meta property=\"dcterms:modified\">$iso</meta>\n")
        if (story.series.isNotBlank()) {
            sb.append("    <meta property=\"belongs-to-collection\" id=\"series\">${escapeXml(story.series)}</meta>\n")
            sb.append("    <meta refines=\"#series\" property=\"collection-type\">series</meta>\n")
            if (story.seriesIndex != null) sb.append("    <meta refines=\"#series\" property=\"group-position\">${num(story.seriesIndex)}</meta>\n")
            sb.append("    <meta name=\"calibre:series\" content=\"${escapeXml(story.series)}\"/>\n")
            if (story.seriesIndex != null) sb.append("    <meta name=\"calibre:series_index\" content=\"${num(story.seriesIndex)}\"/>\n")
        }
        val r = story.rating
        if (r != null && r.scale > 0.0) sb.append("    <meta name=\"calibre:rating\" content=\"${Math.round(r.value / r.scale * 10.0).coerceIn(0L, 10L)}\"/>\n")
        if (story.status.isNotBlank()) sb.append("    <meta name=\"ebookleech:status\" content=\"${escapeXml(story.status)}\"/>\n")
        if (r != null) sb.append("    <meta name=\"ebookleech:rating\" content=\"${escapeXml(ratingText(story))}\"/>\n")
        if (story.updatedAt.isNotBlank()) sb.append("    <meta name=\"ebookleech:updated\" content=\"${escapeXml(story.updatedAt)}\"/>\n")
        if (story.altTitles.isNotEmpty()) sb.append("    <meta name=\"ebookleech:alt_titles\" content=\"${escapeXml(story.altTitles.joinToString(" | "))}\"/>\n")
        if (cover != null) sb.append("    <meta name=\"cover\" content=\"cover-image\"/>\n")
        sb.append("  </metadata>\n  <manifest>\n")
        sb.append("    <item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" properties=\"nav\"/>\n")
        sb.append("    <item id=\"ncx\" href=\"toc.ncx\" media-type=\"application/x-dtbncx+xml\"/>\n")
        sb.append("    <item id=\"css\" href=\"css/style.css\" media-type=\"text/css\"/>\n")
        val info = hasInfoPage(story, cover)
        if (info) sb.append("    <item id=\"info\" href=\"info.xhtml\" media-type=\"application/xhtml+xml\"/>\n")
        if (cover != null) sb.append("    <item id=\"cover-image\" href=\"images/${escapeXml(cover.localFileName)}\" media-type=\"${escapeXml(cover.mimeType)}\" properties=\"cover-image\"/>\n")
        chapters.forEach { sb.append("    <item id=\"chapter_${it.index}\" href=\"chapter_${it.index}.xhtml\" media-type=\"application/xhtml+xml\"/>\n") }
        chapters.flatMap { it.images }.distinctBy { it.localFileName }.forEach {
            sb.append("    <item id=\"img_${it.localFileName.replace(".", "_")}\" href=\"images/${escapeXml(it.localFileName)}\" media-type=\"${escapeXml(it.mimeType)}\"/>\n")
        }
        sb.append("  </manifest>\n  <spine toc=\"ncx\">\n")
        if (info) sb.append("    <itemref idref=\"info\"/>\n")
        chapters.forEach { sb.append("    <itemref idref=\"chapter_${it.index}\"/>\n") }
        sb.append("  </spine>\n</package>\n")
        return sb.toString()
    }

    /** Trang "Giới thiệu" đầu sách: bìa, tên, các dòng thông tin, tóm tắt. */
    fun infoPageXhtml(job: LeechJob, story: StoryMeta, cover: LeechImage?): String {
        val rows = ArrayList<Pair<String, String>>()
        fun row(k: String, v: String) { if (v.isNotBlank()) rows.add(k to v) }
        row("Tác giả", story.author); row("Người dịch", story.translator)
        row("Thể loại", story.genres.joinToString(", ")); row("Từ khoá", story.tags.joinToString(", "))
        row("Tình trạng", statusLabel(story.status, story.statusText)); row("Đánh giá", ratingText(story))
        row("Tên khác", story.altTitles.joinToString(" / ")); row("Bộ truyện", story.series + (if (story.seriesIndex != null && story.series.isNotBlank()) " #" + num(story.seriesIndex) else ""))
        row("Đăng", story.publishedAt); row("Cập nhật", story.updatedAt); row("Nguồn", story.sourceUrl)
        val sb = StringBuilder()
        sb.append(DECL).append("<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\">\n<head>\n  <title>Giới thiệu</title>\n")
        sb.append("  <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\"/>\n</head>\n<body>\n")
        if (cover != null) sb.append("  <p class=\"cover\"><img src=\"images/${escapeXml(cover.localFileName)}\" alt=\"Bìa\"/></p>\n")
        sb.append("  <h1>${escapeXml(bookTitle(job, story))}</h1>\n")
        if (rows.isNotEmpty()) {
            sb.append("  <dl class=\"info\">\n")
            rows.forEach { (k, v) -> sb.append("    <dt>${escapeXml(k)}</dt><dd>${escapeXml(v)}</dd>\n") }
            sb.append("  </dl>\n")
        }
        if (story.summary.isNotBlank()) {
            sb.append("  <h2>Giới thiệu</h2>\n")
            story.summary.split('\n').map { it.trim() }.filter { it.isNotEmpty() }.forEach { sb.append("  <p>${escapeXml(it)}</p>\n") }
        }
        sb.append("</body>\n</html>\n")
        return sb.toString()
    }

    fun chapterXhtml(ch: LeechChapter): String =
        DECL + "<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n  <title>${escapeXml(ch.title)}</title>\n" +
            "  <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\"/>\n</head>\n<body>\n  <h2>${escapeXml(ch.title)}</h2>\n  ${xhtmlFix(ch.htmlContent)}\n</body>\n</html>\n"

    fun epubCss(): String = """
body { font-family: Georgia, serif; line-height: 1.8; margin: 1em 1.5em; color: #222; }
h1 { font-size: 1.6em; text-align: center; margin: 0.6em 0; }
h2 { font-size: 1.3em; border-bottom: 1px solid #ccc; padding-bottom: 0.3em; margin-bottom: 1em; }
p { margin: 0 0 0.8em 0; text-indent: 1.5em; }
img { max-width: 100%; }
p.cover { text-align: center; text-indent: 0; }
dl.info { margin: 1em 0; }
dl.info dt { font-weight: bold; float: left; clear: left; width: 7em; }
dl.info dd { margin: 0 0 0.3em 7.5em; }
""".trimStart()

    fun tocNcx(job: LeechJob, story: StoryMeta, toc: List<TocNode>, withInfo: Boolean): String {
        val counter = intArrayOf(1)
        val head = if (withInfo) {
            val o = counter[0]++
            "    <navPoint id=\"np_info\" playOrder=\"$o\">\n      <navLabel><text>Giới thiệu</text></navLabel>\n      <content src=\"info.xhtml\"/>\n    </navPoint>\n"
        } else ""
        val points = renderNcxNavPoints(toc, counter)
        return DECL + "<ncx version=\"2005-1\" xmlns=\"http://www.daisy.org/z3986/2005/ncx/\">\n  <head>\n    <meta name=\"dtb:uid\" content=\"${escapeXml(job.id)}\"/>\n" +
            "    <meta name=\"dtb:depth\" content=\"${tocDepth(toc)}\"/>\n    <meta name=\"dtb:totalPageCount\" content=\"0\"/>\n    <meta name=\"dtb:maxPageNumber\" content=\"0\"/>\n  </head>\n" +
            "  <docTitle><text>${escapeXml(bookTitle(job, story))}</text></docTitle>\n  <navMap>\n$head$points\n  </navMap>\n</ncx>\n"
    }

    private fun renderNcxNavPoints(nodes: List<TocNode>, counter: IntArray): String = nodes.joinToString("\n") { node ->
        val order = counter[0]++
        if (node.chapterIndex != null) {
            "    <navPoint id=\"np_${escapeXml(node.id)}\" playOrder=\"$order\">\n      <navLabel><text>${escapeXml(node.label)}</text></navLabel>\n      <content src=\"chapter_${node.chapterIndex}.xhtml\"/>\n    </navPoint>"
        } else {
            // Node nhóm (Volume): trỏ content vào chương đầu tiên bên trong để reader không lỗi khi bấm vào tên Volume.
            val firstLeaf = TocNode.flattenChapterOrder(listOf(node)).firstOrNull()
            val children = renderNcxNavPoints(node.children, counter)
            "    <navPoint id=\"np_${escapeXml(node.id)}\" playOrder=\"$order\">\n      <navLabel><text>${escapeXml(node.label)}</text></navLabel>\n" +
                "      <content src=\"${if (firstLeaf != null) "chapter_$firstLeaf.xhtml" else "nav.xhtml"}\"/>\n$children\n    </navPoint>"
        }
    }

    private fun tocDepth(nodes: List<TocNode>, current: Int = 1): Int {
        val childDepths = nodes.filter { it.children.isNotEmpty() }.map { tocDepth(it.children, current + 1) }
        return (childDepths + current).max()
    }

    fun navXhtml(job: LeechJob, story: StoryMeta, toc: List<TocNode>, withInfo: Boolean): String =
        DECL + "<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\">\n<head><title>Mục lục</title></head>\n<body>\n" +
            "  <nav epub:type=\"toc\">\n    <h1>${escapeXml(bookTitle(job, story))} — Mục lục</h1>\n    <ol>\n" +
            (if (withInfo) "      <li><a href=\"info.xhtml\">Giới thiệu</a></li>\n" else "") + "      ${renderNavItems(toc)}\n    </ol>\n  </nav>\n</body>\n</html>\n"

    private fun renderNavItems(nodes: List<TocNode>): String = nodes.joinToString("\n      ") { node ->
        if (node.chapterIndex != null) "<li><a href=\"chapter_${node.chapterIndex}.xhtml\">${escapeXml(node.label)}</a></li>"
        else "<li><span>${escapeXml(node.label)}</span><ol>${renderNavItems(node.children)}</ol></li>"
    }

    /** Toàn bộ mục (đường dẫn trong zip, bytes) của EPUB, KHÔNG gồm `mimetype` (do [writeEpub] ghi đầu tiên, không nén). */
    fun epubEntries(job: LeechJob, chapters: List<LeechChapter>, toc: List<TocNode>, story: StoryMeta, cover: LeechImage?, nowMs: Long): List<Pair<String, ByteArray>> {
        val out = ArrayList<Pair<String, ByteArray>>()
        fun add(path: String, text: String) { out.add(path to text.toByteArray(Charsets.UTF_8)) }
        val info = hasInfoPage(story, cover)
        add("META-INF/container.xml", DECL + "<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\">\n  <rootfiles>\n" +
            "    <rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/>\n  </rootfiles>\n</container>\n")
        add("OEBPS/content.opf", contentOpf(job, chapters, story, cover, nowMs))
        add("OEBPS/toc.ncx", tocNcx(job, story, toc, info))
        add("OEBPS/nav.xhtml", navXhtml(job, story, toc, info))
        add("OEBPS/css/style.css", epubCss())
        if (info) add("OEBPS/info.xhtml", infoPageXhtml(job, story, cover))
        if (cover != null) out.add("OEBPS/images/${cover.localFileName}" to cover.bytes)
        chapters.forEach { add("OEBPS/chapter_${it.index}.xhtml", chapterXhtml(it)) }
        val written = HashSet<String>()
        chapters.forEach { ch -> ch.images.forEach { img -> if (written.add(img.localFileName)) out.add("OEBPS/images/${img.localFileName}" to img.bytes) } }
        return out
    }

    fun writeEpub(out: OutputStream, entries: List<Pair<String, ByteArray>>) {
        ZipOutputStream(out).use { zip ->
            val mime = "application/epub+zip".toByteArray(Charsets.US_ASCII)
            zip.putNextEntry(ZipEntry("mimetype").apply { method = ZipEntry.STORED; size = mime.size.toLong(); compressedSize = mime.size.toLong(); crc = CRC32().also { it.update(mime) }.value })
            zip.write(mime); zip.closeEntry()
            entries.forEach { (path, bytes) -> zip.putNextEntry(ZipEntry(path)); zip.write(bytes); zip.closeEntry() }
        }
    }

    // ----------------------------------------------------------- TXT / HTML ----

    fun infoLines(job: LeechJob, story: StoryMeta): List<Pair<String, String>> {
        val rows = ArrayList<Pair<String, String>>()
        fun row(k: String, v: String) { if (v.isNotBlank()) rows.add(k to v) }
        row("Tác giả", story.author); row("Người dịch", story.translator); row("Thể loại", story.genres.joinToString(", ")); row("Từ khoá", story.tags.joinToString(", "))
        row("Tình trạng", statusLabel(story.status, story.statusText)); row("Đánh giá", ratingText(story)); row("Cập nhật", story.updatedAt); row("Nguồn", story.sourceUrl)
        return rows
    }

    /**
     * Dòng thông tin ở đầu TXT/HTML. Cùng luật với trang Giới thiệu của EPUB: chỉ có TÊN (+ nguồn/ngôn ngữ, trang nào cũng có) thì KHÔNG thêm dòng nào — đầu file giữ như bản cũ;
     * có thêm tác giả/thể loại/tóm tắt/... thì mới liệt kê (kèm "Nguồn").
     */
    private fun headerRows(job: LeechJob, story: StoryMeta): List<Pair<String, String>> =
        if (story.copy(title = "").isBlank()) emptyList() else infoLines(job, story)

    fun txtHeader(job: LeechJob, story: StoryMeta): String {
        val sb = StringBuilder()
        sb.append(bookTitle(job, story)).append('\n').append("=".repeat(60)).append('\n')
        headerRows(job, story).forEach { (k, v) -> sb.append(k).append(": ").append(v).append('\n') }
        if (story.summary.isNotBlank()) sb.append('\n').append("Giới thiệu:\n").append(story.summary).append('\n')
        sb.append('\n')
        return sb.toString()
    }

    /** Phần đầu trang HTML đơn (sau `<body>`): bìa, tên, bảng thông tin, tóm tắt. `coverHref` = đường dẫn tương đối tới ảnh bìa (rỗng = không có). */
    fun htmlHeader(job: LeechJob, story: StoryMeta, coverHref: String): String {
        val sb = StringBuilder()
        if (coverHref.isNotBlank()) sb.append("  <p style=\"text-align:center\"><img src=\"${escapeXml(coverHref)}\" alt=\"Bìa\" style=\"max-width:240px\"></p>\n")
        sb.append("  <h1>${escapeXml(bookTitle(job, story))}</h1>\n")
        val rows = headerRows(job, story)
        if (rows.isNotEmpty()) sb.append("  <ul class=\"story-info\">\n").append(rows.joinToString("") { (k, v) -> "    <li><b>${escapeXml(k)}:</b> ${escapeXml(v)}</li>\n" }).append("  </ul>\n")
        if (story.summary.isNotBlank()) sb.append("  <div class=\"story-summary\">").append(StoryMeta.htmlOf(story.summary)).append("</div>\n")
        return sb.toString()
    }

    // ------------------------------------------------------------ SIDECAR ----

    /**
     * File `<tên ebook>.story.json` — thông tin truyện ở dạng máy đọc được, kèm danh sách chương (số từ, URL gốc, file trong EPUB) và gợi ý ánh xạ sang bài viết web (`webMapping`:
     * tiêu đề, trích đoạn, nội dung giới thiệu, chuyên mục = thể loại, thẻ = tag, ảnh đại diện, trường tuỳ chỉnh) để công cụ đăng bài chỉ việc đọc.
     */
    fun sidecarJson(job: LeechJob, story: StoryMeta, chapters: List<LeechChapter>, mainFileName: String, coverFileName: String, nowMs: Long, generator: String): String {
        val words = chapters.map { wordCount(it.textContent) }
        val root = JSONObject()
        root.put("schema", "ebookleech.story/1")
        root.put("generator", generator)
        root.put("exportedAt", isoNow(nowMs))
        root.put("job", JSONObject().put("id", job.id).put("name", job.name))
        val s = story.toJson()
        s.put("title", bookTitle(job, story))
        root.put("story", s)
        root.put("stats", JSONObject().put("chapterCount", chapters.size).put("wordCount", words.sum()))
        root.put("files", JSONObject().put("ebook", mainFileName).put("cover", coverFileName))
        val arr = JSONArray()
        chapters.forEachIndexed { i, ch ->
            arr.put(JSONObject().put("index", ch.index).put("title", ch.title).put("sourceUrl", ch.sourceUrl).put("wordCount", words[i]).put("file", "chapter_${ch.index}.xhtml"))
        }
        root.put("chapters", arr)
        val excerpt = story.summary.replace(Regex("\\s+"), " ").trim().let { if (it.length > 300) it.substring(0, 297).trimEnd() + "..." else it }
        val meta = JSONObject()
        if (story.author.isNotBlank()) meta.put("author", story.author)
        if (story.translator.isNotBlank()) meta.put("translator", story.translator)
        if (story.status.isNotBlank()) meta.put("status", story.status)
        if (story.rating != null) meta.put("rating", story.rating.toJson())
        if (story.sourceUrl.isNotBlank()) meta.put("source_url", story.sourceUrl)
        if (story.altTitles.isNotEmpty()) meta.put("alt_titles", JSONArray(story.altTitles))
        if (story.series.isNotBlank()) meta.put("series", story.series)
        story.extra.forEach { (k, v) -> meta.put(k, v) }
        root.put("webMapping", JSONObject()
            .put("post_title", bookTitle(job, story)).put("post_excerpt", excerpt).put("post_content", story.summaryHtml.ifBlank { StoryMeta.htmlOf(story.summary) })
            .put("categories", JSONArray(story.genres)).put("tags", JSONArray(story.tags)).put("featured_image", coverFileName).put("meta", meta))
        return root.toString()
    }
}
