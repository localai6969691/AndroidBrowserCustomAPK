package com.colablive.keeper.features.ebookleech.engine

/**
 * Bản 7.104 — QUÉT NHANH DANH SÁCH THEO ĐIỂM NEO. Khối này GIỐNG HỆT `ListScanPlanner` trong `ebookleech/remote_runner/crawler.py` (runner từ xa) và `ld/incremental.py` (LeechDesk) —
 * sửa một nơi phải sửa cả ba; `tools/ebookleech_sim` có bài so khớp chéo (Python sinh kịch bản + kết quả mong đợi, bản Kotlin này chạy lại và phải ra Y HỆT từng trang đã đọc).
 *
 * Ý tưởng (học từ KDN Auto Leech / game "tiếp tục từ chỗ dừng" / Scrapy DeltaFetch — xem TAI_LIEU_KY_THUAT): lần quét trước đã lưu danh sách chương THEO THỨ TỰ (`knownOrder`) và số trang cuối
 * (`hintLastPage`). Chương mới chỉ xuất hiện ở HAI MÉP danh sách:
 *  • ĐẦU danh sách (trang mới nhất đứng đầu — kiểu blog) => đọc từ trang 1 tới trang chứa chương đầu tiên của kho;
 *  • CUỐI danh sách (cũ→mới, chương mới nối vào trang cuối) => nhảy tới trang cuối lần trước (lùi 1 trang làm đệm).
 * Phần giữa (trang toàn chương đã có) KHÔNG đọc lại — nhưng chương trong đó vẫn giữ đúng thứ tự cũ từ kho. Mọi giả định không khớp (không thấy chương đầu kho, trang nhảy tới không chứa chương
 * nào đã biết, thứ tự đảo lộn, trang trống/bị chặn) => tự lùi về quét tuần tự đầy đủ như trước.
 *
 * Cách dùng: `while (true) { val p = pl.nextPage() ?: break; pl.onPage(p, fetch(p)) }` rồi `pl.result()`. `fetch(p)` trả danh sách URL chương (rỗng nếu trang không có chương) hoặc null
 * nếu trang bị chặn/lỗi. Lớp này THUẦN (không đụng Android) để chạy được trên JVM.
 */
class ListScanPlanner(maxPages: Int, knownOrder: List<String>? = null, hintLastPage: Int = 0, fastRequested: Boolean = false) {

    class Meta(val mode: String, val lastPage: Int, val pagesLoaded: Int, val pagesSkipped: Int, val blocked: Boolean = false)

    /** [inconsistent] = true: kết quả nhanh không đáng tin, người gọi phải quét lại ĐẦY ĐỦ (bộ lập kế hoạch mới với fast=false). */
    class Result(val links: List<String>, val meta: Meta, val inconsistent: Boolean)

    private enum class Phase { TOP, PROBE, BOTTOM }

    private val maxPages: Int = maxOf(1, maxPages)
    private val known = ArrayList<String>()
    private val pos = HashMap<String, Int>()
    private val hint: Int = hintLastPage
    /** Đang ở chế độ nhanh (có thể bị hạ xuống false giữa chừng khi giả định sai). */
    var fast: Boolean = false
        private set
    private var phase = Phase.TOP
    private var page = 1
    private var probe = 0
    private var probeSteps = 0
    private var topEnd = 0
    private var skippedPages = 0
    private val scanned = ArrayList<String>()
    private val scannedSet = HashSet<String>()
    private val top = ArrayList<String>()
    private val bottom = ArrayList<String>()
    private var loaded = 0
    private var lastPage = 0
    private var done = false
    private var blocked = false
    var fellBack: Boolean = false
        private set

    init {
        for (u in knownOrder.orEmpty()) {
            if (u.isNotEmpty() && !pos.containsKey(u)) { pos[u] = known.size; known.add(u) }
        }
        fast = fastRequested && known.isNotEmpty() && hint >= 1
    }

    /** Trang cần đọc tiếp theo; null = xong. */
    fun nextPage(): Int? = if (done) null else if (phase == Phase.PROBE) probe else page

    /** Số trang đã đọc (kể cả trang lỗi). */
    val pagesLoaded: Int get() = loaded

    private fun add(links: List<String>, p: Int, bucket: MutableList<String>): List<String> {
        val fresh = ArrayList<String>()
        for (u in links) if (scannedSet.add(u)) { scanned.add(u); fresh.add(u) }
        bucket.addAll(fresh)
        if (fresh.isNotEmpty()) lastPage = maxOf(lastPage, p)   // trang cuối CÓ chương mới (site trả lại trang cuối cho trang quá cuối không làm "dài" danh sách)
        return fresh
    }

    fun onPage(p: Int, rawLinks: List<String>?) {
        loaded++
        if (rawLinks == null) { blocked = true; done = true; return }
        val links = rawLinks.filter { it.isNotEmpty() }
        if (phase == Phase.PROBE) { onProbe(p, links); return }
        val fresh = add(links, p, if (phase == Phase.TOP) top else bottom)
        if (fresh.isEmpty()) { done = true; return }          // trang không còn link mới => hết danh sách (đúng luật cũ)
        if (p >= maxPages) { done = true; return }
        if (phase == Phase.TOP && fast) {
            if (links.contains(known[0])) {
                topEnd = p
                val start = maxOf(p + 1, minOf(hint - 1, maxPages))
                if (start <= p + 1) { phase = Phase.BOTTOM; page = p + 1 }
                else { phase = Phase.PROBE; probe = start; probeSteps = 0 }
                return
            }
            if (p + 1 >= hint - 1) {
                // đã đọc tới vùng cuối của lần trước mà vẫn chưa thấy chương đầu kho => giả định sai, quét đầy đủ
                fast = false
                fellBack = true
            }
        }
        page = p + 1
    }

    private fun onProbe(p: Int, links: List<String>) {
        if (links.any { pos.containsKey(it) }) {
            skippedPages = p - topEnd - 1
            add(links, p, bottom)
            phase = Phase.BOTTOM
            page = p + 1
            if (p >= maxPages) done = true
            return
        }
        // trang trống / toàn chương lạ => lùi (tối đa 3 lần), không neo được thì quét tuần tự từ sau phần đầu
        probeSteps++
        val nxt = p - 1
        if (nxt <= topEnd || probeSteps > 3) {
            phase = Phase.BOTTOM
            page = topEnd + 1
            fellBack = true
        } else probe = nxt
    }

    private fun kept(afterPos: Int): List<String> =
        if (afterPos + 1 >= known.size) emptyList() else known.subList(afterPos + 1, known.size).filter { it !in scannedSet }

    fun result(): Result {
        val skipped = fast && skippedPages > 0
        var mode = if (skipped) "fast" else "full"
        val topPos = top.mapNotNull { pos[it] }
        val botPos = bottom.mapNotNull { pos[it] }
        if (blocked && known.isNotEmpty()) {
            // trang danh sách bị chặn giữa chừng (cả khi quét đầy đủ): GIỮ phần kho chưa quét thay vì để mất khỏi ebook
            val lo = topPos.maxOrNull() ?: -1
            val middle: List<String>
            val tail: List<String>
            if (botPos.isNotEmpty() && botPos.min() > lo) {
                middle = known.subList(lo + 1, botPos.min()).filter { it !in scannedSet }
                tail = kept(botPos.max())
            } else {
                middle = kept(lo)
                tail = emptyList()
            }
            mode = if (fast) "fast" else "full"
            return Result(dedupe(top + middle + bottom + tail), Meta(mode, lastPage, loaded, if (skipped) skippedPages else 0, blocked = true), false)
        }
        val meta = Meta(mode, lastPage, loaded, if (skipped) skippedPages else 0)
        if (!skipped) return Result(ArrayList(scanned), meta, false)
        if (topPos.isEmpty() || botPos.isEmpty()) return Result(emptyList(), meta, true)
        val lo = topPos.max()
        val hi = botPos.min()
        if (hi <= lo) return Result(emptyList(), meta, true)
        val middle = known.subList(lo + 1, hi).filter { it !in scannedSet }
        return Result(dedupe(top + middle + bottom), meta, false)
    }

    private fun dedupe(seq: List<String>): List<String> {
        val seen = HashSet<String>()
        val out = ArrayList<String>()
        for (u in seq) if (seen.add(u)) out.add(u)
        return out
    }

    companion object {
        /** Sau chừng đó lần quét nhanh liên tiếp, lần kế tiếp quét ĐẦY ĐỦ (bắt chương chèn/đổi tên ở giữa). */
        const val FAST_SCAN_MAX_STREAK = 10

        /**
         * Chạy trọn một lần quét ĐỒNG BỘ với [fetch]; tự quét lại ĐẦY ĐỦ nếu kết quả nhanh không nhất quán (như `run_list_scan` bên Python). Dùng cho kiểm thử JVM; crawler thật chạy
         * từng trang bất đồng bộ trên luồng chính nên tự điều khiển [ListScanPlanner] (xem EbookLeechCrawler.stepPlannedScan).
         */
        fun run(fetch: (Int) -> List<String>?, maxPages: Int, knownOrder: List<String>?, hintLastPage: Int, fast: Boolean): Result {
            var last: Result? = null
            for (attemptFast in if (fast) listOf(true, false) else listOf(false)) {
                val pl = ListScanPlanner(maxPages, knownOrder, hintLastPage, attemptFast)
                while (true) { val p = pl.nextPage() ?: break; pl.onPage(p, fetch(p)) }
                val r = pl.result()
                last = r
                if (!r.inconsistent) return r
            }
            return last!!
        }
    }
}
