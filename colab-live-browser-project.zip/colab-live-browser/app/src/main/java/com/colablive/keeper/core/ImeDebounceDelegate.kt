package com.colablive.keeper.core

import android.os.Handler
import android.os.Looper
import android.view.inputmethod.CursorAnchorInfo
import android.view.inputmethod.ExtractedText
import android.view.inputmethod.ExtractedTextRequest
import org.mozilla.geckoview.GeckoSession

/**
 * Mục 113 — chống CHỚP bàn phím (hiện/ẩn/hiện liên tục) khi focus chuyển giữa các ô nhập (vd các ô code Monaco của Colab).
 *
 * Căn cứ tra cứu (xem PROJECT_STATUS.md mục 113):
 *  - Log 06:55 cho thấy `imeVisible` đổi true/false/true và imeBottom 949/1046/0 liên tục quanh mỗi lần nhấn giữ. Mỗi lần
 *    đổi là một lần co/giãn khung GeckoView (padding root theo IME) nên trang nhảy.
 *  - GeckoView gọi `TextInputDelegate.hideSoftInput` ngay khi ô nhập cũ mất focus, rồi `showSoftInput` khi ô mới nhận focus.
 *    Tài liệu GeckoView: nếu app không đặt delegate thì các thao tác này chuyển thẳng cho InputMethodManager (không có đệm nào);
 *    `SessionTextInput.setDelegate` là điểm móc chính thức để app tự quyết.
 *  - Cách chữa: HOÃN lệnh ẩn một khoảng ngắn; nếu trong khoảng đó có lệnh hiện (hoặc `restartInput` do FOCUS) thì HUỶ lệnh ẩn —
 *    bàn phím đứng yên, khung trang không bị co/giãn. Người dùng thật sự đóng bàn phím (bấm ra ngoài, nút Back) chỉ trễ ~300ms.
 *
 * Mọi hàm khác chuyển nguyên cho delegate mặc định của GeckoView (`getDelegate()` trả về bản mặc định khi chưa đặt).
 */
class ImeDebounceDelegate(
    private val base: GeckoSession.TextInputDelegate,
    /** Chỉ hoãn lệnh ẩn khi trả về true (hiện chỉ cho trang Colab). False => hành vi GỐC của GeckoView, không đệm gì. */
    private val shouldDebounce: () -> Boolean = { true },
    /** Mục 116: mốc uptime (ms) tới khi KHÔNG được ẩn bàn phím (đang xử lý nhấn giữ chọn chữ: Gecko ẩn rồi ta tự focus lại sau ~1-2s). */
    private val holdHideUntilUptime: () -> Long = { 0L },
    private val onLog: (String) -> Unit = {}
) : GeckoSession.TextInputDelegate {
    private val handler = Handler(Looper.getMainLooper())
    private var pendingHide: Runnable? = null
    private var suppressedHides = 0

    private fun cancelPendingHide(why: String): Boolean {
        val p = pendingHide ?: return false
        handler.removeCallbacks(p)
        pendingHide = null
        suppressedHides++
        if (suppressedHides <= 5 || suppressedHides % 20 == 0) onLog("IME: huỷ lệnh ẩn bàn phím đang chờ ($why) — đã chặn $suppressedHides lần chớp")
        return true
    }

    override fun hideSoftInput(session: GeckoSession) {
        pendingHide?.let { handler.removeCallbacks(it) }
        pendingHide = null
        // Trang không thuộc diện áp dụng (mọi trang khác Colab): ẩn NGAY như chưa từng có bộ đệm này.
        if (!shouldDebounce()) {
            base.hideSoftInput(session)
            return
        }
        val r = object : Runnable {
            override fun run() {
                val remain = holdHideUntilUptime() - android.os.SystemClock.uptimeMillis()
                if (remain > 0) { handler.postDelayed(this, remain); return } // còn trong cửa sổ giữ bàn phím — hoãn tiếp
                pendingHide = null
                try { base.hideSoftInput(session) } catch (e: Exception) { onLog("IME: hideSoftInput lỗi ${e.message}") }
            }
        }
        pendingHide = r
        handler.postDelayed(r, HIDE_DELAY_MS)
    }

    override fun showSoftInput(session: GeckoSession) {
        cancelPendingHide("có lệnh hiện lại")
        base.showSoftInput(session)
    }

    override fun restartInput(session: GeckoSession, reason: Int) {
        if (reason == GeckoSession.TextInputDelegate.RESTART_REASON_FOCUS) cancelPendingHide("ô nhập mới nhận focus")
        base.restartInput(session, reason)
    }

    override fun updateSelection(session: GeckoSession, selStart: Int, selEnd: Int, compositionStart: Int, compositionEnd: Int) =
        base.updateSelection(session, selStart, selEnd, compositionStart, compositionEnd)

    override fun updateExtractedText(session: GeckoSession, request: ExtractedTextRequest, text: ExtractedText) =
        base.updateExtractedText(session, request, text)

    override fun updateCursorAnchorInfo(session: GeckoSession, info: CursorAnchorInfo) =
        base.updateCursorAnchorInfo(session, info)

    companion object {
        /** Đủ dài để nuốt chớp hide→show khi chuyển ô (quan sát log: vài trăm ms), đủ ngắn để người dùng không thấy trễ khi đóng thật. */
        const val HIDE_DELAY_MS = 300L
    }
}
