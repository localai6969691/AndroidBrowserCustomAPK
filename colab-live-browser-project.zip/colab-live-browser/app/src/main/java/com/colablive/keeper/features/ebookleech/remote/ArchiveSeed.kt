package com.colablive.keeper.features.ebookleech.remote

import org.json.JSONArray
import org.json.JSONObject

/**
 * Bản 7.104 — dựng "kho chương gieo" (`remote-jobs/<id>-archive.json`) từ KHO CỤC BỘ trên điện thoại, để runner từ xa (crawler.py trên GitHub Actions/Colab, hoặc LeechDesk trên PC)
 * BẮT ĐẦU từ những chương điện thoại đã cào xong và chỉ cào phần còn thiếu — "việc đã xong ở máy thì đẩy lên cloud làm điểm bắt đầu cho máy kia nối tiếp".
 * Cùng định dạng mà runner tự ghi khi chạy lần hai (`parse_archive_data` trong crawler.py): `{chaptersSoFar, chapterLinks, listScan, storyMeta}`.
 *
 * THUẦN (chỉ org.json) để kiểm trên JVM (tools/ebookleech_sim). Việc đẩy ảnh/JSON lên GitHub nằm ở RemoteCrawlRunner; mỗi ảnh là MỘT commit nên có hạn mức: chương nào làm vượt hạn mức ảnh
 * (hoặc dung lượng JSON) bị LOẠI khỏi bản gieo — chương đó đơn giản được cào lại ở máy chạy, KHÔNG sai gì cả, chỉ chậm hơn. Chương có ảnh mà file ảnh trong kho đã mất cũng bị loại
 * (nếu gieo thì ebook cuối thiếu ảnh mà runner tưởng là đã đủ).
 */
object ArchiveSeed {
    const val MAX_JSON_BYTES = 12L * 1024 * 1024
    const val MAX_IMAGE_FILES = 150
    const val MAX_IMAGE_BYTES = 30L * 1024 * 1024

    class Seed(val json: String, val imageNames: List<String>, val included: Int, val excluded: Int, val imageBytes: Long)

    /**
     * @param chapters mảng JSON chương của kho cục bộ (dạng `LeechChapter.toJson`, ảnh chỉ có tên file).
     * @param order thứ tự đầy đủ danh sách chương lần quét trước (rỗng => runner suy ra từ thứ tự chương).
     * @param imageSize kích thước (byte) file ảnh theo tên trong kho cục bộ; < 0 = file không còn.
     */
    fun build(
        chapters: JSONArray, order: List<String>, lastPage: Int, fastStreak: Int, storyMeta: JSONObject?, imageSize: (String) -> Long,
        maxJsonBytes: Long = MAX_JSON_BYTES, maxImageFiles: Int = MAX_IMAGE_FILES, maxImageBytes: Long = MAX_IMAGE_BYTES,
    ): Seed {
        val picked = JSONArray()
        val imageNames = LinkedHashSet<String>()
        var imageBytes = 0L
        var jsonBytes = 4096L + order.sumOf { it.length + 4L }
        var excluded = 0
        for (i in 0 until chapters.length()) {
            val ch = chapters.getJSONObject(i)
            if (ch.optString("sourceUrl", "").isBlank()) { excluded++; continue }
            val names = ch.optJSONArray("images")?.let { arr -> (0 until arr.length()).map { arr.getJSONObject(it).optString("localFileName", "") }.filter { it.isNotEmpty() } } ?: emptyList()
            val fresh = names.filter { it !in imageNames }.distinct()
            val sizes = fresh.map { imageSize(it) }
            val size = ch.toString().toByteArray(Charsets.UTF_8).size.toLong()
            val ok = sizes.none { it < 0 } &&
                imageNames.size + fresh.size <= maxImageFiles && imageBytes + sizes.sum() <= maxImageBytes && jsonBytes + size <= maxJsonBytes
            if (!ok) { excluded++; continue }
            picked.put(ch)
            imageNames.addAll(fresh)
            imageBytes += sizes.sum()
            jsonBytes += size
        }
        val root = JSONObject()
        root.put("chaptersSoFar", picked)
        root.put("chapterLinks", JSONArray(order))
        root.put("listScan", JSONObject().put("lastPage", lastPage).put("fastStreak", fastStreak))
        if (storyMeta != null) root.put("storyMeta", storyMeta)
        return Seed(root.toString(), imageNames.toList(), picked.length(), excluded, imageBytes)
    }
}
