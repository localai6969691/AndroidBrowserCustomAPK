package com.colablive.keeper

import android.app.Application
import android.content.Intent
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.CrashBreadcrumb
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.GeckoRuntimeProvider
import com.colablive.keeper.core.ProfileSlots
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LiveBrowserApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // BUG THẬT phát hiện qua log chẩn đoán chính người dùng gửi lại:
        // GeckoView TỰ SINH nhiều tiến trình con để sandbox (":tabN" — mỗi
        // tab nội dung 1 tiến trình riêng, ":gpu", ":media", ":utility",
        // ":crashhelper") — ĐÂY LÀ HÀNH VI BÌNH THƯỜNG của Gecko multi-
        // process, không liên quan gì tới khe (slot) nào cả. Nhưng
        // `Application.onCreate()` CHẠY TRONG MỌI TIẾN TRÌNH mà hệ điều
        // hành sinh ra cho package này — kể cả các tiến trình con này —
        // nên code TRƯỚC ĐÂY (không phân biệt) vẫn gọi
        // `getCurrentSlotIndex()` ở đó, KHÔNG khớp mẫu ":slot1/2/3" nào cả
        // nên luôn rơi về mặc định 0 — GÁN NHẦM mọi tiến trình con của MỌI
        // khe (kể cả khe 1/2/3) thành "Khe 0" trong log, gây nhiễu và có
        // thể khiến người dùng hiểu lầm thêm 1 lớp nữa khi đọc log. Các
        // tiến trình con này không chạy `MainActivity`/bất kỳ UI nào của
        // app — không cần và không nên khởi tạo DebugLog/crash handler ở
        // đây, chỉ cần thoát sớm.
        val rawProcessName = if (android.os.Build.VERSION.SDK_INT >= 28) android.app.Application.getProcessName() else null
        val isGeckoHelperProcess = rawProcessName != null && (
            GECKO_HELPER_PROCESS_SUFFIXES.any { rawProcessName.endsWith(it) } ||
            Regex(":tab\\d+$").containsMatchIn(rawProcessName)
        )
        if (isGeckoHelperProcess) return

        val slotIndex = ProfileSlots.getCurrentSlotIndex(this)
        DebugLog.init(this, slotIndex) // PHẢI gọi trước mọi DebugLog.log() khác trong toàn app — file riêng theo đúng khe (xem chú thích trong DebugLog.kt)
        logPreviousProcessExits() // Mục 125: lý do THẬT khiến tiến trình trước chết (Android ghi lại) — không phụ thuộc exception handler
        // FIX MỚI — kiểm tra breadcrumb (xem CrashBreadcrumb.kt để hiểu đầy
        // đủ cơ chế + lý do). Nếu dòng log "[CHẨN ĐOÁN NATIVE CRASH]" xuất
        // hiện ngay sau dòng "App process start" — XÁC NHẬN CHẮC CHẮN
        // 100% phiên trước đã chết bất thường (khả năng cao native crash,
        // không bắt được bằng try/catch) đúng ngay tại bước được ghi
        // trong breadcrumb, kể cả khi KHÔNG có bất kỳ log lỗi nào khác.
        CrashBreadcrumb.checkAndClearAfterCrash(this)?.let { lastStep ->
            DebugLog.log("[CHẨN ĐOÁN NATIVE CRASH] Phiên TRƯỚC đã chết bất thường (không tắt app bình thường) ngay sau bước: $lastStep — đây là bằng chứng CHẮC CHẮN xác nhận đúng vị trí crash, dùng để tra tiếp nguyên nhân gốc.")
        }
        // CHẨN ĐOÁN TRỰC TIẾP — không suy luận nữa, in ra SỰ THẬT: tên tiến
        // trình THẬT (theo Android báo cáo, không qua trung gian nào) cạnh
        // slotIndex tính được từ nó. Nếu build này VẪN sai khe, dòng log
        // này sẽ lộ ra NGAY LẬP TỨC: hoặc processNameThat không có hậu tố
        // ":slotN" (nghĩa là Android không hề chạy tiến trình riêng — lỗi ở
        // Manifest/hệ thống, không phải ở code parse) hoặc processNameThat
        // ĐÚNG ":slot1" nhưng slotIndex vẫn ra 0 (nghĩa là lỗi nằm trong
        // chính hàm parse `getSlotIndexFromProcess`).
        DebugLog.log("CHẨN ĐOÁN TIẾN TRÌNH: processName_THẬT='$rawProcessName' → slotIndex_tính_được=$slotIndex (SDK=${android.os.Build.VERSION.SDK_INT})")
        applyPendingProfilePromoteIfAny()
        applyPendingReassignIfAny()
        DebugLog.log("App init — slot=$slotIndex, version=${com.colablive.keeper.core.BuildMarker.VERSION}")
        installCrashHandler()
    }

    companion object {
        /** Hậu tố tiến trình con GeckoView tự sinh — KHÔNG phải khe nào,
         * không nên gán slotIndex/ghi DebugLog cho các tiến trình này. */
        private val GECKO_HELPER_PROCESS_SUFFIXES = listOf(":gpu", ":media", ":utility", ":crashhelper", ":socket")
    }

    /**
     * "Đặt tên hồ sơ" (`ProfilePickerActivity.promoteSlotData`) cần đổi tên
     * thư mục Gecko trên đĩa — việc này KHÔNG an toàn nếu làm khi GeckoRuntime
     * của khe đó đang sống (rất có thể, vì hành động này thường bấm từ
     * trong chính khe đang chạy). Nên thay vì đổi ngay, ta LƯU Ý ĐỊNH rồi
     * khởi động lại đúng khe đó — và áp dụng thật ở ĐÂY, chỗ SỚM NHẤT của
     * vòng đời tiến trình MỚI (`Application.onCreate` chạy trước bất kỳ
     * Activity nào, tức trước bất kỳ `GeckoRuntimeProvider.get()` nào),
     * nên tại thời điểm này chắc chắn CHƯA có GeckoRuntime nào được tạo
     * trong tiến trình vừa khởi động — an toàn để đổi tên thư mục.
     */
    private fun applyPendingProfilePromoteIfAny() {
        val pending = ProfileSlots.consumePendingPromoteForCurrentProcess(this) ?: return
        val slot = pending.slot
        val oldNs = pending.oldNs
        val newName = pending.newName
        DebugLog.log("Áp dụng đổi tên hồ sơ đang chờ: khe $slot, '$oldNs' -> '$newName' (thay dữ liệu hồ sơ có sẵn=${pending.replaceExisting})")
        AppPrefs.renameNamespace(this, oldNs, newName)
        GeckoRuntimeProvider.renameProfileDir(this, oldNs, newName, pending.replaceExisting)
        ProfileSlots.addProfile(this, newName)
        ProfileSlots.setSlotAssignment(this, slot, newName)
    }

    /**
     * BUG THẬT đã sửa ("restore profile mất open tabs") — xem giải thích
     * đầy đủ ở `ProfileSlots.schedulePendingReassign()`. Áp dụng CÙNG thời
     * điểm/lý do với `applyPendingProfilePromoteIfAny()` ở trên: sớm nhất
     * có thể trong tiến trình MỚI, TRƯỚC bất kỳ GeckoRuntime/MainActivity
     * nào — đảm bảo tiến trình CŨ (đã đóng, đã lưu tab đúng theo assignment
     * CŨ trước khi bị kill) không còn sống để đọc nhầm assignment MỚI nữa.
     */
    private fun applyPendingReassignIfAny() {
        val pending = ProfileSlots.consumePendingReassignForCurrentProcess(this) ?: return
        val (slot, newName) = pending
        if (newName != null) {
            DebugLog.log("Áp dụng gán hồ sơ đang chờ: khe $slot -> '$newName'")
            ProfileSlots.setSlotAssignment(this, slot, newName)
        } else {
            DebugLog.log("Áp dụng bỏ gán hồ sơ đang chờ: khe $slot")
            ProfileSlots.unassignSlot(this, slot)
        }
    }

    /**
     * Mục 125: người dùng báo "đang dùng mà trình duyệt crash, không hiểu sao", log chỉ thấy "App process start" mới mà KHÔNG có màn hình lỗi Java
     * (CrashReportActivity) => không phải exception JVM. `ActivityManager.getHistoricalProcessExitReasons` (API 30+) cho biết Android ghi nhận tiến trình
     * trước chết vì: CRASH_NATIVE (libxul/Gecko), LOW_MEMORY (bị giết do thiếu RAM), SIGNALED (SIGKILL), ANR, EXCESSIVE_RESOURCE_USAGE, USER_REQUESTED...
     * Mỗi dòng log kèm PSS/RSS lúc chết. Chỉ in các lần thoát MỚI hơn lần đã in (lưu mốc theo tên tiến trình).
     */
    private fun logPreviousProcessExits() {
        if (android.os.Build.VERSION.SDK_INT < 30) return
        try {
            val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
            val myProc = android.app.Application.getProcessName() ?: packageName
            val prefs = getSharedPreferences("exit_info", MODE_PRIVATE)
            val lastTs = prefs.getLong("last_ts_$myProc", 0L)
            var maxTs = lastTs
            val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            val list = am.getHistoricalProcessExitReasons(packageName, 0, 10).filter { it.processName == myProc && it.timestamp > lastTs }.sortedBy { it.timestamp }
            for (info in list) {
                maxTs = maxOf(maxTs, info.timestamp)
                val why = when (info.reason) {
                    android.app.ApplicationExitInfo.REASON_ANR -> "ANR (treo giao diện)"
                    android.app.ApplicationExitInfo.REASON_CRASH -> "CRASH Java (exception)"
                    android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH NATIVE (libxul/Gecko…)"
                    android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> "THIẾU RAM — Android giết tiến trình"
                    android.app.ApplicationExitInfo.REASON_SIGNALED -> "BỊ GIẾT bằng signal ${info.status} (9=SIGKILL: thường là bộ dọn RAM/OEM)"
                    android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "dùng tài nguyên quá mức"
                    android.app.ApplicationExitInfo.REASON_USER_REQUESTED -> "người dùng vuốt tắt/Force stop"
                    android.app.ApplicationExitInfo.REASON_USER_STOPPED -> "người dùng dừng app"
                    android.app.ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "tiến trình phụ thuộc chết"
                    android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "khởi tạo thất bại"
                    android.app.ApplicationExitInfo.REASON_EXIT_SELF -> "tự thoát (System.exit)"
                    android.app.ApplicationExitInfo.REASON_PERMISSION_CHANGE -> "đổi quyền"
                    else -> "khác(${info.reason})"
                }
                DebugLog.log("[THOÁT TIẾN TRÌNH] lúc ${fmt.format(Date(info.timestamp))} process='${info.processName}' pid=${info.pid} LÝ DO=$why " +
                    "status=${info.status} importance=${info.importance} pss=${info.pss / 1024}MB rss=${info.rss / 1024}MB mô tả='${info.description}'")
            }
            if (maxTs > lastTs) prefs.edit().putLong("last_ts_$myProc", maxTs).apply()
        } catch (e: Throwable) {
            DebugLog.log("[THOÁT TIẾN TRÌNH] đọc lịch sử lỗi ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /**
     * Không có máy tính/adb thì không xem được logcat — cái này thay thế 1
     * phần: bắt exception Kotlin/Java chưa xử lý, LƯU RA FILE (sống sót qua
     * crash, xem lại được ở lần mở sau) và MỞ NGAY 1 màn hình hiển thị lỗi
     * (thay cho dialog "App đã dừng" mù thông tin của Android), có nút Sao
     * chép để gửi lại cho người hỗ trợ.
     *
     * ⚠️ GIỚI HẠN THẬT: đây là uncaught exception handler Ở TẦNG JVM
     * (Kotlin/Java) — KHÔNG bắt được crash NATIVE (vd libxul.so của chính
     * Gecko crash ở tầng C++, như rủi ro đã ghi ở GeckoRuntimeProvider về cờ
     * `-profile` chưa xác nhận). Native crash vẫn chỉ hiện dialog hệ thống
     * mù thông tin như cũ — cần logcat/bug report thật mới thấy được loại đó.
     */
    private fun installCrashHandler() {
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try { com.colablive.keeper.core.StartupGuard.onUncaught(this, ProfileSlots.getCurrentSlotIndex(this)) } catch (_: Throwable) {} // 7.93: đếm crash lúc khởi động (chống vòng lặp)
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                val slotIndex = ProfileSlots.getCurrentSlotIndex(this)
                val recentLogs = DebugLog.readFullFile(this, slotIndex).lines().takeLast(60).joinToString("\n")
                val crashText = buildString {
                    append("Crash lúc $time — khe $slotIndex — thread ${thread.name}\n\n")
                    append(sw.toString())
                    append("\n\n--- 60 dòng log gần nhất trước crash (từ file) ---\n")
                    append(recentLogs)
                }
                File(filesDir, "last_crash.txt").writeText(crashText)

                val intent = Intent(applicationContext, CrashReportActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    putExtra("crash_text", crashText)
                    putExtra("slot_index", slotIndex)
                }
                applicationContext.startActivity(intent)
                Thread.sleep(300) // cho hệ thống kịp nhận Intent trước khi tiến trình này chết
            } catch (e: Throwable) {
                // Không để chính crash-handler crash tiếp — im lặng bỏ qua,
                // vẫn còn file last_crash.txt nếu ghi tới được bước đó.
            }
            android.os.Process.killProcess(android.os.Process.myPid())
            kotlin.system.exitProcess(1)
        }
    }
}
