package com.colablive.keeper.core

import org.json.JSONArray
import org.json.JSONObject

/**
 * Bản 7.56 — đọc/ghi các định dạng cookie mà Cookie-Editor (và các công cụ tương tự) xuất/nhập:
 *  1) JSON: mảng {name,value,domain,hostOnly,path,secure,httpOnly,sameSite,session,expirationDate,storeId,...}
 *     (cũng nhận {"cookies":[...]} và biến thể EditThisCookie: expirationDate/sameSite "no_restriction"|"lax"|"strict"|"unspecified").
 *  2) Netscape (cookies.txt): 7 cột cách nhau TAB — domain, includeSubdomains, path, secure, expiry, name, value; dòng `#HttpOnly_` đầu domain = HttpOnly.
 *  3) Header string: `a=b; c=d` (không có thuộc tính => cookie phiên, chỉ-host của trang hiện tại).
 */
object CookieFormats {

    data class Ck(
        val name: String, val value: String, val domain: String, val hostOnly: Boolean, val path: String,
        val secure: Boolean, val httpOnly: Boolean, val sameSite: String, val session: Boolean, val expirationDate: Double
    ) {
        fun toJs(): JSONObject = JSONObject().put("name", name).put("value", value).put("domain", domain).put("hostOnly", hostOnly)
            .put("path", path).put("secure", secure).put("httpOnly", httpOnly).put("sameSite", sameSite).put("session", session)
            .put("expirationDate", expirationDate)
    }

    enum class Fmt { JSON, NETSCAPE, HEADER, UNKNOWN }

    fun detect(text: String): Fmt {
        val t = text.trim()
        if (t.startsWith("[") || t.startsWith("{")) return Fmt.JSON
        if (t.lines().any { it.split('\t').size >= 7 }) return Fmt.NETSCAPE
        if (t.contains('=')) return Fmt.HEADER
        return Fmt.UNKNOWN
    }

    /** Trả (định dạng, danh sách). `host` = host trang hiện tại, dùng cho định dạng Header. */
    fun parse(text: String, host: String): Pair<Fmt, List<Ck>> {
        val fmt = detect(text)
        val list = try {
            when (fmt) {
                Fmt.JSON -> parseJson(text.trim())
                Fmt.NETSCAPE -> parseNetscape(text)
                Fmt.HEADER -> parseHeader(text, host)
                Fmt.UNKNOWN -> emptyList()
            }
        } catch (e: Exception) { emptyList() }
        return fmt to list
    }

    private fun parseJson(t: String): List<Ck> {
        val arr: JSONArray = if (t.startsWith("[")) JSONArray(t) else {
            val o = JSONObject(t)
            o.optJSONArray("cookies") ?: JSONArray().put(o)
        }
        val out = ArrayList<Ck>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val name = o.optString("name", ""); if (name.isEmpty()) continue
            val domain = o.optString("domain", "")
            val exp = if (o.has("expirationDate") && !o.isNull("expirationDate")) o.optDouble("expirationDate", 0.0) else 0.0
            val session = if (o.has("session")) o.optBoolean("session", exp <= 0.0) else exp <= 0.0
            val ss = o.optString("sameSite", "").lowercase()
            out.add(Ck(
                name, o.optString("value", ""), domain,
                if (o.has("hostOnly")) o.optBoolean("hostOnly", false) else !domain.startsWith("."),
                o.optString("path", "/").ifEmpty { "/" }, o.optBoolean("secure", false), o.optBoolean("httpOnly", false),
                if (ss == "unspecified" || ss == "no_restriction" || ss == "none" || ss == "lax" || ss == "strict") ss else "", session, exp
            ))
        }
        return out
    }

    private fun parseNetscape(text: String): List<Ck> {
        val out = ArrayList<Ck>()
        for (raw in text.lines()) {
            var line = raw.trimEnd('\r', '\n')
            if (line.isBlank()) continue
            var httpOnly = false
            if (line.startsWith("#HttpOnly_")) { httpOnly = true; line = line.removePrefix("#HttpOnly_") }
            else if (line.startsWith("#")) continue
            val f = line.split('\t')
            if (f.size < 7) continue
            val exp = f[4].trim().toDoubleOrNull() ?: 0.0
            out.add(Ck(f[5], f.drop(6).joinToString("\t"), f[0].trim(), !f[1].trim().equals("TRUE", true), f[2].ifEmpty { "/" },
                f[3].trim().equals("TRUE", true), httpOnly, "", exp <= 0.0, exp))
        }
        return out
    }

    private fun parseHeader(text: String, host: String): List<Ck> {
        val out = ArrayList<Ck>()
        val body = text.trim().removePrefix("Cookie:").removePrefix("cookie:").trim()
        for (p in body.split(';', '\n')) {
            val s = p.trim(); val i = s.indexOf('=')
            if (i <= 0) continue
            out.add(Ck(s.substring(0, i), s.substring(i + 1), host, true, "/", false, false, "", true, 0.0))
        }
        return out
    }

    // ===== Xuất =====
    fun toJson(list: List<Ck>): String {
        val a = JSONArray()
        for (c in list) {
            val o = JSONObject().put("name", c.name).put("value", c.value).put("domain", c.domain).put("hostOnly", c.hostOnly)
                .put("path", c.path).put("secure", c.secure).put("httpOnly", c.httpOnly)
                .put("sameSite", if (c.sameSite.isEmpty()) "unspecified" else c.sameSite).put("session", c.session).put("firstPartyDomain", "")
                .put("partitionKey", JSONObject.NULL).put("storeId", JSONObject.NULL)
            if (!c.session) o.put("expirationDate", c.expirationDate)
            a.put(o)
        }
        return a.toString(2)
    }

    fun toNetscape(list: List<Ck>): String {
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        for (c in list) {
            val dom = if (!c.hostOnly && !c.domain.startsWith(".")) "." + c.domain else c.domain
            sb.append(if (c.httpOnly) "#HttpOnly_" else "").append(dom).append('\t').append(if (c.hostOnly) "FALSE" else "TRUE").append('\t')
                .append(c.path).append('\t').append(if (c.secure) "TRUE" else "FALSE").append('\t')
                .append(if (c.session) 0L else c.expirationDate.toLong()).append('\t').append(c.name).append('\t').append(c.value).append('\n')
        }
        return sb.toString()
    }

    fun toHeader(list: List<Ck>): String = list.joinToString("; ") { it.name + "=" + it.value }
}
