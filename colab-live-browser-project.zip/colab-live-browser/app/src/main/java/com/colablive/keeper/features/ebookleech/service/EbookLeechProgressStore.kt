package com.colablive.keeper.features.ebookleech.service

import java.util.concurrent.ConcurrentHashMap

/**
 * EbookLeechProgressStore — kho tiến độ REAL-TIME trong RAM (không persist).
 *
 * Trước đây tiến độ chỉ ghi vào LeechJobRepository (SharedPreferences JSON),
 * và notification chỉ đọc lại mỗi 30s theo nhịp tickRunnable → cảm giác
 * "đơ", % nhảy cách quãng. Giờ mỗi lần crawler báo onProgress, dữ liệu vào
 * thẳng store này VÀ đẩy ngay cho EbookLeechService cập nhật notification
 * tức thì — không cần chờ tick.
 */
object EbookLeechProgressStore {

    data class Snapshot(
        val jobName: String,
        val phaseLabel: String,       // "Đang quét trang danh sách", "Đang cào chương 12/50"...
        val current: Int,
        val total: Int,               // 0 nếu chưa biết tổng (đang ở Phase 1 dò link)
        val startedAtMs: Long,
        val lastChapterTitle: String = "",
    ) {
        val percent: Int
            get() = if (total <= 0) 0 else ((current * 100f) / total).toInt().coerceIn(0, 100)

        /** Ước lượng thời gian còn lại (giây), null nếu chưa đủ dữ liệu để tính. */
        fun etaSeconds(): Long? {
            if (total <= 0 || current <= 0) return null
            val elapsedMs = System.currentTimeMillis() - startedAtMs
            if (elapsedMs <= 0) return null
            val ratePerMs = current.toDouble() / elapsedMs
            if (ratePerMs <= 0) return null
            val remaining = total - current
            return (remaining / ratePerMs / 1000).toLong().coerceAtLeast(0)
        }
    }

    private val snapshots = ConcurrentHashMap<String, Snapshot>()

    // Listener do EbookLeechService đăng ký khi đang chạy — để đẩy cập nhật
    // notification NGAY khi có progress mới, thay vì chờ vòng lặp 30s.
    @Volatile private var listener: (() -> Unit)? = null

    fun setListener(l: (() -> Unit)?) { listener = l }

    fun key(slotIndex: Int, jobId: String) = "$slotIndex:$jobId"

    fun update(
        slotIndex: Int, jobId: String, jobName: String,
        phaseLabel: String, current: Int, total: Int, lastChapterTitle: String = "",
    ) {
        val k = key(slotIndex, jobId)
        val existing = snapshots[k]
        val startedAt = existing?.startedAtMs ?: System.currentTimeMillis()
        snapshots[k] = Snapshot(jobName, phaseLabel, current, total, startedAt, lastChapterTitle)
        listener?.invoke()
    }

    fun clear(slotIndex: Int, jobId: String) {
        snapshots.remove(key(slotIndex, jobId))
        listener?.invoke()
    }

    fun allActive(): List<Snapshot> = snapshots.values.toList()
}
