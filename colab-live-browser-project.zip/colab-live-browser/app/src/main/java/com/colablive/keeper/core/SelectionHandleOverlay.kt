package com.colablive.keeper.core

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.roundToInt

/**
 * TÍNH NĂNG MỚI (mục 96 — người dùng chỉ đúng nhiều lần: sửa "Dán" không
 * đủ, menu Sao chép/Cắt/Dán VÔ DỤNG nếu không có con trỏ để KÉO CHỈNH
 * vùng chọn — không ai chọn đúng đoạn văn bản muốn thao tác nếu không kéo
 * được điểm đầu/cuối).
 *
 * Vì sao KHÔNG bật lại `layout.accessiblecaret.*` (con trỏ kéo NATIVE của
 * Gecko): mục 81 từng bật, mục 83 xác nhận nó làm MẤT ĐĂNG NHẬP GOOGLE
 * (hồi quy thật, có bằng chứng trực tiếp) — rủi ro cao hơn hẳn lợi ích,
 * giữ nguyên đã tắt.
 *
 * Thay vào đó: tự vẽ 2 "núm kéo" bằng View Android THẬT (qua
 * `WindowManager`, cùng kỹ thuật `TYPE_APPLICATION_PANEL` đã dùng ổn định
 * ở `SelectionFallbackMenu`) — hoàn toàn KHÔNG đụng tới bất kỳ pref/
 * renderer nào của Gecko, nên không có đường nào lặp lại đúng hồi quy đã
 * gặp ở mục 83.
 *
 * Cơ chế:
 * - `GeckoViewEngine.onSelectionChangedListener` cho `screenRect` (toạ độ
 *   MÀN HÌNH THẬT, cùng hệ toạ độ với `ev.rawX/rawY` — xác nhận qua cách
 *   `BasicSelectionActionDelegate` dùng nó để tự vẽ thanh công cụ nổi ở
 *   đúng vị trí) — đặt núm BẮT ĐẦU ở góc dưới-trái, núm KẾT THÚC ở góc
 *   dưới-phải của rect đó (gần đúng cho vùng chọn 1-vài dòng — trường hợp
 *   phổ biến khi sửa code; vùng chọn nhiều dòng dài sẽ kém chính xác hơn,
 *   chấp nhận được cho bản đầu).
 * - Kéo núm: đổi toạ độ màn hình thật thành PHÂN SỐ (0.0–1.0) trên kích
 *   thước GeckoView (đúng kỹ thuật `dropXFracFallback`/`dropYFracFallback`
 *   đã dùng ổn định ở kéo-thả file), gọi `document.caretRangeFromPoint()`
 *   (API chuẩn, GeckoView/Firefox hỗ trợ) để tìm đúng vị trí văn bản dưới
 *   ngón tay, rồi dựng lại `Range` với 1 đầu CỐ ĐỊNH (đầu còn lại của vùng
 *   chọn, lưu vào `window.__lbSelFixedNode/__lbSelFixedOffset` ngay lúc
 *   bắt đầu kéo — cùng kỹ thuật "stash qua window global giữa các lần gọi
 *   evaluateJs" đã dùng ở mục 86.1) + đầu MỚI vừa kéo tới.
 * - Gọi cập nhật có giới hạn tần suất (~60ms/lần) để không dội lệnh JS
 *   liên tục khi kéo — núm vẫn theo ngón tay mượt (Kotlin, không chờ JS).
 */
class SelectionHandleOverlay(
    private val context: Context,
    private val hostView: View,
    private val engineProvider: () -> GeckoViewEngine
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var startHandle: HandleView? = null
    private var endHandle: HandleView? = null
    private var lastRect: RectF? = null
    private var pendingUpdate: Runnable? = null
    private val UPDATE_THROTTLE_MS = 60L

    /** Gọi từ `GeckoViewEngine.onSelectionChangedListener`. */
    fun onSelectionChanged(rect: RectF?, text: String) {
        if (rect == null || text.isEmpty()) {
            hide()
            return
        }
        lastRect = rect
        handler.post {
            ensureHandlesShown()
            positionHandle(startHandle, rect.left, rect.bottom)
            positionHandle(endHandle, rect.right, rect.bottom)
        }
    }

    /** Gọi từ `GeckoViewEngine.onSelectionHiddenListener`. */
    fun hide() {
        handler.post {
            removeHandle(startHandle); startHandle = null
            removeHandle(endHandle); endHandle = null
            lastRect = null
        }
    }

    private fun ensureHandlesShown() {
        if (startHandle == null) startHandle = addHandle(isStart = true)
        if (endHandle == null) endHandle = addHandle(isStart = false)
    }

    private fun addHandle(isStart: Boolean): HandleView {
        val density = context.resources.displayMetrics.density
        val view = HandleView(context, density, pointingLeft = isStart)
        val sizePx = (28 * density).roundToInt()
        val params = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            token = hostView.windowToken
        }
        view.onDrag = { rawX, rawY, finished ->
            scheduleSelectionUpdate(isStart, rawX, rawY, finished)
        }
        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            DebugLog.log("SelectionHandleOverlay: lỗi addView núm kéo (isStart=$isStart) — ${e.javaClass.simpleName}: ${e.message}")
        }
        return view
    }

    private fun removeHandle(v: HandleView?) {
        if (v == null) return
        try { windowManager.removeViewImmediate(v) } catch (e: Exception) { /* đã bị gỡ/window mất — bỏ qua */ }
    }

    private fun positionHandle(v: HandleView?, screenX: Float, screenY: Float) {
        v ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        // Núm treo NGAY DƯỚI điểm mốc (kiểu "giọt nước" chuẩn của Android) —
        // trừ nửa bề rộng để điểm mốc nằm ở GIỮA cạnh trên của núm.
        lp.x = (screenX - lp.width / 2f).roundToInt().coerceAtLeast(0)
        lp.y = screenY.roundToInt().coerceAtLeast(0)
        try { windowManager.updateViewLayout(v, lp) } catch (e: Exception) { /* view có thể vừa bị gỡ giữa chừng — bỏ qua */ }
    }

    /**
     * Đầu đang kéo di chuyển tới (rawX, rawY) MÀN HÌNH THẬT — cùng hệ toạ
     * độ `screenRect` đã dùng để đặt núm ban đầu.
     */
    private fun scheduleSelectionUpdate(isStart: Boolean, rawX: Float, rawY: Float, finished: Boolean) {
        // Theo ngón tay NGAY LẬP TỨC (mượt), không chờ JS trả lời.
        positionHandle(if (isStart) startHandle else endHandle, rawX, rawY)

        pendingUpdate?.let { handler.removeCallbacks(it) }
        val run = Runnable { applySelectionUpdate(isStart, rawX, rawY, finished) }
        pendingUpdate = run
        if (finished) handler.post(run) else handler.postDelayed(run, UPDATE_THROTTLE_MS)
    }

    private fun applySelectionUpdate(isStart: Boolean, rawX: Float, rawY: Float, finished: Boolean) {
        val loc = IntArray(2)
        try { hostView.getLocationOnScreen(loc) } catch (e: Exception) { return }
        val w = hostView.width.coerceAtLeast(1)
        val h = hostView.height.coerceAtLeast(1)
        val xFrac = ((rawX - loc[0]) / w).coerceIn(0f, 1f)
        val yFrac = ((rawY - loc[1]) / h).coerceIn(0f, 1f)
        val engine = engineProvider()
        val fixedSide = if (isStart) "end" else "start"
        val movingIsStart = isStart

        engine.evaluateJs(
            """(function(){
                try {
                    // Lần kéo ĐẦU TIÊN của thao tác này: lưu đầu CỐ ĐỊNH (đầu
                    // không kéo) vào window global — vẫn còn nguyên qua các
                    // lần gọi evaluateJs sau vì cùng 1 trang, cùng sandbox
                    // content script (đúng kỹ thuật "stash" đã dùng ở mục
                    // 86.1 cho paste-diagnostic).
                    if (!window.__lbSelFixedNode) {
                        var sel = window.getSelection();
                        if (!sel || sel.rangeCount === 0) return 'no-range';
                        var r = sel.getRangeAt(0);
                        window.__lbSelFixedNode = '$fixedSide' === 'start' ? r.startContainer : r.endContainer;
                        window.__lbSelFixedOffset = '$fixedSide' === 'start' ? r.startOffset : r.endOffset;
                    }
                    var cssX = ${xFrac} * window.innerWidth;
                    var cssY = ${yFrac} * window.innerHeight;
                    var moved = document.caretRangeFromPoint ? document.caretRangeFromPoint(cssX, cssY) : null;
                    if (!moved) return 'no-caret-range-at-point';

                    var range = document.createRange();
                    var fixedNode = window.__lbSelFixedNode;
                    var fixedOffset = window.__lbSelFixedOffset;
                    var movingIsStart = $movingIsStart;
                    try {
                        if (movingIsStart) {
                            range.setStart(moved.startContainer, moved.startOffset);
                            range.setEnd(fixedNode, fixedOffset);
                        } else {
                            range.setStart(fixedNode, fixedOffset);
                            range.setEnd(moved.startContainer, moved.startOffset);
                        }
                    } catch (eOrder) {
                        // Kéo qua khỏi đầu kia (đảo thứ tự start/end) — Range
                        // ném lỗi nếu start sau end trong DOM order. Chấp nhận
                        // giữ nguyên lần cập nhật này, thử lại ở lần kéo tiếp
                        // theo khi ngón tay quay lại đúng phía.
                        return 'lỗi thứ tự range (đã kéo qua đầu kia): ' + eOrder.message;
                    }
                    var sel2 = window.getSelection();
                    sel2.removeAllRanges();
                    sel2.addRange(range);
                    return 'OK độ_dài_mới=' + String(sel2.toString()).length;
                } catch (e) { return 'lỗi: ' + e.message; }
            })()"""
        ) { result ->
            if (finished) {
                // Kết thúc kéo — xoá mốc CỐ ĐỊNH đã lưu, thao tác kéo TIẾP
                // THEO (nếu có) phải tự lưu lại mốc mới từ selection hiện tại.
                engine.evaluateJs("(function(){delete window.__lbSelFixedNode; delete window.__lbSelFixedOffset; return 'đã dọn';})()", null)
            }
            DebugLog.log("SelectionHandleOverlay: cập nhật vùng chọn (isStart=$isStart, finished=$finished) — $result")
        }
    }

    /** View núm kéo — vẽ 1 hình giọt nước đơn giản bằng Canvas, tự xử lý kéo bằng ngón tay. */
    private class HandleView(
        context: Context,
        private val density: Float,
        private val pointingLeft: Boolean
    ) : View(context) {
        var onDrag: ((rawX: Float, rawY: Float, finished: Boolean) -> Unit)? = null

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1A73E8")
            style = Paint.Style.FILL
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val r = width / 2f
            canvas.drawCircle(width / 2f, r, r, paint)
            // Vuốt nhọn 1 góc để phân biệt núm ĐẦU (nhọn phải-trên) và núm
            // CUỐI (nhọn trái-trên) — kiểu giọt nước quen thuộc của Android.
            val path = android.graphics.Path()
            if (pointingLeft) {
                path.moveTo(0f, 0f); path.lineTo(r, 0f); path.lineTo(0f, r); path.close()
            } else {
                path.moveTo(width.toFloat(), 0f); path.lineTo(r, 0f); path.lineTo(width.toFloat(), r); path.close()
            }
            canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> return true
                MotionEvent.ACTION_MOVE -> {
                    onDrag?.invoke(event.rawX, event.rawY, false)
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    onDrag?.invoke(event.rawX, event.rawY, true)
                    return true
                }
            }
            return super.onTouchEvent(event)
        }
    }
}
