package com.colablive.keeper.core

import org.json.JSONArray
import org.json.JSONObject
import android.content.Context
import com.colablive.keeper.features.fingerprint.DeviceProfiles
import java.security.SecureRandom

/**
 * Mục 167: VÙNG ẨN DANH — nhiều "ngăn" ẩn danh tách biệt trong cùng một trình duyệt, mỗi vùng có fingerprint RIÊNG.
 *
 * - Cô lập dữ liệu: mỗi vùng dùng `GeckoSessionSettings.contextId("zone_<id>")` + chế độ riêng tư (tài liệu GeckoView: chỉ các phiên cùng contextId mới
 *   dùng chung cookie/localStorage). Tab ẩn danh THƯỜNG (không thuộc vùng nào) vẫn như cũ.
 * - Fingerprint riêng: mỗi vùng có (1) một hồ sơ phần cứng khác trong cùng loại (mobile/desktop) với hồ sơ của khe, (2) một hạt giống nhiễu (canvas/audio/font) riêng.
 *   Ngôn ngữ/múi giờ vẫn theo IP đi ra của khe (cùng một đường mạng).
 * - Vùng được lưu theo khe (AppPrefs) nên còn lại sau khi mở lại app; TAB trong vùng thì không (đúng tính chất ẩn danh).
 */
object IncognitoZones {
    private const val FEATURE = "zones"
    private const val KEY = "list"
    private val PALETTE = listOf("#E8710A", "#1E8E3E", "#A142F4", "#D93025", "#009688", "#F9AB00", "#1A73E8", "#795548")

    data class Zone(val id: String, var name: String, var hwIdx: Int, var seed: Long, val colorHex: String)

    fun groupId(zoneId: String) = "__zone__$zoneId"
    fun contextIdFor(zoneId: String) = "zone_$zoneId"

    fun list(context: Context, slotIndex: Int): List<Zone> = try {
        val arr = JSONArray(AppPrefs.getString(context, slotIndex, FEATURE, KEY, "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id"); if (id.isBlank()) return@mapNotNull null
            Zone(id, o.optString("name", "Vùng"), o.optInt("hw", 0), o.optLong("seed", 1L), o.optString("color", PALETTE[0]))
        }
    } catch (e: Exception) { emptyList() }

    fun get(context: Context, slotIndex: Int, id: String): Zone? = list(context, slotIndex).firstOrNull { it.id == id }

    private fun save(context: Context, slotIndex: Int, zones: List<Zone>) {
        val arr = JSONArray()
        zones.forEach { z -> arr.put(JSONObject().put("id", z.id).put("name", z.name).put("hw", z.hwIdx).put("seed", z.seed).put("color", z.colorHex)) }
        AppPrefs.setString(context, slotIndex, FEATURE, KEY, arr.toString())
    }

    /** Chọn hồ sơ phần cứng cùng loại với hồ sơ của khe, khác hồ sơ khe và ưu tiên khác các vùng đã có. */
    private fun pickHw(zones: List<Zone>, baseCategory: String, baseName: String, exceptIdx: Int = -1): Int {
        val all = DeviceProfiles.hardwareProfiles
        val sameCat = all.indices.filter { all[it].category == baseCategory && all[it].name != baseName && it != exceptIdx }
        val unused = sameCat.filter { idx -> zones.none { it.hwIdx == idx } }
        val pool = if (unused.isNotEmpty()) unused else sameCat.ifEmpty { all.indices.toList() }
        return pool[SecureRandom().nextInt(pool.size)]
    }

    fun create(context: Context, slotIndex: Int, baseCategory: String, baseName: String): Zone {
        val zones = list(context, slotIndex)
        var n = zones.size + 1
        while (zones.any { it.name == "Vùng $n" }) n++
        val z = Zone(
            id = java.util.UUID.randomUUID().toString().replace("-", "").take(12),
            name = "Vùng $n",
            hwIdx = pickHw(zones, baseCategory, baseName),
            seed = SecureRandom().nextLong(),
            colorHex = PALETTE[zones.size % PALETTE.size]
        )
        save(context, slotIndex, zones + z)
        return z
    }

    fun rename(context: Context, slotIndex: Int, id: String, newName: String) {
        val zones = list(context, slotIndex)
        zones.firstOrNull { it.id == id }?.name = newName.trim().take(30).ifBlank { "Vùng" }
        save(context, slotIndex, zones)
    }

    /** Đổi lại fingerprint của vùng: hồ sơ phần cứng + hạt giống nhiễu mới. */
    fun regenerate(context: Context, slotIndex: Int, id: String, baseCategory: String, baseName: String): Zone? {
        val zones = list(context, slotIndex)
        val z = zones.firstOrNull { it.id == id } ?: return null
        z.hwIdx = pickHw(zones - z, baseCategory, baseName, exceptIdx = z.hwIdx)
        z.seed = SecureRandom().nextLong()
        save(context, slotIndex, zones)
        return z
    }

    fun delete(context: Context, slotIndex: Int, id: String) {
        save(context, slotIndex, list(context, slotIndex).filter { it.id != id })
    }

    fun describe(z: Zone): String {
        val hw = DeviceProfiles.hardwareProfiles.getOrNull(z.hwIdx)
        return (hw?.name ?: "?") + " · #" + "%04x".format((z.seed ushr 16) and 0xFFFF)
    }
}
