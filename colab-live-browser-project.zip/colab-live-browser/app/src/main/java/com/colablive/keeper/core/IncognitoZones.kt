package com.colablive.keeper.core

import org.json.JSONArray
import org.json.JSONObject
import android.content.Context
import com.colablive.keeper.features.fingerprint.DeviceProfiles
import java.security.SecureRandom

/**
 * Mục 167: VÙNG ẨN DANH — nhiều "ngăn" ẩn danh tách biệt trong cùng một trình duyệt, mỗi vùng có fingerprint RIÊNG.
 *
 * - Cô lập dữ liệu: mỗi vùng dùng `GeckoSessionSettings.contextId("zone_<id>")` + chế độ riêng tư (tài liệu GeckoView: chỉ các phiên cùng contextId mới
 *   dùng chung cookie/localStorage). Tab ẩn danh THƯỜNG (không thuộc vùng nào) vẫn như cũ.
 * - Fingerprint riêng: mỗi vùng có (1) một hồ sơ phần cứng khác trong cùng loại (mobile/desktop) với hồ sơ của khe, (2) một hạt giống nhiễu (canvas/audio/font) riêng.
 *   Ngôn ngữ/múi giờ vẫn theo IP đi ra của khe (cùng một đường mạng).
 * - Vùng được lưu theo khe (AppPrefs) nên còn lại sau khi mở lại app; TAB trong vùng thì không (đúng tính chất ẩn danh).
 */
object IncognitoZones {
    private const val FEATURE = "zones"
    private const val KEY = "list"
    private val PALETTE = listOf("#E8710A", "#1E8E3E", "#A142F4", "#D93025", "#009688", "#F9AB00", "#1A73E8", "#795548")

    /**
     * Bản 7.63: `persistent` = VÙNG BỀN. Phiên THƯỜNG (không riêng tư) + `contextId` riêng của vùng => cookie/đăng nhập/localStorage GHI XUỐNG ĐĨA (cookies.sqlite của hồ sơ)
     * và còn sau khi tắt app/khởi động lại máy, vẫn tách biệt với mọi vùng khác và với khe (cô lập theo contextId — cơ chế GeckoView chính thức). Tab của vùng bền
     * KHÔNG phải tab ẩn danh (isPrivate=false): được lưu/khôi phục, có lịch sử và ảnh xem trước. Vùng ẩn danh (persistent=false) giữ nguyên hành vi cũ.
     */
    data class Zone(val id: String, var name: String, var hwIdx: Int, var seed: Long, val colorHex: String, val persistent: Boolean = false,
                    /** Bản 7.64: chỉ số trong DeviceProfiles.localeProfiles; -1 = theo khe. Chỉ đổi phía JS (ngôn ngữ/múi giờ) — IP và Accept-Language HTTP vẫn theo khe. */
                    var localeIdx: Int = -1,
                    /**
                     * Bản 7.71: PROXY/VPN RIÊNG THEO VÙNG. 0 = theo khe (mặc định); 1 = proxy riêng của vùng (type 1=HTTP, 2=SOCKS); 2 = trực tiếp (bỏ qua proxy khe,
                     * có thể đè cả addon VPN — chưa kiểm chứng); 3 = để nguyên cho addon VPN xử lý (không dùng proxy khe). Hiệu lực qua addon proxy_config (tabId → vùng).
                     */
                    var proxyMode: Int = 0, var proxyType: Int = 1, var proxyHost: String = "", var proxyPort: Int = 0, var proxyUser: String = "", var proxyPass: String = "")

    fun groupId(zoneId: String) = "__zone__$zoneId"
    fun contextIdFor(zoneId: String) = "zone_$zoneId"

    fun list(context: Context, slotIndex: Int): List<Zone> = try {
        val arr = JSONArray(AppPrefs.getString(context, slotIndex, FEATURE, KEY, "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id"); if (id.isBlank()) return@mapNotNull null
            Zone(id, o.optString("name", "Vùng"), o.optInt("hw", 0), o.optLong("seed", 1L), o.optString("color", PALETTE[0]), o.optBoolean("persist", false), o.optInt("loc", -1),
                o.optInt("pm", 0), o.optInt("pt", 1), o.optString("ph", ""), o.optInt("pp", 0), o.optString("pu", ""), o.optString("pw", ""))
        }
    } catch (e: Exception) { emptyList() }

    fun get(context: Context, slotIndex: Int, id: String): Zone? = list(context, slotIndex).firstOrNull { it.id == id }

    private fun save(context: Context, slotIndex: Int, zones: List<Zone>) {
        val arr = JSONArray()
        zones.forEach { z -> arr.put(JSONObject().put("id", z.id).put("name", z.name).put("hw", z.hwIdx).put("seed", z.seed).put("color", z.colorHex).put("persist", z.persistent).put("loc", z.localeIdx)
            .put("pm", z.proxyMode).put("pt", z.proxyType).put("ph", z.proxyHost).put("pp", z.proxyPort).put("pu", z.proxyUser).put("pw", z.proxyPass)) }
        AppPrefs.setString(context, slotIndex, FEATURE, KEY, arr.toString())
    }

    /** Chọn hồ sơ phần cứng cùng loại với hồ sơ của khe, khác hồ sơ khe và ưu tiên khác các vùng đã có. */
    private fun pickHw(zones: List<Zone>, baseCategory: String, baseName: String, exceptIdx: Int = -1): Int {
        val all = DeviceProfiles.hardwareProfiles
        val sameCat = all.indices.filter { all[it].category == baseCategory && all[it].name != baseName && it != exceptIdx }
        val unused = sameCat.filter { idx -> zones.none { it.hwIdx == idx } }
        val pool = if (unused.isNotEmpty()) unused else sameCat.ifEmpty { all.indices.toList() }
        return pool[SecureRandom().nextInt(pool.size)]
    }

    fun create(context: Context, slotIndex: Int, baseCategory: String, baseName: String, persistent: Boolean = false): Zone {
        val zones = list(context, slotIndex)
        var n = zones.size + 1
        while (zones.any { it.name == "Vùng $n" }) n++
        val label = if (persistent) "Vùng bền $n" else "Vùng $n"
        val z = Zone(
            id = java.util.UUID.randomUUID().toString().replace("-", "").take(12),
            name = label,
            hwIdx = pickHw(zones, baseCategory, baseName),
            seed = SecureRandom().nextLong(),
            colorHex = PALETTE[zones.size % PALETTE.size],
            persistent = persistent
        )
        save(context, slotIndex, zones + z)
        return z
    }

    fun rename(context: Context, slotIndex: Int, id: String, newName: String) {
        val zones = list(context, slotIndex)
        zones.firstOrNull { it.id == id }?.name = newName.trim().take(30).ifBlank { "Vùng" }
        save(context, slotIndex, zones)
    }

    /** Đổi lại fingerprint của vùng: hồ sơ phần cứng + hạt giống nhiễu mới. */
    fun regenerate(context: Context, slotIndex: Int, id: String, baseCategory: String, baseName: String): Zone? {
        val zones = list(context, slotIndex)
        val z = zones.firstOrNull { it.id == id } ?: return null
        z.hwIdx = pickHw(zones - z, baseCategory, baseName, exceptIdx = z.hwIdx)
        z.seed = SecureRandom().nextLong()
        save(context, slotIndex, zones)
        return z
    }

    /** Bản 7.64: chọn THỦ CÔNG hồ sơ phần cứng cho vùng (trước đây chỉ có ngẫu nhiên). Giữ nguyên hạt giống nhiễu. */
    fun setHardware(context: Context, slotIndex: Int, id: String, hwIdx: Int): Zone? {
        val zones = list(context, slotIndex)
        val z = zones.firstOrNull { it.id == id } ?: return null
        if (hwIdx !in DeviceProfiles.hardwareProfiles.indices) return z
        z.hwIdx = hwIdx
        save(context, slotIndex, zones)
        return z
    }

    /** Bản 7.64: ngôn ngữ/múi giờ riêng cho vùng (-1 = theo khe). */
    fun setLocale(context: Context, slotIndex: Int, id: String, localeIdx: Int): Zone? {
        val zones = list(context, slotIndex)
        val z = zones.firstOrNull { it.id == id } ?: return null
        z.localeIdx = if (localeIdx in DeviceProfiles.localeProfiles.indices) localeIdx else -1
        save(context, slotIndex, zones)
        return z
    }

    /** Bản 7.71: đặt proxy/VPN cho vùng (xem [Zone.proxyMode]). Chế độ 1 cần host + cổng hợp lệ, nếu không trả null và KHÔNG đổi gì. */
    fun setProxy(context: Context, slotIndex: Int, id: String, mode: Int, type: Int, host: String, port: Int, user: String, pass: String): Zone? {
        val zones = list(context, slotIndex)
        val z = zones.firstOrNull { it.id == id } ?: return null
        if (mode !in 0..3) return null
        if (mode == 1 && (host.isBlank() || port !in 1..65535)) return null
        z.proxyMode = mode
        if (mode == 1) { z.proxyType = if (type == 2) 2 else 1; z.proxyHost = host.trim(); z.proxyPort = port; z.proxyUser = user; z.proxyPass = pass }
        save(context, slotIndex, zones)
        return z
    }

    /** Nhãn ngắn cho [Zone.proxyMode] (hiện trong danh sách/hộp thoại). */
    fun proxyLabel(z: Zone): String = when (z.proxyMode) {
        1 -> "🔀 proxy riêng ${z.proxyHost}:${z.proxyPort}"
        2 -> "🚫 trực tiếp"
        3 -> "🛡 để addon VPN"
        else -> "theo khe"
    }

    fun delete(context: Context, slotIndex: Int, id: String) {
        save(context, slotIndex, list(context, slotIndex).filter { it.id != id })
    }

    fun describe(z: Zone): String {
        val hw = DeviceProfiles.hardwareProfiles.getOrNull(z.hwIdx)
        return (hw?.name ?: "?") + " · #" + "%04x".format((z.seed ushr 16) and 0xFFFF) + (if (z.persistent) " · 💾 bền" else "") + (DeviceProfiles.localeProfiles.getOrNull(z.localeIdx)?.let { " · 🌐 ${it.name}" } ?: "") + (if (z.proxyMode != 0) " · ${proxyLabel(z)}" else "")
    }
}
