package com.colablive.keeper.core

import org.json.JSONObject

/**
 * Bản 7.104 — ĐO TÁC DỤNG THẬT của một cú thả file lên TRANG (chỉ ĐỌC, không đổi hành vi).
 *
 * Vì sao: log 09:34 ngày 11/11 (7.98) cho thấy khe có fingerprint TẮT bị dán ~30.690 ký tự vào ô soạn thảo ngay sau cú thả file, trong khi người dùng báo một khe khác
 * (cùng bản app) KHÔNG bị. Các dòng log hiện có chỉ cho biết app đã làm gì với DragEvent, không cho biết TRANG có bị chèn chữ hay không, và dòng "[kéo-thả TRANG NHẬN]"
 * (sự kiện `drop` mà trang thấy) không xuất hiện lần nào trong cả 4 log. Muốn biết vì sao hai khe khác nhau thì phải đo cùng một đại lượng ở cả hai: độ dài chữ của ô đang focus
 * TRƯỚC khi thả (lúc ACTION_DRAG_ENTERED) và SAU khi thả (1,5s và 4s). Tăng bất thường => chữ đã bị chèn vào ô.
 *
 * Script chạy trong trang chỉ ĐỌC (activeElement, độ dài giá trị/chữ, độ dài vùng chọn); không ghi, không gửi gì ra ngoài.
 */
object DropEffectProbe {
    /** Ngưỡng tăng chữ coi là "bị chèn": cú gõ/thao tác thường không tăng vài trăm ký tự trong ~1–4 giây quanh lúc thả. */
    const val GROWTH_THRESHOLD_CHARS = 200L

    const val PROBE_JS = "(function(){try{" +
        "if(!window.__lbDropProbe){var L=window.__lbDropProbe={ev:[]};" +
        "var add=function(o){try{if(L.ev.length<12)L.ev.push(o);}catch(x){}};" +
        "window.addEventListener('drop',function(e){var ty='',fl=-1;try{var dt=e.dataTransfer;ty=Array.prototype.slice.call(dt.types||[]).join('+');fl=dt.files?dt.files.length:-1;}catch(x){}" +
        "add('drop[trusted='+e.isTrusted+',types='+ty+',files='+fl+']');},true);" +
        "window.addEventListener('beforeinput',function(e){var it=String(e.inputType||'');if(/^insertFrom(Drop|Paste)/.test(it)){var n=-1;try{n=e.dataTransfer?String(e.dataTransfer.getData('text/plain')||'').length:(e.data?String(e.data).length:0);}catch(x){}" +
        "add(it+'[trusted='+e.isTrusted+',chars='+n+']');}},true);}" +
        "var a=document.activeElement,d=0;" +
        "while(a&&a.shadowRoot&&a.shadowRoot.activeElement&&d<5){a=a.shadowRoot.activeElement;d++;}" +
        "var tag=a?String(a.tagName||'').toLowerCase():'',kind='none',len=-1;" +
        "if(a){" +
        "if(tag==='textarea'||tag==='input'){kind='input';len=String(a.value||'').length;}" +
        "else if(a.isContentEditable){kind='editable';len=String(a.textContent||'').length;}" +
        "}" +
        "var s='';try{s=String(window.getSelection());}catch(e){}" +
        "return JSON.stringify({tag:tag,kind:kind,len:len,sel:s.length,host:location.hostname,ev:window.__lbDropProbe.ev.slice(-6).join(' ; ')});" +
        "}catch(e){return JSON.stringify({err:String((e&&e.message)||e)});}})();"

    class Reading(val tag: String, val kind: String, val len: Long, val sel: Long, val host: String, val ev: String = "") {
        fun brief(): String = if (kind == "none") "không có ô nhập đang focus (tag='$tag')" else "$kind<$tag> dài=$len, vùng chọn=$sel"
    }

    /** Kết quả JS thô (có thể bọc trong dấu nháy kép nếu cầu eval trả chuỗi JSON-hoá) => Reading; null nếu không đọc được. */
    fun parse(raw: String?): Reading? {
        if (raw == null) return null
        var t = raw.trim()
        if (t.isEmpty() || t == "null") return null
        try {
            if (t.startsWith("\"") && t.endsWith("\"")) t = org.json.JSONTokener(t).nextValue() as? String ?: return null
            val o = JSONObject(t)
            if (o.has("err")) return null
            return Reading(o.optString("tag", ""), o.optString("kind", "none"), o.optLong("len", -1L), o.optLong("sel", 0L), o.optString("host", ""), o.optString("ev", ""))
        } catch (e: Exception) {
            return null
        }
    }

    /** Số ký tự tăng thêm của ô nhập so với trước khi thả (ô chưa focus/không đọc được ở mốc đầu coi là 0). null = sau khi thả không có ô nhập nào để so. */
    fun growth(before: Reading?, after: Reading?): Long? {
        if (after == null || after.kind == "none" || after.len < 0) return null
        val b = if (before == null || before.kind == "none" || before.len < 0) 0L else before.len
        return after.len - b
    }

    /** Dòng kết luận ngắn cho log. [fileDropHandledByApp] = app đã KHÔNG chuyển ACTION_DROP cho Gecko. */
    fun verdict(before: Reading?, after: Reading?, fileDropHandledByApp: Boolean): String {
        val g = growth(before, after)
        val seen = after?.ev?.takeIf { it.isNotBlank() } ?: "KHÔNG có sự kiện drop/insertFromDrop/insertFromPaste nào tới trang (kể từ lúc kéo vào)"
        val head = "trước thả: ${before?.brief() ?: "(không đo được)"} | sau thả: ${after?.brief() ?: "(không đo được)"} | trang thấy: $seen"
        return when {
            g == null -> "$head => không so được"
            g >= GROWTH_THRESHOLD_CHARS ->
                "$head => Ô NHẬP TĂNG $g ký tự sau cú thả" + if (fileDropHandledByApp) " (dù app KHÔNG chuyển cú thả cho Gecko — nguồn chèn chữ là đường khác, cần xem tiếp)" else " (app đã chuyển cú thả cho Gecko)"
            else -> "$head => ô nhập tăng $g ký tự (dưới ngưỡng $GROWTH_THRESHOLD_CHARS — không có chữ bị dán)"
        }
    }
}
