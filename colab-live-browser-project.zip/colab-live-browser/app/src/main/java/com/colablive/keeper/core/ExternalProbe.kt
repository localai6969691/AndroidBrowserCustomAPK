package com.colablive.keeper.core

/**
 * Bản 7.119 — ĐO TỪ NGOÀI (người dùng yêu cầu: "muốn đo thì đo từ trang thứ 3 bên ngoài, như IP là dùng cả 2 trang để so khớp kết quả với nhau, kể cả fingerprint cũng làm như vậy").
 *
 * LÝ DO (đọc từ mã + log 24/11, không đoán): các phép "đo" trước đây đều là TỰ ĐO của app — `[fp-selftest]`/công cụ kiểm tra thiết bị 7.113 do chính content script của app đọc rồi tự báo "OK"
 * (người dùng thấy trang Device Info bên ngoài lệch trong khi selftest báo OK), và phép đo IP là hai lời gọi `fetch` chạy BÊN TRONG trang đang xem nên bị CSP chặn (claude.ai), bị định tuyến theo
 * tên miền, rồi rơi về đường dự phòng "(?)". Nay: nạp các TRANG BÊN NGOÀI do bên thứ ba vận hành, làm điều hướng cấp cao nhất trong một "tab đo" vô hình thuộc CÙNG lớp/vùng với tab cần đo
 * (cùng đường mạng, cùng proxy/VPN, cùng kho cookie, cùng UA/Accept-Language), đọc nguyên văn nội dung trang rồi ĐỐI CHIẾU CHÉO các nguồn độc lập với nhau.
 *
 * File này KHÔNG phụ thuộc Android: gồm (1) bộ phân tích từng trang, (2) luật đối chiếu chéo, (3) bộ chạy tuần tự qua giao diện [Env] để thử bằng đồng hồ giả. Phần dính Android (tạo tab đo, đọc
 * nội dung qua eval_bridge) nằm ở GeckoViewEngine.
 *
 * NHỮNG GÌ PHÉP ĐO NÀY CHỨNG MINH (và không): chứng minh điều MÁY CHỦ BÊN NGOÀI thấy ở tầng mạng (IP, nước, múi giờ theo CSDL IP, User-Agent và Accept-Language trên dây). KHÔNG đo được
 * giá trị JS (platform/cores/GPU/màn hình) — muốn đo cái đó từ ngoài phải đọc báo cáo của một trang fingerprint bên ngoài; xem nút "Ghi nội dung trang vào log" ở công cụ kiểm tra thiết bị.
 */
object ExternalProbe {
    enum class Kind { CF_TRACE, IPIFY, IPWHO, HTTPBIN }

    class Source(val kind: Kind, val url: String, val label: String)

    /** Thứ tự nạp. Ba nguồn đầu cho IP (đối chiếu chéo); Cloudflare còn cho nước + UA, ipwho.is cho múi giờ, httpbin cho UA + Accept-Language trên dây. */
    val SOURCES: List<Source> = listOf(
        Source(Kind.CF_TRACE, "https://www.cloudflare.com/cdn-cgi/trace", "Cloudflare"),
        Source(Kind.IPIFY, "https://api.ipify.org/", "ipify"),
        Source(Kind.IPWHO, "https://ipwho.is/", "ipwho.is"),
        Source(Kind.HTTPBIN, "https://httpbin.org/headers", "httpbin"),
    )

    class Reading(
        val kind: Kind,
        val ok: Boolean,
        val ip: String = "",
        val cc: String = "",
        val tz: String = "",
        val ua: String = "",
        val lang: String = "",
        val note: String = "",
    )

    // ---------- (1) Bộ phân tích từng trang ----------
    private val IP_RE = Regex("^[0-9A-Fa-f:.]{3,45}$")
    private fun looksLikeIp(s: String) = IP_RE.matches(s) && (s.contains('.') || s.contains(':'))
    private fun field(t: String, re: String): String? = Regex(re, RegexOption.IGNORE_CASE).find(t)?.groupValues?.getOrNull(1)

    fun parse(kind: Kind, text: String?): Reading {
        val t = text?.trim().orEmpty()
        if (t.isEmpty()) return Reading(kind, false, note = "không đọc được nội dung trang")
        return when (kind) {
            Kind.CF_TRACE -> {
                val kv = HashMap<String, String>()
                for (line in t.lineSequence()) {
                    val i = line.indexOf('=')
                    if (i > 0) kv.putIfAbsent(line.substring(0, i).trim(), line.substring(i + 1).trim())
                }
                val ip = kv["ip"].orEmpty()
                if (!looksLikeIp(ip)) Reading(kind, false, note = "không có dòng ip= hợp lệ")
                else Reading(kind, true, ip = ip, cc = kv["loc"].orEmpty().uppercase(), ua = kv["uag"].orEmpty())
            }
            Kind.IPIFY -> {
                val first = t.lineSequence().firstOrNull()?.trim().orEmpty()
                if (looksLikeIp(first)) Reading(kind, true, ip = first) else Reading(kind, false, note = "nội dung không phải địa chỉ IP")
            }
            Kind.IPWHO -> {
                if (Regex("\"success\"\\s*:\\s*false", RegexOption.IGNORE_CASE).containsMatchIn(t)) {
                    Reading(kind, false, note = "dịch vụ báo success=false")
                } else {
                    val ip = field(t, "\"ip\"\\s*:\\s*\"([^\"]+)\"").orEmpty()
                    val cc = field(t, "\"country_code\"\\s*:\\s*\"([A-Za-z]{2})\"").orEmpty().uppercase()
                    val tz = field(t, "\"timezone\"\\s*:\\s*\\{[^}]*?\"id\"\\s*:\\s*\"([^\"]+)\"").orEmpty()
                    if (!looksLikeIp(ip)) Reading(kind, false, note = "không tách được trường ip")
                    else Reading(kind, true, ip = ip, cc = cc, tz = tz)
                }
            }
            Kind.HTTPBIN -> {
                val ua = field(t, "\"User-Agent\"\\s*:\\s*\"([^\"]*)\"").orEmpty()
                val lang = field(t, "\"Accept-Language\"\\s*:\\s*\"([^\"]*)\"").orEmpty()
                if (ua.isEmpty() && lang.isEmpty()) Reading(kind, false, note = "không tách được User-Agent/Accept-Language")
                else Reading(kind, true, ua = ua, lang = lang)
            }
        }
    }

    // ---------- (2) Luật đối chiếu chéo ----------
    class Verdict(
        val ipAgree: Boolean,       // >=2 nguồn độc lập thấy CÙNG một IP
        val ip: String,             // IP được xác nhận ("" nếu không)
        val applyGeo: Boolean,      // đủ điều kiện để cập nhật geo của lớp/vùng (fingerprint đổi theo)
        val cc: String,             // nước dùng để áp ("" nếu không áp)
        val tz: String,             // múi giờ dùng để áp ("" nếu không áp)
        val uaSeen: String,         // User-Agent máy chủ ngoài thấy ("" nếu không có nguồn)
        val uaMatch: Boolean?,      // null = không so được
        val langSeen: String,       // Accept-Language máy chủ ngoài thấy
        val langMatch: Boolean?,    // null = không so được
        val lines: List<String>,    // diễn giải từng bước, dùng cho hộp thoại và log
    )

    private fun normLang(s: String) = s.replace(" ", "").lowercase()

    fun evaluate(readings: List<Reading>, expectedUa: String, expectedLang: String?): Verdict {
        val lines = ArrayList<String>()
        fun rd(k: Kind) = readings.firstOrNull { it.kind == k }
        for (src in SOURCES) {
            val r = rd(src.kind)
            if (r == null) { lines.add("${src.label}: chưa đo"); continue }
            if (!r.ok) { lines.add("${src.label}: LỖI (${r.note})"); continue }
            val parts = ArrayList<String>()
            if (r.ip.isNotBlank()) parts.add("ip=${r.ip}")
            if (r.cc.isNotBlank()) parts.add("nước=${r.cc}")
            if (r.tz.isNotBlank()) parts.add("múi giờ=${r.tz}")
            if (r.ua.isNotBlank()) parts.add("UA thấy được")
            if (r.lang.isNotBlank()) parts.add("Accept-Language=${r.lang}")
            lines.add("${src.label}: ${parts.joinToString(" · ")}")
        }

        // --- IP: ít nhất hai nguồn độc lập cùng một địa chỉ ---
        val ipReads = readings.filter { it.ok && it.ip.isNotBlank() }
        val groups = ipReads.groupBy { it.ip.lowercase() }
        val best = groups.entries.maxByOrNull { it.value.size }
        val agree = best != null && best.value.size >= 2
        val ip = if (agree) best!!.value.first().ip else ""
        if (agree) {
            lines.add("IP: ${best!!.value.size}/${ipReads.size} nguồn độc lập cùng thấy $ip ⇒ XÁC NHẬN")
        } else if (ipReads.size >= 2) {
            lines.add("IP: các nguồn thấy KHÁC nhau (${ipReads.joinToString(", ") { "${labelOf(it.kind)}=${it.ip}" }}) — định tuyến theo tên miền hoặc proxy đổi giữa chừng; không tự áp")
        } else {
            lines.add("IP: chưa đủ hai nguồn đo được (${ipReads.size}) ⇒ không xác nhận được")
        }

        // --- Geo: múi giờ chỉ lấy từ ipwho.is khi IP của nó ĐÚNG là IP đã xác nhận; nước đối chiếu với Cloudflare ---
        val who = rd(Kind.IPWHO)
        val cf = rd(Kind.CF_TRACE)
        var applyGeo = false
        var cc = ""
        var tz = ""
        if (agree && who != null && who.ok && who.ip.equals(ip, ignoreCase = true) && who.tz.isNotBlank() && who.cc.length == 2) {
            val cfCc = if (cf != null && cf.ok) cf.cc else ""
            if (cfCc.isNotBlank() && !cfCc.equals(who.cc, ignoreCase = true)) {
                lines.add("Nước: Cloudflare thấy $cfCc nhưng ipwho.is nói ${who.cc} — hai nguồn bất đồng, không tự áp")
            } else {
                applyGeo = true; cc = who.cc; tz = who.tz
                lines.add("Nước/múi giờ: ${who.cc} · ${who.tz}" + if (cfCc.isNotBlank()) " (Cloudflare cũng thấy $cfCc ⇒ khớp)" else " (chỉ một nguồn nước)")
            }
        } else if (agree) {
            lines.add("Múi giờ: thiếu ipwho.is cho đúng IP đã xác nhận ⇒ không tự áp")
        }

        // --- Trên dây: UA và Accept-Language mà máy chủ ngoài thấy ---
        val uaCands = listOfNotNull(cf?.takeIf { it.ok && it.ua.isNotBlank() }?.ua, rd(Kind.HTTPBIN)?.takeIf { it.ok && it.ua.isNotBlank() }?.ua)
        val uaSeen = uaCands.firstOrNull().orEmpty()
        var uaMatch: Boolean? = null
        if (uaCands.isNotEmpty()) {
            val consistent = uaCands.all { it == uaSeen }
            if (!consistent) lines.add("User-Agent: Cloudflare và httpbin thấy KHÁC nhau")
            uaMatch = if (expectedUa.isBlank()) null else consistent && uaSeen == expectedUa
            lines.add("User-Agent: " + when (uaMatch) {
                true -> "máy chủ ngoài thấy ĐÚNG UA đã cài"
                false -> "LỆCH — đã cài `$expectedUa` nhưng máy chủ ngoài thấy `$uaSeen`"
                null -> "không so được (thiếu UA đã cài)"
            })
        }
        val langSeen = rd(Kind.HTTPBIN)?.takeIf { it.ok }?.lang.orEmpty()
        var langMatch: Boolean? = null
        if (langSeen.isNotBlank()) {
            langMatch = if (expectedLang.isNullOrBlank()) null else normLang(langSeen) == normLang(expectedLang)
            lines.add("Accept-Language: " + when (langMatch) {
                true -> "máy chủ ngoài thấy ĐÚNG ($langSeen)"
                false -> "LỆCH — đã cài `$expectedLang` nhưng máy chủ ngoài thấy `$langSeen`"
                null -> "thấy `$langSeen` (không có giá trị đã cài để so)"
            })
        }
        return Verdict(agree, ip, applyGeo, cc, tz, uaSeen, uaMatch, langSeen, langMatch, lines)
    }

    private fun labelOf(k: Kind) = SOURCES.firstOrNull { it.kind == k }?.label ?: k.name

    /** Kết quả một lần đo để lưu và hiển thị. */
    class Result(
        val reason: String,
        val atWallMs: Long,
        val zoneName: String,
        val isPrivate: Boolean,
        val readings: List<Reading>,
        val verdict: Verdict,
        val aborted: String = "",
        val note: String = "",
    ) {
        fun summary(nowWallMs: Long): String {
            val mins = ((nowWallMs - atWallMs) / 60_000L).coerceAtLeast(0L)
            val whenText = if (mins < 1L) "vừa đo" else if (mins < 120L) "đo $mins phút trước" else "đo ${mins / 60L} giờ trước"
            val head = "Đo từ ngoài ($whenText; lý do: $reason; ${if (zoneName.isNotBlank()) "vùng '$zoneName'" else if (isPrivate) "lớp ẩn danh" else "lớp thường"})" + if (aborted.isNotBlank()) " — DỪNG GIỮA CHỪNG: $aborted" else ""
            return head + "\n" + verdict.lines.joinToString("\n") { "  • $it" } + if (note.isNotBlank()) "\n  ℹ $note" else ""
        }
    }

    // ---------- (3) Bộ chạy tuần tự (thử được bằng đồng hồ giả) ----------
    interface Env {
        fun nowMs(): Long
        fun postDelayed(ms: Long, r: () -> Unit)
        fun openProbeTab(): Boolean
        fun load(url: String)
        /** Mốc (cùng đồng hồ [nowMs]) của sự kiện "tải xong" gần nhất của tab đo; 0 nếu chưa có. */
        fun lastStopAtMs(): Long
        /** Số lần tab đo đã BẮT ĐẦU tải một trang (tăng ở onPageStart). Chỉ chấp nhận sự kiện "dừng" khi đã thấy một lần bắt đầu MỚI sau lệnh nạp: sự kiện dừng của about:blank khởi tạo/trang trước đến muộn không bị coi là trang này. */
        fun pageStartCount(): Int
        fun readText(cb: (String?) -> Unit)
        fun closeProbeTab()
        fun appInBackground(): Boolean
        fun log(msg: String)
    }

    class Runner(
        private val env: Env,
        private val sources: List<Source> = SOURCES,
        private val onDone: (readings: List<Reading>, aborted: String) -> Unit,
    ) {
        companion object {
            const val PAGE_TIMEOUT_MS = 15_000L
            const val TOTAL_TIMEOUT_MS = 70_000L
            const val POLL_MS = 400L
            const val READ_TRIES = 6
            const val READ_GAP_MS = 500L
        }

        private val readings = ArrayList<Reading>()
        private var idx = 0
        private var finished = false

        fun start() {
            if (!env.openProbeTab()) { finish("không tạo được tab đo"); return }
            env.postDelayed(TOTAL_TIMEOUT_MS) { if (!finished) finish("quá ${TOTAL_TIMEOUT_MS / 1000}s") }
            next()
        }

        private fun next() {
            if (finished) return
            if (idx >= sources.size) { finish(""); return }
            if (env.appInBackground()) { finish("app ra nền (cổng mạng nền giữ yêu cầu của tab đo)"); return }
            val src = sources[idx]
            val t0 = env.nowMs()
            val s0 = env.pageStartCount()
            env.log("[đo ngoài] nạp ${src.label}: ${src.url}")
            env.load(src.url)
            waitLoaded(src, t0, s0)
        }

        private fun waitLoaded(src: Source, t0: Long, s0: Int) {
            if (finished) return
            env.postDelayed(POLL_MS) {
                if (finished) return@postDelayed
                // App ra nền giữa lúc chờ: cổng mạng nền giữ yêu cầu của tab đo (không ghim) nên trang sẽ không tải — dừng ngay thay vì chờ hết 15s.
                if (env.appInBackground()) { finish("app ra nền (cổng mạng nền giữ yêu cầu của tab đo)"); return@postDelayed }
                val stop = env.lastStopAtMs()
                when {
                    // Phải LỚN HƠN HẲN t0: sự kiện dừng của trang TRƯỚC có thể trùng đúng mili-giây với lúc nạp trang này (test bắt được), khi đó `>=` đọc nhầm nội dung trang cũ.
                    stop > 0L && stop > t0 && env.pageStartCount() > s0 -> readWithRetry(src, 1)
                    env.nowMs() - t0 >= PAGE_TIMEOUT_MS -> {
                        readings.add(Reading(src.kind, false, note = "trang không tải xong sau ${PAGE_TIMEOUT_MS / 1000}s"))
                        idx++; next()
                    }
                    else -> waitLoaded(src, t0, s0)
                }
            }
        }

        private fun readWithRetry(src: Source, attempt: Int) {
            if (finished) return
            env.readText { text ->
                if (finished) return@readText
                val rd = parse(src.kind, text)
                if (rd.ok || attempt >= READ_TRIES) {
                    readings.add(rd); idx++; next()
                } else {
                    env.postDelayed(READ_GAP_MS) { readWithRetry(src, attempt + 1) }
                }
            }
        }

        private fun finish(aborted: String) {
            if (finished) return
            finished = true
            try { env.closeProbeTab() } catch (e: Throwable) { env.log("[đo ngoài] đóng tab đo lỗi: ${e.javaClass.simpleName}: ${e.message}") }
            onDone(readings.toList(), aborted)
        }
    }
}
