package com.colablive.keeper.core

import com.colablive.keeper.features.fingerprint.FingerprintSettingsBus
import android.content.Context
import android.os.Build
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.mozilla.geckoview.*
import org.mozilla.geckoview.WebExtension.MessageDelegate
import org.mozilla.geckoview.WebExtension.Port
import org.mozilla.geckoview.WebExtension.PortDelegate
import java.io.File
import java.io.FileOutputStream
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONObject
import org.json.JSONArray
import com.colablive.keeper.features.fingerprint.DeviceProfiles
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import com.colablive.keeper.MediaKeepAliveService

/**
 * Implementation của BrowserEngine dùng GeckoView.
 * Hỗ trợ multi-tab, drag-drop, proxy per slot, DNS over HTTPS, timezone sync, auto behavior.
 */
class GeckoViewEngine(
    private val context: Context,
    private var geckoView: GeckoView,
    private val slotIndex: Int
) : BrowserEngine {

    /**
     * Registry nhẹ (slotIndex -> engine đang chạy) — để các màn hình Settings
     * (VD `FingerprintSpoofFeature.buildSettingsView()`) có thể gọi tới
     * engine THẬT đang chạy mà không cần đổi interface `BrowserFeature.
     * buildSettingsView(context, slotIndex)` (chữ ký hiện KHÔNG có tham số
     * `engine` — đổi sẽ động vào 5 file khác, không cần thiết cho việc nhỏ
     * này). Dùng cho: sau khi lưu danh sách ngoại lệ tên miền desktop-player
     * trong Settings, áp dụng lại NGAY cho tab đang mở (không phải đợi điều
     * hướng tiếp theo mới có tác dụng — xem `applyExceptionAndReloadActiveTab()`).
     */
    companion object {
        private val instances = ConcurrentHashMap<Int, GeckoViewEngine>()
        fun forSlot(slotIndex: Int): GeckoViewEngine? = instances[slotIndex]
    }

    private val runtime: GeckoRuntime = GeckoRuntimeProvider.get(context, slotIndex)
    private val tabs = ConcurrentHashMap<String, GeckoSession>()
    private val tabMeta = ConcurrentHashMap<String, BrowserTab>()
    // BUG THẬT tìm ra (người dùng báo tab sắp xếp lộn xộn sau khi khôi
    // phục): `tabMeta`/`tabs` đều là `ConcurrentHashMap` — KHÔNG giữ thứ tự
    // chèn vào, `.values` trả về theo thứ tự bucket hash nội bộ, không phải
    // thứ tự người dùng mở tab. Ảnh hưởng CẢ `getTabs()` (nguồn cho thanh
    // chuyển tab UI — nghĩa là lộn xộn xảy ra ngay cả lúc dùng bình thường,
    // không chỉ lúc khôi phục) LẪN `saveTabsState()`/`restoreTabsIfAny()`.
    // Thêm danh sách thứ tự THẬT, riêng biệt, cập nhật mỗi khi tạo/đóng tab.
    private val tabOrder = java.util.concurrent.CopyOnWriteArrayList<String>()
    /** Lịch sử chuyển tab, MỚI NHẤT ĐỨNG ĐẦU (mục 107): để đóng tab thì quay về tab vừa xem ngay trước đó. */
    private val tabMru = java.util.concurrent.CopyOnWriteArrayList<String>()
    // Theo dõi tab đang chờ xác nhận `restoreState()` có THẬT SỰ điều
    // hướng đi đâu không — xem `createTabWithState()`/`onLocationChange`.
    private val pendingRestoreTabIds = java.util.concurrent.CopyOnWriteArraySet<String>()
    private val metaLogged = java.util.concurrent.CopyOnWriteArraySet<String>() // 7.69: metaData mỗi addon chỉ ghi MỘT lần/lần chạy

    /**
     * BUG THẬT (xác nhận lại từ log2.txt — người dùng phải bấm "Xem bằng
     * máy tính" 2 LẦN cách nhau 10s cho cùng 1 trang Colab lúc 22:38:37 và
     * 22:38:47): tập theo dõi tab đang bật desktop THỦ CÔNG qua
     * `toggleDesktopMode()` đã được thiết kế trước đó (xem PROJECT_STATUS.md)
     * nhưng KHÔNG có mặt trong file này — có nghĩa bản vá đó chưa từng được
     * ghi vào code thật, chỉ có trong lời kể. Không có tập này,
     * `applyViewportExceptionForUrl()` (chạy lại ở MỌI `onLoadRequest`, kể
     * cả các bước redirect nội bộ của OAuth/Colab) tiếp tục ghi đè lựa chọn
     * thủ công của người dùng ngay khi trang điều hướng tiếp — y hệt bug cũ.
     * Thêm lại tập này và cho `applyViewportExceptionForUrl` bỏ qua hẳn các
     * tab có trong tập, không đụng gì tới `userAgentMode`/`viewportMode`/
     * `userAgentOverride` của tab đó.
     */
    private val manualDesktopTabIds = java.util.concurrent.CopyOnWriteArraySet<String>()
    /**
     * Mục 141: đối xứng với `manualDesktopTabIds`. Khi hồ sơ phần cứng của fingerprint là DESKTOP, `applyViewportExceptionForUrl()` (chạy ở MỌI onLoadRequest) đặt lại
     * userAgentMode/viewportMode = DESKTOP + UA desktop của hồ sơ. Bấm "TẮT máy tính" chỉ đặt MOBILE rồi reload => onLoadRequest đặt lại DESKTOP ngay: người dùng bấm 8 lần
     * (log 07:12–07:16) vẫn thấy trang máy tính. Tab/tên miền do người dùng CHỦ ĐỘNG tắt máy tính được đánh dấu ở đây và được tôn trọng như đánh dấu thủ công bật.
     */
    private val manualMobileTabIds = java.util.concurrent.CopyOnWriteArraySet<String>()
    private var activeTabId: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val random = Random(slotIndex.toLong())

    private val evalPorts = mutableSetOf<Port>()
    // FIX HIỆU NĂNG (bug fan-out): trước đây evaluateJs() gửi script tới
    // TẤT CẢ port đang mở — tức MỌI frame của MỌI tab đang mở trong khe
    // này, không chỉ tab đang xem. Mỗi lần chẩn đoán video (6 lần/12s mỗi
    // khi mở YouTube), mỗi lần load trang (zoom), mỗi lần favicon — đều
    // "đánh thức" toàn bộ tab nền, kể cả 7 tab lazy chưa ai xem tới. Chi
    // phí này tăng TUYẾN TÍNH theo số tab đang mở — ngược hướng với việc
    // "mở nhiều tab vẫn mượt". Sửa: lưu port thuộc tab nào (qua
    // `port.sender.session`, xác nhận có thật qua javadoc chính thức
    // Mozilla — `WebExtension.MessageSender.session`: "GeckoSession that
    // sent this message. null if coming from a background script"), để
    // evaluateJs() lọc đúng port của tab cần nhắm tới.

    /**
     * Cầu nối tới giao diện (MainActivity) cho trình quản lý mật khẩu (mục 105/106). Engine chỉ tra cứu/ghi kho `LoginStore`;
     * việc HỎI người dùng (lưu? chọn tài khoản nào? mở khoá?) do Activity làm vì cần hộp thoại.
     */
    interface LoginEventListener {
        /** kind = NEW hoặc UPDATE; existingId != null khi UPDATE. */
        fun onLoginSubmit(origin: String, username: String, password: String, kind: LoginStore.Compare, existingId: String?, zone: String)
        fun onLoginChoose(origin: String, logins: List<LoginStore.Login>, onChosen: (LoginStore.Login) -> Unit)
        /** Kho đang khoá bằng mật khẩu chủ: hỏi mở khoá rồi gọi `retry` nếu thành công. */
        fun onUnlockNeeded(origin: String, retry: () -> Unit)
    }
    @Volatile var loginEventListener: LoginEventListener? = null

    /** `includePassword=false` ở bước 1 của đăng nhập 2 bước: trang CHƯA cần mật khẩu nên không đưa cho trang. */
    private fun fillMessage(l: LoginStore.Login, includePassword: Boolean = true): JSONObject =
        JSONObject().put("type", "login_fill").put("login", JSONObject()
            .put("username", l.username).put("password", if (includePassword) l.password else ""))

    // ===================== Mục 118: tự điền đăng nhập bằng cơ chế CHÍNH CHỦ của Gecko =====================
    // Lý do: đường JS (eval_bridge) phụ thuộc 4 mắt xích mong manh (extension được phép chạy ở tab ẩn danh -> port connect -> port ánh xạ
    // đúng tab -> JS nhận ra ô) và trước đây chỉ gửi `login_form` ĐÚNG MỘT LẦN cho mỗi ô: hỏng 1 mắt xích là không bao giờ thử lại. Gecko có sẵn
    // bộ nhận diện form đăng nhập (đúng thứ Firefox dùng, kể cả Google). Tài liệu GeckoView (Autocomplete): gặp form đăng nhập, Gecko gọi
    // `StorageDelegate.onLoginFetch(domain)`; có ĐÚNG 1 mục khớp thì tự điền (cần `loginAutofillEnabled`), nhiều mục thì gọi
    // `PromptDelegate.onLoginSelect`. Hai đường chạy song song: ô đã có chữ thì bên sau không đè (JS bỏ qua ô không rỗng).
    @Volatile private var chooseDialogUntil = 0L
    /** Chỉ cho MỘT hộp thoại "chọn tài khoản" mỗi lần (Gecko onLoginSelect và JS login_pick có thể cùng bắn). */
    private fun tryBeginChooseDialog(): Boolean {
        val now = System.currentTimeMillis()
        if (now < chooseDialogUntil) return false
        chooseDialogUntil = now + 6_000L
        return true
    }

    // Mục 120: GeckoView có cơ chế "ZoomToInput" — mỗi lần bàn phím mở/đổi chiều cao, APZ cuộn/zoom trang tới ô đang focus (pref
    // `apz.zoom-to-focused-input.enabled`, xem GeckoViewUtils/GeckoViewContent). Log Drive 21:51: ô tên file ở y=1459 (dưới đỉnh bàn phím y=1451) rồi bị
    // kéo lên y=986, `vvt` 466<->765 — đó chính là cú "nhảy" người dùng thấy, lặp lại mỗi lần bàn phím chớp 949/1046/0. Chỉ tắt cho drive.google.com
    // (đổi pref lúc chạy bằng GeckoPreferenceController), các trang khác (Colab...) giữ nguyên hành vi.
    @Volatile private var zoomToInputDisabled = false
    @Volatile private var lastZoomPolicyForceAt = 0L
    private fun applyZoomToInputPolicy(urlOverride: String? = null, force: Boolean = false) {
        try {
            val url = urlOverride ?: activeTabId?.let { tabMeta[it]?.url } ?: return
            val host = hostOf(url) ?: ""
            val wantDisabled = host == "drive.google.com"
            // Mục 133: `force` bỏ qua bộ nhớ đệm — chế độ "bàn phím phủ" của MainActivity được tính LẠI mỗi lần bàn phím đổi, còn pref này trước đây chỉ đặt khi
            // đổi tab/điều hướng và bị chặn bởi cache => hai thứ có thể lệch nhau (log đổi tên Drive: padBottom=66 nhưng pref vẫn `true`) => trang bị zoom kẹt.
            val now = android.os.SystemClock.uptimeMillis()
            // Giới hạn tần suất: chỉ đặt lại pref khi giá trị ĐỔI, hoặc (khi `force`) tối đa 1 lần / 2 giây để khỏi bắn IPC + log theo từng sự kiện inset.
            if (wantDisabled == zoomToInputDisabled && (!force || now - lastZoomPolicyForceAt < 2_000L)) return
            lastZoomPolicyForceAt = now
            zoomToInputDisabled = wantDisabled
            GeckoPreferenceController.setGeckoPref("apz.zoom-to-focused-input.enabled", !wantDisabled, GeckoPreferenceController.PREF_BRANCH_USER)
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN bàn phím] apz.zoom-to-focused-input.enabled = ${!wantDisabled} (host=$host)")
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN bàn phím] đổi apz.zoom-to-focused-input LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /** Mục 133: MainActivity gọi khi bàn phím hiện/ẩn và khi đổi trang để pref luôn khớp với trang đang xem. */
    fun refreshZoomToInputPolicy() = applyZoomToInputPolicy(null, force = true)
    fun isZoomToInputDisabled(): Boolean = zoomToInputDisabled

    private fun hostOf(origin: String): String? = try { java.net.URI(origin).host?.lowercase() } catch (e: Exception) { null }

    /** Các tài khoản đã lưu thuộc `domain` (Gecko đưa tên miền gốc, vd `google.com` cho `accounts.google.com`). */
    private fun nativeLoginEntriesFor(domain: String): Array<Autocomplete.LoginEntry> {
        if (!AppPrefs.getBoolean(context, slotIndex, "pw_enabled", true)) return emptyArray()
        val d = domain.trim().lowercase().trimStart('.')
        if (d.isEmpty()) return emptyArray()
        if (LoginStore.isLocked(context, slotIndex)) {
            DebugLog.log("Khe $slotIndex: [mật khẩu/Gecko] kho đang khoá bằng mật khẩu chủ — bỏ qua tự điền của Gecko cho '$d' (đường JS sẽ hỏi mở khoá)")
            return emptyArray()
        }
        // Bản 7.64: StorageDelegate.onLoginFetch của Gecko KHÔNG cho biết session nào hỏi => dùng vùng của tab ĐANG XEM (form đăng nhập hỏi từ tab đang xem);
        // chỉ trả tài khoản CÙNG vùng để không tự điền danh tính của vùng khác.
        val fetchZone = activeTabId?.let { tabMeta[it]?.zoneId } ?: ""
        val matches = LoginStore.all(context, slotIndex).filter { l ->
            if (l.zone != fetchZone) return@filter false
            val h = hostOf(l.origin)
            l.password.isNotEmpty() && h != null && (h == d || h.endsWith(".$d") || d.endsWith(".$h"))
        }
        return matches.map { l ->
            Autocomplete.LoginEntry.Builder()
                .guid(l.id)
                .origin(l.origin)
                // Gecko lưu form login với formActionOrigin = origin khi form không có thuộc tính action (nsILoginInfo.idl).
                .formActionOrigin(l.origin)
                .username(l.username)
                .password(l.password)
                .build()
        }.toTypedArray()
    }

    private fun setupNativeLoginAutofill() {
        try {
            runtime.setAutocompleteStorageDelegate(object : Autocomplete.StorageDelegate {
                override fun onLoginFetch(domain: String): GeckoResult<Array<Autocomplete.LoginEntry>>? {
                    return try {
                        val entries = nativeLoginEntriesFor(domain)
                        DebugLog.log("Khe $slotIndex: [mật khẩu/Gecko] onLoginFetch('$domain') -> ${entries.size} tài khoản")
                        GeckoResult.fromValue(entries)
                    } catch (e: Throwable) {
                        DebugLog.log("Khe $slotIndex: [mật khẩu/Gecko] onLoginFetch('$domain') LỖI ${e.javaClass.simpleName}: ${e.message}")
                        GeckoResult.fromValue(emptyArray<Autocomplete.LoginEntry>())
                    }
                }

                override fun onLoginUsed(login: Autocomplete.LoginEntry, usedFields: Int) {
                    try {
                        login.guid?.let { LoginStore.touch(context, slotIndex, it) }
                        DebugLog.log("Khe $slotIndex: [mật khẩu/Gecko] Gecko đã điền tài khoản cho ${login.origin} (usedFields=$usedFields)")
                    } catch (e: Throwable) { /* không quan trọng */ }
                }
            })
            DebugLog.log("Khe $slotIndex: [mật khẩu/Gecko] đã đặt Autocomplete.StorageDelegate (tự điền chính chủ của Gecko)")
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [mật khẩu/Gecko] KHÔNG đặt được StorageDelegate: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /** Gecko hỏi chọn 1 trong nhiều tài khoản (PromptDelegate.onLoginSelect) -> dùng đúng hộp thoại chọn đã có của app. */
    private fun handleNativeLoginSelect(
        request: GeckoSession.PromptDelegate.AutocompleteRequest<Autocomplete.LoginSelectOption>
    ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
        val options = request.options
        val listener = loginEventListener
        if (options.isNullOrEmpty() || listener == null) return null
        val origin = LoginStore.normalizeOrigin(options[0].value.origin) ?: return null
        val selZone = activeTabId?.let { tabMeta[it]?.zoneId } ?: "" // 7.64: chỉ tài khoản của vùng đang xem
        val all = LoginStore.all(context, slotIndex).filter { it.zone == selZone }
        val logins = options.mapNotNull { o -> all.firstOrNull { it.id == o.value.guid } }
        if (logins.isEmpty()) return null
        if (!tryBeginChooseDialog()) {
            DebugLog.log("Khe $slotIndex: [mật khẩu/Gecko] đã có hộp thoại chọn tài khoản đang mở — bỏ qua onLoginSelect cho $origin")
            return null
        }
        DebugLog.log("Khe $slotIndex: [mật khẩu/Gecko] onLoginSelect: ${logins.size} tài khoản cho $origin — hỏi người dùng")
        val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
        val finished = java.util.concurrent.atomic.AtomicBoolean(false)
        fun finish(resp: GeckoSession.PromptDelegate.PromptResponse) {
            if (finished.compareAndSet(false, true)) result.complete(resp)
        }
        // Người dùng bỏ qua hộp thoại thì app không nhận callback: tự đóng sau 60s để prompt của Gecko không treo mãi.
        handler.postDelayed({ if (!finished.get()) finish(request.dismiss()) }, 60_000L)
        listener.onLoginChoose(origin, logins) { chosen ->
            val opt = options.firstOrNull { it.value.guid == chosen.id }
            finish(if (opt != null) request.confirm(opt) else request.dismiss())
        }
        return result
    }

    private fun handleLoginMessage(type: String, message: JSONObject, port: Port) {
        try {
            if (!AppPrefs.getBoolean(context, slotIndex, "pw_enabled", true)) return
            val origin = LoginStore.normalizeOrigin(message.optString("origin", "")) ?: return
            // Mục 118: ánh xạ cổng->tab lúc `onConnect` có thể hụt (session chưa kịp vào bảng `tabs`, nhất là tab vừa mở). Trước đây hụt là
            // BỎ QUA vĩnh viễn (và JS chỉ báo 1 lần). Giờ tra lại ngay từ `port.sender.session` mỗi khi có tin.
            val tabId = portTabId[port] ?: run {
                val s = try { port.sender?.session } catch (e: Throwable) { null }
                val id = s?.let { tabIdFor(it) }
                if (id != null) portTabId[port] = id
                id
            }
            // Vẫn chưa biết cổng thuộc tab nào => KHÔNG làm gì (an toàn hơn là rò rỉ).
            if (tabId == null) {
                DebugLog.log("Khe $slotIndex: [mật khẩu] bỏ qua $type từ $origin — chưa biết cổng thuộc tab nào (JS sẽ báo lại)")
                return
            }
            // Mục 111 (người dùng báo: lưu rồi mà tab ẩn danh không tự điền): Chrome ĐIỀN mật khẩu đã lưu cả trong tab ẩn danh, chỉ
            // KHÔNG hỏi lưu mới. Trước đây chặn cả điền lẫn lưu nên tab ẩn danh không bao giờ điền. Giờ: tab ẩn danh chỉ được ĐIỀN
            // (login_form / login_pick), mọi thứ có thể GHI vào kho (login_submit) vẫn bị chặn để không để lại dấu vết từ phiên ẩn danh.
            val msgZone = tabMeta[tabId]?.zoneId ?: "" // Bản 7.64: tài khoản lưu/điền THEO VÙNG của tab
            val isPrivateTab = getTabs().any { it.id == tabId && it.isPrivate }
            if (isPrivateTab && type == "login_submit") {
                DebugLog.log("Khe $slotIndex: [mật khẩu] tab ẩn danh — không hỏi lưu mật khẩu mới cho $origin (chỉ điền mật khẩu đã lưu)")
                return
            }
            if (isPrivateTab) DebugLog.log("Khe $slotIndex: [mật khẩu] (tab ẩn danh) nhận $type từ $origin — eval_bridge CÓ chạy trong tab ẩn danh")
            if (origin.contains("google.com")) DebugLog.log("Khe $slotIndex: [mật khẩu] nhận $type từ $origin (usernameOnly=${message.optBoolean("usernameOnly", false)}, có gợi ý tên=${message.optString("userHint", "").isNotBlank()})")
            // Kho đang khoá bằng mật khẩu chủ: nhờ giao diện mở khoá rồi xử lý lại đúng tin này.
            if (LoginStore.isLocked(context, slotIndex)) {
                loginEventListener?.onUnlockNeeded(origin) { handleLoginMessage(type, message, port) }
                return
            }
            val usernameOnly = message.optBoolean("usernameOnly", false)
            val hint = message.optString("userHint", "").trim()
            when (type) {
                "login_form" -> {
                    val logins = LoginStore.forOrigin(context, slotIndex, origin, msgZone)
                    if (logins.isEmpty()) return
                    // Trang cho biết đang đăng nhập tài khoản nào (đã gõ ở bước 1 / ghi trong DOM) thì chọn đúng tài khoản đó.
                    val byHint = if (hint.isNotEmpty()) logins.firstOrNull { it.username.equals(hint, ignoreCase = true) } else null
                    val chosen = byHint ?: if (logins.size == 1) logins[0] else null
                    if (chosen != null) {
                        port.postMessage(fillMessage(chosen, includePassword = !usernameOnly))
                        LoginStore.touch(context, slotIndex, chosen.id)
                        DebugLog.log("Khe $slotIndex: [mật khẩu] tự điền ${if (usernameOnly) "tên đăng nhập" else "tài khoản"} đã lưu cho $origin${if (byHint != null) " (khớp gợi ý của trang)" else ""}")
                    } else {
                        // Nhiều tài khoản mà không có gợi ý: không tự đoán, báo trang để hỏi khi người dùng chạm vào ô.
                        port.postMessage(JSONObject().put("type", "login_fill").put("pickOnly", true).put("count", logins.size))
                        DebugLog.log("Khe $slotIndex: [mật khẩu] $origin có ${logins.size} tài khoản — chờ người dùng chạm ô để chọn")
                    }
                }
                "login_pick" -> {
                    val logins = LoginStore.forOrigin(context, slotIndex, origin, msgZone)
                    if (logins.isEmpty()) return
                    if (!tryBeginChooseDialog()) return
                    loginEventListener?.onLoginChoose(origin, logins) { chosen ->
                        try {
                            port.postMessage(fillMessage(chosen, includePassword = !usernameOnly))
                            LoginStore.touch(context, slotIndex, chosen.id)
                        } catch (e: Exception) { DebugLog.log("Khe $slotIndex: [mật khẩu] gửi lệnh điền lỗi — ${e.javaClass.simpleName}") }
                    }
                }
                "login_submit" -> {
                    val password = message.optString("password", "")
                    val username = message.optString("username", "")
                    if (password.isEmpty()) return
                    if (LoginStore.isNever(context, slotIndex, origin)) return
                    val cmp = LoginStore.compare(context, slotIndex, origin, username, password, msgZone)
                    if (cmp.kind == LoginStore.Compare.SAME) {
                        cmp.existingId?.let { LoginStore.touch(context, slotIndex, it) }
                        return
                    }
                    DebugLog.log("Khe $slotIndex: [mật khẩu] bắt được đăng nhập ở $origin (${cmp.kind}, tên dài ${username.length}, mật khẩu dài ${password.length}) — hỏi người dùng")
                    loginEventListener?.onLoginSubmit(origin, username, password, cmp.kind, cmp.existingId, msgZone)
                }
            }
        } catch (e: LoginStore.LockedException) {
            DebugLog.log("Khe $slotIndex: [mật khẩu] kho bị khoá giữa chừng khi xử lý $type — bỏ qua tin này")
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [mật khẩu] lỗi xử lý $type — ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private val portTabId = java.util.concurrent.ConcurrentHashMap<Port, String>()

    // Xem chú thích "TÍNH NĂNG MỚI" ở content.js — cache tạm cho tên file
    // nguồn (2) (thuộc tính `download` trên thẻ <a>, content script bắt
    // được ngay lúc click/gọi click() bằng JS) để đối chiếu khi
    // onExternalResponse tới. Key = href tuyệt đối content script bắt
    // được, value = (tên file, thời điểm nhận). Dọn theo thời gian
    // (DOWNLOAD_HINT_TTL_MS) — tránh phình bộ nhớ nếu người dùng click
    // nhiều link download nhưng không thực sự tải (huỷ dialog, mất mạng...).
    private val downloadFilenameHints = java.util.concurrent.ConcurrentHashMap<String, Pair<String, Long>>()
    private val DOWNLOAD_HINT_TTL_MS = 30_000L

    private var pendingFilePrompt: GeckoSession.PromptDelegate.FilePrompt? = null
    private var pendingFilePromptResult: GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? = null

    /**
     * BUG THẬT (người dùng báo: chuyển sang tab khác lúc 1 tab NỀN đang
     * tải dở, favicon gán ra bị lệch sang site khác): chữ ký cũ chỉ truyền
     * `url`, KHÔNG truyền `tabId` — dù cả 2 nơi gọi listener này bên dưới
     * ĐỀU ĐÃ CÓ SẴN đúng `tabId` (biết chắc 100% là tab nào vừa tải xong,
     * đã tự kiểm `tabId == activeTabId` ngay trước khi gọi). Vì thiếu
     * `tabId` trong chữ ký, `MainActivity.fetchFaviconForActiveTab(url)`
     * buộc phải TỰ ĐOÁN LẠI tab đích bằng `engine.getActiveTab()?.id` —
     * một lượt tra cứu THỨ HAI, xảy ra SAU (không đồng thời với) lượt kiểm
     * tra `tabId == activeTabId` gốc. Giữa 2 lượt tra cứu "tab active" đó
     * (1 ở đây lúc bắn sự kiện, 1 ở `fetchFaviconForActiveTab` lúc chuẩn bị
     * gửi script — cách nhau ít nhất 1 lượt gọi hàm, đủ để hệ thống xử lý
     * 1 sự kiện chuyển tab của người dùng chen vào giữa vì eval là bất
     * đồng bộ/có độ trễ mạng), "tab active" có thể đã ĐỔI — khiến hàm
     * favicon tự nhắm nhầm sang tab MỚI đang active thay vì đúng tab vừa
     * tải xong, thay vì dùng lại CHÍNH XÁC giá trị `tabId` đã biết chắc
     * đúng ngay từ đầu. Sửa: truyền kèm `tabId` — nơi gọi (MainActivity)
     * dùng THẲNG giá trị này, không tự tra cứu lại "tab active" lần nữa.
     */
    var onPageLoadedListener: ((tabId: String, url: String) -> Unit)? = null

    /** Mục 96 — bắn khi Gecko có 1 vùng chọn text thật với toạ độ hình học
     * (`screenRect`, có thể null nếu Gecko không tính được) — dùng để vẽ
     * "núm kéo" (`SelectionHandleOverlay`) thay cho con trỏ native đã phải
     * tắt (mục 81/83). `text` kèm theo để MainActivity biết còn chọn gì. */
    var onSelectionChangedListener: ((rect: android.graphics.RectF?, text: String) -> Unit)? = null
    /** Mục 96 — bắn khi Gecko ẩn action bar (chọn bị huỷ/rời trang...) — ẩn núm kéo theo. */
    var onSelectionHiddenListener: (() -> Unit)? = null
    /**
     * TÍNH NĂNG THIẾU (người dùng báo: "ko có icon biểu hiện trang load
     * xong hết như các trình duyệt khác"): `BrowserTab.isLoading` đã được
     * cập nhật đúng ở `onPageStart`/`onPageStop` bên dưới TỪ TRƯỚC, nhưng
     * chưa từng có cách nào cho UI (MainActivity) BIẾT NGAY lúc bắt đầu
     * tải để vẽ spinner — chỉ có `onPageLoadedListener` (báo lúc XONG),
     * không có listener tương ứng cho lúc BẮT ĐẦU. Thêm listener này, gọi
     * đúng chỗ `isLoading = true` được set, để `MainActivity` có thể
     * `refreshTabBar()` ngay từ lúc bắt đầu tải — không phải tự tưởng
     * tượng thêm cơ chế mới, chỉ nối dây cho dữ liệu đã có sẵn.
     */
    var onPageStartedListener: ((String) -> Unit)? = null
    var onPageErrorListener: ((String, Int) -> Unit)? = null
    var onTitleChangedListener: ((String) -> Unit)? = null
    var onProgressChangedListener: ((Int) -> Unit)? = null
    var onNewTabRequestedListener: ((String) -> Unit)? = null
    // BUG GỐC THẬT SỰ của "download kẹt ở vài trăm byte" (khớp chính xác
    // ảnh chụp "Downloads (IDM)" — tên nội bộ của DIALOG TẢI FILE CỦA
    // CHÍNH APP NÀY, KHÔNG PHẢI app Internet Download Manager bên thứ 3
    // như từng nhầm tưởng — xem comment ở
    // `DownloadEngine.downloadFileBlocking()`: "không cần hiện lên danh
    // sách IDM" tự xác nhận điều này):
    //
    // TỰ SỬA LẠI PHẠM VI (người dùng chỉ ra đúng — tài liệu dự án ghi rõ
    // TRƯỚC ĐÂY tải video YouTube thành công qua CHÍNH DownloadEngine này,
    // dùng OkHttp KHÔNG hề có cookie — nếu "thiếu cookie luôn làm hỏng mọi
    // download" là đúng thì YouTube đã KHÔNG BAO GIỜ tải được, mâu thuẫn
    // với lịch sử thật). Đính chính: KHÔNG PHẢI "mọi download đều hỏng vì
    // thiếu cookie" — URL video YouTube lấy qua NewPipeExtractor là URL
    // CDN CÔNG KHAI, có token/chữ ký tự xác thực RIÊNG trong chính URL
    // (không cần cookie trình duyệt), nên luôn tải được qua OkHttp bình
    // thường như trước giờ, KHÔNG BỊ ẢNH HƯỞNG bởi thiếu cookie. Phạm vi
    // bug THẬT hẹp hơn: CHỈ ảnh hưởng file cần ĐĂNG NHẬP mới tải được (như
    // export của claude.ai) — loại này MỚI cần cookie phiên trình duyệt để
    // server xác thực, và đây đúng là loại code cũ KHÔNG truyền được (đã
    // grep xác nhận: 0 kết quả "cookie" trong toàn bộ DownloadEngine.kt,
    // mọi lệnh gọi startDownload() đều không truyền headers). Với loại
    // file này, server trả về trang lỗi/redirect NHỎ (khớp đúng "132 B"
    // thấy trong ảnh) thay vì file thật.
    //
    // Đã xác nhận `WebResponse.body` là InputStream công khai, ổn định lâu
    // năm (cross-check gecko-dev GitHub + Fossies + javadoc, đều khớp) —
    // dùng THẲNG bytes GeckoView đã tải sẵn (VỚI cookie phiên trình duyệt
    // thật, vì chính GeckoView làm request đó) cho ĐÚNG những trường hợp
    // cần đăng nhập này, KHÔNG đụng gì tới luồng YouTube/file công khai
    // đang hoạt động tốt (vẫn giữ nguyên `onDownloadRequestedListener` cũ
    // làm fallback cho các trường hợp response.body null hoặc không đi
    // qua onExternalResponse).
    var onDownloadRequestedListener: ((String, String) -> Unit)? = null

    /** Một lượt tải đang CHỜ người dùng trả lời (chưa đọc byte nào). `start(onFailure)` bắt đầu đọc; `cancel()` đóng luồng. */
    class AskedDownload(
        val uri: String,
        val fileName: String,
        val start: (onFailure: () -> Unit) -> Unit,
        val cancel: () -> Unit
    )
    /** Gán thì tải từ trang sẽ HỎI TRƯỚC khi đọc dữ liệu; để null thì dùng đường cũ (đọc ngầm song song với hộp thoại). */
    var onDownloadAskListener: ((AskedDownload) -> Unit)? = null
    var onDownloadBodyReadyListener: ((String, String, String?) -> Unit)? = null
    // Mục 109: người dùng xoá/huỷ tác vụ đang đọc luồng GeckoView từ danh sách "IDM Downloads" => luồng đã đóng, file tạm đã xoá,
    // không còn gì để ghép. Tham số = URI gốc, để MainActivity dọn trạng thái chờ (`pendingBgDownloads`).
    var onDownloadDrainCancelledListener: ((String) -> Unit)? = null

    // TÍNH NĂNG MỚI (người dùng hỏi: "cài extension từ URL có làm giống
    // Firefox/Chrome — vào trang store rồi tải về dùng được không?").
    // Callback cho MainActivity biết kết quả cài addon bắt được từ luồng
    // duyệt web bình thường (`onExternalResponse` phát hiện `.xpi`) — khác
    // `onDownloadStartedListener` vốn dành cho file tải về lưu đĩa thật,
    // addon thì cài thẳng vào Gecko, không lưu file cho người dùng thấy.
    var onAddonInstallResultListener: ((success: Boolean, name: String?, error: String?) -> Unit)? = null

    // Mục 116: GeckoView gọi PromptDelegate.onInstallPromptRequest khi cài addon; app CHƯA TỪNG đặt delegate này nên mọi lần cài
    // (từ file/URL/trang store) đều bị Gecko từ chối — đúng triệu chứng "Xem addon đã cài (0)". Listener này để MainActivity hiện hộp thoại xác nhận
    // quyền. Tham số: tên addon, danh sách quyền/miền, callback(cho phép cài, cho phép trong tab ẩn danh).
    // Mục 119: giao diện DÙNG addon. `addonActions` = nút trên thanh công cụ của từng addon (WebExtension.Action mặc định, cập nhật qua
    // ActionDelegate.onBrowserAction); `click()` làm addon chạy hoặc mở popup (onTogglePopup -> onExtensionPopupListener).
    val addonActions = ConcurrentHashMap<String, WebExtension.Action>()
    /** Mục 143: MỌI addon người dùng đã cài (kể cả addon chạy ngầm KHÔNG có nút toolbar) — nguồn của trạng thái bật/tắt thật (`metaData.enabled`). */
    val addonExtensions = ConcurrentHashMap<String, WebExtension>()
    @Volatile var onAddonActionsChanged: (() -> Unit)? = null
    /** Mục 143: bấm vào addon chạy ngầm (không có nút/popup) — MainActivity quyết định hiện gì (tuỳ chọn của addon hoặc Trung tâm addon). */
    @Volatile var onAddonWithoutAction: ((String) -> Unit)? = null
    var onExtensionPopupListener: ((title: String, popup: GeckoSession) -> Unit)? = null
    var onAmoInstallRequestListener: ((slug: String) -> Unit)? = null
    /** Mục 125: bản tin `colab_status` từ content.js (tabId, JSON). */
    var onColabStatusListener: ((tabId: String, json: JSONObject) -> Unit)? = null

    // Mục 127 — ADDON "KHÔNG DÙNG ĐƯỢC": tra tài liệu GeckoView (WebExtensionController.setTabActive: "Notifies extensions about a active tab change over the
    // `tabs.onActivated` event"; Fenix gọi nó mỗi khi chọn tab). App này CHƯA TỪNG gọi nên với mọi addon thì `tabs.query({active:true})`/`activeTab` không có tab
    // nào đang active => addon dạng popup (Cookie-Editor, uBlock, VPN...) mở lên không biết đang ở trang nào và không làm được gì. Thêm: báo tab active mỗi khi
    // chuyển tab, và TabDelegate (`tabs.create`, `runtime.openOptionsPage`) để addon mở được tab/trang tuỳ chọn.
    private var lastActiveForExt: GeckoSession? = null
    var onExtensionTabListener: ((tabId: String) -> Unit)? = null

    private fun markActiveForExtensions(session: GeckoSession?) {
        try {
            val ctl = runtime.webExtensionController
            val prev = lastActiveForExt
            if (prev != null && prev !== session) ctl.setTabActive(prev, false)
            if (session != null) ctl.setTabActive(session, true)
            lastActiveForExt = session
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [addon] setTabActive LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private val addonTabDelegate = object : WebExtension.TabDelegate {
        override fun onNewTab(source: WebExtension, createDetails: WebExtension.CreateTabDetails): GeckoResult<GeckoSession>? {
            return try {
                // Mục 128: log 20:39:12 — VPN gọi tabs.create nhưng tab mới ĐỨNG Ở about:blank, không bao giờ tải URL của addon. Tài liệu:
                // "onNewTab returns a *newly-created* session that GeckoView will use to load the requested page on" — GeckoView TỰ MỞ và TỰ ĐIỀU HƯỚNG
                // session trả về; session đã mở sẵn bị từ chối (cùng lỗi "Must use an unopened GeckoSession" đã gặp ở popup window.open, xem onNewSession).
                // Trước đây mình gọi createTab("about:blank") => session ĐÃ MỞ. Sửa: tạo session chưa mở + đăng ký tab y như nhánh popup.
                val uri = createDetails.url ?: "about:blank"
                val tabId = UUID.randomUUID().toString()
                val opener = activeTabId
                val s = createSessionUnopened(false)
                val t = BrowserTab(id = tabId, url = uri, isPrivate = false, openerTabId = opener)
                tabs[tabId] = s
                tabMeta[tabId] = t
                if (opener != null) inheritGroupFromOpener(t, opener)
                insertTabOrder(tabId, opener, sameOpenerRun = true)
                normalizePrivateOrder()
                DebugLog.log("Khe $slotIndex: [addon] '${source.id}' gọi tabs.create url=$uri active=${createDetails.active} -> tab ${tabId.take(8)} (session chưa mở)")
                if (createDetails.active != false) handler.post { onExtensionTabListener?.invoke(tabId) }
                GeckoResult.fromValue(s)
            } catch (e: Throwable) {
                DebugLog.log("Khe $slotIndex: [addon] onNewTab LỖI ${e.javaClass.simpleName}: ${e.message}")
                null
            }
        }
        override fun onOpenOptionsPage(source: WebExtension) {
            val u = source.metaData?.optionsPageUrl
            DebugLog.log("Khe $slotIndex: [addon] '${source.id}' mở trang tuỳ chọn: $u")
            if (u.isNullOrBlank()) return
            try { val t = createTab(u); handler.post { onExtensionTabListener?.invoke(t.id) } } catch (e: Throwable) {
                DebugLog.log("Khe $slotIndex: [addon] mở trang tuỳ chọn LỖI ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    private val addonActionDelegate = object : WebExtension.ActionDelegate {
        override fun onBrowserAction(extension: WebExtension, session: GeckoSession?, action: WebExtension.Action) {
            DebugLog.log("Khe $slotIndex: [addon] '${extension.id}' browserAction title='${action.title}' enabled=${action.enabled} badge='${action.badgeText}' ${if (session == null) "(mặc định)" else "(riêng cho 1 tab)"}")
            if (session == null) {
                addonActions[extension.id] = action
                handler.post { onAddonActionsChanged?.invoke() } // Mục 139: MainActivity cập nhật chỉ báo addon trên thanh khe
            } else {
                // Mục 140: trạng thái RIÊNG của tab (browserAction.setIcon/setBadgeText/enable/disable({tabId})) — nguồn của "biểu tượng xám/xanh theo tab" như PC.
                val tid = tabIdFor(session)
                if (tid != null) {
                    tabAddonActions.getOrPut(tid) { ConcurrentHashMap() }[extension.id] = action
                    handler.post { onAddonActionsChanged?.invoke() }
                }
            }
        }
        override fun onTogglePopup(extension: WebExtension, action: WebExtension.Action): GeckoResult<GeckoSession>? = openExtensionPopup(extension, action)
        override fun onOpenPopup(extension: WebExtension, action: WebExtension.Action): GeckoResult<GeckoSession>? = openExtensionPopup(extension, action)
    }

    private fun openExtensionPopup(extension: WebExtension, action: WebExtension.Action): GeckoResult<GeckoSession>? {
        DebugLog.log("Khe $slotIndex: [addon] '${extension.id}' yêu cầu mở popup (title='${action.title}')")
        popupNeedsSharedCookies = false
        popupUsesCookiesApi = false
        try {
            // GeckoView 145: MetaData KHÔNG có `permissions` (build 51 lỗi "Unresolved reference 'permissions'"); tên đúng là requiredPermissions + grantedOptionalPermissions.
            val md = extension.metaData
            val perms = (md?.requiredPermissions?.toList() ?: emptyList()) + (md?.grantedOptionalPermissions?.toList() ?: emptyList())
            if (perms.contains("cookies")) popupUsesCookiesApi = true
            if (perms.contains("cookies") && !CookieModeMigration.isShared(context, slotIndex)) {
                popupNeedsSharedCookies = true
                DebugLog.log("Khe $slotIndex: [addon] '${extension.id}' DÙNG API cookies nhưng khe đang ở chế độ cookie CÔ LẬP (contextId): addon sẽ thấy 0 cookie " +
                    "(đã xác nhận bằng Cookie-Editor trống). Bật \"Cho addon thấy cookie\" trong Trung tâm addon.")
            }
        } catch (e: Throwable) { /* bỏ qua */ }
        // Mục 133: addon VPN "không hoạt động" mà log không nói được vì sao => ghi TOÀN BỘ metaData (quyền, miền, chế độ ẩn danh, bật/tắt...) bằng reflection
        // (không phụ thuộc tên trường nào có ở GeckoView 145 nên không thể gây lỗi biên dịch).
        try {
            val md = extension.metaData
            if (md != null) {
                val sb = StringBuilder()
                md.javaClass.fields.forEach { f ->
                    try {
                        val v = f.get(md)
                        // 7.69: bỏ xuống dòng + cắt mỗi trường 160 ký tự (fullDescription của addon dài cả trang, mỗi lần mở popup lại ghi 40 dòng)
                        sb.append(f.name).append('=').append((if (v is Array<*>) v.joinToString(",", "[", "]") else v.toString()).replace('\n', ' ').take(160)).append("; ")
                    } catch (e: Throwable) { /* bỏ qua trường không đọc được */ }
                }
                if (metaLogged.add(extension.id)) DebugLog.log("Khe $slotIndex: [addon] '${extension.id}' metaData: $sb")
            }
        } catch (e: Throwable) { /* chỉ là chẩn đoán */ }
        // Mục 134: `proxy.settings` KHÔNG được hỗ trợ trên Android (mã nguồn Firefox ext-proxy.js ném lỗi), chỉ `proxy.onRequest` chạy được. Quét bản sao .xpi đã lưu
        // để biết addon VPN dùng API nào (đếm chuỗi trong .js/.html; mã bị rút gọn kiểu proxy["settings"] sẽ không thấy).
        val scanId = extension.id
        try { ensureApiProbe() } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [probe API] không khởi động được: ${e.message}") }
        Thread { DebugLog.log("Khe $slotIndex: [addon] '$scanId' quét mã API proxy: ${scanAddonProxyApis(scanId)}") }.start()
        val l = onExtensionPopupListener ?: return null
        return try {
            val popup = GeckoSession()
            popup.progressDelegate = object : GeckoSession.ProgressDelegate {
                override fun onPageStart(session: GeckoSession, url: String) { DebugLog.log("Khe $slotIndex: [addon] popup '${extension.id}' bắt đầu tải: $url") }
                override fun onPageStop(session: GeckoSession, success: Boolean) { DebugLog.log("Khe $slotIndex: [addon] popup '${extension.id}' tải xong success=$success") }
            }
            popup.promptDelegate = WebPromptHandler.delegateFor(context, slotIndex) // Mục 165: dropdown trong popup addon (FastTube...) mới bấm được
            popup.open(runtime)
            l(action.title ?: extension.metaData?.name ?: extension.id, popup)
            GeckoResult.fromValue(popup)
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [addon] mở popup của ${extension.id} LỖI ${e.javaClass.simpleName}: ${e.message}")
            null
        }
    }

    /** Mục 130: xoá cookie + dữ liệu DOM + cache của MIỀN GỐC (mọi vùng contextId) — có hiệu lực ngay. Gọi trên luồng chính. */
    fun clearSiteData(baseDomain: String, cookiesOnly: Boolean = false, onDone: (Boolean, String?) -> Unit) {
        try {
            // Mục 133: `cookiesOnly` = chỉ xoá cookie (nút "Xoá cookie"), giữ localStorage/IndexedDB/cache.
            val flags = if (cookiesOnly) StorageController.ClearFlags.COOKIES
                else StorageController.ClearFlags.COOKIES or StorageController.ClearFlags.DOM_STORAGES or StorageController.ClearFlags.ALL_CACHES
            runtime.storageController.clearDataFromBaseDomain(baseDomain, flags).accept(
                { DebugLog.log("Khe $slotIndex: [Cookie] đã xoá cookie+dữ liệu của $baseDomain"); onDone(true, null) },
                { e -> DebugLog.log("Khe $slotIndex: [Cookie] xoá dữ liệu $baseDomain LỖI ${e?.message}"); onDone(false, e?.message) }
            )
        } catch (e: Throwable) { onDone(false, e.message) }
    }

    /** Gắn ActionDelegate cho một addon (gọi khi vừa cài hoặc khi liệt kê). Addon dựng sẵn của app bị bỏ qua. */
    fun registerAddonActionDelegate(ext: WebExtension) {
        if (ext.isBuiltIn || ext.id.endsWith("@colablive.internal")) return
        try { ext.setTabDelegate(addonTabDelegate) } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [addon] setTabDelegate(${ext.id}) LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
        try { ext.setActionDelegate(addonActionDelegate) } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [addon] setActionDelegate(${ext.id}) LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /**
     * Mục 144: theo GeckoView API (WebExtensionController.AddonManagerDelegate) engine được báo KHI addon bật/tắt/cài — dùng để thanh addon
     * đổi trạng thái ngay (trước đây chỉ làm mới khi mở Trung tâm addon). Chỉ override các hàm default có trong tài liệu GeckoView.
     */
    fun installAddonManagerDelegate() {
        try {
            runtime.webExtensionController.setAddonManagerDelegate(object : WebExtensionController.AddonManagerDelegate {
                override fun onEnabled(extension: WebExtension) { refreshAddonListQuietly("onEnabled ${extension.id}") }
                override fun onDisabled(extension: WebExtension) { refreshAddonListQuietly("onDisabled ${extension.id}") }
                override fun onInstalled(extension: WebExtension) { refreshAddonListQuietly("onInstalled ${extension.id}") }
                override fun onReady(extension: WebExtension) { refreshAddonListQuietly("onReady ${extension.id}") }
            })
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [addon] setAddonManagerDelegate LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun refreshAddonListQuietly(why: String) {
        DebugLog.log("Khe $slotIndex: [addon] AddonManagerDelegate: $why — làm mới danh sách")
        handler.post { try { registerAddonActionDelegates { } } catch (e: Throwable) {} }
    }

    /** Liệt kê addon THẬT của hồ sơ + gắn ActionDelegate cho từng cái; callback chạy trên luồng chính. */
    fun registerAddonActionDelegates(onDone: (List<WebExtension>) -> Unit) {
        try {
            runtime.webExtensionController.list().accept({ list ->
                val all = list ?: emptyList()
                all.forEach { registerAddonActionDelegate(it) }
                // Mục 143: danh sách + trạng thái bật/tắt THẬT của addon lấy từ Gecko (không chỉ addon có nút toolbar).
                addonExtensions.clear()
                all.forEach { if (!it.isBuiltIn && !it.id.endsWith("@colablive.internal")) addonExtensions[it.id] = it }
                handler.post { onAddonActionsChanged?.invoke() }
                handler.postDelayed({ onDone(all) }, 300L) // chờ Gecko gửi onBrowserAction đầu tiên
            }, { e ->
                DebugLog.log("Khe $slotIndex: [addon] list() LỖI ${e?.message}")
                handler.post { onDone(emptyList()) }
            })
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [addon] registerAddonActionDelegates LỖI ${e.javaClass.simpleName}: ${e.message}")
            onDone(emptyList())
        }
    }

    var onAddonInstallPromptListener: ((name: String, permissions: List<String>, respond: (allow: Boolean, allowPrivate: Boolean) -> Unit) -> Unit)? = null

    /**
     * Phát hiện + cài addon NGAY khi người dùng bấm nút cài trên 1 trang
     * addon THẬT (vd. addons.mozilla.org) — thay vì để rơi vào luồng tải
     * file thông thường. Gọi từ `onExternalResponse` khi phát hiện Content-
     * Type/đuôi file là `.xpi`.
     */
    // ===================== Mục 120: cài addon ĐÚNG luồng + addon đi theo hồ sơ (backup/import) =====================
    // BUG THẬT (log 21:47/21:49 "handleExtensionDownloadResponse() lỗi tải/cài: Must have a Handler"): `install()` bị gọi trong `Thread {}` không có
    // Looper => `GeckoResult.accept()` ném IllegalThreadStateException("Must have a Handler"). Gecko VẪN cài addon (log có "xin xác nhận cài" rồi
    // trang options của addon mở), nhưng mọi callback sau cài bị bỏ: không gắn ActionDelegate (nút/popup), không ghi danh sách, không báo kết quả.
    // Sửa: mọi lời gọi `install()` đi qua `installAddonFile()` — chạy trên `handler` (luồng chính).
    private val pendingRestoreAllowPrivate = ConcurrentHashMap<String, Boolean>()
    @Volatile private var lastPromptAllowPrivate = false

    /** Thư mục lưu BẢN SAO .xpi + index trong hồ sơ => `zipDirRecursive` nén theo backup như `colablive_logins.json`. */
    private fun addonStoreDir(): java.io.File {
        val ns = ProfileSlots.getSlotAssignment(context, slotIndex)
        val d = java.io.File(context.filesDir, "gecko_profile_" + ns.replace(Regex("[^a-zA-Z0-9_-]"), "_") + "/colablive_addons")
        d.mkdirs()
        return d
    }
    private fun addonIndexFile() = java.io.File(addonStoreDir(), "index.json")
    private fun readAddonIndex(): org.json.JSONObject = try { org.json.JSONObject(addonIndexFile().readText()) } catch (e: Exception) { org.json.JSONObject() }

    private fun rememberAddon(ext: WebExtension, xpi: java.io.File) {
        try {
            val safe = ext.id.replace(Regex("[^A-Za-z0-9_.@-]"), "_")
            val dest = java.io.File(addonStoreDir(), "$safe.xpi")
            if (xpi.absolutePath != dest.absolutePath) xpi.copyTo(dest, overwrite = true)
            val idx = readAddonIndex()
            idx.put(ext.id, org.json.JSONObject()
                .put("file", dest.name)
                .put("name", ext.metaData?.name ?: ext.id)
                .put("allowPrivate", lastPromptAllowPrivate || ext.metaData?.allowedInPrivateBrowsing == true))
            addonIndexFile().writeText(idx.toString())
            DebugLog.log("Khe $slotIndex: [addon] đã lưu bản sao '${ext.id}' vào hồ sơ (${dest.length()} byte) — đi theo backup/import")
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [addon] LƯU bản sao addon vào hồ sơ LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    fun forgetAddon(id: String) {
        addonExtensions.remove(id); addonActions.remove(id)
        for (m in tabAddonActions.values) m.remove(id)
        handler.post { onAddonActionsChanged?.invoke() }
        try {
            val idx = readAddonIndex()
            val rec = idx.optJSONObject(id)
            if (rec != null) { java.io.File(addonStoreDir(), rec.optString("file")).delete(); idx.remove(id); addonIndexFile().writeText(idx.toString()) }
            val csv = AppPrefs.getString(context, slotIndex, "installed_addons_csv", "")
            AppPrefs.setString(context, slotIndex, "installed_addons_csv", csv.split("|").filter { it.isNotBlank() && !it.startsWith("$id::") }.joinToString("|"))
        } catch (e: Throwable) { /* không quan trọng */ }
    }

    /** Cài một file .xpi. LUÔN chạy trên luồng chính (xem chú thích trên). */
    fun installAddonFile(file: java.io.File) {
        handler.post {
            try {
                runtime.webExtensionController.install("file://${file.absolutePath}").accept(
                    { ext ->
                        val name = ext?.metaData?.name ?: file.name
                        if (ext != null) {
                            registerAddonActionDelegate(ext)
                            rememberAddon(ext, file)
                            val existing = AppPrefs.getString(context, slotIndex, "installed_addons_csv", "")
                            if (!existing.split("|").any { it.startsWith("${ext.id}::") }) {
                                AppPrefs.setString(context, slotIndex, "installed_addons_csv", if (existing.isBlank()) "${ext.id}::$name" else "$existing|${ext.id}::$name")
                            }
                        }
                        onAddonInstallResultListener?.invoke(ext != null, name, null)
                    },
                    { error ->
                        DebugLog.log("Khe $slotIndex: [addon] cài addon thất bại: ${error?.message}")
                        onAddonInstallResultListener?.invoke(false, null, error?.message)
                    }
                )
            } catch (e: Throwable) {
                DebugLog.log("Khe $slotIndex: [addon] install() ném ${e.javaClass.simpleName}: ${e.message}")
                onAddonInstallResultListener?.invoke(false, null, e.message)
            }
        }
    }

    /** Sau import/cài lại, Gecko có thể không còn addon (extensions.json/addonStartup hỏng, hoặc backup cũ) => cài lại từ bản sao trong hồ sơ. */
    private fun restoreMissingAddons(existing: List<WebExtension>) {
        try {
            val idx = readAddonIndex()
            val have = existing.map { it.id }.toSet()
            val ids = idx.keys().asSequence().toList()
            DebugLog.log("Khe $slotIndex: [addon] hồ sơ lưu ${ids.size} addon (colablive_addons), Gecko đang có ${existing.count { !it.isBuiltIn }} addon người dùng")
            // Mục 134: addon VPN/proxy bật sẵn lúc mở khe => IP ra ngoài có thể đổi mà không ai để ý; Google đăng xuất khi IP đổi đột ngột. Ghi lại để đối chiếu với log "văng đăng nhập".
            try {
                val proxyAddons = existing.filter { !it.isBuiltIn && it.metaData?.requiredPermissions?.contains("proxy") == true }.map { it.metaData?.name ?: it.id }
                if (proxyAddons.isNotEmpty()) DebugLog.log("Khe $slotIndex: [addon] LƯU Ý: addon có quyền proxy đang bật lúc mở khe: $proxyAddons — nếu đang kết nối VPN thì IP ra ngoài đã đổi (Google có thể đăng xuất)")
            } catch (e: Throwable) { /* chỉ là chẩn đoán */ }
            for (id in ids) {
                if (id in have) continue
                val rec = idx.optJSONObject(id) ?: continue
                val f = java.io.File(addonStoreDir(), rec.optString("file"))
                if (!f.isFile) { DebugLog.log("Khe $slotIndex: [addon] thiếu file bản sao của '$id' — bỏ qua"); continue }
                pendingRestoreAllowPrivate[id] = rec.optBoolean("allowPrivate", false)
                DebugLog.log("Khe $slotIndex: [addon] Gecko KHÔNG có '$id' — khôi phục từ bản sao trong hồ sơ")
                installAddonFile(f)
            }
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [addon] restoreMissingAddons LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    // Mục 127: log 17:55:50–52 — CÙNG một link .xpi bị tải/cài 5 lần liên tiếp (trang AMO điều hướng lặp) => 6 hộp "Gecko xin xác nhận cài" và
    // "cài addon thất bại: null" 2 lần. Chỉ nhận MỘT lần cho mỗi link trong 25s.
    private val recentExtDownloads = ConcurrentHashMap<String, Long>()

    private fun handleExtensionDownloadResponse(uri: String, body: java.io.InputStream?) {
        val nowMs = System.currentTimeMillis()
        val last = recentExtDownloads[uri]
        if (last != null && nowMs - last < 25_000L) {
            DebugLog.log("Khe $slotIndex: [addon] bỏ qua lần tải trùng .xpi (${nowMs - last}ms trước): $uri")
            try { body?.close() } catch (e: Throwable) {}
            return
        }
        recentExtDownloads[uri] = nowMs
        Thread {
            var tempFile: java.io.File? = null
            try {
                val tempDir = java.io.File(context.cacheDir, "addon_tmp").apply { mkdirs() }
                tempFile = java.io.File(tempDir, "addon_${System.currentTimeMillis()}.xpi")
                if (body != null) {
                    body.use { input -> tempFile.outputStream().use { output -> input.copyTo(output) } }
                } else {
                    // body null (hiếm — xem chú thích ở onExternalResponse
                    // chỗ khác): tự tải lại qua HttpURLConnection thay vì bó
                    // tay, vẫn đúng cho addon công khai.
                    val conn = java.net.URL(uri).openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 15_000
                    conn.readTimeout = 30_000
                    conn.inputStream.use { input -> tempFile.outputStream().use { output -> input.copyTo(output) } }
                }
                installAddonFile(tempFile) // chạy trên luồng chính — xem Mục 120
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: handleExtensionDownloadResponse() lỗi tải/cài: ${e.message}")
                handler.post { onAddonInstallResultListener?.invoke(false, null, e.message) }
            }
        }.start()
    }

    /**
     * BUG THẬT đã tìm ra (người dùng chất vấn đúng: "vậy là không giống
     * Chrome hỏi trước tải sau à?"): thiết kế cũ hỏi `SaveLocationDialog`
     * SAU KHI `onDownloadBodyReadyListener` bắn ra (tức sau khi đã drain
     * XONG HẲN response.body vào file tạm) — với file lớn (VD 692MB thấy
     * trong log thật), người dùng phải CHỜ TOÀN BỘ quá trình tải xong mới
     * được hỏi tên/nơi lưu, khác hẳn Chrome (hỏi/hiện ngay khi bắt đầu).
     *
     * Ràng buộc kỹ thuật THẬT (không đổi được): `response.body` của
     * GeckoView tự hết hạn sau ~30s nếu không đọc — nên KHÔNG THỂ đợi
     * người dùng tương tác dialog xong rồi MỚI bắt đầu đọc stream (dialog
     * modal có thể mở lâu hơn 30s). Nhưng ràng buộc đó chỉ bắt buộc phải
     * BẮT ĐẦU ĐỌC STREAM NGAY — không bắt buộc phải HỎI SAU. Có thể tách
     * 2 việc chạy SONG SONG: bắt đầu drain ngay (như cũ, không đổi) VÀ
     * đồng thời hỏi dialog NGAY (không đợi drain xong) — khi CẢ HAI xong
     * (dialog có kết quả + file đã drain xong), mới thật sự chuyển file
     * vào đúng nơi. Listener này bắn NGAY LẬP TỨC (trước khi Thread drain
     * bắt đầu) để MainActivity hỏi dialog song song — xem
     * `onDownloadBodyReadyListener` (không đổi tín hiệu, vẫn bắn khi drain
     * xong) và cách MainActivity ghép 2 tín hiệu này lại với nhau.
     */
    var onDownloadStartedListener: ((String, String) -> Unit)? = null
    /**
     * BUG THẬT tìm ra (người dùng báo đúng: "khung chat cho phép thêm
     * nhiều file cùng lúc nhưng thực tế chỉ được nhấn vào thêm có một file
     * thôi"): callback này TRƯỚC ĐÂY chỉ báo `mimeTypes`, KHÔNG hề báo cho
     * `MainActivity` biết trang web có yêu cầu CHỌN NHIỀU FILE hay không
     * (`prompt.type == FilePrompt.Type.MULTIPLE`) — nên `showFilePicker()`
     * không có cách nào biết cần thêm `Intent.EXTRA_ALLOW_MULTIPLE`. Thêm
     * tham số `isMultiple` để MainActivity biết chính xác.
     */
    var onFilePromptListener: ((mimeTypes: Array<String>?, isMultiple: Boolean) -> Unit)? = null
    var onTabSwitchedListener: ((BrowserTab) -> Unit)? = null
    // Mục 109: báo cho UI mỗi khi một tab (không ẩn danh) vừa được đóng, kèm snapshot đầy đủ — MainActivity dùng để hiện thanh
    // "Đã đóng … [Hủy]" kiểu Chrome. Luôn gọi trên luồng chính, SAU khi đã chọn xong tab kế tiếp.
    var onTabClosedListener: ((ClosedTabEntry) -> Unit)? = null

    // Mục 116: cửa sổ "đừng ẩn bàn phím" khi đang xử lý nhấn giữ chọn chữ (xem ImeDebounceDelegate.holdHideUntilUptime).
    @Volatile private var imeHoldUntil = 0L
    fun holdKeyboardHide(ms: Long) {
        imeHoldUntil = maxOf(imeHoldUntil, android.os.SystemClock.uptimeMillis() + ms)
    }
    var onLongPressLinkListener: ((linkUri: String, linkText: String?) -> Unit)? = null
    // FIX BUG THẬT (xác nhận qua code — ContentDelegate chưa từng override
    // onFullScreen): trang gọi Fullscreen API (nút toàn màn hình trên
    // player) không hề được app biết tới để ẩn thanh URL/tab đi — video chỉ
    // "giả vờ" fullscreen bên trong khung page vẫn bị chèn ép bởi UI trình
    // duyệt + CSS zoom desktop-layout còn active, gây vỡ hình/"vướng url"
    // đúng như người dùng mô tả. Xem MainActivity.setupEngine() để biết
    // UI thật sự làm gì khi listener này bắn ra.
    var onFullScreenListener: ((Boolean) -> Unit)? = null

    /**
     * QUAN TRỌNG: chọn 1 LẦN DUY NHẤT cho cả engine (không phải mỗi tab/mỗi
     * lần connect extension) — dùng CHUNG cho cả:
     *   1) UA header HTTP thật (`GeckoSessionSettings.userAgentOverride`, áp
     *      dụng ở `createSession()`)
     *   2) `navigator.userAgent` phía JS (đẩy qua `buildFingerprintConfigMessage()`)
     * Trước đây 2 chỗ này KHÔNG dùng chung 1 nguồn — hệ quả: header HTTP
     * thật (Firefox/GeckoView) và `navigator.userAgent` JS (chuỗi Chrome giả)
     * KHÔNG KHỚP NHAU, một mismatch cực kỳ dễ bị site/anti-bot phát hiện
     * (nhiều hệ thống so sánh trực tiếp UA header với navigator.userAgent).
     * Cache 1 lần còn tránh việc chế độ "fresh" (random mỗi lần) chọn ra 2
     * profile KHÁC NHAU cho HTTP header và JS trong cùng 1 lần mở khe.
     */
    private var cachedProfile: Pair<DeviceProfiles.HardwareProfile, DeviceProfiles.LocaleProfile>? = null
    private var fpSignatureLogged = false
    private val fpSelfTestCount = java.util.concurrent.atomic.AtomicInteger(0)
    /** Mục 167: hồ sơ phần cứng của VÙNG ẨN DANH (cùng loại mobile/desktop với hồ sơ khe để layout/viewport nhất quán); vùng rỗng/không tồn tại => hồ sơ khe. */
    private fun resolveProfileForZone(zoneId: String): Pair<DeviceProfiles.HardwareProfile, DeviceProfiles.LocaleProfile> {
        val base = resolveProfile()
        if (zoneId.isBlank()) return base
        val z = IncognitoZones.get(context, slotIndex, zoneId) ?: return base
        val hw = DeviceProfiles.hardwareProfiles.getOrNull(z.hwIdx) ?: return base
        // Bản 7.64: vùng có thể có ngôn ngữ/múi giờ RIÊNG (localeIdx >= 0), ngược lại theo khe.
        return Pair(hw, DeviceProfiles.localeProfiles.getOrNull(z.localeIdx) ?: base.second)
    }

    /**
     * Bản 7.57 — chẩn đoán "bị đăng xuất": khi trang điều hướng tới đường dẫn đăng xuất (claude.ai/logout?involuntary=1, ...reauth=1), ghi ảnh chụp
     * cấu hình lúc đó. So các dòng này GIỮA các lần (và các bản build) để thấy cái gì ĐỔI: UA/hardware (ua#...), seed canvas, chế độ máy tính, IP/múi giờ.
     * Kết hợp với dòng "[giám sát đăng nhập]" (401, máy chủ xoá/cấp cookie phiên) để biết phía nào đòi đăng nhập lại.
     */
    private fun logLogoutSnapshot(session: GeckoSession, uri: String) {
        try {
            val tid = tabIdFor(session)
            val meta = tid?.let { tabMeta[it] }
            val (hw, _) = resolveProfileForZone(meta?.zoneId ?: "")
            fun h4(x: String) = java.security.MessageDigest.getInstance("SHA-256").digest(x.toByteArray()).take(4).joinToString("") { "%02x".format(it) }
            val seed = AppPrefs.getString(context, slotIndex, "fp_noise_seed", "")
            val g = egressForActiveTab()
            val desktop = session.settings.userAgentMode == GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
            val where = try { android.net.Uri.parse(uri).let { (it.host ?: "") + (it.path ?: "") } } catch (e: Exception) { "?" }
            DebugLog.log("Khe $slotIndex: [giám sát đăng nhập] ⚠ điều hướng tới đường dẫn ĐĂNG XUẤT ($where). Cấu hình lúc này: bản=${BuildMarker.VERSION} " +
                "ẩn danh=${meta?.isPrivate} vùng='${meta?.zoneId ?: ""}' fp_bật=${FingerprintSpoofFeature.isEnabled(context, slotIndex)} " +
                "cookie_chung=${CookieModeMigration.isShared(context, slotIndex)} fp_fresh=${AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)} hw='${hw.name}' ua#${h4(hw.userAgent)} seed#${if (seed.isEmpty()) "KHÔNG" else h4(seed)} " +
                "chế_độ_máy_tính=$desktop IP=${g?.ip ?: "?"} nước=${g?.cc ?: "?"} múi_giờ=${g?.tz ?: "?"} ngôn_ngữ=${g?.lang ?: "?"} geo_tự_khớp=${geoAutoEnabled()}")
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [giám sát đăng nhập] logLogoutSnapshot lỗi ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun resolveProfile(): Pair<DeviceProfiles.HardwareProfile, DeviceProfiles.LocaleProfile> {
        cachedProfile?.let { return it }
        val fresh = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
        val resolved = if (fresh) {
            DeviceProfiles.getRandomProfileFresh()
        } else {
            val profileName = ProfileSlots.getSlotAssignment(context, slotIndex)
            val hwIdx = AppPrefs.getInt(context, slotIndex, "fp_hw_idx", DeviceProfiles.defaultHwIndexForProfile(profileName))
            val localeIdx = AppPrefs.getInt(context, slotIndex, "fp_locale_idx", DeviceProfiles.defaultLocaleIndexForProfile(profileName))
            DeviceProfiles.getProfileByIndex(hwIdx, localeIdx)
        }
        cachedProfile = resolved
        return resolved
    }

    init {
        instances[slotIndex] = this
        setupNativeLoginAutofill()
        setupEvalBridge()
        setupFingerprintExtension()
        // Mục 119: gắn ActionDelegate cho addon đã cài từ phiên trước để nút/popup của chúng dùng được ngay.
        handler.postDelayed({ registerAddonActionDelegates { all -> restoreMissingAddons(all) } }, 5000L)
    }

    // ===== BrowserEngine Implementation =====

    override fun currentUrl(): String? {
        return activeTabId?.let { tabMeta[it]?.url }
    }

    // BUG NGHIÊM TRỌNG đã tìm ra (so sánh trực tiếp code Kotlin ↔ JS, không
    // suy đoán): Kotlin gửi field `"action": "eval"`, JS kiểm tra
    // `msg.type === "eval"` — SAI TÊN FIELD hoàn toàn, điều kiện `if` phía
    // JS KHÔNG BAO GIỜ đúng, script CHƯA TỪNG thực sự được thực thi qua
    // cầu nối này — kể cả `keepPlayingScript` (chống YouTube tự pause) đã
    // tưởng hoạt động trước đây. Sửa: đổi Kotlin sang gửi `"type": "eval"`
    // khớp đúng JS.
    //
    // BUG THỨ 2 (đã nêu ở khai báo `evalCallback` cũ, giờ sửa luôn): 1 biến
    // CALLBACK DUY NHẤT dùng chung cho MỌI lệnh gọi `evaluateJs()` — lệnh
    // gọi SAU (VD `BackgroundMediaFeature.onPageFinished()` gọi không kèm
    // callback) sẽ GHI ĐÈ MẤT callback của lệnh gọi TRƯỚC đang chờ kết quả
    // (VD favicon) trước khi kịp nhận phản hồi bất đồng bộ. Sửa: dùng
    // `requestId` tăng dần + Map để mỗi lệnh gọi có đúng callback riêng,
    // không đá nhau.
    //
    // BUG THẬT tìm thêm được (người dùng chỉ đúng qua ảnh chụp: tab "New
    // chat" của claude.ai hiện icon YouTube — xem chú thích đầy đủ ở
    // content.js): value giờ là Pair<targetTabId, callback> thay vì chỉ
    // callback — để `onPortMessage` (bên dưới) có thể ĐỐI CHIẾU `sourceUrl`
    // (URL THẬT trang đã chạy script, content.js mới thêm) với URL của
    // CHÍNH tab đích, TRƯỚC khi tin kết quả. KHÔNG đổi chữ ký công khai
    // `evaluateJs()`/`evaluateJsForTab()` — mọi nơi gọi hàm này trong toàn
    // bộ codebase (favicon, zoom, video diagnostic, keepPlayingScript...)
    // KHÔNG cần sửa gì, hoàn toàn không ảnh hưởng.
    private val evalCallbacks = java.util.concurrent.ConcurrentHashMap<Int, Pair<String?, (String?) -> Unit>>()
    // MỤC 70.4: mốc thời gian (uptimeMillis) lần gần nhất Gecko báo "slow
    // script" cho từng tab — để onSlowScript() phân biệt "mới báo lần đầu"
    // (cho script cơ hội chạy tiếp) và "vẫn còn treo sau ít nhất 1 lần đã
    // cảnh báo" (tự ngắt, xem chi tiết đánh đổi ở onSlowScript()).
    private val slowScriptLastReportUptime = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val evalRequestIdCounter = java.util.concurrent.atomic.AtomicInteger(0)

    override fun evaluateJs(script: String, callback: ((String?) -> Unit)?) {
        // Mặc định nhắm đúng tab ĐANG XEM — mọi lệnh gọi evaluateJs() thật
        // trong codebase (chẩn đoán video, zoom, favicon, keepPlayingScript
        // chống pause nhạc nền, outerHTML để tải trang) đều chỉ có ý nghĩa
        // với tab người dùng đang thấy, không có nơi nào thật sự cần chạm
        // tới tab nền. Xem `evaluateJsForTab()` nếu sau này cần nhắm tab cụ
        // thể không phải tab active.
        evaluateJsForTab(activeTabId, script, callback)
    }

    // Bản PUBLIC (qua interface) nhắm CỐ ĐỊNH vào 1 tabId cụ thể, không đổi
    // theo tab active dù tab active có đổi giữa chừng khi 1 thao tác dài
    // đang chạy (mục 77 PROJECT_STATUS.md). Đặt tên KHÁC với hàm private
    // `evaluateJsForTab(String?, ...)` bên dưới (dù cùng ý nghĩa) để tránh
    // "platform declaration clash" ở tầng JVM — 2 hàm chỉ khác nhau ở
    // nullability của tham số (`String` so với `String?`) bị XOÁ MẤT khi
    // biên dịch xuống bytecode (JVM không phân biệt nullable/non-null cho
    // kiểu tham chiếu), nên KHÔNG THỂ overload chỉ bằng nullability.
    override fun evaluateJsPinnedToTab(tabId: String, script: String, callback: ((String?) -> Unit)?) {
        evaluateJsForTab(tabId, script, callback)
    }

    /**
     * TÍNH NĂNG MỚI (người dùng yêu cầu) — Tìm trong trang.
     *
     * Dùng `GeckoSession.finder` (kiểu `org.mozilla.geckoview.SessionFinder`)
     * — API TÌM KIẾM NATIVE chính thức của GeckoView, KHÔNG phải tự viết
     * JS quét `document.body.innerText` (cách đó không tô sáng được đúng
     * vị trí thật trên layer render, không xử lý được text trong iframe
     * cross-origin, và không có khái niệm "khớp thứ N/tổng M" sẵn có).
     *
     * `find(searchString, flags)` trả về `GeckoResult<FinderResult>` — mỗi
     * lần gọi lại (kể cả gọi lại với CÙNG searchString để "Tìm tiếp") sẽ tô
     * sáng khớp kế tiếp trên trang thật và trả về đúng chỉ số hiện tại.
     *
     * `flags`: mặc định tìm xuôi (`FINDER_FIND_MATCH_CASE` chỉ set nếu
     * `matchCase=true`), có thể set `FINDER_FIND_BACKWARDS` khi
     * `forward=false` (nút "▲ Tìm lùi").
     */
    override fun findInPage(query: String, forward: Boolean, matchCase: Boolean, callback: ((current: Int, total: Int) -> Unit)?) {
        val tabId = activeTabId
        val session = if (tabId != null) tabs[tabId] else null
        if (session == null) {
            DebugLog.log("findInPage: không có tab active nào — bỏ qua tìm kiếm")
            callback?.invoke(0, 0)
            return
        }
        if (query.isBlank()) {
            // Ô tìm kiếm rỗng — coi như xoá highlight, không tìm gì cả
            // (tránh gọi find("") ra kết quả vô nghĩa trên 1 số bản Gecko).
            session.finder.clear()
            callback?.invoke(0, 0)
            return
        }
        var flags = 0
        // SỬA LỖI BUILD THẬT (build #439 báo "Unresolved reference"):
        // hằng số `FINDER_FIND_BACKWARDS`/`FINDER_FIND_MATCH_CASE` nằm
        // trong class `GeckoSession` (xem javadoc chính thức Mozilla:
        // mozilla.github.io/geckoview/javadoc/.../GeckoSession.html —
        // mục "Finder search flag definitions"), KHÔNG PHẢI trong
        // `SessionFinder` như tôi đoán nhầm ban đầu. `SessionFinder` chỉ
        // chứa `find()`/`clear()`/`getDisplayFlags()`/`setDisplayFlags()`
        // — bản thân các hằng số flag lại định nghĩa ở `GeckoSession`.
        if (!forward) flags = flags or GeckoSession.FINDER_FIND_BACKWARDS
        if (matchCase) flags = flags or GeckoSession.FINDER_FIND_MATCH_CASE
        // BUG THẬT ĐÃ SỬA (người dùng báo: gõ tìm kiếm ra đúng số lượng
        // khớp trong log nhưng KHÔNG THẤY BÔI ĐEN trên trang): theo mã
        // nguồn GeckoView (`SessionFinder` constructor gọi
        // `setDisplayFlags(0)` MẶC ĐỊNH), nếu KHÔNG chủ động gọi
        // `setDisplayFlags()`, GeckoView chỉ "find and SELECT" đúng 1
        // khớp hiện tại (dùng cơ chế text-selection nội bộ, không phải
        // highlight tìm kiếm thật) — các khớp CÒN LẠI trên trang hoàn
        // toàn không được tô màu gì. Phải chủ động bật cờ hiển thị
        // `FINDER_DISPLAY_HIGHLIGHT_ALL` (tô vàng TẤT CẢ khớp cùng lúc,
        // giống Chrome/Firefox desktop) mỗi lần gọi find() — set lại mỗi
        // lần vì initial cờ này reset về 0 khi SessionFinder khởi tạo
        // (theo source `setDisplayFlags(0)` trong constructor).
        try {
            session.finder.setDisplayFlags(GeckoSession.FINDER_DISPLAY_HIGHLIGHT_ALL)
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [Tìm trong trang] setDisplayFlags() lỗi: ${e.message}")
        }
        try {
            session.finder.find(query, flags).accept({ result ->
                if (result != null) {
                    DebugLog.log("Khe $slotIndex: [Tìm trong trang] query='$query' found=${result.found} current=${result.current} total=${result.total}")
                    handler.post { callback?.invoke(result.current, result.total) }
                } else {
                    handler.post { callback?.invoke(0, 0) }
                }
            }, { error ->
                DebugLog.log("Khe $slotIndex: [Tìm trong trang] find() lỗi: ${error?.message}")
                handler.post { callback?.invoke(0, 0) }
            })
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [Tìm trong trang] gọi find() ném exception: ${e.message}")
            callback?.invoke(0, 0)
        }
    }

    override fun clearFindInPage() {
        val tabId = activeTabId
        val session = if (tabId != null) tabs[tabId] else null
        try {
            session?.finder?.clear()
        } catch (e: Exception) {
            DebugLog.log("clearFindInPage: lỗi khi clear() — ${e.message}")
        }
    }

    /**
     * FIX HIỆU NĂNG (bug fan-out — xem chú thích ở khai báo `portTabId`):
     * chỉ gửi script tới port thuộc ĐÚNG `targetTabId`, không broadcast
     * toàn bộ `evalPorts` như trước. `targetTabId = null` (VD chưa có tab
     * active nào, hoặc lúc khởi động) vẫn giữ hành vi broadcast CŨ làm lưới
     * an toàn — tốt hơn là im lặng không chạy gì.
     *
     * FALLBACK AN TOÀN: nếu lọc theo tabId ra 0 port (VD content script
     * mới connect nhưng `port.sender.session` vì lý do nào đó chưa map
     * được — CHƯA XÁC NHẬN có xảy ra thật trên máy hay không, chỉ phòng
     * hờ), broadcast toàn bộ như hành vi cũ thay vì lặng thinh không gửi
     * gì — tránh hồi quy tính năng (thà chậm hơn 1 lượt còn hơn favicon/
     * zoom/chẩn đoán video lại im re như trước khi sửa).
     */
    private fun evaluateJsForTab(targetTabId: String?, script: String, callback: ((String?) -> Unit)?) {
        // Bản 7.69: trang resource:// (Tab mới), about:, moz-extension:, data: KHÔNG chạy được content script eval_bridge => trước đây mỗi lệnh (zoom gộp, favicon...) chờ đủ 15s,
        // phát broadcast tới mọi cổng rồi ghi `evalCallbacks timeout` (log 15:27–15:44 có hàng chục dòng) và giữ closure trong map. Trả null NGAY, không gửi gì.
        val tUrl = targetTabId?.let { tabMeta[it]?.url }
        if (!tUrl.isNullOrEmpty() && !(tUrl.startsWith("http://") || tUrl.startsWith("https://"))) {
            callback?.let { cb -> handler.post { try { cb(null) } catch (_: Throwable) {} } }
            return
        }
        val requestId = evalRequestIdCounter.incrementAndGet()
        if (callback != null) {
            evalCallbacks[requestId] = targetTabId to callback
            // FIX BUG THẬT GÂY CRASH OOM (xác nhận qua log crash thật:
            // OutOfMemoryError ở tầng Java heap sau ~5 tiếng chạy liên tục,
            // KHÔNG phải crash native Gecko — nghĩa là rò rỉ nằm ở phía
            // Kotlin/JVM, không phải native). `evalCallbacks` trước đây CHỈ
            // được dọn ở 1 chỗ DUY NHẤT — khi `onPortMessage` nhận đúng
            // `requestId` khớp. Nếu script gửi đi KHÔNG BAO GIỜ nhận được
            // phản hồi (tab đóng/điều hướng giữa chừng làm port ngắt kết
            // nối trước khi content script kịp trả lời, hoặc fallback
            // broadcast — xem log "[CHẨN ĐOÁN evaluateJs fallback]" xuất
            // hiện CỰC KỲ dày đặc trong log thật — gửi tới port đã chết),
            // closure đó nằm lại trong map VĨNH VIỄN. `pollVideoDiagnostic`
            // tự gọi lại 6 lần/video, `applyZoomCombined`/`fetchFavicon`
            // gọi mỗi lần điều hướng — qua nhiều giờ, số closure tồn đọng
            // đủ lớn để ăn hết heap 256MB (đúng target footprint trong log
            // crash thật) dù mỗi closure riêng lẻ rất nhỏ.
            //
            // Sửa: đặt timeout 15 giây — nếu tới lúc đó vẫn chưa có phản
            // hồi, TỰ DỌN + gọi callback với null (coi như "không có kết
            // quả"), thay vì để treo vô hạn. Giới hạn CỨNG kích thước tối
            // đa của map bất kể nguyên nhân gốc là gì.
            handler.postDelayed({
                evalCallbacks.remove(requestId)?.let { (_, orphaned) ->
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN evalCallbacks timeout] requestId=$requestId không nhận được phản hồi sau 15s — tự dọn để tránh rò rỉ bộ nhớ (xem chú thích ở evaluateJsForTab)")
                    orphaned.invoke(null)
                }
            }, 15_000L)
        }
        val message = JSONObject().apply {
            put("type", "eval")
            put("requestId", requestId)
            put("script", script)
        }
        val dead = mutableListOf<Port>()
        val targetedPorts: Collection<Port> = if (targetTabId != null) {
            evalPorts.filter { portTabId[it] == targetTabId }
        } else {
            evalPorts.toList()
        }
        val portsToSend: Collection<Port> = if (targetTabId != null && targetedPorts.isEmpty()) {
            // Fallback: không có port nào map đúng tab — có thể do
            // port.sender.session chưa kịp gán, hoặc tab vừa tạo session
            // xong content script chưa kịp connect. Broadcast toàn bộ để
            // không mất tính năng, đồng thời log 1 dòng CHẨN ĐOÁN để biết
            // fallback này có thật sự bị hit hay không (chưa test thật).
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN evaluateJs fallback] không có port nào khớp tabId=$targetTabId trong ${evalPorts.size} port đang mở — broadcast toàn bộ (cần xác nhận qua log lần tới có bị hit thường xuyên không)")
            evalPorts.toList()
        } else {
            targetedPorts
        }
        portsToSend.forEach { port ->
            try {
                port.postMessage(message)
            } catch (e: Exception) {
                dead.add(port) // port đã chết (frame unload) — dọn sau, không sửa trong lúc forEach
            }
        }
        dead.forEach {
            evalPorts.remove(it)
            portTabId.remove(it)
        }
    }

    override fun loadUrl(url: String) {
        activeTabId?.let { tabId ->
            tabs[tabId]?.loadUri(url)
            tabMeta[tabId]?.url = url
        }
    }

    // Mục 161: nút Tải lại "như cái vỏ" — log thật cho thấy reload() được gọi (session=có, isLoading=false) nhưng KHÔNG có sự kiện bắt đầu tải nào theo sau.
    // Tra cứu (Mozilla): (a) Bug 1609701 — reload() trên GeckoSession đang KHÔNG hoạt động (setActive(false)) làm session treo, Fenix chỉ reload khi GeckoView đang hiện;
    // (b) Bug 1623712 — `reload(LOAD_FLAGS_BYPASS_CACHE)` hỏng, Firefox Reality phải đổi sang `loadUri(url, flags)`; (c) Fenix #5478 — sau khi tiến trình nội dung chết, "refresh does nothing".
    // Cách làm: luôn đảm bảo tab đang xem ở trạng thái hoạt động, gọi reload() như cũ, rồi sau 1,5 giây nếu KHÔNG có onPageStart mới thì dùng `loadUri(url, BYPASS_CACHE)`.
    private val loadStartCount = java.util.concurrent.ConcurrentHashMap<String, Int>()

    override fun reload() {
        val id = activeTabId
        val session = id?.let { tabs[it] }
        DebugLog.log("Khe $slotIndex: [tải lại] reload() tab=${id?.take(8)} url=${id?.let { tabMeta[it]?.url }} isLoading=${id?.let { tabMeta[it]?.isLoading }} session=${if (session != null) "có" else "KHÔNG CÓ"}")
        if (id == null || session == null) return
        val url = tabMeta[id]?.url
        val before = loadStartCount[id] ?: 0
        try { session.setActive(true) } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [tải lại] setActive(true) lỗi: ${e.message}") }
        try { session.reload() } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [tải lại] session.reload() ném lỗi ${e.javaClass.simpleName}: ${e.message}") }
        handler.postDelayed({
            try {
                if (activeTabId != id || tabs[id] !== session) return@postDelayed
                if ((loadStartCount[id] ?: 0) != before) {
                    DebugLog.log("Khe $slotIndex: [tải lại] OK — trang đã bắt đầu tải sau reload()")
                    return@postDelayed
                }
                val target = (if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) url else null)
                    ?: tabMeta[id]?.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                if (target == null) {
                    DebugLog.log("Khe $slotIndex: [tải lại] reload() KHÔNG làm trang tải và tab không có URL http(s) để nạp lại ($url)")
                    return@postDelayed
                }
                DebugLog.log("Khe $slotIndex: [tải lại] reload() KHÔNG làm trang bắt đầu tải sau 1,5s => nạp lại bằng loadUri(BYPASS_CACHE): $target")
                // Bản GeckoView hiện tại KHÔNG còn `loadUri(uri, flags)` (lỗi build #98: "Too many arguments for loadUri(p0: String)") — dùng `Loader`.
                session.load(GeckoSession.Loader().uri(target).flags(GeckoSession.LOAD_FLAGS_BYPASS_CACHE))
            } catch (e: Throwable) {
                DebugLog.log("Khe $slotIndex: [tải lại] dự phòng loadUri LỖI ${e.javaClass.simpleName}: ${e.message}")
            }
        }, 1500L)
    }

    override fun stop() {
        val id = activeTabId ?: return
        DebugLog.log("Khe $slotIndex: [dừng tải] stop() tab=${id.take(8)} url=${tabMeta[id]?.url} isLoading=${tabMeta[id]?.isLoading}")
        try { tabs[id]?.stop() } catch (e: Exception) { DebugLog.log("Khe $slotIndex: stop() lỗi: ${e.message}") }
        // `onPageStop` có thể không bắn sau khi dừng thủ công (hoặc bắn muộn) — tự hạ cờ để menu/thanh tiến trình không kẹt ở trạng thái "đang tải".
        tabMeta[id]?.isLoading = false
        onProgressChangedListener?.invoke(100)
    }

    override fun goBack(): Boolean {
        val tabId = activeTabId ?: return false
        val session = tabs[tabId] ?: return false
        if (tabMeta[tabId]?.canGoBack == true) {
            session.goBack()
            return true
        }
        return false
    }

    override fun goForward(): Boolean {
        val tabId = activeTabId ?: return false
        val session = tabs[tabId] ?: return false
        if (tabMeta[tabId]?.canGoForward == true) {
            session.goForward()
            return true
        }
        return false
    }

    override fun canGoBack(): Boolean {
        return activeTabId?.let { tabMeta[it]?.canGoBack } ?: false
    }

    override fun canGoForward(): Boolean {
        return activeTabId?.let { tabMeta[it]?.canGoForward } ?: false
    }

    // ===== Multi-Tab =====

    /**
     * BUG THẬT đã sửa — trước giờ KHÔNG có gì lưu lại danh sách tab đang mở
     * cả: `tabs`/`tabMeta` chỉ tồn tại TRONG BỘ NHỚ, mất sạch mỗi khi
     * process chết (đóng app, crash, hay Android tự dọn nền) — khác hẳn
     * Chrome/Firefox thật (luôn tự mở lại đúng các tab đang có sau khi
     * khởi động lại). Người dùng hỏi đúng — đây là tính năng thiếu thật, có
     * thể làm được, không phải hạn chế của GeckoView.
     *
     * Cách làm: lưu URL + tiêu đề của từng tab (KHÔNG lưu lịch sử back/
     * forward/scroll/form đầy đủ của từng tab — muốn vậy cần dùng
     * `GeckoSession.saveState()`/`restoreState()`, API bất đồng bộ phức tạp
     * hơn nhiều, để dành làm sau nếu cần) vào 1 file JSON ngay TRONG thư mục
     * hồ sơ Gecko (đi theo hồ sơ luôn — hồ sơ nào có tab nấy, xuất/nhập hồ
     * sơ cũng mang theo danh sách tab). Lưu mỗi khi danh sách tab thay đổi
     * (mở/đóng tab) + mỗi khi khe mất foreground (`onPause`, xem
     * MainActivity) — không lưu SAU KHI crash được (crash thì không kịp
     * chạy code nữa) nhưng lưu ĐỦ THƯỜNG XUYÊN trước đó nên vẫn khôi phục
     * được gần như đầy đủ sau crash.
     */
    private fun tabStateFile(): File {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, "gecko_profile_" + profileNamespace.replace(Regex("[^a-zA-Z0-9_-]"), "_"))
        dir.mkdirs()
        return File(dir, "saved_tabs.json")
    }

    fun saveTabsState() {
        try {
            val arr = JSONArray()
            // SỬA BUG (chính là nguồn gây "tab lộn xộn sau khôi phục"):
            // dùng `tabOrder` thay vì `tabMeta.values` — xem giải thích ở
            // khai báo `tabOrder`.
            tabOrder.mapNotNull { tabMeta[it] }.forEach { tab ->
                // Tab ẨN DANH không bao giờ được lưu — đúng hành vi Chrome
                // thật (đóng app là mất hẳn, không khôi phục lại lần sau).
                if (tab.url.isNotBlank() && !tab.isPrivate) {
                    arr.put(JSONObject().apply {
                        put("url", tab.url)
                        put("title", tab.title ?: "")
                        put("active", tab.id == activeTabId)
                        // Trạng thái ĐẦY ĐỦ (lịch sử/cuộn/form) nếu có — xem
                        // giải thích lớn ở onSessionStateChange() phía trên.
                        tab.savedState?.let { put("state", it) }
                        // FIX BUG THẬT (người dùng báo: "vuốt tắt app trong
                        // Recent Apps thì group tab biến mất luôn") — TRƯỚC
                        // ĐÂY dòng này KHÔNG TỒN TẠI, groupId chưa bao giờ
                        // được lưu xuống đĩa dù bản thân tab thì có — xem
                        // giải thích đầy đủ ở `TabGroup` (BrowserEngine.kt).
                        tab.groupId?.let { gid -> put("groupId", gid) }
                        if (tab.zoneId.isNotBlank()) put("zoneId", tab.zoneId) // 7.63: vùng bền
                    })
                }
            }
            if (arr.length() == 0 && groups.keys.none { !it.startsWith("__") } && recentlyClosedTabs.isEmpty()) {
                tabStateFile().delete()
                return
            }
            // FIX BUG THẬT (cùng vấn đề "group tab biến mất") — TRƯỚC ĐÂY
            // `groups` (tên/màu từng nhóm) hoàn toàn KHÔNG được ghi ra
            // đâu cả, dù đã có `groupId` gắn trên từng tab ở trên — nếu
            // thiếu phần này, khôi phục lại tab CÓ groupId nhưng không có
            // nhóm thật nào tương ứng để tra tên/màu, coi như vẫn mất
            // nhóm. Ghi kèm toàn bộ danh sách nhóm vào CÙNG 1 file, đổi
            // định dạng file từ JSONArray trần sang JSONObject bọc 2
            // mảng — `restoreTabsIfAny()` có fallback đọc được cả định
            // dạng cũ (JSONArray trần) để không mất tab đã lưu từ bản
            // trước bản vá này.
            val groupsArr = JSONArray()
            groups.values.filter { !it.id.startsWith("__") }.forEach { g ->
                groupsArr.put(JSONObject().apply {
                    put("id", g.id)
                    put("name", g.name)
                    put("colorHex", g.colorHex)
                })
            }
            // TÍNH NĂNG MỚI (mục 74 PROJECT_STATUS.md, người dùng yêu cầu
            // sau khi hỏi lại: "là phần đó luôn đi" — tức muốn "Thẻ đã đóng
            // gần đây" SỐNG SÓT qua khởi động lại app, không chỉ trong 1
            // phiên). Ghi kèm vào CÙNG file `saved_tabs.json`, theo đúng
            // khuôn đã làm với `groups` — không cần file riêng.
            val closedArr = JSONArray()
            recentlyClosedTabs.forEach { entry ->
                closedArr.put(JSONObject().apply {
                    put("entryId", entry.entryId)
                    put("url", entry.url)
                    put("title", entry.title)
                    entry.savedState?.let { put("state", it) }
                    put("closedAt", entry.closedAtMillis)
                    if (entry.zoneId.isNotBlank()) put("zoneId", entry.zoneId)
                })
            }
            val root = JSONObject().apply {
                put("tabs", arr)
                put("groups", groupsArr)
                put("closedTabs", closedArr)
            }
            val tmp = File(tabStateFile().parentFile, "saved_tabs.json.tmp")
            tmp.writeText(root.toString())
            tmp.renameTo(tabStateFile())
        } catch (e: Exception) {
            DebugLog.log("saveTabsState lỗi: ${e.message}")
        }
    }

    /** Trả về `true` nếu đã khôi phục được ít nhất 1 tab (gọi nơi tạo tab
     * đầu tiên lúc khởi động — nếu trả `true` thì KHÔNG tạo thêm tab trang
     * chủ mặc định nữa, xem `MainActivity.setupUI()`). */
    fun restoreTabsIfAny(): Boolean {
        return try {
            val f = tabStateFile()
            if (!f.exists()) return false
            val rawText = f.readText()
            // FIX BUG THẬT (group tab biến mất) — TƯƠNG THÍCH NGƯỢC: file
            // TỪ TRƯỚC bản vá này là 1 JSONArray TRẦN (không có "groups").
            // File TỪ bản vá này trở đi là 1 JSONObject bọc {"tabs":[...],
            // "groups":[...]}. Phân biệt bằng ký tự đầu tiên sau khi bỏ
            // khoảng trắng — không đụng gì tới cách đọc tab cũ, chỉ THÊM
            // khả năng đọc groups nếu có.
            val trimmed = rawText.trimStart()
            val (arr, groupsArr, closedArr) = if (trimmed.startsWith("[")) {
                Triple(JSONArray(rawText), JSONArray(), JSONArray())
            } else {
                val root = JSONObject(rawText)
                Triple(
                    root.optJSONArray("tabs") ?: JSONArray(),
                    root.optJSONArray("groups") ?: JSONArray(),
                    root.optJSONArray("closedTabs") ?: JSONArray()
                )
            }

            // Khôi phục NHÓM TRƯỚC — mỗi tab bên dưới cần tra được tên/màu
            // nhóm thật ngay khi gán lại `groupId`, không phải chờ tạo
            // nhóm "mồ côi" sau đó.
            for (i in 0 until groupsArr.length()) {
                val g = groupsArr.optJSONObject(i) ?: continue
                val gid = g.optString("id", "")
                if (gid.isBlank()) continue
                groups[gid] = TabGroup(
                    id = gid,
                    name = g.optString("name", ""),
                    colorHex = g.optString("colorHex", "#1A73E8")
                )
            }

            // TÍNH NĂNG MỚI (mục 74 PROJECT_STATUS.md) — khôi phục "Thẻ đã
            // đóng gần đây" TRƯỚC dòng `if (arr.length() == 0) return false`
            // bên dưới: nếu không làm vậy, đóng HẾT tab (arr rỗng) rồi mở
            // lại app sẽ mất luôn danh sách này — đúng lúc người dùng nhiều
            // khả năng NHẤT cần mở lại 1 trong các tab vừa đóng.
            recentlyClosedTabs.clear()
            for (i in 0 until closedArr.length()) {
                val c = closedArr.optJSONObject(i) ?: continue
                val url = c.optString("url", "")
                if (url.isBlank()) continue
                recentlyClosedTabs.add(ClosedTabEntry(
                    entryId = c.optString("entryId", UUID.randomUUID().toString()),
                    url = url,
                    title = c.optString("title", ""),
                    savedState = if (c.has("state")) c.optString("state", null) else null,
                    closedAtMillis = c.optLong("closedAt", 0L),
                    zoneId = c.optString("zoneId", "")
                ))
            }

            while (recentlyClosedTabs.size > MAX_RECENTLY_CLOSED_TABS) {
                recentlyClosedTabs.removeAt(recentlyClosedTabs.size - 1)
            }

            if (arr.length() == 0) {
                if (recentlyClosedTabs.isNotEmpty()) {
                    DebugLog.log("Khe $slotIndex: không có tab nào để khôi phục, nhưng đã khôi phục ${recentlyClosedTabs.size} thẻ đã đóng gần đây từ lần trước")
                }
                return false
            }

            var restoredActiveId: String? = null
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val url = obj.optString("url", "")
                if (url.isBlank()) continue
                val isActive = obj.optBoolean("active", false)
                val savedState = if (obj.has("state")) obj.optString("state", null) else null
                val groupId = if (obj.has("groupId")) obj.optString("groupId", null) else null
                // LAZY RESTORE: chỉ load NGAY tab đang active — các tab khác
                // tạo session/metadata nhưng KHÔNG load gì cả, chỉ đánh dấu
                // `needsLoad=true` (lưu vào savedState hoặc url). Khi người
                // dùng switchToTab mới load thật. Trước đây tất cả tab đều
                // gọi restoreState()/loadUri() ngay lập tức → 7 tab = 7 tải
                // cùng lúc, làm chậm máy và tranh nhau băng thông/CPU Gecko.
                // Bản 7.63: tab của VÙNG BỀN được lưu kèm zoneId; vùng đã bị xoá thì tab quay về kho thường.
                val zoneId = obj.optString("zoneId", "").let { z -> if (z.isNotBlank() && IncognitoZones.get(context, slotIndex, z)?.persistent == true) z else "" }
                val tab = if (isActive) {
                    createTabWithState(url, savedState, zoneId)
                } else {
                    createTabLazy(url, savedState, zoneId)
                }
                // Chỉ gán lại nếu nhóm đó THẬT SỰ tồn tại trong `groups` —
                // phòng file bị chỉnh tay/hỏng, groupId trỏ tới nhóm không
                // còn tồn tại (tab "mồ côi" coi như không thuộc nhóm nào,
                // an toàn hơn là hiện 1 nhóm rỗng không tên/không màu).
                if (groupId != null && groups.containsKey(groupId)) {
                    tabMeta[tab.id]?.groupId = groupId
                }
                if (isActive) restoredActiveId = tab.id
            }
            restoredActiveId?.let { switchToTab(it) }
            DebugLog.log("Khe $slotIndex: khôi phục ${arr.length()} tab (kèm ${groups.size} nhóm, ${recentlyClosedTabs.size} thẻ đã đóng gần đây) từ lần trước (lazy — chỉ load tab đang active ngay)")
            true
        } catch (e: Exception) {
            DebugLog.log("restoreTabsIfAny lỗi: ${e.message}")
            false
        }
    }

    /**
     * Tạo tab ở trạng thái CHƯA TẢI (lazy) — session được tạo và đăng ký
     * nhưng KHÔNG gọi `restoreState()` hay `loadUri()`. Nội dung chỉ được
     * tải thật khi `switchToTab()` lần đầu đụng vào tab này (lazy load tại
     * thời điểm user thật sự muốn xem). `savedState` được giữ trong
     * `BrowserTab.savedState` để `switchToTab()` dùng sau khi cần.
     *
     * Cơ chế: `isUnloaded = true` trong metadata — `switchToTab()` kiểm tra
     * cờ này, nếu còn thì load thật ngay tại đó, xoá cờ. Session đã open
     * sẵn (cần thiết để GeckoView không bị null session khi vẽ preview tab
     * trong thanh tab) nhưng chưa có nội dung gì.
     */
    private fun createTabLazy(url: String, savedState: String?, zoneId: String = ""): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        // THẬT SỰ LAZY (sửa lại lần 2 — lần đầu vẫn gọi createSession() ở
        // đây, tức là vẫn spin lên 1 GeckoSession NATIVE thật cho mỗi tab
        // lazy, dù không load URL gì. Tạo native session vẫn tốn CPU/bộ nhớ/
        // GPU surface đáng kể — 7 session cùng lúc vẫn làm chậm máy y hệt
        // như trước, chỉ là không thấy trong log `onLoadRequest` nên tưởng
        // đã sửa xong). KHÔNG tạo GeckoSession ở đây — không đụng gì tới
        // `tabs` map cả. Chỉ lưu metadata (tabMeta/tabOrder). Session THẬT
        // chỉ được tạo trong `switchToTab()` lần đầu tab này được chọn.
        val tab = BrowserTab(id = tabId, url = url, savedState = savedState, zoneId = zoneId).also {
            it.isUnloaded = true
        }
        tabMeta[tabId] = tab
        tabOrder.add(tabId)
        // KHÔNG tạo session, KHÔNG gọi switchToTab, KHÔNG loadUri/restoreState.
        return tab
    }

    /**
     * Giống `createTab()` nhưng khôi phục ĐẦY ĐỦ trạng thái (lịch sử back/
     * forward, vị trí cuộn, dữ liệu form) qua `session.restoreState()` nếu
     * có, thay vì chỉ `loadUri()` mở trang trắng mới. KHÔNG gọi `loadUri()`
     * khi có savedState — `restoreState()` đã tự đưa về đúng trang/lịch sử,
     * gọi thêm `loadUri()` sẽ ĐIỀU HƯỚNG ĐI MẤT trạng thái vừa khôi phục.
     */
    private fun createTabWithState(url: String, savedState: String?, zoneId: String = ""): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        val session = createSession(false, zoneId) // 7.63: tab của vùng bền khôi phục vào ĐÚNG kho cookie của vùng
        val tab = BrowserTab(id = tabId, url = url, savedState = savedState, zoneId = zoneId)

        tabs[tabId] = session
        tabMeta[tabId] = tab
        tabOrder.add(tabId)

        if (activeTabId == null) {
            switchToTab(tabId)
        }

        if (savedState != null) {
            try {
                val state = GeckoSession.SessionState.fromString(savedState)
                if (state != null) {
                    pendingRestoreTabIds.add(tabId)
                    session.restoreState(state)
                    // BUG THẬT tìm ra (người dùng báo tab khôi phục ra trang
                    // trắng about:blank): `restoreState()` có thể "thành
                    // công" (không null, không ném lỗi) nhưng dữ liệu khôi
                    // phục THẬT SỰ không đưa tới đâu cả (dữ liệu cũ/hỏng/
                    // không tương thích phiên bản GeckoView) — không có tín
                    // hiệu đồng bộ nào báo "restore thành công hay thất bại
                    // thật". KHÔNG so sánh `tab.url` với "about:blank" (dễ
                    // sai — `tab.url` được khởi tạo bằng URL đã lưu ngay từ
                    // đầu, nếu restore thất bại HOÀN TOÀN không có sự kiện
                    // điều hướng nào cả thì `tab.url` vẫn giữ nguyên giá trị
                    // ban đầu, không bao giờ thành "about:blank" để so khớp
                    // được). Thay vào đó dùng `pendingRestoreTabIds` — cờ chỉ
                    // được xoá khi `onLocationChange` THẬT SỰ bắn ra (bất kỳ
                    // URL nào) — nếu sau 3s cờ vẫn còn, nghĩa là restore
                    // KHÔNG hề gây ra điều hướng nào cả, mới tự tải lại.
                    handler.postDelayed({
                        if (pendingRestoreTabIds.remove(tabId)) {
                            DebugLog.log("Khe $slotIndex: restoreState() không gây ra điều hướng nào sau 3s — tự tải lại URL đã lưu: $url")
                            session.loadUri(loadableUrlForRestore(url))
                        }
                    }, 3000L)
                } else {
                    session.loadUri(loadableUrlForRestore(url))
                }
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: restoreState lỗi (${e.message}) — tải URL thường thay thế")
                session.loadUri(loadableUrlForRestore(url))
            }
        } else {
            session.loadUri(loadableUrlForRestore(url))
        }
        return tab
    }

    /**
     * LỊCH SỬ DUYỆT WEB — logic thật nằm ở `BrowserHistory.kt` (tách riêng
     * để `HistoryActivity` dùng chung được, không cần 1 GeckoViewEngine
     * đang sống). Ở đây chỉ gọi qua, tự bọc luồng nền cho phần ghi (bài học
     * từ bug "chặn UI thread", mục 8t).
     */
    fun recordHistoryVisit(url: String) {
        Thread { BrowserHistory.recordVisit(context, slotIndex, url) }.start()
    }

    fun updateLastHistoryTitle(url: String, title: String) {
        Thread { BrowserHistory.updateTitle(context, slotIndex, url, title) }.start()
    }

    /**
     * "Xem bằng máy tính" (Desktop Site) — API xác nhận từ code mẫu chính
     * thức Mozilla (`GeckoViewActivity.java`): `session.getSettings()` trả
     * về đối tượng cấu hình CÒN SỐNG (đổi lúc đang chạy, không cần tạo lại
     * session) — `setUserAgentMode()` đổi UA gửi lên server,
     * `setViewportMode()` đổi cách trang tự bố cục (đúng cơ chế "Request
     * Desktop Site" thật của trình duyệt mobile, không chỉ đổi 1 chuỗi UA).
     * Gọi `reload()` sau đó để trang tải lại đúng theo chế độ mới.
     */
    /**
     * Bản 7.62 — UA DESKTOP CÙNG PHIÊN BẢN với UA di động của hồ sơ (Firefox Android bật "Request desktop site" gửi "X11; Linux x86_64"). Trước đây bật "Xem bằng máy tính"
     * XOÁ UA giả => UA đổi từ "Firefox/140 (Android 14; Mobile)" sang UA desktop THẬT của GeckoView "Firefox/145" giữa phiên; log: Drive bị chuyển sang accounts.google.com
     * ngay sau khi bật (Google/Anthropic gắn phiên với UA). Giữ nguyên số phiên bản để danh tính trình duyệt không đổi, chỉ đổi phần nền tảng.
     */
    private fun desktopUaFrom(mobileUa: String): String? {
        val ver = Regex("Firefox/(\\d+(?:\\.\\d+)?)").find(mobileUa)?.groupValues?.get(1) ?: return null
        val rv = Regex("rv:(\\d+(?:\\.\\d+)?)").find(mobileUa)?.groupValues?.get(1) ?: ver
        return "Mozilla/5.0 (X11; Linux x86_64; rv:$rv) Gecko/20100101 Firefox/$ver"
    }

    private fun desktopUaOverrideFor(tabId: String): String? {
        if (!FingerprintSpoofFeature.isEnabled(context, slotIndex)) return null
        return try {
            val (hw, _) = resolveProfileForZone(tabMeta[tabId]?.zoneId ?: "")
            if (hw.category == "desktop") null else desktopUaFrom(hw.userAgent)
        } catch (e: Throwable) { null }
    }

    /**
     * BUG THẬT đã sửa (người dùng hỏi đúng trọng tâm: "có đồng bộ với
     * fingerprint không, hay đầu voi đuôi chuột"): TRƯỚC ĐÂY hàm này chỉ
     * đổi `userAgentMode`/`viewportMode` — KHÔNG đụng gì tới
     * `userAgentOverride` (chuỗi UA giả CỐ ĐỊNH gán lúc tạo session từ hồ
     * sơ fingerprint, xem `createSessionUnopened()`). Vấn đề:
     * `userAgentOverride` LUÔN ưu tiên hơn `userAgentMode` khi cả 2 cùng
     * tồn tại — bật "Xem bằng máy tính" chỉ đổi LAYOUT trang (viewport)
     * nhưng UA HTTP thật gửi lên server VẪN LÀ chuỗi mobile giả ban đầu.
     * Kết quả: vừa "đầu voi đuôi chuột" (trang tự phát hiện qua UA vẫn
     * phục vụ bản mobile dù layout đã đổi desktop) VỪA làm fingerprint TỆ
     * HƠN cả không bật gì (UA nói "mobile" nhưng hành vi render lại là
     * desktop — bất nhất, chính bất nhất này là 1 tín hiệu fingerprint).
     *
     * Sửa: bật desktop thì XOÁ override (dùng UA desktop mặc định thật của
     * GeckoView — nhất quán với layout desktop); tắt thì khôi phục lại
     * đúng UA giả ban đầu theo hồ sơ fingerprint đang chọn (nếu đang bật
     * fingerprint spoof).
     */
    fun toggleDesktopMode(tabId: String? = null): Boolean {
        val id = tabId ?: activeTabId ?: return false
        val session = tabs[id] ?: return false
        val settings = session.settings
        val turningOn = settings.userAgentMode != GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        settings.userAgentMode = if (turningOn) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        settings.viewportMode = if (turningOn) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        if (turningOn) {
            settings.userAgentOverride = desktopUaOverrideFor(id) // 7.62: giữ số phiên bản UA của hồ sơ (null nếu không giả/hồ sơ desktop)
            manualDesktopTabIds.add(id)
            manualMobileTabIds.remove(id)
        } else if (FingerprintSpoofFeature.isEnabled(context, slotIndex)) {
            val (hw, _) = resolveProfileForZone(tabMeta[id]?.zoneId ?: "")
            // Hồ sơ phần cứng là MÁY TÍNH: "về di động" nghĩa là UA di động THẬT (không đặt UA của hồ sơ). Hồ sơ di động: giữ UA di động GIẢ của hồ sơ.
            settings.userAgentOverride = if (hw.category == "desktop") null else hw.userAgent
            manualDesktopTabIds.remove(id)
            manualMobileTabIds.add(id)
        } else {
            settings.userAgentOverride = null
            manualDesktopTabIds.remove(id)
            // Mục 141: đánh dấu cho MỌI trường hợp tắt chủ động — tên miền trong danh sách ngoại lệ (YouTube) cũng bị `applyViewportExceptionForUrl()` ép lại
            // userAgentMode=DESKTOP ở mỗi onLoadRequest, nên không đánh dấu thì bấm TẮT vô hiệu ngay sau lần tải kế tiếp.
            manualMobileTabIds.add(id)
        }
        // FIX BUG THẬT (người dùng hỏi đúng: "trạng thái mở bằng máy tính
        // cho Drive không có backup trong profile, restore lại không thấy
        // bật" — đã xác nhận qua đọc code: `manualDesktopTabIds` TRƯỚC ĐÂY
        // là 1 Set THUẦN TRONG BỘ NHỚ, khoá theo `tabId` (UUID sinh mới mỗi
        // lần mở app/restore) — chưa từng ghi ra đâu cả, nên
        // `ProfileExportImport` (chỉ đọc `AppPrefs.exportNamespace` +
        // thư mục `profile_data/` Gecko) không có cách nào biết để backup.
        // Đây là lỗ hổng cho MỌI domain, không riêng Drive). SỬA: lưu thêm
        // theo DOMAIN (sống sót qua restore, không như tabId) vào AppPrefs
        // — nhờ `exportNamespace`/`importNamespace` đọc TOÀN BỘ key dưới
        // namespace hồ sơ một cách TỔNG QUÁT (xem AppPrefs.kt), chỉ cần ghi
        // vào đây là TỰ ĐỘNG được gồm trong `app_prefs.json` khi backup,
        // không cần sửa gì thêm ở ProfileExportImport.kt. Tự động áp lại
        // khi tab load URL có domain khớp — xem `applyViewportExceptionForUrl()`.
        val host = tabMeta[id]?.url?.let { url ->
            try { android.net.Uri.parse(url).host?.lowercase() } catch (e: Exception) { null }
        }
        if (host != null) {
            val key = "manual_desktop_mode_domains"
            val current = AppPrefs.getString(context, slotIndex, key, "")
                .split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }
            val updated = if (turningOn) {
                if (current.any { it.equals(host, ignoreCase = true) }) current else current + host
            } else {
                current.filterNot { it.equals(host, ignoreCase = true) }
            }
            AppPrefs.setString(context, slotIndex, key, updated.joinToString(","))
            // Mục 141: danh sách domain "di động thủ công" (sống sót qua khởi động lại/backup như danh sách desktop)
            val mKey = "manual_mobile_mode_domains"
            val mCur = AppPrefs.getString(context, slotIndex, mKey, "").split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }
            val mUpd = if (manualMobileTabIds.contains(id)) { if (mCur.any { it.equals(host, ignoreCase = true) }) mCur else mCur + host }
                       else mCur.filterNot { it.equals(host, ignoreCase = true) }
            AppPrefs.setString(context, slotIndex, mKey, mUpd.joinToString(","))
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN desktop thủ công] đã ${if (turningOn) "LƯU" else "GỠ"} domain '$host' vào danh sách persist (manual_desktop_mode_domains) — giờ sẽ được gồm trong backup profile và tự áp lại sau restore")
        }
        session.reload()
        pushFingerprintConfig(session)
        DebugLog.log("Khe $slotIndex: toggleDesktopMode -> ${if (turningOn) "BẬT (UA desktop thật, đã xoá UA giả, đã TẮT giả platform/touch/webgl để tránh bất nhất, tab được đánh dấu THỦ CÔNG — applyViewportExceptionForUrl sẽ bỏ qua tab này ở các lần điều hướng tiếp theo)" else "TẮT (khôi phục UA giả + giả platform/touch/webgl nếu đang bật fingerprint spoof, bỏ đánh dấu thủ công)"}")
        return turningOn
    }

    fun isDesktopMode(tabId: String? = null): Boolean {
        val id = tabId ?: activeTabId ?: return false
        val session = tabs[id] ?: return false
        return session.settings.userAgentMode == GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
    }

    override fun createTab(url: String, isPrivate: Boolean, openerTabId: String?): BrowserTab {
        // Bản 7.63: mở tab thường TỪ tab của vùng bền (vd "Mở trong tab mới") phải ở lại ĐÚNG vùng, không rơi sang kho cookie thường.
        val inheritZone = if (isPrivate) "" else (openerTabId?.let { tabMeta[it]?.zoneId } ?: "").takeIf { isPersistentZone(it) } ?: ""
        val t = createTabInternal(url, isPrivate, openerTabId, inheritZone)
        if (inheritZone.isNotBlank()) adoptIntoZoneGroup(t) // 7.66
        return t
    }

    /** Mục 167: mở tab ẩn danh TRONG một vùng ("" = ẩn danh chung). */
    fun createZoneTab(url: String, zoneId: String, openerTabId: String? = null): BrowserTab {
        // Bản 7.63: vùng BỀN => tab THƯỜNG (isPrivate=false) mang zoneId; vùng ẩn danh/không có vùng => như cũ.
        val persistent = zoneId.isNotBlank() && IncognitoZones.get(context, slotIndex, zoneId)?.persistent == true
        val t = createTabInternal(url, !persistent, openerTabId, zoneId)
        if (persistent) adoptIntoZoneGroup(t) // 7.66
        return t
    }

    /** Bản 7.63: vùng này có phải vùng BỀN không (tab của nó không ẩn danh, dữ liệu ghi xuống đĩa). */
    fun isPersistentZone(zoneId: String): Boolean = zoneId.isNotBlank() && IncognitoZones.get(context, slotIndex, zoneId)?.persistent == true

    private fun createTabInternal(url: String, isPrivate: Boolean, openerTabId: String?, zoneId: String): BrowserTab {
        val tabId = UUID.randomUUID().toString()
        val session = createSession(isPrivate, zoneId)
        // FIX BUG THẬT (người dùng báo qua ảnh/log: "mở 1 tab từ tab A, vuốt
        // back đóng tab vừa mở đó, màn hình lại nhảy về tab 0 chứ không về
        // tab A"). Nguyên nhân: `closeTab()` ĐÃ CÓ SẴN logic đúng — quay về
        // `openerTabId` nếu tab đó còn tồn tại — NHƯNG `createTab()` (hàm
        // NÀY) trước giờ không hề nhận/gán `openerTabId`, nên MỌI tab mở
        // qua đường "Mở trong tab mới" từ menu ngữ cảnh (long-press link)
        // đều có `openerTabId = null` ngay từ đầu, dù người dùng CẢM NHẬN
        // là "mở từ tab A". `openerTabId` trước đây CHỈ được gán ở nhánh
        // popup thật (`window.open()`/`target=\"_blank\"`, xem
        // `onNewSession`) — không phải nhánh phổ biến nhất người dùng
        // thật sự dùng để mở tab mới bằng tay.
        val tab = BrowserTab(id = tabId, url = url, isPrivate = isPrivate, openerTabId = openerTabId, zoneId = zoneId) // 7.63: zoneId cũng có nghĩa với tab THƯỜNG của vùng bền

        tabs[tabId] = session
        tabMeta[tabId] = tab
        if (isPrivate) {
            // Mục 117: tab ẩn danh -> nhóm "Ẩn danh" ở cuối dải tab.
            placePrivateTab(tab)
        } else {
            // Mục 107: tab mới đứng NGAY CẠNH tab đã mở ra nó (hoặc tab đang xem nếu mở bằng nút +), không rơi xuống cuối dãy.
            if (openerTabId != null) inheritGroupFromOpener(tab, openerTabId)
            insertTabOrder(tabId, openerTabId ?: activeTabId, sameOpenerRun = openerTabId != null)
            normalizePrivateOrder() // tab thường không được chen vào khối tab ẩn danh
        }

        if (activeTabId == null) {
            switchToTab(tabId)
        }

        session.loadUri(url)
        saveTabsState()
        return tab
    }

    // TÍNH NĂNG MỚI (người dùng yêu cầu) — kéo-thả đổi vị trí tab, giống
    // Chrome. `tabOrder` là `MutableList<String>` giữ đúng thứ tự hiển
    // thị thật (xem chú thích ở closeTab() — lý do KHÔNG dùng thứ tự của
    // ConcurrentHashMap `tabs`). Chỉ cần xoá `tabId` khỏi vị trí cũ rồi
    // chèn lại đúng `toIndex` — không đụng gì tới session/dữ liệu tab.
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — nhóm tab giống Chrome. Lưu
    // trong RAM (xem chú thích ở `TabGroup` trong BrowserEngine.kt).
    private val groups = mutableMapOf<String, TabGroup>()
    // TÍNH NĂNG MỚI (mục 73 PROJECT_STATUS.md): danh sách tab vừa đóng, mới
    // nhất ở ĐẦU (index 0). Giới hạn số lượng để tránh phình RAM vô hạn khi
    // đóng rất nhiều tab trong 1 phiên dài — `savedState` của tab lịch sử
    // duyệt web dài có thể khá nặng (vài trăm KB nếu scroll/form nhiều).
    private val recentlyClosedTabs = java.util.concurrent.CopyOnWriteArrayList<ClosedTabEntry>()
    private val MAX_RECENTLY_CLOSED_TABS = 15

    override fun createGroup(name: String, colorHex: String): TabGroup {
        val group = TabGroup(id = UUID.randomUUID().toString(), name = name, colorHex = colorHex)
        groups[group.id] = group
        return group
    }

    override fun getGroups(): List<TabGroup> = groups.values.toList()

    override fun setTabGroup(tabId: String, groupId: String?) {
        // Mục 117: tab ẩn danh luôn ở nhóm Ẩn danh; tab thường không vào được nhóm Ẩn danh.
        val t = tabMeta[tabId] ?: return
        if (t.isPrivate) return
        if (groupId == PRIVATE_GROUP_ID) return
        // Bản 7.66: nhóm của vùng bền do app quản lý — chỉ tab của ĐÚNG vùng được ở trong; tab của vùng bền không rời nhóm vùng và không vào nhóm khác.
        if (groupId != null && groupId.startsWith("zone:") && groupId != persistentZoneGroupId(t.zoneId)) return
        if (t.zoneId.isNotBlank() && t.groupId == persistentZoneGroupId(t.zoneId) && groupId != t.groupId) return
        t.groupId = groupId
        saveTabsState()
    }

    /**
     * Mục 131.3: `setTabGroup` bỏ qua tab ẩn danh (mục 117), nên nơi nào "tạo nhóm rồi gán tab" mà mọi tab được gán đều là tab ẩn danh thì nhóm vừa tạo
     * bị RỖNG và nằm lại vô thời hạn. Chỉ xoá ĐÚNG nhóm được chỉ định, và chỉ khi nó không còn tab nào — không quét cả danh sách để khỏi xoá nhầm nhóm
     * rỗng do người dùng cố ý tạo trước (\"Tạo nhóm mới\" rồi thêm tab sau).
     */
    // ===== Mục 140: trạng thái addon THEO TỪNG TAB (như thanh công cụ PC) + IP/quốc gia đi ra tự khớp fingerprint — CƠ CHẾ CHUNG, không riêng VPN =====
    val tabAddonActions = ConcurrentHashMap<String, ConcurrentHashMap<String, WebExtension.Action>>()

    /** `enabled` = addon THẬT SỰ đang bật trong Gecko VÀ nút của nó không bị chính nó tắt cho tab này. `hasAction` = có nút toolbar (addon chạy ngầm thì không). */
    class AddonUiState(val id: String, val title: String?, val badge: String?, val enabled: Boolean, val icon: Any?,
                       val hasAction: Boolean = true, val extEnabled: Boolean = true,
                       /** Mục 144 (kiểu Firefox PC: nút addon xám khi addon KHÔNG có quyền với trang hiện tại): true = có, false = không, null = không áp dụng. */
                       val siteAccess: Boolean? = null)

    // `Action.icon` chưa được code nào dùng nên đọc bằng reflection: tên trường khác thì chỉ mất biểu tượng (có chữ cái thay thế), không hỏng biên dịch.
    private fun readActionIcon(a: WebExtension.Action?): Any? {
        if (a == null) return null
        return try { a.javaClass.getField("icon").get(a) } catch (e: Throwable) {
            try { a.javaClass.getMethod("getIcon").invoke(a) } catch (e2: Throwable) { null }
        }
    }

    /** Trạng thái hiệu lực của mọi addon có nút thanh công cụ cho một tab: giá trị RIÊNG của tab (addon gọi browserAction.xxx({tabId})) nếu có, không thì mặc định. */
    /** Khớp một "match pattern" của WebExtension (scheme://host/path, `*` làm ký tự đại diện) với URL. */
    private fun matchPattern(p: String, url: String): Boolean {
        if (p == "<all_urls>") return Regex("^(https?|ftp|file|wss?)://").containsMatchIn(url)
        val m = Regex("^(\\*|https?|wss?|ftp|file)://([^/]*)(/.*)$").find(p) ?: return false
        val sc = m.groupValues[1]; val host = m.groupValues[2]; val path = m.groupValues[3]
        val u = try { android.net.Uri.parse(url) } catch (e: Exception) { return false }
        val us = u.scheme ?: return false
        if (sc == "*") { if (us != "http" && us != "https") return false } else if (sc != us) return false
        val uh = u.host ?: ""
        val hostOk = when {
            host == "*" -> true
            host.startsWith("*.") -> uh == host.substring(2) || uh.endsWith(host.substring(1))
            else -> uh == host
        }
        if (!hostOk) return false
        val rest = (u.encodedPath ?: "/") + (if (u.encodedQuery != null) "?" + u.encodedQuery else "")
        val rx = Regex("^" + path.split("*").joinToString(".*") { Regex.escape(it) } + "$")
        return rx.matches(rest)
    }

    /** Addon có KHAI BÁO quyền origin (bắt buộc hoặc tuỳ chọn) nhưng không có quyền nào (bắt buộc + đã cấp) khớp URL tab => false. Không khai báo/URL không phải web => null. */
    private fun siteAccessFor(md: WebExtension.MetaData?, url: String?): Boolean? {
        if (md == null || url.isNullOrBlank() || !Regex("^(https?|ftp|file)://").containsMatchIn(url)) return null
        val required = md.requiredOrigins?.toList() ?: emptyList()
        val optional = md.optionalOrigins?.toList() ?: emptyList()
        if (required.isEmpty() && optional.isEmpty()) return null
        val granted = required + (md.grantedOptionalOrigins?.toList() ?: emptyList())
        return granted.any { matchPattern(it, url) }
    }

    fun addonStatesForTab(tabId: String?): List<AddonUiState> {
        val out = ArrayList<AddonUiState>()
        val ids = LinkedHashSet<String>()
        ids.addAll(addonExtensions.keys)
        ids.addAll(addonActions.keys.filter { !it.endsWith("@colablive.internal") && (addonExtensions.isEmpty() || addonExtensions.containsKey(it)) })
        for (id in ids) {
            val ext = addonExtensions[id]
            val md = try { ext?.metaData } catch (e: Throwable) { null }
            val extEnabled = md?.enabled ?: true
            val def = addonActions[id]
            val tab = if (tabId != null) tabAddonActions[tabId]?.get(id) else null
            val actionEnabled = (tab?.enabled ?: def?.enabled) != false
            val title = tab?.title ?: def?.title ?: md?.name
            val badge = (tab?.badgeText ?: def?.badgeText)?.takeIf { it.isNotBlank() }
            val icon = readActionIcon(tab) ?: readActionIcon(def) ?: (try { md?.icon } catch (e: Throwable) { null })
            val access = try { siteAccessFor(md, tabId?.let { tabMeta[it]?.url }) } catch (e: Throwable) { null }
            out.add(AddonUiState(id, title, badge, extEnabled && actionEnabled, icon, hasAction = def != null, extEnabled = extEnabled, siteAccess = access))
        }
        return out.sortedBy { it.title ?: it.id }
    }

    fun clickAddon(tabId: String?, id: String) {
        val a = (if (tabId != null) tabAddonActions[tabId]?.get(id) else null) ?: addonActions[id]
        if (a == null) { onAddonWithoutAction?.invoke(id); return }
        try { a.click() } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [addon] click '$id' lỗi: ${e.message}") }
    }

    @Suppress("UNCHECKED_CAST")
    fun loadIconBitmap(icon: Any, sizePx: Int, cb: (android.graphics.Bitmap?) -> Unit) {
        try {
            val m = icon.javaClass.getMethod("getBitmap", Int::class.javaPrimitiveType)
            val res = m.invoke(icon, sizePx) as GeckoResult<android.graphics.Bitmap>
            res.accept({ bmp -> handler.post { cb(bmp) } }, { _ -> handler.post { cb(null) } })
        } catch (e: Throwable) { handler.post { cb(null) } }
    }

    // --- IP/quốc gia/múi giờ mà trình duyệt ĐI RA NGOÀI bằng (qua cookie_helper, đúng đường mạng của trình duyệt nên VPN/proxy nào cũng được) ---
    class EgressGeo(val ip: String, val cc: String, val tz: String, val lang: String, val langs: List<String>, val approx: Boolean = false, val altIp: String = "") {
        /** Mục 154: hai dịch vụ echo cho hai IP KHÁC nhau (cùng họ IPv4/IPv6) => IP phụ thuộc tên miền (VPN/proxy theo từng trang). */
        val mismatch: Boolean get() = altIp.isNotBlank() && ip.isNotBlank() && altIp != ip && (altIp.contains(':') == ip.contains(':'))
    }
    @Volatile var egressGeo: EgressGeo? = null
    /**
     * Bản 7.69 — GEO THEO LỚP ĐƯỜNG MẠNG. Trước đây chỉ có MỘT `egressGeo` cho cả khe và mọi tab nhận cùng múi giờ/ngôn ngữ; nhưng tab thường (qua VPN/proxy, vd IP Singapore)
     * và tab ẩn danh (đi thẳng, IP Việt Nam — addon VPN không được phép trong ẩn danh, hoặc chế độ proxy ẩn danh "trực tiếp") có IP KHÁC NHAU. Log 15:41–15:44: tab thường đo
     * SG → ĐỔI sang en-SG, mở tab ẩn danh đo VN → ĐỔI lại vi-VN và đẩy cho MỌI tab => "vùng chạy đúng, vùng không". Nay mỗi lớp (thường/ẩn danh) có geo riêng; mỗi tab nhận geo
     * của lớp mình. Chưa đo được geo lớp ẩn danh thì KHÔNG giả (giữ giá trị thật — khớp IP thật), không mượn geo của lớp thường.
     */
    @Volatile var egressGeoPrivate: EgressGeo? = null
    @Volatile private var normalGeoFromTab = false
    private fun geoForClass(isPrivate: Boolean): EgressGeo? = if (isPrivate) egressGeoPrivate else egressGeo
    private fun sessionIsPrivate(session: GeckoSession): Boolean = tabIdFor(session)?.let { tabMeta[it]?.isPrivate } == true
    @Volatile var onEgressChanged: (() -> Unit)? = null
    @Volatile private var lastGeoRefreshAt = 0L

    private fun geoAutoEnabled(): Boolean = AppPrefs.getBoolean(context, slotIndex, "fp_t_locale_auto", true)

    private fun loadCachedGeo() {
        try {
            val tz = AppPrefs.getString(context, slotIndex, "geo_tz", "")
            if (tz.isBlank()) return
            val lang = AppPrefs.getString(context, slotIndex, "geo_lang", "en-US")
            val langs = AppPrefs.getString(context, slotIndex, "geo_langs", lang).split(",").filter { it.isNotBlank() }
            egressGeo = EgressGeo(AppPrefs.getString(context, slotIndex, "geo_ip", ""), AppPrefs.getString(context, slotIndex, "geo_cc", ""), tz, lang, langs)
            DebugLog.log("Khe $slotIndex: [geo] nạp geo đã lưu: quốc gia=${egressGeo?.cc} múi giờ=$tz ngôn ngữ=$lang (sẽ cập nhật khi tra lại)")
        } catch (e: Throwable) { /* chỉ là bộ nhớ đệm */ }
        // Bản 7.65 — LỖ HỔNG: Accept-Language (cài đặt runtime, KHÔNG lưu qua lần chạy) chỉ được đặt khi IP ĐỔI so với bộ nhớ đệm (applyGeoToRuntimeLocales trong nhánh `changed`),
        // nên khởi động lại với IP cũ => header về ngôn ngữ mặc định của máy, lệch với JS (navigator.language theo IP). Nay đặt ngay lúc khởi động từ geo đã lưu.
        applyStartupLanguages()
    }

    /** Bản 7.65: đặt Accept-Language/locales của Gecko lúc khởi động: theo geo đã lưu (nếu tự khớp IP) hoặc theo hồ sơ ngôn ngữ của khe. Chỉ khi bật giả fingerprint. */
    private fun applyStartupLanguages() {
        try {
            if (!FingerprintSpoofFeature.isEnabled(context, slotIndex)) return
            val langs: List<String> = if (geoAutoEnabled()) (egressGeo?.langs ?: return) else resolveProfile().second.languages
            if (langs.isEmpty()) return
            val s = runtime.settings
            s.javaClass.getMethod("setLocales", Array<String>::class.java).invoke(s, langs.toTypedArray())
            DebugLog.log("Khe $slotIndex: [ngôn ngữ] lúc khởi động đặt Accept-Language/locales của Gecko = $langs (${if (geoAutoEnabled()) "theo IP đã lưu" else "theo hồ sơ ngôn ngữ"})")
        } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [ngôn ngữ] không đặt được locales lúc khởi động: ${e.javaClass.simpleName} ${e.message}") }
    }

    // ===== Mục 149: IP đang đi ra, đo TRONG TAB (xem content.js `probeIpViaPage`) =====
    private val tabEgress = ConcurrentHashMap<GeckoSession, EgressGeo>()
    @Volatile private var lastTabProbeAt = 0L
    private val countryLang = mapOf("VN" to "vi-VN", "US" to "en-US", "GB" to "en-GB", "DE" to "de-DE", "FR" to "fr-FR", "JP" to "ja-JP", "KR" to "ko-KR",
        "CN" to "zh-CN", "TW" to "zh-TW", "HK" to "zh-HK", "SG" to "en-SG", "IN" to "en-IN", "RU" to "ru-RU", "UA" to "uk-UA", "TR" to "tr-TR", "BR" to "pt-BR",
        "PT" to "pt-PT", "ES" to "es-ES", "MX" to "es-MX", "IT" to "it-IT", "NL" to "nl-NL", "PL" to "pl-PL", "CA" to "en-CA", "AU" to "en-AU", "TH" to "th-TH",
        "ID" to "id-ID", "MY" to "ms-MY", "PH" to "en-PH", "SE" to "sv-SE", "CH" to "de-CH", "AT" to "de-AT", "BE" to "nl-BE", "IE" to "en-IE", "FI" to "fi-FI",
        "NO" to "nb-NO", "DK" to "da-DK", "CZ" to "cs-CZ", "RO" to "ro-RO", "HU" to "hu-HU", "GR" to "el-GR", "IL" to "he-IL", "AE" to "ar-AE", "SA" to "ar-SA",
        "EG" to "ar-EG", "ZA" to "en-ZA", "AR" to "es-AR", "CL" to "es-CL", "CO" to "es-CO", "LT" to "lt-LT", "LV" to "lv-LV", "EE" to "et-EE")

    /** IP/quốc gia mà tab ĐANG XEM thực sự đi ra (ưu tiên đo trong tab; chưa có thì dùng kết quả tra từ addon nền). */
    fun egressForActiveTab(): EgressGeo? = tabs[activeTabId]?.let { tabEgress[it] } ?: egressGeo

    /** Nhờ content script của tab đang xem đo IP. Tab không có content script (trang about:/new tab/bị loại) -> giữ kết quả cũ. */
    fun probeEgressViaTab() {
        val s = tabs[activeTabId] ?: return
        val port = fingerprintPortsBySession[s] ?: return
        val now = android.os.SystemClock.uptimeMillis()
        if (now - lastTabProbeAt < 6_000L) return
        lastTabProbeAt = now
        try { port.postMessage(JSONObject().put("action", "probeIp")) } catch (e: Throwable) { /* port đã đóng */ }
    }

    private fun onTabIpProbe(session: GeckoSession, m: JSONObject) {
        val err = m.optString("error", "")
        if (err.isNotBlank()) { DebugLog.log("Khe $slotIndex: [geo] đo IP trong tab LỖI (${m.optString("host", "")}): $err"); return }
        val ip = m.optString("ip", ""); val cc = m.optString("cc", "").uppercase(); val tz = m.optString("tz", "")
        if (ip.isBlank()) return
        val approx = m.optString("how", "") != "content.fetch"
        val lang = countryLang[cc] ?: egressGeo?.takeIf { it.cc == cc }?.lang ?: "en-US"
        val alt = m.optString("ip2", "")
        val g = EgressGeo(ip, cc, tz.ifBlank { egressGeo?.tz ?: "" }, lang, listOf(lang, lang.substringBefore('-'), "en-US", "en").distinct(), approx, alt)
        val old = tabEgress.put(session, g)
        DebugLog.log("Khe $slotIndex: [geo] IP đi ra THEO TAB: ip=$ip quốc gia=$cc (cách đo: ${m.optString("how", "?")}${if (approx) " — CHỈ GẦN ĐÚNG" else ""})" +
            (if (alt.isNotBlank()) " | dịch vụ 2 (ipify): $alt${if (g.mismatch) " — LỆCH: IP phụ thuộc tên miền" else " — khớp"}" else " | dịch vụ 2: không đo được"))
        val isActive = tabs[activeTabId] === session
        // Chỉ phép đo CHÍNH XÁC (content.fetch) của tab đang xem mới cập nhật geo toàn cục dùng để tự khớp ngôn ngữ/múi giờ.
        if (isActive && !approx && tz.isNotBlank()) {
            onGeoMessage(JSONObject().put("ip", ip).put("cc", cc).put("tz", tz).put("lang", lang).put("src", "ipwho.is(tab)"), sessionIsPrivate(session))
        }
        if (isActive && (old == null || old.ip != g.ip || old.approx != g.approx || old.altIp != g.altIp)) onEgressChanged?.invoke()
    }

    private fun onGeoMessage(m: JSONObject, isPrivateClass: Boolean = false) {
        val tz = m.optString("tz", "")
        if (tz.isBlank()) return
        val srcTab = m.optString("src", "").contains("(tab)")
        // Phép đo của APP (HTTP trực tiếp, không qua VPN/proxy của tab) chỉ mô tả IP THẬT; nếu lớp thường đã có phép đo TRONG TAB thì bỏ qua để không ghi đè
        // (trước đây hai nguồn này đổi qua lại: tab SG ↔ app VN).
        if (!isPrivateClass && !srcTab && normalGeoFromTab) return
        val arr = m.optJSONArray("langs")
        val langs = ArrayList<String>()
        if (arr != null) for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let { langs.add(it) }
        val lang = m.optString("lang", "").ifBlank { langs.firstOrNull() ?: "en-US" }
        if (langs.isEmpty()) langs.add(lang)
        // Bản 7.69: hai nguồn trả NGÔN NGỮ khác nhau cho cùng một IP (log 17:30–17:32: ipapi.co → "cmn-SG", ipwho.is(tab) → "en-SG", đổi qua lại mỗi ~1 phút và mỗi lần đổi lại
        // đẩy cấu hình cho mọi tab). Quốc gia đã biết thì LUÔN dùng bảng countryLang để kết quả không phụ thuộc nguồn.
        val ccUp = m.optString("cc", "").uppercase()
        val mappedLang = countryLang[ccUp]
        val finalLang = mappedLang ?: lang
        val finalLangs = if (mappedLang != null) listOf(mappedLang, mappedLang.substringBefore('-'), "en-US", "en").distinct() else langs
        val g = EgressGeo(m.optString("ip", ""), m.optString("cc", ""), tz, finalLang, finalLangs)
        val old = geoForClass(isPrivateClass)
        val changed = old == null || old.tz != g.tz || old.lang != g.lang || old.cc != g.cc || old.ip != g.ip
        if (isPrivateClass) {
            egressGeoPrivate = g // không lưu xuống đĩa: tab ẩn danh không để lại dấu vết
        } else {
            egressGeo = g
            if (srcTab) normalGeoFromTab = true
            try {
                AppPrefs.setString(context, slotIndex, "geo_ip", g.ip); AppPrefs.setString(context, slotIndex, "geo_cc", g.cc)
                AppPrefs.setString(context, slotIndex, "geo_tz", g.tz); AppPrefs.setString(context, slotIndex, "geo_lang", g.lang)
                AppPrefs.setString(context, slotIndex, "geo_langs", g.langs.joinToString(","))
                // Mục 162: toạ độ/thành phố theo IP đi ra — để trang Tab mới hiện thời tiết đúng vị trí (ipwho.is không cho trang tự gọi vì không hỗ trợ CORS).
                if (m.has("lat") && m.has("lon") && !m.isNull("lat") && !m.isNull("lon")) {
                    AppPrefs.setString(context, slotIndex, "ntp", "geo_lat", m.optDouble("lat").toString())
                    AppPrefs.setString(context, slotIndex, "ntp", "geo_lon", m.optDouble("lon").toString())
                    AppPrefs.setString(context, slotIndex, "ntp", "geo_city", m.optString("city", ""))
                }
            } catch (e: Throwable) { /* bộ nhớ đệm */ }
        }
        DebugLog.log("Khe $slotIndex: [geo] IP đi ra ngoài${if (isPrivateClass) " (LỚP ẨN DANH)" else ""}: ip=${g.ip} quốc gia=${g.cc} múi giờ=${g.tz} ngôn ngữ=${g.lang} (nguồn ${m.optString("src", "")}) — ${if (changed) "ĐỔI so với trước" else "không đổi"}")
        if (changed) {
            if (!isPrivateClass) applyGeoToRuntimeLocales(g) // Accept-Language HTTP là cài đặt CHUNG của runtime => theo lớp thường
            for (s in fingerprintPortsBySession.keys.toList()) try { pushFingerprintConfig(s) } catch (e: Throwable) { /* session đã đóng */ }
            onEgressChanged?.invoke()
        }
    }

    // Accept-Language HTTP + navigator.languages TRONG WORKER do Gecko quyết định (JS giả không với tới worker): đặt qua cài đặt runtime. Dùng reflection vì chưa có code nào gọi.
    private fun applyGeoToRuntimeLocales(g: EgressGeo) {
        if (!geoAutoEnabled() || !FingerprintSpoofFeature.isEnabled(context, slotIndex)) return
        try {
            val s = runtime.settings
            s.javaClass.getMethod("setLocales", Array<String>::class.java).invoke(s, g.langs.toTypedArray())
            DebugLog.log("Khe $slotIndex: [geo] đặt Accept-Language/locales của Gecko = ${g.langs}")
        } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [geo] không đặt được locales: ${e.javaClass.simpleName} ${e.message}") }
    }

    /** MainActivity gọi khi trạng thái addon đổi (ví dụ VPN bật/tắt) để tra lại IP đi ra; tối đa 1 lần/20 giây. */
    // Mục 162: tin tức cho trang "Tab mới" — addon nền (cookie_helper) tải RSS qua đường mạng của khe rồi gửi về đây; lưu theo khe, trang Tab mới đọc khi dựng.
    private fun onNewsMessage(m: JSONObject) {
        val arr = m.optJSONArray("items") ?: return
        if (arr.length() == 0) return
        try {
            AppPrefs.setString(context, slotIndex, "ntp", "news_json", arr.toString())
            AppPrefs.setString(context, slotIndex, "ntp", "news_ts", System.currentTimeMillis().toString())
        } catch (e: Throwable) { /* bộ nhớ đệm */ }
        DebugLog.log("Khe $slotIndex: [tin tức] nhận ${arr.length()} tin từ ${(0 until arr.length()).map { arr.optJSONObject(it)?.optString("s", "?") }.distinct().joinToString()}")
    }

    /** Nút "Tải lại tin" ở trang Tab mới: nhờ addon nền tải lại RSS rồi (sau vài giây) dựng lại trang Tab mới nếu còn đang xem. */
    // ===== Mục 167: quản lý VÙNG ẨN DANH =====
    fun createIncognitoZone(persistent: Boolean = false): IncognitoZones.Zone {
        val (hw, _) = resolveProfile()
        val z = IncognitoZones.create(context, slotIndex, hw.category, hw.name, persistent)
        DebugLog.log("Khe $slotIndex: [vùng ${if (persistent) "BỀN" else "ẩn danh"}] tạo '${z.name}' id=${z.id} hw='${IncognitoZones.describe(z)}'")
        return z
    }

    fun regenerateZoneFingerprint(zoneId: String): IncognitoZones.Zone? {
        val (hw, _) = resolveProfile()
        val z = IncognitoZones.regenerate(context, slotIndex, zoneId, hw.category, hw.name) ?: return null
        refreshZoneTabs(zoneId)
        DebugLog.log("Khe $slotIndex: [vùng ẩn danh] đổi fingerprint '${z.name}' => ${IncognitoZones.describe(z)}")
        return z
    }

    /** Bản 7.64: chọn thủ công thiết bị cho vùng. */
    fun setZoneHardware(zoneId: String, hwIdx: Int): IncognitoZones.Zone? {
        val z = IncognitoZones.setHardware(context, slotIndex, zoneId, hwIdx) ?: return null
        refreshZoneTabs(zoneId)
        DebugLog.log("Khe $slotIndex: [vùng] '${z.name}' chọn thiết bị thủ công => ${IncognitoZones.describe(z)}")
        return z
    }

    /** Bản 7.64: ngôn ngữ/múi giờ riêng cho vùng (-1 = theo khe). */
    fun setZoneLocale(zoneId: String, localeIdx: Int): IncognitoZones.Zone? {
        val z = IncognitoZones.setLocale(context, slotIndex, zoneId, localeIdx) ?: return null
        refreshZoneTabs(zoneId)
        DebugLog.log("Khe $slotIndex: [vùng] '${z.name}' ngôn ngữ/múi giờ => ${IncognitoZones.describe(z)}")
        return z
    }

    /** Tab đang mở của vùng: đổi UA header + đẩy cấu hình JS mới + tải lại để trang thấy danh tính mới. */
    private fun refreshZoneTabs(zoneId: String) {
        val newUa = resolveProfileForZone(zoneId).first.userAgent
        for ((tid, t) in tabMeta.toMap()) if (t.zoneId == zoneId) {
            val sess = tabs[tid] ?: continue
            try { if (FingerprintSpoofFeature.isEnabled(context, slotIndex) && !manualDesktopTabIds.contains(tid)) sess.settings.userAgentOverride = newUa } catch (_: Throwable) {}
            try { pushFingerprintConfig(sess); sess.reload() } catch (_: Throwable) {}
        }
    }

    /** Đóng mọi tab của vùng, xoá dữ liệu của vùng, rồi xoá vùng. */
    fun deleteIncognitoZone(zoneId: String) {
        for ((tid, t) in tabMeta.toMap()) if (t.zoneId == zoneId) try { closeTab(tid) } catch (_: Throwable) {}
        try { runtime.storageController.clearDataForSessionContext(IncognitoZones.contextIdFor(zoneId)) } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [vùng ẩn danh] clearDataForSessionContext lỗi: ${e.javaClass.simpleName} ${e.message}")
        }
        IncognitoZones.delete(context, slotIndex, zoneId)
        groups.remove(IncognitoZones.groupId(zoneId))
        DebugLog.log("Khe $slotIndex: [vùng ẩn danh] đã xoá vùng $zoneId")
    }

    fun requestNewsRefresh(onDone: (() -> Unit)? = null) {
        val p = cookieHelperPort
        if (p != null) try { p.postMessage(JSONObject().put("type", "news_refresh")) } catch (e: Throwable) { /* kênh đã đóng */ }
        else DebugLog.log("Khe $slotIndex: [tin tức] chưa có kênh tới cookie_helper — không tải lại tin được")
        if (onDone != null) handler.postDelayed({ onDone() }, 5000L)
    }

    // ===== Bản 7.70 — FAIL-CLOSED lúc khởi động/khi proxy chưa sẵn sàng =====
    // Khe có proxy mà addon proxy CHƯA xác nhận đã nhận cấu hình thì mọi điều hướng http(s) bị GIỮ (không để trang tải bằng IP thật). Khi addon báo sẵn sàng
    // (hoặc người dùng tắt công tắc chặn) thì nạp lại đúng các tab bị giữ. Khe KHÔNG đặt proxy thì không bao giờ bị giữ.
    private val heldNavigations = ConcurrentHashMap<String, String>() // tabId -> URL bị giữ
    /** Bản 7.71: session tab ẨN DANH đã báo trước cho addon proxy (seq>0), hoặc -1 nếu cần báo mà không gửi được. Điều hướng bị giữ đến khi addon trả tab_mapped(seq). */
    private val sessionMapSeq = ConcurrentHashMap<GeckoSession, Long>()

    /** Tab ẩn danh có quy tắc vùng mà addon CHƯA ghép xong tabId↔vùng => chưa được tải (fail-closed; công tắc chặn tắt thì không giữ). */
    private fun mappingPending(session: GeckoSession?): Boolean {
        if (session == null) return false
        val seq = sessionMapSeq[session] ?: return false
        if (seq == 0L) return false
        if (GeckoRuntimeProvider.isTabMapped(seq)) { sessionMapSeq.remove(session); return false }
        return AppPrefs.getBoolean(context, slotIndex, "proxy_failclosed", true)
    }
    private var probeNavLogged = 0

    // ===== Bản 7.72 — GIẢI PHÓNG TAB NỀN (giống "Memory Saver" của Chrome) =====
    // Chrome giữ được hàng trăm tab vì loại bỏ phần nội dung của tab nền rảnh lâu, giữ lại tiêu đề/biểu tượng/trạng thái và tải lại khi người dùng quay lại.
    // Ở đây dùng đúng cơ chế khôi phục lười có sẵn: tab = metadata (isUnloaded=true, savedState giữ lịch sử/cuộn/form) + KHÔNG có GeckoSession; switchToTab() tạo lại session và restoreState().
    private val tabLastUsed = ConcurrentHashMap<String, Long>()
    private val engineStartMs = System.currentTimeMillis()

    /**
     * Giải phóng các tab nền đã rảnh ít nhất [minIdleMs], luôn giữ lại [keepRecent] tab nền dùng gần nhất. Trả số tab đã giải phóng.
     * KHÔNG bao giờ giải phóng: tab đang xem; tab ẩn danh/vùng ẩn danh (cookie nằm trong RAM của session — đóng là mất đăng nhập); tab đang tải; tab thuộc danh sách chạy nền
     * của app (bg_keepalive_domains); Colab (mục đích của app); mọi tab khi đang phát nhạc/video (chưa biết tab nào phát). Tắt được bằng pref tab_discard.
     * Phải gọi trên luồng chính.
     */
    fun discardIdleTabs(reason: String, minIdleMs: Long, keepRecent: Int): Int {
        if (!AppPrefs.getBoolean(context, slotIndex, "tab_discard", true)) return 0
        if (mediaPlayingNow) return 0
        val now = System.currentTimeMillis()
        val loaded = tabs.keys.filter { it != activeTabId && tabMeta[it]?.isUnloaded == false }
            .sortedByDescending { tabLastUsed[it] ?: engineStartMs }
        var n = 0
        loaded.forEachIndexed { idx, tid ->
            if (idx < keepRecent) return@forEachIndexed
            val tab = tabMeta[tid] ?: return@forEachIndexed
            val session = tabs[tid] ?: return@forEachIndexed
            if (tab.isPrivate || tab.isLoading || pendingRestoreTabIds.contains(tid)) return@forEachIndexed
            val url = tab.url
            if (!(url.startsWith("http://") || url.startsWith("https://"))) return@forEachIndexed
            if (isBackgroundKeepAliveExemptUrl(url)) return@forEachIndexed
            val host = try { Uri.parse(url).host?.lowercase() } catch (e: Exception) { null } ?: return@forEachIndexed
            if (host == "colab.research.google.com" || host.endsWith(".colab.research.google.com")) return@forEachIndexed
            if (now - (tabLastUsed[tid] ?: engineStartMs) < minIdleMs) return@forEachIndexed
            try { session.setActive(false) } catch (_: Throwable) {}
            try { session.close() } catch (_: Throwable) {}
            tabs.remove(tid)
            sessionMapSeq.remove(session)
            heldNavigations.remove(tid)
            tab.isUnloaded = true
            tab.isLoading = false
            n++
        }
        if (n > 0) {
            DebugLog.log("Khe $slotIndex: [giải phóng tab nền] đã giải phóng $n tab ($reason) — còn ${tabs.size} tab đang tải; bấm vào tab để tải lại đúng trạng thái")
            try { saveTabsState() } catch (_: Throwable) {}
        }
        return n
    }

    /** Nạp lại các tab đang bị giữ nếu điều kiện chặn không còn. Gọi từ MainActivity qua GeckoRuntimeProvider.proxyReadyHook. */
    fun releaseHeldNavigations() {
        handler.post {
            for ((tid, url) in heldNavigations.entries.toList()) {
                val priv = tabMeta[tid]?.isPrivate == true
                val zoneR = tabMeta[tid]?.zoneId ?: ""
                if ((GeckoRuntimeProvider.navigationNeedsProxy(context, slotIndex, priv, zoneR) && !GeckoRuntimeProvider.isProxyReady(slotIndex)) || mappingPending(tabs[tid])) continue
                heldNavigations.remove(tid)
                val sess = tabs[tid] ?: continue
                try {
                    DebugLog.log("Khe $slotIndex: [proxy FAIL-CLOSED] nhả điều hướng đã giữ cho tab $tid — nạp lại")
                    sess.loadUri(url)
                } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: nhả điều hướng giữ lỗi: ${e.message}") }
            }
        }
    }

    /**
     * Bản 7.66: sau khi đổi proxy — quên IP đã đo theo tab và đo lại NGAY (bỏ giới hạn tần suất) để múi giờ/ngôn ngữ/Accept-Language tự khớp IP mới
     * (nhánh `changed` của onGeoMessage đã đẩy lại cấu hình fingerprint cho mọi tab). Kết nối đang mở có thể còn đi đường cũ vài giây nên đo hai lần.
     */
    fun forceGeoRefresh() {
        tabEgress.clear()
        lastTabProbeAt = 0L
        lastGeoRefreshAt = 0L
        probeEgressViaTab()
        requestGeoRefresh()
        handler.postDelayed({ lastTabProbeAt = 0L; lastGeoRefreshAt = 0L; probeEgressViaTab(); requestGeoRefresh() }, 6000L)
    }

    fun requestGeoRefresh() {
        probeEgressViaTab()
        val now = android.os.SystemClock.uptimeMillis()
        if (now - lastGeoRefreshAt < 20_000L) return
        lastGeoRefreshAt = now
        val p = cookieHelperPort ?: return
        try { p.postMessage(JSONObject().put("type", "geo_refresh")) } catch (e: Throwable) { /* kênh đã đóng */ }
    }

    // ===== Mục 137: phép thử API — hỏi THẲNG GeckoView của app này nó hỗ trợ API WebExtension nào (áp dụng cho mọi addon) =====
    @Volatile private var apiProbeRequested = false
    @Volatile private var apiProbeLogged = false
    private val apiProbeSeen = HashSet<Int>()
    /** Mục 138: đặt khi mở popup của addon có quyền `cookies` mà khe đang cô lập — MainActivity hiện nút "Bật cookie chung" ngay trong popup. */
    @Volatile var popupNeedsSharedCookies = false
    /** Bản 7.62: popup vừa mở thuộc addon có quyền `cookies` (để UI cảnh báo khi tab đang xem là ẩn danh/vùng — kho cookie riêng, API addon không ghi tới được). */
    @Volatile var popupUsesCookiesApi = false

    private fun ensureApiProbe() {
        if (apiProbeRequested) return
        apiProbeRequested = true
        runtime.webExtensionController.ensureBuiltIn("resource://android/assets/api_probe/", "api-probe@colablive.internal").accept({ ext ->
            if (ext == null) {
                apiProbeRequested = false
                DebugLog.log("Khe $slotIndex: [probe API] ensureBuiltIn(api_probe) TRẢ VỀ NULL")
                return@accept
            }
            ext.setMessageDelegate(object : WebExtension.MessageDelegate {
                override fun onConnect(port: Port) {
                    port.setDelegate(object : PortDelegate {
                        override fun onPortMessage(message: Any, port: Port) {
                            if (message !is JSONObject) return
                            when (message.optString("type", "")) {
                                "hello" -> {
                                    // Mục 138: addon tự nối lại đến khi nhận "ack" (7.41 có thể nối TRƯỚC khi delegate được gắn nên không bao giờ có kết quả).
                                    try { port.postMessage(JSONObject().put("type", "ack")) } catch (e: Throwable) { /* kênh đã đóng */ }
                                    DebugLog.log("Khe $slotIndex: [probe API] kênh native đã nối (hello/ack)")
                                }
                                "api_probe_line" -> {
                                    val idx = message.optInt("i", -1)
                                    synchronized(apiProbeSeen) { if (idx < 0 || !apiProbeSeen.add(idx)) return }
                                    DebugLog.log("Khe $slotIndex: [probe API] " + message.optString("text", ""))
                                }
                            }
                        }
                    })
                }
            }, "browser")
            DebugLog.log("Khe $slotIndex: [probe API] đã đăng ký addon thăm dò — kết quả sẽ hiện trong vài giây")
        }, { t ->
            apiProbeRequested = false
            DebugLog.log("Khe $slotIndex: [probe API] ensureBuiltIn(api_probe) LỖI: ${t?.message}")
        })
    }

    private fun scanAddonProxyApis(extId: String): String {
        return try {
            val safe = extId.replace(Regex("[^A-Za-z0-9_.@-]"), "_")
            val f = java.io.File(addonStoreDir(), "$safe.xpi")
            if (!f.isFile) return "(không có bản sao xpi để quét)"
            val tokens = listOf("proxy.settings", "proxy.onRequest", "browserSettings.proxyConfig", "privacy.network", "proxy.register")
            val counts = LinkedHashMap<String, Int>()
            tokens.forEach { counts[it] = 0 }
            java.util.zip.ZipFile(f).use { z ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.isDirectory || e.size > 6_000_000L) continue
                    val n = e.name.lowercase()
                    if (!(n.endsWith(".js") || n.endsWith(".mjs") || n.endsWith(".html"))) continue
                    val text = z.getInputStream(e).bufferedReader().use { it.readText() }
                    tokens.forEach { t ->
                        var c = 0
                        var i = text.indexOf(t)
                        while (i >= 0) { c++; i = text.indexOf(t, i + t.length) }
                        counts[t] = (counts[t] ?: 0) + c
                    }
                }
            }
            counts.entries.joinToString(", ") { "${it.key}×${it.value}" }
        } catch (e: Throwable) { "(lỗi quét: ${e.message})" }
    }

    // ===== Mục 134: thay cookie TRỰC TIẾP (không đóng khe) qua addon nền cookie_helper =====
    @Volatile private var cookieHelperRequested = false
    private var cookieHelperPort: WebExtension.Port? = null
    private val cookieCallbacks = java.util.concurrent.ConcurrentHashMap<String, (JSONObject) -> Unit>()
    private val cookiePending = java.util.concurrent.CopyOnWriteArrayList<JSONObject>()

    private fun ensureCookieHelper() {
        if (cookieHelperRequested) return
        cookieHelperRequested = true
        loadCachedGeo()
        runtime.webExtensionController.ensureBuiltIn("resource://android/assets/cookie_helper/", "cookie-helper@colablive.internal").accept({ ext ->
            if (ext == null) {
                cookieHelperRequested = false
                DebugLog.log("Khe $slotIndex: [Cookie] ensureBuiltIn(cookie_helper) TRẢ VỀ NULL")
                return@accept
            }
            DebugLog.log("Khe $slotIndex: [Cookie] cookie_helper đã đăng ký")
            ext.setMessageDelegate(object : WebExtension.MessageDelegate {
                override fun onConnect(port: Port) {
                    cookieHelperPort = port
                    port.setDelegate(object : PortDelegate {
                        override fun onPortMessage(message: Any, port: Port) { handleCookieHelperMessage(message, port) }
                        override fun onDisconnect(port: Port) { if (cookieHelperPort === port) cookieHelperPort = null }
                    })
                    DebugLog.log("Khe $slotIndex: [Cookie] cookie_helper đã kết nối kênh native")
                    handler.post { flushCookiePending() }
                }
            }, "browser")
            // Cần để thay cookie trong KHO ẨN DANH (tab ẩn danh).
            try {
                runtime.webExtensionController.setAllowedInPrivateBrowsing(ext, true).accept({ _ ->
                    DebugLog.log("Khe $slotIndex: [Cookie] cookie_helper được phép chạy trong ẩn danh")
                }, { t -> DebugLog.log("Khe $slotIndex: [Cookie] setAllowedInPrivateBrowsing(cookie_helper) LỖI: ${t?.message}") })
            } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [Cookie] không gọi được setAllowedInPrivateBrowsing: ${e.message}") }
        }, { t ->
            cookieHelperRequested = false
            DebugLog.log("Khe $slotIndex: [Cookie] ensureBuiltIn(cookie_helper) LỖI: ${t?.message}")
        })
    }

    private fun handleCookieHelperMessage(message: Any, port: Port) {
        if (message !is JSONObject) return
        val type = message.optString("type", "")
        if (type == "hello") {
            cookieHelperPort = port
            try { port.postMessage(JSONObject().put("type", "ack")) } catch (e: Throwable) { /* kênh đã đóng */ }
            DebugLog.log("Khe $slotIndex: [Cookie] cookie_helper hello/ack — sẵn sàng nhận lệnh")
            handler.post { flushCookiePending() }
            return
        }
        if (type == "geo") { handler.post { onGeoMessage(message) }; return }
        if (type == "news") { handler.post { onNewsMessage(message) }; return } // Mục 162
        if (type != "cookies_result") return
        val cb = cookieCallbacks.remove(message.optString("id", "")) ?: return
        handler.post { cb(message) }
    }

    private fun flushCookiePending() {
        val p = cookieHelperPort ?: return
        val list = ArrayList(cookiePending)
        cookiePending.clear()
        list.forEach { cmd ->
            try { p.postMessage(cmd) } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [Cookie] gửi lệnh cho cookie_helper lỗi: ${e.message}") }
        }
    }

    /**
     * Xoá cookie của `base` (và miền con) rồi ghi `cookiesJson` (mảng đúng định dạng Cookie-Editor, xem CookieVault.toEditorJson) vào kho cookie
     * của Gecko ĐANG CHẠY — có hiệu lực ngay, không đóng khe. `isPrivate` chọn kho ẨN DANH. CHỈ đúng khi khe ở chế độ cookie chung (không contextId).
     */
    fun applyCookiesLive(base: String, cookiesJson: String, isPrivate: Boolean, onDone: (Boolean, String) -> Unit) {
        val id = "ck" + System.nanoTime()
        val cmd = JSONObject().put("type", "cookies_apply").put("id", id).put("base", base).put("private", isPrivate)
            .put("cookies", org.json.JSONArray(cookiesJson))
        cookieCallbacks[id] = { r ->
            val ok = r.optBoolean("ok", false)
            val failed = r.optInt("failed", 0)
            val msg = if (ok) "xoá ${r.optInt("removed")}, ghi ${r.optInt("set")}" + (if (failed > 0) ", LỖI $failed (${r.optString("lastError", "")})" else "") + " — kho '${r.optString("store")}'"
                      else r.optString("error", "không rõ")
            DebugLog.log("Khe $slotIndex: [Cookie] thay TRỰC TIẾP '$base' (ẩn danh=$isPrivate): $msg")
            onDone(ok && failed == 0, msg)
        }
        cookiePending.add(cmd)
        ensureCookieHelper()
        handler.post { flushCookiePending() }
        handler.postDelayed({
            cookiePending.removeAll { it.optString("id", "") == id } // đừng để lệnh cũ chạy âm thầm khi kênh kết nối muộn
            cookieCallbacks.remove(id)?.let { cb ->
                DebugLog.log("Khe $slotIndex: [Cookie] cookie_helper KHÔNG trả lời sau 15s (kênh chưa kết nối hoặc API cookies không dùng được)")
                cb(JSONObject().put("ok", false).put("error", "addon trợ giúp không phản hồi sau 15s"))
            }
        }, 15_000L)
    }

    fun deleteGroupIfEmpty(groupId: String): Boolean {
        if (isAppManagedGroup(groupId)) return false
        if (tabMeta.values.any { it.groupId == groupId }) return false
        val removed = groups.remove(groupId) != null
        if (removed) { saveTabsState(); DebugLog.log("Khe $slotIndex: [nhóm tab] xoá nhóm rỗng $groupId (mọi tab được gán đều là tab ẩn danh hoặc đã bị bỏ qua)") }
        return removed
    }

    override fun deleteGroup(groupId: String) {
        if (isAppManagedGroup(groupId)) return // 7.66: nhóm Ẩn danh/vùng/vùng bền do app quản lý // nhóm Ẩn danh do app quản lý, tự mất khi hết tab ẩn danh
        // Gỡ nhóm khỏi TẤT CẢ tab đang thuộc nhóm này trước khi xoá hẳn
        // nhóm — không để tab nào "mồ côi" trỏ tới groupId không tồn tại.
        tabMeta.values.forEach { if (it.groupId == groupId) it.groupId = null }
        groups.remove(groupId)
        saveTabsState()
    }

    override fun moveTab(tabId: String, toIndex: Int) {
        val fromIndex = tabOrder.indexOf(tabId)
        if (fromIndex == -1) return
        var clampedTo = toIndex.coerceIn(0, tabOrder.size - 1)
        if (fromIndex == clampedTo) return
        tabOrder.removeAt(fromIndex)
        val meta = tabMeta[tabId]
        if (meta?.isPrivate == true) {
            // Bản 7.58: tab ẩn danh chỉ đổi thứ tự TRONG khối nhóm của nó (kéo cả nhóm thì dùng moveGroup) — nếu không, khối nhóm sẽ "nhảy" theo tab bị kéo.
            val gid = meta.groupId
            val sib = tabOrder.indices.filter { i -> tabMeta[tabOrder[i]]?.let { m -> m.isPrivate && m.groupId == gid } == true }
            if (sib.isNotEmpty()) clampedTo = clampedTo.coerceIn(sib.first(), sib.last() + 1)
        }
        tabOrder.add(clampedTo.coerceAtMost(tabOrder.size), tabId)
        normalizePrivateOrder() // Mục 117/7.58: mỗi nhóm ẩn danh luôn liền khối
        saveTabsState()
    }

    /**
     * FIX BUG THẬT (người dùng báo: "group tab trên thanh tab không kéo
     * di chuyển vị trí được như tab thường") — xem giải thích đầy đủ ở
     * khai báo `moveGroup` trong `BrowserEngine.kt`. Lấy TOÀN BỘ tab
     * thuộc `groupId` THEO ĐÚNG thứ tự hiện có trong `tabOrder` (giữ
     * nguyên thứ tự tương đối bên trong nhóm — không xáo lại), xoá cả
     * khối ra khỏi vị trí cũ, rồi chèn nguyên khối vào ngay TRƯỚC
     * `beforeTabId` (hoặc cuối danh sách nếu null).
     */
    override fun moveGroup(groupId: String, beforeTabId: String?) {
        val memberIds = tabOrder.filter { tabMeta[it]?.groupId == groupId }
        if (memberIds.isEmpty()) return
        // Thả ngay lên 1 tab CÙNG nhóm đang kéo — coi như không đổi gì,
        // tránh tự xoá rồi chèn lại đúng chỗ cũ gây rebuild thừa.
        if (beforeTabId != null && beforeTabId in memberIds) return
        tabOrder.removeAll(memberIds)
        val insertAt = if (beforeTabId != null) {
            tabOrder.indexOf(beforeTabId).let { if (it == -1) tabOrder.size else it }
        } else {
            tabOrder.size
        }
        tabOrder.addAll(insertAt, memberIds)
        normalizePrivateOrder()
        saveTabsState()
    }

    override fun getRecentlyClosedTabs(): List<ClosedTabEntry> = recentlyClosedTabs.toList()

    override fun reopenClosedTab(entryId: String): BrowserTab? {
        val entry = recentlyClosedTabs.find { it.entryId == entryId } ?: return null
        recentlyClosedTabs.remove(entry)
        // Tái dùng ĐÚNG cơ chế khôi phục đầy đủ đã có sẵn cho "mở lại app"
        // (`createTabWithState`) — savedState khác null thì tự
        // `session.restoreState()` (nguyên lịch sử back/forward), có sẵn cả
        // lưới an toàn 3s tự tải lại URL thường nếu restore không gây điều
        // hướng nào (xem chú thích đầy đủ ở `createTabWithState`).
        val reopenZone = entry.zoneId.takeIf { it.isNotBlank() && IncognitoZones.get(context, slotIndex, it)?.persistent == true } ?: ""
        val tab = createTabWithState(entry.url, entry.savedState, reopenZone)
        if (reopenZone.isNotBlank()) adoptIntoZoneGroup(tab) // 7.66
        // Mục 109: trả tab về ĐÚNG vị trí cũ (và nhóm cũ nếu nhóm còn) — "Hủy" kiểu Chrome, không ném xuống cuối dải tab.
        if (entry.originalIndex >= 0) {
            tabOrder.remove(tab.id)
            tabOrder.add(entry.originalIndex.coerceIn(0, tabOrder.size), tab.id)
        }
        val gid = entry.groupId
        if (gid != null && groups.containsKey(gid)) tab.groupId = gid
        switchToTab(tab.id)
        saveTabsState()
        return tab
    }

    /**
     * Đọc toàn bộ `body` (luồng GeckoView, GIỮ cookie phiên) vào file tạm ở luồng nền, kèm thông báo tiến độ, rồi báo
     * `onDownloadBodyReadyListener`. Lỗi thì gọi `onFailure` (đường hỏi-trước) hoặc tải lại qua OkHttp (đường cũ).
     */
    private fun drainBodyToTemp(
        uri: String, fileName: String, headers: Map<String, String>?, body: java.io.InputStream, onFailure: (() -> Unit)?
    ) {
        Thread {
            var tempFile: java.io.File? = null
            // BUG THẬT đã tìm ra (người dùng báo: "cái download
            // thì là do down ngầm, lúc đó ko hiển thị, tải xong
            // mới hiển thị... là do tải ngầm lúc đó (cái này là
            // bug)"): toàn bộ quá trình drain này (bắt buộc phải
            // làm NGẦM ở đây, vì cần cookie phiên thật mà chỉ
            // chính GeckoView đang giữ — không thể hỏi người
            // dùng TRƯỚC khi tải như luồng URL thường, đây là
            // giới hạn kiến trúc thật, không tránh được) trước
            // giờ HOÀN TOÀN IM LẶNG — không progress, không
            // thông báo gì — với file lớn (VD 692MB thấy trong
            // log thật) có thể mất hàng chục giây tới vài phút
            // im lặng tuyệt đối, đúng cảm giác "không phản ứng
            // gì". Không thể tránh việc tải-ngầm-trước (giới hạn
            // kiến trúc), nhưng CÓ THỂ và NÊN báo tiến độ ngay
            // trong lúc tải, thay vì im lặng rồi bất ngờ hiện
            // dialog chọn nơi lưu sau khi đã xong hết.
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            val progressChannelId = "live_browser_dl_progress"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                nm.createNotificationChannel(
                    android.app.NotificationChannel(
                        progressChannelId, "Đang tải xuống (nền)",
                        android.app.NotificationManager.IMPORTANCE_LOW
                    ).apply { setShowBadge(false) }
                )
            }
            val progressNotifId = 4000 + slotIndex
            val contentLength = headers?.entries?.firstOrNull {
                it.key.equals("content-length", ignoreCase = true)
            }?.value?.toLongOrNull() ?: -1L

            // Mục 109 (1/2): bấm vào thanh thông báo tải phải làm gì đó. Trước đây Notification.Builder không có contentIntent
            // nên bấm vào KHÔNG phản ứng. Giờ mở đúng khe này và hiện thẳng dialog "IDM Downloads". Dùng đúng mẫu Intent
            // "Mở ở khe khác" (ComponentName của MainActivitySlotN + NEW_TASK + bỏ qua màn hình chọn khe).
            val openDownloadsPendingIntent: android.app.PendingIntent? = try {
                val intent = android.content.Intent().apply {
                    component = android.content.ComponentName(context.packageName, ProfileSlots.componentClassNameForSlot(slotIndex))
                    putExtra("open_downloads", true)
                    putExtra("skip_picker", true)
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                android.app.PendingIntent.getActivity(
                    context, progressNotifId, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: không tạo được PendingIntent cho thông báo tải: ${e.message}")
                null
            }

            // Mục 109 (2/2): đăng ký tác vụ vào DownloadEngine để dialog "IDM Downloads" thấy tiến trình thật (trước đây trống).
            val dlEngine = try {
                com.colablive.keeper.features.downloads.DownloadManagerFeature.engineFor(context)
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: không lấy được DownloadEngine để hiện tiến trình trong danh sách: ${e.message}")
                null
            }
            val transferId = dlEngine?.beginExternalTransfer(fileName, contentLength)

            fun postProgress(doneBytes: Long, finished: Boolean) {
                val builder = android.app.Notification.Builder(context, progressChannelId)
                    .setContentTitle(if (finished) "Đã tải xong (đang chờ chọn nơi lưu)" else "Đang tải xuống: $fileName")
                    .setSmallIcon(android.R.drawable.stat_sys_download)
                    .setOngoing(!finished)
                    .setOnlyAlertOnce(true)
                if (openDownloadsPendingIntent != null) {
                    builder.setContentIntent(openDownloadsPendingIntent)
                    builder.setAutoCancel(true)
                }
                if (contentLength > 0) {
                    builder.setProgress(100, ((doneBytes * 100) / contentLength).toInt().coerceIn(0, 100), false)
                    builder.setContentText("${doneBytes / 1024 / 1024}MB / ${contentLength / 1024 / 1024}MB")
                } else {
                    builder.setProgress(0, 0, !finished)
                    builder.setContentText("${doneBytes / 1024 / 1024}MB")
                }
                try { nm.notify(progressNotifId, builder.build()) } catch (e: Exception) { /* không nghiêm trọng, bỏ qua */ }
            }
            var cancelledByUser = false
            try {
                val tempDir = java.io.File(context.cacheDir, "download_body_tmp").apply { mkdirs() }
                tempFile = java.io.File(tempDir, "body_${System.currentTimeMillis()}_$fileName")
                postProgress(0, false)
                body.use { input ->
                    tempFile!!.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var totalRead = 0L
                        var lastPosted = 0L
                        while (true) {
                            // Người dùng xoá/huỷ tác vụ trong danh sách => dừng đọc ngay (đóng luồng nhờ `body.use`).
                            if (transferId != null && dlEngine!!.isExternalTransferCancelled(transferId)) {
                                cancelledByUser = true
                                break
                            }
                            val read = input.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                            totalRead += read
                            // Danh sách "IDM Downloads" làm mới mỗi 500ms nên cập nhật số byte mỗi lần đọc là rẻ (chỉ set AtomicLong).
                            if (transferId != null) dlEngine!!.updateExternalTransfer(transferId, totalRead)
                            // Chỉ cập nhật notification mỗi ~1MB — cập
                            // nhật MỖI lần đọc (64KB) sẽ spam
                            // NotificationManager, có thể bị hệ
                            // thống rate-limit hoặc tốn pin vô ích.
                            if (totalRead - lastPosted >= 1_000_000L) {
                                postProgress(totalRead, false)
                                lastPosted = totalRead
                            }
                        }
                    }
                }
                nm.cancel(progressNotifId)
                if (transferId != null) dlEngine!!.endExternalTransfer(transferId)
                if (cancelledByUser) {
                    DebugLog.log("Khe $slotIndex: tải $fileName bị người dùng huỷ/xoá từ danh sách trong lúc đang đọc luồng — đã đóng luồng, xoá file tạm")
                    tempFile?.delete()
                    handler.post { onDownloadDrainCancelledListener?.invoke(uri) }
                    return@Thread
                }
                DebugLog.log("Khe $slotIndex: đã drain response.body (${tempFile.length()} byte, CÓ cookie phiên thật vì chính GeckoView tải) vào file tạm cho $fileName")
                val finalTempFile = tempFile
                handler.post {
                    onDownloadBodyReadyListener?.invoke(uri, fileName, finalTempFile?.absolutePath)
                }
            } catch (e: Exception) {
                nm.cancel(progressNotifId)
                if (transferId != null) dlEngine?.endExternalTransfer(transferId)
                DebugLog.log("Khe $slotIndex: drain response.body lỗi (${e.message}) — fallback về tải lại qua OkHttp (KHÔNG có cookie, chỉ đúng cho file công khai)")
                tempFile?.delete()
                handler.post {
                    // Đường "hỏi trước": người dùng ĐÃ chọn nơi lưu nên dùng đúng lựa chọn đó, không hỏi lần 2.
                        if (onFailure != null) onFailure() else onDownloadRequestedListener?.invoke(uri, fileName)
                }
            }
        }.start()
    }

    /** Ghi nhận `tabId` là tab vừa xem gần nhất. */
    private fun touchMru(tabId: String) {
        tabLastUsed[tabId] = System.currentTimeMillis() // 7.72: dùng cho giải phóng tab nền
        tabMru.remove(tabId)
        tabMru.add(0, tabId)
        while (tabMru.size > 50) tabMru.removeAt(tabMru.size - 1)
    }

    /** Tab con mở từ một tab trong nhóm thì vào cùng nhóm (nếu không, nó chen giữa nhóm và làm vỡ khối nhóm liền nhau). */
    private fun inheritGroupFromOpener(tab: BrowserTab, openerTabId: String) {
        val gid = tabMeta[openerTabId]?.groupId ?: return
        // Mục 117: nhóm "Ẩn danh" chỉ dành cho tab ẩn danh — tab thường mở từ tab ẩn danh không được vào nhóm đó.
        if (gid.startsWith("__") && !tab.isPrivate) return // nhóm ẩn danh (chung hoặc theo vùng) — tab thường không được vào
        if (groups.containsKey(gid)) tab.groupId = gid
    }

    // ===== Mục 117: mọi tab ẨN DANH gom thành MỘT nhóm "Ẩn danh" nằm liền nhau ở cuối dải tab =====
    // Người dùng: tab ẩn danh nằm rải rác xen tab thường rất khó dùng. Nhóm này do app quản lý: tự tạo khi có tab ẩn danh đầu tiên, tự xoá khi tab
    // ẩn danh cuối cùng đóng, KHÔNG lưu xuống đĩa (tab ẩn danh vốn không được lưu), không cho gỡ tab ra/gộp tab thường vào/xoá nhóm.
    private val PRIVATE_GROUP_ID = "__private_group__"

    private fun ensurePrivateGroup() {
        if (!groups.containsKey(PRIVATE_GROUP_ID)) groups[PRIVATE_GROUP_ID] = TabGroup(PRIVATE_GROUP_ID, "Ẩn danh", "#3C4043")
    }

    // ===== Bản 7.66 — NHÓM TỰ ĐỘNG CHO VÙNG BỀN =====
    // Tab của vùng bền là tab THƯỜNG (isPrivate=false) nên trước đây nằm lẫn với mọi tab khác, không biết tab nào thuộc vùng nào. Nay mỗi vùng bền có MỘT nhóm
    // tên "💾 <tên vùng>" màu của vùng (id "zone:<zoneId>", KHÔNG bắt đầu bằng "__" nên được LƯU xuống đĩa cùng tab). Nhóm do app quản lý: tab vùng chỉ ở nhóm của vùng mình,
    // tab của vùng khác/tab thường không vào được, không xoá/rã nhóm bằng tay; nhóm tự mất khi hết tab.
    private fun isAppManagedGroup(id: String?): Boolean = id != null && (id == PRIVATE_GROUP_ID || id.startsWith("__zone__") || id.startsWith("zone:"))
    private fun persistentZoneGroupId(zoneId: String) = "zone:$zoneId"

    private fun adoptIntoZoneGroup(tab: BrowserTab) {
        if (tab.isPrivate || tab.zoneId.isBlank()) return
        val z = IncognitoZones.get(context, slotIndex, tab.zoneId) ?: return
        if (!z.persistent) return
        val gid = persistentZoneGroupId(z.id)
        val name = "💾 " + z.name
        val existing = groups[gid]
        if (existing == null) groups[gid] = TabGroup(gid, name, z.colorHex) else existing.name = name
        tab.groupId = gid
        val lastSame = tabOrder.indexOfLast { it != tab.id && tabMeta[it]?.groupId == gid }
        if (lastSame >= 0) { tabOrder.remove(tab.id); tabOrder.add((lastSame + 1).coerceAtMost(tabOrder.size), tab.id) }
        saveTabsState()
    }

    /** Mục 167: mỗi vùng ẩn danh có NHÓM riêng "Ẩn danh · <tên vùng>" với màu của vùng. */
    private fun ensureZoneGroup(zoneId: String) {
        val gid = IncognitoZones.groupId(zoneId)
        val z = IncognitoZones.get(context, slotIndex, zoneId)
        val name = "Ẩn danh · " + (z?.name ?: "Vùng")
        val existing = groups[gid]
        if (existing == null) groups[gid] = TabGroup(gid, name, z?.colorHex ?: "#3C4043") else existing.name = name
    }

    /** Gọi sau khi đổi tên vùng để nhóm hiện tên mới. */
    fun updateZoneGroup(zoneId: String) {
        if (groups.containsKey(IncognitoZones.groupId(zoneId))) ensureZoneGroup(zoneId)
        val pg = groups[persistentZoneGroupId(zoneId)]
        val z = IncognitoZones.get(context, slotIndex, zoneId)
        if (pg != null && z != null) { pg.name = "💾 " + z.name; saveTabsState() } // 7.66: đổi tên vùng bền => nhóm đổi theo
    }

    /**
     * Bản 7.58 — TRƯỚC ĐÂY dồn MỌI tab ẩn danh xuống cuối `tabOrder` nên kéo nhóm vùng ẩn danh (hay nhóm "Ẩn danh") lên giữa các nhóm/tab thường
     * luôn bị đẩy ngược về cuối => người dùng thấy "không kéo di chuyển được như các nhóm khác". Giờ mỗi nhóm ẩn danh/vùng là MỘT KHỐI LIỀN NHAU đặt
     * ở vị trí của tab đầu tiên của nó (có thể ở bất cứ đâu, kéo được như nhóm thường); tab thường lọt vào giữa một khối bị đưa ra TRƯỚC khối đó
     * (giữ hành vi cũ: tab thường mới mở không chen vào khối ẩn danh). Mặc định (tab ẩn danh nằm cuối) kết quả y như trước.
     */
    private fun normalizePrivateOrder() {
        val order = tabOrder.toList()
        fun privKey(id: String): String? {
            val m = tabMeta[id] ?: return null
            return if (m.isPrivate) (m.groupId ?: ("__solo__" + id)) else null
        }
        if (order.none { privKey(it) != null }) return
        val members = LinkedHashMap<String, MutableList<String>>()
        order.forEach { id -> privKey(id)?.let { members.getOrPut(it) { mutableListOf() }.add(id) } }
        val out = ArrayList<String>(order.size)
        val done = HashSet<String>()
        for (id in order) {
            if (id in done) continue
            val k = privKey(id)
            if (k == null) { out.add(id); done.add(id); continue }
            val block = members[k] ?: continue
            val firstIdx = order.indexOf(block.first()); val lastIdx = order.indexOf(block.last())
            // tab thường nằm giữa khối => đứng trước khối
            for (j in firstIdx + 1 until lastIdx) {
                val x = order[j]
                if (x !in done && privKey(x) == null) { out.add(x); done.add(x) }
            }
            block.forEach { if (it !in done) { out.add(it); done.add(it) } }
        }
        if (out != order) { tabOrder.clear(); tabOrder.addAll(out) }
    }

    /** Đưa tab ẩn danh mới vào nhóm Ẩn danh, đứng ngay sau tab ẩn danh cuối (hoặc cuối dải nếu chưa có). */
    private fun placePrivateTab(tab: BrowserTab) {
        val gid: String
        if (tab.zoneId.isBlank()) { ensurePrivateGroup(); gid = PRIVATE_GROUP_ID } else { ensureZoneGroup(tab.zoneId); gid = IncognitoZones.groupId(tab.zoneId) }
        tab.groupId = gid
        // Mục 167: chèn sau tab CUỐI CÙNG CỦA CÙNG NHÓM (vùng) để mỗi vùng nằm liền khối; chưa có thì cuối khối ẩn danh.
        val lastSame = tabOrder.indexOfLast { it != tab.id && tabMeta[it]?.groupId == gid }
        val lastPriv = if (lastSame >= 0) lastSame else tabOrder.indexOfLast { it != tab.id && tabMeta[it]?.isPrivate == true }
        tabOrder.remove(tab.id)
        tabOrder.add(if (lastPriv >= 0) (lastPriv + 1).coerceAtMost(tabOrder.size) else tabOrder.size, tab.id)
    }

    /**
     * Chèn `tabId` vào `tabOrder` NGAY SAU `anchorId` (tab gốc hoặc tab đang xem). Nhiều tab con của CÙNG một tab gốc đứng liền nhau
     * theo thứ tự mở (như Chrome/Firefox), không bị đảo ngược. Tab gốc nằm trong nhóm mà tab mới không vào nhóm thì chèn sau cả khối
     * nhóm. Không có/không tìm thấy tab gốc thì thêm cuối.
     */
    private fun insertTabOrder(tabId: String, anchorId: String?, sameOpenerRun: Boolean) {
        val o = if (anchorId != null) tabOrder.indexOf(anchorId) else -1
        if (o < 0) { tabOrder.add(tabId); return }
        var pos = o + 1
        if (sameOpenerRun) {
            while (pos < tabOrder.size && tabMeta[tabOrder[pos]]?.openerTabId == anchorId) pos++
        } else {
            val anchorGroup = tabMeta[anchorId]?.groupId
            if (anchorGroup != null) while (pos < tabOrder.size && tabMeta[tabOrder[pos]]?.groupId == anchorGroup) pos++
        }
        tabOrder.add(pos.coerceAtMost(tabOrder.size), tabId)
    }

    /**
     * Chọn tab hiện ra sau khi đóng tab đang xem (mục 107). Thứ tự ưu tiên:
     *  1) tab ĐÃ MỞ RA tab vừa đóng (nếu còn);  2) tab vừa xem NGAY TRƯỚC ĐÓ (lịch sử chuyển tab);
     *  3) tab bên cạnh (đứng đúng chỗ tab vừa đóng, không có thì tab cuối).
     * Trước đây bước 2-3 là `tabOrder.firstOrNull()` nên mọi tab không có tab gốc (mở bằng nút +, từ lịch sử...) đều nhảy về TAB ĐẦU TIÊN.
     */
    private fun pickNextActiveTab(openerTabId: String?, closedIndex: Int): String? {
        if (openerTabId != null && tabOrder.contains(openerTabId)) {
            DebugLog.log("closeTab: quay lại tab đã mở ra nó (opener=$openerTabId)")
            return openerTabId
        }
        val prev = tabMru.firstOrNull { tabOrder.contains(it) }
        if (prev != null) {
            DebugLog.log("closeTab: quay lại tab vừa xem trước đó ($prev)")
            return prev
        }
        if (tabOrder.isEmpty()) return null
        val neighbor = tabOrder[closedIndex.coerceIn(0, tabOrder.size - 1)]
        DebugLog.log("closeTab: không có tab gốc/tab xem trước — chọn tab bên cạnh ($neighbor)")
        return neighbor
    }

    override fun closeTab(tabId: String) {
        // FIX BUG THẬT (người dùng báo): lưu lại opener TRƯỚC KHI xoá khỏi
        // tabMeta (xoá xong sẽ không đọc được nữa).
        val openerOfClosedTab = tabMeta[tabId]?.openerTabId
        val closedIndex = tabOrder.indexOf(tabId) // vị trí cũ để chọn tab bên cạnh nếu không còn gì tốt hơn (mục 107)

        // TÍNH NĂNG MỚI (người dùng yêu cầu, mục 73 PROJECT_STATUS.md):
        // lưu lại snapshot ĐẦY ĐỦ (gồm `savedState` — chuỗi
        // `GeckoSession.SessionState`, chứa nguyên lịch sử back/forward)
        // của tab TRƯỚC KHI xoá khỏi `tabMeta`, để "Thẻ đã đóng gần đây" có
        // thể mở lại đúng y hệt tab đó, không chỉ đúng URL mà còn nguyên cả
        // lịch sử duyệt bên trong tab (khớp đúng yêu cầu "vẫn có trang lịch
        // sử đằng sau cái thẻ đó"). BỎ QUA tab ẩn danh — nhất quán với quy
        // ước có sẵn của app (tab ẩn danh không lưu lịch sử, không khôi
        // phục sau khi đóng app — xem `BrowserTab.isPrivate`).
        var closedEntryForUndo: ClosedTabEntry? = null
        tabMeta[tabId]?.let { tab ->
            if (!tab.isPrivate) {
                val entry = ClosedTabEntry(
                    entryId = UUID.randomUUID().toString(),
                    url = tab.url,
                    title = tab.title,
                    savedState = tab.savedState,
                    closedAtMillis = System.currentTimeMillis(),
                    originalIndex = closedIndex,
                    groupId = tab.groupId,
                    zoneId = tab.zoneId
                )
                recentlyClosedTabs.add(0, entry)
                while (recentlyClosedTabs.size > MAX_RECENTLY_CLOSED_TABS) {
                    recentlyClosedTabs.removeAt(recentlyClosedTabs.size - 1)
                }
                closedEntryForUndo = entry
            }
        }

        tabs[tabId]?.close()
        tabs.remove(tabId)
        tabMeta.remove(tabId)
        tabOrder.remove(tabId)
        // Mục 117: hết tab ẩn danh thì bỏ luôn nhóm Ẩn danh.
        if (tabMeta.values.none { it.isPrivate && it.zoneId.isBlank() }) groups.remove(PRIVATE_GROUP_ID)
        groups.keys.filter { (it.startsWith("__zone__") || it.startsWith("zone:")) && tabMeta.values.none { t -> t.groupId == it } }.forEach { groups.remove(it) } // Mục 167 / 7.66
        tabMru.remove(tabId)
        manualDesktopTabIds.remove(tabId)
        manualMobileTabIds.remove(tabId)

        if (activeTabId == tabId) {
            // FIX BUG THẬT (người dùng báo): trước đây LUÔN quay về
            // `tabOrder.firstOrNull()` (tab 0) khi đóng tab đang active —
            // kể cả khi đóng 1 tab POPUP (mở ra từ tab khác qua
            // window.open()/target="_blank") — với nhiều tab, rất khó
            // quản lý vì luôn bị "bắn" về tab đầu tiên thay vì quay lại
            // đúng tab vừa mở popup ra. Giờ ưu tiên quay lại ĐÚNG tab gốc
            // (opener) nếu tab đó VẪN CÒN tồn tại (chưa bị đóng) — giống
            // hành vi Chrome/Firefox thật. Chỉ rơi về `tabOrder.firstOrNull()`
            // khi không có opener (tab tự mở, không phải popup) hoặc tab
            // gốc đã bị đóng từ trước.
            activeTabId = pickNextActiveTab(openerOfClosedTab, closedIndex)
            activeTabId?.let { switchToTab(it) }
        }
        saveTabsState()
        // Mục 109: báo UI SAU CÙNG (tab kế tiếp đã được chọn, danh sách đã lưu) để thanh "Hủy" hiện đúng trạng thái.
        closedEntryForUndo?.let { entry -> handler.post { onTabClosedListener?.invoke(entry) } }
    }

    override fun switchToTab(tabId: String) {
        handler.postDelayed({ try { probeEgressViaTab() } catch (e: Throwable) {} }, 1200) // Mục 149: IP trên thanh theo TAB đang xem
        val tab = tabMeta[tabId] ?: return
        touchMru(tabId)

        // TẠO SESSION THẬT tại đây nếu tab này vẫn đang lazy (chưa từng có
        // GeckoSession native nào) — đây là điểm DUY NHẤT native session
        // được tạo cho tab lazy, đảm bảo tại mọi thời điểm chỉ có ĐÚNG số
        // session đang thật sự cần (tab active + các tab đã từng được xem
        // qua), không phải tạo sẵn tất cả lúc khởi động.
        var session = tabs[tabId]
        val isFirstActivation = (session == null && tab.isUnloaded)
        if (session == null) {
            session = createSession(tab.isPrivate, tab.zoneId)
            tabs[tabId] = session
        }

        // SỬA LẠI cho ĐÚNG sau khi người dùng chỉ ra 2 điểm quan trọng ở
        // mục 41/42:
        // (1) Chrome Android THẬT SỰ đóng băng tab nền rất nhanh (~1 phút,
        //     kể cả KHÔNG rời khỏi app) — nên `setActive(false)` áp dụng
        //     mặc định cho MỌI tab không hiển thị là ĐÚNG hướng, không phải
        //     "quá tay".
        // (2) Nhưng KHÔNG được hard-code riêng "Colab" là ngoại lệ — nếu
        //     vậy các trang khác cũng cần chạy nền thật (vd trang đang phát
        //     nhạc) sẽ bị bỏ rơi. Đúng như người dùng chỉ ra: dùng LẠI cơ
        //     chế "danh sách ngoại lệ theo domain, người dùng tự nhập" ĐÃ
        //     CÓ SẴN trong app (xem `fp_desktop_skip_viewport_domains` +
        //     UI ở FingerprintSpoofFeature) — không phát minh cơ chế mới,
        //     tái dùng đúng pattern đã có. Domain nào người dùng liệt kê
        //     vào `bg_keepalive_domains` thì KHÔNG bị đánh dấu
        //     `setActive(false)` khi rời khỏi (được phép tiếp tục chạy nền
        //     thật, giống hệt cách chỉ có youtube.com/m.youtube.com được
        //     miễn trừ khỏi ngoại lệ desktop mode nếu người dùng liệt kê).
        //     Domain KHÔNG nằm trong danh sách → áp dụng đúng hành vi
        //     Chrome mặc định (bị hạ cấp khi không hiển thị).
        val previousActiveId = activeTabId
        if (previousActiveId != null && previousActiveId != tabId) tabLastUsed[previousActiveId] = System.currentTimeMillis() // 7.72: tab vừa rời đi bắt đầu "rảnh" từ lúc này
        if (previousActiveId != null && previousActiveId != tabId) {
            val previousSession = tabs[previousActiveId]
            val previousUrl = tabMeta[previousActiveId]?.url
            val isExempt = previousUrl != null && isBackgroundKeepAliveExemptUrl(previousUrl)
            if (previousSession != null && !isExempt) {
                previousSession.setActive(false)
            } else if (isExempt) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN keepalive nền] tab '$previousActiveId' ($previousUrl) nằm trong danh sách ngoại lệ — KHÔNG setActive(false), vẫn cho chạy nền thật")
            }
        }
        session.setActive(true)

        activeTabId = tabId
        applyZoomToInputPolicy(tabMeta[tabId]?.url)
        geckoView.setSession(session)
        markActiveForExtensions(session) // Mục 127: addon biết tab nào đang active

        // LAZY LOAD: tab được khôi phục lười (createTabLazy) — lần đầu
        // switchToTab mới thực sự tạo session VÀ tải nội dung, không tải
        // cùng lúc lúc khởi động (tránh 7 session + 7 tải đồng thời làm
        // chậm máy).
        if (isFirstActivation) {
            tab.isUnloaded = false
            val url = tab.url
            val savedState = tab.savedState
            if (savedState != null) {
                try {
                    val state = GeckoSession.SessionState.fromString(savedState)
                    if (state != null) {
                        pendingRestoreTabIds.add(tabId)
                        session.restoreState(state)
                        handler.postDelayed({
                            if (pendingRestoreTabIds.remove(tabId)) {
                                DebugLog.log("Khe $slotIndex: lazy restoreState() không gây điều hướng sau 3s — tải lại URL: $url")
                                session.loadUri(loadableUrlForRestore(url))
                            }
                        }, 3000L)
                    } else {
                        session.loadUri(loadableUrlForRestore(url))
                    }
                } catch (e: Exception) {
                    DebugLog.log("Khe $slotIndex: lazy restoreState lỗi (${e.message}) — loadUri thay thế")
                    session.loadUri(loadableUrlForRestore(url))
                }
            } else if (url.isNotBlank() && url != "about:blank") {
                session.loadUri(loadableUrlForRestore(url))
            }
            DebugLog.log("Khe $slotIndex: lazy load tab $tabId (tạo session THẬT lần đầu) → $url")
        } else {
            // FIX BUG THẬT (người dùng báo: rời tab YouTube đi rồi quay lại
            // thì layout vỡ thành desktop, dù lúc đầu vẫn đang layout mobile
            // đúng — xác nhận qua code: `applyViewportExceptionForUrl()`
            // trước đây CHỈ được gọi ở `onLoadRequest`/`onLocationChange`
            // (mỗi lần điều hướng trang mới), KHÔNG hề được gọi lại ở
            // `switchToTab()` — nếu `session.settings.viewportMode`/
            // `userAgentMode` của tab đó vì bất kỳ lý do gì (kể cả nội bộ
            // GeckoView khi gắn lại session vào GeckoView qua
            // `geckoView.setSession()`) không còn đúng như lúc set ban đầu,
            // KHÔNG có cơ chế nào tự áp lại — y hệt kiểu bug zoom đã sửa
            // trước đó ở đúng chỗ này (`reapplyManualZoom`). Sửa: gọi lại
            // luôn ở đây, mỗi lần chuyển tab — hàm này đã tự kiểm tra
            // `manualDesktopTabIds` để bỏ qua tab đang ở chế độ desktop
            // THỦ CÔNG (không đụng vào lựa chọn tay của người dùng).
            applyViewportExceptionForUrl(session, tab.url)
            // Áp lại mức zoom đã lưu khi chuyển tab — không chỉ khi trang
            // load xong (onPageStop). Tab vừa tạo session lần đầu sẽ được
            // onPageStop áp sau khi load xong.
            val url = tab.url
            if (url.isNotBlank() && url != "about:blank") {
                reapplyManualZoom(tabId, url)
            }
        }

        onTabSwitchedListener?.invoke(tab)
    }

    /**
     * FIX BUG THẬT (người dùng báo, có tái hiện rõ ràng: "upload Drive
     * bình thường khi màn hình sáng dùng app khác, nhưng tắt màn hình là
     * đi ngủ luôn dù đã ghim chạy nền") — xác nhận qua đọc code, không
     * suy đoán: nhánh "ngoại lệ ghim" ở `switchToTab()` (phía trên) CHỈ
     * né được `setActive(false)` — đó là 1 chuyện, còn việc Gecko TỰ hạ
     * ưu tiên tiến trình con khi MẤT SURFACE (tắt màn hình, hoặc chuyển
     * hẳn sang app khác — 2 trường hợp này Android đều gọi
     * `Activity.onPause()`/`onStop()` giống nhau, không phân biệt được ở
     * tầng Activity) là CƠ CHẾ HOÀN TOÀN KHÁC — bằng chứng nằm ngay trong
     * chính comment cũ ở nút "Colab Live" (MainActivity.kt):
     * `setPriorityHint(PRIORITY_HIGH)` mới là cái THẬT SỰ giữ tiến trình
     * con Gecko không bị hạ ưu tiên khi mất surface — và TRƯỚC ĐÂY,
     * `setPriorityHint(PRIORITY_HIGH)` CHỈ được gọi ở 2 nơi: (1) khi có
     * media đang phát VÀ domain nằm trong danh sách ghim (mục 47), (2)
     * khi "Auto Behavior"/nút Colab Live được bật thủ công. KHÔNG CÓ nơi
     * nào set `PRIORITY_HIGH` chỉ vì 1 tab đang nằm trong danh sách ghim
     * chạy nền THÔNG THƯỜNG (không phát media, không phải Colab) — đúng
     * khớp trường hợp upload Drive của người dùng.
     *
     * Cũng cần xử lý riêng trường hợp KHÔNG chuyển tab trong app (đúng
     * kịch bản người dùng mô tả: vẫn đang ở tab Drive, chỉ tắt màn hình
     * hoặc chuyển hẳn sang app khác) — lúc đó `switchToTab()` KHÔNG hề
     * được gọi (không đổi `activeTabId`), nên nhánh ngoại lệ ở đó cũng
     * không có cơ hội chạy. Đây là lý do cần 1 điểm móc RIÊNG, gọi từ
     * `MainActivity.onPause()` — bao trùm cả 2 kịch bản "tắt màn hình"
     * lẫn "chuyển app khác" vì Android xử lý y hệt nhau ở tầng Activity.
     */
    override fun applyBackgroundPriorityForActiveTabIfExempt() {
        val id = activeTabId ?: return
        val session = tabs[id] ?: return
        val url = tabMeta[id]?.url ?: return
        if (isBackgroundKeepAliveExemptUrl(url)) {
            session.setPriorityHint(GeckoSession.PRIORITY_HIGH)
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN keepalive nền] tab đang active '$id' ($url) nằm trong danh sách ghim — setPriorityHint(PRIORITY_HIGH) TRƯỚC KHI mất surface (tắt màn hình/chuyển app khác), tránh bị Gecko tự hạ ưu tiên")
        }
    }

    // ===== Mục 158: trang KHÔNG ghim nền => thật sự "ngủ" khi app ra nền / tắt màn hình, như Chrome =====
    // Trước đây chỉ đổi tab TRONG app mới gọi setActive(false); ở nguyên trang rồi tắt màn hình/sang app khác thì tab đang xem không bị đặt về không hoạt động.
    // Giờ MainActivity.onStop gọi `suspendActiveTabForBackground`, onResume gọi `resumeActiveTabAfterBackground`.
    // KHÔNG ngủ (giữ chạy bình thường) khi: tab thuộc danh sách ghim nền; có tải xuống đang chạy; trang đang tải; vừa đưa file cho trang để TẢI LÊN
    // (trong ${UPLOAD_GRACE_MS / 60000} phút, vì không có API đọc tiến độ upload của trang); đang chờ chọn file; Auto Behavior/Colab Live đang chạy.
    // Media đang phát KHÔNG phải lý do giữ (đúng yêu cầu trước: YouTube không ghim thì không được chạy nền lậu).
    @Volatile private var lastFileHandoffAt = 0L
    @Volatile private var suspendedForBackgroundTabId: String? = null
    private val UPLOAD_GRACE_MS = 30L * 60 * 1000

    /** Gọi mỗi khi file được trao cho trang (FilePrompt confirm hoặc kéo-thả giả lập) — mốc để biết trang có thể đang tải lên. */
    fun noteFileHandedToPage() { lastFileHandoffAt = android.os.SystemClock.uptimeMillis() }

    fun suspendActiveTabForBackground(downloadActive: Boolean) {
        try {
            val id = activeTabId ?: return
            val session = tabs[id] ?: return
            val tab = tabMeta[id] ?: return
            val sinceHandoff = android.os.SystemClock.uptimeMillis() - lastFileHandoffAt
            val reason = when {
                isBackgroundKeepAliveExemptUrl(tab.url) -> "tab thuộc danh sách ghim chạy nền"
                downloadActive -> "đang có tải xuống"
                tab.isLoading -> "trang đang tải"
                pendingFilePrompt != null -> "đang chờ chọn file tải lên"
                lastFileHandoffAt != 0L && sinceHandoff < UPLOAD_GRACE_MS -> "vừa đưa file cho trang (có thể đang tải lên, giữ tối đa ${UPLOAD_GRACE_MS / 60000} phút)"
                autoBehaviorRunnable != null || autoBehaviorPriorityTabId == id -> "Auto Behavior/Colab Live đang chạy"
                else -> null
            }
            if (reason != null) {
                DebugLog.log("Khe $slotIndex: [nền] KHÔNG cho tab '${tab.url}' ngủ khi ra nền — $reason")
                return
            }
            session.setActive(false)
            suspendedForBackgroundTabId = id
            DebugLog.log("Khe $slotIndex: [nền] tab đang xem '${tab.url}' (không ghim, không tải file) => setActive(false) như Chrome")
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [nền] suspendActiveTabForBackground LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    fun resumeActiveTabAfterBackground() {
        try {
            val id = suspendedForBackgroundTabId ?: return
            suspendedForBackgroundTabId = null
            if (id == activeTabId) {
                tabs[id]?.setActive(true)
                DebugLog.log("Khe $slotIndex: [nền] quay lại app => setActive(true) cho tab đang xem")
            }
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [nền] resumeActiveTabAfterBackground LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    override fun getTabs(): List<BrowserTab> {
        // SỬA BUG (người dùng báo tab lộn xộn): dùng `tabOrder` (thứ tự
        // chèn thật) thay vì `tabMeta.values` (ConcurrentHashMap — thứ tự
        // theo bucket hash nội bộ, KHÔNG phải thứ tự mở tab).
        return tabOrder.mapNotNull { tabMeta[it] }
    }

    override fun getActiveTab(): BrowserTab? {
        return activeTabId?.let { tabMeta[it] }
    }

    // ===== Drag & Drop =====

    override fun handleDropUri(uri: Uri, mimeType: String?) {
        val actualMime = mimeType ?: context.contentResolver.getType(uri) ?: "*/*"

        try {
            val fileName = getFileNameFromUri(uri) ?: "dropped_file"
            val tempFile = File(context.cacheDir, "drops/$fileName")
            tempFile.parentFile?.mkdirs()

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }

            val js = """
                (function() {
                    var inputs = document.querySelectorAll('input[type="file"]');
                    if (inputs.length > 0) {
                        window.dispatchEvent(new CustomEvent('livebrowser:filedrop', {
                            detail: { path: '${tempFile.absolutePath}', mime: '$actualMime' }
                        }));
                        return 'file_drop_triggered';
                    }
                    return 'no_file_input';
                })()
            """.trimIndent()

            evaluateJs(js) { result ->
                DebugLog.log("Drop file: $fileName ($actualMime) → $result")
            }

        } catch (e: Exception) {
            DebugLog.log("Drop file error: ${e.message}")
        }
    }

    // ===== Auto Behavior (Giả lập người dùng) =====

    // Theo dõi tab nào đang được nâng PRIORITY_HIGH vì Auto Behavior — cần
    // lưu lại để hạ đúng tab đó khi dừng (activeTabId có thể đã đổi giữa
    // lúc bắt đầu và lúc dừng, không hạ nhầm tab khác).
    private var autoBehaviorPriorityTabId: String? = null

    /**
     * Giả lập hành vi người dùng để tránh bot detection.
     * Chạy ngẫu nhiên: scroll, click, đợi.
     *
     * FIX BUG THẬT (Colab chết khi tắt màn hình lâu, KHÔNG phát media —
     * xem PROJECT_STATUS.md mục 8zm/8zzu): `setPriorityHint(PRIORITY_HIGH)`
     * trước đây CHỈ áp dụng khi MediaSession phát media thật (đúng khớp
     * bằng chứng A/B người dùng: "phát nhạc + Colab + tắt màn hình = sống,
     * chỉ Colab không phát gì = chết"). Auto Behavior CHÍNH LÀ cơ chế giữ
     * Colab "sống" (giả lập tương tác để tránh bị coi là idle) — tab nó
     * đang chạy cũng cần được nâng ưu tiên y hệt tab phát media, vì đây là
     * CÙNG 1 vấn đề gốc (tiến trình con GeckoSession bị hạ ưu tiên khi mất
     * surface), không phải vấn đề riêng của media.
     */
    // FIX GỐC "bàn phím tự rớt khi đang gõ" (bằng chứng: log thật — bàn phím
    // bật/tắt lặp lại mỗi ~10s, cùng lúc log có 6 dòng "Auto behavior started"
    // trong 2,5 phút): `startAutoBehavior()` được gọi lại ở MỌI `onPageStop`
    // của tab active nhưng KHÔNG hề huỷ vòng lặp cũ → mỗi lần load trang lại
    // đẻ thêm 1 vòng lặp tự-lên-lịch song song (không bao giờ dừng, trừ khi
    // gọi stopAutoBehavior). Sau vài trang có 5-10 vòng chạy cùng lúc, mỗi
    // vòng cứ 5-30s lại chạy 1 hành động ngẫu nhiên trong 5 hành động, trong
    // đó có `document.querySelector('button, a, input')?.focus()` — chuyển
    // focus khỏi ô nhập đang gõ sang nút/link đầu tiên của trang → Gecko gọi
    // hideSoftInput() → bàn phím rớt. `scrollTo(random)` + `body.click()`
    // cũng giải thích luôn triệu chứng "loạn cảm ứng / mở nhầm nút" (mục 59).
    //
    // Sửa: (1) đúng 1 vòng lặp duy nhất (giữ tham chiếu Runnable để huỷ/không
    // tạo trùng); (2) tuyệt đối KHÔNG còn `.focus()`; (3) bỏ qua lượt khi
    // người dùng đang thao tác (MainActivity cấp `userInteractionGuard`) hoặc
    // khi phần tử đang focus là ô nhập liệu (kiểm tra thêm ở phía JS).
    private var autoBehaviorRunnable: Runnable? = null

    // Thời điểm (uptimeMillis) Gecko gọi `onShowActionRequest` gần nhất — để
    // `SelectionFallbackMenu` biết long-press vừa rồi Gecko ĐÃ tự hiện menu
    // (thì không chen vào) hay KHÔNG (Colab/Monaco — mới hiện menu dự phòng).
    @Volatile
    var lastSelectionActionUptime: Long = 0L

    // MainActivity gán: trả về true nếu người dùng đang tương tác (đang chạm
    // màn hình gần đây / bàn phím đang hiện) → bỏ qua lượt giả lập này.
    @Volatile
    var userInteractionGuard: (() -> Boolean)? = null

    /**
     * Mục 122: Auto Behavior (PRIORITY_HIGH + cuộn/nhấp ngẫu nhiên) chỉ được áp cho trang ĐÃ BẬT CHẠY NỀN: miền đang ghim, hoặc Colab khi nút
     * Colab Live đang bật. Trước đây cờ `auto_behavior` (lưu bền qua phiên/import) khiến MỌI trang đang xem (google.com, claude.ai...) bị nâng
     * ưu tiên và bị cuộn/nhấp giả — log: "Auto Behavior nâng PRIORITY_HIGH cho tab ..." ở mọi trang.
     */
    private fun autoBehaviorAllowedForActiveTab(): Boolean {
        if (AppPrefs.getBoolean(context, slotIndex, "background_paused", false)) return false
        val url = activeTabId?.let { tabMeta[it]?.url } ?: return false
        val host = hostOf(url) ?: return false
        if (host.endsWith("colab.research.google.com") && AppPrefs.getBoolean(context, slotIndex, "colablive_keepalive_on", false)) return true
        return com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.isDomainPinned(context, slotIndex, host)
    }

    private var autoBehaviorTick = 0

    fun startAutoBehavior() {
        if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) return

        if (autoBehaviorAllowedForActiveTab()) {
            activeTabId?.let { tabId ->
                tabs[tabId]?.setPriorityHint(GeckoSession.PRIORITY_HIGH)
                autoBehaviorPriorityTabId = tabId
                DebugLog.log("Khe $slotIndex: Auto Behavior nâng PRIORITY_HIGH cho tab $tabId")
            }
        }

        if (autoBehaviorRunnable != null) {
            // Đã có 1 vòng lặp — KHÔNG đẻ thêm (nguyên nhân gốc bàn phím rớt).
            return
        }

        val behaviorRunnable = object : Runnable {
            override fun run() {
                if (!AppPrefs.getBoolean(context, slotIndex, "auto_behavior", false)) {
                    autoBehaviorRunnable = null
                    return
                }

                val userBusy = try { userInteractionGuard?.invoke() ?: false } catch (e: Exception) { false }
                // Mục 124: log MẪU để biết vòng lặp có THẬT SỰ chạy hay không (trước đây không có dòng log nào cho từng nhịp).
                val allowedNow = autoBehaviorAllowedForActiveTab()
                autoBehaviorTick++
                if ((userBusy || !allowedNow) && (autoBehaviorTick <= 3 || autoBehaviorTick % 10 == 0)) {
                    DebugLog.log("Khe $slotIndex: [Auto Behavior] BỎ QUA nhịp #$autoBehaviorTick: userBusy=$userBusy, trangĐượcPhép=$allowedNow, tab=${activeTabId?.let { tabMeta[it]?.url }}")
                }
                if (!userBusy && allowedNow) {
                    // Mỗi hành động là 1 IIFE đơn (evaluateJs bọc "return (<script>)")
                    // và đều bắt đầu bằng guard: đang gõ vào ô nhập thì bỏ qua.
                    // KHÔNG dùng .focus() — chỉ scroll/click/mousemove nhẹ.
                    val guard = "var a=document.activeElement; if(a&&(a.isContentEditable||a.tagName==='INPUT'||a.tagName==='TEXTAREA'||a.tagName==='SELECT')) return 'skip-editing';"
                    val actions = listOf(
                        "window.scrollBy(0, ${random.nextInt(100, 500)});",
                        "window.scrollBy(0, -${random.nextInt(50, 300)});",
                        "document.dispatchEvent(new MouseEvent('mousemove', {bubbles: true, clientX: ${random.nextInt(50, 300)}, clientY: ${random.nextInt(50, 300)}}));",
                        "document.body.click();",
                        "window.scrollTo(0, document.body.scrollHeight * ${random.nextDouble()});"
                    )
                    val action = actions[random.nextInt(actions.size)]
                    val tickNo = autoBehaviorTick
                    evaluateJs("(function(){ $guard $action })()") { r ->
                        if (tickNo <= 5 || tickNo % 10 == 0) {
                            DebugLog.log("Khe $slotIndex: [Auto Behavior] nhịp #$tickNo '${action.take(30)}' -> kết quả=${r?.take(80)} (null/rỗng = KHÔNG có tab nào trả lời)")
                        }
                    }
                }

                // Đợi ngẫu nhiên 5-30 giây trước action tiếp
                val delay = 5000 + random.nextInt(25000)
                handler.postDelayed(this, delay.toLong())
            }
        }

        autoBehaviorRunnable = behaviorRunnable
        handler.postDelayed(behaviorRunnable, 10000) // Bắt đầu sau 10 giây
        DebugLog.log("Auto behavior started for slot $slotIndex")
    }

    /**
     * Mục 123: nút "Dừng" trên thông báo = tạm dừng chạy nền THẬT: dừng Auto Behavior, hạ ưu tiên mọi tab, và cho các tab đang ẩn (trước đó
     * được ngoại lệ "ghim" nên vẫn chạy) về trạng thái không hoạt động như tab thường.
     */
    fun pauseBackground() {
        try {
            stopAutoBehavior()
            autoBehaviorPriorityTabId = null
            var deactivated = 0
            tabs.forEach { (id, session) ->
                try {
                    session.setPriorityHint(GeckoSession.PRIORITY_DEFAULT)
                    if (id != activeTabId) { session.setActive(false); deactivated++ }
                } catch (e: Throwable) { /* session có thể đã đóng */ }
            }
            DebugLog.log("Khe $slotIndex: [chạy nền] ĐÃ TẠM DỪNG — hạ ưu tiên mọi tab, tắt hoạt động $deactivated tab đang ẩn, dừng Auto Behavior")
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [chạy nền] pauseBackground LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    fun stopAutoBehavior() {
        // Chỉ huỷ ĐÚNG vòng lặp của Auto Behavior. Trước đây gọi
        // `handler.removeCallbacksAndMessages(null)` xoá LUÔN mọi callback
        // khác trên cùng handler (vd timeout dọn evalCallbacks 15s).
        autoBehaviorRunnable?.let { handler.removeCallbacks(it) }
        autoBehaviorRunnable = null
        // Hạ lại PRIORITY_DEFAULT đúng tab đã nâng lên lúc bắt đầu — không
        // dùng activeTabId ở đây vì có thể đã đổi tab giữa lúc bắt đầu và
        // lúc dừng, hạ nhầm tab khác đang thật sự cần giữ ưu tiên (VD đang
        // phát media) sẽ vô tình huỷ luôn priority hint của MediaSession.
        autoBehaviorPriorityTabId?.let { tabId ->
            tabs[tabId]?.setPriorityHint(GeckoSession.PRIORITY_DEFAULT)
            DebugLog.log("Khe $slotIndex: Auto Behavior hạ lại PRIORITY_DEFAULT cho tab $tabId")
        }
        autoBehaviorPriorityTabId = null
        DebugLog.log("Auto behavior stopped for slot $slotIndex")
    }

    // ===== Internal =====

    /**
     * Bật/tắt ép viewport-desktop THEO TỪNG LẦN ĐIỀU HƯỚNG, dựa vào danh
     * sách tên miền do người dùng tự nhập (`fp_desktop_skip_viewport_domains`,
     * phân cách bằng dấu phẩy — VD "youtube.com,m.youtube.com"). CHỈ áp
     * dụng ngoại lệ (giữ layout mobile) cho ĐÚNG các tên miền trong danh
     * sách — mọi tên miền KHÁC vẫn ép desktop đầy đủ như mặc định an toàn
     * (đúng yêu cầu người dùng: không ảnh hưởng độ nhất quán fingerprint ở
     * các trang không liên quan).
     *
     * Gọi từ `onLoadRequest` (TRƯỚC khi trang đích thật sự tải) — đổi
     * `session.settings.viewportMode`/`userAgentMode` lúc này có hiệu lực
     * cho chính lần tải đó (khác với lúc tạo session — chỉ áp dụng được 1
     * lần cho cả tab, không theo từng trang).
     */
    /**
     * Gọi từ Settings sau khi lưu danh sách ngoại lệ tên miền — trước đây
     * nút Lưu CHỈ ghi vào `AppPrefs`, KHÔNG áp dụng lại cho tab ĐANG MỞ SẴN
     * (chỉ có tác dụng ở lần điều hướng TIẾP THEO, vì logic nằm trong
     * `onLoadRequest`) — người dùng báo "thêm thủ công mà không có thay đổi
     * gì cả" rất có thể là do đang đứng NGAY TRÊN trang đó lúc lưu, cần tải
     * lại mới thấy hiệu lực.
     */
    fun applyExceptionAndReloadActiveTab() {
        val id = activeTabId ?: return
        val session = tabs[id] ?: return
        val url = tabMeta[id]?.url ?: return
        applyViewportExceptionForUrl(session, url)
        session.reload()
    }

    /**
     * GIẢM NHẸ triệu chứng "layout YouTube lệch/khuất sang trái" (mục
     * 8zzi #6, người dùng xác nhận muốn thử hướng này) — theo đúng cách
     * "Xem bằng máy tính" thật trên Chrome mobile hoạt động: trang desktop
     * vẫn giữ NGUYÊN bố cục thật (không bẻ lại CSS gốc của trang), chỉ THU
     * NHỎ toàn bộ lại cho vừa màn hình hẹp bằng CSS `zoom` — đánh đổi: chữ
     * nhỏ hơn, cần phóng to tay (pinch-zoom) khi muốn đọc, giống hệt trải
     * nghiệm "Request Desktop Site" thật trên điện thoại.
     *
     * XÁC NHẬN TRƯỚC KHI DÙNG (không đoán): `zoom` là thuộc tính CSS vốn
     * CHỈ WebKit/Blink hỗ trợ trong nhiều năm — Firefox/Gecko MỚI thêm hỗ
     * trợ từ bản 126 (2024). Bản GeckoView pin trong `build.gradle` là
     * 145.x — đủ mới, an toàn dùng.
     *
     * `evaluateJs()` phát script tới MỌI frame của MỌI tab đang mở (kiến
     * trúc có sẵn từ trước, xem `attachEvalBridgeToSession` gọi cho từng
     * session) — KHÔNG lọc theo tab nào gọi hàm này. Vì vậy script PHẢI TỰ
     * kiểm tra `location.hostname` của chính nó có khớp danh sách ngoại lệ
     * hay không NGAY TRONG JS, không lọc phía Kotlin trước khi gửi — nếu
     * không sẽ áp nhầm zoom vào tab khác đang mở song song.
     */
    /**
     * BUG THẬT (người dùng báo: chỉnh zoom 90% xong refresh trang thì mất
     * luôn, quay lại 100%): mức zoom set qua `document.documentElement
     * .style.zoom` là INLINE STYLE do JS gán — trang tải lại (refresh)
     * nghĩa là DOM mới hoàn toàn, style cũ mất sạch, không có cơ chế nào
     * tự áp lại nếu không chủ động làm.
     *
     * SỬA LẠI LẦN 2 theo đúng góp ý người dùng: lưu theo TAB (bản đầu)
     * nghĩa là đóng tab là mất, phải chỉnh lại từ đầu mỗi lần mở lại cùng
     * trang — không giống Chrome thật (nhớ zoom theo TỪNG TRANG WEB, còn
     * nguyên dù đóng hết tab/khởi động lại app). Đổi sang đọc từ
     * `ZoomPrefs` (lưu bền theo domain, xuyên suốt tab/phiên) thay vì
     * field tạm trên `BrowserTab`.
     */
    /**
     * FIX RACE CONDITION (PDF chẩn đoán): applyDesktopLayoutZoomIfNeeded và
     * reapplyManualZoom trước đây chạy bất đồng bộ độc lập — cả 2 đều gọi
     * evaluateJs() riêng, thứ tự không đảm bảo, script sau có thể ghi đè
     * zoom của script trước (VD desktop zoom tính 0.38 → áp, xong manual
     * zoom 70% → áp đè lại, hoặc ngược lại tùy timing).
     *
     * FIX ZOOM YOUTUBE HOST (PDF chẩn đoán): ZoomPrefs lưu theo host, nhưng
     * YouTube nhảy m.youtube.com ↔ www.youtube.com liên tục (thấy rõ trong
     * log). Zoom lưu ở m.youtube.com khác key với www.youtube.com → tra ra
     * mặc định 100% dù số dialog hiện đúng (dialog đọc lúc URL cũ, áp lúc
     * URL đã đổi host). Sửa: normalize host YouTube về "youtube.com" trước
     * khi đọc/ghi ZoomPrefs.
     *
     * Giải pháp: gộp cả 2 logic zoom vào 1 hàm duy nhất, gửi 1 script JS
     * duy nhất — trong script đó tính final zoom 1 lần, áp 1 lần.
     */
    private fun reapplyManualZoom(tabId: String, url: String) {
        // Normalize YouTube host để ZoomPrefs luôn dùng 1 key duy nhất
        // bất kể trang đang ở m.youtube.com hay www.youtube.com
        val normalizedUrl = normalizeYouTubeHostForZoom(url)
        val manualPercent = ZoomPrefs.getZoomForUrl(context, slotIndex, normalizedUrl)
        applyZoomCombined(tabId, manualPercent)
    }

    /**
     * Public — gọi lại từ MainActivity khi THOÁT fullscreen (xem
     * `onFullScreen` ở ContentDelegate: lúc VÀO fullscreen zoom bị tắt hẳn
     * về '', nhưng lúc THOÁT ra cần tính lại đúng zoom như trước — dùng lại
     * chính logic reapplyManualZoom() cho tab đang active, không viết lại).
     */
    fun reapplyZoomForActiveTab() {
        val tabId = activeTabId ?: return
        val url = tabMeta[tabId]?.url ?: return
        if (url.isNotBlank() && url != "about:blank") {
            reapplyManualZoom(tabId, url)
        }
    }

    /**
     * Gộp desktop-layout zoom + manual zoom thành 1 script JS duy nhất.
     * Tính final scale trong JS rồi áp 1 lần — không còn 2 async script
     * đè nhau nữa.
     */
    private fun applyZoomCombined(tabId: String, manualPercent: Int) {
        try {
            val domainsRaw = AppPrefs.getString(context, slotIndex, "fp_desktop_skip_viewport_domains", "")
            val exceptionDomains = domainsRaw.split(",", "\n")
                .map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            val domainsJsArray = if (exceptionDomains.isNotEmpty())
                exceptionDomains.joinToString(",") { "\"${it.replace("\"", "")}\"" }
            else "[]"
            val manualScale = manualPercent / 100.0

            // SỬA (mục 59 PROJECT_STATUS.md — "màn hình như bị loạn cảm
            // ứng"): trước đây zoom áp qua CSS `document.documentElement
            // .style.zoom`, một thuộc tính KHÔNG CHUẨN có lịch sử hỗ trợ
            // chưa hoàn thiện trong Gecko (Bugzilla #1254064). Quan trọng
            // hơn: Bugzilla #1257579 xác nhận CHÍNH THỨC có lớp bug
            // sai lệch giữa toạ độ chạm (hit-testing) và mức zoom/resolution
            // khi dùng cơ chế này — khớp đúng triệu chứng "chạm vào 1 chỗ
            // nhưng tác động sai chỗ khác".
            //
            // ĐÃ TRA CỨU LẠI (không đoán): GeckoView KHÔNG có API embedder
            // công khai kiểu "set page zoom" cấp session (PanZoomController
            // chỉ có scrollBy/scrollTo, không có setZoom/zoomToRect —
            // xác nhận qua javadoc GeckoView hiện hành, mục Changelog).
            // Hướng thay thế ĐÚNG cơ chế native của Gecko (không phải
            // CSS, tránh đúng lớp bug hit-testing ở trên): điều khiển
            // zoom qua chính thẻ <meta name="viewport" content=
            // "initial-scale=...">, cơ chế Gecko dùng để tính toán
            // resolution/hit-testing THẬT (không phải ghi đè kích thước
            // hiển thị bằng CSS sau khi layout/hit-test đã tính xong).
            // Xác nhận qua Bugzilla #932690 (thảo luận GeckoView
            // zoom/viewport, cùng thread với bug zoom-property ở trên):
            // trang có đặt initial-scale qua meta viewport thì Gecko áp
            // dụng ở đúng tầng resolution/viewport, không phải tầng CSS
            // layout riêng lẻ như style.zoom.
            //
            // Cách làm: tìm thẻ <meta name="viewport"> có sẵn (nếu có,
            // hầu hết trang responsive đều có) và ghi đè content của nó
            // bằng initial-scale=finalScale, giữ nguyên width=device-width
            // nếu trang đã khai; nếu trang KHÔNG có thẻ này, tạo mới.
            // manual/desktop scale = 1.0 (finalScale=1.0) thì XOÁ HẲN thẻ
            // do app tự thêm, trả trang về viewport gốc của chính nó (nếu
            // trang tự có thẻ viewport riêng, không đụng vào — chỉ đụng
            // thẻ do CHÍNH app này thêm, đánh dấu qua data-attribute).
            //
            // ⚠️ CHƯA build/test trên máy thật — đây là thay đổi kiến trúc
            // (đổi cơ chế zoom), cần xác nhận: (a) zoom vẫn phóng to/thu
            // nhỏ được như trước, (b) hit-testing/chạm giờ đúng vị trí kể
            // cả khi bật "Chế độ máy tính", (c) không phá vỡ trang nào tự
            // quản lý viewport riêng của nó (nghi vấn: trang có sẵn 1 thẻ
            // <meta name="viewport"> KHÁC id/data-attribute app gắn — code
            // dưới đây match theo name="viewport" bất kể ai tạo, ưu tiên
            // đơn giản/nhất quán hơn giữ 2 thẻ viewport song song, vốn
            // không hợp lệ theo spec HTML dù trình duyệt thường chỉ đọc
            // thẻ đầu tiên).
            val script = """
                (function() {
                    var domains = [$domainsJsArray];
                    var host = location.hostname.toLowerCase();
                    var isException = domains.length > 0 && domains.some(function(d) {
                        return host === d || host.slice(-(d.length + 1)) === ('.' + d);
                    });
                    // BUG THẬT đã tìm ra (người dùng báo: đặt "ngoại lệ
                    // desktop" cho YouTube — kỳ vọng PLAYER chất lượng
                    // desktop nhưng LAYOUT trang vẫn gọn kiểu mobile — thực
                    // tế lại ra CẢ LAYOUT lẫn PLAYER đều thành desktop, tức
                    // thiết kế "layout mobile" không hề có tác dụng):
                    // `applyViewportExceptionForUrl()` (hàm khác, phía
                    // Kotlin) đã CỐ Ý đặt `viewportMode = MOBILE` cho đúng
                    // domain trong `isException` này (chỉ đổi User-Agent
                    // giả desktop để site tự chọn stream chất lượng cao,
                    // KHÔNG đổi layout viewport) — nhưng đoạn code NGAY DƯỚI
                    // ĐÂY (đã xoá) lại ĐỘC LẬP tự thu nhỏ
                    // `document.documentElement.style.zoom` xuống còn
                    // ~0.3–0.4 cho ĐÚNG cùng danh sách domain đó. Zoom CSS ở
                    // mức `documentElement` không chỉ là phóng to hình ảnh —
                    // nó làm `window.innerWidth` (viewport LOGIC mà các
                    // media-query/JS của trang dùng để tự quyết định layout
                    // mobile hay desktop) báo về to hơn thật (VD màn 396px
                    // vật lý, zoom=0.396 → innerWidth báo ~1000px) — TỰ KÍCH
                    // HOẠT layout desktop thật của trang, xoá sạch tác dụng
                    // của `viewportMode=MOBILE` đã đặt phía Kotlin. Đoạn
                    // code này vốn được viết cho 1 thiết kế CŨ (giả định
                    // viewportMode ĐANG là DESKTOP, cần zoom nhỏ lại cho vừa
                    // màn hình hẹp) — thiết kế mới ở `applyViewportExceptionForUrl()`
                    // đã đổi hẳn hướng (giữ MOBILE, không cần zoom) nhưng
                    // đoạn zoom cũ này bị BỎ SÓT, không xoá theo, nên 2 cơ
                    // chế đá nhau.
                    // SỬA: domain ngoại lệ KHÔNG còn tự zoom gì nữa — để
                    // nguyên layout mobile thật (đúng ý định gốc), việc giả
                    // desktop chỉ còn nằm ở User-Agent (phía Kotlin). Biến
                    // `isException` GIỮ LẠI chỉ để in log chẩn đoán.
                    var desktopScale = 1.0;
                    // Manual zoom từ ZoomPrefs (người dùng chỉnh thủ công)
                    var manualScale = $manualScale;
                    // Final scale: manual zoom nhân thêm lên desktop scale
                    // Ưu tiên manual zoom nếu người dùng đã đặt (khác 1.0)
                    var finalScale;
                    if (manualScale !== 1.0) {
                        finalScale = manualScale;
                        window.__manualZoomOverride = true;
                    } else {
                        finalScale = desktopScale;
                        window.__manualZoomOverride = false;
                    }
                    // Dọn sạch dấu vết cơ chế CŨ (CSS zoom) nếu còn sót lại
                    // từ 1 lần load trước đó (vd trang không reload, chỉ
                    // đổi setting) — tránh 2 cơ chế zoom cùng áp 1 lúc.
                    if (document.documentElement.style.zoom) {
                        document.documentElement.style.zoom = '';
                    }
                    var meta = document.querySelector('meta[name="viewport"]');
                    if (finalScale !== 1.0) {
                        var content = 'width=device-width, initial-scale=' + finalScale +
                                      ', minimum-scale=' + (finalScale * 0.5) +
                                      ', maximum-scale=' + (finalScale * 3) +
                                      ', user-scalable=yes';
                        if (!meta) {
                            meta = document.createElement('meta');
                            meta.setAttribute('name', 'viewport');
                            meta.setAttribute('data-colablive-zoom', '1');
                            (document.head || document.documentElement).appendChild(meta);
                        }
                        meta.setAttribute('content', content);
                    } else if (meta && meta.getAttribute('data-colablive-zoom') === '1') {
                        // Thẻ này do CHÍNH app tạo lúc trước (đánh dấu qua
                        // data-attribute) và giờ không cần zoom nữa — xoá
                        // hẳn để trang tự quyết viewport của nó (khớp hành
                        // vi "chưa từng bị app đụng vào" khi finalScale=1.0
                        // ngay từ đầu, vì lúc đó if() này không tạo ra meta).
                        meta.parentNode.removeChild(meta);
                    }
                    return 'zoom(meta-viewport)=' + finalScale.toFixed(3) +
                           ' (desktop=' + desktopScale.toFixed(3) +
                           ', manual=' + manualScale.toFixed(3) +
                           ', exception=' + isException + ')';
                })();
            """.trimIndent()
            // FIX HIỆU NĂNG (bug fan-out): gọi evaluateJsForTab(tabId, ...)
            // tường minh thay vì evaluateJs() — chỉ nhắm đúng tab đang zoom,
            // không phát script này tới mọi frame của mọi tab khác đang mở.
            evaluateJsForTab(tabId, script) { result ->
                DebugLog.log("Khe $slotIndex: [zoom gộp] $result")
            }
        } catch (e: Exception) {
            DebugLog.log("applyZoomCombined lỗi: ${e.message}")
        }
    }

    /** Normalize YouTube mobile/desktop host về 1 key chung cho ZoomPrefs */
    private fun normalizeYouTubeHostForZoom(url: String): String {
        return try {
            val uri = android.net.Uri.parse(url)
            val host = uri.host ?: return url
            if (host.endsWith("youtube.com")) {
                // m.youtube.com, www.youtube.com, music.youtube.com, v.v.
                // → dùng "youtube.com" làm key chung để zoom nhất quán
                uri.buildUpon().authority("youtube.com").build().toString()
            } else {
                url
            }
        } catch (e: Exception) { url }
    }

    /**
     * CHẨN ĐOÁN player YouTube spin mãi không phát (xem chú thích ở
     * `onPageStop`) — hỏi thẳng `<video>` element thật đang thấy gì, KHÔNG
     * đoán thêm nữa. `readyState` 0-4 (0=HAVE_NOTHING tới 4=HAVE_ENOUGH_DATA
     * để phát mượt), `networkState` 0-3 (3=NETWORK_NO_SOURCE — trình duyệt
     * không tìm được nguồn phát được, dấu hiệu mạnh nhất của lỗi codec/DRM),
     * `error.code` nếu có (1=ABORTED, 2=NETWORK, 3=DECODE — lỗi giải mã
     * THẬT, rất có thể là nguyên nhân — GeckoView embedded có thể thiếu
     * quyền truy cập MediaCodec phần cứng hoặc bị giới hạn nếu khe khác
     * đang chiếm hết decoder phần cứng cùng lúc).
     *
     * Lặp 6 lần, cách nhau 2s (tổng 12s) — đủ để thấy DIỄN BIẾN thật (spin
     * mãi = readyState đứng yên ở 0-1 suốt 12s; phát được = readyState lên
     * 3-4 trong vài giây đầu).
     */
    private fun pollVideoDiagnostic(tabId: String, url: String, attempt: Int) {
        if (attempt >= 6) return
        if (tabId != activeTabId) return // người dùng đã rời trang, dừng poll cho đỡ tốn
        // BỔ SUNG (mục 62.1 PROJECT_STATUS.md — người dùng hỏi thẳng tại
        // sao chưa fix, không chỉ chẩn đoán mãi). Mục 50.2 đã RÚT LẠI giả
        // thuyết "tranh chấp CPU giữa 2 TIẾN TRÌNH khác nhau" (bằng chứng
        // thời gian không khớp), nhưng CHƯA hề loại giả thuyết KHÁC vẫn
        // còn treo từ mục 49 gốc: tranh chấp DECODER PHẦN CỨNG dùng chung
        // giữa các SESSION GeckoView khác nhau TRONG CÙNG 1 TIẾN TRÌNH
        // (dẫn Bugzilla #1545817 + mozilla/geckoview#203) — đây là tranh
        // chấp Ở TẦNG KHÁC (phần cứng codec dùng chung của thiết bị, không
        // phải CPU giữa 2 tiến trình OS), hoàn toàn có thể vẫn đúng dù giả
        // thuyết đa-tiến-trình đã sai. Trước đây CHƯA từng đo trực tiếp có
        // bao nhiêu session khác (tab khác, CÙNG khe này) đang tồn tại lúc
        // video kẹt — thêm phép đo này NGAY BÂY GIỜ, tự động, không cần
        // người dùng tự dàn dựng kịch bản test thủ công nữa.
        val sessionCountSameSlot = tabMeta.size
        val js = """
            (function() {
                var v = document.querySelector('video');
                if (!v) return 'KHÔNG TÌM THẤY THẺ <video> NÀO TRONG TRANG';
                var err = v.error ? ('code=' + v.error.code + ' message=' + v.error.message) : 'không có';
                var buffered = '';
                try {
                    for (var i = 0; i < v.buffered.length; i++) {
                        buffered += '[' + v.buffered.start(i).toFixed(1) + '-' + v.buffered.end(i).toFixed(1) + ']';
                    }
                } catch (e) { buffered = '(lỗi đọc buffered: ' + e.message + ')'; }
                if (buffered === '') buffered = '(rỗng — chưa buffer được byte nào)';

                // ĐÃ GỠ BỎ việc chủ động gọi v.play() (từng thêm ở lượt
                // trước) — RỦI RO THẬT không phải suy đoán: gọi play() từ
                // BÊN NGOÀI, không thông qua chính cơ chế điều khiển nội bộ
                // của player YouTube, có thể can thiệp vào đúng lúc player
                // đang tự load/play/pause để phục hồi buffer — hoàn toàn có
                // thể CHÍNH LÀ nguyên nhân gây ra (hoặc làm nặng thêm)
                // "AbortError: The fetching process for the media resource
                // was aborted by the user agent at the user's request" đã
                // thấy trong log — công cụ chẩn đoán không nên làm thay đổi
                // trạng thái của chính thứ nó đang đo. Quay lại THUẦN ĐỌC
                // (readyState/networkState/error/buffered) như bản đầu.
                var frameDiag = '(không có getVideoPlaybackQuality)';
                try {
                    if (typeof v.getVideoPlaybackQuality === 'function') {
                        var q = v.getVideoPlaybackQuality();
                        frameDiag = 'totalVideoFrames=' + q.totalVideoFrames + ' droppedVideoFrames=' + q.droppedVideoFrames;
                    }
                } catch (e) { frameDiag = '(lỗi đọc: ' + e.message + ')'; }

                var visDiag = 'visibilityState=' + document.visibilityState + ' hidden=' + document.hidden;

                return 'readyState=' + v.readyState + ' networkState=' + v.networkState +
                       ' paused=' + v.paused + ' currentTime=' + v.currentTime.toFixed(2) +
                       ' duration=' + (isNaN(v.duration) ? 'NaN' : v.duration.toFixed(1)) +
                       ' error=[' + err + '] buffered=' + buffered +
                       ' src=' + (v.currentSrc ? v.currentSrc.substring(0, 60) : '(rỗng)') +
                       ' | ' + frameDiag + ' | ' + visDiag;
            })();
        """.trimIndent()
        // Gọi evaluateJsForTab TƯỜNG MINH với đúng tabId đã biết (không
        // dựa ngầm vào activeTabId của evaluateJs()) — dù đã kiểm tra
        // `tabId == activeTabId` ở trên, dùng tabId tường minh vẫn đúng
        // 100% ngay cả trong khung thời gian hẹp giữa lúc gửi script và
        // lúc nhận callback (nếu người dùng đổi tab active đúng lúc đó).
        evaluateJsForTab(tabId, js) { result ->
            // BỔ SUNG mục 62.1: log kèm SỐ TAB (session) khác đang tồn tại
            // trong CHÍNH khe này tại đúng thời điểm quan sát — bằng chứng
            // còn thiếu để xác nhận/loại trừ giả thuyết tranh chấp decoder
            // phần cứng GIỮA CÁC SESSION cùng tiến trình (khác hẳn giả
            // thuyết đa-tiến-trình đã bị mục 50.2 bác bỏ). Nếu lần tới bug
            // tái hiện mà dòng này cho thấy `tabCount=1` (chỉ đúng 1 tab —
            // tab đang xem video, không tab nào khác) mà VẪN kẹt, giả
            // thuyết tranh chấp decoder (dù cùng hay khác tiến trình) coi
            // như bị loại HẲN, không chỉ riêng nhánh đa-tiến-trình.
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN video lần ${attempt + 1}/6, +${attempt * 2}s, tabCountKheThis=$sessionCountSameSlot] $result")
            handler.postDelayed({ pollVideoDiagnostic(tabId, url, attempt + 1) }, 2000L)
        }
    }

    // applyDesktopLayoutZoomIfNeeded() ĐÃ BỊ XÓA — logic gộp vào applyZoomCombined()
    // được gọi qua reapplyManualZoom(). Xem chú thích race condition ở reapplyManualZoom.

    /**
     * TÍNH NĂNG MỚI — dùng LẠI đúng pattern "danh sách ngoại lệ theo domain,
     * người dùng tự nhập" đã có sẵn (xem `applyViewportExceptionForUrl` +
     * pref `fp_desktop_skip_viewport_domains`) cho việc quyết định tab nào
     * được PHÉP tiếp tục chạy nền thật khi không hiển thị (không bị
     * `setActive(false)`) — xem giải thích đầy đủ ở `switchToTab()`. Domain
     * do người dùng tự liệt kê vào `bg_keepalive_domains` (Cài đặt) — KHÔNG
     * hard-code sẵn bất kỳ trang cụ thể nào (Colab, YouTube Music, hay bất
     * cứ gì) — người dùng tự quyết định trang nào cần ngoại lệ.
     */
    /** Mục 173: cho lớp tính năng hỏi "URL này có thuộc danh sách GHIM chạy nền không". */
    fun isKeepAlivePinnedUrl(url: String): Boolean = isBackgroundKeepAliveExemptUrl(url)

    private fun isBackgroundKeepAliveExemptUrl(url: String): Boolean {
        if (AppPrefs.getBoolean(context, slotIndex, "background_paused", false)) return false // Mục 123: đã bấm Dừng trên thông báo
        // Khoá namespaced theo đúng `BackgroundKeepAliveFeature.id` — file
        // đó (tầng features, phụ thuộc CHIỀU XUỐNG core) và file này (tầng
        // core) không tham chiếu code lẫn nhau, chỉ chia sẻ ĐÚNG 1 khoá
        // AppPrefs làm hợp đồng chung — tránh phụ thuộc vòng core↔features.
        val featureId = "background_keepalive_domains"
        val enabled = AppPrefs.getBoolean(context, slotIndex, featureId, "enabled", true)
        if (!enabled) return false
        val domainsRaw = AppPrefs.getString(context, slotIndex, featureId, "domains", "")
        val exceptionDomains = domainsRaw.split(",", "\n")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
        if (exceptionDomains.isEmpty()) return false
        val host = try {
            android.net.Uri.parse(url).host?.lowercase()
        } catch (e: Exception) {
            null
        } ?: return false
        return exceptionDomains.any { d -> host == d || host.endsWith(".$d") }
    }

    private fun applyViewportExceptionForUrl(session: GeckoSession, url: String) {
        val tabId = tabIdFor(session)

        // ĐƠN GIẢN HOÁ (dọn theo hàm dùng chung mới
        // `applyManualDesktopModeIfApplicable()` — xem chú thích đầy đủ ở
        // đó và ở `recoverKilledOrCrashedSession()`, nơi phát hiện ra
        // logic tương tự bị thiếu gây bug thật "tự mất trạng thái
        // desktop"). Logic "áp lại nếu đã đánh dấu thủ công HOẶC domain
        // nằm trong danh sách persist" giờ nằm ở 1 CHỖ DUY NHẤT, tránh 2
        // nơi tự viết lại dễ lệch nhau như đã từng xảy ra.
        if (tabId != null && applyManualDesktopModeIfApplicable(session, tabId, url)) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN ngoại lệ desktop] bỏ qua phần còn lại — tab $tabId đang ở chế độ desktop THỦ CÔNG")
            return
        }
        if (tabId != null && applyManualMobileModeIfApplicable(session, tabId, url)) return // Mục 141

        val domainsRaw = AppPrefs.getString(context, slotIndex, "fp_desktop_skip_viewport_domains", "")
        val exceptionDomains = domainsRaw.split(",", "\n")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
        if (exceptionDomains.isEmpty()) return // chưa cấu hình gì — giữ nguyên hành vi mặc định lúc tạo session

        val host = try {
            android.net.Uri.parse(url).host?.lowercase()
        } catch (e: Exception) {
            null
        } ?: return

        // So khớp domain hoặc subdomain (VD "m.youtube.com" khớp mục
        // "youtube.com") — KHÔNG khớp kiểu "notyoutube.com" chứa chuỗi con.
        val isException = exceptionDomains.any { d -> host == d || host.endsWith(".$d") }

        // LOG CHẨN ĐOÁN — CHỈ 1 DÒNG mỗi lần điều hướng (không spam như các
        // lần trước), để CHẮC CHẮN thấy được domain có khớp không, thay vì
        // đoán qua lại nhiều lượt không có bằng chứng.
        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN ngoại lệ desktop] host=$host, danh sách=$exceptionDomains, khớp=$isException")

        // BUG THẬT tìm ra (người dùng test đúng, báo lại đúng): dòng
        // `if (!FingerprintSpoofFeature.isEnabled(...)) return` TRƯỚC ĐÂY
        // chặn TOÀN BỘ cơ chế này ngay từ đầu nếu tính năng giả mạo vân tay
        // (công tắc TỔNG, MẶC ĐỊNH TẮT — `AppPrefs...("enabled", false)`)
        // chưa được bật riêng — bất kể danh sách tên miền có gì. Đây là lỗi
        // thiết kế: "ép desktop cho tên miền X" và "giả mạo vân tay" là 2
        // việc KHÁC NHAU, không nên gộp chung 1 công tắc. Đã tách ra: ngoại
        // lệ tên miền giờ hoạt động ĐỘC LẬP, không cần bật fingerprint spoof.
        val fpEnabled = FingerprintSpoofFeature.isEnabled(context, slotIndex)
        val hw = if (fpEnabled) resolveProfileForZone(tabId?.let { tabMeta[it]?.zoneId } ?: "").first else null

        try {
            if (isException) {
                // SỬA LỖI THIẾT KẾ NGHIÊM TRỌNG (người dùng chỉ ra đúng):
                // bản trước ép CẢ `viewportMode = DESKTOP` — y hệt nút "Xem
                // bằng máy tính" — cho ra layout desktop khó dùng, SAI HẲN
                // mục đích ban đầu của tính năng này (mục 8zt: "player
                // desktop + layout MOBILE"). Cơ chế THẬT (đã xác nhận ở mục
                // 8zt): chỉ cần UA/thuộc tính JS (navigator.platform,
                // maxTouchPoints...) trông như desktop để trang (VD YouTube)
                // CHỌN PLAYER desktop — viewport/layout hoàn toàn KHÔNG liên
                // quan tới việc chọn player, chỉ quyết định độ rộng CSS hiển
                // thị. Giữ `viewportMode = MOBILE` (layout dễ dùng), CHỈ đổi
                // `userAgentMode = DESKTOP` (UA THẬT trông như desktop, đủ
                // để qua mặt kiểm tra UA/touch của trang).
                session.settings.userAgentOverride = null
                session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_MOBILE
            } else if (fpEnabled && hw != null) {
                // Chỉ khôi phục UA/viewport theo hồ sơ giả nếu fingerprint
                // spoof đang thật sự bật — nếu không, không có gì để khôi
                // phục (giữ nguyên mặc định lúc tạo session).
                session.settings.userAgentOverride = hw.userAgent
                if (hw.category == "desktop") {
                    session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
                    session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                } else {
                    session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_MOBILE
                    session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_MOBILE
                }
            }
            if (fpEnabled) {
                pushFingerprintConfig(session) // đồng bộ lại navigator.platform/maxTouchPoints/WebGL... theo đúng trạng thái vừa đổi
            }
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: applyViewportExceptionForUrl lỗi: ${e.message}")
        }
    }

    private fun createSessionUnopened(isPrivate: Boolean = false, zoneId: String = ""): GeckoSession {
        // CHẾ ĐỘ ẨN DANH — tính năng lớn còn thiếu, ghi rõ trong
        // PROJECT_STATUS.md nhiều lượt liền, giờ mới làm: `usePrivateMode(true)`
        // là API THẬT của GeckoView (đúng cơ chế Private Browsing của
        // Firefox — phiên chạy trong bộ nhớ, không ghi cookie/storage/lịch
        // sử xuống đĩa, tự động cô lập khỏi MỌI context thường kể cả khi
        // vẫn set `contextId` như dưới đây — theo đúng thiết kế Gecko,
        // private mode luôn dùng 1 vùng chứa ephemeral RIÊNG, contextId chỉ
        // có ý nghĩa giữa các phiên KHÔNG private với nhau).
        // BUG THẬT ĐÃ SỬA (người dùng báo: đặt tên hồ sơ cho dữ liệu đang
        // có sẵn trong khe làm MẤT ĐĂNG NHẬP GOOGLE). Trước đây dùng thẳng
        // `ProfileSlots.getSlotAssignment(...)` (tên hồ sơ) làm contextId
        // — tên đổi thì contextId đổi thì container storage đổi. Giờ dùng
        // `getStableContextId()` — 1 UUID lưu ngay trong thư mục hồ sơ vật
        // lý, không đổi dù tên hồ sơ có đổi bao nhiêu lần. Xem chú thích
        // đầy đủ ở `ProfileSlots.getStableContextId()`.
        val builder = GeckoSessionSettings.Builder()
            .usePrivateMode(isPrivate)
            .useTrackingProtection(true)
            .suspendMediaWhenInactive(false)
        // Mục 129: chế độ cookie CHUNG (addon thấy cookie) => KHÔNG đặt contextId (xem CookieModeMigration).
        if (zoneId.isNotBlank()) {
            // Mục 167: VÙNG ẨN DANH — kho dữ liệu RIÊNG của vùng (cookie/localStorage/IndexedDB tách khỏi mọi vùng khác và khỏi khe).
            builder.contextId(IncognitoZones.contextIdFor(zoneId))
        } else if (!CookieModeMigration.isShared(context, slotIndex)) {
            builder.contextId("profile_${ProfileSlots.getStableContextId(context, slotIndex)}")
        }

        // UA header HTTP THẬT — khớp CHÍNH XÁC với navigator.userAgent phía JS
        // (xem buildFingerprintConfigMessage). Trước đây chỉ có JS override,
        // header HTTP thật vẫn để lộ GeckoView/Firefox thật — mismatch dễ bị
        // phát hiện hơn cả không giả UA gì. LUÔN đi cùng hardware spoof —
        // không có tổ hợp hợp lệ nào khi tách UA ra khỏi platform/GPU giả.
        if (FingerprintSpoofFeature.isEnabled(context, slotIndex)) {
            val (hw, _) = resolveProfileForZone(zoneId)
            builder.userAgentOverride(hw.userAgent)

            // Hồ sơ desktop: bật CHẾ ĐỘ DESKTOP THẬT của GeckoView — đúng cơ
            // chế "Request Desktop Site" của trình duyệt mobile thật (viewport
            // CSS 980px, KHÔNG theo <meta viewport> của trang). Đây là thay
            // đổi RENDER THẬT (layout, @media query đều đổi theo), không phải
            // chỉ nói dối 1 property JS như screen.width — thu hẹp đáng kể
            // khoảng cách giữa "khai desktop" và "hiển thị thật vẫn mobile".
            //
            // Giá trị KHỞI TẠO lúc tạo session — mặc định AN TOÀN NHẤT (ép
            // desktop nếu hồ sơ desktop). Việc BỎ ép cho 1 số tên miền cụ
            // thể (VD youtube.com) được xử lý ĐỘNG mỗi lần điều hướng, xem
            // `applyViewportExceptionForUrl()` gọi từ `onLoadRequest` bên
            // dưới — vì `viewportMode`/`userAgentMode` là thuộc tính có thể
            // đổi SAU khi tạo session (bằng chứng: `toggleDesktopMode()` đã
            // làm vậy), không cần cố định 1 lần lúc tạo session cho CẢ tab.
            if (hw.category == "desktop") {
                builder.viewportMode(GeckoSessionSettings.VIEWPORT_MODE_DESKTOP)
                builder.userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_DESKTOP)
            }
        }

        val settings = builder.build()

        val session = GeckoSession(settings)
        // Mục 113: chống chớp bàn phím khi focus chuyển giữa các ô nhập (hide→show) — xem ImeDebounceDelegate.
        try {
            session.textInput.setDelegate(ImeDebounceDelegate(
                session.textInput.getDelegate(),
                shouldDebounce = {
                    // Chỉ Colab + Drive (người dùng yêu cầu giữ nguyên hành vi bàn phím gốc ở trang khác; Drive thêm ở mục 115 vì
                    // đổi tên file trong Drive làm trang nhảy giống Colab).
                    val u = tabIdFor(session)?.let { id -> tabMeta[id]?.url }
                    val host = try { Uri.parse(u ?: "").host?.lowercase() } catch (e: Exception) { null }
                    host == "colab.research.google.com" || host == "drive.google.com"
                },
                holdHideUntilUptime = { imeHoldUntil },
                onLog = { msg -> DebugLog.log("Khe $slotIndex: $msg") }
            ))
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: không đặt được ImeDebounceDelegate: ${e.message}")
        }
        attachEvalBridgeToSession(session)
        attachFingerprintExtensionToSession(session)

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                tabIdFor(session)?.let { tabMeta[it]?.isLoading = true; loadStartCount.merge(it, 1, Int::plus) } // Mục 161: để reload() biết lệnh có làm trang tải thật không
                if (tabIdFor(session) == activeTabId) {
                    onProgressChangedListener?.invoke(0)
                    onPageStartedListener?.invoke(url)
                }
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                val tabId = tabIdFor(session)
                tabId?.let { tabMeta[it]?.isLoading = false }
                if (tabId == activeTabId) onProgressChangedListener?.invoke(100)
                if (success && tabId != null) {
                    val url = tabMeta[tabId]?.url ?: return
                    if (tabId == activeTabId) {
                        onPageLoadedListener?.invoke(tabId, url)
                        startAutoBehavior()
                        // FIX race condition: thay vì gọi applyDesktopLayoutZoomIfNeeded()
                        // + reapplyManualZoom() riêng (2 script async có thể đè nhau),
                        // giờ chỉ gọi reapplyManualZoom() — hàm này đã gộp cả 2 logic
                        // vào 1 script JS duy nhất qua applyZoomCombined(). Xem PDF.
                        reapplyManualZoom(tabId, url)
                        // CHẨN ĐOÁN player YouTube quay spin mãi không phát
                        // (người dùng báo Khe 1) — không đoán thêm nữa, hỏi
                        // THẲNG trình duyệt thật đang thấy gì ở thẻ <video>:
                        // readyState (0=chưa có data, 4=đủ data để phát),
                        // networkState, error.code (nếu có — mã lỗi decode/
                        // network THẬT của trình duyệt), paused, buffered.
                        // Chỉ bật khi URL là trang xem video thật (có
                        // "watch" hoặc "/shorts/") để không tốn tài nguyên ở
                        // trang khác. Poll nhiều lần vì lúc onPageStop bắn,
                        // video có thể vẫn đang khởi tạo — cần thấy DIỄN
                        // BIẾN theo thời gian, không chỉ 1 lát cắt.
                        if (url.contains("youtube.com") && (url.contains("watch") || url.contains("/shorts/"))) {
                            pollVideoDiagnostic(tabId, url, attempt = 0)
                        }
                    }
                }
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                if (tabIdFor(session) == activeTabId) onProgressChangedListener?.invoke(progress)
            }

            override fun onSecurityChange(session: GeckoSession, securityInfo: GeckoSession.ProgressDelegate.SecurityInformation) {}

            /**
             * KHÔI PHỤC TAB ĐẦY ĐỦ — đã TRA ĐƯỢC API chính xác (trước đây
             * chỉ khôi phục URL/tiêu đề, KHÔNG có lịch sử back/forward/vị
             * trí cuộn/dữ liệu form, vì "chưa có mạng tra API bất đồng bộ
             * phức tạp hơn"). Xác nhận từ tài liệu GeckoView chính thức:
             * `onSessionStateChange()` tự động fire mỗi khi trạng thái
             * phiên đổi (điều hướng, cuộn, nhập form...), cho
             * `GeckoSession.SessionState` — chuỗi hoá qua `.toString()`,
             * khôi phục lại qua `SessionState.fromString()` +
             * `session.restoreState()`. Chỉ cập nhật biến TRONG BỘ NHỚ ở
             * đây (rẻ, fire rất thường xuyên) — việc GHI XUỐNG ĐĨA vẫn theo
             * đúng các mốc cũ (mở/đóng tab, mất foreground) qua
             * `saveTabsState()`, không ghi đĩa mỗi lần hàm này chạy (sẽ quá
             * nhiều I/O).
             */
            override fun onSessionStateChange(session: GeckoSession, sessionState: GeckoSession.SessionState) {
                tabIdFor(session)?.let { tabId -> tabMeta[tabId]?.savedState = sessionState.toString() }
            }
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny> {
                DebugLog.log("onLoadRequest: ${request.uri}")
                // Bản 7.70: FAIL-CLOSED + dò vùng (xem releaseHeldNavigations). Chỉ áp cho điều hướng http(s).
                if (request.uri.startsWith("http://") || request.uri.startsWith("https://")) {
                    val tidG = tabIdFor(session)
                    val tabG = tidG?.let { tabMeta[it] }
                    val privG = tabG?.isPrivate == true
                    val zoneG = tabG?.zoneId ?: ""
                    if ((GeckoRuntimeProvider.navigationNeedsProxy(context, slotIndex, privG, zoneG) && !GeckoRuntimeProvider.isProxyReady(slotIndex)) || mappingPending(session)) {
                        if (tidG != null) heldNavigations[tidG] = request.uri
                        DebugLog.log("Khe $slotIndex: [proxy FAIL-CLOSED] GIỮ điều hướng (tab=$tidG) — addon proxy chưa sẵn sàng; sẽ nạp lại khi sẵn sàng (không tải bằng IP thật)")
                        return GeckoResult.deny()
                    }
                    if (probeNavLogged < 80 && GeckoRuntimeProvider.probeEnabled(context, slotIndex)) {
                        probeNavLogged++
                        val zid = tabG?.zoneId ?: ""
                        val persistentZone = zid.isNotBlank() && IncognitoZones.get(context, slotIndex, zid)?.persistent == true
                        val h = try { Uri.parse(request.uri).host ?: "" } catch (e: Exception) { "" }
                        DebugLog.log("Khe $slotIndex: [dò vùng] tab=$tidG ẩn danh=$privG vùng=${if (zid.isBlank()) "-" else zid}${if (persistentZone) "(bền)" else ""} host=${GeckoRuntimeProvider.maskHostForProbe(h, privG)}")
                    }
                }
                if (request.uri.contains("/logout") || request.uri.contains("reauth=1")) logLogoutSnapshot(session, request.uri)
                // TÍNH NĂNG MỚI (mục 91 — dấu "+" ở trang "Tab mới" để tự
                // ghim shortcut): trang đó không có content script/
                // eval_bridge (xem chú thích ở NewTabPage.kt), nên báo lại
                // cho app qua 1 điều hướng giả `colablive://...` — chặn
                // NGAY tại đây (đúng chỗ app đã chặn điều hướng cho nhiều
                // việc khác), lưu xong thì tải lại trang Tab mới với dữ
                // liệu MỚI thay vì để Gecko thật sự điều hướng đi đâu đó
                // (scheme này không tồn tại, chặn lại tránh lỗi tải trang).
                // Mục 162: nút "Tải lại tin" — nhờ addon nền tải RSS, sau ~5 giây dựng lại trang Tab mới (nếu tab vẫn đang ở Tab mới).
                if (request.uri.startsWith("colablive://refresh-news")) {
                    val tid = tabIdFor(session)
                    requestNewsRefresh {
                        if (tid != null && NewTabPage.isNewTabUrl(tabMeta[tid]?.url ?: "")) {
                            val refreshed = NewTabPage.homeUrl(context, slotIndex)
                            tabMeta[tid]?.url = refreshed
                            tabs[tid]?.loadUri(refreshed)
                        }
                    }
                    return GeckoResult.deny()
                }
                if (NewTabPage.tryHandleAddShortcut(context, slotIndex, request.uri) ||
                    NewTabPage.tryHandleNtpPref(context, slotIndex, request.uri) ||
                    NewTabPage.tryHandleSetPlace(context, slotIndex, request.uri) ||
                    NewTabPage.tryHandleRemoveShortcut(context, slotIndex, request.uri) ||
                    NewTabPage.tryHandleHideAutoShortcut(context, slotIndex, request.uri) ||
                    NewTabPage.tryHandleEditShortcut(context, slotIndex, request.uri)) {
                    tabIdFor(session)?.let { tabId ->
                        val refreshed = NewTabPage.homeUrl(context, slotIndex)
                        tabMeta[tabId]?.url = refreshed
                        session.loadUri(refreshed)
                    }
                    return GeckoResult.deny()
                }
                // FIX BUG THẬT (người dùng báo: trang đang tải bị gián đoạn
                // — chuyển app khác/làm việc khác giữa chừng — thì thành
                // about:blank; đã tự tìm ra lỗ hổng cụ thể thay vì chỉ ghi
                // nghi vấn chờ log): TRƯỚC ĐÂY `tab.url` chỉ được cập nhật ở
                // 2 nơi — `loadUrl()` (gõ thanh địa chỉ, cập nhật NGAY) và
                // `onLocationChange` (Gecko tự báo, CÓ ĐỘ TRỄ tới khi Gecko
                // xác nhận điều hướng THẬT SỰ xảy ra). Nếu người dùng bấm 1
                // LIÊN KẾT TRONG TRANG (không qua `loadUrl()` của app) rồi
                // hệ thống kill session GIỮA lúc bấm và lúc `onLocationChange`
                // kịp bắn (cửa sổ hở có thật, không phải suy đoán suông —
                // đúng theo vòng đời GeckoView tài liệu: `onLoadRequest` bắn
                // NGAY khi điều hướng được YÊU CẦU, `onLocationChange` chỉ
                // bắn SAU khi Gecko xác nhận điều hướng đã diễn ra, có độ
                // trễ thật) — `recoverKilledOrCrashedSession()` sẽ phục hồi
                // bằng `tab.url` CŨ (giá trị trước lần điều hướng này), gây
                // đúng cảm giác "trang đang tải mất tích, về trang trống/cũ".
                // SỬA: cập nhật `tab.url` NGAY tại đây — sớm hơn hẳn so với
                // đợi `onLocationChange` — đóng lỗ hổng thời gian đó lại
                // hoàn toàn cho MỌI đường điều hướng (kể cả bấm link trong
                // trang), không chỉ riêng đường gõ thanh địa chỉ.
                // Mục 110 (bug about:blank): CHỈ ghi nhận URL có thể nạp lại sau khi khởi động lại. `blob:` (tải file/xem tệp tạo bằng JS,
                // vd nút Download của claude.ai) chỉ sống trong tiến trình đã tạo ra nó; `about:blank`/`data:`/`javascript:` không phải
                // trang thật. Trước đây mọi onLoadRequest đều ghi đè `tab.url`, nên một lượt tải blob làm tab "kẹt" ở URL blob và
                // lần mở app sau nạp lại blob => trang trắng about:blank (đúng log người dùng gửi).
                if (isRestorableNavigation(request.uri)) {
                    tabIdFor(session)?.let { tabMeta[it]?.url = request.uri }
                }
                applyViewportExceptionForUrl(session, request.uri)
                return GeckoResult.allow()
            }

            override fun onLoadError(
                session: GeckoSession,
                uri: String?,
                error: WebRequestError
            ): GeckoResult<String>? {
                DebugLog.log("onLoadError: $uri — code=${error.code}")
                onPageErrorListener?.invoke(uri ?: "", error.code)
                return GeckoResult.fromValue(null)
            }

            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                // GeckoSession không có property currentUri đọc đồng bộ — đây là
                // NGUỒN DUY NHẤT để biết URL hiện tại của 1 session, phải tự cache.
                if (url != null) {
                    tabIdFor(session)?.let { tabId ->
                        if (tabId == activeTabId) applyZoomToInputPolicy(url)
                        val previousUrl = tabMeta[tabId]?.url
                        // BUG THẬT (lịch sử phiên trước KỂ LẠI là đã sửa — "Tìm ra
                        // đúng lý do phải tự bấm nút mới có tác dụng... 7 tab khôi
                        // phục không hề đi qua onLoadRequest" — nhưng việc sửa đó
                        // KHÔNG hề có trong code thật, chỉ có trong lời kể, y hệt
                        // pattern của `manualDesktopTabIds`/`fp_lock` ở trên): tab
                        // khôi phục từ phiên trước (`restoreState()`) bắn
                        // `onLocationChange` chứ KHÔNG bắn `onLoadRequest` —
                        // `applyViewportExceptionForUrl()` trước đây CHỈ được gọi
                        // từ `onLoadRequest`, nên ngoại lệ tên miền (player desktop +
                        // layout mobile) không bao giờ được áp dụng cho 7 tab khôi
                        // phục cho tới khi người dùng tự ép tải lại. Gọi thêm ở đây,
                        // đúng như lời kể mô tả nhưng chưa từng có trong code.
                        val wasPendingRestore = pendingRestoreTabIds.contains(tabId)
                        pendingRestoreTabIds.remove(tabId) // có sự kiện điều hướng thật — restoreState() đã "làm gì đó"
                        // Mục 110: khôi phục xong lại ra about:blank (lịch sử lưu trỏ vào trang không còn, vd blob:) trong khi tab có
                        // URL thật đã lưu => nạp URL thật thay vì để trang trắng.
                        if (wasPendingRestore && url == "about:blank" && !previousUrl.isNullOrBlank() && previousUrl != "about:blank") {
                            val fallback = loadableUrlForRestore(previousUrl)
                            DebugLog.log("Khe $slotIndex: khôi phục tab $tabId ra about:blank — nạp lại URL đã lưu: $fallback")
                            tabMeta[tabId]?.url = fallback
                            session.loadUri(fallback)
                            return@let
                        }
                        tabMeta[tabId]?.url = url
                        if (wasPendingRestore) {
                            applyViewportExceptionForUrl(session, url)
                            session.reload() // áp settings mới có hiệu lực ngay cho trang vừa khôi phục, không cần đợi điều hướng kế tiếp
                        } else if (tabId == activeTabId && url != previousUrl) {
                            // BUG THẬT (người dùng báo: favicon vẫn xanh lè dù đã
                            // reload/mở tab mới; đồng thời chẩn đoán video YouTube
                            // KHÔNG BAO GIỜ chạy dù đã mở video thật — 2 triệu chứng
                            // tưởng KHÁC NHAU nhưng CÙNG 1 GỐC): YouTube là SPA —
                            // chuyển từ trang chủ/tìm kiếm sang 1 video cụ thể, hay
                            // chuyển bài trong playlist, KHÔNG tải trang mới (không
                            // bắn `onLoadRequest`/`onPageStop`) — chỉ đổi URL qua
                            // History API, chỉ bắn ĐÚNG sự kiện này. Trước đây
                            // `onPageLoadedListener` (nơi gọi `fetchFaviconForActiveTab`
                            // + chẩn đoán video ở `onPageStop`) chỉ được gọi từ
                            // `onPageStop` — nghĩa là mọi lần điều hướng KIỂU SPA
                            // (rất phổ biến ở YouTube/Colab/Drive) đều bị bỏ sót
                            // hoàn toàn, không chỉ favicon mà CẢ chẩn đoán video.
                            // Gọi lại đúng listener đó ở đây khi URL tab đang active
                            // thật sự đổi (so sánh với giá trị TRƯỚC đó, không phải
                            // đổi vì thêm tham số vô hại — vẫn chấp nhận gọi hơi dư
                            // còn hơn bỏ sót, vô hại vì các hàm downstream tự chống
                            // trùng lặp/có giới hạn thử lại riêng).
                            onPageLoadedListener?.invoke(tabId, url)
                            if (url.contains("youtube.com") && (url.contains("watch") || url.contains("/shorts/"))) {
                                pollVideoDiagnostic(tabId, url, attempt = 0)
                            }
                        }
                    }
                }
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tabIdFor(session)?.let { tabMeta[it]?.canGoBack = canGoBack }
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tabIdFor(session)?.let { tabMeta[it]?.canGoForward = canGoForward }
            }

            override fun onNewSession(
                session: GeckoSession,
                uri: String
            ): GeckoResult<GeckoSession> {
                DebugLog.log("onNewSession (popup): $uri")
                /**
                 * BUG THẬT đã sửa — nguyên nhân CHÍNH XÁC của lỗi
                 * "MessageError: Error: credential propagation was
                 * unsuccessful" khi chạy `drive.mount()` trong Colab: hàm
                 * này TRƯỚC ĐÂY trả về `null` — theo đúng tài liệu
                 * GeckoView, `onNewSession` trả `null` nghĩa là TỪ CHỐI
                 * popup hẳn, JS gọi `window.open()` nhận về KHÔNG có cửa sổ
                 * thật nào cả. Popup xác thực Google Colab mở ra để đăng
                 * nhập cần gửi thông tin đăng nhập NGƯỢC LẠI tab chính qua
                 * `window.opener`/`postMessage` — không có cửa sổ thật thì
                 * không có `window.opener`, việc "propagate credential" chắc
                 * chắn thất bại, đúng y hệt lỗi gặp phải.
                 *
                 * Sửa: tạo 1 `GeckoSession` THẬT cho popup, thêm vào danh
                 * sách tab của chính khe này (người dùng thấy/tương tác
                 * được, vd trang đăng nhập Google) — TRẢ VỀ session đó thay
                 * vì `null`, để `window.open()` phía JS nhận cửa sổ thật,
                 * `window.opener` hoạt động đúng — giống hệt cách
                 * Chrome/Firefox xử lý popup.
                 */
                val popupTabId = UUID.randomUUID().toString()
                // FIX BUG THẬT (người dùng báo): ghi lại đúng tab ĐANG MỞ
                // (activeTabId lúc này chính là tab gốc gọi window.open())
                // để dùng khi đóng popup sau này — xem closeTab().
                val openerTabIdSnapshot = activeTabId
                // BUG THẬT đã sửa (crash log xác nhận): "Must use an
                // unopened GeckoSession instance" — GeckoView tự MỞ session
                // trả về từ onNewSession, không được mở sẵn trước khi trả
                // về (khác hẳn tab thường, nơi TA tự mở). Dùng
                // createSessionUnopened() (không gọi session.open()), KHÔNG
                // dùng createSession() (có gọi open(), gây crash đúng như
                // log).
                // Mục 117: popup mở từ tab ẨN DANH phải cũng ẩn danh (trước đây session popup luôn là thường -> lọt dữ liệu khỏi chế độ ẩn danh)
                // và nằm trong nhóm Ẩn danh.
                val openerIsPrivate = openerTabIdSnapshot?.let { tabMeta[it]?.isPrivate } == true
                val openerZone = openerTabIdSnapshot?.let { tabMeta[it]?.zoneId } ?: "" // Mục 167/7.63: popup (vd cửa sổ đăng nhập OAuth) PHẢI ở cùng vùng (cả vùng bền: tab thường mang zoneId)
                val popupSession = createSessionUnopened(openerIsPrivate, openerZone)
                val popupTab = BrowserTab(id = popupTabId, url = uri, isPrivate = openerIsPrivate, openerTabId = openerTabIdSnapshot, zoneId = openerZone)
                tabs[popupTabId] = popupSession
                tabMeta[popupTabId] = popupTab
                if (openerIsPrivate) {
                    placePrivateTab(popupTab)
                } else {
                    if (openerTabIdSnapshot != null) inheritGroupFromOpener(popupTab, openerTabIdSnapshot)
                    insertTabOrder(popupTabId, openerTabIdSnapshot, sameOpenerRun = true)
                    normalizePrivateOrder()
                    adoptIntoZoneGroup(popupTab) // 7.66: popup của tab vùng bền ở trong nhóm vùng
                }
                handler.post {
                    switchToTab(popupTabId)
                    onNewTabRequestedListener?.invoke(uri)
                }
                return GeckoResult.fromValue(popupSession)
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                title?.let {
                    val tabId = tabIdFor(session)
                    tabId?.let { id -> tabMeta[id]?.title = it }
                    if (tabId == activeTabId) onTitleChangedListener?.invoke(it)
                    refreshMediaTitleIfPlayingTab(tabId)
                }
            }

            /**
             * FIX BUG THẬT (xác nhận qua đọc code — hàm này CHƯA TỪNG được
             * override, đối chiếu javadoc chính thức Mozilla:
             * "A page has entered or exited full screen mode. Typically,
             * the implementation would set the Activity containing the
             * GeckoSession to full screen when the page is in full screen
             * mode." — tức đây là nơi BẮT BUỘC phải tự ẩn UI trình duyệt
             * (thanh URL, dải tab), không phải GeckoView tự làm giúp).
             * Người dùng báo: nhấn nút toàn màn hình trên player thì hình
             * bị "vướng url" — đúng như dự đoán, vì trước đây app không hề
             * biết trang đã vào fullscreen để ẩn UI của chính mình đi.
             *
             * Chỉ xử lý cho tab ĐANG ACTIVE — tab nền vào/ra fullscreen (dù
             * hiếm khi xảy ra) không nên ảnh hưởng UI tab đang xem.
             */
            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                val tabId = tabIdFor(session) ?: return
                if (tabId != activeTabId) return
                // FIX PHỐI HỢP: cơ chế zoom (applyZoomCombined(), giờ dùng
                // meta[name=viewport] — xem mục 59 PROJECT_STATUS.md) KHÔNG
                // được trình duyệt tự động vô hiệu hoá khi 1 phần tử vào
                // Fullscreen API — 2 cơ chế này chạy độc lập, chồng lên
                // nhau. Zoom < 1.0 (thu nhỏ layout desktop) làm player
                // fullscreen bị co lại sai kích thước thay vì phủ kín màn
                // hình thật ("vướng url" người dùng mô tả — thực ra là toàn
                // bộ trang, kể cả URL bar co theo scale cũ, không phải video
                // kẹt ở URL). Sửa: tắt hẳn zoom khi vào fullscreen (xoá thẻ
                // meta viewport do app tạo, giống nhánh finalScale=1.0 của
                // applyZoomCombined), tự tính lại đúng zoom khi thoát (gọi
                // lại applyZoomCombined gián tiếp qua onFullScreenListener
                // bên MainActivity).
                val script = if (fullScreen) {
                    """
                    (function() {
                        var meta = document.querySelector('meta[name="viewport"][data-colablive-zoom="1"]');
                        if (meta) { meta.parentNode.removeChild(meta); }
                    })();
                    """.trimIndent()
                } else {
                    null // khôi phục zoom xử lý ở MainActivity qua onFullScreenListener → reapplyManualZoom lại
                }
                script?.let { evaluateJsForTab(tabId, it, null) }
                onFullScreenListener?.invoke(fullScreen)
            }

            override fun onContextMenu(
                session: GeckoSession,
                screenX: Int,
                screenY: Int,
                element: GeckoSession.ContentDelegate.ContextElement
            ) {
                // BỔ SUNG CHẨN ĐOÁN (mục 66 PROJECT_STATUS.md — long-press
                // vào cell Colab KHÔNG PHẢN ỨNG GÌ trên GeckoView, trong khi
                // Chrome cùng vị trí vẫn hiện được menu). Trước đây hàm này
                // CHỈ log khi có `linkUri` — với text thường trong Colab,
                // `linkUri` luôn null nên KHÔNG CÓ DÒNG LOG NÀO xuất hiện dù
                // `onContextMenu` có được gọi hay không, khiến không thể
                // phân biệt 2 khả năng hoàn toàn khác nhau: (a) long-press
                // không tới được Gecko ở tầng thấp hơn cả `onContextMenu`
                // (touch bị chặn/lệch toạ độ trước khi Gecko kịp xử lý), hay
                // (b) `onContextMenu` CÓ được gọi đúng (long-press tới được
                // Gecko) nhưng `onShowActionRequest`/selection lại không bao
                // giờ theo sau — tức 2 pipeline độc lập, vấn đề nằm ở khâu
                // sau, không phải touch bị chặn từ đầu.
                //
                // Log VÔ ĐIỀU KIỆN (bỏ if linkUri) để lần tới người dùng chỉ
                // cần long-press 1 lần vào đúng cell Colab và gửi log, không
                // cần tự thử tắt/bật desktop mode hay làm gì thêm — đối
                // chiếu trực tiếp dòng log này với có/không có dòng
                // "[CHẨN ĐOÁN selection] onShowActionRequest" theo sau trong
                // vòng ~1 giây sẽ trả lời dứt điểm (a) hay (b) ở trên.
                DebugLog.log(
                    "Khe $slotIndex: [CHẨN ĐOÁN context-menu] onContextMenu " +
                    "screenX=$screenX screenY=$screenY " +
                    "linkUri=${element.linkUri ?: "(không có)"} " +
                    "type=${element.type} " +
                    "srcUri=${element.srcUri ?: "(không có)"} — " +
                    "nếu KHÔNG có dòng '[CHẨN ĐOÁN selection] onShowActionRequest' " +
                    "xuất hiện ngay sau dòng này, xác nhận 2 pipeline tách rời " +
                    "(onContextMenu tới được nhưng selection không theo sau); " +
                    "nếu KHÔNG THẤY dòng NÀY xuất hiện dù đã long-press, xác nhận " +
                    "long-press không tới được Gecko ở tầng thấp hơn (khớp giả " +
                    "thuyết hit-test lệch do zoom/desktop-viewport, mục 66)"
                )
                val linkUri = element.linkUri
                if (!linkUri.isNullOrBlank()) {
                    handler.post { onLongPressLinkListener?.invoke(linkUri, element.title) }
                }
            }

            // Chữ ký thật: (session, response: WebResponse) — response.uri là
            // property của WebMessage (lớp cha của WebResponse), KHÔNG có class
            // lồng "GeckoSession.WebResponseInfo" (không tồn tại, code cũ đoán sai).
            //
            // BUG THẬT (xác nhận qua ảnh chụp màn hình người dùng gửi — dialog
            // "Tải File" cho link Google Drive `.../download?id=...&export=
            // download&...` ra tên file y hệt `download?id=1ZbY4NJ2I-jHri6xr...`):
            // code cũ dùng `uri.substringAfterLast("/")` — KHÔNG cắt bỏ phần
            // `?query` trước khi lấy đoạn cuối URL, nên với URL dạng
            // `.../download?id=...` (không có dấu "/" nào sau "download") thì
            // TOÀN BỘ query string (`download?id=...&export=...&uuid=...`) bị
            // lấy làm tên file. Đồng thời bỏ qua hẳn header `Content-Disposition`
            // mà server tải file (Google Drive, v.v.) chắc chắn có gửi kèm tên
            // file THẬT. Sửa đúng gốc: dùng `URLUtil.guessFileName(uri,
            // contentDisposition, mimeType)` — hàm chuẩn của Android, tự ưu
            // tiên đọc `Content-Disposition` trước, chỉ mới cắt query string
            // khỏi URL khi fallback (không phải bỏ qua như code cũ).
            // TÍNH NĂNG MỚI (người dùng hỏi: "cài extension từ URL có làm
            // giống Firefox/Chrome — vào trang store rồi tải về dùng được
            // không?"). Trước đây chỉ có đường "dán URL .xpi trực tiếp"
            // (`installAddonFromUrl` ở MainActivity) — không bắt được lúc
            // người dùng duyệt bình thường tới addons.mozilla.org rồi bấm
            // "Thêm vào Firefox" (nút đó chỉ là 1 link trỏ thẳng file .xpi,
            // Content-Type "application/x-xpinstall" — Firefox thật chặn
            // NGAY bằng Content-Type/đuôi file tại đây, không tải xuống như
            // file thường). Vì đây LÀ addon từ addons.mozilla.org (đã được
            // Mozilla ký) nên đúng loại DUY NHẤT Gecko Release chấp nhận
            // cài — xem giải thích đầy đủ ở
            // `MainActivity.showAddonManagerDialog()`. Bắt SỚM ở đây, trước
            // khi rơi vào toàn bộ máy tải-file-thông-thường bên dưới.
            override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
                val uri = response.uri
                val headers = response.headers
                val contentType0 = headers?.entries?.firstOrNull {
                    it.key.equals("content-type", ignoreCase = true)
                }?.value
                val isXpi = contentType0?.contains("x-xpinstall", ignoreCase = true) == true ||
                    uri.substringBefore("?").endsWith(".xpi", ignoreCase = true)
                if (isXpi) {
                    handleExtensionDownloadResponse(uri, response.body)
                    return
                }
                val contentDisposition = headers?.entries?.firstOrNull {
                    it.key.equals("content-disposition", ignoreCase = true)
                }?.value
                val contentType = headers?.entries?.firstOrNull {
                    it.key.equals("content-type", ignoreCase = true)
                }?.value
                val fileName = extractFileNameFromResponse(uri, contentDisposition, contentType)

                // Xem chú thích lớn ở khai báo `onDownloadBodyReadyListener`
                // phía trên — nếu response.body có sẵn (thường có, per
                // javadoc "if available"), drain NGAY LẬP TỨC vào file tạm
                // trên nền, KHÔNG chờ người dùng tương tác dialog "ASK" nào
                // (tránh timeout đọc mặc định 30s của chính stream này) —
                // xong thì báo listener kèm đường dẫn file tạm đã có đủ
                // byte thật. Nếu body null (hiếm, hoặc trường hợp không đi
                // qua onExternalResponse), fallback về listener cũ (tải lại
                // qua OkHttp — vẫn đúng cho file CÔNG KHAI như trước giờ).
                val body = response.body
                if (body != null) {
                    // Timeout 30s mặc định của GeckoView áp dụng cho TỪNG lệnh read() đang CHỜ dữ liệu (WebResponse.setReadTimeoutMillis),
                    // KHÔNG phải cho luồng chưa đọc; nới ra 2 phút cho server chậm.
                    try { response.setReadTimeoutMillis(120_000L) } catch (e: Exception) { /* bản GeckoView không có: bỏ qua */ }
                }
                val askListener = onDownloadAskListener
                if (body != null && askListener != null && onDownloadBodyReadyListener != null) {
                    // MỤC 107 — HỎI TRƯỚC KHI TẢI: chưa đọc byte nào của body. Luồng được giữ nguyên trong lúc người dùng chọn nơi lưu;
                    // đồng ý thì mới bắt đầu đọc, huỷ thì ĐÓNG luồng (tài liệu GeckoView: phải đóng kể cả khi bỏ qua body, nếu không
                    // kết nối treo tới khi bị dọn rác). Code cũ đọc NGAY rồi hỏi song song nên file đã tải xong/đang tải khi hộp thoại hiện.
                    val askedAt = android.os.SystemClock.elapsedRealtime()
                    DebugLog.log("Khe $slotIndex: [tải xuống] HỎI TRƯỚC — chưa đọc byte nào của '$fileName', chờ người dùng chọn nơi lưu")
                    val item = AskedDownload(
                        uri, fileName,
                        start = { onFailure ->
                            DebugLog.log("Khe $slotIndex: [tải xuống] người dùng đồng ý sau ${android.os.SystemClock.elapsedRealtime() - askedAt}ms — BẮT ĐẦU đọc body")
                            drainBodyToTemp(uri, fileName, headers, body, onFailure)
                        },
                        cancel = {
                            try { body.close() } catch (e: Exception) { /* đã đóng */ }
                            DebugLog.log("Khe $slotIndex: [tải xuống] người dùng HUỶ sau ${android.os.SystemClock.elapsedRealtime() - askedAt}ms — đã đóng luồng, không tải byte nào")
                        }
                    )
                    handler.post { askListener(item) }
                    return
                }
                if (body != null && onDownloadBodyReadyListener != null) {
                    // Bắn NGAY (trước khi Thread drain bắt đầu) — xem chú
                    // thích ở khai báo `onDownloadStartedListener`. Post lên
                    // main thread vì đang chạy trong callback GeckoView.
                    handler.post {
                        onDownloadStartedListener?.invoke(uri, fileName)
                    }
                    drainBodyToTemp(uri, fileName, headers, body, null)
                } else {
                    onDownloadRequestedListener?.invoke(uri, fileName)
                }
            }

            override fun onCrash(session: GeckoSession) {
                DebugLog.log("Session crashed!")
                recoverKilledOrCrashedSession(session, wasCrash = true)
            }

            override fun onKill(session: GeckoSession) {
                DebugLog.log("Session killed by system")
                recoverKilledOrCrashedSession(session, wasCrash = false)
            }

            /**
             * CÔNG CỤ CHẨN ĐOÁN MỚI (người dùng báo bug thật: dán 1 lượng
             * text lớn vào cell Colab làm trang đơ hoàn toàn, phải reload
             * mới hết — Chrome cùng thao tác vẫn bình thường). Đã tra cứu
             * mọi hướng có bằng chứng code (hàng đợi `evalCallbacks` đã có
             * timeout 15s tự dọn từ trước — không phải nguyên nhân; không
             * có pref nào ép tắt GPU/layer acceleration ảnh hưởng hiệu năng
             * chung — không tìm thấy). KHÔNG tìm được bằng chứng CODE APP
             * nào gây ra — nghi vấn cao nhất còn lại là JS thread CỦA
             * CHÍNH TRANG (CodeMirror re-tokenize/highlight khối lượng lớn
             * text vừa dán) bị chặn bên trong Gecko, đây là hành vi CỦA
             * ENGINE, không phải app.
             *
             * `onSlowScript()` là delegate CÓ SẴN của GeckoView, TRƯỚC ĐÂY
             * CHƯA từng implement — đây chính là cách CHÍNH THỨC GeckoView
             * dùng để báo "trang có script chạy quá lâu không nhường CPU"
             * (tương đương "trang không phản hồi" của Chrome). Thêm vào
             * đây để lần tới bug này xảy ra, log sẽ cho biết CHẮC CHẮN: có
             * dòng "[CHẨN ĐOÁN slow script]" xuất hiện đúng lúc đơ hay
             * không — CÓ nghĩa là xác nhận 100% đây là giới hạn tầng Gecko
             * (không phải bug code app, không có cách sửa từ phía Kotlin);
             * KHÔNG CÓ nghĩa là loại trừ khả năng đó, cần điều tra hướng
             * khác (IPC/eval_bridge deadlock, hoặc thứ gì đó khác hẳn).
             * Trả về CONTINUE (không tự ý dừng script của người dùng) —
             * chỉ để CHẨN ĐOÁN, chưa vội "sửa" bằng cách ngắt trang khi
             * chưa chắc đó có phải nguyên nhân hay không.
             *
             * MỤC 70.4 — GIỜ CÓ ĐỦ BẰNG CHỨNG (mục 61.2 PROJECT_STATUS.md:
             * Bugzilla #607921, xác nhận công khai từ nhiều năm — dán text
             * lớn vào textarea/contentEditable khiến CHÍNH ENGINE Gecko
             * treo "vài phút" trên cả bản Desktop, không phải bug riêng
             * app này, KHÔNG có cách sửa ở tầng app/JS vì script chặn ở
             * đúng bên trong JS engine của Gecko). Vì KHÔNG sửa được
             * nguyên nhân, chuyển hướng sang GIẢM NHẸ hậu quả: trước đây
             * luôn trả CONTINUE nên người dùng phải tự thoát app/reload
             * tay khi "đơ vĩnh viễn" — giờ nếu Gecko còn báo script chậm
             * LẦN THỨ 2 trở lên cho CÙNG 1 session trong vòng 20 giây (tức
             * script vẫn treo sau khi đã cho cơ hội đầu), tự trả về STOP
             * để Gecko chủ động ngắt đúng script đang treo đó — tương
             * đương nút "Ngừng script" mà Chrome tự hiện dialog hỏi người
             * dùng, ở đây app tự quyết THAY vì vẽ dialog (nhất quán với
             * các quyền khác trong app đã tự động cấp/từ chối sẵn).
             * ĐÁNH ĐỔI THÀNH THẬT: STOP có thể khiến phần text vừa dán bị
             * chèn DỞ DANG vào cell (Colab tự lưu draft liên tục nên nhiều
             * khả năng không mất hẳn, nhưng CHƯA kiểm chứng trên máy thật)
             * — đổi lại, trang không còn "đơ vĩnh viễn phải reload" như
             * trước, chỉ mất đúng lượt dán đó. Không áp dụng STOP ngay từ
             * lần báo ĐẦU TIÊN — script chạy lâu vài giây là bình thường
             * (video/trang nặng), chỉ can thiệp khi đã kéo dài bất thường.
             */
            override fun onSlowScript(
                session: GeckoSession,
                scriptFileName: String
            ): GeckoResult<SlowScriptResponse>? {
                val now = android.os.SystemClock.uptimeMillis()
                val tabId = tabIdFor(session)
                val lastReport = tabId?.let { slowScriptLastReportUptime[it] }
                val isRepeatedWithin20s = lastReport != null && (now - lastReport) < 20_000L
                if (tabId != null) slowScriptLastReportUptime[tabId] = now

                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN slow script] Gecko báo script CHẠY QUÁ LÂU không nhường CPU — scriptFileName=$scriptFileName, lặp lại trong 20s=$isRepeatedWithin20s (nếu dòng này xuất hiện đúng lúc trang đơ sau khi dán text lớn, XÁC NHẬN chắc chắn đây là giới hạn tầng Gecko/JS engine, không phải bug code app — xem PROJECT_STATUS.md mục 61.2/70.4)")

                return if (isRepeatedWithin20s) {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN slow script] ĐÃ báo chậm lần 2 trong 20s — tự NGẮT script treo (STOP) để tránh đơ vĩnh viễn, thay vì bắt người dùng tự reload tay")
                    tabId?.let { slowScriptLastReportUptime.remove(it) }
                    GeckoResult.fromValue(SlowScriptResponse.STOP)
                } else {
                    GeckoResult.fromValue(SlowScriptResponse.CONTINUE)
                }
            }
        }

        // BUG THẬT (nguyên nhân YT Khe 1 spinner mãi không play): GeckoView
        // KHÔNG tự grant content permission nếu không có `permissionDelegate`
        // — mặc định từ chối HẾT, bao gồm cả AUTOPLAY permission. Khe 1 dùng
        // UA desktop + viewport desktop → YouTube trả trang desktop → player
        // desktop trigger autoplay policy NGHIÊM HƠN của Gecko so với bản
        // mobile (bản mobile có nhiều fallback, bản desktop player đúng nghĩa
        // phụ thuộc autoplay grant). Khe 0 (bản mobile) thoát được vì Gecko
        // có ngoại lệ cho user-initiated navigation với bản mobile YouTube.
        //
        // Sửa: set permissionDelegate tự grant AUTOPLAY và các content
        // permission vô hại khác (geolocation/camera/mic vẫn từ chối — đây
        // là app browser thật, không phải kiosk, không nên auto-grant cảm
        // biến nhạy cảm). API: `onContentPermissionRequest` trả về
        // `GeckoResult.allow()` để grant, `GeckoResult.deny()` để từ chối.
        // CHẨN ĐOÁN (bug "chọn văn bản thường không thấy bôi đen" — mục
        // 23.2/24.1 PROJECT_STATUS.md). Trước đây app KHÔNG có
        // `selectionActionDelegate` — nghĩa là GeckoView tự dùng
        // `BasicSelectionActionDelegate` MẶC ĐỊNH của chính nó (xác nhận
        // qua javadoc chính thức: "This class is used by GeckoView by
        // default if the consumer does not explicitly set a
        // SelectionActionDelegate" — đây CHÍNH LÀ thứ vẽ toolbar "Sao
        // chép/Chọn tất cả/Đọc to" mà người dùng đã thấy trước đây).
        //
        // BUG NGHIÊM TRỌNG TỰ GÂY RA Ở LƯỢT TRƯỚC (đã sửa): lượt trước tôi
        // gán thẳng 1 object tự chế CHỈ LOG, KHÔNG VẼ GÌ, làm
        // `session.selectionActionDelegate` — theo đúng cơ chế Android/
        // GeckoView, làm vậy THAY THẾ HOÀN TOÀN `BasicSelectionActionDelegate`
        // mặc định, không còn ai vẽ toolbar nữa → mất luôn cả Sao chép/Dán/
        // Chọn tất cả (không chỉ mất highlight như bug gốc) — đúng khớp
        // triệu chứng người dùng vừa báo. Đây là lỗi tự gây ra do hiểu sai
        // hành vi delegate, không phải bug có sẵn.
        //
        // SỬA ĐÚNG theo pattern CHÍNH THỨC Mozilla khuyến nghị trong chính
        // javadoc của `BasicSelectionActionDelegate` ("To provide custom
        // actions, extend this class"): KẾ THỪA thay vì THAY THẾ — override
        // 2 hàm chỉ để ghi log chẩn đoán, gọi `super.onShowActionRequest()`/
        // `super.onHideAction()` NGAY SAU ĐÓ để toàn bộ hành vi vẽ toolbar
        // mặc định (bao gồm Sao chép/Dán/Chọn tất cả) hoạt động Y HỆT như
        // lúc chưa có delegate tự chế nào — không "cướp" trách nhiệm hiển
        // thị UI khỏi GeckoView nữa, chỉ "nghe lén" thêm để lấy log.
        // `context` truyền vào `GeckoViewEngine` chính là `MainActivity`
        // (xem `MainActivity`: `GeckoViewEngine(this, geckoView, slotIndex)`)
        // — đủ điều kiện `Activity` mà constructor của
        // `BasicSelectionActionDelegate` yêu cầu.
        //
        // CHƯA build/test — vẫn cần người dùng gửi lại dòng log
        // "[CHẨN ĐOÁN selection]" lần tới để biết `screenRect` có null hay
        // không, xác định bug bôi đen nằm ở tầng model hay tầng vẽ. Đồng
        // thời xác nhận GIÙM: sau bản vá này, Sao chép/Dán/Chọn tất cả đã
        // có lại chưa (phải có — đây là hồi quy chắc chắn phải hết hoàn
        // toàn, không phải giả thuyết).
        session.selectionActionDelegate = object : BasicSelectionActionDelegate(context as android.app.Activity) {
            override fun onShowActionRequest(
                session: GeckoSession,
                selection: GeckoSession.SelectionActionDelegate.Selection
            ) {
                lastSelectionActionUptime = android.os.SystemClock.uptimeMillis()
                val rect = selection.screenRect
                DebugLog.log(
                    "Khe $slotIndex: [CHẨN ĐOÁN selection] onShowActionRequest — " +
                    "text.length=${selection.text.length}, " +
                    "screenRect=${if (rect == null) "NULL (Gecko không có toạ độ hình học cho selection này)" else "$rect"}, " +
                    "flags=${selection.flags}"
                )
                // TÍNH NĂNG MỚI (mục 96 — người dùng chỉ đúng: menu Sao
                // chép/Cắt/Dán vô dụng nếu không có con trỏ để KÉO chỉnh
                // vùng chọn — `layout.accessiblecaret.*` (con trỏ NATIVE
                // của Gecko) đã xác nhận PHẢI tắt vì làm mất đăng nhập
                // Google (mục 81/83), không được bật lại. `screenRect` ở
                // đây là dữ liệu CÓ SẴN, không liên quan gì tới
                // accessiblecaret — dùng nó để vẽ 2 "núm kéo" bằng View
                // Android THẬT SỰ (`SelectionHandleOverlay`, không đụng gì
                // tới pref/renderer của Gecko) thay cho con trỏ native đã
                // phải tắt.
                onSelectionChangedListener?.invoke(rect, selection.text)
                super.onShowActionRequest(session, selection)
            }

            override fun onHideAction(session: GeckoSession, reason: Int) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN selection] onHideAction — reason=$reason")
                onSelectionHiddenListener?.invoke()
                super.onHideAction(session, reason)
            }

            /**
             * FIX BUG THẬT (người dùng báo: "dán text lớn từ khe nhớ tạm
             * vào cell Colab không phản ứng"). Tra cứu xác nhận qua chính
             * mã nguồn `BasicSelectionActionDelegate` (searchfox.org) +
             * changelog GeckoView (bug 1776829): từ 1 bản GeckoView nhất
             * định, MỌI lần trang gọi `navigator.clipboard.readText()`
             * (cách các trình soạn thảo kiểu CodeMirror — Colab dùng loại
             * này — thường xử lý dán, KHÁC với dán vào 1 ô `<input>` thường
             * qua context menu OS) đều phải xin quyền qua đúng callback
             * này trước. `BasicSelectionActionDelegate` (class app đang kế
             * thừa) mặc định xử lý bằng cách tự vẽ 1 THANH CÔNG CỤ NỔI
             * (`ActionMode` kiểu floating) yêu cầu người dùng CHẠM VÀO để
             * cấp quyền — rất có khả năng thanh này bị layout toàn màn
             * hình/immersive-mode của app (xem log "insets đổi" dày đặc
             * xuyên suốt session) che khuất hoặc định vị sai, khiến người
             * dùng không thấy gì để bấm — "không phản ứng" đúng là cảm
             * giác khi 1 UI cần bấm nhưng không hiển thị được, không phải
             * do bản thân việc dán bị chặn cứng.
             *
             * Sửa: ghi đè trực tiếp, tự động CHO PHÉP luôn — không cần vẽ
             * UI xin phép nào cả. An toàn cho app này (trình duyệt cá nhân
             * 1 người dùng, không phải trình duyệt công cộng nhiều người
             * dùng chung — đây cũng chính là lý do các quyền khác trong
             * app (vd `contentPermission=4/5 → ALLOW` thấy trong log) đã
             * được tự động cấp sẵn theo cùng tinh thần, không riêng gì
             * chỗ này).
             */
            override fun onShowClipboardPermissionRequest(
                session: GeckoSession,
                permission: GeckoSession.SelectionActionDelegate.ClipboardPermission
            ): org.mozilla.geckoview.GeckoResult<org.mozilla.geckoview.AllowOrDeny> {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN clipboard] onShowClipboardPermissionRequest — tự động ALLOW luôn, không vẽ UI xin phép")
                return org.mozilla.geckoview.GeckoResult.fromValue(org.mozilla.geckoview.AllowOrDeny.ALLOW)
            }
        }

        session.permissionDelegate = object : GeckoSession.PermissionDelegate {
            override fun onContentPermissionRequest(
                session: GeckoSession,
                perm: GeckoSession.PermissionDelegate.ContentPermission
            ): GeckoResult<Int> {
                // Mục 161: DRM/EME (Netflix, Disney+...). Tra cứu: GeckoView chuyển yêu cầu MediaKeySystemAccess cho APP quyết định (Bug 1587522); trước đây rơi vào nhánh `else -> DENY` nên video DRM không bao giờ chạy.
                // Lấy hằng số bằng reflection để không vỡ build nếu tên hằng khác ở bản GeckoView đang dùng.
                val emePerm = try { GeckoSession.PermissionDelegate::class.java.getField("PERMISSION_MEDIA_KEY_SYSTEM_ACCESS").getInt(null) } catch (_: Throwable) { -1 }
                if (emePerm != -1 && perm.permission == emePerm) {
                    val allowDrm = com.colablive.keeper.features.media.VideoStreamFeature.drmEnabled(context, slotIndex)
                    DebugLog.log("Khe $slotIndex: [DRM] yêu cầu MediaKeySystemAccess uri=${perm.uri} → ${if (allowDrm) "ALLOW (cài đặt Xem video bật DRM)" else "DENY (DRM đang tắt)"}")
                    return GeckoResult.fromValue(
                        if (allowDrm) GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                        else GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
                    )
                }
                return when (perm.permission) {
                    // AUTOPLAY: grant cả audio lẫn video — đây là nguyên nhân
                    // chính spinner YouTube Khe 1. Không có grant này, Gecko
                    // chặn media element tự play() khi không có user gesture
                    // (đúng spec W3C Autoplay Policy, Gecko tuân thủ nghiêm).
                    // Mục 160: video CÓ TIẾNG chỉ tự phát khi người dùng bật trong "Xem video / Stream" (MẶC ĐỊNH TẮT); video không tiếng luôn được phép.
                    GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_AUDIBLE ->
                        GeckoResult.fromValue(
                            if (com.colablive.keeper.features.media.VideoStreamFeature.autoplayAudible(context, slotIndex))
                                GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                            else GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
                        )
                    GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_INAUDIBLE ->
                        GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)

                    // DESKTOP NOTIFICATION: grant để không bị hỏi popup xin
                    // phép liên tục (YouTube, Google Meet hay hỏi).
                    GeckoSession.PermissionDelegate.PERMISSION_DESKTOP_NOTIFICATION ->
                        GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)

                    // GEOLOCATION / CAMERA / MIC: từ chối — app browser thật,
                    // không auto-grant cảm biến nhạy cảm không cần thiết.
                    else ->
                        GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
                }.also {
                    DebugLog.log("Khe $slotIndex: contentPermission=${perm.permission} uri=${perm.uri} → ${
                        when (perm.permission) {
                            GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_AUDIBLE ->
                                if (com.colablive.keeper.features.media.VideoStreamFeature.autoplayAudible(context, slotIndex)) "ALLOW (người dùng bật tự động phát có tiếng)" else "DENY (tự động phát có tiếng đang TẮT)"
                            GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_INAUDIBLE,
                            GeckoSession.PermissionDelegate.PERMISSION_DESKTOP_NOTIFICATION -> "ALLOW"
                            else -> "DENY"
                        }
                    }")
                }
            }
        }

        // onFilePrompt KHÔNG thuộc ContentDelegate (code cũ đặt sai chỗ, kèm
        // theo 1 "FileCallback" không tồn tại) — API thật nằm ở PromptDelegate,
        // nhận 1 đối tượng FilePrompt và trả về GeckoResult<PromptResponse>
        // ĐANG CHỜ (chưa hoàn thành ngay, vì việc chọn file thật xảy ra bất
        // đồng bộ qua Activity chọn file của Android) — MainActivity gọi lại
        // `resolveFilePrompt()` khi người dùng đã chọn xong để hoàn thành nó.
        session.promptDelegate = object : GeckoSession.PromptDelegate {
            override fun onFilePrompt(
                session: GeckoSession,
                prompt: GeckoSession.PromptDelegate.FilePrompt
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? {
                DebugLog.log("onFilePrompt: mimeTypes=${prompt.mimeTypes?.joinToString()} type=${prompt.type} (MULTIPLE=${GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE})")
                val fixedMimeTypes = prompt.mimeTypes?.map { mime ->
                    if (mime.contains("/")) mime else "*/*"
                }?.toTypedArray()
                pendingFilePrompt = prompt
                val result = GeckoResult<GeckoSession.PromptDelegate.PromptResponse>()
                pendingFilePromptResult = result
                onFilePromptListener?.invoke(fixedMimeTypes, prompt.type == GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE)
                return result
            }

            // Mục 165: hộp thoại của trang (dropdown <select>, alert, confirm, prompt) — trước đây KHÔNG có nên mọi dropdown trên mọi trang đều không bấm được.
            override fun onChoicePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ChoicePrompt) = WebPromptHandler.choice(context, slotIndex, prompt)
            override fun onAlertPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.AlertPrompt) = WebPromptHandler.alert(context, slotIndex, prompt)
            override fun onButtonPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ButtonPrompt) = WebPromptHandler.button(context, slotIndex, prompt)
            override fun onTextPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.TextPrompt) = WebPromptHandler.text(context, slotIndex, prompt)
            // Mục 166: ngày/giờ, màu, đăng nhập HTTP (kể cả proxy), cảnh báo rời trang, gửi lại biểu mẫu.
            override fun onDateTimePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.DateTimePrompt) = WebPromptHandler.dateTime(context, slotIndex, prompt)
            override fun onColorPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ColorPrompt) = WebPromptHandler.color(context, slotIndex, prompt)
            override fun onAuthPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.AuthPrompt) = WebPromptHandler.auth(context, slotIndex, prompt)
            override fun onBeforeUnloadPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.BeforeUnloadPrompt) = WebPromptHandler.beforeUnload(context, slotIndex, prompt)
            override fun onRepostConfirmPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.RepostConfirmPrompt) = WebPromptHandler.repost(context, slotIndex, prompt)
            override fun onPopupPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.PopupPrompt) = WebPromptHandler.popup(context, slotIndex, prompt) // Mục 169

            // Mục 118: Gecko tự điền đăng nhập; có nhiều tài khoản khớp thì hỏi ở đây (xem handleNativeLoginSelect).
            override fun onLoginSelect(
                session: GeckoSession,
                request: GeckoSession.PromptDelegate.AutocompleteRequest<Autocomplete.LoginSelectOption>
            ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse>? = try {
                handleNativeLoginSelect(request)
            } catch (e: Throwable) {
                DebugLog.log("Khe $slotIndex: [mật khẩu/Gecko] onLoginSelect LỖI ${e.javaClass.simpleName}: ${e.message}")
                null
            }
        }

        /**
         * NÚT PLAY/PAUSE THẬT TRÊN THÔNG BÁO — đã TRA ĐƯỢC API chính xác từ
         * code mẫu CHÍNH THỨC của Mozilla (GeckoViewActivity.java, ứng dụng
         * mẫu đi kèm GeckoView), không còn đoán. Xác nhận: `GeckoSession` có
         * property `mediaSessionDelegate` nhận 1
         * `MediaSession.Delegate` với `onPlay(session, mediaSession)`/
         * `onPause(...)`/`onStop(...)` — đối tượng `mediaSession` truyền vào
         * có `.play()`/`.pause()`/`.stop()` để ĐIỀU KHIỂN NGƯỢC LẠI (dùng khi
         * người dùng bấm nút trên thông báo).
         *
         * Bọc vào `android.media.session.MediaSession` CHUẨN của Android
         * (API nền tảng có sẵn, không cần thêm thư viện) — để hệ thống
         * (thông báo, màn hình khoá) biết và điều khiển được, giống hệt
         * cách mọi app nhạc/video làm.
         *
         * TÌM RA NGUYÊN NHÂN THẬT SỰ của việc mất nhạc nền (sau rất nhiều lần
         * sửa sai hướng trước đây — xem PROJECT_STATUS.md mục 8zb/8zd/8zh):
         * đọc tài liệu kiến trúc CHÍNH THỨC của Mozilla
         * (firefox-source-docs.mozilla.org/mobile/android/geckoview/
         * contributor/geckoview-architecture.html, mục "Priority Hint") xác
         * nhận: GeckoView TỰ GẮN độ ưu tiên tiến trình của 1 session với
         * việc session đó CÒN SURFACE (còn hiển thị) hay không — khi Activity
         * xuống nền, surface bị Android tự thu hồi, GeckoView tự hạ độ ưu
         * tiên tiến trình của CHÍNH GeckoSession đó (không liên quan gì đến
         * tiến trình chính/`KeepAliveService` — đó là tiến trình con RIÊNG
         * của Gecko, `KeepAliveService` không bảo vệ được nó). Tài liệu ghi
         * rõ đây CHÍNH LÀ tình huống "phát nhạc nền" — và cung cấp sẵn API
         * chính thức để xử lý: `GeckoSession.setPriorityHint(int)` — báo cho
         * GeckoView biết "session này quan trọng, giữ ưu tiên cao dù mất
         * surface". Gọi `PRIORITY_HIGH` khi có media đang phát, trả lại
         * `PRIORITY_DEFAULT` khi dừng hẳn — không giữ `PRIORITY_HIGH` mãi để
         * tránh tốn tài nguyên không cần thiết cho tab không phát gì.
         */
        session.mediaSessionDelegate = object : MediaSession.Delegate {
            override fun onPlay(session: GeckoSession, mediaSession: MediaSession) {
                DebugLog.log("Khe $slotIndex: MediaSession onPlay")
                currentGeckoMediaSession = mediaSession
                currentGeckoMediaSessionTabId = tabIdFor(session)
                // FIX BUG THẬT (người dùng báo đúng: "YouTube không ghim
                // chạy nền mà vẫn chạy nền khi không hiện tab trên màn
                // hình" — đã xác nhận qua đọc lại chính code này, không
                // phải suy đoán): dòng `setPriorityHint(PRIORITY_HIGH)`
                // BẢN CŨ gọi VÔ ĐIỀU KIỆN cho MỌI tab hễ có media bắt đầu
                // phát — hoàn toàn KHÔNG kiểm tra domain đó có nằm trong
                // danh sách ghim (`isBackgroundKeepAliveExemptUrl`,
                // `BackgroundKeepAliveFeature`) hay không. Theo đúng chú
                // thích gốc ngay phía trên (mục "TÌM RA NGUYÊN NHÂN THẬT
                // SỰ của việc mất nhạc nền"), `setPriorityHint(PRIORITY_
                // HIGH)` CHÍNH LÀ cơ chế báo GeckoView "giữ ưu tiên tiến
                // trình cao dù mất surface" — tức là cơ chế THẬT SỰ cho
                // chạy nền. Gọi vô điều kiện = MỌI tab đang phát media đều
                // được chạy nền thật, bất kể có ghim hay không — đúng
                // khớp triệu chứng người dùng báo (YouTube không ghim vẫn
                // chạy nền). SỬA: chỉ boost PRIORITY_HIGH nếu domain của
                // TAB ĐANG PHÁT nằm trong danh sách ghim — dùng lại đúng
                // hàm kiểm tra `isBackgroundKeepAliveExemptUrl()` đã có
                // sẵn (cùng hàm `switchToTab()` dùng), không phát minh cơ
                // chế mới. Tab KHÔNG ghim mà đang là tab ĐANG HIỂN THỊ vẫn
                // không cần boost (đã có ưu tiên tự nhiên vì đang active);
                // khi tab đó bị chuyển đi nền (switchToTab gọi
                // `setActive(false)`), sẽ đúng bị hạ cấp như Chrome thật —
                // không còn "chạy nền lậu" ngoài ý người dùng nữa.
                val tabUrl = tabIdFor(session)?.let { tabMeta[it]?.url }
                val exempt = tabUrl != null && isBackgroundKeepAliveExemptUrl(tabUrl)
                if (exempt) {
                    session.setPriorityHint(GeckoSession.PRIORITY_HIGH)
                } else {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN keepalive nền] tab đang phát media KHÔNG nằm trong danh sách ghim (url=$tabUrl) — KHÔNG boost PRIORITY_HIGH, để tab bị hạ cấp bình thường khi chuyển đi nền (đúng ý người dùng: không ghim thì không chạy nền)")
                }
                requestNonExclusiveAudioFocus()
                updateNativeMediaSession(true)
            }

            override fun onPause(session: GeckoSession, mediaSession: MediaSession) {
                DebugLog.log("Khe $slotIndex: MediaSession onPause")
                // Không hạ nhầm nếu chính tab này đang được Auto Behavior
                // giữ PRIORITY_HIGH vì lý do khác (xem startAutoBehavior) —
                // 2 cơ chế độc lập cùng có thể muốn giữ ưu tiên cao cho
                // CÙNG 1 tab, chỉ hạ khi KHÔNG còn lý do nào giữ nữa.
                if (tabIdFor(session) != autoBehaviorPriorityTabId) {
                    session.setPriorityHint(GeckoSession.PRIORITY_DEFAULT)
                }
                updateNativeMediaSession(false)
            }

            override fun onStop(session: GeckoSession, mediaSession: MediaSession) {
                DebugLog.log("Khe $slotIndex: MediaSession onStop")
                if (tabIdFor(session) != autoBehaviorPriorityTabId) {
                    session.setPriorityHint(GeckoSession.PRIORITY_DEFAULT)
                }
                updateNativeMediaSession(false)
            }
        }

        // Bản 7.71: báo TRƯỚC cho addon proxy vùng của tab ẩn danh sắp mở (xem GeckoRuntimeProvider.announcePrivateTab). Phải xảy ra TRƯỚC session.open().
        if (isPrivate) {
            val seqA = GeckoRuntimeProvider.announcePrivateTab(context, slotIndex, zoneId)
            if (seqA != 0L) sessionMapSeq[session] = seqA
        }
        return session
    }

    /** Tạo + cấu hình đầy đủ session (delegates, media session...) NHƯNG
     * KHÔNG mở — dùng cho tab thường (gọi `session.open()` ngay sau) VÀ cho
     * popup trong `onNewSession()` (KHÔNG được mở trước, xem giải thích lớn
     * ở đó — GeckoView tự mở session trả về từ `onNewSession`, mở sẵn sẽ
     * crash "Must use an unopened GeckoSession instance"). */
    private fun createSession(isPrivate: Boolean = false, zoneId: String = ""): GeckoSession {
        val session = createSessionUnopened(isPrivate, zoneId)
        DebugLog.log("GeckoViewEngine slot $slotIndex: bắt đầu session.open(runtime)")
        session.open(runtime)
        // Mặc định TẤT CẢ session mới tạo là KHÔNG active — chỉ
        // `switchToTab()` mới có quyền bật `setActive(true)` cho đúng 1
        // session đang thật sự hiển thị tại một thời điểm (xem giải thích
        // đầy đủ ở `switchToTab()`). An toàn kể cả với tab vừa tạo rồi
        // được `switchToTab()` gọi ngay sau (trong `createTab()`) — lúc đó
        // `setActive(true)` sẽ ghi đè lại giá trị `false` này ngay lập tức.
        session.setActive(false)
        DebugLog.log("GeckoViewEngine slot $slotIndex: session.open() XONG (không crash)")
        return session
    }

    /**
     * FIX BUG THẬT (người dùng báo: "để trình duyệt lâu không dùng thì màn
     * hình tối đen như mực, bấm reload không phản hồi — như icon chỉ trưng
     * vậy, phải vuốt xoá app trong Recent Apps mới hết"). Log gửi kèm xác
     * nhận chính xác nguyên nhân: `onKill()`/`onCrash()` CHỈ ghi log, KHÔNG
     * làm gì thêm — trong khi đọc thẳng mã nguồn GeckoSession.java
     * (searchfox.org) xác nhận: trước khi gọi `delegate.onKill()`/`onCrash()`,
     * CHÍNH GeckoSession đã tự gọi `close()` — nghĩa là từ thời điểm đó,
     * session coi như ĐÃ CHẾT HẲN (không load được, không reload được —
     * khớp CHÍNH XÁC "bấm reload không phản hồi": `session.reload()` gọi
     * trên 1 session đã `close()` là no-op im lặng, không lỗi, không tác
     * dụng, đúng cảm giác "icon chỉ trưng vậy"). Javadoc chính thức
     * GeckoView xác nhận thêm: *"The GeckoSession is now closed and
     * unusable. You may call GeckoSession.open(GeckoRuntime) to recover...
     * Most applications will want to call ... GeckoSession.restoreState(
     * SessionState) at this point."*
     *
     * Cách khôi phục dùng ở đây THEO ĐÚNG code THẬT của Mozilla (Firefox
     * for Android, android-components `GeckoEngineSession.onKill/onCrash`,
     * không phải suy đoán): thay vì gọi lại `open()` trên CHÍNH session cũ
     * (đã bị chính họ bỏ, kèm chú thích "đã từng gây lỗi" —
     * mozilla-mobile/android-components#3640), tạo hẳn 1 `GeckoSession`
     * MỚI qua `createSession()` (đã tự gắn đủ mọi delegate — content/
     * navigation/progress/permission/media/selection — không cần gắn lại
     * tay), rồi phục hồi state qua `GeckoSession.SessionState.fromString()`
     * (API ĐÃ DÙNG SẴN ở `switchToTab()` phía trên, không đoán mù) từ
     * `tab.savedState` đã lưu liên tục qua `onSessionStateChange`. QUAN
     * TRỌNG không kém: nếu tab vừa chết chính là tab ĐANG HIỂN THỊ
     * (`activeTabId`), phải tự `geckoView.setSession(newSession)` lại —
     * nếu không, `GeckoView` (widget) vẫn trỏ vào session CŨ đã chết, màn
     * hình tiếp tục đen dù đã có session mới sống trong `tabs` map (đây
     * chính là bước "rebind" mà bản Fenick/Fenix chính thức cũng làm ở
     * tầng View, xem `GeckoEngineView.onProcessKilled { rebind() }`).
     */
    /**
     * BUG THẬT tìm ra khi điều tra báo cáo người dùng ("Drive đang xem
     * bằng máy tính tự nhiên mất trạng thái đó, làm video đang upload bị
     * gãy luôn") — xác nhận qua đọc chính code, không suy đoán:
     * `recoverKilledOrCrashedSession()` (gọi rất thường xuyên trong log
     * thật — hệ thống kill session tab nền là chuyện bình thường trên
     * Android khi thiếu RAM) tạo 1 `GeckoSession` HOÀN TOÀN MỚI, load lại
     * URL, nhưng TRƯỚC ĐÂY không hề gọi lại logic áp desktop mode thủ
     * công. `manualDesktopTabIds` (Set theo tabId) vẫn đúng — không mất —
     * nhưng nó chỉ là 1 CỜ NHỚ, KHÔNG tự áp `userAgentMode`/`viewportMode`
     * lên session MỚI (các thuộc tính đó nằm TRÊN TỪNG OBJECT
     * `GeckoSession`, không tự động theo tabId). Kết quả: UI vẫn tưởng
     * "đang bật" (vì `manualDesktopTabIds` vẫn chứa tabId) nhưng session
     * THẬT đã quay về mobile — đúng khớp "tự nhiên mất trạng thái" mà
     * KHÔNG có dòng log nào báo (im lặng, vì không ai gọi tới nhánh log
     * của toggleDesktopMode/applyViewportExceptionForUrl cả). Việc video
     * đang upload bị gãy cũng khớp — session bị kill+tạo lại nghĩa là
     * TOÀN BỘ trạng thái JS/network in-flight trên trang đó mất sạch,
     * không lạ khi 1 upload đang chạy bị gãy.
     *
     * SỬA: trích logic "áp desktop mode nếu tab nằm trong
     * manualDesktopTabIds HOẶC domain nằm trong danh sách persist" thành
     * 1 hàm dùng chung `applyManualDesktopModeIfApplicable()` — gọi cả ở
     * đây (session mới sau kill/crash) VÀ ở `applyViewportExceptionForUrl()`
     * (đường điều hướng bình thường) để tránh 2 nơi tự viết lại logic
     * riêng dễ lệch nhau như đã xảy ra.
     */
    /** Mục 141: áp lại "di động thủ công" cho tab/tên miền người dùng đã chủ động tắt chế độ máy tính (xem `manualMobileTabIds`). true = đã áp. */
    private fun applyManualMobileModeIfApplicable(session: GeckoSession, tabId: String, url: String): Boolean {
        val marked = manualMobileTabIds.contains(tabId)
        val host = try { android.net.Uri.parse(url).host?.lowercase() } catch (e: Exception) { null }
        val persisted = host != null && AppPrefs.getString(context, slotIndex, "manual_mobile_mode_domains", "")
            .split(",", "\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.any { it == host }
        if (!marked && !persisted) return false
        if (manualDesktopTabIds.contains(tabId)) return false // đang bật máy tính thủ công thì đánh dấu kia thắng
        val hwNow = if (FingerprintSpoofFeature.isEnabled(context, slotIndex)) resolveProfileForZone(tabMeta[tabId]?.zoneId ?: "").first else null
        session.settings.userAgentOverride = if (hwNow != null && hwNow.category != "desktop") hwNow.userAgent else null
        session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        manualMobileTabIds.add(tabId)
        pushFingerprintConfig(session)
        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN di động thủ công] ÁP LẠI giao diện di động cho tab ${tabId.take(8)}, url=$url (đã đánh dấu=$marked, domain lưu sẵn=$persisted)")
        return true
    }

    private fun applyManualDesktopModeIfApplicable(session: GeckoSession, tabId: String, url: String): Boolean {
        val alreadyMarkedManual = manualDesktopTabIds.contains(tabId)
        val host = try { android.net.Uri.parse(url).host?.lowercase() } catch (e: Exception) { null }
        val domainPersisted = host != null && AppPrefs.getString(context, slotIndex, "manual_desktop_mode_domains", "")
            .split(",", "\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            .any { it == host }
        if (!alreadyMarkedManual && !domainPersisted) return false
        session.settings.userAgentOverride = desktopUaOverrideFor(tabId) // 7.62: như toggleDesktopMode — không đổi số phiên bản UA giữa phiên
        session.settings.userAgentMode = GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        session.settings.viewportMode = GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
        manualDesktopTabIds.add(tabId)
        pushFingerprintConfig(session)
        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN desktop thủ công] applyManualDesktopModeIfApplicable() ÁP LẠI desktop mode cho tab $tabId, url=$url (đã đánh dấu thủ công=$alreadyMarkedManual, domain lưu sẵn=$domainPersisted)")
        return true
    }

    /** Mục 110: true nếu URL là trang thật có thể nạp lại sau khi khởi động lại app (không phải blob/data/javascript/about:blank). */
    private fun isRestorableNavigation(uri: String?): Boolean {
        if (uri.isNullOrBlank()) return false
        val u = uri.trim().lowercase()
        return !(u == "about:blank" || u.startsWith("blob:") || u.startsWith("data:") || u.startsWith("javascript:") || u.startsWith("about:srcdoc"))
    }

    /**
     * Mục 110: URL dùng để NẠP LẠI tab đã lưu. `blob:https://claude.ai/<uuid>` không còn tồn tại sau khi tiến trình chết => đổi
     * về gốc trang (`https://claude.ai/`) thay vì nạp blob chết (kết quả là about:blank). `data:`/`javascript:` => trang chủ.
     */
    private fun loadableUrlForRestore(url: String): String {
        val u = url.trim()
        val lower = u.lowercase()
        return when {
            lower.startsWith("blob:") -> {
                val origin = try {
                    val inner = Uri.parse(u.substring(5))
                    if ((inner.scheme == "http" || inner.scheme == "https") && !inner.authority.isNullOrEmpty()) "${inner.scheme}://${inner.authority}/" else null
                } catch (e: Exception) { null }
                origin ?: NewTabPage.homeUrl(context, slotIndex)
            }
            lower.startsWith("data:") || lower.startsWith("javascript:") -> NewTabPage.homeUrl(context, slotIndex)
            else -> u
        }
    }

    private fun recoverKilledOrCrashedSession(deadSession: GeckoSession, wasCrash: Boolean) {
        try {
            val tabId = tabIdFor(deadSession)
            if (tabId == null) {
                DebugLog.log("Khe $slotIndex: recoverKilledOrCrashedSession() không tìm được tabId cho session đã chết — bỏ qua (có thể là session popup chưa gắn tabId)")
                return
            }
            val tab = tabMeta[tabId] ?: return
            val savedStateStr = tab.savedState
            val newSession = createSession(tab.isPrivate, tab.zoneId)
            tabs[tabId] = newSession
            // FIX BUG THẬT (xem chú thích đầy đủ ở applyManualDesktopModeIfApplicable
            // phía trên): áp lại desktop mode thủ công cho session MỚI này
            // TRƯỚC KHI load/restore — để lần load đầu tiên trên session
            // mới đã đúng UA/viewport ngay từ đầu, không phải load 1 lần
            // sai rồi mới sửa (tránh nháy giao diện mobile→desktop).
            if (!applyManualDesktopModeIfApplicable(newSession, tabId, tab.url)) applyManualMobileModeIfApplicable(newSession, tabId, tab.url)
            when {
                savedStateStr != null -> {
                    try {
                        val state = GeckoSession.SessionState.fromString(savedStateStr)
                        if (state != null) newSession.restoreState(state) else newSession.loadUri(loadableUrlForRestore(tab.url))
                    } catch (e: Exception) {
                        DebugLog.log("Khe $slotIndex: restoreState sau ${if (wasCrash) "crash" else "kill"} lỗi (${e.message}) — loadUri thay thế")
                        newSession.loadUri(loadableUrlForRestore(tab.url))
                    }
                }
                tab.url.isNotBlank() && tab.url != "about:blank" -> newSession.loadUri(loadableUrlForRestore(tab.url))
            }
            if (tabId == activeTabId) {
                newSession.setActive(true)
                geckoView.setSession(newSession)
                DebugLog.log("Khe $slotIndex: đã tạo session MỚI + rebind GeckoView cho tab $tabId (đang hiển thị) sau ${if (wasCrash) "crash" else "bị hệ thống kill"}")
            } else {
                DebugLog.log("Khe $slotIndex: đã tạo session MỚI (nền, chưa cần rebind) cho tab $tabId sau ${if (wasCrash) "crash" else "bị hệ thống kill"}")
            }
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: recoverKilledOrCrashedSession() lỗi: ${e.message}")
        }
    }

    // MediaSession GeckoView đang phát GẦN NHẤT — dùng để chuyển tiếp lệnh
    // play()/pause() khi người dùng bấm nút trên thông báo hệ thống ngược
    // lại cho ĐÚNG tab đang phát.
    private var currentGeckoMediaSession: MediaSession? = null
    /**
     * FIX BUG THẬT trong CHÍNH log tự-chẩn-đoán (`logMediaActionRealEffect()`)
     * — người dùng chỉ đúng: nhiều dòng log "TUA TỚI... KHÔNG CÓ THẺ
     * VIDEO" hoá ra là DO CHÍNH HÀM CHẨN ĐOÁN đọc NHẦM TAB. Hàm đó trước
     * đây dùng `activeTabId` (tab đang HIỂN THỊ/focus trong app) — nhưng
     * media có thể đang phát ở 1 tab NỀN khác (vd đang xem Colab trong khi
     * nhạc/video YouTube ở tab khác vẫn phát) — `currentGeckoMediaSession`
     * hoàn toàn ĐỘC LẬP với tab nào đang hiển thị. Lưu thêm ĐÚNG tabId của
     * tab đang giữ `currentGeckoMediaSession` này (qua `tabIdFor(session)`
     * đã có sẵn) để hàm chẩn đoán đọc đúng tab, không đoán nhầm theo
     * `activeTabId`.
     */
    private var currentGeckoMediaSessionTabId: String? = null
    private var nativeMediaSession: android.media.session.MediaSession? = null

    /** Callback cho MainActivity/feature biết trạng thái play/pause để cập nhật
     * thông báo hiển thị (tên bài/trang, icon...). */
    override var onMediaPlaybackStateListener: ((playing: Boolean) -> Unit)? = null

    // ===== Mục 159: nút TUA NHANH/TUA LÙI trên thông báo =====
    // Gecko `MediaSession.seekForward()/seekBackward()` chỉ chuyển lệnh cho handler `seekforward/seekbackward` mà TRANG tự đăng ký
    // (navigator.mediaSession.setActionHandler); trang nào không đăng ký thì bấm nút không có tác dụng gì (log chẩn đoán cũ đã ghi "KHÔNG ĐỔI GÌ CẢ").
    // Sửa: vẫn gửi lệnh cho trang trước; sau 0,8 giây đọc lại currentTime của <video>/<audio> (khung chính). Nếu KHÔNG nhảy >= 2 giây
    // (tức trang không xử lý) thì tự đặt currentTime = hiện tại ± 10 giây. Trang đã tự tua thì không tua thêm (tránh tua đôi).
    // Hạn chế: chỉ thấy media ở khung chính của trang, không thấy media trong iframe.
    private fun seekMediaWithFallback(deltaSecSign: Int, label: String, viaPage: () -> Unit) {
        // Mục 160: số giây và công tắc dự phòng lấy từ cài đặt "Xem video / Stream".
        val step = com.colablive.keeper.features.media.VideoStreamFeature.seekStepSec(context, slotIndex)
        val deltaSec = if (deltaSecSign >= 0) step else -step
        val forceApp = com.colablive.keeper.features.media.VideoStreamFeature.seekForceApp(context, slotIndex)
        if (!forceApp && !com.colablive.keeper.features.media.VideoStreamFeature.seekFallback(context, slotIndex)) {
            try { viaPage() } catch (_: Throwable) {}
            DebugLog.log("Khe $slotIndex: [media] '$label': tua dự phòng đang TẮT trong cài đặt — chỉ gửi lệnh cho trang")
            return
        }
        val tabId = currentGeckoMediaSessionTabId ?: activeTabId ?: run { try { viaPage() } catch (_: Throwable) {}; return }
        val pick = "var els=[].slice.call(document.querySelectorAll('video,audio'));if(!els.length)return 'none';" +
            "var v=els.filter(function(e){return !e.paused&&!e.ended;})[0];" +
            "if(!v){els.sort(function(a,b){return (b.duration||0)-(a.duration||0);});v=els[0];}"
        val readJs = "(function(){" + pick + "return v.currentTime.toFixed(2);})();"
        val seekJs = "(function(d){" + pick + "var t=v.currentTime+d;var dur=v.duration;" +
            "if(isFinite(dur))t=Math.min(t,Math.max(0,dur-0.25));t=Math.max(0,t);v.currentTime=t;return 'dat currentTime='+t.toFixed(2);})(" + deltaSec + ");"
        if (forceApp) {
            // Mục 161: "luôn dùng số giây của app" — không gửi cho handler của trang (trang tự quyết số giây theo code của nó), tự tua thẳng vào <video>/<audio>.
            evaluateJsForTab(tabId, seekJs) { r -> DebugLog.log("Khe $slotIndex: [media] '$label': tua trực tiếp ${deltaSec}s theo cài đặt của app (bỏ qua handler của trang): $r") }
            return
        }
        fun parse(r: String?): Double? = r?.trim()?.trim('"')?.toDoubleOrNull()
        evaluateJsForTab(tabId, readJs) { before ->
            try { viaPage() } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [media] '$label' gửi cho trang LỖI: ${e.message}") }
            val b = parse(before)
            if (b == null) {
                // Mục 165: log thật cho thấy kênh đọc đôi khi trả null (broadcast sai tab / chưa có cổng) => không xác minh được trang có tự tua không.
                // Thà thử tua trực tiếp (có thể là lần tua thứ 2 nếu trang vừa tự tua) còn hơn nút "không làm gì".
                DebugLog.log("Khe $slotIndex: [media] '$label': không đọc được <video>/<audio> (kết quả='$before') — thử tua trực tiếp ${deltaSec}s")
                evaluateJsForTab(tabId, seekJs) { r -> DebugLog.log("Khe $slotIndex: [media] '$label': tua trực tiếp (không xác minh): $r") }
                return@evaluateJsForTab
            }
            handler.postDelayed({
                evaluateJsForTab(tabId, readJs) { after ->
                    val a = parse(after)
                    if (a != null && Math.abs(a - b) >= 2.0) {
                        DebugLog.log("Khe $slotIndex: [media] '$label': trang TỰ tua được ($b → $a), không cần dự phòng")
                    } else {
                        evaluateJsForTab(tabId, seekJs) { r -> DebugLog.log("Khe $slotIndex: [media] '$label': trang KHÔNG tua (trước=$b sau=$after) => tua trực tiếp ${deltaSec}s: $r") }
                    }
                }
            }, 800L)
        }
    }

    @Volatile private var mediaPlayingNow = false
    /** Mục 159: có media đang phát (theo MediaSession của Gecko) — dùng để quyết định vào Picture-in-Picture. */
    fun isMediaPlaying(): Boolean = mediaPlayingNow

    /**
     * FIX LOG THẬT (đúng phê bình của người dùng: "nút media như làm
     * cảnh, chả có tác dụng gì" — trước đây log chỉ xác nhận LỆNH ĐÃ TỚI
     * `currentGeckoMediaSession` (`nextTrack()`/`seekForward()`/...), chứ
     * KHÔNG hề xác nhận lệnh đó có THẬT SỰ làm gì trên trang web hay
     * không — đây chính xác là khoảng trống khiến không biết chuyện gì
     * đang xảy ra). Đọc `currentTime`/`src`/`paused` của thẻ `<video>`
     * NGAY TRƯỚC và SAU (2 giây sau) khi gọi 1 hành động MediaSession —
     * nếu `currentTime` hoặc `src` (đổi bài đồng nghĩa đổi src) có thay
     * đổi thật, đó là bằng chứng CHẮC CHẮN lệnh có tác dụng thật trên
     * trang; nếu KHÔNG đổi gì cả, chứng tỏ
     * `currentGeckoMediaSession.nextTrack()/seekForward()/...` tuy được
     * GỌI ĐÚNG (không lỗi) nhưng KHÔNG được trang web (YouTube) thật sự
     * xử lý gì — rất có thể do trang không đăng ký handler tương ứng qua
     * `navigator.mediaSession.setActionHandler(...)`, nằm ngoài tầm sửa
     * của app (GeckoView chỉ CHUYỂN TIẾP lệnh, không tự mô phỏng hành vi
     * nếu trang không có sẵn logic xử lý).
     */
    private fun logMediaActionRealEffect(actionLabel: String) {
        // FIX BUG THẬT: dùng ĐÚNG tab đang giữ currentGeckoMediaSession
        // (`currentGeckoMediaSessionTabId`), KHÔNG dùng `activeTabId` (tab
        // đang hiển thị) — 2 tab này có thể KHÁC NHAU nếu media phát nền ở
        // 1 tab trong khi người dùng đang xem tab khác. Xem chú thích lớn
        // ở khai báo `currentGeckoMediaSessionTabId`.
        val tabId = currentGeckoMediaSessionTabId ?: activeTabId ?: return
        val jsRead = """
            (function() {
                var v = document.querySelector('video');
                if (!v) return 'KHÔNG CÓ THẺ VIDEO';
                return 'currentTime=' + v.currentTime.toFixed(2) + ' paused=' + v.paused + ' src=' + (v.currentSrc ? v.currentSrc.substring(v.currentSrc.length - 40) : '(rỗng)');
            })();
        """.trimIndent()
        evaluateJsForTab(tabId, jsRead) { before ->
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN tác dụng thật của '$actionLabel'] TRƯỚC: $before")
            handler.postDelayed({
                evaluateJsForTab(tabId, jsRead) { after ->
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN tác dụng thật của '$actionLabel'] SAU 2s: $after — ${if (before == after) "KHÔNG ĐỔI GÌ CẢ (nghi ngờ trang không xử lý lệnh này thật sự, dù GeckoView nhận lệnh không lỗi)" else "CÓ THAY ĐỔI (lệnh có tác dụng thật trên trang)"}")
                }
            }, 2000L)
        }
    }

    private fun ensureNativeMediaSession(): android.media.session.MediaSession {
        nativeMediaSession?.let { return it }
        val ms = android.media.session.MediaSession(context, "LiveBrowserMedia_$slotIndex")
        ms.setCallback(object : android.media.session.MediaSession.Callback() {
            override fun onPlay() {
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu Play (từ thông báo/màn hình khoá)")
                currentGeckoMediaSession?.play()
            }
            override fun onPause() {
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu Pause (từ thông báo/màn hình khoá)")
                currentGeckoMediaSession?.pause()
            }
            override fun onStop() {
                currentGeckoMediaSession?.stop()
            }
            /**
             * FIX TÍNH NĂNG THIẾU (người dùng báo: "thanh media player trên
             * thanh thông báo chỉ có nút play pause, ko có nút tiến tới hay
             * lùi lại"): `PlaybackState` trước đây chỉ khai báo
             * ACTION_PLAY/ACTION_PAUSE/ACTION_STOP — chưa từng có
             * SKIP_TO_NEXT/SKIP_TO_PREVIOUS, nên hệ thống không hiện nút đó
             * (đúng hành vi Android: notification chỉ hiện nút cho action
             * đã khai báo trong PlaybackState).
             *
             * BUG THẬT tiếp theo đã sửa (người dùng báo: "nút tiến lùi media
             * trên thanh thông báo khi nhấn vào vẫn ko thay bài nhạc khác"
             * — xác nhận qua log: bấm nút, log "hệ thống yêu cầu tua
             * tới/lui" xuất hiện đúng, `currentGeckoMediaSession=CÓ`, nghĩa
             * là lệnh CÓ tới nơi, nhưng bài không đổi): lượt sửa TRƯỚC dùng
             * `seekForward()`/`seekBackward()` — tra lại tài liệu Javadoc
             * CHÍNH THỨC của GeckoView (mozilla.github.io/geckoview) xác
             * nhận 2 hàm này CHỈ "Seek forward/backward by a sensible
             * number of seconds" (tua vài giây TRONG CÙNG 1 media element
             * đang phát), khác hẳn `nextTrack()`/`previousTrack()` — đúng
             * mô tả Javadoc: "Select and play the next/previous track. Move
             * playback to the next item in the playlist when supported."
             * Đây chính xác là API tương ứng với action
             * `nexttrack`/`previoustrack` của Web MediaSession API
             * (`navigator.mediaSession.setActionHandler('nexttrack', ...)`)
             * — hàm GeckoView chuyển tiếp đúng xuống handler mà TRANG WEB
             * tự đăng ký (vd YouTube tự set handler này để nhảy sang video
             * kế tiếp trong playlist — đúng ngữ cảnh log cho thấy URL có
             * `list=RDeAc2ZtcE-48` là 1 playlist/radio thật). Lượt sửa
             * TRƯỚC nhận định "hầu hết trang không có khái niệm bài tiếp
             * theo" là suy đoán sai khiến chọn nhầm API — sửa lại dùng đúng
             * `nextTrack()`/`previousTrack()`. Nếu trang KHÔNG tự đăng ký
             * handler `nexttrack`/`previoustrack` (trang phát media đơn
             * giản, không phải playlist), GeckoView/trình duyệt sẽ tự
             * fallback hợp lý (thường là không làm gì hoặc coi như seek) —
             * không tệ hơn hành vi cũ, và ĐÚNG hẳn cho đúng trường hợp
             * playlist mà người dùng đang gặp.
             */
            override fun onSkipToNext() {
                val sess = currentGeckoMediaSession
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu CHUYỂN BÀI TIẾP THEO (từ thông báo/màn hình khoá) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart; cần vào tab đang phát để kết nối lại session"}")
                if (sess != null) {
                    sess.nextTrack()
                    logMediaActionRealEffect("CHUYỂN BÀI TIẾP THEO")
                }
            }
            override fun onSkipToPrevious() {
                val sess = currentGeckoMediaSession
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu CHUYỂN BÀI TRƯỚC ĐÓ (từ thông báo/màn hình khoá) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart; cần vào tab đang phát để kết nối lại session"}")
                if (sess != null) {
                    sess.previousTrack()
                    logMediaActionRealEffect("CHUYỂN BÀI TRƯỚC ĐÓ")
                }
            }
            /**
             * THÊM MỚI theo yêu cầu (giữ CẢ 2 loại nút — "chuyển bài"
             * ở trên VÀ "tua giây trong bài" ở đây — thành 4 nút riêng
             * biệt, không phải đổi 2 nút cũ thành nghĩa khác): dùng đúng 2
             * callback THẬT dành riêng cho việc "tua theo giây" của
             * `android.media.session.MediaSession.Callback` —
             * `onFastForward()`/`onRewind()` — khác hẳn
             * `onSkipToNext()`/`onSkipToPrevious()` ở trên (dành cho
             * "chuyển bài"). Gọi đúng `seekForward()`/`seekBackward()` của
             * GeckoView (đã xác nhận qua Javadoc chính thức ở chú thích lớn
             * phía trên: "Seek forward/backward by a sensible number of
             * seconds" — đúng nghĩa tua giây, không phải chuyển bài).
             */
            override fun onFastForward() {
                val sess = currentGeckoMediaSession
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu TUA TỚI vài giây (từ thông báo/màn hình khoá) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart"}")
                seekMediaWithFallback(10, "TUA TỚI (onFastForward)") { sess?.seekForward() }
            }
            override fun onRewind() {
                val sess = currentGeckoMediaSession
                DebugLog.log("Khe $slotIndex: hệ thống yêu cầu TUA LÙI vài giây (từ thông báo/màn hình khoá) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart"}")
                seekMediaWithFallback(-10, "TUA LÙI (onRewind)") { sess?.seekBackward() }
            }
            /**
             * BUG THẬT tìm ra (người dùng báo đúng: widget media control
             * trên thanh thông báo Android 13+ VẪN chỉ hiện 3 nút dù đã
             * khai báo đủ 5 action, xác nhận qua log đúng version mới đang
             * chạy — loại trừ hẳn khả năng "chưa build"). Tra tài liệu
             * CHÍNH THỨC developer.android.com/about/versions/13/behavior-changes-13
             * — mục "Media controls derived from PlaybackState" — có bảng
             * quy định CỨNG: slot 4 và 5 của widget media MỚI (đúng loại
             * card tròn "Điện thoại này" trong ảnh chụp) CHỈ lấy từ
             * `PlaybackState.getCustomActions()` — một danh sách HOÀN TOÀN
             * RIÊNG BIỆT với `.setActions()` (bitmask) đang dùng cho
             * ACTION_FAST_FORWARD/ACTION_REWIND. Bitmask đó KHÔNG BAO GIỜ
             * được widget này dùng để lấp slot 4/5 — đây là lý do THẬT,
             * xác nhận bằng tài liệu, không phải do compact view hay do
             * bản build cũ.
             * Custom Action bấm từ system UI gọi qua
             * `MediaSession.Callback.onCustomAction(action, extras)` —
             * KHÁC hẳn `onFastForward()`/`onRewind()` ở trên (2 hàm đó vẫn
             * giữ lại, dùng cho thông báo mở rộng kiểu cũ/thiết bị dưới
             * Android 13 đọc theo `Notification.Action` thường).
             */
            override fun onCustomAction(action: String, extras: android.os.Bundle?) {
                val sess = currentGeckoMediaSession
                when (action) {
                    CUSTOM_ACTION_REWIND -> {
                        DebugLog.log("Khe $slotIndex: hệ thống yêu cầu TUA LÙI vài giây qua CustomAction (widget media Android 13+) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart; cần vào tab đang phát để kết nối lại session"}")
                        // FIX BUG THẬT: trước đây gọi logMediaActionRealEffect()
                        // VÔ ĐIỀU KIỆN kể cả khi sess=null (currentGeckoMediaSession?.seekBackward()
                        // là no-op im lặng) — hàm đó fallback đọc trạng thái video
                        // của activeTabId (tab ĐANG HIỂN THỊ, có thể KHÁC tab
                        // đang phát nhạc nền), rồi báo "KHÔNG ĐỔI GÌ CẢ" — bị
                        // hiểu nhầm là "trang không xử lý lệnh" trong khi THỰC RA
                        // lệnh chưa từng được gửi đi (session null). Chỉ gọi
                        // logMediaActionRealEffect() khi THẬT SỰ có lệnh gửi.
                        seekMediaWithFallback(-10, "TUA LÙI (CustomAction)") { sess?.seekBackward() }
                    }
                    CUSTOM_ACTION_FAST_FORWARD -> {
                        DebugLog.log("Khe $slotIndex: hệ thống yêu cầu TUA TỚI vài giây qua CustomAction (widget media Android 13+) — currentGeckoMediaSession=${if (sess != null) "CÓ (tabId=$currentGeckoMediaSessionTabId)" else "NULL — tab media lazy-load chưa phát lại sau restart; cần vào tab đang phát để kết nối lại session"}")
                        seekMediaWithFallback(10, "TUA TỚI (CustomAction)") { sess?.seekForward() }
                    }
                }
            }
        })
        nativeMediaSession = ms
        return ms
    }

    override fun getNativeMediaSessionToken(): android.media.session.MediaSession.Token =
        ensureNativeMediaSession().sessionToken

    /**
     * BUG THẬT đã tìm ra (người dùng báo: "thanh bar phát nhạc không như
     * bar bình thường, nhấn dừng vẫn còn bar, hiện icon tam giác, bấm vào
     * lại phát tiếp"): `nativeMediaSession` (ở trên) có đầy đủ
     * `PlaybackState` đúng (PLAYING/PAUSED) — NHƯNG chưa từng có notification
     * `MediaStyle` THẬT nào được dựng từ nó cả. `onMediaPlaybackStateListener`
     * (khai báo phía trên) CHƯA TỪNG có ai lắng nghe — kiểm tra toàn bộ
     * MainActivity.kt xác nhận không có dòng nào dùng nó. Cái "thanh bar" mà
     * người dùng thấy chỉ là notification TĨNH của `KeepAliveService`
     * (`ic_media_play` — icon tam giác CỨNG, không đổi bao giờ, không có nút
     * bấm thật, không liên quan gì đến nhạc — nó luôn ở đó bất kể có phát
     * nhạc hay không).
     *
     * Sửa: tự dựng notification `MediaStyle` THẬT ở đây, dùng
     * `android.app.Notification.MediaStyle` (lớp NỀN TẢNG, không phải
     * `androidx.media.app.NotificationCompat.MediaStyle` — lớp đó nằm trong
     * dependency `androidx.media:media` CHƯA có trong build.gradle project
     * này, thêm dependency mới sẽ không build-test được ở đây). Lớp nền tảng
     * nhận thẳng `android.media.session.MediaSession.Token` (đúng loại
     * `sessionToken` đã có sẵn), không cần thêm gì.
     *
     * Nút Play/Pause thật: dùng `BroadcastReceiver` tự đăng ký trong chính
     * class này (KHÔNG khai báo trong Manifest, không cần thư viện
     * `androidx.media`/`MediaButtonReceiver`) — khi bấm, gọi thẳng
     * `nativeMediaSession.controller.transportControls.play()/pause()`,
     * chuyển tiếp đúng qua `MediaSession.Callback` đã có ở trên.
     */
    private var mediaActionReceiverRegistered = false
    private val mediaActionReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: android.content.Intent) {
            when (intent.action) {
                ACTION_MEDIA_PLAY -> nativeMediaSession?.controller?.transportControls?.play()
                ACTION_MEDIA_PAUSE -> nativeMediaSession?.controller?.transportControls?.pause()
                ACTION_MEDIA_SEEK_FORWARD -> nativeMediaSession?.controller?.transportControls?.skipToNext()
                ACTION_MEDIA_SEEK_BACKWARD -> nativeMediaSession?.controller?.transportControls?.skipToPrevious()
                // THÊM MỚI: 2 action riêng cho "tua giây trong bài" — khác
                // hẳn 2 action ở trên ("chuyển bài", gọi skipToNext/Previous
                // → onSkipToNext/onSkipToPrevious → nextTrack/previousTrack).
                // Ở đây gọi fastForward()/rewind() → đúng
                // onFastForward()/onRewind() → seekForward()/seekBackward().
                ACTION_MEDIA_FAST_FORWARD -> nativeMediaSession?.controller?.transportControls?.fastForward()
                ACTION_MEDIA_REWIND -> nativeMediaSession?.controller?.transportControls?.rewind()
            }
        }
    }
    private val ACTION_MEDIA_PLAY get() = "com.colablive.keeper.MEDIA_PLAY_$slotIndex"
    private val ACTION_MEDIA_PAUSE get() = "com.colablive.keeper.MEDIA_PAUSE_$slotIndex"
    private val ACTION_MEDIA_SEEK_FORWARD get() = "com.colablive.keeper.MEDIA_SEEK_FORWARD_$slotIndex"
    private val ACTION_MEDIA_SEEK_BACKWARD get() = "com.colablive.keeper.MEDIA_SEEK_BACKWARD_$slotIndex"
    private val ACTION_MEDIA_FAST_FORWARD get() = "com.colablive.keeper.MEDIA_FAST_FORWARD_$slotIndex"
    private val ACTION_MEDIA_REWIND get() = "com.colablive.keeper.MEDIA_REWIND_$slotIndex"

    /** Action string cho `PlaybackState.CustomAction` (khác hẳn action
     * string của Intent broadcast ở trên) — xem chú thích lớn ở
     * `onCustomAction()`/`updateNativeMediaSession()`. Không cần gắn
     * $slotIndex vì đây chỉ là định danh NỘI BỘ trong 1 MediaSession
     * (mỗi khe có MediaSession riêng), không phát broadcast toàn hệ thống
     * như 2 hằng số phía trên nên không lo trùng giữa các khe. */
    private val CUSTOM_ACTION_REWIND get() = "com.colablive.keeper.CUSTOM_ACTION_REWIND"
    private val CUSTOM_ACTION_FAST_FORWARD get() = "com.colablive.keeper.CUSTOM_ACTION_FAST_FORWARD"

    private fun ensureMediaActionReceiverRegistered() {
        if (mediaActionReceiverRegistered) return
        val filter = android.content.IntentFilter().apply {
            addAction(ACTION_MEDIA_PLAY)
            addAction(ACTION_MEDIA_PAUSE)
            addAction(ACTION_MEDIA_SEEK_FORWARD)
            addAction(ACTION_MEDIA_SEEK_BACKWARD)
            addAction(ACTION_MEDIA_FAST_FORWARD)
            addAction(ACTION_MEDIA_REWIND)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(mediaActionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(mediaActionReceiver, filter)
        }
        mediaActionReceiverRegistered = true
    }

    // Mục 142: tiêu đề/phụ đề thông báo phát nhạc phải theo TAB ĐANG PHÁT (không phải tab đang xem) + tên khe/hồ sơ.
    @Volatile private var nativeMediaPlaying = false

    private fun mediaSourceTabId(): String? = currentGeckoMediaSessionTabId ?: activeTabId

    private fun mediaTabTitle(): String {
        val t = mediaSourceTabId()?.let { tabMeta[it] }
        val title = t?.title?.takeIf { it.isNotBlank() }
        if (title != null) return title
        val host = try { t?.url?.let { android.net.Uri.parse(it).host } } catch (e: Exception) { null }
        return host?.takeIf { it.isNotBlank() } ?: "AndroidBrowserCustom"
    }

    private fun mediaProfileLine(): String =
        "Khe $slotIndex — ${com.colablive.keeper.core.ProfileSlots.getSlotAssignmentDisplay(context, slotIndex)}"

    /** Android 13+ vẽ thẻ media từ MediaMetadata của MediaSession (không đọc tiêu đề thông báo) nên phải đặt cả hai. */
    private fun applyMediaMetadata() {
        try {
            val ms = nativeMediaSession ?: return
            ms.setMetadata(
                android.media.MediaMetadata.Builder()
                    .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, mediaTabTitle())
                    .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, mediaProfileLine())
                    .putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, mediaProfileLine())
                    .build()
            )
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [nhạc nền] setMetadata lỗi: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /** Gọi khi tiêu đề tab đang phát đổi (YouTube nạp tên bài sau khi bắt đầu phát). */
    private fun refreshMediaTitleIfPlayingTab(tabId: String?) {
        if (tabId == null || nativeMediaSession == null || tabId != currentGeckoMediaSessionTabId) return
        handler.post {
            try {
                applyMediaMetadata()
                postMediaNotification(nativeMediaPlaying)
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: [nhạc nền] cập nhật tiêu đề thông báo lỗi: ${e.message}")
            }
        }
    }

    private fun postMediaNotification(playing: Boolean) {
        ensureMediaActionReceiverRegistered()
        val nm = context.getSystemService(android.app.NotificationManager::class.java)
        val channelId = "live_browser_media"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                channelId, "Đang phát media", android.app.NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            nm.createNotificationChannel(channel)
        }

        val playPauseAction = if (playing) {
            val pi = android.app.PendingIntent.getBroadcast(
                context, slotIndex, android.content.Intent(ACTION_MEDIA_PAUSE),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            android.app.Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_pause),
                "Tạm dừng", pi
            ).build()
        } else {
            val pi = android.app.PendingIntent.getBroadcast(
                context, slotIndex, android.content.Intent(ACTION_MEDIA_PLAY),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            android.app.Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_play),
                "Phát", pi
            ).build()
        }

        /**
         * FIX TÍNH NĂNG THIẾU (tiếp tục): 2 nút CHUYỂN BÀI thật, dùng
         * PendingIntent broadcast riêng (giống pattern play/pause đã có
         * sẵn ở trên) — không cần thư viện `androidx.media` mới nào.
         *
         * Nhãn/icon "Bài trước/Bài sau" (ic_media_previous/next) — khớp
         * đúng hành vi THẬT sau khi sửa bug nút không đổi bài (xem chú
         * thích lớn ở `onSkipToNext()`/`onSkipToPrevious()` phía trên): 2
         * nút này gọi `nextTrack()`/`previousTrack()` (chuyển bài trong
         * playlist).
         */
        val previousTrackAction = android.app.Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_previous),
            "Bài trước",
            android.app.PendingIntent.getBroadcast(
                context, slotIndex + 10_000, android.content.Intent(ACTION_MEDIA_SEEK_BACKWARD),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
        ).build()
        val nextTrackAction = android.app.Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_next),
            "Bài sau",
            android.app.PendingIntent.getBroadcast(
                context, slotIndex + 20_000, android.content.Intent(ACTION_MEDIA_SEEK_FORWARD),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
        ).build()

        /**
         * THÊM MỚI theo yêu cầu người dùng ("lỡ có 2 nút kia rồi thì làm
         * thêm 2 nút kia thành 4 nút luôn"): giữ LẠI 2 nút "tua giây trong
         * bài" (ý nghĩa gốc ban đầu, dùng icon tua thật `ic_media_rew`/
         * `ic_media_ff`) — KHÔNG thay thế 2 nút chuyển bài ở trên, mà làm
         * THÊM cho đủ 4 nút điều khiển + 1 nút play/pause = 5 nút tổng.
         * Dùng 2 action string mới (`ACTION_MEDIA_REWIND`/
         * `ACTION_MEDIA_FAST_FORWARD`) + request code riêng (khác hẳn
         * request code của 2 nút chuyển bài ở trên) để 2 cặp PendingIntent
         * không đè lên nhau.
         */
        val rewindAction = android.app.Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_rew),
            "Tua lùi",
            android.app.PendingIntent.getBroadcast(
                context, slotIndex + 30_000, android.content.Intent(ACTION_MEDIA_REWIND),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
        ).build()
        val fastForwardAction = android.app.Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_ff),
            "Tua tới",
            android.app.PendingIntent.getBroadcast(
                context, slotIndex + 40_000, android.content.Intent(ACTION_MEDIA_FAST_FORWARD),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
        ).build()

        val notification = android.app.Notification.Builder(context, channelId)
            .setContentTitle(mediaTabTitle())
            // BUG THẬT đã tìm ra (người dùng báo: "trên thanh thông báo
            // cũng ko biết đang phát nhạc khe nào, profile nào"): trước đây
            // contentText chỉ ghi "Đang phát"/"Đã tạm dừng", không có gì
            // phân biệt khe nào khi chạy nhiều khe song song. Thêm tiền tố
            // "Khe $slotIndex" — đây là thông tin GeckoViewEngine đã có sẵn
            // (không cần tra cứu thêm gì), đủ để phân biệt giữa các khe.
            .setContentText("${mediaProfileLine()} · ${if (playing) "Đang phát" else "Đã tạm dừng"}")
            .setSmallIcon(if (playing) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause)
            // Thứ tự 5 nút: lùi bài / tua lùi / play-play / tua tới / bài
            // sau — play/pause nằm CHÍNH GIỮA đúng bố cục media player
            // chuẩn (index 2 trong 5 nút, 0..4).
            .addAction(previousTrackAction)
            .addAction(rewindAction)
            .addAction(playPauseAction)
            .addAction(fastForwardAction)
            .addAction(nextTrackAction)
            .setStyle(
                android.app.Notification.MediaStyle()
                    .setMediaSession(ensureNativeMediaSession().sessionToken)
                    // Compact view (thu gọn trên màn hình khoá/thanh trạng
                    // thái) TỐI ĐA chỉ hiện được 3 nút — ưu tiên "bài
                    // trước/play-pause/bài sau" (index 0,2,4) vì đây là 3
                    // nút hữu ích nhất khi thu gọn; 2 nút tua giây (index
                    // 1,3) chỉ hiện khi mở rộng notification đầy đủ.
                    .setShowActionsInCompactView(0, 2, 4)
            )
            .setOngoing(playing)
            .build()

        /**
         * BUG THẬT đã tìm ra (người dùng báo 2 việc liên quan: nút
         * play/pause trên thông báo không tắt được nhạc; VÀ "trước kia vừa
         * phát nhạc nền vừa chạy Colab, Colab vẫn sống được, giờ dù phát
         * nhạc nền Colab vẫn không sống nổi"): trước lượt gate lại
         * `KeepAliveService` theo đúng cờ `colablive_keepalive_on`, service
         * đó chạy vô điều kiện — VÔ TÌNH bảo vệ luôn CẢ PROCESS (không chỉ
         * riêng Colab) khỏi bị hệ thống đóng băng/giết khi xuống nền, kể cả
         * khi chỉ đang phát nhạc nền không liên quan Colab. Bảo vệ process
         * thì bảo vệ TẤT CẢ mọi thứ chạy trong đó (Colab, MediaSession...).
         * Gate lại đúng cờ (fix hợp lý, không sai) vô tình làm mất luôn tác
         * dụng phụ này.
         * SỬA ĐÚNG GỐC: dùng `MediaKeepAliveService` (đã dựng riêng — xem
         * MediaKeepAliveService.kt) khi ĐANG PHÁT — service này chạy độc
         * lập với `colablive_keepalive_on`, chỉ cần có media đang phát. Vì
         * nó bảo vệ CẢ process, Colab (nếu đang chạy trong cùng khe) được
         * bảo vệ THEO — đúng lại hành vi cũ người dùng đã quen, không phải
         * chủ ý thiết kế mới mà là khôi phục tác dụng phụ có lợi đã mất.
         * Khi TẠM DỪNG, dừng foreground service (không cần bảo vệ liên tục
         * nữa), notification vẫn hiện bình thường qua nm.notify() (không
         * foreground, nhưng vẫn có nút bấm tương tác được ngay lúc process
         * còn sống — đủ dùng cho UI đã tạm dừng, không cần bảo vệ mạnh).
         */
        val serviceClass = MediaKeepAliveService.classForSlot(slotIndex)
        if (playing) {
            MediaKeepAliveService.start(context, serviceClass, 2000 + slotIndex, notification)
        } else {
            MediaKeepAliveService.stop(context, serviceClass)
            nm.notify(2000 + slotIndex, notification)
        }
    }

    private fun updateNativeMediaSession(playing: Boolean) {
        mediaPlayingNow = playing // Mục 159
        val ms = ensureNativeMediaSession()
        val stateBuilder = android.media.session.PlaybackState.Builder()
            .setActions(
                android.media.session.PlaybackState.ACTION_PLAY or
                android.media.session.PlaybackState.ACTION_PAUSE or
                android.media.session.PlaybackState.ACTION_STOP or
                // FIX TÍNH NĂNG THIẾU: thêm 2 action tua tới/lui — thiếu
                // khai báo ở đây thì dù có addAction() ở notification, hệ
                // thống vẫn có thể ẩn nút (PlaybackState là nguồn sự thật
                // Android dùng để quyết định action nào hợp lệ/hiện được).
                android.media.session.PlaybackState.ACTION_SKIP_TO_NEXT or
                android.media.session.PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                // Giữ lại 2 bitmask action này cho THIẾT BỊ DƯỚI ANDROID 13
                // (hoặc app không target API 33 — theo đúng bảng tài liệu,
                // ở các trường hợp đó hệ thống vẫn đọc theo Notification.Action
                // thường như trước giờ). Ở Android 13+ thì 2 action bitmask
                // này KHÔNG được widget media mới dùng cho slot 4/5 — xem
                // chú thích lớn ở `addCustomAction` ngay dưới đây để biết
                // cách THẬT làm 2 nút tua giây hiện ra trên widget mới.
                android.media.session.PlaybackState.ACTION_FAST_FORWARD or
                android.media.session.PlaybackState.ACTION_REWIND
            )
            .setState(
                if (playing) android.media.session.PlaybackState.STATE_PLAYING else android.media.session.PlaybackState.STATE_PAUSED,
                android.media.session.PlaybackState.PLAYBACK_POSITION_UNKNOWN,
                1f
            )
        /**
         * BUG THẬT đã sửa (xem chú thích đầy đủ, có trích dẫn tài liệu
         * chính thức, ở `onCustomAction()` phía trên): widget media control
         * MỚI của Android 13+ (đúng loại card tròn "Điện thoại này" người
         * dùng chụp) CHỈ lấp slot 4/5 (2 nút thêm ngoài play/pause/prev/
         * next) từ `PlaybackState.getCustomActions()` — một danh sách
         * HOÀN TOÀN RIÊNG, không liên quan gì tới `.setActions()` bitmask
         * ở trên (ACTION_FAST_FORWARD/ACTION_REWIND tuy có khai báo nhưng
         * KHÔNG BAO GIỜ được widget mới dùng để lấp 2 slot đó). Đây là
         * cách THẬT, đúng tài liệu, để 2 nút tua giây hiện ra trên widget
         * mới — dùng đúng `android.R.drawable.ic_media_rew`/`ic_media_ff`
         * làm icon, khớp icon đã dùng ở notification thường.
         */
        stateBuilder.addCustomAction(
            android.media.session.PlaybackState.CustomAction.Builder(
                CUSTOM_ACTION_REWIND, "Tua lùi", android.R.drawable.ic_media_rew
            ).build()
        )
        stateBuilder.addCustomAction(
            android.media.session.PlaybackState.CustomAction.Builder(
                CUSTOM_ACTION_FAST_FORWARD, "Tua tới", android.R.drawable.ic_media_ff
            ).build()
        )
        val state = stateBuilder.build()
        ms.setPlaybackState(state)
        nativeMediaPlaying = playing
        applyMediaMetadata()
        // BUG NGHI NGỜ (người dùng báo: sau khi thêm notification, tính năng
        // phát nhạc nền — vốn đã sửa được — LẠI HỎNG, quay về đúng triệu
        // chứng cũ: tắt ngay khi xuống nền). `postMediaNotification()` chạy
        // ĐỒNG BỘ ngay trong callback THẬT của Gecko
        // (`mediaSessionDelegate.onPlay/onPause`, xem session.mediaSessionDelegate
        // ở trên) — nếu nó ném lỗi mà KHÔNG được bắt, lỗi sẽ dội ngược lên
        // callback native của Gecko đang chạy, có thể làm rối/ngắt luôn xử lý
        // phía Gecko cho session đó. Trước đây (chưa có `postMediaNotification`)
        // callback này chỉ làm 2 việc đơn giản, không có gì để ném lỗi. Giờ bọc
        // `try/catch` để LOẠI TRỪ HẲN khả năng này — dù đúng hay không, đây là
        // rủi ro thật cần chặn trước, không phải suy đoán suông.
        try {
            handler.post {
                try {
                    postMediaNotification(playing)
                } catch (e: Exception) {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] postMediaNotification NÉM LỖI: ${e.javaClass.simpleName}: ${e.message}")
                }
            }
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] handler.post lỗi: ${e.message}")
        }
        /**
         * CẬP NHẬT (đảo ngược 1 phần thay đổi trước — thay đổi đó dựa trên

         * "nghi ngờ" chưa test kiểm chứng, không phải xác nhận thật):
         *
         * Đã tra lại tài liệu chính thức Android — `android.media.session.
         * MediaSession.isActive = true` KHÔNG PHẢI là thứ khiến hệ thống
         * "nhắm vào để tự tắt", mà NGƯỢC LẠI: đây là cách CHÍNH THỨC báo cho
         * Android biết "đây là 1 phiên phát media thật đang diễn ra" — thiếu
         * cờ này, hệ thống coi app như app thường (không có ngoại lệ nào cho
         * phát nhạc nền), dễ bị giới hạn nền (Doze/App Standby) hơn, không
         * phải ít hơn. Comment cũ ở trên chỉ là suy đoán ("nghi ngờ chính
         * xác dòng này") — CHƯA từng được xác nhận bằng test thật trước khi
         * xoá.
         *
         * Khôi phục lại `ms.isActive` (đặt `true` khi đang phát, `false` khi
         * dừng — không giữ `true` mãi kể cả lúc không phát, tránh giữ phiên
         * "sống" không cần thiết) để test lại với dữ liệu thật, thay vì suy
         * đoán tiếp không kiểm chứng.
         */
        ms.isActive = playing

        onMediaPlaybackStateListener?.invoke(playing)
    }

    // Helper cho tên file download sai (xem comment ở onExternalResponse).
    //
    // TỰ PHÊ BÌNH LẠI (người dùng chỉ ra đúng — bản trước đọc query param
    // "path=" của URL để đoán tên file là HARDCODE, không phải fix tổng
    // quát): bản đó chỉ hoạt động với URL có ĐÚNG hình dạng
    // `...?path=/mnt/.../TenFile.zip` — tức chỉ khớp riêng endpoint
    // `/wiggle/download-file` của claude.ai, đoán từ 1 tấm ảnh chụp màn
    // hình, KHÔNG PHẢI xác nhận qua log thật rằng Content-Disposition có bị
    // thiếu/sai hay không. Đây là vá theo hình dạng URL cụ thể, không phải
    // sửa đúng nguyên nhân gốc — nếu server khác trả tên file sai theo 1
    // hình dạng URL khác, patch này không giúp được gì.
    //
    // Sửa lại đúng hướng: CƠ CHẾ CHUẨN HTTP duy nhất đáng tin cậy cho MỌI
    // server là `Content-Disposition` — củng cố việc đọc header này cho
    // đúng chuẩn (RFC 6266/5987: hỗ trợ cả `filename=` lẫn `filename*=`,
    // ưu tiên `filename*=` vì có encoding đầy đủ hơn, giải mã URL-encode
    // đúng chuẩn thay vì giữ nguyên chuỗi thô). Bỏ hẳn heuristic "path="
    // dựa vào hình dạng URL — thay bằng LOG rõ ràng khi rơi vào fallback
    // URLUtil, để lần sau có bug tương tự sẽ có LOG THẬT (giá trị
    // Content-Disposition thô nhận được, nếu có) thay vì phải đoán mù qua
    // ảnh chụp màn hình.
    private fun extractFileNameFromResponse(uri: String, contentDisposition: String?, contentType: String?): String {
        if (!contentDisposition.isNullOrBlank()) {
            // Ưu tiên filename*= (RFC 5987, có thể có charset + URL-encode,
            // vd: filename*=UTF-8''B%C3%A1o%20c%C3%A1o.pdf) trước
            // filename= (ASCII fallback đơn giản) — theo đúng thứ tự ưu
            // tiên RFC 6266 khuyến nghị khi cả 2 cùng xuất hiện.
            val extendedMatch = Regex("""filename\*\s*=\s*([^;\r\n]+)""", RegexOption.IGNORE_CASE)
                .find(contentDisposition)
            if (extendedMatch != null) {
                val raw = extendedMatch.groupValues[1].trim().trim('"')
                // Dạng chuẩn: charset''percent-encoded-name, vd "UTF-8''a%20b.zip"
                val afterCharset = raw.substringAfter("''", raw)
                val decoded = try {
                    java.net.URLDecoder.decode(afterCharset, "UTF-8")
                } catch (e: Exception) {
                    afterCharset
                }
                if (decoded.isNotBlank()) return decoded
            }

            val simpleMatch = Regex("""filename\s*=\s*"?([^";\r\n]+)"?""", RegexOption.IGNORE_CASE)
                .find(contentDisposition)
            val simpleName = simpleMatch?.groupValues?.get(1)?.trim()?.trim('"')
            if (!simpleName.isNullOrBlank()) return simpleName
        }

        // Không đọc được tên file thật từ Content-Disposition — thử nguồn
        // (2): thuộc tính `download` mà content script bắt được ngay lúc
        // click (xem chú thích "TÍNH NĂNG MỚI" ở content.js — đây là NGUỒN
        // THỨ 2 mà trình duyệt thật Chrome/Firefox dùng, đã tra cứu xác
        // nhận qua nhiều nguồn, KHÔNG phải đoán theo hình dạng URL như bản
        // vá cũ đã bị chỉ ra là hardcode). Dọn hint hết hạn (TTL) trước khi
        // tra, tránh dùng nhầm hint cũ của 1 lượt click khác.
        val nowMs = System.currentTimeMillis()
        downloadFilenameHints.entries.removeIf { nowMs - it.value.second > DOWNLOAD_HINT_TTL_MS }
        val hint = downloadFilenameHints.remove(uri)
        if (hint != null) {
            DebugLog.log("extractFileNameFromResponse: dùng download_hint từ content script cho uri=$uri -> filename=${hint.first}")
            return hint.first
        }

        // Không đọc được tên file thật từ Content-Disposition, cũng không
        // có download_hint khớp URL — log NGUYÊN VĂN header (nếu có) để
        // lần sau xảy ra bug tương tự có dữ liệu thật để chẩn đoán, thay vì
        // phải đoán qua ảnh chụp màn hình như lần trước.
        DebugLog.log(
            "extractFileNameFromResponse: không tách được filename từ Content-Disposition " +
                "(giá trị thô nhận được = ${contentDisposition ?: "null/không có header"}), " +
                "fallback về URLUtil.guessFileName() cho uri=$uri"
        )
        return android.webkit.URLUtil.guessFileName(uri, contentDisposition, contentType)
    }

    // BUG THẬT liên quan (người dùng báo: Khe 0 đang phát nhạc, Khe 1 bắt
    // đầu phát tiếp thì bị "player spinner" treo mãi — ĐÃ KIỂM TRA: KHÔNG
    // PHẢI rò rỉ dữ liệu giữa 2 tiến trình, mỗi khe chạy GeckoRuntime +
    // profile hoàn toàn riêng, đã có CookieLeakDetector.kt xác nhận cách ly
    // đúng bằng test thật).
    //
    // TỰ SỬA LẠI (người dùng chất vấn đúng — bản trước viết "Gecko-native
    // tự ý xin AUDIOFOCUS_GAIN, ngoài tầm kiểm soát Kotlin" mà CHƯA hề tra
    // cứu xác nhận, chỉ là suy đoán): đã web_search và đọc trực tiếp
    // Bugzilla Mozilla #1545817 ("GeckoView never requests audio focus, so
    // YouTube plays over other audio apps") — bug này đã ĐÓNG WONTFIX với
    // kết luận rõ ràng từ chính GV team: "WONTFIX because the GV team says
    // this is an app bug" — tức là GeckoView KHÔNG HỀ tự request Audio
    // Focus, đây là trách nhiệm CỦA APP NHÚNG (đúng là code Kotlin này),
    // không phải nằm ở tầng native ngoài tầm với như đã viết sai trước đó.
    //
    // Điều này cũng làm SUY YẾU giả thuyết gốc: nếu GeckoView không tự xin
    // Audio Focus, thì hệ thống Android sẽ KHÔNG tự gửi LOSS/LOSS_TRANSIENT
    // cho Khe 0 khi Khe 1 phát — vì trước patch này, KHÔNG ai xin Focus cả,
    // nghĩa là tranh chấp Audio Focus có thể KHÔNG PHẢI nguyên nhân gốc
    // thật của "player spinner". Đã tìm thêm 1 báo cáo cùng triệu chứng ở
    // chính GitHub issue mozilla/geckoview#203 ("Play multiple videos... 
    // when a video starts playing the other is interrupted") — xảy ra
    // NGAY CẢ trong 1 tiến trình (2 GeckoView cùng activity), càng cho
    // thấy nguyên nhân nhiều khả năng nằm ở tranh chấp TÀI NGUYÊN PHẦN
    // CỨNG (audio HAL/AudioTrack, số phiên decoder đồng thời tối đa của
    // thiết bị) chứ không phải riêng Audio Focus ở tầng hệ điều hành.
    //
    // Patch dưới đây (tự request AudioFocusRequest ở tầng Kotlin) vẫn ĐÚNG
    // HƯỚNG theo đúng khuyến nghị chính thức của Mozilla (app phải tự làm
    // việc này, không phải Gecko) — nhưng KHÔNG CÒN CHẮC nó giải quyết
    // được triệu chứng spinner cụ thể đã gặp, vì nguyên nhân thật có thể
    // nằm ở tầng phần cứng/driver, ngoài tầm với của AudioManager Java API.
    // CẦN log "AudioFocus đổi" thật khi tái hiện lỗi để biết chắc — nếu
    // log không thấy LOSS/LOSS_TRANSIENT nào xảy ra đúng lúc Khe 1 phát,
    // xác nhận đúng giả thuyết mới (tranh chấp phần cứng, không phải Audio
    // Focus) và patch này sẽ KHÔNG giúp được gì, cần hướng khác hoàn toàn.
    private var audioFocusRequest: android.media.AudioFocusRequest? = null

    private fun requestNonExclusiveAudioFocus() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager ?: return
            val attrs = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val request = android.media.AudioFocusRequest.Builder(android.media.AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(false)
                .setWillPauseWhenDucked(false)
                .setOnAudioFocusChangeListener { focusChange ->
                    // CHỦ Ý bỏ qua LOSS/LOSS_TRANSIENT — chỉ log để chẩn
                    // đoán, không tự pause/dừng gì ở tầng Kotlin.
                    DebugLog.log("Khe $slotIndex: AudioFocus đổi = $focusChange (bỏ qua, không tự pause)")
                }
                .build()
            audioFocusRequest = request
            val result = am.requestAudioFocus(request)
            DebugLog.log(
                "Khe $slotIndex: requestAudioFocus() kết quả = $result " +
                    "(${if (result == android.media.AudioManager.AUDIOFOCUS_REQUEST_GRANTED) "GRANTED" else "FAILED/DELAYED"})"
            )
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: requestNonExclusiveAudioFocus() lỗi: ${e.message}")
        }
    }

    private fun tabIdFor(session: GeckoSession): String? =
        tabs.entries.firstOrNull { it.value === session }?.key

    // Extension eval_bridge đã đăng ký — lưu lại để gắn message delegate
    // CHO TỪNG SESSION khi tạo (xem attachEvalBridgeToSession bên dưới).
    private var evalBridgeExtension: WebExtension? = null

    private val evalBridgeContentDelegate = object : MessageDelegate {
        override fun onConnect(port: Port) {
            evalPorts.add(port)
            /**
             * BUG THẬT (tìm qua tự đối chiếu code với chính comment của nó):
             * comment ở `attachEvalBridgeToSession` phía trên tự nói "chỉ tin
             * khi build lại, log THẬT SỰ có dòng xác nhận connect" — nhưng
             * dòng log đó CHƯA TỪNG được viết ra ở đây. Hệ quả: log của
             * người dùng liên tục ghi "0 port đang mở" ở MỌI request, nhưng
             * không có cách nào phân biệt được 2 khả năng: (a) fix session-
             * delegate (dòng 2362) chưa từng chạy tới (APK cũ) hay (b) fix
             * ĐÃ chạy nhưng `onConnect` vẫn không được Gecko gọi vì lý do
             * khác. Thêm log để lần build tới trả lời dứt điểm câu hỏi này.
             */
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN eval_bridge] port CONNECT được (tabId=${port.sender?.session?.let { tabIdFor(it) } ?: "không xác định session"}, ẩn danh=${port.sender?.session?.let { s -> tabIdFor(s)?.let { id -> getTabs().any { it.id == id && it.isPrivate } } } ?: "?"}, tổng số port đang mở=${evalPorts.size})")
            // FIX HIỆU NĂNG: map port này thuộc tab nào ngay lúc connect —
            // dùng port.sender.session (API xác nhận thật qua javadoc chính
            // thức Mozilla, xem chú thích ở khai báo `portTabId`). Nếu
            // session null (lý thuyết là background script — không nên xảy
            // ra ở đây vì eval_bridge chỉ đăng ký content_scripts, không có
            // background script, nhưng vẫn phòng hờ) thì không map được,
            // evaluateJsForTab() sẽ tự fallback broadcast cho port này.
            val session = port.sender?.session
            if (session != null) {
                tabIdFor(session)?.let { tabId -> portTabId[port] = tabId }
            }
            port.setDelegate(object : PortDelegate {
                override fun onPortMessage(message: Any, port: Port) {
                    if (message is JSONObject) {
                        // Xem chú thích "TÍNH NĂNG MỚI" ở content.js — nhánh
                        // này xử lý message TỰ NGUYỆN báo tên file từ thuộc
                        // tính `download` trên <a>, KHÔNG phải trả lời cho
                        // lệnh eval nào (không có requestId để khớp).
                        if (message.optString("type", "") == "download_hint") {
                            val href = message.optString("href", "")
                            val filename = message.optString("filename", "")
                            if (href.isNotBlank() && filename.isNotBlank()) {
                                downloadFilenameHints[href] = filename to System.currentTimeMillis()
                                DebugLog.log("Khe $slotIndex: nhận download_hint từ content script — href=$href, filename=$filename")
                            }
                            return
                        }
                        if (message.optString("type", "") == "authwatch") {
                            DebugLog.log("Khe $slotIndex: [giám sát đăng nhập] ${message.optString("text", "")}")
                            return
                        }
                        val loginType = message.optString("type", "")
                        if (loginType == "colab_status") {
                            val tid = portTabId[port] ?: port.sender?.session?.let { tabIdFor(it) }
                            if (tid != null) { portTabId[port] = tid; handler.post { onColabStatusListener?.invoke(tid, message) } }
                            return
                        }
                        if (loginType == "amo_install") {
                            val slug = message.optString("slug", "")
                            if (slug.matches(Regex("[A-Za-z0-9_.@-]{1,120}"))) handler.post { onAmoInstallRequestListener?.invoke(slug) }
                            return
                        }
                        if (loginType.startsWith("login_")) {
                            handleLoginMessage(loginType, message, port)
                            return
                        }
                        val result = message.optString("result", null)
                        val requestId = message.optInt("requestId", -1)
                        val sourceUrl = message.optString("sourceUrl", "")
                        if (requestId >= 0) {
                            // .remove() thay vì chỉ đọc — đảm bảo callback CHỈ
                            // chạy 1 LẦN dù `all_frames:true` có thể khiến
                            // nhiều frame cùng phản hồi cho cùng 1 requestId
                            // (mỗi frame tự có port riêng, script chạy ở mọi
                            // frame nên có thể có nhiều phản hồi cho 1 yêu cầu).
                            val entry = evalCallbacks.remove(requestId)
                            if (entry != null) {
                                val (expectedTabId, cb) = entry
                                // BUG THẬT (xem chú thích đầy đủ ở content.js
                                // và khai báo evalCallbacks phía trên): khi
                                // fallback broadcast gửi lệnh tới MỌI tab,
                                // tab SAI có thể trả lời trước tab đích —
                                // đối chiếu sourceUrl (URL THẬT nơi script
                                // vừa chạy) với URL hiện tại của tab đích
                                // TRƯỚC khi tin kết quả. Chỉ so sánh host
                                // (không so cả URL đầy đủ) — đủ để phát hiện
                                // "trả lời từ tab hoàn toàn khác trang", vẫn
                                // chấp nhận nếu chỉ khác query/path do cùng
                                // trang đổi nhẹ giữa lúc gửi và lúc nhận.
                                val expectedHost = expectedTabId?.let { tabMeta[it]?.url }
                                    ?.let { try { java.net.URI(it).host } catch (e: Exception) { null } }
                                val actualHost = sourceUrl.takeIf { it.isNotBlank() }
                                    ?.let { try { java.net.URI(it).host } catch (e: Exception) { null } }
                                /**
                                 * BUG THẬT tìm thêm được (người dùng chụp ảnh
                                 * xác nhận: tab claude.ai hiện favicon Google
                                 * "G" dù cơ chế đối chiếu `sourceUrl` này đã
                                 * có sẵn): điều kiện gốc chỉ TỪ CHỐI khi CẢ
                                 * `expectedHost` LẪN `actualHost` đều xác định
                                 * được VÀ khác nhau — nghĩa là nếu `actualHost`
                                 * là `null` (content script ở tab kia không
                                 * gửi được `sourceUrl` hợp lệ — dễ xảy ra ở
                                 * trang có iframe/sandbox như luồng đăng nhập
                                 * Google, `location.href` có thể ném exception
                                 * hoặc rỗng trong ngữ cảnh đó), code CŨ rơi
                                 * thẳng vào nhánh `else` — TỰ ĐỘNG CHẤP NHẬN
                                 * kết quả, dù hoàn toàn không xác minh được nó
                                 * đến từ đúng tab hay không. Đây là thiết kế
                                 * "fail-open" (mặc định tin tưởng khi không
                                 * chắc) — SAI hướng cho 1 cơ chế an toàn.
                                 * Sửa thành "fail-closed": nếu ta CÓ
                                 * `expectedHost` (biết rõ tab đích là trang
                                 * nào) nhưng KHÔNG xác minh được `actualHost`
                                 * (không rõ phản hồi đến từ đâu), từ chối
                                 * luôn — thà bỏ lỡ 1 lượt favicon (sẽ tự thử
                                 * lại, xem `attempt < 3` ở MainActivity) còn
                                 * hơn gán nhầm favicon từ tab khác.
                                 */
                                val suspicious = expectedHost != null && (actualHost == null || expectedHost != actualHost)
                                if (suspicious) {
                                    DebugLog.log(
                                        "Khe $slotIndex: [CHẨN ĐOÁN cross-tab] BỎ kết quả eval vì sourceUrl khác tab đích hoặc không xác minh được " +
                                            "(mong đợi host=$expectedHost, thực nhận host=$actualHost, requestId=$requestId) " +
                                            "— khả năng broadcast fallback trả lời từ tab khác, không dùng kết quả sai này"
                                    )
                                    cb.invoke(null)
                                } else {
                                    cb.invoke(result)
                                }
                            }
                        }
                    }
                }

                override fun onDisconnect(port: Port) {
                    evalPorts.remove(port)
                    portTabId.remove(port)
                }
            })
        }
    }

    /**
     * BUG THẬT tìm ra (sau khi bị người dùng chất vấn đúng — trước đó lỡ ghi
     * "đã xác nhận" khi thật ra chưa từng thấy log "frame mới connect" nào cả):
     * đối chiếu với ví dụ CHÍNH THỨC của Mozilla (firefox-source-docs.mozilla.
     * org/mobile/android/geckoview/consumer/web-extensions.html) — để nhận
     * message từ CONTENT SCRIPT (không phải background script — `eval_bridge`
     * không hề có background script), phải gọi:
     *   `session.webExtensionController.setMessageDelegate(extension, delegate, "browser")`
     * — tức là gắn theo TỪNG SESSION (`GeckoSession.WebExtensionController`,
     * xác nhận có thật qua `WebExtension.SessionController.setMessageDelegate`
     * trong javadoc chính thức) — KHÔNG PHẢI `extension.setMessageDelegate(...)`
     * (gắn theo EXTENSION, chỉ dành cho message từ BACKGROUND SCRIPT).
     *
     * Code cũ dùng nhầm `ext.setMessageDelegate(...)` — đây CHÍNH XÁC là lý do
     * `ensureBuiltIn THÀNH CÔNG` nhưng KHÔNG BAO GIỜ thấy "frame mới connect":
     * content script gọi `connectNative()` gửi đi đúng, nhưng Kotlin lắng nghe
     * SAI kênh (kênh background-script, không ai gửi gì vào đó cả).
     */
    private fun attachEvalBridgeToSession(session: GeckoSession) {
        val ext = evalBridgeExtension ?: return
        try {
            session.webExtensionController.setMessageDelegate(ext, evalBridgeContentDelegate, "browser")
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] attachEvalBridgeToSession lỗi: ${e.message}")
        }
    }

    private fun setupEvalBridge() {
        // Mục 116: đăng ký bộ xác nhận cài addon (xem chú thích ở onAddonInstallPromptListener).
        try {
            runtime.webExtensionController.setPromptDelegate(object : WebExtensionController.PromptDelegate {
                override fun onInstallPromptRequest(
                    extension: WebExtension,
                    permissions: Array<String>,
                    origins: Array<String>,
                    dataCollectionPermissions: Array<String>
                ): GeckoResult<WebExtension.PermissionPromptResponse>? {
                    val result = GeckoResult<WebExtension.PermissionPromptResponse>()
                    val name = extension.metaData?.name ?: extension.id
                    DebugLog.log("Khe $slotIndex: [addon] Gecko xin xác nhận cài '$name' (quyền=${permissions.size}, miền=${origins.size})")
                    val restoreAllowPrivate = pendingRestoreAllowPrivate.remove(extension.id)
                    if (restoreAllowPrivate != null) {
                        result.complete(WebExtension.PermissionPromptResponse(true, restoreAllowPrivate, false))
                        return result
                    }
                    handler.post {
                        val l = onAddonInstallPromptListener
                        if (l == null) {
                            result.complete(WebExtension.PermissionPromptResponse(true, false, false))
                        } else {
                            l(name, permissions.toList() + origins.toList()) { allow, allowPrivate ->
                                lastPromptAllowPrivate = allowPrivate
                                result.complete(WebExtension.PermissionPromptResponse(allow, allowPrivate, false))
                            }
                        }
                    }
                    return result
                }
            })
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [addon] không đặt được PromptDelegate: ${e.message}")
        }
        val evalBridgeT0 = android.os.SystemClock.uptimeMillis()
        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] setupEvalBridge() bắt đầu — gọi ensureBuiltIn cho eval_bridge")
        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/eval_bridge/",
            "eval-bridge"
        ).accept({ ext ->
            if (ext == null) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] ensureBuiltIn TRẢ VỀ NULL — eval_bridge KHÔNG được đăng ký")
                return@accept
            }
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] ensureBuiltIn THÀNH CÔNG — eval_bridge đã đăng ký (sau ${android.os.SystemClock.uptimeMillis() - evalBridgeT0}ms kể từ setupEvalBridge)")
            // Mục 111: GeckoView KHÔNG chạy content script của extension trong tab ẩn danh trừ khi extension được cho phép
            // rõ ràng (`setAllowedInPrivateBrowsing`). Chưa từng gọi => trong tab ẩn danh cầu nối này (điền mật khẩu, evaluateJs,
            // theo dõi trang...) hoàn toàn không chạy. Cho phép xong mới gắn vào các session.
            fun finishSetup(e: WebExtension) {
                evalBridgeExtension = e
                // Gắn cho MỌI session đã tồn tại từ trước (vì ensureBuiltIn chạy
                // bất đồng bộ — có thể các tab/session đã được tạo xong TRƯỚC
                // khi extension đăng ký xong).
                tabs.values.forEach { attachEvalBridgeToSession(it) }
            }
            try {
                runtime.webExtensionController.setAllowedInPrivateBrowsing(ext, true).accept({ updated ->
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN ẩn danh] eval_bridge ĐÃ được cho phép chạy trong tab ẩn danh")
                    finishSetup(updated ?: ext)
                }, { t ->
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN ẩn danh] setAllowedInPrivateBrowsing LỖI: ${t?.message} — tab ẩn danh có thể không điền được mật khẩu")
                    finishSetup(ext)
                })
            } catch (e: Throwable) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN ẩn danh] không gọi được setAllowedInPrivateBrowsing: ${e.message}")
                finishSetup(ext)
            }
        }, { throwable ->
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN nhạc nền] ensureBuiltIn LỖI: ${throwable?.message}")
        })
    }

    // Extension fingerprint-spoof đã đăng ký — lưu lại để gắn delegate CHO
    // TỪNG SESSION (giống hệt eval_bridge, xem attachEvalBridgeToSession).
    private var fingerprintExtension: WebExtension? = null
    // Port đang mở của TỪNG session — cần để có thể ĐẨY config MỚI theo
    // yêu cầu (VD khi bật/tắt "Xem bằng máy tính" — xem toggleDesktopMode())
    // mà không phải đợi trang tự reload rồi content script tự hỏi lại.
    private val fingerprintPortsBySession = ConcurrentHashMap<GeckoSession, Port>()

    private fun attachFingerprintExtensionToSession(session: GeckoSession) {
        val ext = fingerprintExtension ?: return
        try {
            session.webExtensionController.setMessageDelegate(ext, object : MessageDelegate {
                override fun onConnect(port: Port) {
                    fingerprintPortsBySession[session] = port
                    // Log ĐÚNG như comment ở trên đã tự đề ra làm tiêu chuẩn
                    // xác nhận ("chỉ tin khi... log THẬT SỰ có dòng...") —
                    // trước đây thiếu dòng này nên không ai biết fix
                    // session-delegate có thật sự làm port connect được hay
                    // không, dù comment đã viết sẵn kỳ vọng.
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN fingerprint] fingerprint-spoof content script CONNECT được")
                    // Mục 139: content script tự đọc lại giá trị TRANG THẤY (qua wrappedJSObject) rồi gửi về đây — bằng chứng thật rằng giả mạo có hiệu lực.
                    port.setDelegate(object : PortDelegate {
                        override fun onPortMessage(message: Any, port: Port) {
                            if (message !is JSONObject) return
                            val act = message.optString("action", "")
                            if (act == "ipProbe") { onTabIpProbe(session, message); return }
                            if (act != "selftest") return
                            if (fpSelfTestCount.incrementAndGet() > 120) return // giới hạn log mỗi tiến trình
                            DebugLog.log("Khe $slotIndex: [fp-selftest] " + message.optString("text", ""))
                        }
                    })
                    port.postMessage(buildFingerprintConfigMessage(session))
                    if (tabs[activeTabId] === session) handler.postDelayed({ probeEgressViaTab() }, 2500)
                }
            }, "browser")
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN fingerprint] attachFingerprintExtensionToSession lỗi: ${e.message}")
        }
    }

    /**
     * BUG THẬT (cùng loại đã tìm ra và sửa cho eval_bridge, mục 8zq
     * PROJECT_STATUS.md — người dùng hỏi 1 câu về toggleDesktopMode mà lộ
     * ra bug NGHIÊM TRỌNG HƠN cả câu hỏi gốc): `fingerprint-spoof` không có
     * background script, nhưng code CŨ dùng `ext.setMessageDelegate(...)` —
     * kênh CHỈ dành cho background script. Content script gọi
     * `connectNative()` gửi đúng, nhưng Kotlin lắng nghe SAI kênh — rất có
     * khả năng TOÀN BỘ tính năng giả mạo vân tay (`navigator.platform`,
     * `maxTouchPoints`, WebGL, canvas, audio, font, timezone...) CHƯA TỪNG
     * hoạt động thật từ đầu, vì `config.enabled` mặc định `false` trong
     * content.js, chỉ được bật khi nhận được message từ Kotlin — mà message
     * đó chưa bao giờ tới nơi.
     *
     * Cũng bổ sung permission `nativeMessaging`/`nativeMessagingFromContent`/
     * `geckoViewAddons` còn thiếu trong manifest.json (so với `eval_bridge`
     * đã xác nhận hoạt động, có đủ 3 quyền này).
     *
     * CHƯA đánh dấu "đã xác nhận" — theo đúng kỷ luật đã rút ra (mục 8zp):
     * chỉ tin khi build lại, log THẬT SỰ có dòng
     * "[CHẨN ĐOÁN fingerprint] fingerprint-spoof content script CONNECT được".
     */
    private fun setupFingerprintExtension() {
        // 7.56: thay vì XOÁ RTCPeerConnection khỏi trang (dấu hiệu bot), chặn rò IP LAN/IP thật ở tầng Gecko: chỉ dùng đường mặc định, không lộ ứng viên "host".
        try {
            GeckoPreferenceController.setGeckoPref("media.peerconnection.ice.default_address_only", true, GeckoPreferenceController.PREF_BRANCH_USER)
            GeckoPreferenceController.setGeckoPref("media.peerconnection.ice.no_host", true, GeckoPreferenceController.PREF_BRANCH_USER)
        } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: đặt pref WebRTC lỗi ${e.javaClass.simpleName}: ${e.message}") }

        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/fingerprint_spoof/",
            "fingerprint-spoof"
        ).accept(
            { ext ->
                if (ext == null) {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN fingerprint] ensureBuiltIn TRẢ VỀ NULL")
                    return@accept
                }
                fingerprintExtension = ext
                installAddonManagerDelegate()
                FingerprintSettingsBus.listener = { handler.post { try { pushFingerprintConfigToAll() } catch (e: Throwable) {} } }
                tabs.values.forEach { attachFingerprintExtensionToSession(it) }
                DebugLog.log("Fingerprint spoof extension loaded for slot $slotIndex")
                try { ensureCookieHelper() } catch (e: Throwable) { DebugLog.log("Khe $slotIndex: [geo] không khởi động được cookie_helper: ${e.message}") } // Mục 140
            },
            { error -> DebugLog.log("Slot $slotIndex: không đăng ký được fingerprint extension — $error") }
        )
    }

    /**
     * Đẩy lại config MỚI cho content script đang kết nối (nếu có) — dùng khi
     * cần đồng bộ ngay lập tức, không đợi trang tự reload (VD từ
     * `toggleDesktopMode()` — xem sửa đổi ở đó: khi bật desktop mode, TẮT
     * hẳn phần giả platform/touch/webgl thay vì để lộ tổ hợp UA-thật +
     * platform-giả-mobile bất nhất).
     */
    /** Mục 149: đổi bất kỳ công tắc fingerprint nào -> đẩy cấu hình MỚI xuống mọi tab đang mở để content script cập nhật cache áp-sớm NGAY
     *  (trước đây cache chỉ đổi ở lần tải trang kế => công tắc có hiệu lực chậm một nhịp, trông như "loạng xạ"). Trang đang mở vẫn cần tải lại. */
    fun pushFingerprintConfigToAll() {
        for (session in fingerprintPortsBySession.keys.toList()) pushFingerprintConfig(session)
        DebugLog.log("Khe $slotIndex: [fingerprint] đã đẩy cấu hình mới tới ${fingerprintPortsBySession.size} tab đang mở (công tắc vừa đổi)")
    }

    private fun pushFingerprintConfig(session: GeckoSession) {
        val port = fingerprintPortsBySession[session] ?: return
        try {
            port.postMessage(buildFingerprintConfigMessage(session))
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN fingerprint] pushFingerprintConfig lỗi: ${e.message}")
        }
    }

    /**
     * Đọc lựa chọn thật của người dùng (FingerprintSpoofFeature settings) và
     * build message config gửi cho content.js. 1 công tắc chính (fp_enabled)
     * bật/tắt TOÀN BỘ bộ giả lập (hardware+locale+canvas+audio+font+webrtc) —
     * chưa có UI bật/tắt riêng lẻ từng kỹ thuật.
     *
     * CẬP NHẬT (trả lời câu hỏi người dùng về `toggleDesktopMode()` +
     * fingerprint): khi session đang bật "Xem bằng máy tính"
     * (`userAgentMode == USER_AGENT_MODE_DESKTOP`, và tên miền KHÔNG nằm
     * trong danh sách ngoại lệ mobile-layout — xem `applyViewportExceptionForUrl`),
     * `userAgentOverride` đã bị xoá (dùng UA desktop THẬT của GeckoView,
     * xem `toggleDesktopMode()`). Nếu vẫn gửi `platform`/`maxTouchPoints`/
     * WebGL... theo hồ sơ CŨ (có thể là mobile) → tạo ra tổ hợp UA-thật-
     * desktop + platform-giả-mobile — BẤT NHẤT NẶNG, dễ bị soi hơn hẳn so
     * với không giả gì cả. Sửa: khi phát hiện đang ở chế độ desktop-mode-
     * toggle, TẮT hẳn phần `hardware` (để trình duyệt trả về giá trị THẬT
     * của chính điện thoại) — thà lộ đúng 1 thiết bị thật còn hơn lộ 1 tổ
     * hợp giả-thật lẫn lộn không tồn tại trên đời thực.
     */
    private fun buildFingerprintConfigMessage(session: GeckoSession? = null): JSONObject {
        val enabled = FingerprintSpoofFeature.isEnabled(context, slotIndex)
        val desktopModeToggledOn = session?.settings?.userAgentMode == GeckoSessionSettings.USER_AGENT_MODE_DESKTOP &&
            (session?.settings?.userAgentOverride == null || (session != null && (tabIdFor(session)?.let { manualDesktopTabIds.contains(it) } == true)))
        // Mục 141: tab người dùng chủ động tắt "máy tính" khi hồ sơ là desktop => UA thật là di động, nên KHÔNG giả platform/màn hình/GPU desktop (sẽ lệch với UA).
        val manualMobile = session != null && (tabIdFor(session)?.let { manualMobileTabIds.contains(it) } == true) &&
            (try { resolveProfile().first.category == "desktop" } catch (e: Exception) { false })
        val config = JSONObject().put("enabled", enabled)
        if (enabled) {
            val zoneIdForCfg = session?.let { sess -> tabIdFor(sess)?.let { tabMeta[it]?.zoneId } } ?: ""
            val zoneForCfg = if (zoneIdForCfg.isNotBlank()) IncognitoZones.get(context, slotIndex, zoneIdForCfg) else null
            val (hw, locale) = resolveProfileForZone(zoneIdForCfg)
            if (!fpSignatureLogged) {
                fpSignatureLogged = true
                // Chữ ký dấu vân tay mỗi lần mở khe (mục 102): so sánh giữa các lần mở/import để biết nó có TRÔI không.
                // Không ghi seed thô, chỉ 4 byte băm.
                val fresh = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
                val seedStr = AppPrefs.getString(context, slotIndex, "fp_noise_seed", "")
                val seedTag = if (seedStr.isEmpty()) "KHÔNG CÓ" else
                    java.security.MessageDigest.getInstance("SHA-256").digest(seedStr.toByteArray()).take(4).joinToString("") { "%02x".format(it) }
                val uaTag = java.security.MessageDigest.getInstance("SHA-256").digest(hw.userAgent.toByteArray()).take(4).joinToString("") { "%02x".format(it) }
                DebugLog.log("Khe $slotIndex: [CHỮ KÝ FINGERPRINT] fp_fresh=$fresh (true = ĐỔI NGẪU NHIÊN mỗi lần mở) hw='${hw.name}' locale='${locale.name}' tz=${locale.timezone} ua#$uaTag seed#$seedTag")
            }
            config.put("hardware", !desktopModeToggledOn && !manualMobile)
            // Mục 140: mặc định TỰ KHỚP IP đang đi ra (VPN nào cũng được): có geo => múi giờ/ngôn ngữ theo IP; chưa có geo => KHÔNG giả (giữ giá trị thật, khớp IP thật).
            // Tắt "tự khớp" => dùng Locale Profile cố định (công tắc fp_t_locale).
            val localeAuto = geoAutoEnabled()
            // Bản 7.69: (1) ngôn ngữ/múi giờ RIÊNG của vùng (người dùng chọn tay) được ƯU TIÊN trên tự khớp IP — trước đây bị bỏ qua khi bật tự khớp IP;
            // (2) tab nhận geo của ĐÚNG LỚP đường mạng của nó (thường / ẩn danh).
            val zoneLocaleExplicit = zoneForCfg != null && zoneForCfg.localeIdx >= 0
            val cfgPrivate = session != null && sessionIsPrivate(session)
            val geoNow = if (zoneLocaleExplicit) null else geoForClass(cfgPrivate)
            config.put("spoofLocale", if (zoneLocaleExplicit) true else if (localeAuto) geoNow != null else AppPrefs.getBoolean(context, slotIndex, "fp_t_locale", true))
            config.put("canvas", AppPrefs.getBoolean(context, slotIndex, "fp_t_canvas", true))
            config.put("audio", AppPrefs.getBoolean(context, slotIndex, "fp_t_audio", true))
            config.put("font", AppPrefs.getBoolean(context, slotIndex, "fp_t_font", true))
            config.put("webrtc", AppPrefs.getBoolean(context, slotIndex, "fp_t_webrtc", false)) // 7.56: MẶC ĐỊNH TẮT — xoá RTCPeerConnection là dấu hiệu bot của captcha (không có trên Firefox thật)
            config.put("uaSync", !desktopModeToggledOn && !manualMobile)
            config.put("platform", hw.platform)
            config.put("hardwareConcurrency", hw.hardwareConcurrency)
            config.put("deviceMemory", hw.deviceMemory)
            config.put("maxTouchPoints", hw.maxTouchPoints)
            config.put("screenSpoof", hw.category == "desktop") // 7.56: hồ sơ di động dùng màn hình/DPR thật của máy (khai px thiết bị + dpr lệch innerWidth)
            config.put("screenWidth", hw.screenWidth)
            config.put("screenHeight", hw.screenHeight)
            config.put("colorDepth", hw.colorDepth)
            config.put("pixelRatio", hw.pixelRatio)
            config.put("webglVendor", hw.webglVendor)
            config.put("webglRenderer", hw.webglRenderer)
            config.put("userAgent", hw.userAgent)
            config.put("workerWrap", AppPrefs.getBoolean(context, slotIndex, "fp_worker_wrap", false)) // Mục 146: MẶC ĐỊNH TẮT (bọc Worker bằng Blob có thể làm hỏng worker của trang)
            config.put("mainWorld", AppPrefs.getBoolean(context, slotIndex, "fp_t_mainworld", false)) // Mục 147: MẶC ĐỊNH TẮT cho tới khi kiểm chứng trên máy (bản MAIN world: Date/Intl/Temporal)
            // Mục 149: trang KHÔNG áp dụng fingerprint — mặc định RỖNG (mặc định "claude.ai" của 147 gây nhầm lẫn khi import/thiếu pref)
            run {
                val arr = org.json.JSONArray()
                AppPrefs.getString(context, slotIndex, "fp_skip_hosts", "").split(',', ';', ' ', '\n')
                    .map { it.trim().lowercase() }.filter { it.matches(Regex("[a-z0-9.-]+")) }.distinct().forEach { arr.put(it) }
                config.put("skipHosts", arr)
            }
            config.put("timezone", if (localeAuto && geoNow != null) geoNow.tz else locale.timezone)
            config.put("language", if (localeAuto && geoNow != null) geoNow.lang else locale.language)
            config.put("locale", if (localeAuto && geoNow != null) geoNow.lang else locale.locale)
            config.put("languages", JSONArray(if (localeAuto && geoNow != null) geoNow.langs else locale.languages))
            // BUG THẬT người dùng chỉ ra ĐÚNG (bản vá trước của tôi CHƯA
            // hoàn chỉnh — chỉ seed ổn định TRONG 1 lần tải trang, KHÔNG
            // cố định theo hồ sơ như mọi giá trị hardware/locale khác ở
            // trên đã làm đúng từ trước): mỗi lần tải trang MỚI (kể cả
            // cùng 1 hồ sơ, chỉ cách nhau vài giây), seed random cũ tự sinh
            // lại từ `Date.now()` — khác hoàn toàn lần trước, nghĩa là
            // NHIỄU CANVAS/AUDIO/WEBGL ĐỔI KHÁC NHAU MỖI LẦN ĐĂNG NHẬP, dù
            // hardware/locale/UA vẫn giữ nguyên. Đây CHÍNH XÁC là điều
            // người dùng phản ánh và đúng là tôi làm nửa vời — hệ thống
            // chống gian lận chỉ cần thấy TOÀN BỘ fingerprint (bao gồm
            // canvas/audio) ổn định qua nhiều lần ghé thăm mới coi là 1
            // thiết bị thật, không chỉ ổn định trong 1 trang.
            //
            // Sửa ĐÚNG: seed nhiễu giờ lấy từ `getOrCreateNoiseSeedForSlot()`
            // — sinh 1 LẦN DUY NHẤT cho hồ sơ này, LƯU LẠI qua AppPrefs
            // (đúng namespace theo slot, sống sót qua app restart/nhiều
            // ngày, y hệt cách `resolveProfile()` đã làm cho hardware/
            // locale) — không tự sinh lại theo `Date.now()` mỗi lần tải
            // trang nữa.
            config.put("noiseSeed", zoneForCfg?.seed ?: getOrCreateNoiseSeedForSlot()) // Mục 167: vùng ẩn danh có hạt giống riêng
        }
        return JSONObject().put("config", config)
    }

    /**
     * Seed nhiễu fingerprint (canvas/audio/WebGL/timing) — sinh 1 lần duy
     * nhất cho MỖI HỒ SƠ (namespace theo slot, qua AppPrefs — cùng cơ chế
     * độ bền dữ liệu mà `resolveProfile()` đã dùng cho hardware profile),
     * KHÔNG sinh lại mỗi lần tải trang. Xem chú thích ở
     * `buildFingerprintConfigMessage()`.
     */
    private fun getOrCreateNoiseSeedForSlot(): Long {
        // Nhất quán với công tắc "Đổi mới mỗi lần mở" (fp_fresh, xem
        // FingerprintSpoofFeature.kt) — nếu người dùng CHỦ Ý bật fresh mode
        // (muốn TOÀN BỘ danh tính, kể cả hardware/locale, đổi mới mỗi lần
        // mở app), seed nhiễu canvas/audio/WebGL cũng PHẢI đổi theo, không
        // được giữ cố định — nếu không sẽ mâu thuẫn nửa vời: hardware đổi
        // mới nhưng nhiễu vẫn y hệt lần trước, tự nó cũng là 1 tín hiệu bất
        // nhất đáng ngờ không kém. Khi fresh=false (mặc định), hành vi giữ
        // nguyên như đã sửa — seed cố định bền theo hồ sơ.
        val fresh = AppPrefs.getBoolean(context, slotIndex, "fp_fresh", false)
        if (!fresh) {
            val existing = AppPrefs.getString(context, slotIndex, "fp_noise_seed", "")
            existing.toLongOrNull()?.let { return it }
        }
        // Mục 143: seed mặc định XÁC ĐỊNH theo TÊN HỒ SƠ (giống hw/locale đã mặc định theo tên): cài lại app / import backup thiếu `fp_noise_seed`
        // vẫn ra ĐÚNG dấu vân tay canvas/audio/WebGL cũ. Trước đây sinh ngẫu nhiên => mỗi lần import là một "thiết bị mới" với Google (log 23:38).
        val newSeed = if (fresh) (System.currentTimeMillis() xor (Math.random() * Long.MAX_VALUE).toLong())
        else {
            val name = try { ProfileSlots.getSlotAssignment(context, slotIndex) } catch (e: Throwable) { "slot$slotIndex" }
            FingerprintIdentity.defaultSeedFor(name)
        }
        if (!fresh) {
            AppPrefs.setString(context, slotIndex, "fp_noise_seed", newSeed.toString())
        }
        return newSeed
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        if (result == null) {
            result = uri.path?.let { File(it).name }
        }
        return result
    }

    /**
     * Gọi từ MainActivity sau khi Activity chọn file (ACTION_OPEN_DOCUMENT)
     * trả về kết quả — hoàn thành GeckoResult đang treo từ onFilePrompt() để
     * trang web THẬT SỰ nhận được file qua <input type="file"> (khác hẳn
     * cách cũ dispatch 1 CustomEvent tự chế mà trang bình thường không nghe).
     */
    fun resolveFilePrompt(context: Context, uri: Uri?) {
        val prompt = pendingFilePrompt
        val result = pendingFilePromptResult
        pendingFilePrompt = null
        pendingFilePromptResult = null
        if (prompt == null || result == null) {
            // CHẨN ĐOÁN: nếu dòng này xuất hiện, nghĩa là lúc gọi
            // resolveFilePrompt() thì KHÔNG CÒN prompt nào đang chờ — có
            // thể do: (a) đã resolve rồi (gọi 2 lần), hoặc (b) 1
            // onFilePrompt MỚI đã ghi đè pendingFilePrompt trước khi lượt
            // cũ kịp resolve (2 lần chọn file liên tiếp, lượt đầu chưa xong
            // copy nền thì lượt 2 đã bắt đầu) — nếu đúng vậy thì lượt ĐẦU sẽ
            // luôn "biến mất" không dấu vết, đúng như người dùng mô tả.
            DebugLog.log("resolveFilePrompt: KHÔNG CÒN prompt đang chờ (đã resolve rồi, hoặc bị 1 onFilePrompt mới ghi đè trước khi resolve) — bỏ qua, uri=$uri")
            return
        }
        val response = if (uri != null) prompt.confirm(context, uri) else prompt.dismiss()
        result.complete(response)
        if (uri != null) noteFileHandedToPage() // Mục 158
        DebugLog.log("resolveFilePrompt: đã ${if (uri != null) "confirm" else "dismiss"} prompt thành công")
    }

    /**
     * FIX BUG THẬT (đúng người dùng báo — xem chú thích lớn ở
     * `onFilePromptListener`): dùng đúng overload `FilePrompt.confirm(Context,
     * Uri[])` — XÁC NHẬN CÓ THẬT qua tài liệu chính thức GeckoView Javadoc
     * ("Confirms the prompt and passes the file URIs back to content") —
     * để trả về NHIỀU file cùng lúc cho trang web, thay vì luôn chỉ gọi
     * overload 1-Uri (`confirm(Context, Uri)`) khiến trang chỉ NHẬN ĐƯỢC
     * ĐÚNG 1 FILE dù người dùng đã chọn/kéo-thả nhiều file.
     */
    fun resolveFilePromptMultiple(context: Context, uris: Array<Uri>?) {
        val prompt = pendingFilePrompt
        val result = pendingFilePromptResult
        pendingFilePrompt = null
        pendingFilePromptResult = null
        if (prompt == null || result == null) {
            DebugLog.log("resolveFilePromptMultiple: KHÔNG CÒN prompt đang chờ — bỏ qua, uris=${uris?.size}")
            return
        }
        val response = if (uris != null && uris.isNotEmpty()) prompt.confirm(context, uris) else prompt.dismiss()
        result.complete(response)
        if (uris != null && uris.isNotEmpty()) noteFileHandedToPage() // Mục 158
        DebugLog.log("resolveFilePromptMultiple: đã ${if (uris != null && uris.isNotEmpty()) "confirm (${uris.size} file)" else "dismiss"} prompt thành công")
    }

    fun release() {
        stopAutoBehavior()
        handler.removeCallbacksAndMessages(null) // giữ hành vi cũ khi ĐÓNG khe: dọn sạch mọi callback còn treo
        tabs.values.forEach { it.close() }
        tabs.clear()
        tabMeta.clear()
        // Dọn dẹp nativeMediaSession và mediaActionReceiver khi khe đóng.
        // Quan trọng: nếu không release, nativeMediaSession vẫn "sống" trong
        // hệ thống MediaSession của Android, nhưng nativeMediaSession.controller
        // trỏ về object đã bị GC — bấm nút từ widget màn hình khoá sau khi
        // app restart sẽ gọi callback vào nativeMediaSession cũ (null hoặc
        // instance cũ trong process mới), không có tác dụng. Release đúng lúc
        // shutdown đảm bảo lần khởi động tiếp theo, ensureNativeMediaSession()
        // tạo instance mới sạch và isActive được set đúng khi có media event.
        try {
            nativeMediaSession?.isActive = false
            nativeMediaSession?.release()
        } catch (e: Exception) {
            DebugLog.log("Khe $slotIndex: release() — nativeMediaSession.release() lỗi: ${e.message}")
        }
        nativeMediaSession = null
        currentGeckoMediaSession = null
        currentGeckoMediaSessionTabId = null
        if (mediaActionReceiverRegistered) {
            try { context.unregisterReceiver(mediaActionReceiver) } catch (_: Exception) {}
            mediaActionReceiverRegistered = false
        }
        // Xoá notification media còn sót (nếu khe bị đóng khi đang tạm dừng —
        // lúc đó MediaKeepAliveService không chạy nhưng notification vẫn còn qua nm.notify).
        try {
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            nm.cancel(2000 + slotIndex)
        } catch (_: Exception) {}
        // FIX BUG THẬT (xem giải thích đầy đủ ở `rebindView()`/`hasLiveTabs()`
        // phía dưới) — release() nghĩa là khe ĐÓNG HẲN THẬT SỰ (người dùng
        // chủ động đóng, hoặc gán lại profile), nên PHẢI gỡ khỏi registry
        // `instances`. Thiếu dòng này, lần mở khe MỚI (thật sự mới, không
        // phải Activity bị Android tự huỷ+tạo lại) sẽ tìm thấy 1 entry CŨ đã
        // `release()` (tabs/sessions đã đóng hết) trong `forSlot()`, tưởng
        // nhầm là "engine đang sống" rồi cố gắn vào — hỏng hoàn toàn.
        instances.remove(slotIndex)
    }

    /**
     * FIX BUG THẬT NGHIÊM TRỌNG (người dùng báo: chuyển sang app khác/vào
     * Cài đặt lấy log, quay lại thì TOÀN BỘ tab bị tải lại từ đầu — kể cả
     * tab vừa bật chế độ máy tính cũng mất luôn trạng thái đó). Nguyên nhân
     * THẬT (đọc code xác nhận, không đoán): `MainActivity.setupEngine()`
     * trước đây LUÔN gọi `GeckoViewEngine(this, geckoView, slotIndex)` —
     * tạo hẳn 1 instance MỚI, map `tabs`/`tabMeta` RỖNG — mỗi khi
     * `onCreate()` chạy lại. Trong khi đó `GeckoRuntimeProvider` (runtime
     * Gecko thật) CÓ cache theo tiến trình (`runtimes` map), sống sót qua
     * việc Activity bị Android tự thu hồi rồi tạo lại (rất hay gặp — xem
     * `onDestroy()` log "isFinishing=false (Android tự thu hồi Activity
     * nền)") — CHỈ RIÊNG lớp `GeckoViewEngine` (nơi giữ danh sách tab/
     * session THẬT đang chạy) là KHÔNG được tái sử dụng, bị bỏ rơi (leak)
     * rồi Activity mới lại tự đi phục hồi tab từ file JSON đã lưu — y hệt
     * như vừa khởi động lại thật, mất mọi trạng thái CHỈ SỐNG TRONG RAM (vd
     * cờ "chế độ máy tính THỦ CÔNG" của 1 tab, `manualDesktopTabIds`).
     *
     * Sửa: `rebindView()` được gọi từ `MainActivity.setupEngine()` khi tìm
     * thấy 1 instance CÒN SỐNG qua `forSlot()` (registry vốn đã có sẵn từ
     * trước, dùng cho `FingerprintSpoofFeature` — chỉ là chưa ai tận dụng
     * nó để TÁI SỬ DỤNG thay vì tạo mới) — trỏ lại field `geckoView` sang
     * `GeckoView` widget MỚI (widget cũ đã chết cùng Activity cũ), rồi gắn
     * lại đúng session đang active vào widget mới này
     * (`newView.setSession(...)`) — y hệt bước "rebind" đã dùng ở
     * `recoverKilledOrCrashedSession()` cho trường hợp onKill/onCrash, cùng
     * 1 bản chất vấn đề (View mới, Session cũ vẫn sống, cần nối lại).
     */
    fun rebindView(newView: GeckoView) {
        geckoView = newView
        val activeSession = activeTabId?.let { tabs[it] }
        if (activeSession != null) {
            activeSession.setActive(true)
            geckoView.setSession(activeSession)
            DebugLog.log("Khe $slotIndex: rebindView() — đã gắn lại session của tab đang active vào GeckoView mới, KHÔNG tải lại gì cả")
        } else {
            DebugLog.log("Khe $slotIndex: rebindView() — không có activeTabId/session nào để gắn (bất thường, kiểm tra thêm nếu thấy màn hình trắng)")
        }
    }

    /** Có tab nào đang sống trong RAM hay không — dùng ở `MainActivity.
     * onCreate()` để quyết định có cần restoreTabsIfAny()/tạo tab trang chủ
     * hay không khi vừa rebind vào 1 engine cũ (đã có sẵn tab, không cần
     * làm gì thêm). */
    fun hasLiveTabs(): Boolean = tabs.isNotEmpty()

    /**
     * Cấu hình proxy cho slot này qua eval bridge.
     * Đồng thời setup DNS over HTTPS + timezone.
     */
    /**
     * Proxy riêng theo khe THỰC SỰ được áp dụng — nhưng KHÔNG phải ở đây.
     * Việc đăng ký thật xảy ra tự động trong `GeckoRuntimeProvider.createRuntime()`
     * (đọc proxy_host/proxy_port/... từ AppPrefs, đăng ký WebExtension
     * `proxy_config` dùng browser.proxy.onRequest) ngay khi runtime của khe
     * được tạo lần đầu trong tiến trình.
     *
     * Hàm này chỉ còn tác dụng NHẮC người dùng khởi động lại khe để áp dụng
     * thay đổi vừa lưu — GeckoRuntime của khe đã tồn tại trong tiến trình
     * hiện tại thì không thể đăng ký lại extension với cấu hình mới cho tới
     * khi tiến trình khởi động lại (đóng khe rồi mở lại).
     */
    fun setupProxy(host: String, port: Int, user: String = "", pass: String = "") {
        DebugLog.log(
            "Proxy $host:$port đã lưu cho khe $slotIndex — cần KHỞI ĐỘNG LẠI khe " +
                "(đóng rồi mở lại) để GeckoRuntimeProvider đăng ký WebExtension proxy_config mới."
        )
    }

    fun clearProxy() {
        DebugLog.log("Đã xoá cấu hình proxy cho khe $slotIndex — cần khởi động lại khe để áp dụng.")
    }
}
