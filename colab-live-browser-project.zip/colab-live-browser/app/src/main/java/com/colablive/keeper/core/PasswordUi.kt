package com.colablive.keeper.core

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.InputType
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

/**
 * Giao diện hỏi/hiện mật khẩu đã lưu (mục 105/106): hộp thoại "Lưu mật khẩu?", chọn tài khoản khi trang có nhiều tài khoản,
 * mở khoá bằng mật khẩu chủ, và màn hình quản lý (xem / sao chép / xoá / thêm tay / bật-tắt / mật khẩu chủ).
 * Toàn bộ chạy trên luồng UI của Activity; việc tính khoá (PBKDF2) chạy ở luồng nền để không gây ANR.
 */
class PasswordUi(
    private val activity: Activity,
    private val slotIndex: Int
) : GeckoViewEngine.LoginEventListener {

    private var savePromptShowing = false
    private var pendingSave: (() -> Unit)? = null
    private var unlockShowing = false
    private var unlockSuppressedUntil = 0L

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
    private fun alive() = !activity.isFinishing && !activity.isDestroyed

    private fun mask(p: String) = "•".repeat(minOf(p.length, 12))
    private fun hostOf(origin: String) = origin.substringAfter("://")

    private fun field(hint: String, type: Int, text: String = "") = EditText(activity).apply {
        this.hint = hint
        inputType = type
        setText(text)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
    private val pwType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

    private fun column(vararg views: android.view.View) = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(8), dp(20), 0)
        views.forEach { addView(it) }
    }

    // ---------------------------------------------------------------- mở khoá
    override fun onUnlockNeeded(origin: String, retry: () -> Unit) {
        activity.runOnUiThread {
            if (!alive() || unlockShowing) return@runOnUiThread
            // Người dùng vừa bấm "Để sau" thì đừng làm phiền lại ngay (mỗi trang đăng nhập đều gọi vào đây).
            if (System.currentTimeMillis() < unlockSuppressedUntil) return@runOnUiThread
            showUnlockDialog("Mở khoá để dùng mật khẩu đã lưu cho ${hostOf(origin)}", onUnlocked = retry)
        }
    }

    private fun showUnlockDialog(reason: String, onUnlocked: () -> Unit) {
        if (!alive()) return
        unlockShowing = true
        val input = field("Mật khẩu chủ", pwType)
        val status = TextView(activity).apply { setPadding(0, dp(6), 0, 0) }
        val dialog = AlertDialog.Builder(activity)
            .setTitle("Kho mật khẩu đang khoá")
            .setMessage(reason)
            .setView(column(input, status))
            .setPositiveButton("Mở khoá", null) // gắn xử lý bên dưới để KHÔNG tự đóng khi nhập sai
            .setNegativeButton("Để sau") { _, _ -> unlockSuppressedUntil = System.currentTimeMillis() + 120_000L }
            .setNeutralButton("Quên mật khẩu chủ?") { _, _ -> confirmReset() }
            .setOnDismissListener { unlockShowing = false }
            .create()
        dialog.show()
        val ok = dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE)
        ok.setOnClickListener {
            val pw = input.text.toString()
            if (pw.isEmpty()) { status.text = "Hãy nhập mật khẩu chủ"; return@setOnClickListener }
            ok.isEnabled = false
            status.text = "Đang mở khoá…"
            Thread {
                val good = try { LoginStore.unlock(activity, slotIndex, pw) } catch (e: Exception) { false }
                activity.runOnUiThread {
                    if (!alive()) return@runOnUiThread
                    if (good) {
                        DebugLog.log("Khe $slotIndex: [mật khẩu] đã mở khoá kho bằng mật khẩu chủ")
                        dialog.dismiss()
                        onUnlocked()
                    } else {
                        ok.isEnabled = true
                        status.text = "Sai mật khẩu chủ"
                    }
                }
            }.start()
        }
    }

    private fun confirmReset() {
        if (!alive()) return
        AlertDialog.Builder(activity)
            .setTitle("Xoá sạch mật khẩu đã lưu?")
            .setMessage("Không có cách khôi phục mật khẩu chủ. Chỉ có thể XOÁ TOÀN BỘ mật khẩu đã lưu của hồ sơ này rồi bắt đầu lại.")
            .setPositiveButton("Xoá sạch") { _, _ -> LoginStore.resetAll(activity, slotIndex); toast("Đã xoá toàn bộ mật khẩu đã lưu") }
            .setNegativeButton("Giữ lại", null)
            .show()
    }

    // ---------------------------------------------------------------- hỏi lưu
    override fun onLoginSubmit(origin: String, username: String, password: String, kind: LoginStore.Compare, existingId: String?) {
        activity.runOnUiThread {
            if (!alive()) return@runOnUiThread
            val show = { showSavePrompt(origin, username, password, kind) }
            // Đang có hộp thoại khác thì xếp hàng bản MỚI NHẤT, không chồng nhiều hộp thoại.
            if (savePromptShowing) pendingSave = show else show()
        }
    }

    private fun showSavePrompt(origin: String, username: String, password: String, kind: LoginStore.Compare) {
        if (!alive()) return
        savePromptShowing = true
        val update = kind == LoginStore.Compare.UPDATE
        // Tên đăng nhập cho SỬA được: có trang không cho biết tên ở bước mật khẩu (vd đăng nhập 2 bước), người dùng tự điền.
        val user = field("Tên đăng nhập / email", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, username)
        val info = TextView(activity).apply { text = "Trang: ${hostOf(origin)}\nMật khẩu: ${mask(password)}" }
        AlertDialog.Builder(activity)
            .setTitle(if (update) "Cập nhật mật khẩu?" else "Lưu mật khẩu?")
            .setView(column(info, user))
            .setPositiveButton(if (update) "Cập nhật" else "Lưu") { _, _ ->
                try {
                    LoginStore.save(activity, slotIndex, origin, user.text.toString().trim(), password)
                    toast("Đã lưu mật khẩu")
                    DebugLog.log("Khe $slotIndex: [mật khẩu] đã ${if (update) "cập nhật" else "lưu"} tài khoản cho $origin")
                } catch (e: LoginStore.LockedException) { toast("Kho đang khoá — chưa lưu được") }
            }
            .setNegativeButton("Không lưu", null)
            .setNeutralButton("Không bao giờ") { _, _ ->
                try {
                    LoginStore.setNever(activity, slotIndex, origin)
                    toast("Sẽ không hỏi lưu mật khẩu cho ${hostOf(origin)}")
                } catch (e: LoginStore.LockedException) { toast("Kho đang khoá") }
            }
            .setOnDismissListener {
                savePromptShowing = false
                pendingSave?.let { p -> pendingSave = null; p() }
            }
            .show()
    }

    // ---------------------------------------------------------------- chọn tài khoản
    override fun onLoginChoose(origin: String, logins: List<LoginStore.Login>, onChosen: (LoginStore.Login) -> Unit) {
        activity.runOnUiThread {
            if (!alive()) return@runOnUiThread
            val labels = logins.map { if (it.username.isBlank()) "(không có tên đăng nhập)" else it.username }.toTypedArray()
            AlertDialog.Builder(activity)
                .setTitle("Điền tài khoản cho ${hostOf(origin)}")
                .setItems(labels) { _, which -> onChosen(logins[which]) }
                .setNegativeButton("Bỏ qua", null)
                .show()
        }
    }

    // ---------------------------------------------------------------- quản lý
    fun showManager() {
        if (!alive()) return
        if (LoginStore.isLocked(activity, slotIndex)) {
            showUnlockDialog("Nhập mật khẩu chủ để xem và quản lý mật khẩu đã lưu") { showManager() }
            return
        }
        val enabled = AppPrefs.getBoolean(activity, slotIndex, "pw_enabled", true)
        val encrypted = LoginStore.isEncrypted(activity, slotIndex)
        val logins = LoginStore.all(activity, slotIndex)
        val labels = ArrayList<String>()
        labels.add(if (enabled) "✔ Lưu & tự điền mật khẩu: ĐANG BẬT (chạm để tắt)" else "✖ Lưu & tự điền mật khẩu: ĐANG TẮT (chạm để bật)")
        labels.add(if (encrypted) "🔐 Mật khẩu chủ: ĐANG BẬT (đổi / tắt / khoá ngay)" else "🔓 Mật khẩu chủ: CHƯA ĐẶT (chạm để đặt, mã hoá kho)")
        labels.add("＋ Thêm tài khoản thủ công")
        logins.forEach { labels.add("${hostOf(it.origin)}  —  ${if (it.username.isBlank()) "(trống)" else it.username}") }
        AlertDialog.Builder(activity)
            .setTitle("Mật khẩu đã lưu (${logins.size})")
            .setItems(labels.toTypedArray()) { _, which ->
                when (which) {
                    0 -> {
                        AppPrefs.setBoolean(activity, slotIndex, "pw_enabled", !enabled)
                        toast(if (!enabled) "Đã bật lưu & tự điền mật khẩu" else "Đã tắt lưu & tự điền mật khẩu")
                    }
                    1 -> if (encrypted) showMasterMenu() else showSetMasterDialog(change = false)
                    2 -> showAddDialog()
                    else -> showEntry(logins[which - 3])
                }
            }
            .setNegativeButton("Đóng", null)
            .setNeutralButton("Ghi chú bảo mật") { _, _ ->
                AlertDialog.Builder(activity)
                    .setTitle("Ghi chú bảo mật")
                    .setMessage("Mật khẩu nằm trong hồ sơ và đi kèm file sao lưu hồ sơ (khôi phục cùng cookie khi import).\n\n" +
                        "• Chưa đặt mật khẩu chủ: file backup chứa mật khẩu dạng chữ thường — giữ file backup riêng tư.\n" +
                        "• Đã đặt mật khẩu chủ: kho được mã hoá AES-256-GCM, khoá dẫn xuất từ mật khẩu chủ (PBKDF2, 250.000 vòng). " +
                        "Mật khẩu chủ KHÔNG được lưu ở đâu; quên là không khôi phục được. Kho tự khoá lại sau 15 phút không dùng.\n\n" +
                        "Tab ẩn danh không bao giờ lưu hay tự điền mật khẩu.")
                    .setPositiveButton("Đã hiểu", null).show()
            }
            .show()
    }

    private fun showMasterMenu() {
        if (!alive()) return
        AlertDialog.Builder(activity)
            .setTitle("Mật khẩu chủ")
            .setItems(arrayOf("Đổi mật khẩu chủ", "Tắt mật khẩu chủ (giải mã kho)", "Khoá ngay")) { _, which ->
                when (which) {
                    0 -> showSetMasterDialog(change = true)
                    1 -> AlertDialog.Builder(activity)
                        .setTitle("Tắt mật khẩu chủ?")
                        .setMessage("Kho sẽ được giải mã và lưu dạng chữ thường. File backup sẽ chứa mật khẩu rõ ràng.")
                        .setPositiveButton("Tắt") { _, _ ->
                            try { LoginStore.removeMasterPassword(activity, slotIndex); toast("Đã tắt mật khẩu chủ") }
                            catch (e: LoginStore.LockedException) { toast("Kho đang khoá") }
                        }
                        .setNegativeButton("Giữ", null).show()
                    2 -> { LoginStore.lock(activity, slotIndex); toast("Đã khoá kho mật khẩu") }
                }
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun showSetMasterDialog(change: Boolean) {
        if (!alive()) return
        val p1 = field("Mật khẩu chủ mới (ít nhất 6 ký tự)", pwType)
        val p2 = field("Nhập lại mật khẩu chủ", pwType)
        val status = TextView(activity).apply { setPadding(0, dp(6), 0, 0) }
        val dialog = AlertDialog.Builder(activity)
            .setTitle(if (change) "Đổi mật khẩu chủ" else "Đặt mật khẩu chủ")
            .setMessage("Quên mật khẩu chủ thì KHÔNG khôi phục được các mật khẩu đã lưu.")
            .setView(column(p1, p2, status))
            .setPositiveButton("Đặt", null)
            .setNegativeButton("Huỷ", null)
            .create()
        dialog.show()
        val ok = dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE)
        ok.setOnClickListener {
            val a = p1.text.toString()
            when {
                a.length < 6 -> { status.text = "Mật khẩu chủ cần ít nhất 6 ký tự"; return@setOnClickListener }
                a != p2.text.toString() -> { status.text = "Hai lần nhập không khớp"; return@setOnClickListener }
            }
            ok.isEnabled = false
            status.text = "Đang mã hoá…"
            Thread {
                val err: String? = try { LoginStore.setMasterPassword(activity, slotIndex, a); null }
                    catch (e: LoginStore.LockedException) { "Kho đang khoá — mở khoá trước" }
                    catch (e: Exception) { "Lỗi: ${e.javaClass.simpleName}" }
                activity.runOnUiThread {
                    if (!alive()) return@runOnUiThread
                    if (err == null) {
                        DebugLog.log("Khe $slotIndex: [mật khẩu] đã ${if (change) "đổi" else "đặt"} mật khẩu chủ (kho được mã hoá)")
                        dialog.dismiss()
                        toast(if (change) "Đã đổi mật khẩu chủ" else "Đã bật mật khẩu chủ — kho mật khẩu được mã hoá")
                    } else { ok.isEnabled = true; status.text = err }
                }
            }.start()
        }
    }

    private fun showEntry(l: LoginStore.Login) {
        if (!alive()) return
        AlertDialog.Builder(activity)
            .setTitle(hostOf(l.origin))
            .setMessage("Tài khoản: ${if (l.username.isBlank()) "(trống)" else l.username}\nMật khẩu: ${mask(l.password)}")
            .setPositiveButton("Hiện mật khẩu") { _, _ ->
                AlertDialog.Builder(activity)
                    .setTitle(hostOf(l.origin))
                    .setMessage("Tài khoản: ${l.username}\nMật khẩu: ${l.password}")
                    .setPositiveButton("Đóng", null).show()
            }
            .setNeutralButton("Sao chép MK") { _, _ ->
                val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("mật khẩu", l.password))
                toast("Đã sao chép mật khẩu")
            }
            .setNegativeButton("Xoá") { _, _ ->
                AlertDialog.Builder(activity)
                    .setTitle("Xoá mật khẩu này?")
                    .setMessage("${hostOf(l.origin)} — ${l.username}")
                    .setPositiveButton("Xoá") { _, _ ->
                        try { LoginStore.delete(activity, slotIndex, l.id); toast("Đã xoá") }
                        catch (e: LoginStore.LockedException) { toast("Kho đang khoá") }
                    }
                    .setNegativeButton("Giữ lại", null).show()
            }
            .show()
    }

    private fun showAddDialog() {
        if (!alive()) return
        val site = field("Địa chỉ trang (vd https://example.com)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val user = field("Tên đăng nhập / email", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val pass = field("Mật khẩu", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        AlertDialog.Builder(activity)
            .setTitle("Thêm tài khoản")
            .setView(column(site, user, pass))
            .setPositiveButton("Lưu") { _, _ ->
                var raw = site.text.toString().trim()
                if (raw.isNotEmpty() && !raw.contains("://")) raw = "https://$raw"
                val origin = LoginStore.normalizeOrigin(raw)
                val p = pass.text.toString()
                if (origin == null || p.isEmpty()) { toast("Cần địa chỉ trang hợp lệ và mật khẩu"); return@setPositiveButton }
                try {
                    LoginStore.save(activity, slotIndex, origin, user.text.toString().trim(), p)
                    toast("Đã lưu")
                } catch (e: LoginStore.LockedException) { toast("Kho đang khoá") }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }
}
