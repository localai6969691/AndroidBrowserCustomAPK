package com.colablive.keeper

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.DebugLog

/**
 * BUG THẬT đã tìm ra (người dùng báo: "nút phát media trên thanh thông báo
 * nhấn vào không tắt nhạc, trước kia thì nhấn vào là tắt nhạc"): trước lượt
 * sửa gate `KeepAliveService.start()` theo đúng cờ `colablive_keepalive_on`
 * (fix bug "thông báo Colab Live chạy trước khi vào Colab"), service đó
 * chạy VÔ ĐIỀU KIỆN ở MỌI lần mở app — vô tình giữ luôn PROCESS sống ở nền
 * (foreground service = ưu tiên cao hơn hẳn app thường, khó bị hệ thống
 * đóng băng/giết khi xuống nền). Sau khi gate lại đúng thiết kế, nếu người
 * dùng CHỈ nghe nhạc nền (không bật Colab Live), process không còn được
 * bảo vệ nữa — dễ bị hệ thống đóng băng/giết khi app xuống nền, khiến
 * `BroadcastReceiver` đăng ký ĐỘNG trong code (`mediaActionReceiver` ở
 * GeckoViewEngine — CHỈ tồn tại khi process còn sống, khác receiver khai
 * báo trong Manifest) ngừng nhận được broadcast từ nút bấm trên thông báo.
 *
 * SỬA ĐÚNG GỐC (không phải vá lại KeepAliveService cho mục đích khác):
 * dựng 1 foreground service THẬT RIêng cho việc phát media — permission
 * `FOREGROUND_SERVICE_MEDIA_PLAYBACK` đã khai báo sẵn trong Manifest từ
 * trước nhưng CHƯA TỪNG có service nào thật sự dùng tới. Chỉ chạy khi CÓ
 * media đang phát, dừng khi tạm dừng/dừng hẳn — HOÀN TOÀN độc lập với cờ
 * `colablive_keepalive_on`.
 *
 * ĐA TIẾN TRÌNH: mỗi khe (slot) là 1 tiến trình Android RIÊNG (`MainActivity`
 * dùng process mặc định, `MainActivitySlot1/2/3` dùng `:slot1`/`:slot2`/
 * `:slot3` — xem AndroidManifest.xml). Service KHÔNG có `android:process`
 * riêng sẽ LUÔN chạy ở process MẶC ĐỊNH bất kể ai gọi startForegroundService
 * — nếu khe 1/2/3 (process riêng) gọi thẳng `MediaKeepAliveService`, sẽ vô
 * tình khởi động process MẶC ĐỊNH thay vì giữ ĐÚNG process của chính khe đó
 * sống — không đạt được mục đích. Nên cần 3 class con RỖNG (giống hệt
 * pattern `MainActivitySlot1/2/3` trong `MainActivitySlots.kt`) khai báo
 * `<service>` riêng với `android:process` khớp đúng từng khe.
 */
open class MediaKeepAliveService : Service() {

    /** Id thông báo của khe này (khớp `2000 + slotIndex` mà GeckoViewEngine dùng) — để thông báo tối thiểu lúc khởi động được thay thế êm bằng thông báo thật. */
    protected open val slotNotifId: Int get() = 2000

    companion object {
        private const val EXTRA_NOTIF_ID = "notif_id"
        private const val EXTRA_NOTIFICATION = "notification"
        private const val CHANNEL_ID = "media_keepalive_min"

        /**
         * Bản 7.75 — sửa CRASH `ForegroundServiceDidNotStartInTimeException` (báo cáo 00:18:17): Android bắt buộc mỗi lần gọi startForegroundService() thì service phải gọi
         * startForeground() trong ~5 giây. Hai đường vi phạm cũ: (1) YouTube bắn onPause/onPlay liên tiếp (chuyển bài, tự phát bài kế) => app gọi start() rồi stop() ngay trong
         * vài chục ms, lệnh stopService() chen vào TRƯỚC khi service kịp gọi startForeground(); (2) onStartCommand gặp notification null chỉ gọi stopSelf() mà chưa startForeground().
         * Sửa: service gọi startForeground() NGAY trong onCreate (thông báo tối thiểu), và stop() luôn bị TRÌ HOÃN tới khi service đã sống tối thiểu MIN_LIFETIME_MS,
         * huỷ nếu có start() mới tới trong lúc chờ.
         */
        private const val MIN_LIFETIME_MS = 2500L
        private val handler = android.os.Handler(android.os.Looper.getMainLooper())
        @Volatile private var lastStartAt = 0L
        @Volatile private var pendingStop: Runnable? = null

        /** Trả về ĐÚNG class con khớp process của khe hiện tại — gọi từ GeckoViewEngine (biết sẵn slotIndex). */
        fun classForSlot(slotIndex: Int): Class<out MediaKeepAliveService> = when (slotIndex) {
            1 -> MediaKeepAliveServiceSlot1::class.java
            2 -> MediaKeepAliveServiceSlot2::class.java
            3 -> MediaKeepAliveServiceSlot3::class.java
            else -> MediaKeepAliveService::class.java
        }

        fun start(context: Context, serviceClass: Class<out MediaKeepAliveService>, notifId: Int, notification: Notification) {
            try {
                pendingStop?.let { handler.removeCallbacks(it) }
                pendingStop = null
                lastStartAt = android.os.SystemClock.elapsedRealtime()
                val intent = Intent(context, serviceClass).apply {
                    putExtra(EXTRA_NOTIF_ID, notifId)
                    putExtra(EXTRA_NOTIFICATION, notification)
                }
                ContextCompat.startForegroundService(context, intent)
            } catch (e: Exception) {
                DebugLog.log("MediaKeepAliveService.start() lỗi: ${e.message}")
            }
        }

        fun stop(context: Context, serviceClass: Class<out MediaKeepAliveService>) {
            try {
                val doStop = Runnable {
                    pendingStop = null
                    try { context.stopService(Intent(context, serviceClass)) } catch (e: Exception) { DebugLog.log("MediaKeepAliveService.stop() lỗi: ${e.message}") }
                }
                pendingStop?.let { handler.removeCallbacks(it) }
                val wait = MIN_LIFETIME_MS - (android.os.SystemClock.elapsedRealtime() - lastStartAt)
                if (wait <= 0L) doStop.run() else { pendingStop = doStop; handler.postDelayed(doStop, wait) }
            } catch (e: Exception) {
                DebugLog.log("MediaKeepAliveService.stop() lỗi: ${e.message}")
            }
        }
    }

    private fun minimalNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(android.app.NotificationChannel(CHANNEL_ID, "Giữ nền khi phát media", android.app.NotificationManager.IMPORTANCE_LOW))
            }
            Notification.Builder(this, CHANNEL_ID).setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Đang phát media").setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Đang phát media").setOngoing(true).build()
        }
    }

    private fun enterForeground(id: Int, notification: Notification): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(id, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(id, notification)
            }
            true
        } catch (e: Exception) {
            DebugLog.log("MediaKeepAliveService: startForeground() lỗi (${e.message})")
            false
        }
    }

    override fun onCreate() {
        super.onCreate()
        // Thoả hợp đồng "startForegroundService => startForeground trong ~5s" NGAY khi service được tạo, trước mọi việc khác.
        enterForeground(slotNotifId, minimalNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notifId = intent?.getIntExtra(EXTRA_NOTIF_ID, slotNotifId) ?: slotNotifId
        val notification: Notification? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent?.getParcelableExtra(EXTRA_NOTIFICATION, Notification::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent?.getParcelableExtra(EXTRA_NOTIFICATION)
            }
        } catch (e: Exception) {
            null
        }
        // MỖI lần onStartCommand đều phải startForeground (mỗi lệnh startForegroundService là một hợp đồng riêng): dùng thông báo thật nếu có, không thì thông báo tối thiểu.
        val ok = enterForeground(if (notification != null) notifId else slotNotifId, notification ?: minimalNotification())
        if (!ok || notification == null) {
            // Đã startForeground (hoặc thử hết cách) rồi mới được dừng — dừng SAU khi thoả hợp đồng, không phải thay cho nó.
            try { stopForeground(true) } catch (_: Exception) {}
            stopSelf()
        }
        // CỐ Ý START_NOT_STICKY: service này không có state đáng khôi phục (xem ghi chú gốc ở đầu file).
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

// Xem giải thích ĐA TIẾN TRÌNH ở comment lớn phía trên — 3 class con, mỗi cái có 1 tên class riêng khai báo <service> với android:process khớp từng khe trong AndroidManifest.xml.
class MediaKeepAliveServiceSlot1 : MediaKeepAliveService() { override val slotNotifId: Int get() = 2001 }
class MediaKeepAliveServiceSlot2 : MediaKeepAliveService() { override val slotNotifId: Int get() = 2002 }
class MediaKeepAliveServiceSlot3 : MediaKeepAliveService() { override val slotNotifId: Int get() = 2003 }
