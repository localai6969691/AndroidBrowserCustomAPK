package com.colablive.keeper

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.DebugLog

/**
 * BUG THẬT đã tìm ra (người dùng báo: "nút phát media trên thanh thông báo
 * nhấn vào không tắt nhạc, trước kia thì nhấn vào là tắt nhạc"): trước lượt
 * sửa gate `KeepAliveService.start()` theo đúng cờ `colablive_keepalive_on`
 * (fix bug "thông báo Colab Live chạy trước khi vào Colab"), service đó
 * chạy VÔ ĐIỀU KIỆN ở MỌI lần mở app — vô tình giữ luôn PROCESS sống ở nền
 * (foreground service = ưu tiên cao hơn hẳn app thường, khó bị hệ thống
 * đóng băng/giết khi xuống nền). Sau khi gate lại đúng thiết kế, nếu người
 * dùng CHỈ nghe nhạc nền (không bật Colab Live), process không còn được
 * bảo vệ nữa — dễ bị hệ thống đóng băng/giết khi app xuống nền, khiến
 * `BroadcastReceiver` đăng ký ĐỘNG trong code (`mediaActionReceiver` ở
 * GeckoViewEngine — CHỈ tồn tại khi process còn sống, khác receiver khai
 * báo trong Manifest) ngừng nhận được broadcast từ nút bấm trên thông báo.
 *
 * SỬA ĐÚNG GỐC (không phải vá lại KeepAliveService cho mục đích khác):
 * dựng 1 foreground service THẬT RIêng cho việc phát media — permission
 * `FOREGROUND_SERVICE_MEDIA_PLAYBACK` đã khai báo sẵn trong Manifest từ
 * trước nhưng CHƯA TỪNG có service nào thật sự dùng tới. Chỉ chạy khi CÓ
 * media đang phát, dừng khi tạm dừng/dừng hẳn — HOÀN TOÀN độc lập với cờ
 * `colablive_keepalive_on`.
 *
 * ĐA TIẾN TRÌNH: mỗi khe (slot) là 1 tiến trình Android RIÊNG (`MainActivity`
 * dùng process mặc định, `MainActivitySlot1/2/3` dùng `:slot1`/`:slot2`/
 * `:slot3` — xem AndroidManifest.xml). Service KHÔNG có `android:process`
 * riêng sẽ LUÔN chạy ở process MẶC ĐỊNH bất kể ai gọi startForegroundService
 * — nếu khe 1/2/3 (process riêng) gọi thẳng `MediaKeepAliveService`, sẽ vô
 * tình khởi động process MẶC ĐỊNH thay vì giữ ĐÚNG process của chính khe đó
 * sống — không đạt được mục đích. Nên cần 3 class con RỖNG (giống hệt
 * pattern `MainActivitySlot1/2/3` trong `MainActivitySlots.kt`) khai báo
 * `<service>` riêng với `android:process` khớp đúng từng khe.
 */
open class MediaKeepAliveService : Service() {

    /** Id thông báo của khe này (khớp `2000 + slotIndex` mà GeckoViewEngine dùng) — để thông báo tối thiểu lúc khởi động được thay thế êm bằng thông báo thật. */
    protected open val slotNotifId: Int get() = 2000

    companion object {
        private const val EXTRA_NOTIF_ID = "notif_id"
        private const val EXTRA_NOTIFICATION = "notification"
        private const val CHANNEL_ID = "media_keepalive_min"

        /**
         * Bản 7.109 — THIẾT KẾ LẠI vòng đời "phát -> tạm dừng -> phát" để hết tranh chấp (người dùng báo: bấm Tạm dừng rồi Phát lại trên thanh thông báo thì thanh đó biến mất).
         * Lịch sử: 7.75 sửa crash ForegroundServiceDidNotStartInTimeException bằng cách TRÌ HOÃN stopService() >= 2,5s; 7.78 thêm DETACH trong onDestroy. Cả hai đều chỉ VÁ thứ tự bằng đồng hồ:
         * engine gọi stopService() rồi nm.notify() (hai lệnh binder độc lập), còn việc "gỡ cờ foreground" của thông báo lại nằm trong onDestroy() — tức SAU khi hệ thống đã bắt đầu dừng service.
         * Thứ tự thật giữa ba việc đó (hệ thống huỷ thông báo foreground / lệnh notify của engine / DETACH trong onDestroy) không được đảm bảo, và khi Phát lại tới sát lúc service đang bị dừng thì lệnh start mới
         * rơi vào đúng khe tranh chấp đó.
         * Cách mới (không dựa vào đồng hồ): chuyển "hạ xuống tạm dừng" thành MỘT chuỗi lệnh chạy tuần tự TRONG service, trên luồng chính:
         *   (1) stopForeground(DETACH)  — gọi binder đồng bộ, xong là hệ thống không còn coi thông báo là của foreground service nữa => dừng service sau đó KHÔNG kéo thông báo đi theo;
         *   (2) notify(thông báo "tạm dừng") — đè lên thông báo cũ cùng id;
         *   (3) stopSelf().
         * Chỉ hạ xuống khi KHÔNG còn lệnh start nào đang chờ giao (pendingStarts == 0) — vì mỗi startForegroundService() phải được một onStartCommand() đáp lại bằng startForeground(), dừng trước đó là crash 7.75.
         * Có start() mới thì mọi lần hạ đang chờ bị huỷ (demoteSeq tăng).
         * Mọi trạng thái bên dưới chỉ chạm từ luồng chính (start()/demote() tự chuyển về luồng chính).
         */
        private val handler = android.os.Handler(android.os.Looper.getMainLooper())
        private var running: MediaKeepAliveService? = null
        private var pendingStarts = 0
        private var demoteSeq = 0

        private fun onMain(block: () -> Unit) {
            if (android.os.Looper.myLooper() === android.os.Looper.getMainLooper()) block() else handler.post { block() }
        }

        /** Trả về ĐÚNG class con khớp process của khe hiện tại — gọi từ GeckoViewEngine (biết sẵn slotIndex). */
        fun classForSlot(slotIndex: Int): Class<out MediaKeepAliveService> = when (slotIndex) {
            1 -> MediaKeepAliveServiceSlot1::class.java
            2 -> MediaKeepAliveServiceSlot2::class.java
            3 -> MediaKeepAliveServiceSlot3::class.java
            else -> MediaKeepAliveService::class.java
        }

        fun start(context: Context, serviceClass: Class<out MediaKeepAliveService>, notifId: Int, notification: Notification) {
            onMain {
                demoteSeq++ // huỷ mọi lần "hạ xuống tạm dừng" đang chờ
                pendingStarts++
                try {
                    val intent = Intent(context, serviceClass).apply {
                        putExtra(EXTRA_NOTIF_ID, notifId)
                        putExtra(EXTRA_NOTIFICATION, notification)
                    }
                    ContextCompat.startForegroundService(context, intent)
                } catch (e: Exception) {
                    pendingStarts = maxOf(0, pendingStarts - 1)
                    DebugLog.log("MediaKeepAliveService.start() lỗi: ${e.javaClass.simpleName}: ${e.message} — vẫn đăng thông báo thường (không giữ được tiến trình nền) để người dùng còn thấy/bấm được")
                    try { (context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).notify(notifId, notification) } catch (_: Exception) {}
                }
            }
        }

        /**
         * Hạ xuống "tạm dừng": đăng [notification] (bản tạm dừng) cùng id với thông báo đang phát và dừng service theo đúng thứ tự (xem ghi chú lớn phía trên).
         * Không có service nào đang chạy và không có lệnh start nào đang chờ thì chỉ đăng thông báo.
         */
        fun demote(context: Context, notifId: Int, notification: Notification) {
            onMain {
                val seq = ++demoteSeq
                val t0 = android.os.SystemClock.elapsedRealtime()
                fun attempt() {
                    if (seq != demoteSeq) return // đã có start()/demote() mới hơn
                    if (pendingStarts > 0 && android.os.SystemClock.elapsedRealtime() - t0 < 4000L) {
                        handler.postDelayed({ attempt() }, 120L) // còn lệnh start chưa được onStartCommand đáp lại: chờ, KHÔNG dừng giữa chừng
                        return
                    }
                    if (pendingStarts > 0) {
                        DebugLog.log("MediaKeepAliveService: ${pendingStarts} lệnh start không được giao sau 4s — bỏ chờ, hạ xuống tạm dừng")
                        pendingStarts = 0
                    }
                    val svc = running
                    if (svc != null) {
                        svc.demoteNow(notifId, notification)
                    } else {
                        try {
                            (context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).notify(notifId, notification)
                            DebugLog.log("MediaKeepAliveService: không có service đang chạy — chỉ đăng thông báo tạm dừng (id=$notifId)")
                        } catch (e: Exception) {
                            DebugLog.log("MediaKeepAliveService: đăng thông báo tạm dừng lỗi: ${e.javaClass.simpleName}: ${e.message}")
                        }
                    }
                }
                attempt()
            }
        }
    }

    /** Chạy trên luồng chính. Thứ tự BẮT BUỘC: tách foreground (đồng bộ) -> đăng thông báo tạm dừng -> dừng service. Mỗi bước tự bắt lỗi riêng để một bước hỏng không làm mất thông báo ở bước sau. */
    private fun demoteNow(id: Int, notification: Notification) {
        val err = StringBuilder()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(Service.STOP_FOREGROUND_DETACH)
            else @Suppress("DEPRECATION") stopForeground(false)
        } catch (e: Exception) { err.append(" [tách foreground lỗi: ${e.javaClass.simpleName}: ${e.message}]") }
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).notify(id, notification)
        } catch (e: Exception) { err.append(" [đăng thông báo lỗi: ${e.javaClass.simpleName}: ${e.message}]") }
        try { stopSelf() } catch (e: Exception) { err.append(" [dừng service lỗi: ${e.javaClass.simpleName}: ${e.message}]") }
        DebugLog.log("MediaKeepAliveService: hạ xuống TẠM DỪNG theo thứ tự (tách foreground -> đăng thông báo tạm dừng -> dừng service), id=$id" + if (err.isEmpty()) " — không lỗi" else err.toString())
    }

    private fun minimalNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(android.app.NotificationChannel(CHANNEL_ID, "Giữ nền khi phát media", android.app.NotificationManager.IMPORTANCE_LOW))
            }
            Notification.Builder(this, CHANNEL_ID).setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Đang phát media").setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Đang phát media").setOngoing(true).build()
        }
    }

    private fun enterForeground(id: Int, notification: Notification): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(id, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(id, notification)
            }
            true
        } catch (e: Exception) {
            DebugLog.log("MediaKeepAliveService: startForeground() lỗi (${e.message})")
            false
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = this
        // Thoả hợp đồng "startForegroundService => startForeground trong ~5s" NGAY khi service được tạo, trước mọi việc khác.
        enterForeground(slotNotifId, minimalNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        pendingStarts = maxOf(0, pendingStarts - 1) // lệnh start này đã được giao; tới cuối hàm sẽ đáp lại bằng startForeground()
        val notifId = intent?.getIntExtra(EXTRA_NOTIF_ID, slotNotifId) ?: slotNotifId
        val notification: Notification? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent?.getParcelableExtra(EXTRA_NOTIFICATION, Notification::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent?.getParcelableExtra(EXTRA_NOTIFICATION)
            }
        } catch (e: Exception) {
            null
        }
        // MỖI lần onStartCommand đều phải startForeground (mỗi lệnh startForegroundService là một hợp đồng riêng): dùng thông báo thật nếu có, không thì thông báo tối thiểu.
        val ok = enterForeground(if (notification != null) notifId else slotNotifId, notification ?: minimalNotification())
        DebugLog.log("MediaKeepAliveService: onStartCommand id=$notifId thông báo=${if (notification != null) "có" else "KHÔNG (intent=" + (if (intent == null) "null" else "có nhưng thiếu extra") + ") — sẽ dừng service và GỠ thông báo"} startForeground=${if (ok) "OK" else "LỖI"}")
        if (!ok || notification == null) {
            // Đã startForeground (hoặc thử hết cách) rồi mới được dừng — dừng SAU khi thoả hợp đồng, không phải thay cho nó.
            try { stopForeground(true) } catch (_: Exception) {}
            stopSelf()
        }
        // CỐ Ý START_NOT_STICKY: service này không có state đáng khôi phục (xem ghi chú gốc ở đầu file).
        return START_NOT_STICKY
    }

    // Hạ xuống tạm dừng bình thường đã DETACH trước khi tới đây (xem demoteNow). DETACH ở đây chỉ là lưới an toàn cho đường dừng bất thường (hệ thống tự dừng service...): không bao giờ để hệ thống kéo thông báo đi theo.
    override fun onDestroy() {
        if (running === this) running = null
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(Service.STOP_FOREGROUND_DETACH)
            else @Suppress("DEPRECATION") stopForeground(false)
        } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

// Xem giải thích ĐA TIẾN TRÌNH ở comment lớn phía trên — 3 class con, mỗi cái có 1 tên class riêng khai báo <service> với android:process khớp từng khe trong AndroidManifest.xml.
class MediaKeepAliveServiceSlot1 : MediaKeepAliveService() { override val slotNotifId: Int get() = 2001 }
class MediaKeepAliveServiceSlot2 : MediaKeepAliveService() { override val slotNotifId: Int get() = 2002 }
class MediaKeepAliveServiceSlot3 : MediaKeepAliveService() { override val slotNotifId: Int get() = 2003 }
