package com.colablive.keeper.features.ebookleech.service

import android.content.Context
import java.io.File

/**
 * Registry GLOBAL (không theo slot) ghi nhớ những slot nào đang bật EbookLeech.
 *
 * Bản 7.98 — LƯU BẰNG FILE (không dùng SharedPreferences như bản gốc của addon). Lý do: app chạy MỖI KHE Ở MỘT TIẾN TRÌNH RIÊNG (`:slot1`..`:slot3`); người bật/tắt
 * tính năng ở tiến trình khe, còn WorkManager (`EbookLeechWorkLogic`, lưới an toàn) chạy ở tiến trình CHÍNH. SharedPreferences MODE_PRIVATE được MỖI tiến trình
 * nhớ riêng (không tự đọc lại thay đổi do tiến trình khác ghi), nên tiến trình chính sẽ không bao giờ thấy khe vừa bật. File nhỏ đọc lại từ đĩa mỗi lần thì thấy đúng.
 */
object EbookLeechSlotRegistry {

    private const val FILE_NAME = "ebook_leech_enabled_slots.txt"

    private fun file(context: Context) = File(context.applicationContext.filesDir, FILE_NAME)

    @Synchronized
    private fun write(context: Context, slots: Set<Int>) {
        val f = file(context)
        val tmp = File(f.parentFile, "$FILE_NAME.tmp")
        val text = slots.sorted().joinToString(",")
        try {
            tmp.writeText(text)
            if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
        } catch (e: Exception) {
            try { f.writeText(text) } catch (_: Exception) { /* không ghi được thì lưới an toàn không thấy khe này — service vẫn chạy theo AppPrefs của khe */ }
        }
    }

    fun addSlot(context: Context, slotIndex: Int) {
        write(context, enabledSlots(context).toSet() + slotIndex)
    }

    fun removeSlot(context: Context, slotIndex: Int) {
        write(context, enabledSlots(context).toSet() - slotIndex)
    }

    fun enabledSlots(context: Context): List<Int> = try {
        val f = file(context)
        if (!f.exists()) emptyList() else f.readText().split(",").mapNotNull { it.trim().toIntOrNull() }.distinct()
    } catch (e: Exception) { emptyList() }

    fun hasAnyEnabledSlot(context: Context): Boolean = enabledSlots(context).isNotEmpty()
}
