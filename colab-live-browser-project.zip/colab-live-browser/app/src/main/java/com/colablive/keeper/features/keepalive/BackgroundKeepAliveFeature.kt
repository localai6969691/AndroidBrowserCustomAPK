package com.colablive.keeper.features.keepalive

import android.content.Context
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.BrowserFeature

/**
 * TÍNH NĂNG RIÊNG (người dùng chỉ ra đúng: "hai tính năng khác biệt mà
 * gộp vào nhau thì rất khó quản lý" — trước đây tôi định nhét chung vào
 * màn hình cài đặt của FingerprintSpoofFeature, SAI vì đây là 2 tính năng
 * có mục đích hoàn toàn khác nhau, chỉ TÌNH CỜ dùng chung 1 "hình dạng"
 * kỹ thuật — danh sách domain).
 *
 * Quyết định trang nào được PHÉP tiếp tục chạy nền thật khi người dùng
 * chuyển sang xem tab khác (không bị `GeckoSession.setActive(false)` —
 * xem `GeckoViewEngine.switchToTab()`/`isBackgroundKeepAliveExemptUrl()`).
 * Mặc định (giống Chrome thật): mọi trang đều bị hạ cấp ngay khi không
 * hiển thị. Người dùng tự liệt kê domain cần ngoại lệ — KHÔNG hard-code
 * sẵn bất kỳ trang cụ thể nào (Colab, trang nhạc, hay bất cứ gì).
 *
 * Feature này chỉ là nơi CHỨA cấu hình (bật/tắt + danh sách domain) —
 * `GeckoViewEngine` (tầng core, không phụ thuộc ngược lại features) tự
 * đọc thẳng cùng 1 khoá AppPrefs bên dưới, không gọi qua lại class này,
 * tránh phụ thuộc vòng giữa core và features.
 */
object BackgroundKeepAliveFeature : BrowserFeature {

    override val id = "background_keepalive_domains"
    override val displayName = "Trang chạy nền khi chuyển tab"
    override val description =
        "Mặc định, giống Chrome thật: chuyển sang xem tab khác thì tab vừa " +
            "rời khỏi bị hạ cấp ưu tiên/tài nguyên gần như ngay lập tức (không " +
            "cần rời khỏi cả app). Liệt kê tên miền cần tiếp tục chạy NỀN THẬT " +
            "khi không hiển thị (ví dụ Colab đang chạy cell, trang đang phát " +
            "nhạc) — trang không có trong danh sách vẫn bị hạ cấp bình thường.\n\n" +
            "Bên dưới còn chỉnh được số tab dùng gần nhất luôn giữ sống (không tải lại khi quay lại, ghim hay không) " +
            "và ngân sách RAM; bỏ trống = tự động theo RAM của máy này."

    // Khoá con trong AppPrefs (namespaced theo `id` ở trên, đúng pattern
    // chung mọi feature khác dùng — xem `AppPrefs.getString/getBoolean` bản
    // 5 tham số).
    private const val KEY_ENABLED = "enabled"
    private const val KEY_DOMAINS = "domains"
    // Bản 7.84 — giữ sống tab dùng gần nhất (GeckoViewEngine đọc thẳng cùng khoá, không gọi ngược lại class này).
    private const val KEY_RECENT_LIVE = "recent_live_tabs"
    private const val KEY_RAM_BUDGET = "ram_budget_pct"
    private const val KEY_PROTECT_PRIORITY = "protect_recent_priority"

    /** N hiệu lực (người dùng đặt, bỏ trống = tự động theo RAM máy). */
    fun getRecentLiveTabs(context: Context, slotIndex: Int): Int =
        com.colablive.keeper.core.MemoryPolicy.recentLive(context, slotIndex)

    /** Giá trị NGƯỜI DÙNG đã đặt cho ô nhập (<=0 = để tự động). */
    private fun rawInt(context: Context, slotIndex: Int, key: String): Int =
        AppPrefs.getInt(context, slotIndex, id, key, -1)

    fun isProtectPriority(context: Context, slotIndex: Int): Boolean =
        AppPrefs.getBoolean(context, slotIndex, id, KEY_PROTECT_PRIORITY, false)

    override fun isEnabled(context: Context, slotIndex: Int): Boolean =
        AppPrefs.getBoolean(context, slotIndex, id, KEY_ENABLED, true)

    override fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean) =
        AppPrefs.setBoolean(context, slotIndex, id, KEY_ENABLED, enabled)

    fun getDomains(context: Context, slotIndex: Int): String =
        AppPrefs.getString(context, slotIndex, id, KEY_DOMAINS, "")

    fun setDomains(context: Context, slotIndex: Int, value: String) =
        AppPrefs.setString(context, slotIndex, id, KEY_DOMAINS, value)

    /**
     * Thêm 1 domain vào danh sách nếu chưa có — dùng cho nút ghim trên
     * thanh URL (xem `MainActivity`) và hành động "Chạy nền" khi chọn
     * nhiều tab trong lưới tab.
     */
    fun addDomain(context: Context, slotIndex: Int, domain: String) {
        // Mục 123: ghim (lại) một trang = người dùng muốn chạy nền => bỏ trạng thái "tạm dừng" đặt bởi nút Dừng trên thông báo.
        com.colablive.keeper.core.AppPrefs.setBoolean(context, slotIndex, "background_paused", false)
        val d = domain.trim().lowercase()
        if (d.isEmpty()) return
        val current = getDomains(context, slotIndex).split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }
        if (current.any { it.equals(d, ignoreCase = true) }) return
        setDomains(context, slotIndex, (current + d).joinToString(","))
    }

    fun removeDomain(context: Context, slotIndex: Int, domain: String) {
        val d = domain.trim().lowercase()
        val current = getDomains(context, slotIndex).split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }
        setDomains(context, slotIndex, current.filterNot { it.equals(d, ignoreCase = true) }.joinToString(","))
    }

    fun isDomainPinned(context: Context, slotIndex: Int, domain: String): Boolean {
        val d = domain.trim().lowercase()
        if (d.isEmpty()) return false
        return getDomains(context, slotIndex).split(",", "\n")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .any { it == d || d.endsWith(".$it") }
    }

    override fun buildSettingsView(context: Context, slotIndex: Int): View {
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        layout.addView(TextView(context).apply {
            text = description
            textSize = 14f
            setPadding(0, 0, 0, 24)
        })

        val enableRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        enableRow.addView(TextView(context).apply {
            text = "Bật tính năng này"
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        val enableSwitch = Switch(context).apply { isChecked = isEnabled(context, slotIndex) }
        enableRow.addView(enableSwitch)
        layout.addView(enableRow)

        layout.addView(TextView(context).apply {
            text = "Tên miền được phép chạy nền (mỗi dòng hoặc phẩy 1 tên miền):"
            textSize = 14f
            setPadding(0, 24, 0, 4)
        })
        val domainsInput = EditText(context).apply {
            hint = "colab.research.google.com"
            setText(getDomains(context, slotIndex))
            setSingleLine(false)
        }
        layout.addView(domainsInput)

        // ---- Bản 7.84: GIỮ SỐNG TAB DÙNG GẦN NHẤT (áp cho MỌI trang, ghim hay không) ----
        layout.addView(TextView(context).apply {
            text = "Số tab dùng gần nhất luôn giữ sống, KHÔNG tải lại khi quay lại (tính cả tab đang xem; tab ghim chạy nền không chiếm chỗ):"
            textSize = 14f
            setPadding(0, 32, 0, 4)
        })
        val autoN = com.colablive.keeper.core.MemoryPolicy.autoRecentLive(context)
        val recentInput = EditText(context).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "Tự động ($autoN theo RAM máy này)"
            rawInt(context, slotIndex, KEY_RECENT_LIVE).let { if (it > 0) setText(it.toString()) }
        }
        layout.addView(recentInput)

        layout.addView(TextView(context).apply {
            text = "Ngân sách RAM của app (% RAM máy). Vượt ngưỡng này thì tab cũ ngoài số tab giữ sống bị giải phóng sớm hơn (khôi phục lại đúng vị trí khi bấm vào). Bỏ trống = tự động:"
            textSize = 14f
            setPadding(0, 24, 0, 4)
        })
        val autoPct = com.colablive.keeper.core.MemoryPolicy.autoBudgetPercent(context)
        val budgetInput = EditText(context).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "Tự động (~$autoPct% RAM máy này)"
            rawInt(context, slotIndex, KEY_RAM_BUDGET).let { if (it > 0) setText(it.toString()) }
        }
        layout.addView(budgetInput)

        val protectRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 24, 0, 0) }
        protectRow.addView(TextView(context).apply {
            text = "Bảo vệ tiến trình tab gần đây khi ra nền (hệ điều hành ít giết hơn; thử nghiệm)"
            textSize = 14f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        val protectSwitch = Switch(context).apply { isChecked = isProtectPriority(context, slotIndex) }
        protectRow.addView(protectSwitch)
        layout.addView(protectRow)

        val featureId = id // KHÔNG dùng `id` trần trong khối apply của View: nó là View.id (Int), che mất id chuỗi của tính năng
        layout.addView(Button(context).apply {
            text = "Lưu"
            setOnClickListener {
                setEnabled(context, slotIndex, enableSwitch.isChecked)
                setDomains(context, slotIndex, domainsInput.text.toString())
                // Bỏ trống/không phải số => -1 = TỰ ĐỘNG theo máy (không ghi đè bằng con số cố định).
                AppPrefs.setInt(context, slotIndex, featureId, KEY_RECENT_LIVE, recentInput.text.toString().trim().toIntOrNull()?.takeIf { it > 0 }?.coerceIn(1, 50) ?: -1)
                AppPrefs.setInt(context, slotIndex, featureId, KEY_RAM_BUDGET, budgetInput.text.toString().trim().toIntOrNull()?.takeIf { it > 0 }?.coerceIn(5, 80) ?: -1)
                AppPrefs.setBoolean(context, slotIndex, featureId, KEY_PROTECT_PRIORITY, protectSwitch.isChecked)
            }
        })

        return layout
    }
}
