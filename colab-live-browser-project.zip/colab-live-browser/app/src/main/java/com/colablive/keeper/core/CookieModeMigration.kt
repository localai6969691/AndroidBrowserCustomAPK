package com.colablive.keeper.core

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.math.BigInteger

/**
 * Mục 129: CHẾ ĐỘ COOKIE CHUNG cho addon.
 *
 * BẰNG CHỨNG (người dùng thử, 9/10): mở popup Cookie-Editor trên trang đã đăng nhập => danh sách cookie TRỐNG. App gắn `contextId` vào MỌI cookie
 * (originAttributes `^geckoViewUserContextId=gvctx<hex>`, xem ContextIdRecovery). API `cookies` của addon tra cookie theo originAttributes mặc định ('') nên
 * không thấy cookie nằm trong vùng contextId — khác Firefox PC (không có contextId nên cookie ở vùng mặc định mà addon thấy). Mỗi khe đã có tiến trình +
 * thư mục hồ sơ RIÊNG nên contextId thừa về mặt cô lập giữa các khe.
 *
 * Chế độ chung: phiên KHÔNG đặt contextId nữa, và (một lần, lúc khởi động khe, TRƯỚC khi Gecko mở cookies.sqlite) chuyển cookie của contextId hiện tại về vùng
 * mặc định ('') để addon thấy. Có sao lưu `cookies.sqlite.before_shared` và đường quay lại. Chỉ chuyển COOKIE (đăng nhập dựa vào cookie); localStorage/IndexedDB
 * của vùng cũ nằm ở thư mục khác và KHÔNG được chuyển.
 */
object CookieModeMigration {
    private val RE = Regex("geckoViewUserContextId=gvctx([0-9a-fA-F]+)")

    fun isShared(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "cookies_shared_mode", false)
    fun isPending(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "cookies_shared_pending", false) || AppPrefs.getBoolean(c, slot, "cookies_isolated_pending", false)

    private fun encode(ctx: String) = "gvctx" + BigInteger(1, ctx.toByteArray(Charsets.UTF_8)).toString(16)
    private fun decode(hex: String): String? = try {
        val h = if (hex.length % 2 == 1) "0$hex" else hex
        String(ByteArray(h.length / 2) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }, Charsets.UTF_8)
    } catch (e: Exception) { null }

    /**
     * Bản 7.93 — NHẬN LẠI cookie "MỒ CÔI" nằm ở vùng mặc định ('') khi khe đang chạy chế độ CÔ LẬP.
     *
     * Log người dùng (18:22:32, "import profile xong tất cả trang đều văng đăng nhập"):
     *   `ContextIdRecovery: contextId đang dùng='profile_vpscolab694'; cookie theo contextId (tổng/google): '(không có contextId)'=78/46`
     *   `cookie đăng nhập Google lúc KHỞI ĐỘNG: có 0 | thiếu: [SID, HSID, ...]`
     * => cookies.sqlite CÓ 78 cookie (46 của Google) nhưng TẤT CẢ ở vùng mặc định (originAttributes rỗng); mọi phiên của khe lại chạy với contextId
     * `profile_vpscolab694` nên chỉ thấy vùng `^geckoViewUserContextId=gvctx...` (rỗng) => MỌI trang (không riêng Google) coi như chưa đăng nhập, dù file còn nguyên.
     * `ContextIdRecovery` chỉ tìm contextId KHÁC bắt đầu bằng `profile_` nên bỏ qua đúng nhóm này.
     *
     * Vùng mặc định lệch cờ chế độ xảy ra khi: backup xuất lúc khe ở "cookie chung" nhưng `app_prefs.json` rỗng/thiếu cờ (đã gặp `app_prefs 0/0`, mục 142.2),
     * backup cũ trước khi có contextId, hoặc cookie ghi bằng addon (Cookie-Editor dùng kho mặc định). Ở khe CÔ LẬP không phiên nào đọc vùng '' => cookie ở đó vô dụng.
     *
     * Cơ chế chung (không phụ thuộc nguồn gốc dữ liệu): TRƯỚC khi Gecko mở cookies.sqlite, chuyển cookie vùng '' sang vùng contextId hiện tại — cùng thao tác với
     * "VỀ chế độ cô lập" ở [runPending] nhưng (1) tự chạy mỗi lần khởi động khi có cookie mồ côi, (2) xử lý trùng (tên, host, path) theo thời điểm truy cập MỚI NHẤT
     * thay vì để UPDATE OR REPLACE đè mù. Có sao lưu `cookies.sqlite.before_adopt`. Chỉ cookie; localStorage/IndexedDB ở vùng cũ KHÔNG được chuyển (giới hạn như [runPending]).
     * Trả về số cookie đã chuyển (0 nếu không có gì/ lỗi). Lỗi => không đổi gì (giao dịch bị huỷ).
     */
    fun adoptDefaultZoneCookies(c: Context, slot: Int, profileDir: File, contextIdFull: String): Int {
        if (isShared(c, slot)) return 0
        val dbFile = File(profileDir, "cookies.sqlite")
        if (!dbFile.isFile) return 0
        return try {
            val targetOa = "^geckoViewUserContextId=" + encode(contextIdFull)
            var moved = 0
            val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
            try {
                db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { it.moveToFirst() }
                val orphans = db.rawQuery("SELECT COUNT(*) FROM moz_cookies WHERE originAttributes = ''", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
                if (orphans <= 0) return 0
                val inCtx = db.rawQuery("SELECT COUNT(*) FROM moz_cookies WHERE originAttributes = ?", arrayOf(targetOa)).use { if (it.moveToFirst()) it.getInt(0) else 0 }
                val bak = File(profileDir, "cookies.sqlite.before_adopt")
                dbFile.copyTo(bak, overwrite = true)
                DebugLog.log("CookieMode: [nhận cookie mồ côi] vùng mặc định có $orphans cookie, vùng '$contextIdFull' có $inCtx — chuyển vào vùng đang dùng (sao lưu -> ${bak.name})")
                var droppedOld = 0
                var replacedCtx = 0
                db.beginTransaction()
                try {
                    // Trùng (name, host, path): giữ bản được truy cập MỚI hơn (như một kho duy nhất sẽ có), bản kia bị bỏ để UPDATE không vướng UNIQUE.
                    db.compileStatement(
                        "DELETE FROM moz_cookies WHERE originAttributes = '' AND EXISTS (SELECT 1 FROM moz_cookies t WHERE t.originAttributes = ? " +
                            "AND t.name = moz_cookies.name AND t.host = moz_cookies.host AND t.path = moz_cookies.path AND t.lastAccessed >= moz_cookies.lastAccessed)"
                    ).use { st -> st.bindString(1, targetOa); droppedOld = st.executeUpdateDelete() }
                    db.compileStatement(
                        "DELETE FROM moz_cookies WHERE originAttributes = ? AND EXISTS (SELECT 1 FROM moz_cookies o WHERE o.originAttributes = '' " +
                            "AND o.name = moz_cookies.name AND o.host = moz_cookies.host AND o.path = moz_cookies.path)"
                    ).use { st -> st.bindString(1, targetOa); replacedCtx = st.executeUpdateDelete() }
                    db.compileStatement("UPDATE moz_cookies SET originAttributes = ? WHERE originAttributes = ''")
                        .use { st -> st.bindString(1, targetOa); moved = st.executeUpdateDelete() }
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
                DebugLog.log("CookieMode: [nhận cookie mồ côi] XONG — chuyển $moved cookie (bỏ $droppedOld bản mồ côi cũ hơn, thay $replacedCtx bản trong vùng đang dùng bằng bản mồ côi mới hơn)")
            } finally { db.close() }
            moved
        } catch (e: Throwable) {
            DebugLog.log("CookieMode: [nhận cookie mồ côi] THẤT BẠI ${e.javaClass.simpleName}: ${e.message} — không đổi gì (còn bản sao cookies.sqlite.before_adopt nếu đã tạo)")
            0
        }
    }

    /** Gọi trong GeckoRuntimeProvider TRƯỚC khi tạo GeckoRuntime. */
    fun runPending(c: Context, slot: Int, profileDir: File, contextIdFull: String) {
        val toShared = AppPrefs.getBoolean(c, slot, "cookies_shared_pending", false)
        val toIsolated = AppPrefs.getBoolean(c, slot, "cookies_isolated_pending", false)
        if (!toShared && !toIsolated) return
        val label = if (toShared) "SANG chế độ chung" else "VỀ chế độ cô lập"
        try {
            val dbFile = File(profileDir, "cookies.sqlite")
            var moved = 0
            if (dbFile.isFile) {
                val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
                try {
                    db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { it.moveToFirst() }
                    val bak = File(profileDir, "cookies.sqlite.before_${if (toShared) "shared" else "isolated"}")
                    dbFile.copyTo(bak, overwrite = true)
                    DebugLog.log("CookieMode: đã sao lưu cookies.sqlite -> ${bak.name} (${bak.length()} byte)")
                    db.beginTransaction()
                    try {
                        if (toShared) {
                            val oas = ArrayList<String>()
                            db.rawQuery("SELECT DISTINCT originAttributes FROM moz_cookies", null).use { cur -> while (cur.moveToNext()) oas.add(cur.getString(0) ?: "") }
                            for (oa in oas) {
                                val m = RE.find(oa) ?: continue
                                if (decode(m.groupValues[1]) != contextIdFull) continue
                                val rest = oa.removePrefix("^").split("&").filter { it.isNotEmpty() && !it.startsWith("geckoViewUserContextId=") }
                                val newOa = if (rest.isEmpty()) "" else "^" + rest.joinToString("&")
                                val st = db.compileStatement("UPDATE OR REPLACE moz_cookies SET originAttributes = ? WHERE originAttributes = ?")
                                st.bindString(1, newOa); st.bindString(2, oa)
                                moved += st.executeUpdateDelete()
                            }
                        } else {
                            val st = db.compileStatement("UPDATE OR REPLACE moz_cookies SET originAttributes = ? WHERE originAttributes = ''")
                            st.bindString(1, "^geckoViewUserContextId=" + encode(contextIdFull))
                            moved = st.executeUpdateDelete()
                        }
                        db.setTransactionSuccessful()
                    } finally { db.endTransaction() }
                } finally { db.close() }
            }
            AppPrefs.setBoolean(c, slot, "cookies_shared_mode", toShared)
            AppPrefs.setBoolean(c, slot, "cookies_shared_pending", false)
            AppPrefs.setBoolean(c, slot, "cookies_isolated_pending", false)
            DebugLog.log("CookieMode: ĐÃ CHUYỂN $label — $moved cookie đổi vùng (contextId='$contextIdFull')")
        } catch (e: Throwable) {
            // Lỗi => KHÔNG đổi chế độ, giữ nguyên dữ liệu (đã có bản sao) để không làm mất đăng nhập.
            AppPrefs.setBoolean(c, slot, "cookies_shared_pending", false)
            AppPrefs.setBoolean(c, slot, "cookies_isolated_pending", false)
            DebugLog.log("CookieMode: chuyển $label THẤT BẠI ${e.javaClass.simpleName}: ${e.message} — giữ nguyên chế độ cũ")
        }
    }
}
