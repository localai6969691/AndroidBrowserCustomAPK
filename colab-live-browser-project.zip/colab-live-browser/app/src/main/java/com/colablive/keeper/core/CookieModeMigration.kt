package com.colablive.keeper.core

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.math.BigInteger

/**
 * Mục 129: CHẾ ĐỘ COOKIE CHUNG cho addon.
 *
 * BẰNG CHỨNG (người dùng thử, 9/10): mở popup Cookie-Editor trên trang đã đăng nhập => danh sách cookie TRỐNG. App gắn `contextId` vào MỌI cookie
 * (originAttributes `^geckoViewUserContextId=gvctx<hex>`, xem ContextIdRecovery). API `cookies` của addon tra cookie theo originAttributes mặc định ('') nên
 * không thấy cookie nằm trong vùng contextId — khác Firefox PC (không có contextId nên cookie ở vùng mặc định mà addon thấy). Mỗi khe đã có tiến trình +
 * thư mục hồ sơ RIÊNG nên contextId thừa về mặt cô lập giữa các khe.
 *
 * Chế độ chung: phiên KHÔNG đặt contextId nữa, và (một lần, lúc khởi động khe, TRƯỚC khi Gecko mở cookies.sqlite) chuyển cookie của contextId hiện tại về vùng
 * mặc định ('') để addon thấy. Có sao lưu `cookies.sqlite.before_shared` và đường quay lại. Chỉ chuyển COOKIE (đăng nhập dựa vào cookie); localStorage/IndexedDB
 * của vùng cũ nằm ở thư mục khác và KHÔNG được chuyển.
 */
object CookieModeMigration {
    private val RE = Regex("geckoViewUserContextId=gvctx([0-9a-fA-F]+)")

    fun isShared(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "cookies_shared_mode", false)
    fun isPending(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "cookies_shared_pending", false) || AppPrefs.getBoolean(c, slot, "cookies_isolated_pending", false)

    private fun encode(ctx: String) = "gvctx" + BigInteger(1, ctx.toByteArray(Charsets.UTF_8)).toString(16)
    private fun decode(hex: String): String? = try {
        val h = if (hex.length % 2 == 1) "0$hex" else hex
        String(ByteArray(h.length / 2) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }, Charsets.UTF_8)
    } catch (e: Exception) { null }

    /** Gọi trong GeckoRuntimeProvider TRƯỚC khi tạo GeckoRuntime. */
    fun runPending(c: Context, slot: Int, profileDir: File, contextIdFull: String) {
        val toShared = AppPrefs.getBoolean(c, slot, "cookies_shared_pending", false)
        val toIsolated = AppPrefs.getBoolean(c, slot, "cookies_isolated_pending", false)
        if (!toShared && !toIsolated) return
        val label = if (toShared) "SANG chế độ chung" else "VỀ chế độ cô lập"
        try {
            val dbFile = File(profileDir, "cookies.sqlite")
            var moved = 0
            if (dbFile.isFile) {
                val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
                try {
                    db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { it.moveToFirst() }
                    val bak = File(profileDir, "cookies.sqlite.before_${if (toShared) "shared" else "isolated"}")
                    dbFile.copyTo(bak, overwrite = true)
                    DebugLog.log("CookieMode: đã sao lưu cookies.sqlite -> ${bak.name} (${bak.length()} byte)")
                    db.beginTransaction()
                    try {
                        if (toShared) {
                            val oas = ArrayList<String>()
                            db.rawQuery("SELECT DISTINCT originAttributes FROM moz_cookies", null).use { cur -> while (cur.moveToNext()) oas.add(cur.getString(0) ?: "") }
                            for (oa in oas) {
                                val m = RE.find(oa) ?: continue
                                if (decode(m.groupValues[1]) != contextIdFull) continue
                                val rest = oa.removePrefix("^").split("&").filter { it.isNotEmpty() && !it.startsWith("geckoViewUserContextId=") }
                                val newOa = if (rest.isEmpty()) "" else "^" + rest.joinToString("&")
                                val st = db.compileStatement("UPDATE OR REPLACE moz_cookies SET originAttributes = ? WHERE originAttributes = ?")
                                st.bindString(1, newOa); st.bindString(2, oa)
                                moved += st.executeUpdateDelete()
                            }
                        } else {
                            val st = db.compileStatement("UPDATE OR REPLACE moz_cookies SET originAttributes = ? WHERE originAttributes = ''")
                            st.bindString(1, "^geckoViewUserContextId=" + encode(contextIdFull))
                            moved = st.executeUpdateDelete()
                        }
                        db.setTransactionSuccessful()
                    } finally { db.endTransaction() }
                } finally { db.close() }
            }
            AppPrefs.setBoolean(c, slot, "cookies_shared_mode", toShared)
            AppPrefs.setBoolean(c, slot, "cookies_shared_pending", false)
            AppPrefs.setBoolean(c, slot, "cookies_isolated_pending", false)
            DebugLog.log("CookieMode: ĐÃ CHUYỂN $label — $moved cookie đổi vùng (contextId='$contextIdFull')")
        } catch (e: Throwable) {
            // Lỗi => KHÔNG đổi chế độ, giữ nguyên dữ liệu (đã có bản sao) để không làm mất đăng nhập.
            AppPrefs.setBoolean(c, slot, "cookies_shared_pending", false)
            AppPrefs.setBoolean(c, slot, "cookies_isolated_pending", false)
            DebugLog.log("CookieMode: chuyển $label THẤT BẠI ${e.javaClass.simpleName}: ${e.message} — giữ nguyên chế độ cũ")
        }
    }
}
