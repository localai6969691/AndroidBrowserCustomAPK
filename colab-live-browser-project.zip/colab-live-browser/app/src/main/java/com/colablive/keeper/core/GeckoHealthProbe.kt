package com.colablive.keeper.core

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.mozilla.geckoview.GeckoRuntime
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/**
 * Bản 7.82 — bộ ĐO để kết luận bằng dữ liệu, thay vì đoán, khi Gecko "treo" (trang không tải, ensureBuiltIn không trả về).
 *
 * Mỗi lần tạo engine, đo ở +0s/+5s/+15s/+45s:
 *  - `list()` của WebExtensionController: có trả về không, sau bao nhiêu ms. (Gecko phần cha còn trả lời hay không.)
 *  - eval_bridge đã đăng ký xong chưa (engine tự ghi mốc `evalBridgeRegisteredAtMs`).
 *  - Từng tiến trình của app (chính, tab*, gpu, utility...): pid, độ quan trọng, trạng thái /proc (S/R/D/T/Z), cgroup.
 *    Tiến trình con bị đóng băng/dừng/chết sẽ lộ ra ở đây.
 *  - Lý do thoát của các tiến trình CON trong 10 phút gần nhất (LOW_MEMORY, SIGNALED, FREEZER...).
 *
 * Đọc log: nếu `list()` trả về nhanh mà eval_bridge không đăng ký => lỗi nằm ở addon/tiến trình extension.
 * Nếu `list()` cũng không trả về => Gecko phần cha không phục vụ. Nếu tiến trình con vắng hoặc State=T/D => lỗi ở tiến trình con.
 */
object GeckoHealthProbe {
    private val main = Handler(Looper.getMainLooper())
    private val fmt get() = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private fun field(lines: List<String>, key: String): String =
        lines.firstOrNull { it.startsWith("$key:") }?.substringAfter(":")?.trim()?.replace(Regex("\\s+"), " ") ?: "?"

    /** Trạng thái 1 tiến trình qua /proc (cùng UID nên đọc được). Lỗi đọc thì ghi rõ lý do, không đoán. */
    private fun procInfo(pid: Int): String {
        val status = try { File("/proc/$pid/status").readLines() } catch (e: Throwable) { return "không đọc được /proc/$pid/status (${e.javaClass.simpleName})" }
        val cg = try { File("/proc/$pid/cgroup").readText().trim().lines().lastOrNull().orEmpty().take(80) } catch (e: Throwable) { "?" }
        return "State=${field(status, "State")} Threads=${field(status, "Threads")} VmRSS=${field(status, "VmRSS")} cgroup=[$cg]"
    }

    fun describeProcesses(context: Context): String {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val pkg = context.packageName
            val procs = (am.runningAppProcesses ?: emptyList()).filter { it.processName == pkg || it.processName.startsWith("$pkg:") }
            if (procs.isEmpty()) "không thấy tiến trình nào của app trong runningAppProcesses"
            else procs.sortedBy { it.processName }.joinToString(" ; ") {
                "${it.processName.removePrefix(pkg).ifEmpty { "chính" }.removePrefix(":")}(pid=${it.pid},imp=${it.importance}) ${procInfo(it.pid)}"
            }
        } catch (e: Throwable) { "describeProcesses lỗi ${e.javaClass.simpleName}: ${e.message}" }
    }

    /** Tiến trình CON của app đã thoát trong [windowMs] gần nhất, kèm lý do do Android ghi nhận (API 30+). */
    fun recentChildExits(context: Context, windowMs: Long = 10 * 60_000L): String {
        if (Build.VERSION.SDK_INT < 30) return "(API<30: không có lịch sử thoát)"
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val pkg = context.packageName
            val now = System.currentTimeMillis()
            val list = am.getHistoricalProcessExitReasons(pkg, 0, 40)
                .filter { it.processName != pkg && now - it.timestamp <= windowMs }
                .sortedBy { it.timestamp }
            if (list.isEmpty()) "không có tiến trình con nào thoát trong ${windowMs / 60_000}p"
            else list.joinToString(" ; ") {
                val why = when (it.reason) {
                    android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY"
                    android.app.ApplicationExitInfo.REASON_SIGNALED -> "SIGNALED(${it.status})"
                    android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE"
                    android.app.ApplicationExitInfo.REASON_CRASH -> "CRASH"
                    android.app.ApplicationExitInfo.REASON_EXIT_SELF -> "EXIT_SELF"
                    android.app.ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "DEPENDENCY_DIED"
                    android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE_RESOURCE"
                    android.app.ApplicationExitInfo.REASON_OTHER -> "OTHER"
                    else -> "reason=${it.reason}"
                }
                "${it.processName.removePrefix(pkg).removePrefix(":")}@${fmt.format(Date(it.timestamp))}=$why"
            }
        } catch (e: Throwable) { "recentChildExits lỗi ${e.javaClass.simpleName}: ${e.message}" }
    }

    /** Luồng Gecko phía Java (tên chứa "gecko"): chỉ ghi tên + trạng thái luồng, đủ để thấy có bị BLOCKED/WAITING bất thường. */
    private fun geckoThreads(): String = try {
        Thread.getAllStackTraces().keys.filter { it.name.contains("gecko", ignoreCase = true) }
            .joinToString(",") { "${it.name}:${it.state}" }.ifEmpty { "không thấy luồng 'gecko' nào" }
    } catch (e: Throwable) { "?" }

    /** Chụp trạng thái 1 lần, ghi thẳng vào log. [extra] là chuỗi mô tả thêm từ nơi gọi (VD trạng thái engine). */
    fun snapshot(context: Context, slotIndex: Int, tag: String, extra: String = "") {
        val up = try { SystemClock.elapsedRealtime() - android.os.Process.getStartElapsedRealtime() } catch (e: Throwable) { -1L }
        DebugLog.log("Khe $slotIndex: [sức khỏe Gecko] $tag | tiến trình sống ${up / 1000}s | $extra | luồng: ${geckoThreads()} | tiến trình: ${describeProcesses(context)} | con đã thoát: ${recentChildExits(context)}")
    }

    /**
     * Đo định kỳ sau khi tạo engine. [engineState] trả về chuỗi trạng thái hiện tại của engine (đọc lúc đo, không phải lúc gọi).
     * Không thay đổi hành vi gì của app — chỉ đọc và ghi log.
     */
    fun startBootProbe(context: Context, slotIndex: Int, runtime: GeckoRuntime, label: String, engineState: () -> String) {
        val appCtx = context.applicationContext
        val t0 = SystemClock.uptimeMillis()
        val listedAfter = AtomicLong(-1L)
        snapshot(appCtx, slotIndex, "BẮT ĐẦU ($label)", engineState())
        try {
            runtime.webExtensionController.list().accept({ l ->
                listedAfter.set(SystemClock.uptimeMillis() - t0)
                DebugLog.log("Khe $slotIndex: [sức khỏe Gecko] list() TRẢ VỀ sau ${listedAfter.get()}ms (${l?.size ?: 0} addon) — Gecko phần cha CÓ phục vụ")
            }, { e ->
                listedAfter.set(SystemClock.uptimeMillis() - t0)
                DebugLog.log("Khe $slotIndex: [sức khỏe Gecko] list() LỖI sau ${listedAfter.get()}ms: ${e?.message}")
            })
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [sức khỏe Gecko] không gọi được list(): ${e.javaClass.simpleName}: ${e.message}")
        }
        for (delayMs in longArrayOf(5_000L, 15_000L, 45_000L)) {
            main.postDelayed({
                val l = listedAfter.get()
                val listState = if (l >= 0) "list() đã trả về sau ${l}ms" else "list() CHƯA trả về sau ${delayMs / 1000}s"
                snapshot(appCtx, slotIndex, "+${delayMs / 1000}s ($label) $listState", engineState())
            }, delayMs)
        }
    }
}
