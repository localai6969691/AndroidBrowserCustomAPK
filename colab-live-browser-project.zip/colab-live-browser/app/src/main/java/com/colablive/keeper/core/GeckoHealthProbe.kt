package com.colablive.keeper.core

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.mozilla.geckoview.GeckoRuntime
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/**
 * Bản 7.82 — bộ ĐO để kết luận bằng dữ liệu, thay vì đoán, khi Gecko "treo" (trang không tải, ensureBuiltIn không trả về).
 *
 * Mỗi lần tạo engine, đo ở +0s/+5s/+15s/+45s:
 *  - `list()` của WebExtensionController: có trả về không, sau bao nhiêu ms. (Gecko phần cha còn trả lời hay không.)
 *  - eval_bridge đã đăng ký xong chưa (engine tự ghi mốc `evalBridgeRegisteredAtMs`).
 *  - Từng tiến trình của app (chính, tab*, gpu, utility...): pid, độ quan trọng, trạng thái /proc (S/R/D/T/Z), cgroup.
 *    Tiến trình con bị đóng băng/dừng/chết sẽ lộ ra ở đây.
 *  - Lý do thoát của các tiến trình CON trong 10 phút gần nhất (LOW_MEMORY, SIGNALED, FREEZER...).
 *
 * Đọc log: nếu `list()` trả về nhanh mà eval_bridge không đăng ký => lỗi nằm ở addon/tiến trình extension.
 * Nếu `list()` cũng không trả về => Gecko phần cha không phục vụ. Nếu tiến trình con vắng hoặc State=T/D => lỗi ở tiến trình con.
 */
object GeckoHealthProbe {
    private val main = Handler(Looper.getMainLooper())
    private val fmt get() = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private fun field(lines: List<String>, key: String): String =
        lines.firstOrNull { it.startsWith("$key:") }?.substringAfter(":")?.trim()?.replace(Regex("\\s+"), " ") ?: "?"

    /** Trạng thái 1 tiến trình qua /proc (cùng UID nên đọc được). Lỗi đọc thì ghi rõ lý do, không đoán. */
    private fun procInfo(pid: Int): String {
        val status = try { File("/proc/$pid/status").readLines() } catch (e: Throwable) { return "không đọc được /proc/$pid/status (${e.javaClass.simpleName})" }
        val cg = try { File("/proc/$pid/cgroup").readText().trim().lines().lastOrNull().orEmpty().take(80) } catch (e: Throwable) { "?" }
        return "State=${field(status, "State")} Threads=${field(status, "Threads")} VmRSS=${field(status, "VmRSS")} cgroup=[$cg]"
    }

    fun describeProcesses(context: Context): String {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val pkg = context.packageName
            val procs = (am.runningAppProcesses ?: emptyList()).filter { it.processName == pkg || it.processName.startsWith("$pkg:") }
            if (procs.isEmpty()) "không thấy tiến trình nào của app trong runningAppProcesses"
            else procs.sortedBy { it.processName }.joinToString(" ; ") {
                "${it.processName.removePrefix(pkg).ifEmpty { "chính" }.removePrefix(":")}(pid=${it.pid},imp=${it.importance}) ${procInfo(it.pid)}"
            }
        } catch (e: Throwable) { "describeProcesses lỗi ${e.javaClass.simpleName}: ${e.message}" }
    }

    /** Tiến trình CON của app đã thoát trong [windowMs] gần nhất, kèm lý do do Android ghi nhận (API 30+). */
    fun recentChildExits(context: Context, windowMs: Long = 10 * 60_000L): String {
        if (Build.VERSION.SDK_INT < 30) return "(API<30: không có lịch sử thoát)"
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val pkg = context.packageName
            val now = System.currentTimeMillis()
            val list = am.getHistoricalProcessExitReasons(pkg, 0, 40)
                .filter { it.processName != pkg && now - it.timestamp <= windowMs }
                .sortedBy { it.timestamp }
            if (list.isEmpty()) "không có tiến trình con nào thoát trong ${windowMs / 60_000}p"
            else list.joinToString(" ; ") {
                val why = when (it.reason) {
                    android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY"
                    android.app.ApplicationExitInfo.REASON_SIGNALED -> "SIGNALED(${it.status})"
                    android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE"
                    android.app.ApplicationExitInfo.REASON_CRASH -> "CRASH"
                    android.app.ApplicationExitInfo.REASON_EXIT_SELF -> "EXIT_SELF"
                    android.app.ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "DEPENDENCY_DIED"
                    android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE_RESOURCE"
                    android.app.ApplicationExitInfo.REASON_OTHER -> "OTHER"
                    else -> "reason=${it.reason}"
                }
                "${it.processName.removePrefix(pkg).removePrefix(":")}@${fmt.format(Date(it.timestamp))}=$why"
            }
        } catch (e: Throwable) { "recentChildExits lỗi ${e.javaClass.simpleName}: ${e.message}" }
    }

    /** Luồng Gecko phía Java (tên chứa "gecko"): chỉ ghi tên + trạng thái luồng, đủ để thấy có bị BLOCKED/WAITING bất thường. */
    private fun geckoThreads(): String = try {
        Thread.getAllStackTraces().keys.filter { it.name.contains("gecko", ignoreCase = true) }
            .joinToString(",") { "${it.name}:${it.state}" }.ifEmpty { "không thấy luồng 'gecko' nào" }
    } catch (e: Throwable) { "?" }

    /** Chụp trạng thái 1 lần, ghi thẳng vào log. [extra] là chuỗi mô tả thêm từ nơi gọi (VD trạng thái engine). */
    fun snapshot(context: Context, slotIndex: Int, tag: String, extra: String = "") {
        val up = try { SystemClock.elapsedRealtime() - android.os.Process.getStartElapsedRealtime() } catch (e: Throwable) { -1L }
        DebugLog.log("Khe $slotIndex: [sức khỏe Gecko] $tag | tiến trình sống ${up / 1000}s | $extra | luồng: ${geckoThreads()} | tiến trình: ${describeProcesses(context)} | con đã thoát: ${recentChildExits(context)}")
    }

    /**
     * Bản 7.89 — BẰNG CHỨNG "vì sao tab bị tải lại khi quay lại app": ghi một dòng mỗi lần quay về sau >= 20s ở nền, gồm số tab đang tải, trạng thái từng tiến trình của app
     * và các tiến trình CON đã thoát TRONG LÚC NỀN cùng lý do Android ghi nhận (LOW_MEMORY / SIGNALED(9) / FREEZER...). Đọc cùng dòng `[giải phóng tab nền]` (app tự bỏ tab) và `[CHẨN ĐOÁN ... kill]`
     * (Gecko báo tiến trình tab bị giết): có tiến trình con thoát vì LOW_MEMORY/SIGNALED => hệ điều hành giết; có `[giải phóng tab nền]` => chính sách của app; không có cả hai mà tab vẫn tải lại => nguyên nhân khác.
     */
    fun resumeSummary(context: Context, slotIndex: Int, backgroundMs: Long, engineState: String) {
        DebugLog.log("Khe $slotIndex: [quay lại app] đã ra nền ${backgroundMs / 1000}s | $engineState | tiến trình: ${describeProcesses(context)} | tiến trình con ĐÃ THOÁT lúc nền: ${recentChildExits(context, backgroundMs + 15_000L)}")
    }

    // ===== Bản 7.94 — BẰNG CHỨNG NGAY LÚC GECKO "ĐƠ" (nút Tải lại không làm trang nào bắt đầu tải) =====
    // Bộ đo 7.82 chỉ chạy ở +0/+5/+15/+45s sau khi mở engine, nên chưa bao giờ chụp được trạng thái ĐÚNG LÚC bị đơ (log người dùng 13:44–13:45: tiến trình mới sống 2 phút,
    // Tải lại 4 lần: `onLoadRequest` được app cho phép rồi KHÔNG có onPageStart/onLocationChange/onPageStop nào, và người dùng báo CẢ trình duyệt đơ, mọi trang đều không tải, chỉ vuốt tắt
    // mở lại mới hết). Các hàm dưới đây chỉ ĐỌC (/proc, /sys) và ghi log — không đổi hành vi.

    /** Mẫu thời gian CPU (tick hệ thống) của từng tiến trình và từng luồng của app tại một thời điểm. */
    class CpuMark(
        val atUptimeMs: Long,
        val procTicks: Map<Int, Long>,
        val procLabels: Map<Int, String>,
        val threadTicks: Map<String, Long>,  // "pid/tid" -> utime+stime
        val threadNames: Map<String, String> // "pid/tid" -> tên luồng (/proc/.../comm)
    )

    private fun clkTck(): Long = try {
        android.system.Os.sysconf(android.system.OsConstants._SC_CLK_TCK).let { if (it > 0) it else 100L }
    } catch (_: Throwable) { 100L }

    /** utime+stime (tick) từ một tệp /proc/.../stat; null nếu không đọc được. Tên lệnh có thể chứa khoảng trắng/ngoặc nên cắt sau dấu ')' CUỐI. */
    private fun statTicks(path: String): Long? = try {
        val s = File(path).readText()
        val rp = s.lastIndexOf(')')
        if (rp < 0) null else {
            val f = s.substring(rp + 2).split(' ')
            f[11].toLong() + f[12].toLong()
        }
    } catch (_: Throwable) { null }

    private fun appProcesses(context: Context): List<ActivityManager.RunningAppProcessInfo> = try {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pkg = context.packageName
        (am.runningAppProcesses ?: emptyList()).filter { it.processName == pkg || it.processName.startsWith("$pkg:") }
    } catch (_: Throwable) { emptyList() }

    private fun procLabel(context: Context, processName: String): String =
        processName.removePrefix(context.packageName).ifEmpty { "chính" }.removePrefix(":")

    /** Chụp CPU từng tiến trình + từng luồng. Đọc vài trăm tệp nhỏ trong /proc => gọi trên luồng nền, không gọi trên luồng giao diện. */
    fun cpuMark(context: Context): CpuMark {
        val pt = HashMap<Int, Long>()
        val pl = HashMap<Int, String>()
        val tt = HashMap<String, Long>()
        val tn = HashMap<String, String>()
        for (p in appProcesses(context)) {
            pl[p.pid] = procLabel(context, p.processName)
            statTicks("/proc/${p.pid}/stat")?.let { pt[p.pid] = it }
            val tids = try { File("/proc/${p.pid}/task").list() } catch (_: Throwable) { null } ?: continue
            for (tid in tids) {
                val key = "${p.pid}/$tid"
                statTicks("/proc/${p.pid}/task/$tid/stat")?.let { tt[key] = it }
                try { tn[key] = File("/proc/${p.pid}/task/$tid/comm").readText().trim() } catch (_: Throwable) {}
            }
        }
        return CpuMark(SystemClock.uptimeMillis(), pt, pl, tt, tn)
    }

    /**
     * CPU đã dùng từ mốc [from] đến bây giờ: mỗi tiến trình một mục `tên(pid)=Xms[luồng nóng nhất...]`.
     * Cách đọc: một luồng dùng gần hết cửa sổ (vd `Gecko=2900ms` trong 3s) => đang QUAY VÒNG (vòng lặp/tác vụ nặng); mọi tiến trình ~0ms => ĐỨNG IM (chờ khoá/IPC, hoặc bị đóng băng).
     */
    fun cpuDelta(context: Context, from: CpuMark): String {
        val now = cpuMark(context)
        val tck = clkTck()
        fun ms(ticks: Long) = ticks * 1000L / tck
        val windowMs = (now.atUptimeMs - from.atUptimeMs).coerceAtLeast(1L)
        val threadsByPid = now.threadTicks.entries.groupBy { it.key.substringBefore('/') }
        val parts = ArrayList<String>()
        for ((pid, label) in now.procLabels.entries.sortedBy { it.value }) {
            val cur = now.procTicks[pid]
            val old = from.procTicks[pid]
            if (cur == null || old == null) { parts.add("$label(pid=$pid)=${if (cur == null) "không đọc được" else "tiến trình MỚI"}"); continue }
            val hot = (threadsByPid[pid.toString()] ?: emptyList())
                .mapNotNull { e -> from.threadTicks[e.key]?.let { o -> Triple(now.threadNames[e.key] ?: e.key.substringAfter('/'), ms(e.value - o), e.key) } }
                .filter { it.second > 0L }
                .sortedByDescending { it.second }
                .take(3)
                .joinToString(",") { "${it.first}=${it.second}" }
            parts.add("$label(pid=$pid)=${ms(cur - old)}ms${if (hot.isEmpty()) "" else "[$hot]"}")
        }
        return "trong ${windowMs}ms: " + parts.joinToString(" ; ")
    }

    /**
     * Dấu hiệu tiến trình bị ĐÓNG BĂNG bởi hệ điều hành (cgroup freezer): `cgroup.events` có `frozen 1`, hoặc luồng chính đang chờ ở `do_freezer_trap`.
     * Không đọc được (bị SELinux chặn, không có tệp) thì ghi rõ loại lỗi — KHÔNG suy diễn.
     */
    fun freezeEvidence(context: Context): String =
        appProcesses(context).sortedBy { it.processName }.joinToString(" ; ") { p ->
            val cg = try { File("/proc/${p.pid}/cgroup").readText().trim().lines().lastOrNull().orEmpty().substringAfter("::") } catch (_: Throwable) { "" }
            val ev = if (cg.isEmpty()) "cgroup?" else try {
                val t = File("/sys/fs/cgroup$cg/cgroup.events").readText()
                "frozen=" + (Regex("frozen\\s+(\\d)").find(t)?.groupValues?.get(1) ?: "?")
            } catch (e: Throwable) { "events:${e.javaClass.simpleName}" }
            val wc = try { File("/proc/${p.pid}/wchan").readText().trim().take(30).ifEmpty { "-" } } catch (e: Throwable) { "wchan:${e.javaClass.simpleName}" }
            "${procLabel(context, p.processName)}=$ev,wchan=$wc"
        }

    /** Phần chứng cứ phía HỆ THỐNG cho một lần Gecko đơ: CPU từ [from], dấu hiệu đóng băng, trạng thái từng tiến trình, tiến trình con vừa thoát. Gọi trên luồng nền. */
    fun stallEvidence(context: Context, from: CpuMark?): String =
        "CPU ${if (from != null) cpuDelta(context, from) else "(không có mốc đầu)"} | đóng băng?: ${freezeEvidence(context)} | tiến trình: ${describeProcesses(context)} | con đã thoát (5p): ${recentChildExits(context, 5 * 60_000L)}"

    /**
     * Đo định kỳ sau khi tạo engine. [engineState] trả về chuỗi trạng thái hiện tại của engine (đọc lúc đo, không phải lúc gọi).
     * Không thay đổi hành vi gì của app — chỉ đọc và ghi log.
     */
    fun startBootProbe(context: Context, slotIndex: Int, runtime: GeckoRuntime, label: String, engineState: () -> String) {
        val appCtx = context.applicationContext
        val t0 = SystemClock.uptimeMillis()
        val listedAfter = AtomicLong(-1L)
        snapshot(appCtx, slotIndex, "BẮT ĐẦU ($label)", engineState())
        try {
            runtime.webExtensionController.list().accept({ l ->
                listedAfter.set(SystemClock.uptimeMillis() - t0)
                DebugLog.log("Khe $slotIndex: [sức khỏe Gecko] list() TRẢ VỀ sau ${listedAfter.get()}ms (${l?.size ?: 0} addon) — Gecko phần cha CÓ phục vụ")
            }, { e ->
                listedAfter.set(SystemClock.uptimeMillis() - t0)
                DebugLog.log("Khe $slotIndex: [sức khỏe Gecko] list() LỖI sau ${listedAfter.get()}ms: ${e?.message}")
            })
        } catch (e: Throwable) {
            DebugLog.log("Khe $slotIndex: [sức khỏe Gecko] không gọi được list(): ${e.javaClass.simpleName}: ${e.message}")
        }
        for (delayMs in longArrayOf(5_000L, 15_000L, 45_000L)) {
            main.postDelayed({
                val l = listedAfter.get()
                val listState = if (l >= 0) "list() đã trả về sau ${l}ms" else "list() CHƯA trả về sau ${delayMs / 1000}s"
                snapshot(appCtx, slotIndex, "+${delayMs / 1000}s ($label) $listState", engineState())
            }, delayMs)
        }
    }
}
