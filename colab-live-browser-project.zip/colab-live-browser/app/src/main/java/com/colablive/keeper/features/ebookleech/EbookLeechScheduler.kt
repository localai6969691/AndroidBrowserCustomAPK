package com.colablive.keeper.features.ebookleech

import android.content.Context
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.GeckoViewEngine
import com.colablive.keeper.features.ebookleech.engine.ChapterCache
import com.colablive.keeper.features.ebookleech.engine.EbookLeechCrawler
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpointRepository
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.model.LeechJobRepository
import com.colablive.keeper.features.ebookleech.service.EbookLeechProgressStore
import com.colablive.keeper.features.ebookleech.service.EbookLeechServiceLogic

/**
 * EbookLeechScheduler — được gọi từ vòng lặp nội bộ của EbookLeechService
 * (mỗi 30s) cho mọi slot đang bật. Cũng được UI gọi trực tiếp khi user bấm
 * "Chạy ngay" (MANUAL).
 *
 * Mỗi job chỉ có 1 crawler chạy tại một thời điểm — key theo "slotIndex:jobId"
 * vì nhiều slot có thể trùng jobId nếu copy cấu hình qua lại (phòng xa).
 */
object EbookLeechScheduler {

    private val activeJobs = mutableMapOf<String, EbookLeechCrawler>()
    private val activeRemoteJobs = mutableMapOf<String, com.colablive.keeper.features.ebookleech.remote.RemoteCrawlRunner>()
    private fun key(slotIndex: Int, jobId: String) = "$slotIndex:$jobId"

    // -------------------------------------------------------------------------

    fun tick(context: Context, slotIndex: Int) {
        val jobs = LeechJobRepository.loadAll(context, slotIndex)
        val now = System.currentTimeMillis()

        jobs.forEach { job ->
            if (job.status == LeechJob.JobStatus.RUNNING) return@forEach
            if (job.status == LeechJob.JobStatus.PAUSED) return@forEach
            if (job.status == LeechJob.JobStatus.NEEDS_ACTION) return@forEach  // chờ người dùng giải tay, KHÔNG tự chạy lại
            if (isDue(job, now)) startJob(context, slotIndex, job)
        }
    }

    fun isDue(job: LeechJob, now: Long): Boolean = when (job.scheduleMode) {
        LeechJob.ScheduleMode.MANUAL -> false
        LeechJob.ScheduleMode.INTERVAL -> (now - job.lastRunAt) >= job.intervalMinutes * 60_000L
        LeechJob.ScheduleMode.DAILY -> dayOf(job.lastRunAt) < dayOf(now)
    }

    /**
     * Chạy 1 job cụ thể.
     * @param resumeFromCheckpoint true = tìm checkpoint đã lưu (nếu có) và
     *   cào TIẾP đúng chỗ thay vì từ đầu — dùng cho luồng khôi phục sau khi
     *   app bị kill/crash (xem `resumeInterruptedJobs`). false (mặc định,
     *   dùng cho "Chạy ngay"/tick bình thường) = LUÔN chạy mới hoàn toàn,
     *   XOÁ checkpoint cũ nếu có — tránh trường hợp người dùng đã sửa lại
     *   selector/URL của job rồi bấm chạy lại, mà checkpoint cũ (cào theo
     *   cấu hình CŨ) lại âm thầm được dùng tiếp, gây sai lệch khó hiểu.
     */
    fun startJob(context: Context, slotIndex: Int, job: LeechJob, engine: GeckoViewEngine? = null, resumeFromCheckpoint: Boolean = false, isAppRestartRecovery: Boolean = false) {
        val jobKey = key(slotIndex, job.id)
        if (activeJobs.containsKey(jobKey)) return

        // Đảm bảo service (foreground, sống liên tục) đang chạy — kể cả khi
        // user bấm "Chạy ngay" trong lúc feature vừa mới bật chưa kịp tick.
        EbookLeechServiceLogic.ensureStarted(context, slotIndex) // 7.98: service theo khe (tiến trình của khe)

        val checkpoint = if (resumeFromCheckpoint) CrawlCheckpointRepository.load(context, slotIndex, job.id) else null
        if (!resumeFromCheckpoint) {
            CrawlCheckpointRepository.delete(context, slotIndex, job.id)
        }

        // Nếu đang khôi phục 1 job vẫn còn dừng chờ giải Cloudflare/captcha
        // (checkpoint.pausedAtIndex >= 0), GIỮ NGUYÊN status NEEDS_ACTION đã
        // có sẵn (không đổi thành RUNNING) — job thật sự chưa "chạy" gì cả,
        // chỉ đang chuẩn bị sẵn tab để chờ người dùng bấm nút giải xong.
        val isResumingPaused = checkpoint != null && checkpoint.pausedAtIndex >= 0
        if (!isResumingPaused) {
            LeechJobRepository.updateJob(context, slotIndex, job.copy(
                status = LeechJob.JobStatus.RUNNING,
                lastRunAt = if (resumeFromCheckpoint) job.lastRunAt else System.currentTimeMillis()
            ))
        }

        // ĐÃ THÊM — "Cào từ xa qua GitHub Actions": branch SỚM ở ĐÂY (TRƯỚC
        // khi cần `GeckoViewEngine.forSlot()`) — remote KHÔNG cần tab
        // GeckoView nào cả, đặt sau `resolvedEngine` sẽ vô tình bắt job
        // remote phải có 1 khe GeckoView đang sống mới chạy được, sai hoàn
        // toàn với lý do tồn tại của tính năng này. KHÔNG đụng gì luồng
        // cào tại máy bên dưới nếu job không bật remote.
        if (job.remoteBackend == "GITHUB" || job.remoteBackend == "COLAB") {
            val remoteRunner = com.colablive.keeper.features.ebookleech.remote.RemoteCrawlRunner(
                context = context, slotIndex = slotIndex, job = job,
                backend = job.remoteBackend,
                onProgress = { crawled, total, message ->
                    val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@RemoteCrawlRunner
                    LeechJobRepository.updateJob(context, slotIndex, current.copy(chaptersCollected = crawled))
                    EbookLeechProgressStore.update(slotIndex = slotIndex, jobId = job.id, jobName = job.name, phaseLabel = message, current = crawled, total = total)
                },
                onColabReady = { colabUrl ->
                    // ĐÃ THÊM — chỉ Colab dùng — lưu link vào pendingActionUrl
                    // (tái dùng field có sẵn, KHÔNG đổi status thành
                    // NEEDS_ACTION — job vẫn đang chạy bình thường, chỉ cần
                    // người dùng 1 lần mở link + bấm "Run all" bên Colab) để
                    // UI hiện nút "📓 Mở Colab" bất cứ lúc nào job còn RUNNING.
                    val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@RemoteCrawlRunner
                    LeechJobRepository.updateJob(context, slotIndex, current.copy(pendingActionUrl = colabUrl))
                },
                onInteractiveResult = { screenshotLocalPath, _ ->
                    // ĐÃ THÊM — kết quả 1 lệnh điều khiển từ xa (screenshot/
                    // click/type/...) vừa xử lý xong — cập nhật ảnh mới nhất
                    // vào ĐÚNG field UI đang đọc (pendingActionScreenshotPath),
                    // KHÔNG đổi status/reason/url (job vẫn NEEDS_ACTION như cũ,
                    // chỉ ảnh đổi). Bỏ qua nếu tải ảnh thất bại (đường dẫn rỗng)
                    // — giữ nguyên ảnh cũ thay vì xoá mất field đang có giá trị.
                    if (screenshotLocalPath.isNotEmpty()) {
                        val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@RemoteCrawlRunner
                        LeechJobRepository.updateJob(context, slotIndex, current.copy(pendingActionScreenshotPath = screenshotLocalPath))
                    }
                },
                onDone = { path ->
                    activeRemoteJobs.remove(jobKey)
                    EbookLeechProgressStore.clear(slotIndex, job.id)
                    val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@RemoteCrawlRunner
                    LeechJobRepository.updateJob(context, slotIndex, current.copy(status = LeechJob.JobStatus.DONE, outputFilePath = path))
                },
                onError = { msg ->
                    activeRemoteJobs.remove(jobKey)
                    EbookLeechProgressStore.clear(slotIndex, job.id)
                    val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@RemoteCrawlRunner
                    LeechJobRepository.updateJob(context, slotIndex, current.copy(status = LeechJob.JobStatus.ERROR, pendingActionReason = msg))
                },
                onNeedsManualAction = { screenshotPath, reason, blockedUrl ->
                    // ĐÃ THÊM — tái dùng ĐÚNG status NEEDS_ACTION đã có sẵn
                    // cho local, KHÔNG remove khỏi activeRemoteJobs (giống
                    // local giữ activeJobs) — resumeAfterManualSolve() bên
                    // dưới cần tìm lại đúng instance qua activeRemoteJobs[jobKey].
                    val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@RemoteCrawlRunner
                    LeechJobRepository.updateJob(context, slotIndex, current.copy(
                        status = LeechJob.JobStatus.NEEDS_ACTION,
                        pendingActionUrl = blockedUrl,
                        pendingActionReason = reason,
                        pendingActionScreenshotPath = screenshotPath,
                    ))
                    EbookLeechProgressStore.update(
                        slotIndex = slotIndex, jobId = job.id, jobName = job.name,
                        phaseLabel = "⚠️ (Từ xa) Cần xem lại thủ công — mở app để xem ảnh chụp màn hình",
                        current = current.chaptersCollected, total = 0,
                    )
                    EbookLeechServiceLogic.postManualActionAlert(context, job.name, blockedUrl, reason)
                    // ĐÃ THÊM — job có thể phải chờ LÂU ở trạng thái này
                    // (người dùng không mở app ngay) — tự sao lưu checkpoint
                    // hiện có ra Downloads (độc lập GitHub, xem
                    // EbookLeechBackupManager) NGAY LÚC NÀY, không đợi người
                    // dùng nhớ bấm tay. Bọc try-catch — lỗi backup không
                    // được làm hỏng luồng chính (job vẫn NEEDS_ACTION bình
                    // thường dù backup có lỗi).
                    try {
                        com.colablive.keeper.features.ebookleech.backup.EbookLeechBackupManager.exportToFile(context, slotIndex)
                    } catch (e: Exception) { /* không chặn luồng chính */ }
                },
            )
            activeRemoteJobs[jobKey] = remoteRunner
            // ĐÃ SỬA — phân biệt rõ 2 trường hợp hay bị nhầm chung 1 cờ:
            // `resumeFromCheckpoint` = "đã có checkpoint, coi là TIẾP TỤC
            // thay vì cào mới" (áp dụng CẢ khi chuyển job từ local sang
            // remote — RemoteCrawlRunner.start() ở nhánh không-resumeExisting
            // đã tự đẩy checkpoint cục bộ lên trước khi dispatch, xem đó).
            // `isAppRestartRecovery` = "app vừa khởi động lại, có 1 lần
            // chạy Actions ĐANG DỞ trên GitHub cần nối lại polling, KHÔNG
            // dispatch thêm" — CHỈ true khi gọi từ resumeInterruptedJobs().
            // Trước đây 2 khái niệm này dùng CHUNG resumeFromCheckpoint —
            // sai vì "▶ Chạy ngay"/resumeAfterManualSolve() cũng truyền
            // resumeFromCheckpoint=true nhưng KHÔNG có nghĩa "đang có lần
            // chạy dở trên GitHub cần nối lại" — findLatestRun() không lọc
            // theo job_id (giới hạn API GitHub), nối nhầm dễ bắt SAI lần
            // chạy (của job khác, hoặc lần chạy cũ đã xong từ lâu).
            remoteRunner.start(resumeExisting = isAppRestartRecovery)
            return
        }

        val resolvedEngine = engine ?: GeckoViewEngine.forSlot(slotIndex) ?: run {
            // Bản 7.98: ghi RÕ lý do. Mỗi khe chạy ở tiến trình riêng và engine GeckoView của khe chỉ tồn tại khi khe đang mở (MainActivity của khe đã dựng engine) —
            // job cào TẠI MÁY của khe chưa mở sẽ lỗi thế này; chế độ cào TỪ XA (GitHub/Colab) thì không cần engine.
            DebugLog.log("EbookLeech: khe $slotIndex chưa có GeckoView engine trong tiến trình này (khe chưa mở?) — job '${job.name}' => ERROR (cào tại máy cần khe đang mở)")
            LeechJobRepository.updateJob(context, slotIndex, job.copy(status = LeechJob.JobStatus.ERROR))
            return
        }

        val crawler = EbookLeechCrawler(
            context = context,
            slotIndex = slotIndex,
            engine = resolvedEngine,
            job = job,
            onProgress = { crawled, total, message ->
                val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@EbookLeechCrawler
                LeechJobRepository.updateJob(context, slotIndex, current.copy(chaptersCollected = crawled))
                EbookLeechProgressStore.update(
                    slotIndex = slotIndex, jobId = job.id, jobName = job.name,
                    phaseLabel = message, current = crawled, total = total,
                )
            },
            onJobUpdate = { updated ->
                // Crawler báo về dữ liệu học được giữa chừng (pattern phân
                // trang đã dò ra, endpoint AJAX phát hiện được) — merge vào
                // bản mới nhất trong repo (không ghi đè status/progress).
                val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@EbookLeechCrawler
                LeechJobRepository.updateJob(context, slotIndex, current.copy(
                    resolvedPaginationPattern = updated.resolvedPaginationPattern.ifBlank { current.resolvedPaginationPattern },
                    detectedAjaxEndpoints = if (updated.detectedAjaxEndpoints.isNotEmpty()) updated.detectedAjaxEndpoints else current.detectedAjaxEndpoints,
                ))
            },
            onDone = { path ->
                activeJobs.remove(jobKey)
                EbookLeechProgressStore.clear(slotIndex, job.id)
                val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@EbookLeechCrawler
                LeechJobRepository.updateJob(context, slotIndex, current.copy(
                    status = LeechJob.JobStatus.DONE,
                    outputFilePath = path
                ))
            },
            onReviewReady = { chapters ->
                activeJobs.remove(jobKey)
                EbookLeechProgressStore.clear(slotIndex, job.id)
                ChapterCache.put(slotIndex, job.id, chapters)
                val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@EbookLeechCrawler
                LeechJobRepository.updateJob(context, slotIndex, current.copy(
                    status = LeechJob.JobStatus.REVIEW_READY,
                    chaptersCollected = chapters.size,
                ))
            },
            onNeedsManualAction = { url, reason ->
                // KHÔNG remove khỏi activeJobs — crawler vẫn "sống", chỉ tạm
                // dừng chờ. resumeAfterManualSolve()/skipBlockedChapter() ở
                // dưới cần tìm lại đúng instance này qua activeJobs[jobKey].
                val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@EbookLeechCrawler
                LeechJobRepository.updateJob(context, slotIndex, current.copy(
                    status = LeechJob.JobStatus.NEEDS_ACTION,
                    pendingActionUrl = url,
                    pendingActionReason = reason,
                ))
                EbookLeechProgressStore.update(
                    slotIndex = slotIndex, jobId = job.id, jobName = job.name,
                    phaseLabel = "⚠️ Cần giải xác minh thủ công — mở app để xem trang và giải tay",
                    current = current.chaptersCollected, total = 0,
                )
                EbookLeechServiceLogic.postManualActionAlert(context, job.name, url, reason)
            },
            onError = { _ ->
                activeJobs.remove(jobKey)
                EbookLeechProgressStore.clear(slotIndex, job.id)
                val current = LeechJobRepository.getJob(context, slotIndex, job.id) ?: return@EbookLeechCrawler
                LeechJobRepository.updateJob(context, slotIndex, current.copy(status = LeechJob.JobStatus.ERROR))
            }
        )

        activeJobs[jobKey] = crawler
        if (checkpoint != null) crawler.resumeFromCheckpoint(checkpoint) else crawler.start()
    }

    /**
     * Quét mọi job đang RUNNING/NEEDS_ACTION mà có checkpoint tồn đọng —
     * nghĩa là lần chạy trước bị gián đoạn giữa chừng (app crash/bị kill,
     * KHÔNG phải người dùng chủ động dừng — dừng chủ động thì status đã
     * chuyển PAUSED từ trước). Gọi 1 lần khi EbookLeechService khởi động.
     */
    fun resumeInterruptedJobs(context: Context, slotIndex: Int) {
        val jobs = LeechJobRepository.loadAll(context, slotIndex)
        jobs.forEach { job ->
            val looksInterrupted = job.status == LeechJob.JobStatus.RUNNING || job.status == LeechJob.JobStatus.NEEDS_ACTION
            if (looksInterrupted && CrawlCheckpointRepository.exists(context, slotIndex, job.id)) {
                startJob(context, slotIndex, job, resumeFromCheckpoint = true, isAppRestartRecovery = true)
            }
        }
    }

    /**
     * Xuất ebook từ chapters đã cào sẵn trong ChapterCache (đường REVIEW_READY),
     * với job đã được UI cập nhật tocOverride theo cách người dùng sắp xếp.
     * Chạy trên thread riêng vì EbookExporter làm I/O (ghi file/ZIP).
     */
    fun exportFromReview(
        context: Context, slotIndex: Int, job: LeechJob,
        onDone: (String) -> Unit, onError: (String) -> Unit,
    ) {
        val chapters = ChapterCache.get(slotIndex, job.id)
        if (chapters == null) {
            onError("Dữ liệu đã cào không còn trong bộ nhớ (có thể app đã bị khởi động lại) — cần chạy lại job")
            return
        }
        Thread {
            try {
                val path = com.colablive.keeper.features.ebookleech.export.EbookExporter.export(context, job, chapters)
                ChapterCache.clear(slotIndex, job.id)
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    LeechJobRepository.updateJob(context, slotIndex, job.copy(
                        status = LeechJob.JobStatus.DONE, outputFilePath = path
                    ))
                    onDone(path)
                }
            } catch (e: Exception) {
                android.os.Handler(android.os.Looper.getMainLooper()).post { onError(e.message ?: "Lỗi không rõ") }
            }
        }.start()
    }

    /** UI gọi khi người dùng bấm "✅ Đã giải xong, tiếp tục" trên job đang NEEDS_ACTION. */
    fun resumeAfterManualSolve(context: Context, slotIndex: Int, jobId: String) {
        val jobKey = key(slotIndex, jobId)
        val job = LeechJobRepository.getJob(context, slotIndex, jobId) ?: return

        // ĐÃ THÊM — nhánh remote: "giải xong" ở đây nghĩa là người dùng đã
        // (có thể) cập nhật lại job.cookieHeader sau khi tự mở URL bị chặn
        // trong trình duyệt CỦA HỌ và giải/lấy cookie mới — bấm "Chạy lại"
        // sẽ dispatch 1 lần chạy Actions MỚI, Python tự đọc checkpoint cũ
        // (đã lưu đúng chapterProgressIndex của chương bị chặn) và THỬ LẠI
        // đúng chương đó trước, KHÔNG cào lại từ đầu. KHÔNG đảm bảo chắc
        // chắn qua được (xem giới hạn CAPTCHA thật/chặn theo IP trong
        // RemoteCrawlRunner.kt/crawler.py) — đây giờ CHỈ LÀ PHƯƠNG ÁN DỰ
        // PHÒNG (dispatch mới = IP mới = thường phải giải lại từ đầu nếu
        // site chặn theo IP). CÁCH TỐT HƠN — dùng khối "🖥️ Điều khiển
        // trình duyệt từ xa" trong UI (gửi lệnh resume_crawl qua git, giữ
        // nguyên session/IP đang bị chặn, không dispatch gì cả — xem
        // RemoteCrawlRunner.sendInteractiveAction()/handle_blocked_pause()
        // trong crawler.py) — ĐÃ LÀM, thay thế ý tưởng tunnel ban đầu (rủi
        // ro bảo mật cao hơn) bằng kênh git+token đã xác thực sẵn.
        if (job.remoteBackend == "GITHUB" || job.remoteBackend == "COLAB") {
            LeechJobRepository.updateJob(context, slotIndex, job.copy(
                status = LeechJob.JobStatus.RUNNING, pendingActionUrl = "", pendingActionReason = "", pendingActionScreenshotPath = "",
            ))
            // ĐÃ SỬA: resumeFromCheckpoint PHẢI là true — false sẽ XOÁ mất
            // checkpoint (đang giữ đúng tiến độ tới chỗ bị chặn) TRƯỚC KHI
            // RemoteCrawlRunner kịp đẩy nó lên GitHub (xem startJob() dòng
            // xoá checkpoint khi !resumeFromCheckpoint) — dispatch lại sẽ
            // cào lại từ đầu, đúng thứ job này đang cố tránh.
            startJob(context, slotIndex, job.copy(status = LeechJob.JobStatus.RUNNING), resumeFromCheckpoint = true)
            return
        }

        val crawler = activeJobs[jobKey]

        if (crawler == null) {
            // Crawler không còn sống trong RAM (app bị kill trong lúc đang
            // chờ) — nhưng checkpoint vẫn còn trên đĩa, dùng nó để dựng lại
            // crawler mới rồi thử lại NGAY, không bắt người dùng chạy lại
            // job từ đầu.
            if (CrawlCheckpointRepository.exists(context, slotIndex, jobId)) {
                startJob(context, slotIndex, job, resumeFromCheckpoint = true)
                // Job vừa dựng lại đang ở đúng trạng thái pausedAtIndex (từ
                // checkpoint) — gọi resume ngay trên instance mới tạo.
                activeJobs[jobKey]?.resumeAfterManualSolve()
            } else {
                LeechJobRepository.updateJob(context, slotIndex, job.copy(status = LeechJob.JobStatus.ERROR))
            }
            return
        }

        LeechJobRepository.updateJob(context, slotIndex, job.copy(
            status = LeechJob.JobStatus.RUNNING, pendingActionUrl = "", pendingActionReason = ""
        ))
        crawler.resumeAfterManualSolve()
    }

    /** UI gọi khi người dùng bấm "⏭ Bỏ qua chương này". */
    fun skipBlockedChapter(context: Context, slotIndex: Int, jobId: String) {
        val jobKey = key(slotIndex, jobId)
        val crawler = activeJobs[jobKey]
        val job = LeechJobRepository.getJob(context, slotIndex, jobId) ?: return

        if (crawler == null) {
            if (CrawlCheckpointRepository.exists(context, slotIndex, jobId)) {
                startJob(context, slotIndex, job, resumeFromCheckpoint = true)
                activeJobs[jobKey]?.skipBlockedChapter()
            }
            return
        }

        LeechJobRepository.updateJob(context, slotIndex, job.copy(
            status = LeechJob.JobStatus.RUNNING, pendingActionUrl = "", pendingActionReason = ""
        ))
        crawler.skipBlockedChapter()
    }

    /** UI gọi khi bấm "🔄 Đồng bộ ngay" trên 1 job remote đang chạy — bỏ
     * qua lịch chờ, tải checkpoint/ảnh mới nhất từ GitHub ngay lập tức. */
    fun syncRemoteNow(slotIndex: Int, jobId: String) {
        activeRemoteJobs[key(slotIndex, jobId)]?.syncNow()
    }

    fun cancelJob(context: Context, slotIndex: Int, jobId: String) {
        val jobKey = key(slotIndex, jobId)
        activeJobs[jobKey]?.cancel()
        activeJobs.remove(jobKey)
        activeRemoteJobs[jobKey]?.cancel()
        activeRemoteJobs.remove(jobKey)
        val job = LeechJobRepository.getJob(context, slotIndex, jobId) ?: return
        LeechJobRepository.updateJob(context, slotIndex, job.copy(status = LeechJob.JobStatus.PAUSED))
    }

    /** UI gọi để lấy RemoteCrawlRunner đang chạy cho job này (nếu có) —
     * dùng để gọi sendInteractiveAction() từ EbookLeechSettingsView. */
    fun getActiveRemoteRunner(slotIndex: Int, jobId: String): com.colablive.keeper.features.ebookleech.remote.RemoteCrawlRunner? {
        return activeRemoteJobs[key(slotIndex, jobId)]
    }

    /** Huỷ toàn bộ job của MỘT slot cụ thể (khi feature bị tắt ở slot đó). */
    fun cancelAllForSlot(context: Context, slotIndex: Int) {
        val toCancel = activeJobs.keys.filter { it.startsWith("$slotIndex:") }
        toCancel.forEach { k ->
            activeJobs[k]?.cancel()
            activeJobs.remove(k)
        }
        val toCancelRemote = activeRemoteJobs.keys.filter { it.startsWith("$slotIndex:") }
        toCancelRemote.forEach { k ->
            activeRemoteJobs[k]?.cancel()
            activeRemoteJobs.remove(k)
        }
    }

    /** Huỷ TẤT CẢ job của TẤT CẢ slot (dùng khi app bị kill hẳn / debug). */
    fun cancelAll(context: Context) {
        activeJobs.values.forEach { it.cancel() }
        activeJobs.clear()
        activeRemoteJobs.values.forEach { it.cancel() }
        activeRemoteJobs.clear()
    }

    private fun dayOf(ms: Long): Int {
        if (ms == 0L) return 0
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = ms
        return cal.get(java.util.Calendar.YEAR) * 1000 + cal.get(java.util.Calendar.DAY_OF_YEAR)
    }
}
