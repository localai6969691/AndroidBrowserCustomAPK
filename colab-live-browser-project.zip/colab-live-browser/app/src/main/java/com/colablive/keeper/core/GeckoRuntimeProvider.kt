package com.colablive.keeper.core

import android.content.Context
import org.json.JSONObject
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.WebExtension
import java.io.File

/**
 * Mỗi khe (process riêng) tự tạo 1 GeckoRuntime — đúng theo tài liệu chính
 * thức Mozilla: "GeckoRuntime can only be initialized once per process".
 *
 * Cô lập cookie/storage — 2 LỚP:
 *   1) `arguments(["-profile", <thư mục riêng của khe>, "-no-remote"])` —
 *      cờ dòng lệnh CHUẨN của Gecko/Firefox (xem tài liệu automation chính
 *      thức của GeckoView: args: [-profile, "/path"]), cho mỗi khe 1 thư
 *      mục hồ sơ Gecko RIÊNG BIỆT trên đĩa (cookies.sqlite, storage,
 *      permissions, cache... tách hẳn, không chỉ tách trong 1 hồ sơ dùng
 *      chung). "-no-remote" ngăn Gecko cố gắng dùng lại 1 instance khác
 *      đang chạy (quan trọng vì có NHIỀU tiến trình :slotN của CÙNG 1 app).
 *      ⚠️ CHƯA XÁC NHẬN TRÊN THIẾT BỊ THẬT — `-profile` là cờ chuẩn của
 *      Gecko nhưng KHÔNG có API public riêng (`GeckoRuntimeSettings` không
 *      có hàm `.profileDir()`) cho việc này trong ngữ cảnh nhúng Android
 *      (tài liệu chính thức mới thấy dùng trong automation/geckodriver) —
 *      cần build thật + kiểm tra log/file để xác nhận Gecko có thực sự ghi
 *      vào đúng thư mục này không, hay vẫn rơi về hồ sơ mặc định dùng
 *      chung. NẾU KHÔNG ăn, lớp 2 (contextId) vẫn còn tác dụng.
 *   2) `GeckoSessionSettings.Builder().contextId()` (xem GeckoViewEngine.kt)
 *      — cô lập cookie/storage theo "container" NGAY CẢ KHI dùng chung 1
 *      hồ sơ vật lý — đây là cơ chế CHẮC CHẮN có tác dụng (API công khai,
 *      không cần xác nhận thêm), nhưng chỉ cô lập storage theo-origin, KHÔNG
 *      cô lập permission/cache/profile-level prefs như lớp 1 nếu lớp 1 ăn.
 *
 * Proxy riêng theo khe: đăng ký WebExtension `proxy_config`
 * (assets/proxy_config/) dùng browser.proxy.onRequest — API CHUẨN của
 * WebExtension, xác nhận đúng hướng qua Mozilla bug 1525486 (đội Secure
 * Proxy: "có thể làm được bằng chính Proxy API sẵn có trong WebExtension").
 * KHÁC với việc DÙNG `arguments()` ĐỂ SET PROXY (đã xác nhận không hoạt
 * động qua báo lỗi công khai — không nhầm với việc dùng arguments() để set
 * `-profile` ở trên, đó là 2 việc khác nhau, `-profile` không liên quan gì
 * tới proxy).
 *
 * Background script (không phải content script) nên đăng ký message
 * delegate ở CẤP EXTENSION (`extension.setMessageDelegate`), không phải cấp
 * session như eval_bridge/fingerprint_spoof.
 */
object GeckoRuntimeProvider {
    private const val PROXY_CONFIG_LOCATION = "resource://android/assets/proxy_config/"
    private const val PROXY_CONFIG_ID = "proxy-config@colablive.internal"

    private val runtimes = mutableMapOf<Int, GeckoRuntime>()

    // Cho phép MainActivity truy cập runtime hiện có của 1 khe để gọi
    // `webExtensionController.install()` (tính năng cài addon từ file/URL
    // ngoài — xem `showAddonManagerDialog()` ở MainActivity.kt). Chỉ đọc,
    // không cho phép sửa map từ ngoài.
    fun getRuntime(slotIndex: Int): GeckoRuntime? = runtimes[slotIndex]
    private val dataDirs = mutableMapOf<Int, File>()

    /** Tên thư mục AN TOÀN trên đĩa ứng với 1 namespace hồ sơ — dùng chung ở
     * `createRuntime`, `clearSlotData`, `renameProfileDir` để 3 chỗ này
     * LUÔN tính ra đúng cùng 1 đường dẫn cho cùng 1 namespace (trước đây
     * mỗi hàm tự viết lại y hệt logic này riêng — dễ lệch nếu sửa 1 chỗ mà
     * quên chỗ khác). */
    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    // Mục 142 — GỐC của lỗi "Only one GeckoRuntime instance is allowed" lặp lại sau nhiều lượt sửa từng đường riêng lẻ:
    // GeckoRuntime là singleton của TIẾN TRÌNH; `shutdown()` không gỡ nó. Bất kỳ đường nào đóng khe (đổi chế độ cookie, Back thoát, đóng từ
    // Recent, import/export...) mà tiến trình còn sống rồi mở lại Activity trong CÙNG tiến trình đều va vào lỗi này. Thay vì chặn từng đường,
    // chốt ở nơi tạo runtime: nếu tiến trình đã từng tạo runtime thì KHÔNG đụng vào cookies.sqlite hay Gecko nữa, dựng lại tiến trình sạch.
    @Volatile private var runtimeEverCreatedInProcess = false

    private fun relaunchInFreshProcess(context: Context, slotIndex: Int, reason: String): Nothing {
        DebugLog.log("GeckoRuntimeProvider slot $slotIndex: [Mục 142] $reason — dựng lại TIẾN TRÌNH SẠCH (chưa đụng cookies.sqlite)")
        try {
            val prefs = context.getSharedPreferences("runtime_relaunch_guard", Context.MODE_PRIVATE)
            val last = prefs.getLong("last_relaunch_at", 0L)
            val now = System.currentTimeMillis()
            if (now - last < 8000L) {
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: [Mục 142] vừa dựng lại cách đây ${now - last}ms — KHÔNG lặp để tránh vòng vô hạn")
                throw IllegalStateException("Trình duyệt chưa đóng hẳn tiến trình cũ — vuốt đóng app khỏi Recent rồi mở lại. ($reason)")
            }
            prefs.edit().putLong("last_relaunch_at", now).commit()
            val intent = if (slotIndex == 0) {
                context.packageManager.getLaunchIntentForPackage(context.packageName)
            } else {
                android.content.Intent().setClassName(context.packageName, ProfileSlots.componentClassNameForSlot(slotIndex))
            }
            intent?.apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK or android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(com.colablive.keeper.MainActivity.EXTRA_SKIP_PICKER, true)
            }
            if (intent != null) context.startActivity(intent)
        } catch (e: IllegalStateException) {
            throw e
        } catch (e: Throwable) {
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: [Mục 142] dựng lại tiến trình lỗi: ${e.javaClass.simpleName}: ${e.message}")
        }
        // Bản 7.82: thoát bằng exit(0) TRƯỚC (Android ghi REASON_EXIT_SELF — đây là thoát CÓ CHỦ ĐÍCH). Trước đây killProcess đi trước nên Android ghi
        // REASON_SIGNALED(9) và `logPreviousProcessExits` in nhầm "BỊ GIẾT bằng signal 9 (bộ dọn RAM/OEM)" => đọc log lần sau dễ kết luận sai.
        try { CrashBreadcrumb.clear(context) } catch (_: Throwable) {}
        Runtime.getRuntime().exit(0)
        android.os.Process.killProcess(android.os.Process.myPid())
        throw IllegalStateException("unreachable")
    }

    @Synchronized
    fun get(context: Context, slotIndex: Int): GeckoRuntime {
        // Bản 7.82 — chốt chặn theo TRẠNG THÁI, không theo vòng đời Activity.
        // Bằng chứng (log 05:30:08–05:30:29, tiến trình KHÔNG đổi giữa 2 lần mở): khe đóng thật => engine.release() đóng hết tab, runtime vẫn nằm trong
        // map; lần mở sau tạo GeckoViewEngine MỚI trên runtime cũ đó thì: ensureBuiltIn(eval_bridge) không bao giờ trả về (lần sạch: 1860ms), không có
        // `content script CONNECT`, `capturePixels: Compositor must be ready`, trang không commit. Runtime ĐÃ BỊ RÚT SẠCH session KHÔNG phục vụ được engine mới.
        // Điều kiện nhận ra trạng thái này chỉ cần 2 vế: map còn runtime + không engine nào đang sở hữu nó (`forSlot` null vì release() đã gỡ).
        // Đường "Android huỷ rồi tạo lại Activity" KHÔNG qua đây (setupEngine tìm thấy engine sống và rebindView), nên không bị ảnh hưởng.
        // Chặn ở đây phủ MỌI đường đóng khe (vuốt Recent, Back, finish từ picker, hệ thống huỷ task...), không chỉ đường 7.81 bắt ở onDestroy.
        val old = runtimes[slotIndex]
        if (old != null && GeckoViewEngine.forSlot(slotIndex) == null) {
            try { GeckoHealthProbe.snapshot(context.applicationContext, slotIndex, "PHÁT HIỆN runtime rỗng bị bỏ lại", "map còn runtime, forSlot=null") } catch (_: Throwable) {}
            relaunchInFreshProcess(context, slotIndex, "runtime cũ còn trong tiến trình nhưng khe đã đóng thật (engine đã release) — runtime rỗng này không phục vụ được engine mới")
        }
        return runtimes.getOrPut(slotIndex) {
            createRuntime(context, slotIndex)
        }
    }

    /**
     * FIX BUG THẬT (người dùng xác nhận qua thử nghiệm: CHỈ 2 khe cùng mở
     * video YouTube là ĐÃ lỗi — không cần tới 4 khe) — xem chẩn đoán đầy đủ
     * ở `GeckoViewEngine.pollVideoDiagnostic()`: `readyState` kẹt ở 1,
     * `totalVideoFrames=0` mãi mãi dù `buffered` vẫn tăng đều (mạng tải
     * bình thường) — không hề có `error` nào.
     *
     * SỬA LẠI CHẨN ĐOÁN (người dùng chỉ đúng, lượt trước diễn giải quá tay):
     * đây KHÔNG phải phát hiện mới — `PROJECT_STATUS.md` đã tự đặt ra CHÍNH
     * giả thuyết "tranh chấp phần cứng giải mã" này từ trước (mục "8zzs") và
     * ĐÃ tự nghi ngờ lại chính nó sau khi tra thêm Bugzilla #1545817 + GitHub
     * mozilla/geckoview#203 ("phát nhiều video, video này bị gián đoạn khi
     * video kia phát" — xảy ra NGAY TRONG 1 TIẾN TRÌNH, 2 GeckoView cùng 1
     * activity). Lượt trước bỏ sót điểm quan trọng: nếu đây thật sự là giới
     * hạn "chip chỉ có N decoder phần cứng dùng chung cho MỌI app" thì 2 ỨNG
     * DỤNG KHÁC NHAU (trình duyệt + app phát nhạc/video khác) cũng phải
     * tranh nhau y hệt — nhưng thực tế (người dùng xác nhận) 2 app khác
     * nhau vẫn chồng chéo phát được bình thường. Việc chính GitHub issue
     * #203 ghi nhận lỗi này xảy ra NGAY TRONG GeckoView (kể cả cùng 1 tiến
     * trình) cho thấy nhiều khả năng đây là vấn đề nằm ở cách CHÍNH GeckoView
     * quản lý/tuần tự hoá tài nguyên giải mã cho MỖI SESSION nó tạo ra —
     * không phải một giới hạn phần cứng chia đều cho MỌI app trên máy như đã
     * viết quá tay trước đó.
     *
     * Vì vậy: đổi giải mã sang PHẦN MỀM (`media.hardware-video-decoding.
     * enabled=false`, xác nhận là pref THẬT qua chính test suite nội bộ
     * Mozilla trên searchfox.org, không suy đoán) vẫn là hướng giảm nhẹ HỢP
     * LÝ — né hẳn tài nguyên giải mã phần cứng mà GeckoView đang tranh chấp
     * với CHÍNH NÓ giữa các session/tiến trình của CÙNG app này, bất kể cơ
     * chế THẬT SỰ gây tranh chấp là gì (giới hạn phần cứng máy, hay hạn chế/
     * bug nội bộ GeckoView) — nhưng KHÔNG khẳng định đây là "giới hạn ROM/
     * chip dùng chung mọi app" như trước, vì bằng chứng thực tế không khớp
     * cách diễn giải đó. Đổi lại: TỐN CPU/PIN hơn hẳn so với phần cứng.
     *
     * Cách áp dụng AN TOÀN nhất (không đoán tên method Java theo đúng bài
     * học ở `createRuntime()` phía dưới — `GeckoRuntimeSettings` không có
     * hàm `setPreference(name, value)` chung, và API mới hơn như
     * `GeckoPreferenceController.setBoolPref` có thể chưa tồn tại ở bản pin
     * cứng 145.0.20251124145406, CHƯA XÁC NHẬN): dùng cơ chế
     * `GeckoRuntimeSettings.Builder.configFilePath()` — TỒN TẠI ổn định
     * xuyên suốt GeckoView từ rất lâu (Mozilla bug 1533385, năm 2019 — gần
     * như chắc chắn có mặt ở bản 145 pin cứng, khác hẳn rủi ro "javadoc
     * mozilla-central mới nhất" đã vấp phải trước đây), đọc 1 file YAML với
     * mục `prefs:` để set pref TRƯỚC khi Gecko khởi động.
     *
     * ⚠️ CHƯA XÁC NHẬN TRÊN THIẾT BỊ THẬT — cần build + test lại đúng kịch
     * bản "2 khe cùng phát" để biết chắc có hết bug không, và xem log
     * "GeckoRuntime I Adding debug configuration from: ..." trong logcat để
     * xác nhận Gecko THẬT SỰ đọc file này — KHÔNG suy luận thêm nếu chưa có
     * log/kết quả thật, y hệt tinh thần "chưa xác nhận" đã áp dụng cho cờ
     * `-profile` ở dưới.
     */
    // LƯU Ý: tên hàm giữ nguyên "SoftwareDecodeConfigFile" dù giờ ghi thêm
    // pref accessiblecaret không liên quan giải mã video — không đổi tên
    // để tránh động chạm chỗ khác không cần thiết, chỉ cần biết hàm này
    // giờ là "file cấu hình pref chung", không chỉ riêng giải mã video.
    private fun writeSoftwareDecodeConfigFile(context: Context): File {
        val f = File(context.filesDir, "gv-config.yaml")
        f.writeText(
            "prefs:\n" +
                "  media.hardware-video-decoding.enabled: false\n" +
                "  layout.accessiblecaret.caret_shown_when_long_tapping_on_empty_content: true\n" +
                // MỤC 70.5 PROJECT_STATUS.md: xem giải thích đầy đủ ở khối
                // user.js bên dưới (writeUserJsSoftwareDecodePref) — tắt hẳn
                // bộ kiểm tra chính tả nội tuyến của Gecko, thủ phạm thật rất
                // có khả năng gây "Colab đơ hoàn toàn sau khi dán text lớn".
                "  layout.spellcheckDefault: 0\n"
                // MỤC 83 PROJECT_STATUS.md — ĐÃ GỠ BỎ toàn bộ 6 pref
                // `layout.accessiblecaret.*` thêm ở mục 81 (enabled,
                // enabled_on_touch, always_tilt, extend_selection_for_phone_number,
                // hapticfeedback, script_change_update_mode). Người dùng
                // xác nhận: CÙNG 1 file backup, bản CŨ (trước mục 81) import
                // vẫn đăng nhập Google bình thường, bản MỚI (có mục 81) thì
                // bị văng đăng nhập — bằng chứng trực tiếp loại trừ giả
                // thuyết "backup thiếu do khoá lúc export" ở mục 82 (vì
                // CÙNG backup, chỉ đổi version app, kết quả khác nhau), và
                // chỉ thẳng vào mục 81 — thay đổi lớn nhất, mới nhất, đụng
                // trực tiếp vào cách Gecko xử lý SỰ KIỆN CẢM ỨNG toàn cục —
                // là nghi phạm hợp lý nhất (bật `accessiblecaret.enabled`
                // có thể làm nhiễu việc phân biệt tap/long-press ngay giữa
                // luồng đăng nhập Google nhiều bước chuyển hướng, khiến 1
                // bước xác nhận bị hiểu sai, phiên đăng nhập không hoàn tất
                // trọn vẹn). CHƯA XÁC NHẬN 100% đây là nguyên nhân — chỉ là
                // nghi phạm hợp lý nhất và rủi ro của việc GIỮ LẠI (mất
                // đăng nhập Google — nghiêm trọng) cao hơn hẳn lợi ích của
                // việc giữ (Copy/Cắt trong Colab — bất tiện nhưng không mất
                // dữ liệu người dùng), nên gỡ NGAY để dừng hồi quy trước,
                // xem PROJECT_STATUS.md mục 83 để biết bước xác nhận tiếp
                // theo.
        )
        return f
    }

    private fun createRuntime(context: Context, slotIndex: Int): GeckoRuntime {
        if (runtimeEverCreatedInProcess) {
            relaunchInFreshProcess(context, slotIndex, "tiến trình này đã có GeckoRuntime (khe đã đóng nhưng tiến trình còn sống)")
        }
        // Thư mục hồ sơ RIÊNG cho HỒ SƠ đang gán vào khe này (không phải cho
        // bản thân số khe — xem AppPrefs.kt giải thích đầy đủ lý do) —
        // truyền vào Gecko qua cờ dòng lệnh "-profile" (xem giải thích ở
        // comment lớp 1 phía trên class).
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val slotDataDir = File(context.filesDir, safeDirNameFor(profileNamespace))
        slotDataDir.mkdirs()
        dataDirs[slotIndex] = slotDataDir

        /**
         * BUG DO TÔI GÂY RA — ĐÃ THỬ 2 LẦN ĐỀU SAI, DỪNG LẠI Ở ĐÂY, KHÔNG
         * ĐOÁN LẦN 3 (người dùng chỉ đúng: đây là kiểu vá mù, dù có tra
         * cứu, vì tra SAI PHIÊN BẢN):
         *
         * Lần 1: đoán tên method `androidZygotePreloadEnabled` — sai, đã tự
         * phát hiện và gỡ trước khi build.
         * Lần 2: fetch thẳng trang javadoc gốc
         * mozilla.github.io/geckoview/javadoc/mozilla-central/... — tưởng
         * đã chắc chắn 100% vì đọc được chữ ký thật `appZygoteProcessEnabled`
         * — NHƯNG trang đó là bản "geckoview 156.0.20260823..." (mozilla-
         * central = bản NIGHTLY MỚI NHẤT), trong khi `app/build.gradle`
         * của CHÍNH dự án này pin CỨNG version 145.0.20251124145406 — lệch
         * 11 phiên bản. Method này khả năng cao được thêm SAU version 145,
         * không tồn tại trong bản project thực sự build — gây lỗi
         * "Unresolved reference 'appZygoteProcessEnabled'" thật trên CI.
         *
         * BÀI HỌC: mozilla-central javadoc LUÔN là bản mới nhất/nightly,
         * KHÔNG PHẢI tài liệu khớp với version PIN CỨNG trong build.gradle
         * — tra cứu "đúng trang chính thức" vẫn có thể sai nếu không khớp
         * đúng version đang dùng. Mozilla KHÔNG public sẵn javadoc tách
         * riêng theo từng version cũ tại 1 URL tĩnh dễ truy cập — không có
         * cách xác nhận chắc chắn 100% qua web mà không có chính file .aar
         * của geckoview:145.0.20251124145406 để giải nén/đọc trực tiếp
         * (cần Android Studio mở dependency đó, hoặc giải nén .aar thật).
         *
         * QUYẾT ĐỊNH: KHÔNG thêm `appZygoteProcessEnabled` (hay bất kỳ
         * tối ưu chưa xác nhận được đúng version nào khác) vào code nữa.
         * Nếu người dùng muốn bật tối ưu này, cách DUY NHẤT đáng tin: mở
         * project trong Android Studio, gõ `GeckoRuntimeSettings.Builder()`
         * rồi gõ `.`, để autocomplete hiện đúng danh sách method THẬT của
         * đúng bản .aar 145.0.20251124145406 đang nằm trong classpath — đó
         * là nguồn duy nhất khớp 100% với bản build thật, không phải web.
         */
        val configFile = writeSoftwareDecodeConfigFile(context)
        // FIX BUG THẬT (người dùng chỉ ra bằng chứng: log "TỰ KIỂM
        // configFilePath" báo KHÔNG thấy pref trong prefs.js ở CẢ 2 khe,
        // nhiều lần liên tiếp — không phải do chưa flush kịp, mà nhiều khả
        // năng `configFilePath()` THẬT SỰ không có tác dụng ở bản Gecko
        // 145 pin cứng này). Thêm 1 CƠ CHẾ THỨ HAI, cổ điển hơn và độc lập
        // hoàn toàn với `configFilePath()`: ghi thẳng file `user.js` vào
        // ĐÚNG thư mục hồ sơ (`slotDataDir`) — đây là cơ chế gốc của
        // Gecko/Firefox (không phải riêng GeckoView, dùng được từ rất lâu
        // đời, xuyên suốt mọi bản), TỰ ĐỘNG được đọc bởi bất kỳ tiến trình
        // Gecko nào khởi động với đúng thư mục hồ sơ đó — miễn `-profile`
        // (đã dùng ở dòng dưới) thật sự có tác dụng (mà log xác nhận CÓ —
        // dữ liệu mỗi khe tách biệt đúng theo tên hồ sơ). Ghi CẢ 2 cách
        // (configFilePath + user.js) — nếu 1 trong 2 có tác dụng là đạt
        // mục đích, không cần biết chính xác cách nào ăn.
        try {
            val userJs = File(slotDataDir, "user.js")
            // TÍNH NĂNG MỚI (người dùng chỉ ra ĐÚNG: kết luận "giới hạn
            // tầng Gecko, không có gì sửa được" ở mục 52.1 là VÔ THƯỞNG VÔ
            // PHẠT — cho qua chứ chưa thực sự thử hết cách). Đã tra cứu
            // web THẬT (searchfox.org, mã nguồn `geckoview-prefs.js` chính
            // thức của Mozilla) tìm ra đúng pref liên quan trực tiếp tới
            // đúng kịch bản người dùng chụp ảnh (long-tap vào Ô TRỐNG
            // trong cell Colab):
            // `layout.accessiblecaret.caret_shown_when_long_tapping_on_empty_content`
            // — theo mã nguồn Mozilla, pref này MẶC ĐỊNH ĐÃ = true trong
            // build GeckoView chuẩn, nên về lý thuyết không cần ép lại.
            // Nhưng ép RÕ RÀNG ở đây vẫn có giá trị thật (không phải hành
            // động vô nghĩa): (1) phòng trường hợp có pref KHÁC trong cấu
            // hình app này vô tình ghi đè/tắt nó mà chưa phát hiện ra, (2)
            // nếu ép xong mà vẫn KHÔNG hết bug, ĐÓ LÀ BẰNG CHỨNG MẠNH HƠN
            // hẳn để kết luận chắc chắn đây là giới hạn thật của Gecko cho
            // editor tuỳ biến (CodeMirror) chứ không phải do pref — biến
            // 1 kết luận suy đoán thành 1 kết luận có KIỂM CHỨNG.
            // CHƯA XÁC NHẬN có tác dụng thật hay không — cần test trên
            // thiết bị thật.
            val userJsContent = buildString {
                append("user_pref(\"media.hardware-video-decoding.enabled\", false);\n")
                append("user_pref(\"layout.accessiblecaret.caret_shown_when_long_tapping_on_empty_content\", true);\n")
                // MỤC 83 PROJECT_STATUS.md — ĐÃ GỠ BỎ HOÀN TOÀN 6 pref
                // `layout.accessiblecaret.*` (enabled, enabled_on_touch,
                // always_tilt, extend_selection_for_phone_number,
                // hapticfeedback, script_change_update_mode) thêm ở mục 81.
                // Người dùng xác nhận bằng chứng trực tiếp: CÙNG 1 file
                // backup, bản app CŨ (trước mục 81) import vẫn đăng nhập
                // Google bình thường, bản MỚI (có mục 81) bị văng đăng
                // nhập — loại trừ thẳng giả thuyết "backup thiếu do khoá
                // lúc export" (mục 82, vì cùng backup, chỉ đổi version app,
                // kết quả khác nhau) và chỉ thẳng vào đúng thay đổi ở mục
                // 81 — lớn nhất, mới nhất, đụng trực tiếp vào cách Gecko xử
                // lý SỰ KIỆN CẢM ỨNG toàn cục (bật `accessiblecaret.enabled`
                // có thể làm nhiễu việc phân biệt tap/long-press ngay giữa
                // luồng đăng nhập Google nhiều bước chuyển hướng). CHƯA xác
                // nhận 100% đây là nguyên nhân, nhưng rủi ro giữ lại (mất
                // đăng nhập — nghiêm trọng) cao hơn hẳn lợi ích giữ (Copy/
                // Cắt trong Colab — bất tiện, không mất dữ liệu), nên gỡ
                // ngay để dừng hồi quy. Xem PROJECT_STATUS.md mục 83.
                // MỤC 70.5 PROJECT_STATUS.md — FIX THẬT (không phải đoán):
                // tra lại đúng câu hỏi người dùng đặt ra ("bug 10 năm tuổi
                // chẳng lẽ không ai fix, sao không tra cách cộng đồng làm")
                // — Bugzilla #607921 trích dẫn trước đây thực ra ĐÃ ĐÓNG
                // "WORKSFORME" do 1 tiện ích mở rộng gây ra (AI Roboform
                // Toolbar), KHÔNG PHẢI bằng chứng đúng cho "giới hạn thật
                // của Gecko" như đã kết luận nhầm. Tra sâu hơn tìm ra
                // nguyên nhân CÓ CĂN CỨ KỸ THUẬT THẬT SỰ: bộ kiểm tra
                // chính tả nội tuyến của Gecko (`mozInlineSpellChecker`)
                // có thuật toán O(M*N) đã biết (Bugzilla #743819, #344895,
                // #1354641) — mỗi lần nội dung 1 vùng có thể sửa đổi thay
                // đổi (kể cả do PASTE 1 lượng lớn text), nó quét lại TOÀN
                // BỘ vùng đó để tô đỏ từ sai chính tả, có thể mất "vài
                // phút" đúng khớp triệu chứng "đơ" người dùng báo.
                //
                // Bằng chứng quan trọng: pref `layout.spellcheckDefault`
                // mặc định là `1` (bật, áp dụng cho textarea/contentEditable
                // nhiều dòng) ở TẦNG GECKO GỐC — chỉ app Firefox for Android
                // (Fenix) mới tự ghi đè về `0` qua file riêng của họ
                // (`mobile/android/app/geckoview-prefs.js`, xác nhận qua
                // searchfox.org). App này dùng THẲNG thư viện GeckoView gốc
                // (không phải Fenix), KHÔNG có file đó, nên rất có khả năng
                // đang chạy với spellcheck BẬT trên mọi ô nhập nhiều dòng —
                // bao gồm cả vùng input ẩn của Monaco/CodeMirror mà Colab
                // dùng. Ép về `0` ở đây là fix ĐÚNG NGUYÊN NHÂN GỐC (không
                // giống mục 70.4 — chỉ giảm nhẹ hậu quả), người dùng vẫn
                // không mất gì (đây là trình duyệt gõ code, không cần kiểm
                // tra chính tả). CHƯA build/test trên máy thật.
                append("user_pref(\"layout.spellcheckDefault\", 0);\n")
            }
            userJs.writeText(userJsContent)
            // FIX LỖ HỔNG LOGIC THẬT (đào sâu theo yêu cầu người dùng —
            // trước đây chỉ suy đoán "có thể tranh chấp tài nguyên", CHƯA
            // thực sự tra cứu tới cùng): tự-kiểm-tra cũ (dưới, khối
            // `Thread { ... prefs.js ... }`) đọc SAI FILE để xác nhận —
            // `prefs.js` là file GECKO TỰ GHI RA lúc ĐÓNG SẠCH (hoặc theo
            // 1 số mốc định kỳ khác), KHÔNG PHẢI lúc đang chạy; còn
            // `user.js` (file NÀY, cơ chế cổ điển Firefox/Gecko rất ổn
            // định, dùng xuyên suốt hàng chục năm) mới là file Gecko ĐỌC
            // LÚC KHỞI ĐỘNG để áp pref. Kiểm tra `prefs.js` trong lúc
            // runtime vẫn đang chạy sống gần như CHẮC CHẮN sẽ "không
            // thấy" bất kể `user.js` có ăn hay không — tự-kiểm-tra cũ dễ
            // gây hiểu lầm "pref có thể chưa ăn" trong khi thực ra chỉ là
            // đang hỏi nhầm file. SỬA: đọc lại NGAY chính `user.js` vừa
            // ghi (đồng bộ, không cần chờ Gecko làm gì cả — đây chỉ là
            // xác nhận BƯỚC GHI FILE của app tự nó có thành công hay
            // không, một nửa câu chuyện nhưng xác nhận được NGAY LẬP TỨC,
            // không cần đoán).
            val readback = userJs.readText()
            val writeOk = readback.contains("media.hardware-video-decoding.enabled") &&
                readback.contains("layout.accessiblecaret.caret_shown_when_long_tapping_on_empty_content") &&
                readback.contains("layout.spellcheckDefault")
            DebugLog.log(
                "GeckoRuntimeProvider slot $slotIndex: [TỰ KIỂM user.js] đọc lại NGAY sau khi ghi — " +
                    (if (writeOk) "ĐÚNG, có dòng pref trong file (bước GHI của app thành công — " +
                        "phần còn lại là Gecko có ĐỌC file này lúc khởi động hay không, cơ chế " +
                        "user.js là cơ chế gốc rất ổn định của Gecko nên khả năng cao có ăn, nhưng " +
                        "KHÔNG có cách xác nhận 100% từ phía app mà không có quyền truy cập " +
                        "about:config runtime — xem PROJECT_STATUS.md mục 49)"
                    else "SAI, KHÔNG thấy dòng pref sau khi đọc lại — bước GHI của app THẤT BẠI THẬT " +
                        "SỰ, cần điều tra tiếp (quyền ghi thư mục, disk đầy...)")
            )
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: đã ghi user.js ép giải mã phần mềm (cơ chế thứ 2, độc lập với configFilePath) tại ${userJs.absolutePath}")
        } catch (e: Exception) {
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: ghi user.js lỗi: ${e.message}")
        }
        val settings = GeckoRuntimeSettings.Builder()
            .consoleOutput(false)
            .aboutConfigEnabled(true)
            .arguments(arrayOf("-profile", slotDataDir.absolutePath, "-no-remote"))
            .configFilePath(configFile.absolutePath)
            // Mục 118: bật bộ tự điền đăng nhập CHÍNH CHỦ của Gecko (dùng `Autocomplete.StorageDelegate` đặt ở GeckoViewEngine). Gecko tự nhận
            // diện form (kể cả Google, kể cả tab ẩn danh) và không phụ thuộc extension eval_bridge có chạy trong tab ẩn danh hay không.
            .loginAutofillEnabled(true)
            .build()

        // Mục 121: khớp contextId với nơi cookie đăng nhập thật sự nằm (TRƯỚC khi Gecko mở cookies.sqlite) — xem ContextIdRecovery.
        try {
            val curCtx = "profile_" + ProfileSlots.getStableContextId(context, slotIndex)
            CookieModeMigration.runPending(context, slotIndex, slotDataDir, curCtx) // Mục 129
            CookieVault.applyPending(context, slotIndex, slotDataDir, curCtx, CookieModeMigration.isShared(context, slotIndex)) // Mục 130
            try { // Mục 136: ảnh chụp cookie đăng nhập Google LÚC KHỞI ĐỘNG (không ghi giá trị) — để phân biệt "cookie mất" với "Google từ chối"
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: [Cookie] cookie đăng nhập Google lúc KHỞI ĐỘNG (chỉ tên + hạn, không giá trị): " +
                    CookieVault.googleAuthHealth(context, slotDataDir, curCtx, CookieModeMigration.isShared(context, slotIndex)))
            } catch (e: Throwable) { /* chỉ là chẩn đoán */ }
            if (CookieModeMigration.isShared(context, slotIndex)) {
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: chế độ cookie CHUNG đang bật — không đặt contextId (addon thấy được cookie)")
            } else ContextIdRecovery.recover(context, slotDataDir, curCtx)?.let { newId ->
                File(slotDataDir, ".context_id").writeText(newId)
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: đã ghi .context_id='$newId' (contextId mới = 'profile_$newId')")
            }
        } catch (e: Throwable) {
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: ContextIdRecovery LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
        DebugLog.log("GeckoRuntimeProvider slot $slotIndex (hồ sơ '$profileNamespace'): bắt đầu GeckoRuntime.create() với -profile=${slotDataDir.absolutePath}")
        val runtime = try {
            GeckoRuntime.create(context, settings)
        } catch (e: Throwable) {
            // Không phải mọi lỗi native đều crash cứng process — 1 số lỗi
            // validate tham số vẫn ném exception JVM bắt được. Nếu vậy, thử
            // lại KHÔNG dùng cờ "-profile" (chưa xác nhận chắc chắn hoạt
            // động — xem PROJECT_STATUS.md mục "Lượt 3") thay vì để cả app
            // crash hẳn — cô lập vẫn còn contextId (lớp 2, chắc chắn hoạt
            // động) dù không có cô lập hồ sơ vật lý riêng (lớp 1).
            DebugLog.log("GeckoRuntimeProvider slot $slotIndex: GeckoRuntime.create() với -profile LỖI (${e.javaClass.simpleName}: ${e.message}) — thử lại KHÔNG có -profile")
            val fallbackSettings = GeckoRuntimeSettings.Builder()
                .consoleOutput(false)
                .aboutConfigEnabled(true)
                .configFilePath(configFile.absolutePath)
                .loginAutofillEnabled(true)
                .build()
            try {
                GeckoRuntime.create(context, fallbackSettings)
            } catch (e2: Throwable) {
                // Lượt thử lại (không -profile) CŨNG lỗi — thường là vì lỗi
                // gốc không liên quan gì tới "-profile" (ví dụ đúng là đã có
                // 1 GeckoRuntime khác trong process này, xem PROJECT_STATUS.md
                // mục "Only one GeckoRuntime instance"). Trước đây để lỗi này
                // BAY THẲNG lên ActivityThread → crash cứng cả app. Giờ log
                // rõ + ném lại 1 exception có thông điệp dễ hiểu hơn thay vì
                // im lặng nuốt lỗi (nuốt lỗi ở đây nguy hiểm hơn — app sẽ
                // chạy tiếp với engine null/half-broken).
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: fallback KHÔNG -profile CŨNG lỗi (${e2.javaClass.simpleName}: ${e2.message}) — không tạo được GeckoRuntime")
                if (e2 is IllegalStateException && (e2.message ?: "").contains("Only one GeckoRuntime")) {
                    relaunchInFreshProcess(context, slotIndex, "GeckoRuntime.create() báo đã có instance")
                }
                throw IllegalStateException(
                    "Không tạo được trình duyệt cho Khe $slotIndex (có thể do process cũ chưa kịp đóng hẳn — thử đóng hẳn app rồi mở lại). Lỗi gốc: ${e2.message}",
                    e2
                )
            }
        }
        runtimeEverCreatedInProcess = true
        DebugLog.log("GeckoRuntimeProvider slot $slotIndex: GeckoRuntime.create() XONG (không crash)")

        registerProxyExtensionIfConfigured(context, runtime, slotIndex)

        DebugLog.log(
            "GeckoRuntime slot $slotIndex: -profile=${slotDataDir.absolutePath} " +
                "(CHƯA XÁC NHẬN có ăn thật không — xem log Gecko/kiểm tra file trong " +
                "thư mục này sau khi duyệt web) + contextId isolation (GeckoViewEngine)"
        )

        // FIX BUG THẬT (người dùng chỉ đúng: "tại sao không tự log mà bắt
        // người dùng tự vào about:config kiểm tra") — TỰ đọc thẳng file
        // `prefs.js` trong đúng thư mục profile vừa dùng, tìm dòng pref
        // `media.hardware-video-decoding.enabled` (bản vá mục 34.4/36 ghi
        // qua `configFilePath()`), log lại kết quả THẬT — không cần người
        // dùng tự làm gì cả nữa. LƯU Ý ĐỘ TIN CẬY (nói rõ, không giấu):
        // Gecko không ghi `prefs.js` ngay lập tức lúc khởi động — chỉ ghi
        // khi có 1 số mốc nhất định (đóng runtime sạch, sau 1 khoảng thời
        // gian...) nên poll thử trong tối đa ~20s thay vì đọc 1 lần rồi kết
        // luận vội "không có" — vẫn có thể ra "chưa thấy" nếu Gecko thật sự
        // chưa flush kịp, không phải nghĩa là pref chưa ăn.
        Thread {
            val prefFile = File(slotDataDir, "prefs.js")
            var found = false
            repeat(10) { attempt ->
                Thread.sleep(2000)
                if (prefFile.exists()) {
                    try {
                        val line = prefFile.readLines()
                            .firstOrNull { it.contains("media.hardware-video-decoding.enabled") }
                        if (line != null) {
                            DebugLog.log("Slot $slotIndex: [TỰ KIỂM configFilePath] TÌM THẤY trong prefs.js (lần thử ${attempt + 1}/10): $line")
                            found = true
                            return@Thread
                        }
                    } catch (e: Exception) {
                        DebugLog.log("Slot $slotIndex: [TỰ KIỂM configFilePath] lỗi đọc prefs.js: ${e.message}")
                    }
                }
            }
            if (!found) {
                DebugLog.log("Slot $slotIndex: [TỰ KIỂM configFilePath qua prefs.js] KHÔNG thấy dòng 'media.hardware-video-decoding.enabled' sau 20s — ĐÂY LÀ KẾT QUẢ GẦN NHƯ CHẮC CHẮN SẼ XẢY RA (không phải dấu hiệu pref chưa ăn): prefs.js là file Gecko TỰ GHI RA lúc ĐÓNG SẠCH runtime (hoặc 1 số mốc định kỳ khác), KHÔNG PHẢI lúc runtime đang chạy sống — kiểm tra file này trong lúc app vẫn mở gần như luôn ra 'không thấy' bất kể pref có ăn hay không. Xem tự-kiểm-tra ĐÁNG TIN CẬY hơn ngay ở chỗ ghi user.js phía trên (đọc lại NGAY sau khi ghi, đồng bộ, không phụ thuộc Gecko flush gì cả) — đó mới là bằng chứng thật cho bước GHI. Muốn xác nhận 100% Gecko có THẬT SỰ đọc/áp dụng pref này lúc khởi động hay không thì vẫn cần vào about:config thủ công (xem PROJECT_STATUS.md mục 49).")
            }
        }.start()

        return runtime
    }

    // ===== Bản 7.66 — proxy áp dụng NGAY (không khởi động lại khe) =====
    // Trước đây cấu hình proxy chỉ được đẩy xuống addon lúc addon kết nối (khởi động khe) => đổi proxy phải khởi động lại. Nay giữ cổng native của addon và đẩy cấu hình
    // mới qua cổng đó bất cứ lúc nào (addon chọn proxy theo cấu hình MỚI NHẤT cho từng yêu cầu); chưa có addon (khe chưa từng có proxy) thì đăng ký addon ngay.
    // Lưu ý: kết nối TCP/HTTP2 đang mở có thể còn đi đường cũ vài giây — tải lại trang để chắc.
    private val proxyPorts = java.util.concurrent.ConcurrentHashMap<Int, WebExtension.Port>()
    private val proxyExts = java.util.concurrent.ConcurrentHashMap<Int, WebExtension>()
    /** Bản 7.70: addon proxy của khe đã NHẬN cấu hình (ack) chưa. Chưa => engine giữ mọi điều hướng http(s) (fail-closed) để IP thật không lộ lúc khởi động. */
    private val proxyReady = java.util.concurrent.ConcurrentHashMap<Int, Boolean>()
    /** Engine đặt hàm này để nạp lại các tab đang bị giữ khi proxy sẵn sàng (hoặc khi người dùng tắt chặn). */
    @Volatile var proxyReadyHook: ((Int) -> Unit)? = null
    /** MainActivity đặt hàm này để báo người dùng: state = "down" (proxy không phản hồi, đang chặn) / "up" (đã hoạt động lại). */
    @Volatile var proxyStateHook: ((Int, String, String) -> Unit)? = null

    fun isProxyReady(slotIndex: Int): Boolean = proxyReady[slotIndex] == true

    // ===== Bản 7.71 — ghép tab ẩn danh (Gecko tabId) với vùng của app =====
    // tabs API chỉ cho "firefox-private" ở mọi tab ẩn danh nên app BÁO TRƯỚC (expect_tab, seq) vùng của tab sắp mở; addon ghép FIFO với tab ẩn danh vừa tạo rồi trả tab_mapped(seq).
    private val tabSeq = java.util.concurrent.atomic.AtomicLong(0L)
    private val mappedSeqs: MutableSet<Long> = java.util.concurrent.ConcurrentHashMap.newKeySet<Long>()

    /** Có vùng ẨN DANH nào đang có quy tắc proxy/VPN riêng không (khi đó mọi tab ẩn danh phải được báo trước cho addon). */
    fun privateZoneRulesActive(context: Context, slotIndex: Int): Boolean =
        IncognitoZones.list(context, slotIndex).any { !it.persistent && (it.proxyMode in 2..3 || (it.proxyMode == 1 && it.proxyHost.isNotBlank() && it.proxyPort in 1..65535)) }

    /**
     * Báo addon tab ẩn danh sắp mở thuộc vùng [zoneId] ("" = ẩn danh chung). Trả: 0 = không cần (chưa có quy tắc vùng ẩn danh); >0 = số thứ tự đã gửi;
     * -1 = cần mà không gửi được (addon chưa nối) => engine giữ điều hướng của tab (fail-closed).
     */
    fun announcePrivateTab(context: Context, slotIndex: Int, zoneId: String): Long {
        if (!privateZoneRulesActive(context, slotIndex)) return 0L
        val port = proxyPorts[slotIndex]
        if (port == null) { DebugLog.log("Slot $slotIndex: [proxy vùng] cần báo tab ẩn danh (vùng='${zoneId.ifBlank { "-" }}') nhưng addon proxy chưa nối kênh"); return -1L }
        val seq = tabSeq.incrementAndGet()
        return try {
            port.postMessage(JSONObject().apply { put("type", "expect_tab"); put("seq", seq); put("zone", zoneId) })
            seq
        } catch (e: Throwable) { DebugLog.log("Slot $slotIndex: [proxy vùng] gửi expect_tab lỗi: ${e.message}"); -1L }
    }

    fun isTabMapped(seq: Long): Boolean = mappedSeqs.contains(seq)

    /**
     * Bản 7.70: tab loại này (thường/ẩn danh) có BẮT BUỘC đi qua proxy theo cấu hình hiện tại không (và công tắc chặn đang bật). Dùng để quyết định giữ điều hướng
     * khi addon chưa sẵn sàng. Chế độ ẩn danh "trực tiếp" (0) KHÔNG bị giữ vì người dùng chủ động chọn đi thẳng.
     */
    fun navigationNeedsProxy(context: Context, slotIndex: Int, isPrivateTab: Boolean, zoneId: String = ""): Boolean {
        if (!AppPrefs.getBoolean(context, slotIndex, "proxy_failclosed", true)) return false
        // Bản 7.71: vùng có quy tắc riêng — chế độ 1 (proxy riêng) BẮT BUỘC có proxy; chế độ 2/3 không (người dùng chủ động đi thẳng/để VPN addon).
        if (zoneId.isNotBlank()) {
            val z = IncognitoZones.get(context, slotIndex, zoneId)
            if (z != null) {
                when (z.proxyMode) {
                    1 -> return z.proxyHost.isNotBlank() && z.proxyPort in 1..65535
                    2, 3 -> return false
                }
            }
        }
        val hasMain = AppPrefs.getInt(context, slotIndex, "proxy_type", 0) != 0 &&
            AppPrefs.getString(context, slotIndex, "proxy_host", "").isNotEmpty() &&
            (AppPrefs.getString(context, slotIndex, "proxy_port", "0").toIntOrNull() ?: 0) != 0
        val privMode = AppPrefs.getInt(context, slotIndex, "proxy_priv_mode", 0)
        val hasPriv = privMode == 2 && AppPrefs.getString(context, slotIndex, "proxy_priv_host", "").isNotEmpty() &&
            (AppPrefs.getString(context, slotIndex, "proxy_priv_port", "0").toIntOrNull() ?: 0) != 0
        return if (isPrivateTab) (privMode == 1 && hasMain) || hasPriv else hasMain
    }

    fun probeEnabled(context: Context, slotIndex: Int): Boolean = AppPrefs.getBoolean(context, slotIndex, "proxy_probe", true)

    /** Tab ẩn danh: che bớt host khi ghi log dò để không lưu lịch sử duyệt ẩn danh vào file log (đủ để đối chiếu). */
    fun maskHostForProbe(host: String, isPrivate: Boolean): String =
        if (!isPrivate || host.length <= 6) host else host.substring(0, 2) + "~" + host.takeLast(4)

    /** Cấu hình proxy hiện tại của khe; null = không có proxy nào cần addon. Cặp thứ hai = 1 nếu addon cần được phép chạy trong ẩn danh (proxy ẩn danh 1/2 hoặc đang dò), ngược lại 0. */
    private fun buildProxyCfg(context: Context, slotIndex: Int): Pair<JSONObject, Int>? {
        val proxyType = AppPrefs.getInt(context, slotIndex, "proxy_type", 0)
        val host = AppPrefs.getString(context, slotIndex, "proxy_host", "")
        val proxyPort = AppPrefs.getString(context, slotIndex, "proxy_port", "0").toIntOrNull() ?: 0
        val hasMain = proxyType != 0 && host.isNotEmpty() && proxyPort != 0
        if (proxyType != 0 && !hasMain) DebugLog.log("Slot $slotIndex: proxy_type != Direct nhưng thiếu host/port của proxy khe")
        // Bản 7.65: proxy cho tab ẩn danh/vùng ẩn danh: 0 = trực tiếp (như cũ), 1 = dùng chung proxy của khe, 2 = proxy riêng.
        val privMode = AppPrefs.getInt(context, slotIndex, "proxy_priv_mode", 0)
        val pHost = AppPrefs.getString(context, slotIndex, "proxy_priv_host", "")
        val pPort = AppPrefs.getString(context, slotIndex, "proxy_priv_port", "0").toIntOrNull() ?: 0
        val hasPrivCustom = privMode == 2 && pHost.isNotEmpty() && pPort != 0
        // Bản 7.68: chế độ DÒ (chỉ ghi log) — nạp addon proxy KHÔNG đổi đường đi nào (enabled=false, privateMode=0) để thu `[dò proxy]`/`[dò tab]`
        // mà không cần đặt proxy trong app (người dùng dùng addon VPN riêng nên trước đây addon dò không bao giờ được nạp => log không có dòng nào).
        // Bản 7.70: dò MẶC ĐỊNH BẬT, hoàn toàn thụ động (không đổi đường đi nào), tự dừng khi đủ dữ liệu (addon báo `proxy_probe_done`) => người dùng không phải làm gì.
        val probeOnly = AppPrefs.getBoolean(context, slotIndex, "proxy_probe", true)
        // Bản 7.71: quy tắc proxy/VPN theo VÙNG (zones[id] = {m,t,h,p,u,w}); vùng chế độ 1 mà thiếu host/cổng bị bỏ qua.
        val zonesJson = JSONObject()
        var hasZoneRule = false
        var hasPrivZoneRule = false
        IncognitoZones.list(context, slotIndex).forEach { z ->
            if (z.proxyMode !in 1..3) return@forEach
            if (z.proxyMode == 1 && (z.proxyHost.isBlank() || z.proxyPort !in 1..65535)) return@forEach
            zonesJson.put(z.id, JSONObject().put("m", z.proxyMode).put("t", if (z.proxyType == 2) "socks" else "http")
                .put("h", z.proxyHost).put("p", z.proxyPort).put("u", z.proxyUser).put("w", z.proxyPass))
            hasZoneRule = true
            if (!z.persistent) hasPrivZoneRule = true
        }
        if (!hasMain && !hasPrivCustom && !probeOnly && !hasZoneRule) return null
        // Bản 7.70: FAIL-CLOSED — khe có proxy thì proxy chưa sẵn sàng/chết là KHÔNG có mạng (không bao giờ tự rơi về IP thật). Tắt được bằng công tắc.
        val hasZoneOwnProxy = IncognitoZones.list(context, slotIndex).any { it.proxyMode == 1 && it.proxyHost.isNotBlank() && it.proxyPort in 1..65535 }
        val failClosed = (hasMain || hasPrivCustom || hasZoneOwnProxy) && AppPrefs.getBoolean(context, slotIndex, "proxy_failclosed", true)
        val cfg = JSONObject().apply {
            put("enabled", hasMain)
            put("type", if (proxyType == 2) "socks" else "http")
            put("host", host)
            put("port", proxyPort)
            put("username", AppPrefs.getString(context, slotIndex, "proxy_user", ""))
            put("password", AppPrefs.getString(context, slotIndex, "proxy_pass", ""))
            put("privateMode", privMode)
            put("pType", if (AppPrefs.getInt(context, slotIndex, "proxy_priv_type", 1) == 2) "socks" else "http")
            put("pHost", pHost)
            put("pPort", pPort)
            put("pUser", AppPrefs.getString(context, slotIndex, "proxy_priv_user", ""))
            put("pPass", AppPrefs.getString(context, slotIndex, "proxy_priv_pass", ""))
            put("failClosed", failClosed)
            put("probe", probeOnly)
            put("zones", zonesJson)
            put("zonePriv", hasPrivZoneRule)
        }
        // Cặp thứ hai = "addon có được phép chạy trong ẩn danh không" (khác 0): chế độ proxy ẩn danh 1/2, HOẶC đang dò (để thấy cả tab ẩn danh; addon khi đó chỉ ghi log).
        return cfg to (if (privMode != 0 || probeOnly || hasPrivZoneRule) 1 else 0)
    }

    /** Bản 7.70c: giá trị "cho phép trong ẩn danh" đã áp trong tiến trình này — đổi quyền này KHỞI ĐỘNG LẠI addon (thấy ở log cookie_helper), nên chỉ gọi khi giá trị đổi, tránh vòng lặp nối→đổi quyền→khởi động lại→nối. */
    private val proxyPrivApplied = java.util.concurrent.ConcurrentHashMap<Int, Boolean>()

    private fun setProxyAllowedInPrivate(runtime: GeckoRuntime, extension: WebExtension, allowed: Boolean, slotIndex: Int) {
        if (proxyPrivApplied[slotIndex] == allowed) return
        proxyPrivApplied[slotIndex] = allowed
        // Addon CHỈ nhận được yêu cầu ẩn danh khi được phép chạy trong ẩn danh; chế độ 0 (trực tiếp) => không cho phép => ẩn danh đi thẳng.
        try {
            runtime.webExtensionController.setAllowedInPrivateBrowsing(extension, allowed).accept(
                { DebugLog.log("Slot $slotIndex: addon proxy ${if (allowed) "ĐƯỢC" else "KHÔNG"} phép chạy trong ẩn danh") },
                { t -> DebugLog.log("Slot $slotIndex: setAllowedInPrivateBrowsing(proxy) LỖI: ${t?.message}") }
            )
        } catch (e: Throwable) { DebugLog.log("Slot $slotIndex: setAllowedInPrivateBrowsing(proxy): ${e.message}") }
    }

    private fun registerProxyExtensionIfConfigured(context: Context, runtime: GeckoRuntime, slotIndex: Int) {
        if (buildProxyCfg(context, slotIndex) == null) { DebugLog.log("Slot $slotIndex: [proxy] không có proxy trong app và dò đã TẮT — không nạp addon proxy_config"); return }
        runtime.webExtensionController
            .ensureBuiltIn(PROXY_CONFIG_LOCATION, PROXY_CONFIG_ID)
            .accept(
                { extension ->
                    if (extension == null) { DebugLog.log("Slot $slotIndex: [proxy] ensureBuiltIn(proxy_config) TRẢ VỀ NULL — addon KHÔNG được nạp"); return@accept }
                    DebugLog.log("Slot $slotIndex: [proxy] addon proxy_config ĐÃ ĐĂNG KÝ — chờ addon nối kênh native (nó tự thử lại mỗi 2s)")
                    proxyExts[slotIndex] = extension
                    val messageDelegate = object : WebExtension.MessageDelegate {
                        override fun onConnect(port: WebExtension.Port) {
                            DebugLog.log("Slot $slotIndex: [proxy] addon proxy NỐI kênh native (onConnect)")
                            proxyPorts[slotIndex] = port
                            // Nhận tin dò của addon (xem proxy_config/background.js) để ghi log.
                            port.setDelegate(object : WebExtension.PortDelegate {
                                override fun onPortMessage(message: Any, port: WebExtension.Port) {
                                    try {
                                        val m = message as? JSONObject ?: return
                                        when (m.optString("type")) {
                                            "proxy_ack" -> {
                                                val first = proxyReady.put(slotIndex, true) != true
                                                DebugLog.log("Slot $slotIndex: [proxy] addon ĐÃ NHẬN cấu hình (ack, failClosed=${m.optBoolean("failClosed")})" + if (first) " — chốt chặn điều hướng MỞ" else "")
                                                if (first) try { proxyReadyHook?.invoke(slotIndex) } catch (_: Throwable) {}
                                            }
                                            "proxy_state" -> {
                                                val st = m.optString("state"); val er = m.optString("error")
                                                DebugLog.log("Slot $slotIndex: [proxy] " + if (st == "down") "⚠ PROXY KHÔNG PHẢN HỒI ($er) — fail-closed: ĐANG CHẶN, KHÔNG đi thẳng bằng IP thật; tự thử lại ở mỗi yêu cầu mới" else "✅ proxy đã hoạt động lại")
                                                try { proxyStateHook?.invoke(slotIndex, st, er) } catch (_: Throwable) {}
                                            }
                                            "tab_mapped" -> {
                                                mappedSeqs.add(m.optLong("seq"))
                                                DebugLog.log("Slot $slotIndex: [proxy vùng] tab ẩn danh seq=${m.optLong("seq")} ↔ tabId Gecko=${m.opt("tabId")} vùng='${m.optString("zone").ifBlank { "-" }}' — ghép xong, mở điều hướng")
                                                try { proxyReadyHook?.invoke(slotIndex) } catch (_: Throwable) {}
                                            }
                                            "http_headers" -> DebugLog.log("Slot $slotIndex: [HTTP THẬT] host=${m.optString("host")} vùng='${m.optString("zone").ifBlank { "-" }}' ẩn danh=${m.optBoolean("incognito")} tabId=${m.opt("tabId")} | Accept-Language='${m.optString("al")}' | User-Agent='${m.optString("ua").take(110)}'")
                                            "vpn_tap" -> DebugLog.log("Slot $slotIndex: [VPN tap] request tới ${m.optString("req")} (tabId=${m.opt("tabId")}, vùng='${m.optString("zone").ifBlank { "-" }}') đi qua proxy NGOÀI addon proxy_config: kiểu=${m.optString("ptype")} máy chủ=${m.optString("host")}:${m.opt("port")} có user=${m.opt("hasUser")} proxyDNS=${m.opt("dns")}")
                                            "zone_hit" -> DebugLog.log("Slot $slotIndex: [proxy vùng] ÁP DỤNG quy tắc vùng='${m.optString("zone")}' chế độ=${m.opt("mode")} cho tabId=${m.opt("tabId")} host=${m.optString("host")}")
                                            "proxy_probe_done" -> {
                                                val enough = m.optBoolean("enough")
                                                DebugLog.log("Slot $slotIndex: [dò proxy] TỔNG KẾT (${m.optString("reason")}): yêu cầu ẩn danh=${m.opt("inc")} thường=${m.opt("nonInc")} số tabId khác nhau=${m.opt("tabs")} sự kiện tab=${m.opt("tabEvents")} kho=[${m.optString("stores")}] — " +
                                                    if (enough) "ĐỦ dữ liệu, tự TẮT dò" else "CHƯA đủ (cần cả tab thường lẫn ẩn danh và ≥4 tabId) — giữ dò, thử lại ở lần mở sau")
                                                if (enough) { AppPrefs.setBoolean(context, slotIndex, "proxy_probe", false); applyProxyLiveInternal(context, slotIndex) }
                                            }
                                        }
                                        if (m.optString("type") == "proxy_probe_tab") {
                                            DebugLog.log("Slot $slotIndex: [dò tab] ${m.optString("kind")} tabId=${m.opt("tabId")} url=${m.optString("url")} ${m.optString("extra")}")
                                        }
                                        if (m.optString("type") == "proxy_probe") {
                                            DebugLog.log("Slot $slotIndex: [dò proxy] host=${m.optString("host")} cookieStoreId=${m.optString("cookieStoreId")} tabId=${m.opt("tabId")} ẩn danh=${m.opt("incognito")} loại=${m.optString("reqType")} trường=${m.optString("keys")}")
                                        }
                                    } catch (e: Throwable) { /* chỉ là chẩn đoán */ }
                                }
                                override fun onDisconnect(port: WebExtension.Port) { if (proxyPorts.remove(slotIndex, port)) { proxyReady.remove(slotIndex); DebugLog.log("Slot $slotIndex: [proxy] addon proxy MẤT kênh native — chờ nối lại (chốt chặn điều hướng đóng lại nếu cần proxy)") } }
                            })
                            val built = buildProxyCfg(context, slotIndex)
                            if (built != null) {
                                port.postMessage(JSONObject().apply { put("type", "proxy_config"); put("config", built.first) })
                                setProxyAllowedInPrivate(runtime, extension, built.second != 0, slotIndex)
                                DebugLog.log("Slot $slotIndex: đã đẩy cấu hình proxy xuống addon")
                            }
                        }
                    }
                    extension.setMessageDelegate(messageDelegate, "browser")
                },
                { error -> DebugLog.log("Slot $slotIndex: không đăng ký được proxy extension — $error" + if (navigationNeedsProxy(context, slotIndex, false) || navigationNeedsProxy(context, slotIndex, true)) " — FAIL-CLOSED: điều hướng http(s) sẽ bị CHẶN (tắt công tắc chặn trong cài đặt proxy nếu muốn đi thẳng)" else "") }
            )
        // Bản 7.70: cảnh báo nếu sau 15s addon vẫn chưa nhận cấu hình mà đang chặn điều hướng (để người dùng/log thấy lý do trang không tải).
        if (navigationNeedsProxy(context, slotIndex, false) || navigationNeedsProxy(context, slotIndex, true)) {
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (!isProxyReady(slotIndex)) DebugLog.log("Slot $slotIndex: [proxy] ⚠ sau 15s addon proxy CHƯA nhận cấu hình — điều hướng http(s) đang bị CHẶN (fail-closed). Kiểm tra log 'đăng ký proxy extension'.")
            }, 15_000L)
        }
    }

    /**
     * Bản 7.66: ÁP DỤNG proxy NGAY sau khi người dùng đổi cấu hình (không khởi động lại khe). Đã có cổng => đẩy cấu hình mới (cả "tắt proxy": enabled=false, privateMode=0);
     * chưa có addon mà cấu hình cần proxy => đăng ký addon. Trả về true nếu đã gửi/đăng ký.
     */
    /** Bản 7.66: MainActivity đặt hàm này để đo lại IP đi ra (và tự khớp múi giờ/ngôn ngữ) ngay sau khi proxy đổi. */
    @Volatile var proxyAppliedHook: ((Int) -> Unit)? = null

    fun applyProxyLive(context: Context, slotIndex: Int): Boolean {
        val ok = applyProxyLiveInternal(context, slotIndex)
        if (ok) try { proxyAppliedHook?.invoke(slotIndex) } catch (_: Throwable) {}
        return ok
    }

    private fun applyProxyLiveInternal(context: Context, slotIndex: Int): Boolean {
        val runtime = runtimes[slotIndex] ?: return false
        val built = buildProxyCfg(context, slotIndex)
        val port = proxyPorts[slotIndex]
        if (port != null) {
            val cfg = built?.first ?: JSONObject().apply { put("enabled", false); put("privateMode", 0) }
            port.postMessage(JSONObject().apply { put("type", "proxy_config"); put("config", cfg) })
            proxyExts[slotIndex]?.let { setProxyAllowedInPrivate(runtime, it, (built?.second ?: 0) != 0, slotIndex) }
            DebugLog.log("Slot $slotIndex: [proxy] ÁP DỤNG NGAY cấu hình mới (không khởi động lại) — ${if (built == null) "tắt proxy" else "có proxy"}")
            // Bản 7.70: nếu cấu hình mới không còn yêu cầu chặn (tắt proxy/tắt công tắc) thì nhả các tab đang bị giữ.
            try { proxyReadyHook?.invoke(slotIndex) } catch (_: Throwable) {}
            return true
        }
        if (built != null) { registerProxyExtensionIfConfigured(context, runtime, slotIndex); DebugLog.log("Slot $slotIndex: [proxy] đăng ký addon proxy ngay (chưa có lúc khởi động)"); return true }
        return false
    }

    fun getDataDir(slotIndex: Int): File? = dataDirs[slotIndex]

    /** Chỉ quên khỏi map — KHÔNG tắt native runtime (xem bug 8g: dùng hàm
     * này mà process không chết theo ngay sau đó sẽ gây crash "Only one
     * GeckoRuntime instance"). Giữ lại cho `releaseAll()`. Muốn đóng THẬT
     * (đảm bảo Gecko flush dữ liệu) và CHẮC CHẮN process sẽ chết ngay sau,
     * dùng `shutdown()` bên dưới thay vì hàm này. */
    fun release(slotIndex: Int) {
        runtimes.remove(slotIndex)
    }

    /**
     * Tắt hẳn GeckoRuntime — gọi `runtime.shutdown()` thật (API chuẩn của
     * GeckoView, dùng để đảm bảo mọi dữ liệu persistent — cookie, session
     * store — được flush xuống đĩa trước khi tiến trình chết), rồi mới quên
     * khỏi map. CHỈ được gọi khi CHẮC CHẮN tiến trình này sẽ bị kill/exit
     * ngay sau đó (hiện chỉ gọi từ `MainActivity`'s gracefulCloseReceiver,
     * bản thân broadcast đó chỉ được gửi từ
     * `ProfilePickerActivity.restartSlot()` — luôn kill/exit process ngay
     * sau khi nhận ACK) — nếu process còn sống tiếp mà gọi hàm này thì lần
     * tạo GeckoRuntime kế tiếp trong CHÍNH process đó sẽ bị Gecko từ chối
     * (đúng bug đã sửa ở mục 8g, chỉ là giờ đổi từ "quên mà không tắt"
     * thành "tắt nhưng process không chết" — TRIỆU CHỨNG GIỐNG NHAU).
     */
    fun shutdown(slotIndex: Int) {
        runtimes.remove(slotIndex)?.let { runtime ->
            try {
                runtime.shutdown()
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: runtime.shutdown() xong")
            } catch (e: Exception) {
                DebugLog.log("GeckoRuntimeProvider slot $slotIndex: lỗi khi shutdown runtime: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    fun releaseAll() {
        runtimes.clear()
        dataDirs.clear()
    }

    fun clearSlotData(context: Context, slotIndex: Int) {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, safeDirNameFor(profileNamespace))
        if (dir.exists()) {
            dir.deleteRecursively()
            DebugLog.log("Cleared Gecko profile data for '$profileNamespace' (slot $slotIndex)")
        }
    }

    /**
     * Đổi tên thư mục hồ sơ Gecko trên đĩa từ `oldNamespace` sang
     * `newNamespace` — dùng khi "đặt tên" dữ liệu đang có sẵn trong 1 khe
     * thành hồ sơ có tên (xem `ProfileSlots.schedulePromoteSlotData`).
     *
     * CHỈ được gọi từ `LiveBrowserApp.onCreate()` — TRƯỚC khi `get()`/
     * `createRuntime()` của khe đó từng chạy trong tiến trình này (tiến
     * trình vừa khởi động sạch), để chắc chắn không có GeckoRuntime nào
     * đang mở file trong thư mục bị đổi tên.
     */
    /** Mục 135: mô tả dữ liệu đang có trong thư mục hồ sơ `namespace` ("N file, X MB"); null = chưa có thư mục/không có file nào. */
    fun describeProfileData(context: Context, namespace: String): String? {
        val dir = File(context.filesDir, safeDirNameFor(namespace))
        if (!dir.isDirectory) return null
        var bytes = 0L
        var files = 0
        dir.walkTopDown().forEach { f -> if (f.isFile) { bytes += f.length(); files++ } }
        if (files == 0) return null
        return String.format(java.util.Locale.US, "%d file, %.1f MB", files, bytes / (1024.0 * 1024.0))
    }

    fun renameProfileDir(context: Context, oldNamespace: String, newNamespace: String, replaceExisting: Boolean = false) {
        if (oldNamespace == newNamespace) return
        val oldDir = File(context.filesDir, safeDirNameFor(oldNamespace))
        val newDir = File(context.filesDir, safeDirNameFor(newNamespace))
        // Mục 116: đưa dữ liệu khe vào hồ sơ có sẵn — xoá thư mục cũ của hồ sơ đích (người dùng đã xác nhận) rồi đổi tên. Chỉ xoá khi
        // thư mục nguồn thật sự tồn tại, để không mất dữ liệu đích mà chẳng có gì thay vào.
        if (replaceExisting && oldDir.exists() && newDir.exists()) {
            val deleted = newDir.deleteRecursively()
            DebugLog.log("renameProfileDir: xoá dữ liệu cũ của hồ sơ đích '$newNamespace' trước khi thay bằng dữ liệu khe → ${if (deleted) "OK" else "THẤT BẠI"}")
        }
        if (oldDir.exists() && !newDir.exists()) {
            val ok = oldDir.renameTo(newDir)
            DebugLog.log("renameProfileDir: '$oldNamespace' -> '$newNamespace' ${if (ok) "OK" else "THẤT BẠI"}")
        } else {
            DebugLog.log("renameProfileDir: bỏ qua (oldDir tồn tại=${oldDir.exists()}, newDir đã tồn tại=${newDir.exists()})")
        }
    }
}
