package com.colablive.keeper.core

import org.json.JSONArray
import org.json.JSONObject
import android.content.Context
import java.io.File

/**
 * TÍNH NĂNG MỚI (người dùng yêu cầu ở trang "Tab mới" — mục 88 — thêm dấu
 * "+" để TỰ đặt tiêu đề + trang web muốn truy cập nhanh, khác với shortcut
 * "hay truy cập" `NewTabPage.mostVisited()` tự tính từ lịch sử: cái đó có
 * thể đổi/mất khi thói quen duyệt web đổi, còn cái này người dùng CHỦ Ý
 * ghim, phải giữ lâu dài cho tới khi họ tự xoá).
 *
 * Đi theo ĐÚNG khuôn mẫu đã có của `BrowserBookmarks.kt`: JSON trong thư
 * mục hồ sơ Gecko, khoá `synchronized`, không giới hạn số lượng tự động
 * cắt bớt (giống bookmark, khác lịch sử) — vì đây cũng là dữ liệu người
 * dùng chủ ý lưu.
 */
object PinnedShortcuts {
    private val lock = Any()
    private const val MAX_PINNED = 16 // chỉ để tránh phình vô hạn nếu bấm nhầm liên tục, không phải giới hạn "tự động cắt" như lịch sử

    private fun safeDirNameFor(namespace: String) =
        "gecko_profile_" + namespace.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    private fun file(context: Context, slotIndex: Int): File {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, safeDirNameFor(profileNamespace))
        dir.mkdirs()
        return File(dir, "pinned_shortcuts.json")
    }

    private fun readArray(context: Context, slotIndex: Int): JSONArray {
        val f = file(context, slotIndex)
        if (!f.exists()) return JSONArray()
        return try { JSONArray(f.readText()) } catch (e: Exception) { JSONArray() }
    }

    private fun writeArray(context: Context, slotIndex: Int, arr: JSONArray) {
        val f = file(context, slotIndex)
        val tmp = File(f.parentFile, "pinned_shortcuts.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(f)
    }

    data class Pinned(val title: String, val url: String)

    fun list(context: Context, slotIndex: Int): List<Pinned> = synchronized(lock) {
        try {
            val arr = readArray(context, slotIndex)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val url = o.optString("url")
                if (url.isBlank()) null else Pinned(o.optString("title").ifBlank { url }, url)
            }
        } catch (e: Exception) { emptyList() }
    }

    /** Thêm mới — nếu URL đã ghim rồi thì chỉ cập nhật tiêu đề (không tạo trùng). */
    fun add(context: Context, slotIndex: Int, title: String, url: String) {
        if (url.isBlank()) return
        synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optString("url") == url) {
                        o.put("title", title.ifBlank { url })
                        writeArray(context, slotIndex, arr)
                        return
                    }
                }
                arr.put(JSONObject().apply {
                    put("title", title.ifBlank { url })
                    put("url", url)
                })
                // Cắt bớt mục CŨ NHẤT nếu vượt MAX_PINNED — chỉ để tránh phình vô
                // hạn do bấm nhầm/lỗi lặp, không phải hành vi "tự động dọn" như
                // lịch sử (số lượng này đủ lớn để không ai chạm tới trong dùng
                // bình thường).
                while (arr.length() > MAX_PINNED) arr.remove(0)
                writeArray(context, slotIndex, arr)
            } catch (e: Exception) { /* mất 1 lần ghim không nghiêm trọng, bỏ qua */ }
        }
    }

    fun remove(context: Context, slotIndex: Int, url: String) {
        if (url.isBlank()) return
        synchronized(lock) {
            try {
                val arr = readArray(context, slotIndex)
                val kept = JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optString("url") != url) kept.put(o)
                }
                writeArray(context, slotIndex, kept)
            } catch (e: Exception) { /* bỏ qua */ }
        }
    }

    /**
     * TÍNH NĂNG MỚI (người dùng yêu cầu): dấu "x" cũng phải xoá được cho
     * shortcut TỰ TÍNH từ lịch sử (không chỉ shortcut đã ghim) — nhưng
     * shortcut tự tính không phải 1 bản ghi cố định để "xoá" (nó tự tính
     * lại mỗi lần từ `BrowserHistory`, hôm nay ẩn thì domain đó vẫn còn
     * trong lịch sử, mai tính lại vẫn ra y hệt). Cách đúng: lưu 1 danh
     * sách "origin đã ẩn khỏi Tab mới" riêng — `NewTabPage.mostVisited()`
     * lọc bỏ origin nào nằm trong danh sách này trước khi trả kết quả.
     * Đi CÙNG khuôn mẫu file JSON như `list()`/`add()`/`remove()` ở trên,
     * chỉ khác tên file — không lẫn với danh sách ghim (ý nghĩa khác hẳn:
     * ghim = "luôn hiện", ẩn = "không bao giờ tự đề xuất nữa").
     */
    private fun hiddenFile(context: Context, slotIndex: Int): File {
        val profileNamespace = ProfileSlots.getSlotAssignment(context, slotIndex)
        val dir = File(context.filesDir, safeDirNameFor(profileNamespace))
        dir.mkdirs()
        return File(dir, "hidden_auto_shortcuts.json")
    }

    fun hiddenOrigins(context: Context, slotIndex: Int): Set<String> = synchronized(lock) {
        try {
            val f = hiddenFile(context, slotIndex)
            if (!f.exists()) return@synchronized emptySet()
            val arr = JSONArray(f.readText())
            (0 until arr.length()).mapNotNull { arr.optString(it, null) }.toSet()
        } catch (e: Exception) { emptySet() }
    }

    fun hideOrigin(context: Context, slotIndex: Int, origin: String) {
        if (origin.isBlank()) return
        synchronized(lock) {
            try {
                val current = hiddenOrigins(context, slotIndex).toMutableSet()
                current.add(origin)
                val arr = JSONArray()
                current.forEach { arr.put(it) }
                val f = hiddenFile(context, slotIndex)
                val tmp = File(f.parentFile, "hidden_auto_shortcuts.json.tmp")
                tmp.writeText(arr.toString())
                tmp.renameTo(f)
            } catch (e: Exception) { /* bỏ qua */ }
        }
    }
}
