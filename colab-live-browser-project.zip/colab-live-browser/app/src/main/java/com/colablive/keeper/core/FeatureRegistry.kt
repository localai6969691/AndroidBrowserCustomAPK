package com.colablive.keeper.core

import android.content.Context
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import com.colablive.keeper.features.downloads.DownloadManagerFeature
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import com.colablive.keeper.features.media.BackgroundMediaFeature
import com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature

object FeatureRegistry {
    // Thêm tiện ích mới ở đây khi phát triển thêm — chỉ 1 dòng, không sửa gì khác.
    val features: List<BrowserFeature> = listOf(
        ColabLiveKeeperFeature,
        DownloadManagerFeature,
        FingerprintSpoofFeature,
        BackgroundMediaFeature,
        BackgroundKeepAliveFeature
    )

    /** Alias của `features` — nhiều chỗ gọi code (MainActivity, DownloadManagerFeature)
     * dùng tên `all()`, giữ cả 2 tên để không phải sửa lại toàn bộ call site. */
    fun all(): List<BrowserFeature> = features

    fun enabledFeatures(context: Context, slotIndex: Int): List<BrowserFeature> =
        features.filter { it.isEnabled(context, slotIndex) }
}
