package com.colablive.keeper.core

import android.content.Context
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import com.colablive.keeper.features.downloads.DownloadManagerFeature
import com.colablive.keeper.features.ebookleech.EbookLeechFeature
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import com.colablive.keeper.features.media.BackgroundMediaFeature
import com.colablive.keeper.features.media.VideoStreamFeature
import com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature

object FeatureRegistry {
    // Thêm tiện ích mới ở đây khi phát triển thêm — chỉ 1 dòng, không sửa gì khác.
    // Bản 7.98: thêm EbookLeechFeature (addon cào ebook) ở chế độ NHÚNG — biên dịch thẳng vào :app (xem PluginLoader.kt).
    private val residentFeatures: List<BrowserFeature> = listOf(
        ColabLiveKeeperFeature,
        DownloadManagerFeature,
        FingerprintSpoofFeature,
        BackgroundMediaFeature,
        VideoStreamFeature,
        BackgroundKeepAliveFeature,
        EbookLeechFeature
    )

    // Feature nạp động từ file .jar ngoài APK (cơ chế PluginLoader). Chế độ nhúng KHÔNG quét jar lúc khởi động
    // (`init()` không được gọi ở LiveBrowserApp) — danh sách này rỗng trừ khi ai đó gọi `init(context)` thủ công.
    private var pluginFeatures: List<BrowserFeature> = emptyList()

    /** Quét/nạp lại plugin .jar (nếu có). Feature trùng `id` với feature cứng bị bỏ qua — bản trong APK luôn thắng. */
    fun init(context: Context) {
        pluginFeatures = PluginLoader.scanAndLoad(context)
    }

    val features: List<BrowserFeature>
        get() = residentFeatures + pluginFeatures.filter { p -> residentFeatures.none { it.id == p.id } }

    /** Alias của `features` — nhiều chỗ gọi code (MainActivity, DownloadManagerFeature)
     * dùng tên `all()`, giữ cả 2 tên để không phải sửa lại toàn bộ call site. */
    fun all(): List<BrowserFeature> = features

    fun enabledFeatures(context: Context, slotIndex: Int): List<BrowserFeature> =
        features.filter { it.isEnabled(context, slotIndex) }
}
