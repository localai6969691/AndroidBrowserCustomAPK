package com.colablive.keeper.features.colab

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.colablive.keeper.MainActivity
import com.colablive.keeper.MainActivitySlot1
import com.colablive.keeper.MainActivitySlot2
import com.colablive.keeper.MainActivitySlot3
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.DebugLog
import com.colablive.keeper.core.GeckoStallWatchdog
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Mục 125: GIÁM SÁT TRẠNG THÁI COLAB.
 *
 * `content.js` (hàm `lbColab`) chạy trong CHÍNH trang Colab, đọc thanh trạng thái / nút kết nối / hộp thoại và gửi `colab_status` về app khi
 * trạng thái đổi + nhịp tim ~45s. Lớp này: giữ trạng thái từng tab, phát hiện chuyển trạng thái xấu để BÁO ĐỘNG, phát hiện trang IM LẶNG (không còn nhịp
 * tim — trang treo/bị tiến trình Gecko thu hồi), và tạo dòng tóm tắt hiện trên thông báo "Đang giữ kết nối".
 *
 * Trạng thái: running | idle | connecting | error | crashed | disconnected | timeout | quota | silent | unknown.
 */
object ColabMonitor {
    private const val CHANNEL_ALARM = "colab_alarm"
    private const val CHANNEL_INFO = "colab_info"
    // Mục 129: ảnh chụp thông báo "KHÔNG PHẢN HỒI (trang treo?)" hiện khi khe không mở Colab. 150s quá ngắn (tab nền bị Gecko giãn nhịp) và trạng thái này chỉ
    // nghĩa "mất liên lạc với bộ giám sát", chưa chắc Colab hỏng => 5 phút, và chỉ BÁO ĐỘNG khi người dùng đã bật Colab Live; còn lại chỉ ghi chữ nhẹ.
    private const val SILENT_AFTER_MS = 300_000L

    class Status(
        val tabId: String,
        var state: String = "unknown",
        var detail: String = "",
        var elapsed: String = "",
        var runtime: String = "",
        var errors: Int = 0,
        var url: String = "",
        var title: String = "",
        var since: Long = System.currentTimeMillis(),
        var lastSeen: Long = System.currentTimeMillis(),
        var isPrivate: Boolean = false,
        // Mục 173: đã từng THẤY runtime chạy/rảnh trong phiên này (kết nối thật). Chưa từng => nút "Kết nối" chỉ là trang chưa bấm kết nối, KHÔNG phải mất kết nối.
        var everOk: Boolean = false,
        // Bản 7.110: nhớ "đang có lượt chạy" qua cả lúc im lặng để vẫn báo "đã chạy xong" (log 10:00:10: silent -> idle trước đây không báo).
        val run: ColabLogic.RunTracker = ColabLogic.RunTracker()
    )

    private val tabs = ConcurrentHashMap<String, Status>()
    private val lastAlarmAt = ConcurrentHashMap<String, Long>()
    // Bản 7.110: app CHỦ ĐỘNG hỏi trang Colab (không dựa vào bộ đếm giờ trong trang — bộ đó ngừng khi app ra nền).
    private val lastPollAtById = ConcurrentHashMap<String, Long>()
    private val pollFails = ConcurrentHashMap<String, Int>()
    private val BAD = setOf("error", "crashed", "disconnected", "timeout", "quota", "silent")

    fun isEnabled(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "colab_monitor_on", true)
    fun alarmOn(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "colab_alarm_on", true)
    fun soundOn(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "colab_alarm_sound", true)
    fun doneNotifyOn(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "colab_done_notify", true)

    /** Nhận một bản tin `colab_status` từ content.js. `onChanged` được gọi khi trạng thái ĐỔI (để làm mới thông báo). */
    fun onStatus(c: Context, slot: Int, tabId: String, isPrivate: Boolean, m: JSONObject, fromPoll: Boolean = false, onChanged: () -> Unit) {
        if (!isEnabled(c, slot)) return
        val s = m.optString("state", "unknown")
        val prev = tabs[tabId]
        val now = System.currentTimeMillis()
        val st = prev ?: Status(tabId)
        val changed = prev == null || prev.state != s
        pollFails.remove(tabId) // có bản tin (nhịp tim hoặc trả lời hỏi) => trang còn sống
        val runFinished = st.run.observe(s, now)
        st.detail = m.optString("detail", "")
        st.elapsed = m.optString("elapsed", "")
        st.runtime = m.optString("runtime", "")
        st.errors = m.optInt("errors", 0)
        st.url = m.optString("url", "")
        st.title = m.optString("title", "").removeSuffix(" - Colab").removeSuffix(" - Google Colab").take(28)
        st.lastSeen = now
        st.isPrivate = isPrivate
        if (s == "running" || s == "idle") {
            st.everOk = true
            AppPrefs.setString(c, slot, "colab_last_ok_ms", now.toString())
        }
        if (changed) {
            val old = prev?.state ?: "(mới)"
            st.state = s
            st.since = now
            tabs[tabId] = st
            DebugLog.log("Khe $slot: [Colab] tab ${tabId.take(8)}: $old -> $s | ${st.detail} | ${st.elapsed} | ${st.runtime} | lỗi=${st.errors} | thăm dò ${m.optInt("ms", -1)}ms${if (fromPoll) " | nguồn=app hỏi trang" else ""}")
            // Mục 173: log thật — mở trang Colab chưa chạy gì cũng bị "connecting -> disconnected" rồi báo động liên tục. Trang Colab vừa tải mà chưa có runtime luôn hiện nút "Kết nối".
            // Chỉ coi là MẤT KẾT NỐI khi (a) tab này từng chạy/rảnh trong phiên, hoặc (b) khe này từng kết nối thành công trong 30 phút gần đây (vd app bị tắt rồi mở lại giữa lúc đang chạy).
            val lastOk = AppPrefs.getString(c, slot, "colab_last_ok_ms", "0").toLongOrNull() ?: 0L
            val neverConnected = s == "disconnected" && !st.everOk && (now - lastOk) > 30 * 60_000L
            if (neverConnected) DebugLog.log("Khe $slot: [Colab] tab ${tabId.take(8)}: chưa từng kết nối runtime (nút 'Kết nối' chỉ là trang mới mở) — KHÔNG báo động")
            else if (s in BAD && old != "(mới)") alarm(c, slot, tabId, s, st)
            else if (s in BAD && old == "(mới)" && s != "silent") alarm(c, slot, tabId, s, st) // mở app lên mà Colab đã hỏng sẵn thì cũng báo
            if (runFinished && doneNotifyOn(c, slot)) {
                // Bản 7.110: tính từ lúc THẤY chạy lần đầu của lượt này (không phải từ lần chuyển trạng thái cuối) và báo cả khi giữa chừng mất tín hiệu.
                val mins = (now - st.run.startedAt) / 60000
                val gap = if (st.run.gapDuringRun) " (giữa chừng có lúc app không nghe được trang, nên có thể xong sớm hơn lúc báo)" else ""
                info(c, slot, "✅ Colab đã chạy xong", "Chạy khoảng $mins phút, không có lỗi mới.$gap ${st.runtime}")
            }
            onChanged()
        } else {
            tabs[tabId] = st
        }
    }

    /**
     * Bản 7.110 — các tab Colab cần HỎI ngay bây giờ (đã đánh dấu thời điểm hỏi). Ở nền: mỗi ~60s; đang xem: chỉ khi >90s không có tín hiệu nào.
     * Nơi gọi gửi lệnh [POLL_SCRIPT] vào từng tab rồi chuyển kết quả cho [onPollResult].
     */
    fun tabsToPoll(c: Context, slot: Int, loadedColabTabIds: Set<String>, appInBackground: Boolean): List<String> {
        if (!isEnabled(c, slot)) return emptyList()
        val now = System.currentTimeMillis()
        val out = ArrayList<String>()
        for (id in loadedColabTabIds) {
            val lastSeen = tabs[id]?.lastSeen ?: 0L   // chưa có bản tin nào => coi là rất cũ
            if (ColabLogic.shouldPoll(now, lastPollAtById[id] ?: 0L, lastSeen, appInBackground)) { lastPollAtById[id] = now; out.add(id) }
        }
        lastPollAtById.keys.retainAll(loadedColabTabIds)
        pollFails.keys.retainAll(loadedColabTabIds)
        return out
    }

    /** Lệnh hỏi: gọi hàm thăm dò CÓ SẴN của content.js (`window.__lbColab.probe`, trả về chuỗi JSON). Chạy qua cổng eval — không phụ thuộc bộ đếm giờ trong trang. */
    const val POLL_SCRIPT = "(function(){ try { return window.__lbColab ? window.__lbColab.probe() : 'NOPROBE'; } catch (e) { return 'ERR:' + e.message; } })()"

    /** Kết quả một lần hỏi. [raw] = chuỗi eval trả về ("OK: {json}" / "LOI: ..."), null nếu không ai đáp trong 15s hoặc không có cổng tới tab. */
    fun onPollResult(c: Context, slot: Int, tabId: String, isPrivate: Boolean, raw: String?, onChanged: () -> Unit) {
        if (!isEnabled(c, slot)) return
        val body = raw?.removePrefix("OK: ")?.trim()
        val json = if (body != null && body.startsWith("{")) try { JSONObject(body) } catch (_: Throwable) { null } else null
        if (json == null) {
            // Trình duyệt đang đơ thì một lần hỏi hỏng không nói gì về Colab => không đếm.
            if (!ColabLogic.countsAsPollFailure(GeckoStallWatchdog.isStalled())) return
            val n = (pollFails[tabId] ?: 0) + 1
            pollFails[tabId] = n
            if ((n == 1 && tabs.containsKey(tabId)) || n % 3 == 0) {
                DebugLog.log("Khe $slot: [Colab] tab ${tabId.take(8)}: app hỏi trang KHÔNG được đáp, lần thứ $n liên tiếp (${if (raw == null) "không phản hồi/không có cổng" else raw.take(60)}) — ${ColabLogic.POLL_FAILS_BEFORE_SILENT} lần liên tiếp + >5 phút không tín hiệu mới coi là im lặng")
            }
            return
        }
        val prevFails = pollFails.remove(tabId) ?: 0
        if (prevFails > 0) DebugLog.log("Khe $slot: [Colab] tab ${tabId.take(8)}: app hỏi trang đã được đáp lại sau $prevFails lần hỏng")
        onStatus(c, slot, tabId, isPrivate, json, true, onChanged)
    }

    /** Gọi định kỳ: tab Colab đã tải mà không còn gửi nhịp tim > SILENT_AFTER_MS (5 phút) => coi là "silent"; chỉ BÁO ĐỘNG khi Colab Live đang bật. */
    fun checkSilence(c: Context, slot: Int, loadedColabTabIds: Set<String>, onChanged: () -> Unit) {
        if (!isEnabled(c, slot)) return
        val now = System.currentTimeMillis()
        tabs.keys.filter { it !in loadedColabTabIds }.forEach { tabs.remove(it) }
        val stalled = GeckoStallWatchdog.isStalled()
        for ((id, st) in tabs) {
            // Bản 7.110: im lặng chỉ khi (a) tab từng kết nối thật, (b) trình duyệt không đang đơ, (c) quá 5 phút VÀ app đã hỏi trang >= 3 lần không ai đáp.
            // (Tab chưa từng kết nối — tab nền của log 08:47 — không bao giờ bị coi là im lặng; tab trả lời được lệnh hỏi thì lastSeen luôn tươi.)
            if (st.state != "silent" && ColabLogic.shouldMarkSilent(now, st.lastSeen, pollFails[id] ?: 0, st.everOk, stalled)) {
                // Mục 131.1: trước đây dòng log đọc `st.state` SAU khi đã gán "silent" nên luôn in "trạng thái cuối trước đó: silent" —
                // mất đúng thông tin mục 129.2 cần để truy vì sao nhịp tim dừng. Chụp trạng thái cũ TRƯỚC khi ghi đè.
                val lastState = st.state
                val lastDetail = st.detail
                val lastElapsed = st.elapsed
                st.state = "silent"; st.since = now
                st.run.observe("silent", now)
                st.detail = "không nhận được tín hiệu từ trang Colab trong ${(now - st.lastSeen) / 1000}s và app hỏi ${pollFails[id] ?: 0} lần không ai đáp"
                DebugLog.log("Khe $slot: [Colab] tab ${id.take(8)} '${st.title}': mất tín hiệu — ${st.detail} (trạng thái cuối trước đó: $lastState | $lastDetail | $lastElapsed)")
                if (AppPrefs.getBoolean(c, slot, "colablive_keepalive_on", false)) alarm(c, slot, id, "silent", st)
                onChanged()
            }
        }
    }

    /** Dòng tóm tắt cho thông báo (trạng thái XẤU NHẤT trong các tab Colab đã tải); null nếu chưa có dữ liệu. */
    fun summary(): String? {
        // Bản 7.110: trình duyệt đang đơ thì nói thẳng, đừng để người dùng tưởng Colab hỏng.
        if (GeckoStallWatchdog.isStalled()) return "🧊 Trình duyệt đang ĐƠ — Colab tạm không giám sát được (không phải lỗi Colab)"
        val list = tabs.values.toList()
        if (list.isEmpty()) return null
        // Thứ hạng mới (ColabLogic.rank): tab im lặng/chưa từng kết nối không còn đè lên tab đang chạy; hoà thì lấy tab có tín hiệu mới nhất.
        val worst = list.sortedByDescending { it.lastSeen }.minByOrNull { ColabLogic.rank(it.state, it.everOk) } ?: return null
        val extra = if (list.size > 1) " (${list.size} tab)" else ""
        return when (worst.state) {
            "crashed" -> "🔴 Colab: PHIÊN BỊ SẬP — ${worst.detail.take(50)}$extra"
            "disconnected" -> if (!worst.everOk) "⚪ Colab: chưa kết nối runtime (chưa bấm Kết nối)$extra"
                else "⛔ Colab: MẤT KẾT NỐI${if (worst.detail.isNotBlank()) " — " + worst.detail.take(50) else ""}$extra"
            "timeout" -> "⏱ Colab: HẾT PHIÊN/HẾT THỜI GIAN CHỜ$extra"
            "quota" -> "⛔ Colab: HẾT HẠN MỨC GPU$extra"
            "silent" -> "⚠ Colab: mất tín hiệu từ tab${if (worst.title.isNotBlank()) " '${worst.title}'" else ""} (chưa chắc là lỗi)$extra"
            "error" -> "🔴 Colab: CÓ LỖI${if (worst.detail.isNotBlank()) " — " + worst.detail.take(50) else ""}$extra"
            "running" -> "🟢 Colab${if (worst.title.isNotBlank()) " '${worst.title}'" else ""}: đang chạy${if (worst.elapsed.isNotBlank()) " (${worst.elapsed})" else ""}${if (worst.runtime.isNotBlank()) " · ${worst.runtime}" else ""}$extra"
            "connecting" -> "🟡 Colab: đang kết nối$extra"
            "idle" -> "✅ Colab${if (worst.title.isNotBlank()) " '${worst.title}'" else ""}: kết nối tốt, đang rảnh${if (worst.runtime.isNotBlank()) " · ${worst.runtime}" else ""}$extra"
            else -> null
        }
    }

    // ---------------- Báo động ----------------
    private fun activityFor(slot: Int): Class<*> = when (slot) {
        1 -> MainActivitySlot1::class.java
        2 -> MainActivitySlot2::class.java
        3 -> MainActivitySlot3::class.java
        else -> MainActivity::class.java
    }

    private fun contentIntent(c: Context, slot: Int): PendingIntent {
        val i = Intent(c, activityFor(slot)).apply {
            putExtra(MainActivity.EXTRA_SKIP_PICKER, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        return PendingIntent.getActivity(c, 7000 + slot, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ALARM) == null) {
            val ch = NotificationChannel(CHANNEL_ALARM, "Cảnh báo Colab (lỗi/mất kết nối)", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Báo động khi Colab gặp lỗi, mất kết nối, hết phiên hoặc trang không phản hồi"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 600, 250, 600, 250, 900)
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(ch)
        }
        if (nm.getNotificationChannel(CHANNEL_INFO) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_INFO, "Thông tin Colab (chạy xong)", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun label(state: String) = when (state) {
        "error" -> "Colab có LỖI"
        "crashed" -> "Phiên Colab bị SẬP"
        "disconnected" -> "Colab MẤT KẾT NỐI"
        "timeout" -> "Colab HẾT PHIÊN / hết thời gian chờ"
        "quota" -> "Colab HẾT HẠN MỨC GPU"
        "silent" -> "Trang Colab KHÔNG PHẢN HỒI"
        "stalled" -> "Trình duyệt BỊ ĐƠ"
        else -> "Colab: $state"
    }

    private fun alarm(c: Context, slot: Int, tabId: String, state: String, st: Status) {
        if (!alarmOn(c, slot)) return
        val key = "$tabId|$state"
        val now = System.currentTimeMillis()
        if (now - (lastAlarmAt[key] ?: 0L) < 5 * 60_000L) return // không kêu lặp cùng một sự cố trong 5 phút
        lastAlarmAt[key] = now
        val title = "🚨 ${label(state)} — Khe $slot"
        val text = (st.detail.ifBlank { "Kiểm tra lại notebook" }) + (if (st.url.isNotBlank()) "\n" + st.url.take(90) else "")
        DebugLog.log("Khe $slot: [Colab] BÁO ĐỘNG: $title | ${st.detail}")
        try {
            ensureChannels(c)
            val n = NotificationCompat.Builder(c, CHANNEL_ALARM)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(st.detail.ifBlank { "Nhấn để mở khe" })
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(contentIntent(c, slot))
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(3000 + slot * 10 + (state.hashCode() and 7), n)
        } catch (e: Throwable) {
            DebugLog.log("Khe $slot: [Colab] đăng thông báo báo động LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
        if (soundOn(c, slot)) ring(c)
    }

    /**
     * Bản 7.110: trình duyệt bị đơ lúc app ở nền — không hiện được hộp thoại (Android 14 chặn tự mở Activity từ nền) và Colab không còn được giám sát. Chỉ báo khi Colab Live đang bật
     * (người dùng đang trông cậy vào giám sát); dùng chung kênh/chuông báo động, tối đa 1 lần/5 phút.
     */
    fun alarmBrowserStall(c: Context, slot: Int) {
        if (!AppPrefs.getBoolean(c, slot, "colablive_keepalive_on", false)) return
        val st = Status("browser", state = "stalled", detail = "Trình duyệt bị đơ nên Colab tạm không được giám sát (không phải lỗi Colab). Mở app để khởi động lại.")
        alarm(c, slot, "browser", "stalled", st)
    }

    private fun info(c: Context, slot: Int, title: String, text: String) {
        try {
            ensureChannels(c)
            val n = NotificationCompat.Builder(c, CHANNEL_INFO)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("$title — Khe $slot")
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(contentIntent(c, slot))
                .build()
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(3100 + slot, n)
        } catch (e: Throwable) { /* không quan trọng */ }
    }

    /** Kêu chuông báo thức ~8s + rung (kể cả khi kênh thông báo bị người dùng tắt âm). */
    fun ring(c: Context) {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = RingtoneManager.getRingtone(c.applicationContext, uri)
            if (Build.VERSION.SDK_INT >= 28) {
                r.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            }
            r.play()
            Handler(Looper.getMainLooper()).postDelayed({ try { r.stop() } catch (e: Throwable) {} }, 8000L)
        } catch (e: Throwable) {
            DebugLog.log("[Colab] phát chuông LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
        try {
            val v = c.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 250, 600, 250, 900), -1))
            else @Suppress("DEPRECATION") v.vibrate(longArrayOf(0, 600, 250, 600, 250, 900), -1)
        } catch (e: Throwable) { /* thiết bị không có rung */ }
    }

    /** Nút "Thử báo động" trong hộp thoại cài đặt. */
    fun testAlarm(c: Context, slot: Int) {
        val st = Status("test", state = "error", detail = "Đây là báo động THỬ — Colab chưa có sự cố", url = "")
        lastAlarmAt.remove("test|error")
        alarm(c, slot, "test", "error", st)
    }
}
