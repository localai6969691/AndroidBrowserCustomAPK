package com.colablive.keeper.features.colab

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.colablive.keeper.MainActivity
import com.colablive.keeper.MainActivitySlot1
import com.colablive.keeper.MainActivitySlot2
import com.colablive.keeper.MainActivitySlot3
import com.colablive.keeper.core.AppPrefs
import com.colablive.keeper.core.DebugLog
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Mục 125: GIÁM SÁT TRẠNG THÁI COLAB.
 *
 * `content.js` (hàm `lbColab`) chạy trong CHÍNH trang Colab, đọc thanh trạng thái / nút kết nối / hộp thoại và gửi `colab_status` về app khi
 * trạng thái đổi + nhịp tim ~45s. Lớp này: giữ trạng thái từng tab, phát hiện chuyển trạng thái xấu để BÁO ĐỘNG, phát hiện trang IM LẶNG (không còn nhịp
 * tim — trang treo/bị tiến trình Gecko thu hồi), và tạo dòng tóm tắt hiện trên thông báo "Đang giữ kết nối".
 *
 * Trạng thái: running | idle | connecting | error | crashed | disconnected | timeout | quota | silent | unknown.
 */
object ColabMonitor {
    private const val CHANNEL_ALARM = "colab_alarm"
    private const val CHANNEL_INFO = "colab_info"
    // Mục 129: ảnh chụp thông báo "KHÔNG PHẢN HỒI (trang treo?)" hiện khi khe không mở Colab. 150s quá ngắn (tab nền bị Gecko giãn nhịp) và trạng thái này chỉ
    // nghĩa "mất liên lạc với bộ giám sát", chưa chắc Colab hỏng => 5 phút, và chỉ BÁO ĐỘNG khi người dùng đã bật Colab Live; còn lại chỉ ghi chữ nhẹ.
    private const val SILENT_AFTER_MS = 300_000L

    class Status(
        val tabId: String,
        var state: String = "unknown",
        var detail: String = "",
        var elapsed: String = "",
        var runtime: String = "",
        var errors: Int = 0,
        var url: String = "",
        var title: String = "",
        var since: Long = System.currentTimeMillis(),
        var lastSeen: Long = System.currentTimeMillis(),
        var isPrivate: Boolean = false
    )

    private val tabs = ConcurrentHashMap<String, Status>()
    private val lastAlarmAt = ConcurrentHashMap<String, Long>()
    private val BAD = setOf("error", "crashed", "disconnected", "timeout", "quota", "silent")

    fun isEnabled(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "colab_monitor_on", true)
    fun alarmOn(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "colab_alarm_on", true)
    fun soundOn(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "colab_alarm_sound", true)
    fun doneNotifyOn(c: Context, slot: Int) = AppPrefs.getBoolean(c, slot, "colab_done_notify", true)

    /** Nhận một bản tin `colab_status` từ content.js. `onChanged` được gọi khi trạng thái ĐỔI (để làm mới thông báo). */
    fun onStatus(c: Context, slot: Int, tabId: String, isPrivate: Boolean, m: JSONObject, onChanged: () -> Unit) {
        if (!isEnabled(c, slot)) return
        val s = m.optString("state", "unknown")
        val prev = tabs[tabId]
        val now = System.currentTimeMillis()
        val st = prev ?: Status(tabId)
        val changed = prev == null || prev.state != s
        val wasRunningSince = if (prev != null && prev.state == "running") prev.since else 0L
        st.detail = m.optString("detail", "")
        st.elapsed = m.optString("elapsed", "")
        st.runtime = m.optString("runtime", "")
        st.errors = m.optInt("errors", 0)
        st.url = m.optString("url", "")
        st.title = m.optString("title", "").removeSuffix(" - Colab").removeSuffix(" - Google Colab").take(28)
        st.lastSeen = now
        st.isPrivate = isPrivate
        if (changed) {
            val old = prev?.state ?: "(mới)"
            st.state = s
            st.since = now
            tabs[tabId] = st
            DebugLog.log("Khe $slot: [Colab] tab ${tabId.take(8)}: $old -> $s | ${st.detail} | ${st.elapsed} | ${st.runtime} | lỗi=${st.errors} | thăm dò ${m.optInt("ms", -1)}ms")
            if (s in BAD && old != "(mới)") alarm(c, slot, tabId, s, st)
            else if (s in BAD && old == "(mới)" && s != "silent") alarm(c, slot, tabId, s, st) // mở app lên mà Colab đã hỏng sẵn thì cũng báo
            if (prev?.state == "running" && s == "idle" && doneNotifyOn(c, slot)) {
                val mins = (now - wasRunningSince) / 60000
                info(c, slot, "✅ Colab đã chạy xong", "Chạy khoảng $mins phút, không có lỗi mới. ${st.runtime}")
            }
            onChanged()
        } else {
            tabs[tabId] = st
        }
    }

    /** Gọi định kỳ: tab Colab đã tải mà không còn gửi nhịp tim > 150s => coi là "silent" và báo động. */
    fun checkSilence(c: Context, slot: Int, loadedColabTabIds: Set<String>, onChanged: () -> Unit) {
        if (!isEnabled(c, slot)) return
        val now = System.currentTimeMillis()
        tabs.keys.filter { it !in loadedColabTabIds }.forEach { tabs.remove(it) }
        for ((id, st) in tabs) {
            if (now - st.lastSeen > SILENT_AFTER_MS && st.state != "silent") {
                st.state = "silent"; st.since = now
                st.detail = "không nhận được tín hiệu từ trang Colab trong ${(now - st.lastSeen) / 1000}s"
                DebugLog.log("Khe $slot: [Colab] tab ${id.take(8)} '${st.title}': mất tín hiệu — ${st.detail} (trạng thái cuối trước đó: ${st.state})")
                if (AppPrefs.getBoolean(c, slot, "colablive_keepalive_on", false)) alarm(c, slot, id, "silent", st)
                onChanged()
            }
        }
    }

    /** Dòng tóm tắt cho thông báo (trạng thái XẤU NHẤT trong các tab Colab đã tải); null nếu chưa có dữ liệu. */
    fun summary(): String? {
        val list = tabs.values.toList()
        if (list.isEmpty()) return null
        val order = listOf("crashed", "disconnected", "timeout", "quota", "silent", "error", "running", "connecting", "idle", "unknown")
        val worst = list.minByOrNull { order.indexOf(it.state).let { i -> if (i < 0) 99 else i } } ?: return null
        val extra = if (list.size > 1) " (${list.size} tab)" else ""
        return when (worst.state) {
            "crashed" -> "🔴 Colab: PHIÊN BỊ SẬP — ${worst.detail.take(50)}$extra"
            "disconnected" -> "⛔ Colab: MẤT KẾT NỐI${if (worst.detail.isNotBlank()) " — " + worst.detail.take(50) else ""}$extra"
            "timeout" -> "⏱ Colab: HẾT PHIÊN/HẾT THỜI GIAN CHỜ$extra"
            "quota" -> "⛔ Colab: HẾT HẠN MỨC GPU$extra"
            "silent" -> "⚠ Colab: mất tín hiệu từ tab${if (worst.title.isNotBlank()) " '${worst.title}'" else ""} (chưa chắc là lỗi)$extra"
            "error" -> "🔴 Colab: CÓ LỖI${if (worst.detail.isNotBlank()) " — " + worst.detail.take(50) else ""}$extra"
            "running" -> "🟢 Colab${if (worst.title.isNotBlank()) " '${worst.title}'" else ""}: đang chạy${if (worst.elapsed.isNotBlank()) " (${worst.elapsed})" else ""}${if (worst.runtime.isNotBlank()) " · ${worst.runtime}" else ""}$extra"
            "connecting" -> "🟡 Colab: đang kết nối$extra"
            "idle" -> "✅ Colab${if (worst.title.isNotBlank()) " '${worst.title}'" else ""}: kết nối tốt, đang rảnh${if (worst.runtime.isNotBlank()) " · ${worst.runtime}" else ""}$extra"
            else -> null
        }
    }

    // ---------------- Báo động ----------------
    private fun activityFor(slot: Int): Class<*> = when (slot) {
        1 -> MainActivitySlot1::class.java
        2 -> MainActivitySlot2::class.java
        3 -> MainActivitySlot3::class.java
        else -> MainActivity::class.java
    }

    private fun contentIntent(c: Context, slot: Int): PendingIntent {
        val i = Intent(c, activityFor(slot)).apply {
            putExtra(MainActivity.EXTRA_SKIP_PICKER, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        return PendingIntent.getActivity(c, 7000 + slot, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ALARM) == null) {
            val ch = NotificationChannel(CHANNEL_ALARM, "Cảnh báo Colab (lỗi/mất kết nối)", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Báo động khi Colab gặp lỗi, mất kết nối, hết phiên hoặc trang không phản hồi"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 600, 250, 600, 250, 900)
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(ch)
        }
        if (nm.getNotificationChannel(CHANNEL_INFO) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_INFO, "Thông tin Colab (chạy xong)", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun label(state: String) = when (state) {
        "error" -> "Colab có LỖI"
        "crashed" -> "Phiên Colab bị SẬP"
        "disconnected" -> "Colab MẤT KẾT NỐI"
        "timeout" -> "Colab HẾT PHIÊN / hết thời gian chờ"
        "quota" -> "Colab HẾT HẠN MỨC GPU"
        "silent" -> "Trang Colab KHÔNG PHẢN HỒI"
        else -> "Colab: $state"
    }

    private fun alarm(c: Context, slot: Int, tabId: String, state: String, st: Status) {
        if (!alarmOn(c, slot)) return
        val key = "$tabId|$state"
        val now = System.currentTimeMillis()
        if (now - (lastAlarmAt[key] ?: 0L) < 5 * 60_000L) return // không kêu lặp cùng một sự cố trong 5 phút
        lastAlarmAt[key] = now
        val title = "🚨 ${label(state)} — Khe $slot"
        val text = (st.detail.ifBlank { "Kiểm tra lại notebook" }) + (if (st.url.isNotBlank()) "\n" + st.url.take(90) else "")
        DebugLog.log("Khe $slot: [Colab] BÁO ĐỘNG: $title | ${st.detail}")
        try {
            ensureChannels(c)
            val n = NotificationCompat.Builder(c, CHANNEL_ALARM)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(st.detail.ifBlank { "Nhấn để mở khe" })
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(contentIntent(c, slot))
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(3000 + slot * 10 + (state.hashCode() and 7), n)
        } catch (e: Throwable) {
            DebugLog.log("Khe $slot: [Colab] đăng thông báo báo động LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
        if (soundOn(c, slot)) ring(c)
    }

    private fun info(c: Context, slot: Int, title: String, text: String) {
        try {
            ensureChannels(c)
            val n = NotificationCompat.Builder(c, CHANNEL_INFO)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("$title — Khe $slot")
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(contentIntent(c, slot))
                .build()
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(3100 + slot, n)
        } catch (e: Throwable) { /* không quan trọng */ }
    }

    /** Kêu chuông báo thức ~8s + rung (kể cả khi kênh thông báo bị người dùng tắt âm). */
    fun ring(c: Context) {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = RingtoneManager.getRingtone(c.applicationContext, uri)
            if (Build.VERSION.SDK_INT >= 28) {
                r.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            }
            r.play()
            Handler(Looper.getMainLooper()).postDelayed({ try { r.stop() } catch (e: Throwable) {} }, 8000L)
        } catch (e: Throwable) {
            DebugLog.log("[Colab] phát chuông LỖI ${e.javaClass.simpleName}: ${e.message}")
        }
        try {
            val v = c.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 250, 600, 250, 900), -1))
            else @Suppress("DEPRECATION") v.vibrate(longArrayOf(0, 600, 250, 600, 250, 900), -1)
        } catch (e: Throwable) { /* thiết bị không có rung */ }
    }

    /** Nút "Thử báo động" trong hộp thoại cài đặt. */
    fun testAlarm(c: Context, slot: Int) {
        val st = Status("test", state = "error", detail = "Đây là báo động THỬ — Colab chưa có sự cố", url = "")
        lastAlarmAt.remove("test|error")
        alarm(c, slot, "test", "error", st)
    }
}
