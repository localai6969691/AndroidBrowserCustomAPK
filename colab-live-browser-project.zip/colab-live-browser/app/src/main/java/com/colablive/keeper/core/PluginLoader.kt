package com.colablive.keeper.core

import android.content.Context
import android.util.Log
import dalvik.system.DexClassLoader
import java.io.File

/**
 * PluginLoader — nạp các feature (implement `BrowserFeature`) từ file
 * `.jar` NẰM NGOÀI APK, lúc app chạy — thay vì phải biên dịch cứng vào
 * APK như `FeatureRegistry.features` hiện tại.
 *
 * ĐÂY LÀ FILE MỚI thêm vào `:core` khi tách module (không có trong bản
 * gốc trước khi có EbookLeech) — sau khi thêm file này + sửa
 * `FeatureRegistry.kt` 1 lần, KHÔNG BAO GIỜ cần đụng lại base app nữa để
 * cập nhật/vá lỗi EbookLeech (hay bất kỳ plugin nào khác build theo cùng
 * chuẩn) — chỉ cần build lại riêng module plugin, thay file `.jar`, nạp
 * lại (qua nút trong Settings, không cần khởi động lại app).
 *
 * ═══ BẢN 7.98 — CHẾ ĐỘ NHÚNG (EMBEDDED) ═══
 * Trong project này EbookLeech KHÔNG build thành `.jar` riêng mà được biên dịch THẲNG
 * vào module `:app` (xem PROJECT_STATUS.md mục 222: tách `:core` đòi kéo ~80 file của app
 * sang module khác, không biên dịch thử được ở đây nên không làm mù). Hệ quả:
 *  - `findPluginClass()` có đường lui: không thấy trong jar nào thì tìm bằng ClassLoader
 *    của chính app => `PluginForegroundServiceProxy`/`PluginWorker` vẫn tìm ra
 *    `EbookLeechServiceLogic`/`EbookLeechWorkLogic` nằm sẵn trong APK.
 *  - `FeatureRegistry` KHÔNG quét thư mục jar lúc khởi động (không có lợi gì ở chế độ nhúng,
 *    lại thêm bề mặt nạp mã ngoài APK). Cơ chế jar vẫn còn nguyên để dùng sau nếu tách module.
 *  - DexClassLoader parent-first: class đã có trong APK luôn thắng class cùng tên trong jar,
 *    nên một file .jar EbookLeech cũ/mới bỏ vào thư mục plugin KHÔNG thay được bản trong APK.
 *
 * QUY ƯỚC PLUGIN (bất kỳ ai build plugin theo chuẩn này):
 *  - Build ra 1 file `.jar` chứa các class Kotlin/Java đã biên dịch
 *    (KHÔNG kèm theo các class của base app — dùng `compileOnly` khi build).
 *  - Trong jar, tại đường dẫn `META-INF/colablive-plugin/entry-points.txt`,
 *    liệt kê MỖI DÒNG 1 tên class đầy đủ (fully-qualified) của các
 *    `object`/class implement `BrowserFeature` muốn đăng ký.
 *  - Đặt file `.jar` vào thư mục `PLUGIN_DIR` bên dưới (mặc định
 *    `Android/data/<package>/files/plugins/`, không cần quyền đặc biệt vì
 *    là thư mục riêng của app).
 *
 * BẢO MẬT — PHẢI NÓI RÕ: nạp code từ file ngoài APK bằng DexClassLoader
 * đồng nghĩa BẤT KỲ ai ghi được vào PLUGIN_DIR đều có thể khiến app chạy
 * code tuỳ ý của họ (chạy với quyền của chính app). Vì thư mục dùng ở đây
 * (`getExternalFilesDir`) là thư mục RIÊNG của app trên Android 10+ (app
 * khác không ghi vào được nếu không có quyền root), rủi ro ở mức chấp
 * nhận được cho MỤC ĐÍCH CÁ NHÂN (tự bạn build, tự bạn nạp jar vào máy
 * của chính mình) — KHÔNG nên dùng cơ chế này nếu app này sẽ phân phối
 * rộng cho người khác dùng.
 */
object PluginLoader {

    private const val TAG = "PluginLoader"
    private const val ENTRY_POINTS_PATH = "META-INF/colablive-plugin/entry-points.txt"

    private val loadedFeatures = mutableListOf<BrowserFeature>()
    private val loadedClassLoaders = mutableListOf<DexClassLoader>()
    private var scanned = false

    /** Thư mục chứa file .jar plugin — riêng của app, không cần xin quyền. */
    fun pluginDir(context: Context): File {
        val dir = context.getExternalFilesDir("plugins") ?: File(context.filesDir, "plugins")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Quét `pluginDir()` tìm mọi file `.jar`, nạp từng cái, đọc
     * entry-points.txt, khởi tạo từng class → thêm vào danh sách feature
     * động. Gọi 1 lần lúc app khởi động (trong `LiveBrowserApp.onCreate()`),
     * và gọi lại bất kỳ lúc nào sau `reset()` (vd sau khi nạp `.jar` mới
     * qua nút trong Settings EbookLeech — không cần khởi động lại app).
     */
    fun scanAndLoad(context: Context): List<BrowserFeature> {
        if (scanned) return loadedFeatures
        scanned = true
        loadedFeatures.clear()
        loadedClassLoaders.clear()

        val jarFiles = pluginDir(context).listFiles { f -> f.isFile && f.name.endsWith(".jar") } ?: emptyArray()
        val optimizedDir = File(context.codeCacheDir, "plugin_dex").apply { if (!exists()) mkdirs() }

        jarFiles.forEach { jarFile ->
            try {
                loadOneJar(context, jarFile, optimizedDir)
            } catch (e: Exception) {
                // 1 plugin lỗi KHÔNG được làm sập cả app — log rồi bỏ qua,
                // các feature cứng (FeatureRegistry.features gốc) vẫn chạy
                // bình thường.
                Log.e(TAG, "Không nạp được plugin ${jarFile.name}: ${e.message}", e)
            }
        }

        Log.i(TAG, "Đã nạp ${loadedFeatures.size} feature từ ${jarFiles.size} file plugin")
        return loadedFeatures
    }

    private fun loadOneJar(context: Context, jarFile: File, optimizedDir: File) {
        // Android 14+ với targetSdk >= 34: nạp mã động từ file CÒN QUYỀN GHI ném SecurityException
        // (tài liệu "Dynamic code loading: files must be read-only"). Đặt chỉ-đọc trước khi nạp.
        try { jarFile.setReadOnly() } catch (_: Exception) { }
        val classLoader = DexClassLoader(
            jarFile.absolutePath,
            optimizedDir.absolutePath,
            null,
            context.classLoader,  // QUAN TRỌNG: dùng classLoader của chính app làm parent
        )
        loadedClassLoaders.add(classLoader)

        val entryPointsText = try {
            classLoader.getResourceAsStream(ENTRY_POINTS_PATH)?.bufferedReader()?.readText()
        } catch (e: Exception) {
            null
        }

        if (entryPointsText.isNullOrBlank()) {
            Log.w(TAG, "${jarFile.name}: không tìm thấy $ENTRY_POINTS_PATH — bỏ qua file này")
            return
        }

        entryPointsText.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.forEach { className ->
            try {
                val instance = instantiate(classLoader.loadClass(className))
                if (instance is BrowserFeature) {
                    loadedFeatures.add(instance)
                    Log.i(TAG, "Đã nạp feature: $className (từ ${jarFile.name})")
                } else {
                    Log.w(TAG, "$className không implement BrowserFeature — bỏ qua")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi nạp class $className từ ${jarFile.name}: ${e.message}", e)
            }
        }
    }

    /** `object` Kotlin → lấy field `INSTANCE` (singleton có sẵn, đúng cách
     * dùng của plugin — cả `BrowserFeature` lẫn `PluginServiceLogic`/
     * `PluginWorkLogic` đều nên khai là `object`). Class thường (hiếm khi
     * cần) → gọi constructor rỗng làm phương án dự phòng. */
    private fun instantiate(clazz: Class<*>): Any =
        try {
            clazz.getField("INSTANCE").get(null)
        } catch (e: NoSuchFieldException) {
            clazz.getDeclaredConstructor().newInstance()
        }

    /** Xoá cache — gọi khi muốn buộc quét lại (vd sau khi nạp jar mới rồi
     * bấm "Nạp lại plugin"/"Nạp .jar mới" trong app, không cần khởi động
     * lại app). */
    fun reset() {
        scanned = false
        loadedFeatures.clear()
        loadedClassLoaders.clear()
    }

    /**
     * Tìm 1 class BẤT KỲ (không nhất thiết `BrowserFeature`) trong các jar
     * plugin đã nạp — dùng bởi `PluginForegroundServiceProxy`/`PluginWorker`
     * để tìm đúng class implement `PluginServiceLogic`/`PluginWorkLogic` mà
     * proxy cần chuyển tiếp lời gọi tới (xem `PluginServiceLogic.kt` — lý do
     * cần lớp proxy này thay vì để Android tự khởi tạo Service/Worker của
     * plugin trực tiếp). Trả về `null` nếu không plugin nào có class đó
     * (vd đã gỡ jar, hoặc gọi trước khi `scanAndLoad()` chạy lần nào).
     */
    fun findPluginClass(className: String): Class<*>? {
        loadedClassLoaders.forEach { cl ->
            try {
                return Class.forName(className, true, cl)
            } catch (e: ClassNotFoundException) {
                // Thử classloader kế tiếp — bình thường nếu có nhiều jar
            }
        }
        // Chế độ nhúng (7.98): class nằm sẵn trong APK => ClassLoader của chính app.
        return try {
            Class.forName(className, true, PluginLoader::class.java.classLoader)
        } catch (e: ClassNotFoundException) {
            null
        }
    }

    /** Kết hợp `findPluginClass()` + `instantiate()` — dùng bởi
     * `PluginForegroundServiceProxy`/`PluginWorker` để lấy thẳng instance từ
     * tên class, khỏi lặp lại 2 bước ở call site. Trả về `null` nếu không
     * tìm thấy class. Cố ý trả `Any?` (không dùng `inline reified`) vì hàm
     * `inline` public không được phép đụng vào `instantiate()` (private) —
     * ép kiểu ở call site bằng `as? PluginServiceLogic` v.v. */
    fun findPluginInstance(className: String): Any? {
        val clazz = findPluginClass(className) ?: return null
        return try {
            instantiate(clazz)
        } catch (e: Exception) {
            Log.e(TAG, "findPluginInstance($className) lỗi: ${e.message}", e)
            null
        }
    }
}
