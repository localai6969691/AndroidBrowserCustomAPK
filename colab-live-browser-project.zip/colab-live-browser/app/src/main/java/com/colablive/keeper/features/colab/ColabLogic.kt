package com.colablive.keeper.features.colab

/**
 * Bản 7.110 — LOGIC THUẦN (không đụng Android) của giám sát Colab, tách ra để kiểm thử bằng số liệu thật.
 *
 * Sửa lỗi "thông báo lệch với tình trạng thật của Colab" (log 08:40–10:01, khe 0, hai tab Colab):
 *  1. Nhãn kẹt ở "⚠ mất tín hiệu từ tab..." từ 08:47 tới 10:01 trong khi Colab thật đã chạy rồi xong rồi mất kết nối. Nguyên nhân: tab `f471f19e` (CHƯA TỪNG kết nối, tab nền) bị
 *     coi là "silent" mãi mãi, mà thứ tự cũ xếp `silent` TỆ HƠN `running` => nó đè lên dòng của tab `ae23cb46` đang chạy thật. (Nhãn còn sai từ 08:41:44/08:41:52: tab chưa kết nối đè lên tab đang chạy.)
 *  2. Ba báo động "KHÔNG PHẢN HỒI" (08:54, 09:01, 09:07) lúc Colab đang chạy bình thường (đồng hồ chạy của Colab tăng đúng 3m57s→9m27s = 5m30s trong lúc app "không nghe thấy gì"):
 *     tín hiệu chỉ đến từ một bộ đếm giờ NẰM TRONG trang, mà bộ đếm đó ngừng khi app ra nền. Nay app CHỦ ĐỘNG hỏi trang (lệnh eval, không dựa vào bộ đếm giờ) và chỉ coi là im lặng khi hỏi mà không ai đáp.
 *  3. 10:00:10 `silent -> idle` nên không có thông báo "đã chạy xong" (chỉ có chuyển `running -> idle` mới báo). Nay nhớ "đã thấy chạy" qua cả lúc im lặng.
 */
object ColabLogic {
    /** Không có tín hiệu quá ngần này thì (nếu hỏi cũng không đáp) coi là im lặng. */
    const val SILENT_AFTER_MS = 300_000L
    /** Hỏi trang Colab nhiều nhất mỗi ngần này ms (vòng giám sát chạy mỗi 30s nên thực tế ~60s). */
    const val POLL_EVERY_MS = 55_000L
    /** Ở nền: hỏi luôn. Đang xem: chỉ hỏi khi quá ngần này ms chưa có tín hiệu nào (nhịp tim tự nhiên ~20–45s). */
    const val POLL_WHEN_QUIET_MS = 90_000L
    /** Số lần hỏi liên tiếp không đáp mới được coi là im lặng. */
    const val POLL_FAILS_BEFORE_SILENT = 3

    /**
     * Thứ hạng để chọn MỘT dòng cho thông báo: số nhỏ = đáng chú ý hơn. So với bản cũ:
     *  - `silent` (không biết) xếp SAU `idle`: một tab im lặng không được đè lên tab đang chạy/rảnh/kết nối tốt;
     *  - `disconnected` của tab CHƯA TỪNG kết nối (chỉ là trang mới mở, nút "Kết nối") xếp gần cuối.
     */
    fun rank(state: String, everOk: Boolean): Int = when (state) {
        "crashed" -> 0
        "disconnected" -> if (everOk) 1 else 9
        "timeout" -> 2
        "quota" -> 3
        "error" -> 4
        "running" -> 5
        "connecting" -> 6
        "idle" -> 7
        "silent" -> 8
        "unknown" -> 10
        else -> 11
    }

    /**
     * Có nên đánh dấu tab là "silent" không.
     *  - Tab chưa từng thấy chạy/rảnh ([everOk]=false): trang nền không gửi nhịp tim là bình thường => KHÔNG BAO GIỜ (log: tab `f471f19e`).
     *  - Trình duyệt đang đơ ([browserStalled]): trang im vì trình duyệt, không phải vì Colab => không.
     *  - Còn lại: quá [SILENT_AFTER_MS] kể từ tín hiệu cuối VÀ đã hỏi >= [POLL_FAILS_BEFORE_SILENT] lần không đáp.
     *    (Hỏi thành công sẽ làm mới `lastSeen` nên tab trả lời được không bao giờ tới đây.)
     */
    fun shouldMarkSilent(now: Long, lastSeen: Long, pollFails: Int, everOk: Boolean, browserStalled: Boolean): Boolean {
        if (!everOk || browserStalled) return false
        return now - lastSeen > SILENT_AFTER_MS && pollFails >= POLL_FAILS_BEFORE_SILENT
    }

    /** Đến lúc hỏi trang này chưa. */
    fun shouldPoll(now: Long, lastPollAt: Long, lastSeen: Long, appInBackground: Boolean): Boolean {
        if (now - lastPollAt < POLL_EVERY_MS) return false
        return appInBackground || now - lastSeen > POLL_WHEN_QUIET_MS
    }

    /** Có nên chấp nhận một lần hỏi hỏng vào bộ đếm không (trình duyệt đang đơ thì lần hỏng không nói gì về Colab). */
    fun countsAsPollFailure(browserStalled: Boolean): Boolean = !browserStalled

    /**
     * Máy trạng thái "lượt chạy": thấy `running` => đang có lượt chạy; sau đó thấy `idle` => lượt chạy ĐÃ XONG (kể cả khi giữa chừng im lặng/đang kết nối/không rõ).
     * Gặp trạng thái hỏng (crashed/disconnected/timeout/quota/error) => lượt chạy kết thúc không phải bằng "xong" (đã có báo động riêng) nên bỏ cờ, không báo "xong".
     */
    class RunTracker {
        var pending = false; private set
        var startedAt = 0L; private set
        var gapDuringRun = false; private set

        /** Trả về true nếu bản tin này nghĩa là "vừa chạy xong". */
        fun observe(state: String, now: Long): Boolean {
            when (state) {
                "running" -> { if (!pending) { pending = true; startedAt = now; gapDuringRun = false } }
                "silent" -> if (pending) gapDuringRun = true
                "idle" -> if (pending) { pending = false; return true }
                "crashed", "disconnected", "timeout", "quota", "error" -> { pending = false }
            }
            return false
        }
    }
}
