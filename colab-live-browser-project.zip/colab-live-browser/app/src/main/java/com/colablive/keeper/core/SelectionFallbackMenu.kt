package com.colablive.keeper.core

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.SystemClock
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * FIX BUG THẬT (đã ghi chú trong PROJECT_STATUS.md mục 52.1/53.2/58: "trong
 * Colab không có menu dán/copy khi nhấn đè"): trên các trang dùng editor vẽ
 * bằng canvas hoặc DOM tuỳ biến sâu (Monaco/CodeMirror mà Colab dùng cho ô
 * code — KHÔNG phải `<textarea>`/`contenteditable` chuẩn mà Gecko theo dõi
 * qua `GeckoSession.SelectionActionDelegate`), long-press vẫn được trang tự
 * xử lý bằng JS nội bộ của nó (đặt caret, có thể tự vẽ "vùng bôi xanh") —
 * nhưng Gecko không biết có SELECTION THẬT SỰ ở cấp DOM/accessibility, nên
 * KHÔNG BAO GIỜ gọi `onShowActionRequest()` → không có custom action bar
 * (`GeckoView.ActionBarDelegateBackground` không được kích hoạt) → người
 * dùng không có cách nào Copy/Paste bằng menu hệ thống trong các ô này.
 * Log thật xác nhận: có rất nhiều dòng `onShowActionRequest`/`onHideAction`
 * trong lúc dùng claude.ai (DOM chuẩn, Gecko theo dõi được) nhưng KHÔNG một
 * dòng nào xảy ra trong lúc tương tác với các ô code của Colab.
 *
 * Đây là giới hạn thật của GeckoView (không có API "buộc" trang báo cáo
 * selection nó tự vẽ bằng canvas) — không thể sửa "cho đúng" bằng cách gọi
 * lại API Gecko nào đó. Giải pháp thực tế: tự phát hiện long-press bằng
 * touch event ở tầng Activity (không phụ thuộc trang có hợp tác hay không),
 * đợi 1 khoảng ngắn xem Gecko có tự hiện menu thật không (`engine.
 * lastSelectionActionUptime` mới cập nhật → có, bỏ qua, tránh hiện TRÙNG 2
 * menu trên các trang DOM chuẩn) — nếu không, hiện menu nổi tối giản
 * (Copy/Cut/Paste) ngay tại điểm nhấn, thao tác qua:
 *   - Copy/Cut: đọc `window.getSelection().toString()` bằng JS (Monaco vẫn
 *     cập nhật `window.getSelection()` thật dù tự vẽ giao diện, vì input
 *     thật vẫn là 1 `<textarea>` ẩn theo cơ chế chuẩn của Monaco) rồi ghi
 *     vào `ClipboardManager` của Android — không cần trang hợp tác gì thêm.
 *   - Paste: đọc clipboard Android, chèn vào bằng
 *     `document.execCommand('insertText', false, text)` sau khi đảm bảo
 *     phần tử đang có focus (Monaco luôn giữ focus ở textarea ẩn của nó khi
 *     con trỏ đang nhấp nháy trong ô code, kể cả sau long-press).
 *
 * Không cố phát hiện "đây có phải Colab hay không" bằng domain — cách này
 * tổng quát, chạy được với bất kỳ trang nào rơi vào đúng tình huống Gecko
 * không tự hiện menu (an toàn: nếu Gecko ĐÃ hiện menu thật, class này im
 * lặng không làm gì).
 *
 * THÀNH THẬT VỀ GIỚI HẠN CÒN LẠI (đối chiếu mục 68.1 PROJECT_STATUS.md,
 * tra sâu hơn TRƯỚC lượt này): Gecko không tự tạo được BẤT KỲ selection
 * nào (không chỉ thiếu menu, thiếu cả caret/handle) trên vùng Monaco tự
 * vẽ — vì Monaco render nội dung bằng các `<div>` định vị tuyệt đối theo
 * dòng/cột (không phải text node liền mạch trình duyệt hiểu là 1 đoạn văn
 * bản), nên `window.getSelection()` CÓ THỂ trả về rỗng dù mắt thường thấy
 * vùng bôi xanh do chính Monaco tự vẽ bằng CSS overlay (không phải Selection
 * API của trình duyệt). Nếu đúng vậy, nút "Sao chép/Cắt" trong menu này sẽ
 * KHÔNG hiện ra được (vì hasSelection=false) dù người dùng thấy có vùng bôi
 * xanh — đây là giới hạn thật CHƯA kiểm chứng được nếu không có máy thật,
 * không phải lỗi của class này. Ngược lại, "Dán" nhiều khả năng vẫn hoạt
 * động vì chỉ cần `document.activeElement` đúng là ô nhập của Monaco (input
 * capturetextarea của nó), không phụ thuộc Selection API. Đã thêm phương
 * án dự phòng: nếu `window.getSelection()` rỗng NHƯNG `document.activeElement`
 * là 1 ô nhập/textarea/contentEditable (khớp Monaco), vẫn hiện "Sao chép
 * tất cả dòng hiện tại" dùng `document.execCommand('selectAll')` rồi mới
 * đọc `getSelection()` lần 2 — nếu selectAll cũng không tạo ra gì, coi như
 * xác nhận thêm bằng chứng cho giả thuyết mục 68.1, không còn gì để thử
 * thêm ở tầng JS công khai.
 */
class SelectionFallbackMenu(
    private val context: Context,
    private val hostView: View,
    private val engineProvider: () -> GeckoViewEngine
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    // Lớp chọn riêng cho Monaco/Colab (mục 100): núm kéo + Cắt/Sao chép/Dán/Chọn hết, dùng phím Ctrl+C/X/A thật.
    private val monacoUi: MonacoSelectionUi by lazy {
        MonacoSelectionUi(
            context, hostView,
            { js, cb -> engineProvider().evaluateJs(js, cb) },
            object : MonacoSelectionUi.Actions {
                override fun onCopy() {
                    NativeClipKeys.copyOrCut(context, hostView, false, { js, cb -> engineProvider().evaluateJs(js, cb) }) { ok ->
                        if (!ok) copySelectionToClipboard()
                    }
                }
                override fun onCut() {
                    NativeClipKeys.copyOrCut(context, hostView, true, { js, cb -> engineProvider().evaluateJs(js, cb) }) { ok ->
                        monacoUi.selectionActive = false
                        if (!ok) { cutSelectionToClipboard(); return@copyOrCut }
                        // Log thực tế: Ctrl+X đã GHI clipboard nhưng Monaco KHÔNG xoá vùng chọn (chỉ như Sao chép).
                        // Kiểm tra vùng chọn còn không; còn thì xoá bằng phím Xoá lùi thật.
                        NativeClipKeys.ensureDeleted(hostView, { js, cb -> engineProvider().evaluateJs(js, cb) })
                    }
                }
                override fun onPaste() { monacoUi.selectionActive = false; pasteFromClipboard() }
                override fun onSelectAll() {
                    NativeClipKeys.selectAll(hostView, { js, cb -> engineProvider().evaluateJs(js, cb) }) { monacoUi.refresh() }
                }
            }
        )
    }

    /** Bỏ tiền tố "OK: " / "LOI: " mà cầu nối content.js luôn thêm vào kết quả (lỗi gốc của Copy/Cut cũ). */
    private fun unwrap(raw: String?): String? = MonacoSelectionUi.unwrapBridge(raw)

    private var popupView: View? = null
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var longPressPending = false
    private var moved = false

    private val LONG_PRESS_MS = 500L
    private val TOUCH_SLOP = 24f // px — nới hơn slop hệ thống 1 chút, tránh trigger nhầm khi cuộn

    private val longPressCheck = Runnable {
        if (!moved) {
            checkFallbackNeeded(downX, downY)
        }
    }

    fun onTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dismiss()
                downX = ev.rawX
                downY = ev.rawY
                downTime = SystemClock.uptimeMillis()
                moved = false
                longPressPending = true
                handler.postDelayed(longPressCheck, LONG_PRESS_MS)
            }
            MotionEvent.ACTION_MOVE -> {
                if (kotlin.math.abs(ev.rawX - downX) > TOUCH_SLOP || kotlin.math.abs(ev.rawY - downY) > TOUCH_SLOP) {
                    moved = true
                    if (longPressPending) {
                        handler.removeCallbacks(longPressCheck)
                        longPressPending = false
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                // Chạm trang có thể làm vùng chọn Monaco biến mất (nhấp = đặt con trỏ) — đọc lại để phím Xoá biết đúng.
                if (monacoUi.selectionActive) handler.postDelayed({ monacoUi.verifySelection() }, 450L)
                if (longPressPending) {
                    handler.removeCallbacks(longPressCheck)
                    longPressPending = false
                }
            }
        }
    }

    private fun checkFallbackNeeded(x: Float, y: Float) {
        longPressPending = false
        val checkAtUptime = SystemClock.uptimeMillis()
        // Đợi thêm 350ms: nếu long-press này là trên DOM chuẩn, Gecko thường
        // gọi onShowActionRequest trong khoảng này. Không đợi lâu hơn để
        // tránh cảm giác trễ khi thật sự cần fallback.
        handler.postDelayed({
            val engine = engineProvider()
            val geckoHandledIt = engine.lastSelectionActionUptime >= checkAtUptime
            if (!geckoHandledIt) {
                showFallbackMenu(x, y)
            }
        }, 350L)
    }

    private fun showFallbackMenu(x: Float, y: Float) {
        val engine = engineProvider()
        val loc = IntArray(2)
        hostView.getLocationOnScreen(loc)
        val fx = ((x - loc[0]) / hostView.width.coerceAtLeast(1)).coerceIn(0f, 1f)
        val fy = ((y - loc[1]) / hostView.height.coerceAtLeast(1)).coerceIn(0f, 1f)
        // Bước 1: có phải ô Monaco không? Nếu có: đóng menu riêng của Monaco, chọn từ tại điểm nhấn
        // (trừ khi điểm nhấn nằm trong vùng đang chọn), rồi hiện núm kéo.
        engine.evaluateJs(
            """(function(){ try {
                if (!window.__lbMon) return 'NOAPI';
                if (!__lbMon.isAt($fx, $fy)) return 'NOTMONACO';
                __lbMon.refocus($fx, $fy);
                if (__lbMon.hitSelection($fx, $fy)) return 'KEEP';
                __lbMon.wordAt($fx, $fy);
                return 'WORD';
            } catch (e) { return 'ERR ' + e.message; } })()"""
        ) { r ->
            val mode = unwrap(r)
            DebugLog.log("SelectionFallbackMenu: phát hiện Monaco tại ($fx,$fy) → $mode")
            if (mode == "KEEP" || mode == "WORD") {
                // Monaco vẽ vùng chọn ở khung hình kế tiếp — chờ rồi mới đọc hình chữ nhật.
                handler.postDelayed({
                    engine.evaluateJs("(function(){ try { return __lbMon.rects(); } catch(e){ return '{\"n\":0}'; } })()") { rr ->
                        val sel = monacoUi.parse(rr)
                        handler.post {
                            if (sel != null) monacoUi.show(sel)
                            else monacoUi.showBarOnly(x, y)
                        }
                    }
                }, 220L)
            } else {
                showLegacyMenu(x, y)
            }
        }
    }

    /** Trang KHÔNG phải Monaco (claude.ai, deepseek...): menu cũ, đã sửa lỗi tiền tố "OK: ". */
    private fun showLegacyMenu(x: Float, y: Float) {
        val engine = engineProvider()
        engine.evaluateJs("(function(){try{return String(window.getSelection().toString());}catch(e){return '';}})()") { raw ->
            val result = unwrap(raw)
            val hasSelection = !result.isNullOrEmpty() && result != "null"
            if (hasSelection) {
                handler.post { buildAndShowPopup(x, y, hasSelection = true) }
                return@evaluateJs
            }
            engine.evaluateJs(
                """(function(){
                    var a = document.activeElement;
                    while (a && a.shadowRoot && a.shadowRoot.activeElement) { a = a.shadowRoot.activeElement; }
                    if (!a) return 'none';
                    var editable = a.isContentEditable || a.tagName==='INPUT' || a.tagName==='TEXTAREA';
                    return editable ? 'editable' : 'none';
                })()"""
            ) { editableRaw ->
                handler.post {
                    buildAndShowPopup(x, y, hasSelection = false, activeElementEditable = unwrap(editableRaw) == "editable")
                }
            }
        }
    }

    private fun buildAndShowPopup(x: Float, y: Float, hasSelection: Boolean, activeElementEditable: Boolean = false) {
        dismiss()

        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF2B2B2B.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        fun addItem(label: String, onClick: () -> Unit) {
            val tv = TextView(context).apply {
                text = label
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 14f
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener {
                    onClick()
                    dismiss()
                }
            }
            container.addView(tv)
        }

        if (hasSelection) {
            addItem("Sao chép") { copySelectionToClipboard() }
            addItem("Cắt") { cutSelectionToClipboard() }
        } else if (activeElementEditable) {
            // Phương án dự phòng cho Monaco/CodeMirror (xem giải thích ở đầu
            // file) — không có selection thật để biết CHÍNH XÁC người dùng
            // định chọn gì, nên chỉ đề nghị "chọn hết rồi chép" thay vì đoán.
            addItem("Chọn hết & Sao chép") { selectAllThenCopy() }
        }
        if (clipboard.hasPrimaryClip()) {
            addItem("Dán") { pasteFromClipboard() }
        }

        if (container.childCount == 0) return // không có gì để làm — không hiện menu trống

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x.toInt().coerceAtLeast(0)
            // Hiện phía TRÊN điểm nhấn 1 chút (giống menu chọn chuẩn của hệ
            // thống) để ngón tay không che mất menu vừa hiện ra.
            this.y = (y - dp(70)).toInt().coerceAtLeast(dp(24))
            token = hostView.windowToken
        }

        try {
            windowManager.addView(container, params)
            popupView = container
        } catch (e: Exception) {
            DebugLog.log("SelectionFallbackMenu: lỗi hiện popup — ${e.message}")
        }
    }

    /**
     * SỬA LẠI HOÀN TOÀN (mục 76 PROJECT_STATUS.md — người dùng báo qua ảnh
     * chụp: menu "Sao chép/Cắt" của chính class này CÓ hiện ra trong Colab
     * nhưng bấm vào "vô dụng", và "Dán" ở nơi khác cũng "nhấn mà chẳng có
     * gì xảy ra"). Nguyên nhân thật: cả 4 hàm bên dưới trước đây dùng
     * `document.execCommand(...)` — API này chỉ có tác dụng trên
     * `<textarea>`/`<input>`/`contentEditable` THẬT SỰ để trình duyệt tự
     * quản lý nội dung. Monaco (editor Colab dùng) KHÔNG quản lý nội dung
     * qua DOM theo kiểu đó — nó tự vẽ giao diện bằng các `<div>` định vị
     * theo dòng/cột, và bộ đệm văn bản thật nằm trong mô hình JS nội bộ
     * của Monaco. Input/output duy nhất Monaco THẬT SỰ lắng nghe là các SỰ
     * KIỆN CLIPBOARD gốc (`copy`/`cut`/`paste` — đúng cách trình duyệt bắn
     * ra khi người dùng bấm Ctrl+V/Ctrl+C thật, hoặc khi hệ điều hành dán
     * qua IME) trên ô `<textarea>` ẩn nó dùng để bắt sự kiện bàn phím —
     * KHÔNG PHẢI lệnh `execCommand`, vốn chỉ là API thao tác DOM trực tiếp
     * mà Monaco hoàn toàn bỏ qua vì tự quản lý nội dung riêng.
     *
     * Sửa đúng chỗ: thay `execCommand` bằng cách tự tạo và bắn 1
     * `ClipboardEvent` THẬT (`new ClipboardEvent('paste'/'copy'/'cut', {
     * clipboardData: new DataTransfer() })`) vào đúng phần tử đang focus —
     * đây là cách JS "giả lập" một thao tác Ctrl+V/C/X thật mà Monaco (và
     * mọi framework editor khác lắng nghe sự kiện clipboard chuẩn) nhận ra
     * và xử lý bằng đúng logic nội bộ của nó. Với "Dán": nếu sau khi bắn sự
     * kiện mà không có ai gọi `preventDefault()` (nghĩa là không phải
     * Monaco, không ai xử lý), coi như trang DOM chuẩn và fallback về
     * `execCommand('insertText', ...)` như cũ. Với "Sao chép/Cắt": đọc
     * lại đúng `DataTransfer` mà TRANG TỰ GHI VÀO trong lúc xử lý sự kiện
     * — nếu trang không ghi gì (không tự xử lý), fallback về
     * `window.getSelection()`/`execCommand('delete')` như cũ cho các trang
     * DOM chuẩn khác (claude.ai...).
     */
    private fun copySelectionToClipboard() {
        val engine = engineProvider()
        engine.evaluateJs(
            """(function(){
                try {
                    var dt = new DataTransfer();
                    var ev = new ClipboardEvent('copy', { clipboardData: dt, bubbles: true, cancelable: true });
                    var target = document.activeElement || document;
                    while (target && target.shadowRoot && target.shadowRoot.activeElement) { target = target.shadowRoot.activeElement; }
                    target.dispatchEvent(ev);
                    var text = dt.getData('text/plain');
                    if (text) return text;
                    return String(window.getSelection().toString());
                } catch(e) { return ''; }
            })()"""
        ) { raw ->
            val result = unwrap(raw)
            if (!result.isNullOrEmpty() && result != "null") {
                handler.post {
                    clipboard.setPrimaryClip(ClipData.newPlainText("colab-live-browser", result))
                }
            }
        }
    }

    private fun cutSelectionToClipboard() {
        val engine = engineProvider()
        engine.evaluateJs(
            """(function(){
                try {
                    var dt = new DataTransfer();
                    var ev = new ClipboardEvent('cut', { clipboardData: dt, bubbles: true, cancelable: true });
                    var target = document.activeElement || document;
                    while (target && target.shadowRoot && target.shadowRoot.activeElement) { target = target.shadowRoot.activeElement; }
                    target.dispatchEvent(ev);
                    var text = dt.getData('text/plain');
                    if (text) return text; // trang (Monaco...) đã tự bắt sự kiện và tự xoá theo đúng logic của nó
                    // Không ai xử lý — coi như trang DOM chuẩn khác, tự lấy + tự xoá như cách cũ
                    text = String(window.getSelection().toString());
                    if (text) { try { document.execCommand('delete'); } catch(e2) {} }
                    return text;
                } catch(e) { return ''; }
            })()"""
        ) { raw ->
            val result = unwrap(raw)
            if (!result.isNullOrEmpty() && result != "null") {
                handler.post {
                    clipboard.setPrimaryClip(ClipData.newPlainText("colab-live-browser", result))
                }
            }
        }
    }

    private fun selectAllThenCopy() {
        val engine = engineProvider()
        engine.evaluateJs(
            """(function(){
                try {
                    document.execCommand('selectAll');
                    var dt = new DataTransfer();
                    var ev = new ClipboardEvent('copy', { clipboardData: dt, bubbles: true, cancelable: true });
                    var target = document.activeElement || document;
                    while (target && target.shadowRoot && target.shadowRoot.activeElement) { target = target.shadowRoot.activeElement; }
                    target.dispatchEvent(ev);
                    var text = dt.getData('text/plain');
                    if (text) return text;
                    return String(window.getSelection().toString());
                } catch(e) { return ''; }
            })()"""
        ) { raw ->
            val result = unwrap(raw)
            if (!result.isNullOrEmpty() && result != "null") {
                handler.post {
                    clipboard.setPrimaryClip(ClipData.newPlainText("colab-live-browser", result))
                }
            } else {
                DebugLog.log("SelectionFallbackMenu: selectAll+copy (kể cả qua ClipboardEvent) vẫn rỗng — trang này thật sự không lộ nội dung qua cả 2 đường")
            }
        }
    }

    /**
     * SỬA ĐÚNG NGUYÊN NHÂN GỐC (mục 80.3 PROJECT_STATUS.md — người dùng vẫn
     * báo "Dán trong menu nhấn đè không phản ứng" dù log cho thấy sự kiện
     * 'paste' giả lập ĐÃ chạy tới `dispatched-handled-by-page`).
     *
     * 2 bug thật tìm ra khi audit lại, cả 2 đều là lý do khiến các lượt sửa
     * trước "coi như đã sửa" nhưng thật ra chưa hề có bằng chứng:
     *
     * 1) CHẨN ĐOÁN THÊM Ở MỤC 80.3 LÀ CODE CHẾT — không bao giờ tới được
     *    log app: nó dùng `console.log(...)` bên trong `setTimeout` chạy ở
     *    PHÍA TRANG, nhưng codebase này CHƯA TỪNG override
     *    `GeckoSession.ContentDelegate`/hook nào để bắt console message của
     *    trang và ghi ra `DebugLog` (đã grep toàn bộ `GeckoViewEngine.kt`,
     *    `MainActivity.kt` — không có `onConsoleMessage` nào cả). Nghĩa là
     *    suốt từ mục 80 tới giờ, dòng "[colablive] CHẨN ĐOÁN paste #N..."
     *    KHÔNG BAO GIỜ được người dùng nhìn thấy dù code sinh ra nó có chạy
     *    hay không — team luôn thiếu đúng bằng chứng cần để đi tiếp, không
     *    phải vì bug khó, mà vì chính công cụ đo đạc bị điếc. Sửa: đo đạc
     *    lại bằng 1 lời gọi `evaluateJs` THỨ HAI từ phía Kotlin (không phải
     *    console.log phía JS) — luôn tới được `DebugLog` vì đi qua đúng
     *    cùng con đường callback đã dùng cho mọi log khác trong file này.
     *
     * 2) NGUYÊN NHÂN THẬT NHIỀU KHẢ NĂNG NHẤT của "không phản ứng": việc mô
     *    phỏng thao tác dán bằng cách BẮN SỰ KIỆN `paste` GIẢ LẬP
     *    (`el.dispatchEvent(new ClipboardEvent(...))`) tự nó KHÔNG PHẢI 1
     *    "trusted event" (`event.isTrusted` luôn = `false` với mọi sự kiện
     *    JS tự tạo — xác nhận qua MDN: "DragEvent(): Creates a synthetic
     *    and untrusted DragEvent", cùng nguyên tắc áp dụng cho MỌI event
     *    constructor kể cả ClipboardEvent). Nếu Monaco (hoặc phần nào khác
     *    của trang) khi bắt 'paste' lại tự gọi
     *    `navigator.clipboard.readText()` (Async Clipboard API) thay vì
     *    dùng `event.clipboardData` mình gán — API này theo spec yêu cầu
     *    "transient user activation" của TRANG, mà 1 sự kiện JS tự bắn từ
     *    `evaluateJs()` (không xuất phát từ input thật do Gecko xử lý)
     *    không tạo ra activation đó — lời gọi có thể bị từ chối hoặc treo
     *    ÂM THẦM (không throw ra `notCancelled`), khớp đúng cảm giác "bấm
     *    mà chẳng có gì xảy ra".
     *
     *    SỬA ĐÚNG GỐC: BỎ HẲN việc phụ thuộc vào sự kiện clipboard DOM cho
     *    đúng trường hợp Monaco — gọi THẲNG vào API lệnh công khai của
     *    Monaco (`editor.trigger(source, 'paste', { text })`, hằng số
     *    `editorCommon.Handler.Paste` trong chính mã nguồn Monaco) để chèn
     *    text vào đúng vị trí con trỏ — đây là API Monaco tự dùng nội bộ
     *    mỗi khi xử lý paste thật, không đi qua bất kỳ ClipboardEvent hay
     *    Clipboard API bất đồng bộ nào cả, nên không phụ thuộc gì vào
     *    isTrusted/user-activation. Chỉ fallback về ClipboardEvent+
     *    execCommand cho các trang KHÔNG PHẢI Monaco (DOM chuẩn khác).
     */
    /**
     * Dán TRUSTED trước (Ctrl+V native, có tự kiểm chứng), chỉ khi không xác nhận được
     * mới rơi về đường giả lập sự kiện cũ (xem NativePaste.kt, mục 99).
     */
    private fun pasteFromClipboard() {
        val clip = clipboard.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(context)?.toString() ?: return
        val engine = engineProvider()
        NativePaste.paste(context, hostView, text, { js, cb -> engine.evaluateJs(js, cb) }) { ok ->
            if (!ok) pasteViaSyntheticEvent()
        }
    }

    private fun pasteViaSyntheticEvent() {
        val clip = clipboard.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(context)?.toString() ?: return
        // JSON.stringify để escape an toàn (xuống dòng, dấu nháy...) trước khi
        // chèn vào chuỗi script — text dán có thể chứa BẤT KỲ ký tự nào.
        val jsonEscaped = org.json.JSONObject.quote(text)
        val engine = engineProvider()
        engine.evaluateJs(
            """(function(){
                try {
                    /**
                     * BUG THẬT xác nhận qua log thật (mục 91 — không còn
                     * suy đoán): kết quả trả về từng ghi
                     * `activeEl=DIV.shadow-root-host` trên đúng trang
                     * Colab — nghĩa là ô soạn thảo thật của Colab nằm
                     * TRONG 1 Shadow DOM (Web Component), còn
                     * `document.activeElement` ở tài liệu ngoài cùng CHỈ
                     * trả về đúng cái "vỏ" (shadow host), KHÔNG xuyên qua
                     * được ranh giới shadow để lấy phần tử thật đang focus
                     * bên trong — đây là hành vi CHUẨN của DOM (Shadow DOM
                     * cố tình cô lập, không phải lỗi trình duyệt). Toàn bộ
                     * logic cũ (tìm Monaco bằng containment, dispatch
                     * ClipboardEvent, execCommand) đều thao tác nhầm lên
                     * cái VỎ NGOÀI (1 <div> không có handler paste nào cả)
                     * thay vì phần tử thật — khớp chính xác triệu chứng
                     * "bấm Dán không có phản ứng gì".
                     *
                     * Sửa: xuyên qua shadow root để lấy đúng phần tử đang
                     * focus thật sự (đệ quy `el.shadowRoot.activeElement`
                     * cho tới khi hết shadow root lồng nhau) TRƯỚC khi làm
                     * bất kỳ việc gì khác.
                     */
                    function deepActiveElement(root) {
                        var el = root.activeElement;
                        while (el && el.shadowRoot && el.shadowRoot.activeElement) {
                            el = el.shadowRoot.activeElement;
                        }
                        return el;
                    }
                    var el = deepActiveElement(document);
                    if (!el) return 'no-active-element';

                    // Log thật 17:04-17:05: nhấn giữ trong ô code làm Monaco mở
                    // menu chuột phải riêng, menu đó cướp focus (activeEl =
                    // UL.actions-container) nên Dán bắn nhầm vào danh sách menu.
                    // Nếu phần tử đang focus KHÔNG phải ô soạn thảo, dùng lại ô
                    // soạn thảo được focus gần nhất (do eval_bridge/content.js
                    // ghi nhớ ngay lúc nó nhận focus) và trả focus về đó.
                    function isEditableEl(x) {
                        if (!x || !x.tagName) return false;
                        if (x.isContentEditable || x.tagName === 'TEXTAREA') return true;
                        return x.tagName === 'INPUT';
                    }
                    var focusRecovered = 'không cần';
                    if (!isEditableEl(el)) {
                        var last = window.__lbLastEditable;
                        if (last && last.isConnected && isEditableEl(last)) {
                            try { last.focus(); } catch (eF) {}
                            el = last;
                            focusRecovered = 'ĐÃ trả focus về ô soạn thảo gần nhất';
                        } else {
                            focusRecovered = 'KHÔNG có ô soạn thảo nào được ghi nhớ';
                        }
                    }

                    var monacoModel = null, monacoEditor = null;
                    var monacoDiag = 'window.monaco=' + (typeof window.monaco) +
                        ' activeEl(xuyên shadow)=' + (el.tagName || '?') + '.' + (el.className || '') +
                        ' contentEditable=' + (el.isContentEditable) +
                        ' focus=' + focusRecovered;
                    try {
                        if (window.monaco && window.monaco.editor && window.monaco.editor.getEditors) {
                            var eds = window.monaco.editor.getEditors();
                            monacoDiag += ' getEditors().length=' + eds.length;
                            for (var i = 0; i < eds.length; i++) {
                                var dn = eds[i].getDomNode && eds[i].getDomNode();
                                if (dn && dn.contains(el)) { monacoEditor = eds[i]; monacoModel = eds[i].getModel(); break; }
                            }
                        }
                    } catch (eM) { monacoDiag += ' err=' + eM.message; }

                    if (monacoEditor) {
                        // Đường CHÍNH cho Monaco (Colab...): gọi thẳng lệnh
                        // 'paste' nội bộ của Monaco — không qua DOM
                        // ClipboardEvent/Async Clipboard API nào cả, nên
                        // không bị chặn bởi isTrusted/thiếu user-activation.
                        var lenBefore = monacoModel ? (monacoModel.getValueLength ? monacoModel.getValueLength() : monacoModel.getValue().length) : null;
                        monacoEditor.focus();
                        monacoEditor.trigger('colablive-paste-menu', 'paste', {
                            text: $jsonEscaped,
                            pasteOnNewLine: false,
                            multicursorText: null
                        });
                        window.__lbPasteModel = monacoModel;
                        window.__lbPasteLenBefore = lenBefore;
                        return 'monaco-trigger-paste(lenBefore=' + lenBefore + ') [' + monacoDiag + ']';
                    }

                    var dt = new DataTransfer();
                    dt.setData('text/plain', $jsonEscaped);
                    var ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
                    var notCancelled = el.dispatchEvent(ev);
                    if (notCancelled) {
                        // Không ai gọi preventDefault() — không phải Monaco/
                        // không ai tự xử lý sự kiện paste — fallback về
                        // execCommand cho các ô nhập DOM chuẩn (input/
                        // textarea/contentEditable ngoài Monaco).
                        try { document.execCommand('insertText', false, $jsonEscaped); } catch(e2) {}
                        return 'dispatched-fallback-execCommand [' + monacoDiag + ']';
                    }
                    return 'dispatched-handled-by-page [' + monacoDiag + ']';
                } catch(e) { return 'err:' + e.message; }
            })()"""
        ) { raw ->
            val result = unwrap(raw)
            DebugLog.log("SelectionFallbackMenu: paste kết quả=$raw")
            // Đo lại SAU 450ms bằng 1 lời gọi evaluateJs THỨ HAI (không phải
            // console.log phía trang — xem chú thích ở trên vì sao console.log
            // không bao giờ tới được DebugLog) — chỉ áp dụng khi đường Monaco
            // vừa chạy (đã lưu window.__lbPasteModel).
            if (result != null && result.startsWith("monaco-trigger-paste")) {
                handler.postDelayed({
                    engine.evaluateJs(
                        """(function(){
                            try {
                                var m = window.__lbPasteModel;
                                var before = window.__lbPasteLenBefore;
                                delete window.__lbPasteModel;
                                delete window.__lbPasteLenBefore;
                                if (!m || before === null) return 'no-model-to-check';
                                var after = m.getValueLength ? m.getValueLength() : m.getValue().length;
                                return 'lenBefore=' + before + ' lenAfter=' + after + ' delta=' + (after - before);
                            } catch (e) { return 'err:' + e.message; }
                        })()"""
                    ) { diag ->
                        DebugLog.log("SelectionFallbackMenu: CHẨN ĐOÁN paste (đo sau 450ms) — $diag")
                    }
                }, 450L)
            }
        }
    }

    /**
     * Gọi từ LbGeckoView khi bàn phím ảo gửi lệnh Xoá lùi. Nếu đang có vùng chọn Monaco thì tự xoá vùng chọn bằng phím giả
     * vào ô nhập và trả true (đã xử lý, không cho Gecko xoá 1 ký tự sai chỗ). Không có vùng chọn thì trả false.
     */
    fun tryDeleteMonacoSelection(): Boolean {
        if (!monacoUi.selectionActive) return false
        DebugLog.log("SelectionFallbackMenu: bàn phím ảo bấm Xoá khi có vùng chọn Monaco → xoá vùng chọn thay vì xoá 1 ký tự")
        monacoUi.dismiss()
        monacoUi.selectionActive = false
        NativeClipKeys.deleteSelection({ js, cb -> engineProvider().evaluateJs(js, cb) }) { ok ->
            DebugLog.log("SelectionFallbackMenu: xoá vùng chọn bằng phím Xoá bàn phím → ${if (ok) "THÀNH CÔNG" else "KHÔNG thành công"}")
            if (!ok) monacoUi.verifySelection()
        }
        return true
    }

    fun dismiss() {
        popupView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) { /* đã bị gỡ hoặc window chết — bỏ qua */ }
        }
        popupView = null
        monacoUi.dismiss()
    }
}
