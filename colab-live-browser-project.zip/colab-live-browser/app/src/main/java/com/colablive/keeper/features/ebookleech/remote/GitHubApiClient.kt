package com.colablive.keeper.features.ebookleech.remote

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * GitHubApiClient — gọi thẳng REST API GitHub bằng `HttpURLConnection`
 * (framework Android, không cần OkHttp/Retrofit — `:core` có OkHttp cho
 * riêng nó nhưng KHÔNG expose ra ngoài, xem ghi chú trong `SecureTokenStore.kt`
 * về lý do addon này tránh mọi dependency ngoài framework khi có thể).
 *
 * CHỈ dùng 3 nhóm endpoint cần cho "cào từ xa":
 * 1. Contents API — ghi/đọc file JSON job-spec + checkpoint trực tiếp
 *    trong repo (thay vì workflow_dispatch inputs — input có giới hạn
 *    kích thước, job phức tạp (nhiều regex rule, kịch bản nhiều bước) có
 *    thể vượt qua giới hạn đó).
 * 2. Actions API — kích hoạt workflow (`workflow_dispatch`) + tra cứu
 *    trạng thái lần chạy.
 * 3. Git Trees API — CHỈ để liệt kê thư mục có từ 1000 file trở lên (Contents API cắt cứng ở 1000).
 *
 * Bản 7.103 (mục 227) — vá các giới hạn của GitHub đã tra trong tài liệu chính thức:
 *  - Contents API trả `content` base64 CHỈ cho file ≤ 1 MB; file 1–100 MB phải dùng media type `raw` (nội dung) / `object` (lấy `sha`). Trước đây checkpoint > 1 MB (job vài trăm chương)
 *    đọc HỎNG và ghi đè KHÔNG được (không lấy được sha => GitHub từ chối) => nay đọc bằng `application/vnd.github.raw+json`, lấy sha bằng `application/vnd.github.object+json`.
 *  - Poll checkpoint mỗi ~20 giây: gửi `If-None-Match` với ETag lần trước; GitHub trả 304 (KHÔNG tải lại thân, KHÔNG tính vào hạn mức primary rate limit) khi file chưa đổi.
 *    Bộ nhớ đệm nằm trong RAM, có trần dung lượng (xem CACHE_MAX_*), `clearCache()` khi xong job.
 *  - Thư mục ≥ 1000 mục: Contents API chỉ trả 1000 => chuyển sang Git Trees API (đi từng cấp, không dùng `recursive`).
 *  - Giới hạn tốc độ: HTTP 429, hoặc 403 kèm `Retry-After` / `x-ratelimit-remaining: 0` / thông báo "rate limit" => chờ đúng `Retry-After` (tối đa MAX_WAIT_SEC) rồi thử lại tối đa MAX_RETRY lần;
 *    chờ lâu hơn (hết hạn mức giờ) thì trả lỗi rõ ràng thay vì treo luồng.
 *  - Ghi file: nếu GitHub báo 409/422 (sha lệch — một runner khác như LeechDesk vừa ghi cùng file) => đọc lại sha rồi ghi lại MỘT lần.
 *
 * TẤT CẢ hàm ở đây BLOCKING (I/O đồng bộ) — PHẢI gọi từ background thread,
 * KHÔNG BAO GIỜ gọi trực tiếp từ main thread (sẽ crash
 * NetworkOnMainThreadException).
 */
object GitHubApiClient {

    sealed class ApiResult<out T> {
        data class Ok<T>(val value: T) : ApiResult<T>()
        data class Err(val message: String, val httpCode: Int = -1) : ApiResult<Nothing>()
    }

    /** Gốc API. Chỉ đổi khi kiểm thử trên JVM với GitHub giả (hoặc GitHub Enterprise Server); mặc định api.github.com. */
    @Volatile var apiBase: String = "https://api.github.com"

    private const val ACCEPT_JSON = "application/vnd.github+json"
    private const val ACCEPT_RAW = "application/vnd.github.raw+json"
    private const val ACCEPT_OBJECT = "application/vnd.github.object+json"
    private const val READ_TIMEOUT_MS = 20_000
    private const val RAW_TIMEOUT_MS = 90_000      // file lớn (tới 100 MB theo tài liệu) tải lâu hơn
    private const val CONTENTS_DIR_CAP = 1000      // Contents API chỉ liệt kê tối đa 1000 mục của thư mục
    private const val MAX_RETRY = 2
    private const val MAX_WAIT_SEC = 65L
    private const val CACHE_MAX_ENTRY = 24L * 1024 * 1024
    private const val CACHE_MAX_TOTAL = 40L * 1024 * 1024

    // ───────── bộ nhớ đệm ETag (RAM) ─────────
    private class CacheEntry(val etag: String, val bytes: ByteArray)
    private val cacheLock = Any()
    private val cache = LinkedHashMap<String, CacheEntry>(16, 0.75f, true)   // accessOrder=true => LRU
    private var cacheBytes = 0L

    private fun cacheGet(key: String): CacheEntry? = synchronized(cacheLock) { cache[key] }

    private fun cachePut(key: String, etag: String, bytes: ByteArray) {
        if (bytes.size > CACHE_MAX_ENTRY) return
        synchronized(cacheLock) {
            cache.remove(key)?.let { cacheBytes -= it.bytes.size }
            while (cacheBytes + bytes.size > CACHE_MAX_TOTAL && cache.isNotEmpty()) {
                val eldest = cache.entries.iterator().next()
                cacheBytes -= eldest.value.bytes.size
                cache.remove(eldest.key)
            }
            cache[key] = CacheEntry(etag, bytes)
            cacheBytes += bytes.size
        }
    }

    /** Giải phóng bộ nhớ đệm (gọi khi một job cào từ xa kết thúc / bị huỷ). */
    fun clearCache() = synchronized(cacheLock) { cache.clear(); cacheBytes = 0L }

    // ───────── tầng HTTP ─────────
    private class Resp(
        val code: Int, val bytes: ByteArray, val etag: String?,
        val retryAfterSec: Long?, val rateRemaining: Int?, val rateResetEpochSec: Long?,
        val fromCache: Boolean = false,
    ) {
        val ok: Boolean get() = code in 200..299
        val text: String get() = String(bytes, Charsets.UTF_8)
    }

    private fun connect(url: String, token: String, method: String, accept: String = ACCEPT_JSON, readTimeoutMs: Int = READ_TIMEOUT_MS): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Accept", accept)
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        conn.useCaches = false
        conn.connectTimeout = 15_000
        conn.readTimeout = readTimeoutMs
        return conn
    }

    private fun rawCall(method: String, url: String, token: String, accept: String, readTimeoutMs: Int, body: ByteArray?, ifNoneMatch: String?): Resp {
        val conn = connect(url, token, method, accept, readTimeoutMs)
        try {
            if (ifNoneMatch != null) conn.setRequestProperty("If-None-Match", ifNoneMatch)
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            return Resp(
                code, bytes, conn.getHeaderField("ETag"),
                conn.getHeaderField("Retry-After")?.trim()?.toLongOrNull(),
                conn.getHeaderField("x-ratelimit-remaining")?.trim()?.toIntOrNull(),
                conn.getHeaderField("x-ratelimit-reset")?.trim()?.toLongOrNull(),
            )
        } finally {
            conn.disconnect()
        }
    }

    private fun isRateLimited(r: Resp): Boolean =
        r.code == 429 || (r.code == 403 && (r.retryAfterSec != null || r.rateRemaining == 0 || r.text.contains("rate limit", ignoreCase = true)))

    /** Số giây nên chờ: `Retry-After`; hết hạn mức chính => tới mốc reset; còn lại (giới hạn phụ) => 60 giây như tài liệu GitHub khuyến nghị. */
    private fun waitSeconds(r: Resp): Long {
        r.retryAfterSec?.let { return it.coerceAtLeast(1L) }
        if (r.rateRemaining == 0 && r.rateResetEpochSec != null) {
            return (r.rateResetEpochSec - System.currentTimeMillis() / 1000L).coerceAtLeast(1L)
        }
        return 60L
    }

    private fun rateLimitMessage(r: Resp): String {
        val w = waitSeconds(r)
        val human = if (w >= 120) "${w / 60} phút" else "$w giây"
        return "GitHub đang giới hạn tốc độ (HTTP ${r.code}) — cần chờ ~$human rồi thử lại"
    }

    /**
     * Gọi 1 request: có thể dùng bộ nhớ đệm ETag (`cacheable`, chỉ cho GET), tự chờ + thử lại khi bị giới hạn tốc độ.
     * 304 được trả về như 200 với `fromCache=true` và thân lấy từ bộ nhớ đệm.
     */
    private fun call(method: String, url: String, token: String, accept: String = ACCEPT_JSON, readTimeoutMs: Int = READ_TIMEOUT_MS,
                     body: ByteArray? = null, cacheable: Boolean = false): Resp {
        val key = "$accept $url"
        var attempt = 0
        while (true) {
            val cached = if (cacheable) cacheGet(key) else null
            var r = rawCall(method, url, token, accept, readTimeoutMs, body, cached?.etag)
            if (r.code == 304 && cached != null) {
                r = Resp(200, cached.bytes, cached.etag, r.retryAfterSec, r.rateRemaining, r.rateResetEpochSec, fromCache = true)
            } else if (cacheable && r.ok && r.etag != null) {
                cachePut(key, r.etag, r.bytes)
            }
            if (!isRateLimited(r) || attempt >= MAX_RETRY) return r
            val wait = waitSeconds(r)
            if (wait > MAX_WAIT_SEC) return r      // hết hạn mức giờ: đừng treo luồng, để người gọi báo lỗi
            attempt++
            try { Thread.sleep(wait * 1000L) } catch (e: InterruptedException) { Thread.currentThread().interrupt(); return r }
        }
    }

    private fun httpError(what: String, r: Resp): ApiResult.Err =
        if (isRateLimited(r)) ApiResult.Err("$what: ${rateLimitMessage(r)}", r.code)
        else ApiResult.Err("$what lỗi HTTP ${r.code}: ${r.text}", r.code)

    private fun contentsUrl(owner: String, repo: String, branch: String, path: String) =
        "$apiBase/repos/$owner/$repo/contents/$path?ref=$branch"

    // ───────── ghi ─────────
    /**
     * Ghi (tạo mới hoặc cập nhật) 1 file trong repo qua Contents API. Tự
     * đọc `sha` hiện có nếu file đã tồn tại (Contents API BẮT BUỘC phải
     * có đúng `sha` cũ mới cho phép ghi đè — tránh mất dữ liệu do ghi đè
     * nhầm bản cũ hơn).
     */
    fun putFile(owner: String, repo: String, branch: String, token: String, path: String, content: String, message: String): ApiResult<Unit> =
        putBytesInternal(owner, repo, branch, token, path, content.toByteArray(Charsets.UTF_8), message, "PUT $path")

    /** Ghi bytes THẬT (nhị phân, vd ảnh) — biến thể của `putFile()` cho nội
     * dung không phải text UTF-8. */
    fun putFileBytes(owner: String, repo: String, branch: String, token: String, path: String, bytes: ByteArray, message: String): ApiResult<Unit> =
        putBytesInternal(owner, repo, branch, token, path, bytes, message, "PUT $path (bytes)")

    private fun putBytesInternal(owner: String, repo: String, branch: String, token: String, path: String, bytes: ByteArray, message: String, what: String): ApiResult<Unit> {
        return try {
            val url = "$apiBase/repos/$owner/$repo/contents/$path"
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            var last: ApiResult<Unit> = ApiResult.Err("$what: chưa gửi được")
            for (attempt in 0..1) {
                val existingSha = getFileSha(owner, repo, branch, token, path)
                val body = JSONObject().apply {
                    put("message", message)
                    put("content", b64)
                    put("branch", branch)
                    if (existingSha != null) put("sha", existingSha)
                }
                val r = call("PUT", url, token, body = body.toString().toByteArray(Charsets.UTF_8))
                if (r.ok) return ApiResult.Ok(Unit)
                last = httpError(what, r)
                // 409/422: sha lệch vì runner khác (vd LeechDesk) vừa ghi cùng file giữa lúc ta đọc sha và ghi => đọc sha mới, thử đúng một lần nữa.
                if (r.code != 409 && r.code != 422) break
            }
            last
        } catch (e: Exception) {
            ApiResult.Err("$what lỗi mạng: ${e.message}")
        }
    }

    /** @return `sha` của file nếu đã tồn tại, `null` nếu chưa có (file mới). Dùng media type `object` nên cũng đúng với file > 1 MB (JSON thường không trả được). */
    private fun getFileSha(owner: String, repo: String, branch: String, token: String, path: String): String? {
        return try {
            val r = call("GET", contentsUrl(owner, repo, branch, path), token, ACCEPT_OBJECT, 30_000)
            if (r.code != 200) return null
            val sha = JSONObject(r.text).optString("sha", "")
            if (sha.isEmpty()) null else sha
        } catch (e: Exception) {
            null
        }
    }

    // ───────── đọc ─────────
    /** Đọc nội dung 1 file text từ repo (UTF-8) — dùng để đọc checkpoint
     * Python script commit lên giữa chừng job đang chạy. Dùng media type `raw` (đọc được file tới 100 MB) + ETag/304. */
    fun getFileContent(owner: String, repo: String, branch: String, token: String, path: String): ApiResult<String> {
        return try {
            val r = call("GET", contentsUrl(owner, repo, branch, path), token, ACCEPT_RAW, RAW_TIMEOUT_MS, cacheable = true)
            if (r.code == 404) return ApiResult.Err("Chưa có file (404) — job có thể chưa bắt đầu chạy trên Actions", 404)
            if (!r.ok) return httpError("GET $path", r)
            ApiResult.Ok(r.text)
        } catch (e: Exception) {
            ApiResult.Err("GET $path lỗi mạng: ${e.message}")
        }
    }

    /** Đọc bytes THẬT (không ép UTF-8 text) — dùng cho file nhị phân (ảnh). */
    fun getFileBytes(owner: String, repo: String, branch: String, token: String, path: String): ApiResult<ByteArray> {
        return try {
            // Ảnh bất biến (tên file theo chương) nên KHÔNG đưa vào bộ nhớ đệm ETag — tránh chiếm RAM.
            val r = call("GET", contentsUrl(owner, repo, branch, path), token, ACCEPT_RAW, RAW_TIMEOUT_MS, cacheable = false)
            if (r.code == 404) return ApiResult.Err("Chưa có file (404)", 404)
            if (!r.ok) return httpError("GET $path (bytes)", r)
            ApiResult.Ok(r.bytes)
        } catch (e: Exception) {
            ApiResult.Err("GET $path (bytes) lỗi mạng: ${e.message}")
        }
    }

    /** Liệt kê tên file trong 1 thư mục của repo (Contents API trả mảng
     * khi `path` trỏ tới thư mục thay vì 1 file) — dùng để biết ảnh nào
     * MỚI được Python commit thêm kể từ lần đồng bộ trước.
     * Thư mục có từ 1000 mục trở lên: Contents API CHỈ trả 1000 => chuyển sang Git Trees API để lấy đủ. */
    fun listDirectory(owner: String, repo: String, branch: String, token: String, path: String): ApiResult<List<String>> {
        return try {
            val r = call("GET", contentsUrl(owner, repo, branch, path), token, ACCEPT_JSON, cacheable = true)
            if (r.code == 404) return ApiResult.Ok(emptyList())  // thư mục chưa tồn tại — bình thường (chưa có ảnh nào commit)
            if (!r.ok) return httpError("Liệt kê $path", r)
            val arr = JSONArray(r.text)
            if (arr.length() >= CONTENTS_DIR_CAP) return listViaTrees(owner, repo, branch, token, path)
            val names = (0 until arr.length()).mapNotNull { i ->
                val entry = arr.getJSONObject(i)
                if (entry.optString("type") == "file") entry.optString("name") else null
            }
            ApiResult.Ok(names)
        } catch (e: Exception) {
            ApiResult.Err("Liệt kê $path lỗi mạng: ${e.message}")
        }
    }

    /** Liệt kê file của thư mục qua Git Trees API: đi từng cấp từ gốc nhánh (không dùng `recursive`), lấy sha cây con, rồi đọc cây đích. */
    private fun listViaTrees(owner: String, repo: String, branch: String, token: String, path: String): ApiResult<List<String>> {
        var cur = URLEncoder.encode(branch, "UTF-8")
        for (seg in path.trim('/').split('/').filter { it.isNotEmpty() }) {
            val r = call("GET", "$apiBase/repos/$owner/$repo/git/trees/$cur", token, cacheable = true)
            if (r.code == 404) return ApiResult.Ok(emptyList())
            if (!r.ok) return httpError("Đọc cây $seg", r)
            val tree = JSONObject(r.text).optJSONArray("tree") ?: return ApiResult.Ok(emptyList())
            var next: String? = null
            for (i in 0 until tree.length()) {
                val e = tree.getJSONObject(i)
                if (e.optString("type") == "tree" && e.optString("path") == seg) { next = e.optString("sha"); break }
            }
            cur = next ?: return ApiResult.Ok(emptyList())
        }
        val r = call("GET", "$apiBase/repos/$owner/$repo/git/trees/$cur", token, cacheable = true)
        if (!r.ok) return httpError("Liệt kê $path (Git Trees)", r)
        val tree = JSONObject(r.text).optJSONArray("tree") ?: return ApiResult.Ok(emptyList())
        val names = (0 until tree.length()).mapNotNull { i ->
            val e = tree.getJSONObject(i)
            if (e.optString("type") == "blob") e.optString("path") else null
        }
        return ApiResult.Ok(names)
    }

    // ───────── Actions ─────────
    /** Kích hoạt workflow qua `workflow_dispatch`. `workflowFile` = tên
     * file (vd "ebookleech-remote-crawl.yml"), KHÔNG phải đường dẫn đầy đủ. */
    fun dispatchWorkflow(owner: String, repo: String, branch: String, token: String, workflowFile: String, inputs: Map<String, String>): ApiResult<Unit> {
        return try {
            val url = "$apiBase/repos/$owner/$repo/actions/workflows/$workflowFile/dispatches"
            val body = JSONObject().apply {
                put("ref", branch)
                put("inputs", JSONObject(inputs as Map<*, *>))
            }
            val r = call("POST", url, token, body = body.toString().toByteArray(Charsets.UTF_8))
            if (r.ok) ApiResult.Ok(Unit)
            else ApiResult.Err("Kích hoạt workflow lỗi HTTP ${r.code}: ${r.text} — kiểm tra token có quyền 'workflow' và đúng tên file workflow chưa", r.code)
        } catch (e: Exception) {
            ApiResult.Err("Kích hoạt workflow lỗi mạng: ${e.message}")
        }
    }

    data class RunInfo(val id: Long, val status: String, val conclusion: String?)

    /**
     * Tìm lần chạy MỚI NHẤT của workflow (sắp theo thời gian tạo giảm dần
     * — GitHub trả sẵn theo thứ tự này). Gọi NGAY SAU `dispatchWorkflow()`
     * vài giây — `workflow_dispatch` không trả về run id trực tiếp (API
     * GitHub thiết kế vậy, không phải giới hạn của client này), phải tra
     * cứu lại theo cách này.
     */
    fun findLatestRun(owner: String, repo: String, token: String, workflowFile: String): ApiResult<RunInfo> {
        return try {
            val r = call("GET", "$apiBase/repos/$owner/$repo/actions/workflows/$workflowFile/runs?per_page=1", token)
            if (!r.ok) return ApiResult.Err("Tra cứu lần chạy lỗi HTTP ${r.code}: ${r.text}", r.code)
            val arr: JSONArray = JSONObject(r.text).getJSONArray("workflow_runs")
            if (arr.length() == 0) return ApiResult.Err("Chưa có lần chạy nào — workflow có thể chưa được kích hoạt đúng")
            val run = arr.getJSONObject(0)
            ApiResult.Ok(RunInfo(run.getLong("id"), run.getString("status"), run.optString("conclusion", null)))
        } catch (e: Exception) {
            ApiResult.Err("Tra cứu lần chạy lỗi mạng: ${e.message}")
        }
    }

    fun getRunStatus(owner: String, repo: String, token: String, runId: Long): ApiResult<RunInfo> {
        return try {
            val r = call("GET", "$apiBase/repos/$owner/$repo/actions/runs/$runId", token)
            if (!r.ok) return ApiResult.Err("Tra cứu trạng thái lỗi HTTP ${r.code}: ${r.text}", r.code)
            val run = JSONObject(r.text)
            ApiResult.Ok(RunInfo(run.getLong("id"), run.getString("status"), run.optString("conclusion", null)))
        } catch (e: Exception) {
            ApiResult.Err("Tra cứu trạng thái lỗi mạng: ${e.message}")
        }
    }
}
