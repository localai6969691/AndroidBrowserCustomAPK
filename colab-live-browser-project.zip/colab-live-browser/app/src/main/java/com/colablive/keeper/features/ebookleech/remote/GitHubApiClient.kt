package com.colablive.keeper.features.ebookleech.remote

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * GitHubApiClient — gọi thẳng REST API GitHub bằng `HttpURLConnection`
 * (framework Android, không cần OkHttp/Retrofit — `:core` có OkHttp cho
 * riêng nó nhưng KHÔNG expose ra ngoài, xem ghi chú trong `SecureTokenStore.kt`
 * về lý do addon này tránh mọi dependency ngoài framework khi có thể).
 *
 * CHỈ dùng 3 nhóm endpoint cần cho "cào từ xa":
 * 1. Contents API — ghi/đọc file JSON job-spec + checkpoint trực tiếp
 *    trong repo (thay vì workflow_dispatch inputs — input có giới hạn
 *    kích thước, job phức tạp (nhiều regex rule, kịch bản nhiều bước) có
 *    thể vượt qua giới hạn đó).
 * 2. Actions API — kích hoạt workflow (`workflow_dispatch`) + tra cứu
 *    trạng thái lần chạy.
 *
 * TẤT CẢ hàm ở đây BLOCKING (I/O đồng bộ) — PHẢI gọi từ background thread,
 * KHÔNG BAO GIỜ gọi trực tiếp từ main thread (sẽ crash
 * NetworkOnMainThreadException).
 */
object GitHubApiClient {

    sealed class ApiResult<out T> {
        data class Ok<T>(val value: T) : ApiResult<T>()
        data class Err(val message: String, val httpCode: Int = -1) : ApiResult<Nothing>()
    }

    private fun connect(url: String, token: String, method: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        return conn
    }

    private fun readBody(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        return stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""
    }

    /**
     * Ghi (tạo mới hoặc cập nhật) 1 file trong repo qua Contents API. Tự
     * đọc `sha` hiện có nếu file đã tồn tại (Contents API BẮT BUỘC phải
     * có đúng `sha` cũ mới cho phép ghi đè — tránh mất dữ liệu do ghi đè
     * nhầm bản cũ hơn).
     */
    fun putFile(owner: String, repo: String, branch: String, token: String, path: String, content: String, message: String): ApiResult<Unit> {
        val existingSha = getFileSha(owner, repo, branch, token, path)
        val url = "https://api.github.com/repos/$owner/$repo/contents/$path"
        return try {
            val conn = connect(url, token, "PUT")
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().apply {
                put("message", message)
                put("content", Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                put("branch", branch)
                if (existingSha != null) put("sha", existingSha)
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            if (code in 200..299) ApiResult.Ok(Unit)
            else ApiResult.Err("PUT $path lỗi HTTP $code: ${readBody(conn)}", code)
        } catch (e: Exception) {
            ApiResult.Err("PUT $path lỗi mạng: ${e.message}")
        }
    }

    /** Ghi bytes THẬT (nhị phân, vd ảnh) — biến thể của `putFile()` cho nội
     * dung không phải text UTF-8. */
    fun putFileBytes(owner: String, repo: String, branch: String, token: String, path: String, bytes: ByteArray, message: String): ApiResult<Unit> {
        val existingSha = getFileSha(owner, repo, branch, token, path)
        val url = "https://api.github.com/repos/$owner/$repo/contents/$path"
        return try {
            val conn = connect(url, token, "PUT")
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().apply {
                put("message", message)
                put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
                put("branch", branch)
                if (existingSha != null) put("sha", existingSha)
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            if (code in 200..299) ApiResult.Ok(Unit)
            else ApiResult.Err("PUT $path (bytes) lỗi HTTP $code: ${readBody(conn)}", code)
        } catch (e: Exception) {
            ApiResult.Err("PUT $path (bytes) lỗi mạng: ${e.message}")
        }
    }

    /** @return `sha` của file nếu đã tồn tại, `null` nếu chưa có (file mới). */
    private fun getFileSha(owner: String, repo: String, branch: String, token: String, path: String): String? {
        return try {
            val conn = connect("https://api.github.com/repos/$owner/$repo/contents/$path?ref=$branch", token, "GET")
            if (conn.responseCode != 200) return null
            JSONObject(readBody(conn)).optString("sha", null)
        } catch (e: Exception) {
            null
        }
    }

    /** Đọc nội dung 1 file text từ repo (UTF-8) — dùng để đọc checkpoint
     * Python script commit lên giữa chừng job đang chạy. */
    fun getFileContent(owner: String, repo: String, branch: String, token: String, path: String): ApiResult<String> {
        return try {
            val conn = connect("https://api.github.com/repos/$owner/$repo/contents/$path?ref=$branch", token, "GET")
            val code = conn.responseCode
            if (code == 404) return ApiResult.Err("Chưa có file (404) — job có thể chưa bắt đầu chạy trên Actions", 404)
            if (code !in 200..299) return ApiResult.Err("GET $path lỗi HTTP $code: ${readBody(conn)}", code)
            val json = JSONObject(readBody(conn))
            val b64 = json.getString("content").replace("\n", "")
            ApiResult.Ok(String(Base64.decode(b64, Base64.DEFAULT), Charsets.UTF_8))
        } catch (e: Exception) {
            ApiResult.Err("GET $path lỗi mạng: ${e.message}")
        }
    }

    /** Kích hoạt workflow qua `workflow_dispatch`. `workflowFile` = tên
     * file (vd "ebookleech-remote-crawl.yml"), KHÔNG phải đường dẫn đầy đủ. */
    fun dispatchWorkflow(owner: String, repo: String, branch: String, token: String, workflowFile: String, inputs: Map<String, String>): ApiResult<Unit> {
        return try {
            val url = "https://api.github.com/repos/$owner/$repo/actions/workflows/$workflowFile/dispatches"
            val conn = connect(url, token, "POST")
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().apply {
                put("ref", branch)
                put("inputs", JSONObject(inputs as Map<*, *>))
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            if (code in 200..299) ApiResult.Ok(Unit)
            else ApiResult.Err("Kích hoạt workflow lỗi HTTP $code: ${readBody(conn)} — kiểm tra token có quyền 'workflow' và đúng tên file workflow chưa", code)
        } catch (e: Exception) {
            ApiResult.Err("Kích hoạt workflow lỗi mạng: ${e.message}")
        }
    }

    /** Đọc bytes THẬT (không ép UTF-8 text) — dùng cho file nhị phân (ảnh). */
    fun getFileBytes(owner: String, repo: String, branch: String, token: String, path: String): ApiResult<ByteArray> {
        return try {
            val conn = connect("https://api.github.com/repos/$owner/$repo/contents/$path?ref=$branch", token, "GET")
            val code = conn.responseCode
            if (code == 404) return ApiResult.Err("Chưa có file (404)", 404)
            if (code !in 200..299) return ApiResult.Err("GET $path lỗi HTTP $code: ${readBody(conn)}", code)
            val json = JSONObject(readBody(conn))
            val b64 = json.getString("content").replace("\n", "")
            ApiResult.Ok(Base64.decode(b64, Base64.DEFAULT))
        } catch (e: Exception) {
            ApiResult.Err("GET $path (bytes) lỗi mạng: ${e.message}")
        }
    }

    /** Liệt kê tên file trong 1 thư mục của repo (Contents API trả mảng
     * khi `path` trỏ tới thư mục thay vì 1 file) — dùng để biết ảnh nào
     * MỚI được Python commit thêm kể từ lần đồng bộ trước. */
    fun listDirectory(owner: String, repo: String, branch: String, token: String, path: String): ApiResult<List<String>> {
        return try {
            val conn = connect("https://api.github.com/repos/$owner/$repo/contents/$path?ref=$branch", token, "GET")
            val code = conn.responseCode
            if (code == 404) return ApiResult.Ok(emptyList())  // thư mục chưa tồn tại — bình thường (chưa có ảnh nào commit)
            if (code !in 200..299) return ApiResult.Err("Liệt kê $path lỗi HTTP $code: ${readBody(conn)}", code)
            val arr = JSONArray(readBody(conn))
            val names = (0 until arr.length()).mapNotNull { i ->
                val entry = arr.getJSONObject(i)
                if (entry.optString("type") == "file") entry.optString("name") else null
            }
            ApiResult.Ok(names)
        } catch (e: Exception) {
            ApiResult.Err("Liệt kê $path lỗi mạng: ${e.message}")
        }
    }

    data class RunInfo(val id: Long, val status: String, val conclusion: String?)

    /**
     * Tìm lần chạy MỚI NHẤT của workflow (sắp theo thời gian tạo giảm dần
     * — GitHub trả sẵn theo thứ tự này). Gọi NGAY SAU `dispatchWorkflow()`
     * vài giây — `workflow_dispatch` không trả về run id trực tiếp (API
     * GitHub thiết kế vậy, không phải giới hạn của client này), phải tra
     * cứu lại theo cách này.
     */
    fun findLatestRun(owner: String, repo: String, token: String, workflowFile: String): ApiResult<RunInfo> {
        return try {
            val url = "https://api.github.com/repos/$owner/$repo/actions/workflows/$workflowFile/runs?per_page=1"
            val conn = connect(url, token, "GET")
            val code = conn.responseCode
            if (code !in 200..299) return ApiResult.Err("Tra cứu lần chạy lỗi HTTP $code: ${readBody(conn)}", code)
            val arr: JSONArray = JSONObject(readBody(conn)).getJSONArray("workflow_runs")
            if (arr.length() == 0) return ApiResult.Err("Chưa có lần chạy nào — workflow có thể chưa được kích hoạt đúng")
            val run = arr.getJSONObject(0)
            ApiResult.Ok(RunInfo(run.getLong("id"), run.getString("status"), run.optString("conclusion", null)))
        } catch (e: Exception) {
            ApiResult.Err("Tra cứu lần chạy lỗi mạng: ${e.message}")
        }
    }

    fun getRunStatus(owner: String, repo: String, token: String, runId: Long): ApiResult<RunInfo> {
        return try {
            val conn = connect("https://api.github.com/repos/$owner/$repo/actions/runs/$runId", token, "GET")
            val code = conn.responseCode
            if (code !in 200..299) return ApiResult.Err("Tra cứu trạng thái lỗi HTTP $code: ${readBody(conn)}", code)
            val run = JSONObject(readBody(conn))
            ApiResult.Ok(RunInfo(run.getLong("id"), run.getString("status"), run.optString("conclusion", null)))
        } catch (e: Exception) {
            ApiResult.Err("Tra cứu trạng thái lỗi mạng: ${e.message}")
        }
    }
}
