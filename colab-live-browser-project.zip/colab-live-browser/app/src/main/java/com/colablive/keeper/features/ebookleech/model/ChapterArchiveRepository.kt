package com.colablive.keeper.features.ebookleech.model

import android.content.Context
import org.json.JSONArray
import java.io.File

/**
 * ChapterArchiveRepository — KHO CHƯƠNG ĐÃ CÀO theo từng job, sống SAU khi job xong (bản 7.100, học từ cách KDN Auto Leech nhớ URL đã cào
 * để chỉ lấy bài mới, xem PROJECT_STATUS mục 224).
 *
 * KHÁC CrawlCheckpoint: checkpoint chỉ giữ trạng thái giữa chừng của MỘT lần chạy rồi bị xoá khi xong (`finishAllEntries`). Kho này giữ bản chương
 * cuối cùng của lần chạy gần nhất để lần chạy kế tiếp (thủ công hoặc theo lịch) so link chương hiện tại với kho và chỉ mở những chương CHƯA có.
 *
 * Bố cục: <filesDir>/ebookleech_archive/<slot>_<jobId>.json (danh sách chương, không chứa bytes ảnh)
 *         <filesDir>/ebookleech_archive/<slot>_<jobId>_images/<localFileName> (bytes ảnh, cùng cơ chế CrawlCheckpointRepository)
 *
 * GIỚI HẠN trung thực: kho KHÔNG nằm trong Sao lưu/Khôi phục (sẽ rất nặng); chuyển máy => lần chạy đầu cào lại toàn bộ. Khoá theo URL chương đúng như site
 * trả: nếu site đổi dạng URL (vd thêm/bỏ "www", đổi domain) thì mọi chương coi là mới. Chương lỗi/bị chặn KHÔNG được lưu (xem [isReusable]).
 */
object ChapterArchiveRepository {

    private fun dir(context: Context): File =
        File(context.filesDir, "ebookleech_archive").apply { if (!exists()) mkdirs() }

    private fun file(context: Context, slotIndex: Int, jobId: String): File =
        File(dir(context), "${slotIndex}_${jobId}.json")

    private fun imagesDir(context: Context, slotIndex: Int, jobId: String): File =
        File(dir(context), "${slotIndex}_${jobId}_images").apply { if (!exists()) mkdirs() }

    /** Chương giữ chỗ do chính crawler sinh ra khi lỗi/bị chặn — dùng lại sẽ "đóng băng" lỗi vào ebook mãi mãi nên KHÔNG lưu. */
    fun isReusable(ch: LeechChapter): Boolean =
        !ch.title.contains("[lỗi]") && !ch.title.contains("[BỊ CHẶN") &&
            !ch.textContent.startsWith("[Không lấy được nội dung") && !ch.textContent.startsWith("[Bị chặn")

    /** Ghi kho = đúng tập chương của lần chạy này (chương site đã bỏ bị loại khỏi kho). Ghi ra file tạm rồi đổi tên để không để lại file dở. */
    fun save(context: Context, slotIndex: Int, jobId: String, chapters: List<LeechChapter>) {
        try {
            val keep = chapters.filter { isReusable(it) && it.sourceUrl.isNotBlank() }
            val imgDir = imagesDir(context, slotIndex, jobId)
            val referenced = HashSet<String>()
            keep.forEach { ch ->
                ch.images.forEach { img ->
                    referenced.add(img.localFileName)
                    val f = File(imgDir, img.localFileName)
                    if (!f.exists()) {
                        try { f.writeBytes(img.bytes) } catch (e: Exception) { /* một ảnh lỗi không chặn việc lưu kho */ }
                    }
                }
            }
            imgDir.listFiles()?.forEach { if (it.isFile && it.name !in referenced) it.delete() }
            val tmp = File(dir(context), "${slotIndex}_${jobId}.json.tmp")
            tmp.writeText(LeechChapter.listToJson(keep).toString(), Charsets.UTF_8)
            val dest = file(context, slotIndex, jobId)
            if (!tmp.renameTo(dest)) { dest.writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8); tmp.delete() }
        } catch (e: Exception) {
            // Lỗi ghi kho không được làm hỏng lần cào vừa xong; lần sau chỉ cào lại nhiều hơn.
        }
    }

    /** Bản 7.104: mảng JSON chương của kho (dạng `LeechChapter.toJson`, ảnh chỉ có tên file) — để gieo kho lên máy chạy từ xa mà KHÔNG nạp bytes ảnh vào RAM. null = không có/hỏng. */
    fun readRawArchive(context: Context, slotIndex: Int, jobId: String): JSONArray? {
        val f = file(context, slotIndex, jobId)
        if (!f.exists()) return null
        return try { JSONArray(f.readText(Charsets.UTF_8)) } catch (e: Exception) { null }
    }

    /** Bản 7.104: file ảnh của kho theo tên (có thể không tồn tại). */
    fun imageFile(context: Context, slotIndex: Int, jobId: String, localFileName: String): File = File(imagesDir(context, slotIndex, jobId), localFileName)

    /** URL chương -> chương đã lưu (kèm bytes ảnh). Kho hỏng/không đọc được => map rỗng (cào lại như lần đầu). */
    fun load(context: Context, slotIndex: Int, jobId: String): Map<String, LeechChapter> {
        val f = file(context, slotIndex, jobId)
        if (!f.exists()) return emptyMap()
        return try {
            val imgDir = imagesDir(context, slotIndex, jobId)
            val arr = JSONArray(f.readText(Charsets.UTF_8))
            val out = LinkedHashMap<String, LeechChapter>()
            LeechChapter.listFromJson(arr) { name ->
                val imgFile = File(imgDir, name)
                if (imgFile.exists()) try { imgFile.readBytes() } catch (e: Exception) { null } else null
            }.forEach { if (it.sourceUrl.isNotBlank()) out[it.sourceUrl] = it }
            out
        } catch (e: Exception) {
            emptyMap()
        }
    }

    /**
     * Bản 7.104 — "điểm neo" quét danh sách của lần chạy gần nhất: [order] = THỨ TỰ ĐẦY ĐỦ danh sách chương lần đó (kể cả chương bị bỏ qua/lỗi, nên lần sau vẫn thử lại), [lastPage] = trang cuối
     * có chương mới, [fastStreak] = số lần quét nhanh liên tiếp tính tới lần đó. Dùng cho [com.colablive.keeper.features.ebookleech.engine.ListScanPlanner]. Gắn với KHO (xoá kho thì xoá luôn).
     */
    class ListMeta(val order: List<String>, val lastPage: Int, val fastStreak: Int)

    private fun listFile(context: Context, slotIndex: Int, jobId: String): File =
        File(dir(context), "${slotIndex}_${jobId}.list.json")

    fun saveListMeta(context: Context, slotIndex: Int, jobId: String, meta: ListMeta) {
        try {
            val o = org.json.JSONObject()
            o.put("order", JSONArray(meta.order)); o.put("lastPage", meta.lastPage); o.put("fastStreak", meta.fastStreak)
            val f = listFile(context, slotIndex, jobId)
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(o.toString(), Charsets.UTF_8)
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        } catch (e: Exception) { /* không lưu được => lần sau quét đầy đủ, an toàn */ }
    }

    fun loadListMeta(context: Context, slotIndex: Int, jobId: String): ListMeta? {
        val f = listFile(context, slotIndex, jobId)
        if (!f.exists()) return null
        return try {
            val o = org.json.JSONObject(f.readText(Charsets.UTF_8))
            val arr = o.getJSONArray("order")
            ListMeta((0 until arr.length()).map { arr.getString(it) }.filter { it.isNotEmpty() }, o.optInt("lastPage", 0), o.optInt("fastStreak", 0))
        } catch (e: Exception) { null }
    }

    private fun sigFile(context: Context, slotIndex: Int, jobId: String): File =
        File(dir(context), "${slotIndex}_${jobId}.sig")

    /** Bản 7.101: "chữ ký" cấu hình xuất (định dạng, tên file...) của LẦN XUẤT GẦN NHẤT. Dùng để biết có được bỏ qua việc xuất lại khi không có chương mới (đổi định dạng => chữ ký khác => vẫn xuất). */
    fun saveExportSignature(context: Context, slotIndex: Int, jobId: String, signature: String) {
        try { sigFile(context, slotIndex, jobId).writeText(signature, Charsets.UTF_8) } catch (e: Exception) { /* không lưu được => lần sau xuất lại, an toàn */ }
    }

    fun loadExportSignature(context: Context, slotIndex: Int, jobId: String): String =
        try { sigFile(context, slotIndex, jobId).takeIf { it.exists() }?.readText(Charsets.UTF_8) ?: "" } catch (e: Exception) { "" }

    fun count(context: Context, slotIndex: Int, jobId: String): Int {
        val f = file(context, slotIndex, jobId)
        if (!f.exists()) return 0
        return try { JSONArray(f.readText(Charsets.UTF_8)).length() } catch (e: Exception) { 0 }
    }

    private fun baselineFile(context: Context, slotIndex: Int, jobId: String): File =
        File(dir(context), "${slotIndex}_${jobId}.baseline")

    /**
     * Bản 7.102 — "mốc" của lần xuất gần nhất: mỗi dòng `<URL chương>\t<băm tiêu đề+nội dung>`. Dùng để (1) đếm chương MỚI so với lần xuất trước (thông báo), (2) biết lần chạy này có khác
     * lần xuất trước không (cào từ xa không có kho chương trên điện thoại để so). Ghi cho MỌI job (kể cả không bật cập nhật tăng dần). null = chưa từng xuất (hoặc kho vừa bị xoá).
     */
    fun saveExportBaseline(context: Context, slotIndex: Int, jobId: String, lines: List<String>) {
        try {
            val f = baselineFile(context, slotIndex, jobId)
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(lines.joinToString("\n"), Charsets.UTF_8)
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        } catch (e: Exception) { /* không lưu được => lần sau coi như chưa có mốc: không báo chương mới, vẫn xuất bình thường */ }
    }

    fun loadExportBaseline(context: Context, slotIndex: Int, jobId: String): List<String>? =
        try { baselineFile(context, slotIndex, jobId).takeIf { it.exists() }?.readLines(Charsets.UTF_8)?.filter { it.isNotEmpty() } } catch (e: Exception) { null }

    /** Xoá TOÀN BỘ dữ liệu của job (gọi khi người dùng xoá job): kho chương, ảnh, chữ ký cấu hình xuất và mốc xuất. */
    fun delete(context: Context, slotIndex: Int, jobId: String) {
        deleteArchive(context, slotIndex, jobId)
        sigFile(context, slotIndex, jobId).delete()
        baselineFile(context, slotIndex, jobId).delete()
    }

    /**
     * Bản 7.103 — chỉ xoá KHO CHƯƠNG (nội dung + ảnh) để lần sau cào lại hết ("Xoá kho"). GIỮ mốc xuất (`.baseline`, chỉ vài chục KB: URL + băm) và chữ ký cấu hình xuất,
     * vì chúng mô tả file ebook ĐÃ xuất chứ không phải kho: nếu xoá cả mốc thì lần chạy sau bị coi là "xuất lần đầu" và không báo được chương mới (bản 7.102 mắc lỗi này).
     */
    fun deleteArchive(context: Context, slotIndex: Int, jobId: String) {
        file(context, slotIndex, jobId).delete()
        listFile(context, slotIndex, jobId).delete()   // bản 7.104: điểm neo quét danh sách đi cùng kho — mất kho thì quét đầy đủ lại
        imagesDir(context, slotIndex, jobId).deleteRecursively()
    }
}
