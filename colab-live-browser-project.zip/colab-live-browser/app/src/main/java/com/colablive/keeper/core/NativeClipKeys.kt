package com.colablive.keeper.core

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.View

/**
 * Sao chép / Cắt / Chọn tất cả / đo độ phản hồi — bằng phím Ctrl+C / X / A thật gửi vào GeckoView (mục 100).
 *
 * Copy/Cut tự kiểm chứng bằng clipboard: đặt một chuỗi canh (sentinel) vào clipboard,
 * gửi phím, sau 450ms nếu clipboard KHÁC sentinel nghĩa là trang (Monaco) đã ghi nội dung thật.
 * Nếu vẫn là sentinel thì khôi phục clipboard cũ và báo false để bên gọi dùng đường dự phòng.
 */
object NativeClipKeys {
    private val handler = Handler(Looper.getMainLooper())
    private const val SENTINEL = "\u0001colablive-sentinel\u0001"

    fun sendCtrl(host: View, keyCode: Int) {
        val t = SystemClock.uptimeMillis()
        val meta = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        fun ev(action: Int, code: Int, m: Int) =
            KeyEvent(t, SystemClock.uptimeMillis(), action, code, 0, m, -1, 0, 0, InputDevice.SOURCE_KEYBOARD)
        host.requestFocus()
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_CTRL_LEFT, meta))
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_DOWN, keyCode, meta))
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_UP, keyCode, meta))
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_CTRL_LEFT, 0))
    }

    /** @param cut true = Ctrl+X. onResult(true) = clipboard đã có nội dung thật từ trang. */
    fun copyOrCut(
        context: Context, host: View, cut: Boolean,
        evalJs: (String, (String?) -> Unit) -> Unit,
        onResult: (Boolean) -> Unit
    ) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val old: ClipData? = try { cm.primaryClip } catch (e: Exception) { null }
        evalJs("(function(){ try { return window.__lbMon ? __lbMon.refocus() : 'noapi'; } catch(e){ return 'ERR '+e.message; } })()") { r ->
            DebugLog.log("NativeClipKeys: refocus → $r")
            try { cm.setPrimaryClip(ClipData.newPlainText("colablive", SENTINEL)) } catch (e: Exception) {}
            sendCtrl(host, if (cut) KeyEvent.KEYCODE_X else KeyEvent.KEYCODE_C)
            handler.postDelayed({
                val now = try { cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString() } catch (e: Exception) { null }
                val ok = now != null && now != SENTINEL
                DebugLog.log("NativeClipKeys: ${if (cut) "Ctrl+X" else "Ctrl+C"} → clipboard ${if (ok) "ĐÃ có nội dung thật (${now?.length} ký tự)" else "vẫn là sentinel → dùng đường dự phòng"}")
                if (!ok && old != null) { try { cm.setPrimaryClip(old) } catch (e: Exception) {} }
                onResult(ok)
            }, 450)
        }
    }

    private const val RECTS_JS = "(function(){ try { return window.__lbMon ? __lbMon.rects() : '{\"n\":0}'; } catch(e){ return '{\"n\":0}'; } })()"

    private fun hasSel(raw: String?): Boolean =
        MonacoSelectionUi.unwrapBridge(raw)?.let { !it.contains("\"n\":0") } ?: false

    /**
     * Xoá vùng chọn Monaco bằng KeyboardEvent giả bắn thẳng vào ô nhập (mục 103). Log thật: phím Backspace gửi bằng KeyEvent Android
     * ("Backspace không tới Monaco") và Ctrl+X native đều KHÔNG làm Monaco xoá. Báo kết quả qua onDone(true = đã xoá).
     */
    fun deleteSelection(evalJs: (String, (String?) -> Unit) -> Unit, onDone: (Boolean) -> Unit) {
        evalJs("(function(){ try { return window.__lbMon ? __lbMon.deleteSelection() : 'noapi'; } catch(e){ return 'ERR '+e.message; } })()") { r ->
            DebugLog.log("NativeClipKeys: deleteSelection bắt đầu → $r")
            handler.postDelayed({
                evalJs("(function(){ return String(window.__lbDelResult); })()") { res ->
                    evalJs(RECTS_JS) { rr ->
                        val still = hasSel(rr)
                        DebugLog.log("NativeClipKeys: deleteSelection kết quả → ${MonacoSelectionUi.unwrapBridge(res)}; vùng chọn ${if (still) "VẪN CÒN" else "đã hết"}")
                        onDone(!still)
                    }
                }
            }, 700)
        }
    }

    /** Sau Ctrl+X: nếu vùng chọn Monaco vẫn còn thì xoá bằng phím giả vào ô nhập. */
    fun ensureDeleted(host: View, evalJs: (String, (String?) -> Unit) -> Unit, onDone: (Boolean) -> Unit = {}) {
        evalJs(RECTS_JS) { r ->
            val still = hasSel(r)
            DebugLog.log("NativeClipKeys: sau Ctrl+X vùng chọn ${if (still) "VẪN CÒN → xoá bằng phím giả vào ô nhập" else "đã biến mất (Monaco tự xoá)"}")
            if (!still) { onDone(true); return@evalJs }
            deleteSelection(evalJs, onDone)
        }
    }

    /** Ô code dài hơn ngưỡng này (ước lượng) thì Chọn hết cần bấm lần 2 để xác nhận (mục 105). */
    private const val SELECT_ALL_LINE_LIMIT = 1500
    private var selectAllWarnedAt = 0L

    /**
     * Chọn hết: Ctrl+A giả (không keyup) vào ô nhập. Log 7.7: sau Chọn hết trang Colab đơ >30s (mọi evalJs hết 15s, Gecko báo slow script
     * ở editor.main.js) và code cũ coi "không phản hồi" là "không đổi" rồi gửi THÊM Ctrl+A native. Sửa: (1) ước lượng số dòng và cảnh báo
     * trước với ô rất dài (bấm lần 2 trong 6s để xác nhận); (2) không bắn keyup; (3) nếu trang không phản hồi thì DỪNG, không gửi thêm gì.
     * Nguyên nhân cụ thể làm Monaco/Colab đơ khi chọn cả ô lớn CHƯA xác định — log `ước lượng ô code` sẽ cho biết ngưỡng thật.
     */
    fun selectAll(host: View, evalJs: (String, (String?) -> Unit) -> Unit, done: () -> Unit) {
        evalJs("(function(){ try { return window.__lbMon ? __lbMon.refocus() : 'noapi'; } catch(e){ return 'ERR '+e.message; } })()") {
            evalJs("(function(){ try { return __lbMon.docInfo(); } catch(e){ return '{\"lines\":-1}'; } })()") { info ->
                val lines = Regex("\"lines\":(-?\\d+)").find(info ?: "")?.groupValues?.get(1)?.toIntOrNull() ?: -1
                DebugLog.log("NativeClipKeys: ước lượng ô code ≈ $lines dòng (${MonacoSelectionUi.unwrapBridge(info)})")
                val now = SystemClock.uptimeMillis()
                if (lines > SELECT_ALL_LINE_LIMIT && now - selectAllWarnedAt > 6000L) {
                    selectAllWarnedAt = now
                    DebugLog.log("NativeClipKeys: Chọn hết bị chặn lần 1 vì ô ≈ $lines dòng > $SELECT_ALL_LINE_LIMIT — chờ bấm lần 2 để xác nhận")
                    host.post {
                        android.widget.Toast.makeText(host.context,
                            "Ô code rất dài (~$lines dòng), Chọn hết có thể làm Colab đơ. Bấm Chọn hết lần nữa để vẫn thực hiện.",
                            android.widget.Toast.LENGTH_LONG).show()
                    }
                    done()
                    return@evalJs
                }
                selectAllWarnedAt = 0L
                evalJs("(function(){ try { return __lbMon.rects(); } catch(e){ return '{}'; } })()") { before ->
                    evalJs("(function(){ try { return __lbMon.selectAll(); } catch(e){ return 'ERR '+e.message; } })()") { r ->
                        DebugLog.log("NativeClipKeys: Chọn hết (phím giả) → $r")
                        handler.postDelayed({
                            evalJs("(function(){ try { return __lbMon.rects(); } catch(e){ return '{}'; } })()") { after ->
                                if (after == null) {
                                    DebugLog.log("NativeClipKeys: Chọn hết → trang KHÔNG phản hồi (đang xử lý vùng chọn lớn) — dừng, không gửi thêm phím")
                                    done(); return@evalJs
                                }
                                val changed = after != before && hasSel(after)
                                DebugLog.log("NativeClipKeys: Chọn hết (phím giả) → vùng chọn ${if (changed) "ĐÃ ĐỔI (thành công)" else "KHÔNG đổi → thử Ctrl+A native"}")
                                if (changed) { done(); return@evalJs }
                                sendCtrl(host, KeyEvent.KEYCODE_A)
                                handler.postDelayed({
                                    evalJs("(function(){ try { return __lbMon.rects(); } catch(e){ return '{}'; } })()") { after2 ->
                                        DebugLog.log("NativeClipKeys: Chọn hết (Ctrl+A native) → ${if (after2 == null) "trang không phản hồi" else if (after2 != after && hasSel(after2)) "ĐÃ ĐỔI" else "KHÔNG đổi"}")
                                        done()
                                    }
                                }, 300)
                            }
                        }, 300)
                    }
                }
            }
        }
    }

    /**
     * Đo độ phản hồi của trang sau thao tác dán lớn để lần sau có SỐ LIỆU thay vì đoán
     * (mục 8654: "Colab đơ sau khi dán" chưa từng có bằng chứng). Ghi độ trễ khứ hồi JS ở 0.5s/2s/5s/10s.
     */
    fun probeResponsiveness(label: String, evalJs: (String, (String?) -> Unit) -> Unit) {
        for (delay in longArrayOf(500, 2000, 5000, 10000)) {
            handler.postDelayed({
                val t0 = SystemClock.uptimeMillis()
                var answered = false
                evalJs("(function(){ return 'pong'; })()") {
                    answered = true
                    DebugLog.log("Probe[$label] +${delay}ms: trang trả lời sau ${SystemClock.uptimeMillis() - t0}ms")
                }
                handler.postDelayed({
                    if (!answered) DebugLog.log("Probe[$label] +${delay}ms: trang KHÔNG trả lời sau 12s — luồng JS của trang đang bị chặn")
                }, 12000)
            }, delay)
        }
    }
}
