package com.colablive.keeper.core

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.View

/**
 * Sao chép / Cắt / Chọn tất cả / đo độ phản hồi — bằng phím Ctrl+C / X / A thật gửi vào GeckoView (mục 100).
 *
 * Copy/Cut tự kiểm chứng bằng clipboard: đặt một chuỗi canh (sentinel) vào clipboard,
 * gửi phím, sau 450ms nếu clipboard KHÁC sentinel nghĩa là trang (Monaco) đã ghi nội dung thật.
 * Nếu vẫn là sentinel thì khôi phục clipboard cũ và báo false để bên gọi dùng đường dự phòng.
 */
object NativeClipKeys {
    private val handler = Handler(Looper.getMainLooper())
    private const val SENTINEL = "\u0001colablive-sentinel\u0001"

    fun sendCtrl(host: View, keyCode: Int) {
        val t = SystemClock.uptimeMillis()
        val meta = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        fun ev(action: Int, code: Int, m: Int) =
            KeyEvent(t, SystemClock.uptimeMillis(), action, code, 0, m, -1, 0, 0, InputDevice.SOURCE_KEYBOARD)
        host.requestFocus()
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_CTRL_LEFT, meta))
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_DOWN, keyCode, meta))
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_UP, keyCode, meta))
        host.dispatchKeyEvent(ev(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_CTRL_LEFT, 0))
    }

    /** @param cut true = Ctrl+X. onResult(true) = clipboard đã có nội dung thật từ trang. */
    fun copyOrCut(
        context: Context, host: View, cut: Boolean,
        evalJs: (String, (String?) -> Unit) -> Unit,
        onResult: (Boolean) -> Unit
    ) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val old: ClipData? = try { cm.primaryClip } catch (e: Exception) { null }
        evalJs("(function(){ try { return window.__lbMon ? __lbMon.refocus() : 'noapi'; } catch(e){ return 'ERR '+e.message; } })()") { r ->
            DebugLog.log("NativeClipKeys: refocus → $r")
            try { cm.setPrimaryClip(ClipData.newPlainText("colablive", SENTINEL)) } catch (e: Exception) {}
            sendCtrl(host, if (cut) KeyEvent.KEYCODE_X else KeyEvent.KEYCODE_C)
            handler.postDelayed({
                val now = try { cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString() } catch (e: Exception) { null }
                val ok = now != null && now != SENTINEL
                DebugLog.log("NativeClipKeys: ${if (cut) "Ctrl+X" else "Ctrl+C"} → clipboard ${if (ok) "ĐÃ có nội dung thật (${now?.length} ký tự)" else "vẫn là sentinel → dùng đường dự phòng"}")
                if (!ok && old != null) { try { cm.setPrimaryClip(old) } catch (e: Exception) {} }
                onResult(ok)
            }, 450)
        }
    }

    fun selectAll(host: View, evalJs: (String, (String?) -> Unit) -> Unit, done: () -> Unit) {
        evalJs("(function(){ try { return window.__lbMon ? __lbMon.refocus() : 'noapi'; } catch(e){ return 'ERR '+e.message; } })()") {
            sendCtrl(host, KeyEvent.KEYCODE_A)
            handler.postDelayed({ done() }, 250)
        }
    }

    /**
     * Đo độ phản hồi của trang sau thao tác dán lớn để lần sau có SỐ LIỆU thay vì đoán
     * (mục 8654: "Colab đơ sau khi dán" chưa từng có bằng chứng). Ghi độ trễ khứ hồi JS ở 0.5s/2s/5s/10s.
     */
    fun probeResponsiveness(label: String, evalJs: (String, (String?) -> Unit) -> Unit) {
        for (delay in longArrayOf(500, 2000, 5000, 10000)) {
            handler.postDelayed({
                val t0 = SystemClock.uptimeMillis()
                var answered = false
                evalJs("(function(){ return 'pong'; })()") {
                    answered = true
                    DebugLog.log("Probe[$label] +${delay}ms: trang trả lời sau ${SystemClock.uptimeMillis() - t0}ms")
                }
                handler.postDelayed({
                    if (!answered) DebugLog.log("Probe[$label] +${delay}ms: trang KHÔNG trả lời sau 12s — luồng JS của trang đang bị chặn")
                }, 12000)
            }, delay)
        }
    }
}
