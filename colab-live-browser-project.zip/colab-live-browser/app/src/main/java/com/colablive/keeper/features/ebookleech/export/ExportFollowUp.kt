package com.colablive.keeper.features.ebookleech.export

import android.content.Context
import com.colablive.keeper.features.ebookleech.model.ChapterArchiveRepository
import com.colablive.keeper.features.ebookleech.model.LeechChapter
import com.colablive.keeper.features.ebookleech.model.LeechJob
import java.util.zip.CRC32

/**
 * Bản 7.102 (mục 226) — việc làm CHUNG sau/trước mỗi lần xuất ebook, dùng cho cả đường cào tại máy, cào từ xa và xuất sau khi xem trước mục lục:
 *  - so danh sách chương lần này với "mốc" của lần xuất trước (`ChapterArchiveRepository.saveExportBaseline`) để biết có bao nhiêu chương MỚI (thông báo) và có gì đổi không;
 *  - chữ ký cấu hình xuất + kiểm tra "file ebook cũ còn không" để quyết định có bỏ qua việc xuất lại khi không có gì mới.
 *
 * Không đụng Android UI/Notification: việc báo cho người dùng do EbookLeechScheduler (qua callback) làm, để lớp cào và lớp xuất không phụ thuộc vào service.
 */
object ExportFollowUp {

    /** @param hadBaseline false = chưa từng xuất (hoặc mốc bị xoá) => KHÔNG coi cả cuốn là "chương mới". */
    data class Delta(val hadBaseline: Boolean, val newCount: Int, val total: Int, val unchanged: Boolean)

    /** Một dòng mốc: URL + băm (tiêu đề + HTML) — đổi nội dung một chương làm dòng đổi, nhưng chương đó KHÔNG tính là "mới" (đếm theo URL). */
    internal fun lineOf(ch: LeechChapter): String {
        val crc = CRC32()
        crc.update((ch.title + "\u0000" + ch.htmlContent).toByteArray(Charsets.UTF_8))
        return "${ch.sourceUrl.replace('\t', ' ').replace('\n', ' ')}\t${java.lang.Long.toHexString(crc.value)}"
    }

    /** Chữ ký cấu hình xuất: đổi định dạng/tên file/số mục lục thủ công/chế độ ghi đè => khác chữ ký => vẫn phải xuất lại dù không có chương mới. */
    fun signatureOf(job: LeechJob): String = "${job.outputFormat.name}|${job.outputFileName}|${job.tocOverride.size}|${job.updateExistingFile}"

    fun compare(context: Context, slotIndex: Int, jobId: String, chapters: List<LeechChapter>): Delta {
        val baseline = ChapterArchiveRepository.loadExportBaseline(context, slotIndex, jobId)
            ?: return Delta(hadBaseline = false, newCount = 0, total = chapters.size, unchanged = false)
        val oldUrls = baseline.map { it.substringBefore('\t') }.toHashSet()
        val newCount = chapters.count { it.sourceUrl.replace('\t', ' ').replace('\n', ' ') !in oldUrls }
        // Bản 7.103: mốc cũ mà KHÔNG chương nào của lần này trùng URL (đổi link nguồn/đổi cấu trúc trang) => coi như xuất lần đầu, đừng báo "+N chương mới" cho cả cuốn.
        if (baseline.isNotEmpty() && chapters.isNotEmpty() && newCount == chapters.size) {
            return Delta(hadBaseline = false, newCount = 0, total = chapters.size, unchanged = false)
        }
        val unchanged = baseline == chapters.map { lineOf(it) }
        return Delta(hadBaseline = true, newCount = newCount, total = chapters.size, unchanged = unchanged)
    }

    /** Gọi SAU KHI xuất thành công: ghi mốc mới + (nếu job bật cập nhật tăng dần) chữ ký cấu hình xuất. */
    fun afterExport(context: Context, slotIndex: Int, job: LeechJob, chapters: List<LeechChapter>) {
        ChapterArchiveRepository.saveExportBaseline(context, slotIndex, job.id, chapters.map { lineOf(it) })
        if (job.incrementalUpdate) ChapterArchiveRepository.saveExportSignature(context, slotIndex, job.id, signatureOf(job))
    }

    fun outputStillExists(context: Context, path: String): Boolean {
        if (path.isBlank()) return false
        if (path.startsWith("content://")) {
            return try { context.contentResolver.openInputStream(android.net.Uri.parse(path))?.use { true } ?: false } catch (e: Exception) { false }
        }
        return java.io.File(path).exists()
    }

    /**
     * Có thể bỏ qua việc xuất lại không: chỉ khi job bật cập nhật tăng dần (người dùng đã chọn "đừng tạo file thừa"), không chờ xem trước mục lục, file ebook lần trước còn,
     * cấu hình xuất không đổi và danh sách chương (URL + tiêu đề + nội dung) GIỐNG HỆT mốc lần xuất trước.
     * Bản 7.104: thêm điều kiện thông tin truyện (tác giả, tóm tắt, bìa...) KHÔNG đổi so với bản đã lưu — [storyChanged] true thì vẫn phải xuất lại.
     */
    fun canSkipExport(context: Context, slotIndex: Int, job: LeechJob, delta: Delta, storyChanged: Boolean = false): Boolean =
        job.incrementalUpdate && !job.manualTocReview && !storyChanged && delta.hadBaseline && delta.unchanged &&
            outputStillExists(context, job.outputFilePath) &&
            ChapterArchiveRepository.loadExportSignature(context, slotIndex, job.id) == signatureOf(job)

    /** Dòng ghi chú hiện trên thẻ job. */
    fun noteFor(delta: Delta, detail: String): String {
        val stamp = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.US).format(java.util.Date())
        val head = when {
            !delta.hadBaseline -> "xuất lần đầu ${delta.total} chương"
            delta.newCount > 0 -> "+${delta.newCount} chương mới (tổng ${delta.total})"
            else -> "tổng ${delta.total} chương, không có chương mới"
        }
        return "$stamp — $head" + if (detail.isNotBlank()) " ($detail)" else ""
    }
}
