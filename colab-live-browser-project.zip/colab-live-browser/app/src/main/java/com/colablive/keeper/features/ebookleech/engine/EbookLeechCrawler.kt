package com.colablive.keeper.features.ebookleech.engine

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.colablive.keeper.core.GeckoViewEngine
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpoint
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpointRepository
import com.colablive.keeper.features.ebookleech.model.LeechChapter
import com.colablive.keeper.features.ebookleech.model.LeechJob
import org.json.JSONObject

/**
 * EbookLeechCrawler — BẢN SỬA sau khi đọc source thật.
 *
 * THAY ĐỔI KIẾN TRÚC LỚN NHẤT: không còn "session ẩn" nào cả — mọi lệnh
 * cào chạy qua 1 TAB THẬT riêng (`crawlTabId`), tạo lúc `start()`, đóng lúc
 * kết thúc. Tab này CÓ THỂ hiện lên màn hình nếu người dùng đang thật sự
 * nhìn slot đó lúc crawl chạy (xem chú thích trong GeckoViewEngineExt.kt).
 * Tự động chuyển lại đúng tab người dùng đang xem trước khi crawl bắt đầu.
 *
 * TÍNH NĂNG AJAX SNIFF TẠM NGỪNG: không còn `collectAjaxEndpoints` — lý do
 * kỹ thuật thật (không phải chưa làm): content script của eval_bridge chạy
 * ở "document_idle" (xem manifest.json thật), nghĩa là fetch/XHR trang gọi
 * lúc tải ban đầu ĐÃ XẢY RA TRƯỚC khi ta kịp tiêm script theo dõi — và việc
 * patch `window.fetch` từ content script có patch được `fetch` mà PAGE
 * SCRIPT thật sự gọi hay không phụ thuộc cơ chế isolated-world của
 * GeckoView WebExtension (Xray wrapper) — CHƯA XÁC NHẬN, cần
 * `exportFunction`/`wrappedJSObject` đúng cách mới chắc ăn. Quyết định bỏ
 * thay vì ship 1 tính năng không chắc chạy — xem PROJECT_STATUS mục hướng
 * dẫn nếu muốn làm lại đúng.
 */
class EbookLeechCrawler(
    private val context: Context,
    private val slotIndex: Int,
    private val engine: GeckoViewEngine,
    private val job: LeechJob,
    private val onProgress: (crawled: Int, total: Int, message: String) -> Unit,
    private val onJobUpdate: (LeechJob) -> Unit,
    private val onDone: (outputPath: String) -> Unit,
    private val onReviewReady: (chapters: List<LeechChapter>) -> Unit = {},
    private val onNeedsManualAction: (url: String, reason: String) -> Unit = { _, _ -> },
    private val onError: (reason: String) -> Unit,
) {
    private val handler = Handler(Looper.getMainLooper())
    private val chapterLinks = mutableListOf<String>()
    private val chapters = mutableListOf<LeechChapter>()
    private var blockedChapterCount = 0
    private var publishedCount = 0
    private var publishErrorCount = 0
    private val ajaxEndpointsSeen = linkedSetOf<String>()

    private var listPageEntries = listOf<String>()
    private var listPageEntryIndex = 0
    private var resolvedPattern: String = job.resolvedPaginationPattern

    private var crawlTabId: String? = null
    private var previousActiveTabId: String? = null

    @Volatile private var cancelled = false

    private val paginationCandidates = listOf(
        "{base}?page={page}", "{base}/page/{page}", "{base}/trang-{page}", "{base}/page-{page}", "{base}/{page}",
    )

    // -------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------

    fun start() {
        previousActiveTabId = engine.getActiveTab()?.id

        // ĐÃ THÊM — xoay proxy dự phòng (nếu người dùng đã bấm "tìm nhiều
        // proxy" trước đó) — CHỈ lúc job MỚI khởi động, không gọi ở
        // resumeFromCheckpoint(). Xem giới hạn kiến trúc đầy đủ trong
        // ProxyPoolManager.kt — KHÔNG có tác dụng tức thời nếu khe đang
        // chạy liên tục, chỉ có hiệu lực từ lần khe khởi động lại kế tiếp.
        ProxyPoolManager.rotateToNext(context, slotIndex)

        // Dùng job.useLoginSession để quyết định isPrivate — xem chú thích
        // đầy đủ tại LeechJob.useLoginSession. false (private=true, mặc
        // định) = không dùng được đăng nhập sẵn có nhưng không đụng lịch sử;
        // true (private=false) = mang theo đăng nhập, đổi lại ghi lịch sử.
        val tab = engine.createTab(url = "about:blank", isPrivate = !job.useLoginSession)
        crawlTabId = tab.id
        onProgress(0, 0, "Đã mở tab crawl riêng — bắt đầu…")

        if (job.preListStages.isNotEmpty()) {
            phaseNeg1TraverseStages(stageIndex = 0, frontier = listOf(job.listPageUrl))
        } else {
            listPageEntries = listOf(job.listPageUrl)
            startEntry(0)
        }
    }

    fun cancel() {
        cancelled = true
        cleanupTab()
    }

    /**
     * Khôi phục crawl từ checkpoint đã lưu (app crash/bị kill giữa chừng
     * lần chạy trước) — cào TIẾP đúng chỗ, KHÔNG lại từ đầu. Gọi thay cho
     * `start()` khi Scheduler phát hiện job này có checkpoint tồn đọng.
     */
    fun resumeFromCheckpoint(checkpoint: CrawlCheckpoint) {
        previousActiveTabId = engine.getActiveTab()?.id
        chapters.addAll(checkpoint.chaptersSoFar)
        listPageEntries = checkpoint.listPageEntries
        listPageEntryIndex = checkpoint.listPageEntryIndex
        chapterLinks.addAll(checkpoint.chapterLinks)
        blockedChapterCount = checkpoint.blockedChapterCount

        val tab = engine.createTab(url = "about:blank", isPrivate = !job.useLoginSession)
        crawlTabId = tab.id
        onProgress(chapters.size, chapterLinks.size, "Đã khôi phục từ checkpoint (job bị gián đoạn lần trước) — tiếp tục cào…")

        if (checkpoint.pausedAtIndex >= 0) {
            // Vẫn đang chờ giải Cloudflare/captcha thủ công — job status đã
            // là NEEDS_ACTION từ trước (persist riêng trong LeechJob), chỉ
            // cần chuẩn bị sẵn tab + đặt lại pausedAtIndex để
            // resumeAfterManualSolve()/skipBlockedChapter() dùng được ngay
            // khi người dùng bấm nút — KHÔNG tự ý load lại trang hay báo
            // động lại (đã báo từ lần trước, tránh spam notification mỗi
            // lần service khởi động lại).
            pausedAtIndex = checkpoint.pausedAtIndex
            return
        }

        when (checkpoint.phase) {
            CrawlCheckpoint.Phase.COLLECTING_LINKS ->
                if (job.ajaxListMode) phase1CollectLinksAjax(page = 1, baseUrl = listPageEntries.getOrElse(listPageEntryIndex) { job.listPageUrl })
                else phase1CollectLinks(page = 1, baseUrl = listPageEntries.getOrElse(listPageEntryIndex) { job.listPageUrl })
            CrawlCheckpoint.Phase.CRAWLING_CHAPTERS ->
                phase2CrawlChapter(checkpoint.chapterProgressIndex)
        }
    }

    /** Ghi checkpoint xuống đĩa trên thread riêng — không chặn main thread. */
    private fun saveCheckpoint(phase: CrawlCheckpoint.Phase, chapterProgressIndex: Int, pausedIdx: Int = -1) {
        val snapshot = CrawlCheckpoint(
            jobId = job.id, phase = phase,
            listPageEntries = listPageEntries, listPageEntryIndex = listPageEntryIndex,
            chapterLinks = chapterLinks.toList(), chapterProgressIndex = chapterProgressIndex,
            chaptersSoFar = chapters.toList(), blockedChapterCount = blockedChapterCount,
            pausedAtIndex = pausedIdx,
        )
        Thread { CrawlCheckpointRepository.save(context, slotIndex, snapshot) }.start()
    }

    private fun cleanupTab() {
        val tid = crawlTabId ?: return
        crawlTabId = null
        try {
            engine.closeTab(tid)
            previousActiveTabId?.let { prev ->
                if (engine.getTabs().any { it.id == prev }) engine.switchToTab(prev)
            }
        } catch (e: Exception) { /* tab có thể đã bị đóng theo cách khác, bỏ qua an toàn */ }
    }

    // -------------------------------------------------------------------------
    // Phase -1 — Kịch bản nhiều bước tuỳ biến
    // -------------------------------------------------------------------------

    private fun phaseNeg1TraverseStages(stageIndex: Int, frontier: List<String>) {
        if (cancelled) return
        if (stageIndex >= job.preListStages.size) {
            listPageEntries = frontier.distinct()
            onProgress(0, 0, "Kịch bản xong: tìm được ${listPageEntries.size} trang danh sách chương")
            if (listPageEntries.isEmpty()) { finish(error = "Kịch bản không tìm ra trang danh sách chương nào"); return }
            startEntry(0)
            return
        }
        val stage = job.preListStages[stageIndex]
        onProgress(0, 0, "Bước ${stageIndex + 1}/${job.preListStages.size}: ${stage.label} (${frontier.size} trang nguồn)")
        val nextFrontier = mutableListOf<String>()
        traverseFrontierUrl(frontier, 0, stage, nextFrontier) {
            handler.postDelayed({ phaseNeg1TraverseStages(stageIndex + 1, nextFrontier) }, job.delayBetweenPagesMs)
        }
    }

    private fun traverseFrontierUrl(
        frontier: List<String>, idx: Int, stage: com.colablive.keeper.features.ebookleech.model.CrawlStage,
        out: MutableList<String>, onFrontierDone: () -> Unit,
    ) {
        if (cancelled) return
        if (idx >= frontier.size) { onFrontierDone(); return }
        loadUrlAndExtract(
            url = frontier[idx], js = buildCollectLinksJs(stage.linkSelector, stage.linkAttribute),
            onResult = { json ->
                var links = extractLinks(json)
                if (stage.maxLinksPerPage > 0) links = links.take(stage.maxLinksPerPage)
                out.addAll(links)
                handler.postDelayed({ traverseFrontierUrl(frontier, idx + 1, stage, out, onFrontierDone) }, job.delayBetweenPagesMs)
            },
            onError = { handler.postDelayed({ traverseFrontierUrl(frontier, idx + 1, stage, out, onFrontierDone) }, job.delayBetweenPagesMs) }
        )
    }

    // -------------------------------------------------------------------------
    // Điều phối nhiều entry
    // -------------------------------------------------------------------------

    private fun startEntry(entryIdx: Int) {
        if (cancelled) return
        if (entryIdx >= listPageEntries.size) {
            onProgress(chapters.size, chapterLinks.size, "Đã cào xong ${chapters.size} chương từ ${listPageEntries.size} nguồn.")
            finishAllEntries()
            return
        }
        listPageEntryIndex = entryIdx
        if (job.ajaxListMode) {
            // AJAX bỏ qua hẳn Phase 0 (tự dò phân trang DOM) — phân trang
            // AJAX chỉ cần đúng {page} trong ajaxListUrlTemplate.
            phase1CollectLinksAjax(page = 1, baseUrl = listPageEntries[entryIdx])
            return
        }
        val needsDetection = job.autoDetectPagination && job.listPageUrlPattern.isBlank() && resolvedPattern.isBlank()
        if (needsDetection) phase0DetectPagination(listPageEntries[entryIdx])
        else phase1CollectLinks(page = 1, baseUrl = listPageEntries[entryIdx])
    }

    private fun advanceToNextEntry() {
        handler.postDelayed({ startEntry(listPageEntryIndex + 1) }, job.delayBetweenPagesMs)
    }

    // -------------------------------------------------------------------------
    // Phase 0 — Tự dò pattern phân trang
    // -------------------------------------------------------------------------

    private fun phase0DetectPagination(baseUrl: String) {
        if (cancelled) return
        onProgress(0, 0, "Đang dò cách phân trang…")
        loadUrlAndExtract(
            url = baseUrl, js = buildCollectLinksJs(job.chapterLinkSelector, job.chapterLinkAttribute),
            installAjaxPatchFirst = job.suggestAjaxEndpoints,
            onResult = { json ->
                val page1Links = extractLinks(json)
                collectAjaxFrom(json)
                chapterLinks.addAll(page1Links.filter { it !in chapterLinks })
                tryPaginationCandidate(0, page1Links.toSet(), baseUrl)
            },
            onError = { onProgress(0, 0, "Không đọc được trang danh sách gốc — bỏ qua nguồn này"); advanceToNextEntry() }
        )
    }

    private fun tryPaginationCandidate(idx: Int, baseline: Set<String>, baseUrl: String) {
        if (cancelled) return
        if (idx >= paginationCandidates.size) {
            onProgress(0, chapterLinks.size, "Không tự dò được phân trang — coi như chỉ có 1 trang")
            phase2CrawlChapter(index = 0)
            return
        }
        val base = baseUrl.trimEnd('/')
        val template = paginationCandidates[idx].replace("{base}", base)
        val candidateUrl = template.replace("{page}", "2")
        loadUrlAndExtract(
            url = candidateUrl, js = buildCollectLinksJs(job.chapterLinkSelector, job.chapterLinkAttribute),
            onResult = { json ->
                val links = extractLinks(json)
                val newOnes = links.filter { it !in baseline }
                if (newOnes.isNotEmpty()) {
                    resolvedPattern = template
                    chapterLinks.addAll(newOnes.filter { it !in chapterLinks })
                    onJobUpdate(job.copy(resolvedPaginationPattern = template))
                    handler.postDelayed({ phase1CollectLinks(page = 3, baseUrl = baseUrl) }, job.delayBetweenPagesMs)
                } else {
                    handler.postDelayed({ tryPaginationCandidate(idx + 1, baseline, baseUrl) }, job.delayBetweenPagesMs)
                }
            },
            onError = { handler.postDelayed({ tryPaginationCandidate(idx + 1, baseline, baseUrl) }, job.delayBetweenPagesMs) }
        )
    }

    // -------------------------------------------------------------------------
    // Phase 1 (AJAX) — Thu thập link chương từ JSON API thật (KHÔNG bóc HTML)
    // -------------------------------------------------------------------------

    /**
     * ĐÃ THÊM — nhánh AJAX của Phase 1: thay vì bóc link chương bằng CSS
     * selector trên trang HTML, gọi thẳng `job.ajaxListUrlTemplate` (đã
     * thay `{page}`/`{base}`), coi JSON trả về là nguồn danh sách chương
     * THẬT. Bỏ qua hoàn toàn Phase 0 (tự dò phân trang DOM) — phân trang
     * AJAX chỉ cần đúng `{page}` trong template, không cần dò.
     */
    private fun phase1CollectLinksAjax(page: Int, baseUrl: String) {
        if (cancelled) return
        saveCheckpoint(phase = CrawlCheckpoint.Phase.COLLECTING_LINKS, chapterProgressIndex = 0)
        if (page > job.maxPages) {
            onProgress(0, chapterLinks.size, "Nguồn ${listPageEntryIndex + 1}/${listPageEntries.size}: thu thập xong ${chapterLinks.size} chương (AJAX)")
            phase2CrawlChapter(index = 0)
            return
        }
        val tid = crawlTabId
        if (tid == null) { finish(error = "Tab crawl đã bị đóng"); return }
        val apiUrl = job.ajaxListUrlTemplate
            .replace("{page}", page.toString())
            .replace("{base}", baseUrl.trimEnd('/'))
        if (apiUrl.isBlank()) {
            onProgress(0, 0, "Chưa cấu hình URL API danh sách chương (AJAX) — dừng nguồn này")
            advanceToNextEntry()
            return
        }
        onProgress(0, 0, "Đang gọi AJAX API trang $page / ${job.maxPages}…")
        engine.evaluateJsOnTab(
            crawlTabId = tid, url = apiUrl,
            js = "(function(){ return document.body ? document.body.innerText : (document.documentElement ? document.documentElement.innerText : ''); })();",
            timeoutMs = 15_000L,
            onResult = { raw ->
                try {
                    val root = org.json.JSONTokener(raw).nextValue()
                    val itemsArr = JsonPathExtractor.resolveArray(root, job.ajaxListItemsPath)
                        ?: (root as? org.json.JSONArray)
                    if (itemsArr == null) {
                        onProgress(0, 0, "AJAX API trang $page: không tìm thấy mảng chương tại path \"${job.ajaxListItemsPath}\" — dừng nguồn này")
                        phase2CrawlChapter(index = 0)
                        return@evaluateJsOnTab
                    }
                    var foundNew = false
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.opt(i)
                        val rawUrl = JsonPathExtractor.resolveString(item, job.ajaxListUrlField)?.trim().orEmpty()
                        if (rawUrl.isEmpty()) continue
                        val absoluteUrl = try { java.net.URL(java.net.URL(apiUrl), rawUrl).toString() } catch (e: Exception) { rawUrl }
                        if (!chapterLinks.contains(absoluteUrl)) { chapterLinks.add(absoluteUrl); foundNew = true }
                    }
                    if (!foundNew) phase2CrawlChapter(index = 0)
                    else handler.postDelayed({ phase1CollectLinksAjax(page + 1, baseUrl) }, job.delayBetweenPagesMs)
                } catch (e: Exception) {
                    onProgress(0, 0, "AJAX API trang $page lỗi parse JSON: ${e.message} — cào tiếp với ${chapterLinks.size} chương đã có")
                    phase2CrawlChapter(index = 0)
                }
            },
            onError = { reason ->
                if (chapterLinks.isNotEmpty()) phase2CrawlChapter(index = 0)
                else { onProgress(0, 0, "Nguồn ${listPageEntryIndex + 1} lỗi AJAX: $reason — bỏ qua"); advanceToNextEntry() }
            }
        )
    }

    // -------------------------------------------------------------------------
    // Phase 1 — Thu thập link chương
    // -------------------------------------------------------------------------

    private fun phase1CollectLinks(page: Int, baseUrl: String) {
        if (cancelled) return
        saveCheckpoint(phase = CrawlCheckpoint.Phase.COLLECTING_LINKS, chapterProgressIndex = 0)
        if (page > job.maxPages) {
            onProgress(0, chapterLinks.size, "Nguồn ${listPageEntryIndex + 1}/${listPageEntries.size}: thu thập xong ${chapterLinks.size} chương")
            phase2CrawlChapter(index = 0)
            return
        }
        val url = buildListPageUrl(page, baseUrl)
        onProgress(0, 0, "Đang quét trang danh sách $page / ${job.maxPages}…")
        loadUrlAndExtract(
            url = url, js = buildCollectLinksJs(job.chapterLinkSelector, job.chapterLinkAttribute),
            installAjaxPatchFirst = job.suggestAjaxEndpoints,
            onResult = { json ->
                val links = extractLinks(json)
                collectAjaxFrom(json)
                if (links.isEmpty()) { phase2CrawlChapter(index = 0); return@loadUrlAndExtract }
                var foundNew = false
                links.forEach { link -> if (link.isNotEmpty() && !chapterLinks.contains(link)) { chapterLinks.add(link); foundNew = true } }
                if (!foundNew) phase2CrawlChapter(index = 0)
                else handler.postDelayed({ phase1CollectLinks(page + 1, baseUrl) }, job.delayBetweenPagesMs)
            },
            onError = { reason ->
                if (chapterLinks.isNotEmpty()) phase2CrawlChapter(index = 0)
                else { onProgress(0, 0, "Nguồn ${listPageEntryIndex + 1} lỗi: $reason — bỏ qua"); advanceToNextEntry() }
            }
        )
    }

    private fun buildListPageUrl(page: Int, baseUrl: String): String {
        val pattern = resolvedPattern.ifBlank { job.listPageUrlPattern }
        return when {
            pattern.isNotEmpty() && page > 1 -> pattern.replace("{page}", page.toString())
            page == 1 -> baseUrl
            else -> "${baseUrl.trimEnd('/')}/page/$page"
        }
    }

    // -------------------------------------------------------------------------
    // Phase 2 — Cào nội dung từng chương
    // -------------------------------------------------------------------------

    private fun phase2CrawlChapter(index: Int) {
        if (cancelled) return
        if (index >= chapterLinks.size) {
            chapterLinks.clear()
            advanceToNextEntry()
            return
        }
        saveCheckpoint(phase = CrawlCheckpoint.Phase.CRAWLING_CHAPTERS, chapterProgressIndex = index)
        val url = chapterLinks[index]
        val chapterNumber = chapters.size + 1
        onProgress(chapters.size, chapterLinks.size, "Đang cào chương $chapterNumber (nguồn ${listPageEntryIndex + 1}/${listPageEntries.size}, ${index + 1}/${chapterLinks.size})…")

        // ĐÃ THÊM: "AJAX Leech thật" — job.ajaxContentMode bật thì coi
        // `url` (từ chapterLinks) là 1 endpoint JSON THẬT (không phải
        // trang HTML để bóc bằng CSS selector) — parse trực tiếp theo
        // path cấu hình trong job (xem JsonPathExtractor + LeechJob các
        // field ajaxContent*). 2 nhánh CHIA SẺ chung logic xử lý kết quả
        // (blocked-check, ContentProcessor, tải ảnh, publish WordPress,
        // sang chương kế) — chỉ khác cách LẤY json thô.
        val handleChapterJson: (JSONObject) -> Unit = chapterJson@{ json ->
            if (json.optBoolean("blocked", false)) {
                val reason = json.optString("blockReason", "trang yêu cầu xác minh (Cloudflare/captcha)")
                // DỪNG LẠI CHỜ — không tự bỏ qua. Tab crawl vẫn đang
                // active + đang mở đúng trang chặn này, nên nếu
                // người dùng mở app lên lúc này họ sẽ THẤY trực tiếp
                // trang xác minh (Cloudflare checkbox/CAPTCHA...) và
                // có thể giải tay ngay trên đó. Gọi resumeAfterManualSolve()
                // (từ nút UI) để thử lại đúng URL này sau khi giải xong.
                pausedAtIndex = index
                saveCheckpoint(phase = CrawlCheckpoint.Phase.CRAWLING_CHAPTERS, chapterProgressIndex = index, pausedIdx = index)
                onNeedsManualAction(url, reason)
                return@chapterJson
            }
            val rawTitle = json.optString("title", "Chương $chapterNumber").ifBlank { "Chương $chapterNumber" }
            val rawHtml = json.optString("html", "")
            val rawText = json.optString("text", "")
            val processed = ContentProcessor.apply(rawTitle, rawHtml, rawText, job.regexRules)

            if (job.downloadImages) {
                Thread {
                    val (rewrittenHtml, images) = ImageDownloader.processChapterImages(
                        html = processed.html, chapterIndex = chapterNumber,
                        userAgent = job.customUserAgent, maxImages = job.maxImagesPerChapter,
                    )
                    val chapter = LeechChapter(chapterNumber, processed.title, rewrittenHtml, processed.text, url, images)
                    handler.post {
                        chapters.add(chapter)
                        publishIfEnabled(chapter)
                        handler.postDelayed({ phase2CrawlChapter(index + 1) }, job.delayBetweenPagesMs)
                    }
                }.start()
            } else {
                val chapter = LeechChapter(chapterNumber, processed.title, processed.html, processed.text, url)
                chapters.add(chapter)
                publishIfEnabled(chapter)
                handler.postDelayed({ phase2CrawlChapter(index + 1) }, job.delayBetweenPagesMs)
            }
        }
        val handleChapterError: (String) -> Unit = { reason ->
            chapters.add(LeechChapter(chapterNumber, "Chương $chapterNumber [lỗi]",
                "<p>Không lấy được nội dung: $reason</p>", "[Không lấy được nội dung: $reason]", url))
            handler.postDelayed({ phase2CrawlChapter(index + 1) }, job.delayBetweenPagesMs)
        }

        fun doExtract() {
            if (job.ajaxContentMode) {
                extractChapterJsonViaAjax(url, onResult = handleChapterJson, onError = handleChapterError)
            } else {
                loadUrlAndExtract(
                    url = url, js = buildExtractChapterJs(job.chapterTitleSelector, job.chapterContentSelector),
                    onResult = handleChapterJson,
                    onError = handleChapterError,
                )
            }
        }

        if (job.simulateScrollForLazyLoad) {
            autoScrollThenRun(url, attemptsLeft = job.maxScrollAttempts, lastHeight = -1, onDone = { doExtract() })
        } else {
            doExtract()
        }
    }

    /**
     * Đăng chương lên WordPress ngay sau khi cào xong, nếu job bật
     * `publishToWordPress` — chạy trên thread riêng (network I/O), KHÔNG
     * chặn/làm chậm luồng cào tiếp (không đợi kết quả trước khi cào chương
     * kế — lỗi đăng bài không làm hỏng job cào).
     */
    private fun publishIfEnabled(chapter: LeechChapter) {
        if (!job.publishToWordPress) return
        Thread {
            val result = WordPressPublisher.publishChapter(job, chapter, job.name)
            handler.post {
                if (result.success) {
                    publishedCount++
                    onProgress(chapters.size, chapterLinks.size, "Đã đăng \"${chapter.title}\" lên WordPress" + (result.postUrl?.let { " — $it" } ?: ""))
                } else {
                    publishErrorCount++
                    onProgress(chapters.size, chapterLinks.size, "⚠️ Đăng WordPress lỗi ở \"${chapter.title}\": ${result.error}")
                }
            }
        }.start()
    }

    private var pausedAtIndex: Int = -1

    /**
     * Gọi từ UI khi người dùng bấm "✅ Đã giải xong, tiếp tục" — thử lại
     * ĐÚNG URL đang bị chặn (tab crawl vẫn giữ nguyên trạng thái, không
     * load lại từ đầu — script kiểm tra `blocked` sẽ tự thấy trang giờ đã
     * qua được thử thách, vì người dùng vừa giải trực tiếp trên tab đó).
     */
    fun resumeAfterManualSolve() {
        if (cancelled || pausedAtIndex < 0) return
        val idx = pausedAtIndex
        pausedAtIndex = -1
        onProgress(chapters.size, chapterLinks.size, "Đang kiểm tra lại sau khi giải xác minh thủ công…")
        phase2CrawlChapter(idx)
    }

    /**
     * Gọi từ UI khi người dùng bấm "⏭ Bỏ qua chương này" — không cố giải,
     * ghi placeholder rồi cào tiếp các chương sau.
     */
    fun skipBlockedChapter() {
        if (cancelled || pausedAtIndex < 0) return
        val idx = pausedAtIndex
        pausedAtIndex = -1
        blockedChapterCount++
        val url = chapterLinks.getOrNull(idx) ?: ""
        val chapterNumber = chapters.size + 1
        chapters.add(LeechChapter(chapterNumber, "Chương $chapterNumber [BỊ CHẶN - đã bỏ qua]",
            "<p>Trang bị chặn xác minh, người dùng chọn bỏ qua. URL gốc: $url</p>",
            "[Bị chặn, đã bỏ qua: $url]", url))
        onProgress(chapters.size, chapterLinks.size, "Đã bỏ qua chương bị chặn — tiếp tục")
        handler.postDelayed({ phase2CrawlChapter(idx + 1) }, job.delayBetweenPagesMs)
    }


    /**
     * Cuộn dần trang crawl xuống đáy, đợi 700ms, đo lại chiều cao trang —
     * lặp tới khi chiều cao không đổi (nội dung lazy-load đã render hết)
     * hoặc hết `attemptsLeft`. eval_bridge chạy ĐỒNG BỘ (không await được
     * Promise bên trong 1 lệnh eval), nên phải cuộn qua NHIỀU lệnh eval rời
     * rạc từ phía Kotlin thay vì 1 vòng lặp async trong JS.
     */
    private fun autoScrollThenRun(url: String, attemptsLeft: Int, lastHeight: Int, onDone: () -> Unit) {
        if (cancelled) return
        val tid = crawlTabId ?: run { onDone(); return }
        if (attemptsLeft <= 0) { onDone(); return }

        engine.evaluateJs(
            "(function(){window.scrollTo(0, document.body.scrollHeight); return String(document.body.scrollHeight);})();"
        ) { raw ->
            val height = raw?.removePrefix("OK: ")?.toIntOrNull() ?: -1
            if (height == lastHeight) {
                onDone()  // chiều cao ổn định — coi như lazy-load đã xong
            } else {
                handler.postDelayed({ autoScrollThenRun(url, attemptsLeft - 1, height, onDone) }, 700L)
            }
        }
    }


    // -------------------------------------------------------------------------
    // Kết thúc
    // -------------------------------------------------------------------------

    private fun finishAllEntries() {
        if (cancelled) return
        cleanupTab()
        // Toàn bộ phần CÀO đã xong (mọi entry, mọi chương) — checkpoint hết
        // tác dụng từ đây, kể cả nếu job đang chờ sắp xếp mục lục
        // (manualTocReview dùng ChapterCache riêng, không phải checkpoint).
        CrawlCheckpointRepository.delete(context, slotIndex, job.id)
        if (job.suggestAjaxEndpoints && ajaxEndpointsSeen.isNotEmpty()) {
            onJobUpdate(job.copy(detectedAjaxEndpoints = ajaxEndpointsSeen.toList()))
        }
        val blockNote = if (blockedChapterCount > 0) " ($blockedChapterCount chương bị chặn xác minh, xem chi tiết trong ebook)" else ""
        val publishNote = if (job.publishToWordPress) {
            " • WordPress: $publishedCount bài đăng thành công" + (if (publishErrorCount > 0) ", $publishErrorCount lỗi" else "")
        } else ""
        if (job.manualTocReview) {
            onProgress(chapters.size, chapters.size, "Đã cào xong ${chapters.size} chương$blockNote$publishNote. Chờ sắp xếp mục lục…")
            onReviewReady(chapters.toList())
        } else {
            onProgress(chapters.size, chapters.size, "Đã cào xong ${chapters.size} chương$blockNote$publishNote. Đang xuất ebook…")
            phase3Export()
        }
    }

    private fun finish(error: String) {
        cleanupTab()
        onError(error)
    }

    private fun phase3Export() {
        Thread {
            try {
                val path = EbookExporter.export(context, job, chapters)
                handler.post { onDone(path) }
            } catch (e: Exception) {
                handler.post { onError("Xuất ebook thất bại: ${e.message}") }
            }
        }.start()
    }

    /**
     * ĐÃ THÊM — "AJAX Leech thật": `url` (lấy từ `chapterLinks`, có thể do
     * `phase1CollectLinksAjax()` tạo ra HOẶC do người dùng tự nhập link
     * API trực tiếp) được coi là 1 endpoint JSON THẬT — điều hướng tab
     * crawl thẳng tới URL đó (giữ nguyên cookie/session của tab, khác gọi
     * `fetch()` từ 1 origin khác dễ dính CORS), đọc `document.body.innerText`
     * (chính là JSON thô server trả về khi trình duyệt hiển thị 1 URL JSON
     * trần), parse theo path cấu hình trong job.
     *
     * KHÁC "AJAX sniff" cũ (`job.suggestAjaxEndpoints`) — cái đó chỉ DÒ &
     * GỢI Ý url để người dùng tự nhìn, không tự dùng làm nguồn dữ liệu. Cái
     * này DÙNG THẲNG JSON làm nguồn — đúng nghĩa "leech qua AJAX".
     */
    private fun extractChapterJsonViaAjax(url: String, onResult: (JSONObject) -> Unit, onError: (String) -> Unit) {
        val tid = crawlTabId
        if (tid == null) { onError("Tab crawl đã bị đóng"); return }
        engine.evaluateJsOnTab(
            crawlTabId = tid, url = url,
            js = "(function(){ return document.body ? document.body.innerText : (document.documentElement ? document.documentElement.innerText : ''); })();",
            timeoutMs = 15_000L,
            onResult = { raw ->
                try {
                    val root = org.json.JSONTokener(raw).nextValue()
                    val title = JsonPathExtractor.resolveString(root, job.ajaxContentTitleField)
                        ?.trim().takeUnless { it.isNullOrEmpty() }
                    val contentRaw = JsonPathExtractor.resolveString(root, job.ajaxContentField).orEmpty()
                    if (contentRaw.isEmpty()) {
                        onError("Không tìm thấy nội dung tại path \"${job.ajaxContentField}\" trong JSON trả về")
                        return@evaluateJsOnTab
                    }
                    // Nội dung từ JSON API có thể là HTML thô (site render
                    // sẵn) hoặc text thuần (site trả markdown/plain) — KHÔNG
                    // đoán được trước, nên dùng CHUNG 1 giá trị cho cả
                    // html/text; ContentProcessor + EbookExporter phía sau
                    // vẫn xử lý bình thường (EPUB/HTML output dùng field
                    // html, TXT dùng field text — nếu content thật ra là
                    // text thuần thì bản EPUB/HTML sẽ không có thẻ định
                    // dạng, vẫn đọc được, không hỏng).
                    onResult(JSONObject().apply {
                        put("title", title ?: "")
                        put("html", contentRaw)
                        put("text", stripHtmlTagsRoughly(contentRaw))
                    })
                } catch (e: Exception) {
                    onError("AJAX content — JSON không hợp lệ tại $url: ${e.message}")
                }
            },
            onError = onError,
        )
    }

    /** Bóc thẻ HTML thô để có bản text thuần dùng cho xuất TXT — KHÔNG
     * phải parser HTML đầy đủ (không cần, chỉ cần đọc được, không cần đẹp
     * tuyệt đối) — dùng khi nội dung AJAX là HTML nhưng job xuất định dạng
     * TXT (`buildExtractChapterJs` bản HTML có browser thật làm việc này
     * qua `.innerText`; nhánh AJAX không có DOM để nhờ, phải tự làm). */
    private fun stripHtmlTagsRoughly(html: String): String =
        html.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private fun extractLinks(json: JSONObject): List<String> {
        val arr = json.optJSONArray("links") ?: return emptyList()
        return (0 until arr.length()).map { arr.getString(it).trim() }.filter { it.isNotEmpty() }
    }

    private fun collectAjaxFrom(json: JSONObject) {
        if (!job.suggestAjaxEndpoints) return
        val arr = json.optJSONArray("ajaxEndpoints") ?: return
        for (i in 0 until arr.length()) {
            ajaxEndpointsSeen.add(arr.getString(i))
            if (ajaxEndpointsSeen.size >= 40) break
        }
    }

    private fun loadUrlAndExtract(
        url: String, js: String, onResult: (JSONObject) -> Unit, onError: (String) -> Unit,
        installAjaxPatchFirst: Boolean = false,
    ) {
        val tid = crawlTabId
        if (tid == null) { onError("Tab crawl đã bị đóng"); return }
        engine.evaluateJsOnTab(
            crawlTabId = tid, url = url, js = js, timeoutMs = 15_000L,
            installAjaxPatchFirst = installAjaxPatchFirst,
            onResult = { raw ->
                try { onResult(JSONObject(raw)) } catch (e: Exception) { onError("JSON parse lỗi: ${e.message} (raw: ${raw.take(200)})") }
            },
            onError = onError
        )
    }

    private fun buildCollectLinksJs(selector: String, attr: String): String {
        val safeSelector = selector.replace("'", "\\'")
        val safeAttr = attr.replace("'", "\\'")
        val ajaxPart = if (job.suggestAjaxEndpoints)
            "obj.ajaxEndpoints = (window.__ebookLeechAjaxLog || []).map(function(e){ return e.url; });"
        else ""
        return """
            (function() {
                var links = [];
                var elems = document.querySelectorAll('$safeSelector');
                elems.forEach(function(el) {
                    var val = el.getAttribute('$safeAttr') || el.href || '';
                    if (val) {
                        try { val = new URL(val, document.baseURI).href; } catch(e){}
                        links.push(val);
                    }
                });
                var obj = { links: links };
                $ajaxPart
                return JSON.stringify(obj);
            })();
        """.trimIndent()
    }

    private fun buildExtractChapterJs(titleSelector: String, contentSelector: String): String {
        val safeTitle = titleSelector.replace("'", "\\'")
        val safeContent = contentSelector.replace("'", "\\'")
        return """
            (function() {
                // Phát hiện trang chặn xác minh (Cloudflare/captcha) — KHÔNG
                // tự giải được, chỉ nhận diện để báo cáo thay vì âm thầm cào
                // ra rác (title/nội dung rỗng, hoặc chính trang thử thách).
                // Vì GeckoView chạy JS thật (khác HTTP scraper tĩnh), phần
                // lớn thử thách "kiểm tra trình duyệt" tự động qua được —
                // đoạn này chỉ bắt phần CÒN LẠI cần con người (CAPTCHA ảnh,
                // Turnstile tương tác...).
                var titleLower = (document.title || '').toLowerCase();
                var bodyText = (document.body ? document.body.innerText : '').toLowerCase();
                var blockMarkers = [
                    'checking your browser', 'just a moment', 'attention required',
                    'verify you are human', 'xác minh bạn là người', 'cloudflare',
                    'ddos protection by', 'please wait while we verify'
                ];
                var challengeSelectors = ['#challenge-form', '#cf-challenge-running', '.cf-turnstile', 'iframe[src*="turnstile"]'];
                var isBlocked = false;
                var blockReason = '';
                for (var i = 0; i < blockMarkers.length; i++) {
                    if (titleLower.indexOf(blockMarkers[i]) !== -1 || bodyText.indexOf(blockMarkers[i]) !== -1) {
                        isBlocked = true; blockReason = 'title/nội dung khớp "' + blockMarkers[i] + '"'; break;
                    }
                }
                if (!isBlocked) {
                    for (var j = 0; j < challengeSelectors.length; j++) {
                        try {
                            if (document.querySelector(challengeSelectors[j])) {
                                isBlocked = true; blockReason = 'phát hiện phần tử ' + challengeSelectors[j]; break;
                            }
                        } catch (e) {}
                    }
                }
                if (isBlocked) {
                    return JSON.stringify({ blocked: true, blockReason: blockReason });
                }

                var titleEl = document.querySelector('$safeTitle');
                var contentEl = document.querySelector('$safeContent');
                var title = titleEl ? titleEl.innerText.trim() : document.title;
                var html = contentEl ? contentEl.innerHTML : '';
                var text = contentEl ? contentEl.innerText.trim() : document.body.innerText.trim();
                html = html.replace(/<script[\s\S]*?<\/script>/gi, '')
                           .replace(/<style[\s\S]*?<\/style>/gi, '');
                return JSON.stringify({ title: title, html: html, text: text });
            })();
        """.trimIndent()
    }
}
