package com.colablive.keeper.features.ebookleech.engine

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.colablive.keeper.core.GeckoViewEngine
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpoint
import com.colablive.keeper.features.ebookleech.model.CrawlCheckpointRepository
import com.colablive.keeper.features.ebookleech.model.ChapterArchiveRepository
import com.colablive.keeper.features.ebookleech.model.StoryMeta
import com.colablive.keeper.features.ebookleech.model.StoryMetaStore
import com.colablive.keeper.features.ebookleech.model.LeechChapter
import com.colablive.keeper.features.ebookleech.model.LeechJob
import com.colablive.keeper.features.ebookleech.export.EbookExporter
import com.colablive.keeper.features.ebookleech.export.ExportFollowUp
import org.json.JSONObject

/**
 * EbookLeechCrawler — BẢN SỬA sau khi đọc source thật.
 *
 * THAY ĐỔI KIẾN TRÚC LỚN NHẤT: không còn "session ẩn" nào cả — mọi lệnh
 * cào chạy qua 1 TAB THẬT riêng (`crawlTabId`), tạo lúc `start()`, đóng lúc
 * kết thúc. Tab này CÓ THỂ hiện lên màn hình nếu người dùng đang thật sự
 * nhìn slot đó lúc crawl chạy (xem chú thích trong GeckoViewEngineExt.kt).
 * Tự động chuyển lại đúng tab người dùng đang xem trước khi crawl bắt đầu.
 *
 * TÍNH NĂNG AJAX SNIFF TẠM NGỪNG: không còn `collectAjaxEndpoints` — lý do
 * kỹ thuật thật (không phải chưa làm): content script của eval_bridge chạy
 * ở "document_idle" (xem manifest.json thật), nghĩa là fetch/XHR trang gọi
 * lúc tải ban đầu ĐÃ XẢY RA TRƯỚC khi ta kịp tiêm script theo dõi — và việc
 * patch `window.fetch` từ content script có patch được `fetch` mà PAGE
 * SCRIPT thật sự gọi hay không phụ thuộc cơ chế isolated-world của
 * GeckoView WebExtension (Xray wrapper) — CHƯA XÁC NHẬN, cần
 * `exportFunction`/`wrappedJSObject` đúng cách mới chắc ăn. Quyết định bỏ
 * thay vì ship 1 tính năng không chắc chạy — xem PROJECT_STATUS mục hướng
 * dẫn nếu muốn làm lại đúng.
 */
class EbookLeechCrawler(
    private val context: Context,
    private val slotIndex: Int,
    private val engine: GeckoViewEngine,
    private val job: LeechJob,
    private val onProgress: (crawled: Int, total: Int, message: String) -> Unit,
    private val onJobUpdate: (LeechJob) -> Unit,
    private val onDone: (outputPath: String) -> Unit,
    private val onReviewReady: (chapters: List<LeechChapter>) -> Unit = {},
    private val onNeedsManualAction: (url: String, reason: String) -> Unit = { _, _ -> },
    private val onError: (reason: String) -> Unit,
    /** Bản 7.101: tóm tắt lần chạy (cập nhật tăng dần) để hiện trên thẻ job. Gọi ngay TRƯỚC khi xuất ebook / báo xong. */
    private val onRunNote: (note: String) -> Unit = {},
    /** Bản 7.102: lần xuất này có [newCount] chương MỚI so với lần xuất trước (chỉ gọi khi job bật `notifyNewChapters`, đã có lần xuất trước và newCount > 0). EbookLeechScheduler lo việc báo thông báo. */
    private val onNewChapters: (newCount: Int, total: Int) -> Unit = { _, _ -> },
) {
    private val handler = Handler(Looper.getMainLooper())
    private val chapterLinks = mutableListOf<String>()
    private val chapters = mutableListOf<LeechChapter>()
    private var blockedChapterCount = 0
    private var publishedCount = 0
    private var publishErrorCount = 0
    private val ajaxEndpointsSeen = linkedSetOf<String>()

    private var listPageEntries = listOf<String>()
    private var listPageEntryIndex = 0
    private var resolvedPattern: String = job.resolvedPaginationPattern

    private var crawlTabId: String? = null
    private var previousActiveTabId: String? = null

    @Volatile private var cancelled = false

    // ── Bản 7.100 (mục 224): cập nhật tăng dần + bỏ qua chương + chương nhiều trang ──
    /** Kho chương đã cào ở các lần trước (URL -> chương), chỉ nạp khi job.incrementalUpdate. */
    private var archive: Map<String, LeechChapter> = emptyMap()
    /** URL chương đã đưa vào ebook trong lần chạy này (kể cả khôi phục từ checkpoint) — chống trùng giữa nhiều nguồn/nhiều trang danh sách. */
    private val seenUrls = HashSet<String>()
    private var reusedCount = 0
    private var newCount = 0
    private var skippedCount = 0

    // ── Bản 7.104: quét nhanh danh sách theo điểm neo (ListScanPlanner) ──
    /** Điểm neo lần trước (thứ tự danh sách đầy đủ + trang cuối + số lần quét nhanh liên tiếp); nạp cùng kho. */
    private var prevListMeta: ChapterArchiveRepository.ListMeta? = null
    private var planner: ListScanPlanner? = null
    private var scanKnown: List<String> = emptyList()
    private var scanHint = 0
    private var scanPrevStreak = 0
    /** THỨ TỰ danh sách chương của lần quét NÀY (gom trước khi `chapterLinks` bị xoá ở cuối mỗi nguồn) — ghi vào kho làm điểm neo cho lần sau. */
    private val lastLinkOrder = LinkedHashSet<String>()
    private var listScanLastPage = 0
    private var listScanFastStreak = 0
    private var listScanNote = ""

    // ── Bản 7.104: thông tin truyện ──
    private var storyMetaDone = false
    /** Thông tin truyện (hoặc ảnh bìa) lần này KHÁC bản đã lưu => phải xuất lại ebook dù không có chương mới (cập nhật tăng dần). */
    @Volatile private var storyChanged = false

    private val paginationCandidates = listOf(
        "{base}?page={page}", "{base}/page/{page}", "{base}/trang-{page}", "{base}/page-{page}", "{base}/{page}",
    )

    // -------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------

    fun start() {
        previousActiveTabId = engine.getActiveTab()?.id

        // ĐÃ THÊM — xoay proxy dự phòng (nếu người dùng đã bấm "tìm nhiều
        // proxy" trước đó) — CHỈ lúc job MỚI khởi động, không gọi ở
        // resumeFromCheckpoint(). Xem giới hạn kiến trúc đầy đủ trong
        // ProxyPoolManager.kt — KHÔNG có tác dụng tức thời nếu khe đang
        // chạy liên tục, chỉ có hiệu lực từ lần khe khởi động lại kế tiếp.
        ProxyPoolManager.rotateToNext(context, slotIndex)

        // Dùng job.useLoginSession để quyết định isPrivate — xem chú thích
        // đầy đủ tại LeechJob.useLoginSession. false (private=true, mặc
        // định) = không dùng được đăng nhập sẵn có nhưng không đụng lịch sử;
        // true (private=false) = mang theo đăng nhập, đổi lại ghi lịch sử.
        val tab = engine.createTab(url = "about:blank", isPrivate = !job.useLoginSession)
        crawlTabId = tab.id
        onProgress(0, 0, "Đã mở tab crawl riêng — bắt đầu…")

        withArchive {
            if (job.preListStages.isNotEmpty()) {
                phaseNeg1TraverseStages(stageIndex = 0, frontier = listOf(job.listPageUrl))
            } else {
                listPageEntries = listOf(job.listPageUrl)
                startEntry(0)
            }
        }
    }

    /**
     * Nạp kho chương (chỉ khi job.incrementalUpdate) trên thread riêng — kho có thể hàng trăm chương kèm ảnh, đọc trên main thread có thể gây ANR —
     * rồi chạy tiếp [then] trên main thread. Kho hỏng/không có => rỗng => cào đầy đủ như lần đầu.
     */
    private fun withArchive(then: () -> Unit) {
        if (!job.incrementalUpdate) { then(); return }
        onProgress(0, 0, "Cập nhật tăng dần: đang nạp kho chương đã cào…")
        Thread {
            val loaded = try { ChapterArchiveRepository.load(context, slotIndex, job.id) } catch (e: Exception) { emptyMap() }
            val loadedListMeta = try { ChapterArchiveRepository.loadListMeta(context, slotIndex, job.id) } catch (e: Exception) { null }
            handler.post {
                if (cancelled) return@post
                archive = loaded
                prevListMeta = loadedListMeta
                onProgress(0, 0, if (loaded.isEmpty()) "Kho chương trống — lần này cào đầy đủ" else "Kho có ${loaded.size} chương đã cào — chỉ mở chương mới")
                then()
            }
        }.start()
    }

    /** Mọi chỗ đưa chương vào ebook đều qua đây để seenUrls luôn đúng. */
    private fun addChapter(ch: LeechChapter) {
        chapters.add(ch)
        if (ch.sourceUrl.isNotBlank()) seenUrls.add(ch.sourceUrl)
    }

    private fun skipReasonFor(rawText: String, processedText: String): String? = skipReason(job, rawText, processedText)

    fun cancel() {
        cancelled = true
        cleanupTab()
    }

    /**
     * Khôi phục crawl từ checkpoint đã lưu (app crash/bị kill giữa chừng
     * lần chạy trước) — cào TIẾP đúng chỗ, KHÔNG lại từ đầu. Gọi thay cho
     * `start()` khi Scheduler phát hiện job này có checkpoint tồn đọng.
     */
    fun resumeFromCheckpoint(checkpoint: CrawlCheckpoint) {
        previousActiveTabId = engine.getActiveTab()?.id
        chapters.addAll(checkpoint.chaptersSoFar)
        checkpoint.chaptersSoFar.forEach { if (it.sourceUrl.isNotBlank()) seenUrls.add(it.sourceUrl) }
        listPageEntries = checkpoint.listPageEntries
        listPageEntryIndex = checkpoint.listPageEntryIndex
        chapterLinks.addAll(checkpoint.chapterLinks)
        blockedChapterCount = checkpoint.blockedChapterCount

        val tab = engine.createTab(url = "about:blank", isPrivate = !job.useLoginSession)
        crawlTabId = tab.id
        onProgress(chapters.size, chapterLinks.size, "Đã khôi phục từ checkpoint (job bị gián đoạn lần trước) — tiếp tục cào…")

        withArchive resume@{
        if (checkpoint.pausedAtIndex >= 0) {
            // Vẫn đang chờ giải Cloudflare/captcha thủ công — job status đã
            // là NEEDS_ACTION từ trước (persist riêng trong LeechJob), chỉ
            // cần chuẩn bị sẵn tab + đặt lại pausedAtIndex để
            // resumeAfterManualSolve()/skipBlockedChapter() dùng được ngay
            // khi người dùng bấm nút — KHÔNG tự ý load lại trang hay báo
            // động lại (đã báo từ lần trước, tránh spam notification mỗi
            // lần service khởi động lại).
            pausedAtIndex = checkpoint.pausedAtIndex
            return@resume
        }

        when (checkpoint.phase) {
            CrawlCheckpoint.Phase.COLLECTING_LINKS ->
                if (job.ajaxListMode) phase1CollectLinksAjax(page = 1, baseUrl = listPageEntries.getOrElse(listPageEntryIndex) { job.listPageUrl })
                else phase1CollectLinks(page = 1, baseUrl = listPageEntries.getOrElse(listPageEntryIndex) { job.listPageUrl })
            CrawlCheckpoint.Phase.CRAWLING_CHAPTERS ->
                phase2CrawlChapter(checkpoint.chapterProgressIndex)
        }
        }
    }

    /** Ghi checkpoint xuống đĩa trên thread riêng — không chặn main thread. */
    private fun saveCheckpoint(phase: CrawlCheckpoint.Phase, chapterProgressIndex: Int, pausedIdx: Int = -1) {
        val snapshot = CrawlCheckpoint(
            jobId = job.id, phase = phase,
            listPageEntries = listPageEntries, listPageEntryIndex = listPageEntryIndex,
            chapterLinks = chapterLinks.toList(), chapterProgressIndex = chapterProgressIndex,
            chaptersSoFar = chapters.toList(), blockedChapterCount = blockedChapterCount,
            pausedAtIndex = pausedIdx,
        )
        Thread { CrawlCheckpointRepository.save(context, slotIndex, snapshot) }.start()
    }

    private fun cleanupTab() {
        val tid = crawlTabId ?: return
        crawlTabId = null
        try {
            engine.closeTab(tid)
            previousActiveTabId?.let { prev ->
                if (engine.getTabs().any { it.id == prev }) engine.switchToTab(prev)
            }
        } catch (e: Exception) { /* tab có thể đã bị đóng theo cách khác, bỏ qua an toàn */ }
    }

    // -------------------------------------------------------------------------
    // Phase -1 — Kịch bản nhiều bước tuỳ biến
    // -------------------------------------------------------------------------

    private fun phaseNeg1TraverseStages(stageIndex: Int, frontier: List<String>) {
        if (cancelled) return
        if (stageIndex >= job.preListStages.size) {
            listPageEntries = frontier.distinct()
            onProgress(0, 0, "Kịch bản xong: tìm được ${listPageEntries.size} trang danh sách chương")
            if (listPageEntries.isEmpty()) { finish(error = "Kịch bản không tìm ra trang danh sách chương nào"); return }
            startEntry(0)
            return
        }
        val stage = job.preListStages[stageIndex]
        onProgress(0, 0, "Bước ${stageIndex + 1}/${job.preListStages.size}: ${stage.label} (${frontier.size} trang nguồn)")
        val nextFrontier = mutableListOf<String>()
        traverseFrontierUrl(frontier, 0, stage, nextFrontier) {
            handler.postDelayed({ phaseNeg1TraverseStages(stageIndex + 1, nextFrontier) }, job.delayBetweenPagesMs)
        }
    }

    private fun traverseFrontierUrl(
        frontier: List<String>, idx: Int, stage: com.colablive.keeper.features.ebookleech.model.CrawlStage,
        out: MutableList<String>, onFrontierDone: () -> Unit,
    ) {
        if (cancelled) return
        if (idx >= frontier.size) { onFrontierDone(); return }
        loadUrlAndExtract(
            url = frontier[idx], js = buildCollectLinksJs(stage.linkSelector, stage.linkAttribute),
            onResult = { json ->
                var links = extractLinks(json)
                if (stage.maxLinksPerPage > 0) links = links.take(stage.maxLinksPerPage)
                out.addAll(links)
                handler.postDelayed({ traverseFrontierUrl(frontier, idx + 1, stage, out, onFrontierDone) }, job.delayBetweenPagesMs)
            },
            onError = { handler.postDelayed({ traverseFrontierUrl(frontier, idx + 1, stage, out, onFrontierDone) }, job.delayBetweenPagesMs) }
        )
    }

    // -------------------------------------------------------------------------
    // Điều phối nhiều entry
    // -------------------------------------------------------------------------

    private fun startEntry(entryIdx: Int) {
        if (cancelled) return
        if (entryIdx >= listPageEntries.size) {
            onProgress(chapters.size, chapterLinks.size, "Đã cào xong ${chapters.size} chương từ ${listPageEntries.size} nguồn.")
            finishAllEntries()
            return
        }
        listPageEntryIndex = entryIdx
        if (canPlanScan()) { startPlannedScan(listPageEntries[entryIdx]); return }
        if (job.ajaxListMode) {
            // AJAX bỏ qua hẳn Phase 0 (tự dò phân trang DOM) — phân trang
            // AJAX chỉ cần đúng {page} trong ajaxListUrlTemplate.
            phase1CollectLinksAjax(page = 1, baseUrl = listPageEntries[entryIdx])
            return
        }
        val needsDetection = job.autoDetectPagination && job.listPageUrlPattern.isBlank() && resolvedPattern.isBlank()
        if (needsDetection) phase0DetectPagination(listPageEntries[entryIdx])
        else phase1CollectLinks(page = 1, baseUrl = listPageEntries[entryIdx])
    }

    private fun advanceToNextEntry() {
        handler.postDelayed({ startEntry(listPageEntryIndex + 1) }, job.delayBetweenPagesMs)
    }

    // -------------------------------------------------------------------------
    // Phase 0 — Tự dò pattern phân trang
    // -------------------------------------------------------------------------

    private fun phase0DetectPagination(baseUrl: String) {
        if (cancelled) return
        onProgress(0, 0, "Đang dò cách phân trang…")
        loadUrlAndExtract(
            url = baseUrl, js = buildCollectLinksJs(job.chapterLinkSelector, job.chapterLinkAttribute),
            installAjaxPatchFirst = job.suggestAjaxEndpoints,
            onResult = { json ->
                val page1Links = extractLinks(json)
                collectAjaxFrom(json)
                chapterLinks.addAll(page1Links.filter { it !in chapterLinks })
                tryPaginationCandidate(0, page1Links.toSet(), baseUrl)
            },
            onError = { onProgress(0, 0, "Không đọc được trang danh sách gốc — bỏ qua nguồn này"); advanceToNextEntry() }
        )
    }

    private fun tryPaginationCandidate(idx: Int, baseline: Set<String>, baseUrl: String) {
        if (cancelled) return
        if (idx >= paginationCandidates.size) {
            onProgress(0, chapterLinks.size, "Không tự dò được phân trang — coi như chỉ có 1 trang")
            phase2CrawlChapter(index = 0)
            return
        }
        val base = baseUrl.trimEnd('/')
        val template = paginationCandidates[idx].replace("{base}", base)
        val candidateUrl = template.replace("{page}", "2")
        loadUrlAndExtract(
            url = candidateUrl, js = buildCollectLinksJs(job.chapterLinkSelector, job.chapterLinkAttribute),
            onResult = { json ->
                val links = extractLinks(json)
                val newOnes = links.filter { it !in baseline }
                if (newOnes.isNotEmpty()) {
                    resolvedPattern = template
                    chapterLinks.addAll(newOnes.filter { it !in chapterLinks })
                    onJobUpdate(job.copy(resolvedPaginationPattern = template))
                    handler.postDelayed({ phase1CollectLinks(page = 3, baseUrl = baseUrl) }, job.delayBetweenPagesMs)
                } else {
                    handler.postDelayed({ tryPaginationCandidate(idx + 1, baseline, baseUrl) }, job.delayBetweenPagesMs)
                }
            },
            onError = { handler.postDelayed({ tryPaginationCandidate(idx + 1, baseline, baseUrl) }, job.delayBetweenPagesMs) }
        )
    }

    // -------------------------------------------------------------------------
    // Phase 1 (AJAX) — Thu thập link chương từ JSON API thật (KHÔNG bóc HTML)
    // -------------------------------------------------------------------------

    /**
     * ĐÃ THÊM — nhánh AJAX của Phase 1: thay vì bóc link chương bằng CSS
     * selector trên trang HTML, gọi thẳng `job.ajaxListUrlTemplate` (đã
     * thay `{page}`/`{base}`), coi JSON trả về là nguồn danh sách chương
     * THẬT. Bỏ qua hoàn toàn Phase 0 (tự dò phân trang DOM) — phân trang
     * AJAX chỉ cần đúng `{page}` trong template, không cần dò.
     */
    private fun phase1CollectLinksAjax(page: Int, baseUrl: String) {
        if (cancelled) return
        saveCheckpoint(phase = CrawlCheckpoint.Phase.COLLECTING_LINKS, chapterProgressIndex = 0)
        if (page > job.maxPages) {
            onProgress(0, chapterLinks.size, "Nguồn ${listPageEntryIndex + 1}/${listPageEntries.size}: thu thập xong ${chapterLinks.size} chương (AJAX)")
            phase2CrawlChapter(index = 0)
            return
        }
        val tid = crawlTabId
        if (tid == null) { finish(error = "Tab crawl đã bị đóng"); return }
        val apiUrl = job.ajaxListUrlTemplate
            .replace("{page}", page.toString())
            .replace("{base}", baseUrl.trimEnd('/'))
        if (apiUrl.isBlank()) {
            onProgress(0, 0, "Chưa cấu hình URL API danh sách chương (AJAX) — dừng nguồn này")
            advanceToNextEntry()
            return
        }
        onProgress(0, 0, "Đang gọi AJAX API trang $page / ${job.maxPages}…")
        engine.evaluateJsOnTab(
            crawlTabId = tid, url = apiUrl,
            js = "(function(){ return document.body ? document.body.innerText : (document.documentElement ? document.documentElement.innerText : ''); })();",
            timeoutMs = 15_000L,
            onResult = { raw ->
                try {
                    val root = org.json.JSONTokener(raw).nextValue()
                    val itemsArr = JsonPathExtractor.resolveArray(root, job.ajaxListItemsPath)
                        ?: (root as? org.json.JSONArray)
                    if (itemsArr == null) {
                        onProgress(0, 0, "AJAX API trang $page: không tìm thấy mảng chương tại path \"${job.ajaxListItemsPath}\" — dừng nguồn này")
                        phase2CrawlChapter(index = 0)
                        return@evaluateJsOnTab
                    }
                    var foundNew = false
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.opt(i)
                        val rawUrl = JsonPathExtractor.resolveString(item, job.ajaxListUrlField)?.trim().orEmpty()
                        if (rawUrl.isEmpty()) continue
                        val absoluteUrl = try { java.net.URL(java.net.URL(apiUrl), rawUrl).toString() } catch (e: Exception) { rawUrl }
                        if (!chapterLinks.contains(absoluteUrl)) { chapterLinks.add(absoluteUrl); foundNew = true }
                    }
                    if (foundNew) listScanLastPage = maxOf(listScanLastPage, page)
                    if (!foundNew) phase2CrawlChapter(index = 0)
                    else handler.postDelayed({ phase1CollectLinksAjax(page + 1, baseUrl) }, job.delayBetweenPagesMs)
                } catch (e: Exception) {
                    onProgress(0, 0, "AJAX API trang $page lỗi parse JSON: ${e.message} — cào tiếp với ${chapterLinks.size} chương đã có")
                    phase2CrawlChapter(index = 0)
                }
            },
            onError = { reason ->
                if (chapterLinks.isNotEmpty()) phase2CrawlChapter(index = 0)
                else { onProgress(0, 0, "Nguồn ${listPageEntryIndex + 1} lỗi AJAX: $reason — bỏ qua"); advanceToNextEntry() }
            }
        )
    }

    // -------------------------------------------------------------------------
    // Phase 1 — Thu thập link chương
    // -------------------------------------------------------------------------

    private fun phase1CollectLinks(page: Int, baseUrl: String) {
        if (cancelled) return
        saveCheckpoint(phase = CrawlCheckpoint.Phase.COLLECTING_LINKS, chapterProgressIndex = 0)
        if (page > job.maxPages) {
            onProgress(0, chapterLinks.size, "Nguồn ${listPageEntryIndex + 1}/${listPageEntries.size}: thu thập xong ${chapterLinks.size} chương")
            phase2CrawlChapter(index = 0)
            return
        }
        val url = buildListPageUrl(page, baseUrl)
        onProgress(0, 0, "Đang quét trang danh sách $page / ${job.maxPages}…")
        loadUrlAndExtract(
            url = url, js = buildCollectLinksJs(job.chapterLinkSelector, job.chapterLinkAttribute),
            installAjaxPatchFirst = job.suggestAjaxEndpoints,
            onResult = { json ->
                val links = extractLinks(json)
                collectAjaxFrom(json)
                if (links.isEmpty()) { phase2CrawlChapter(index = 0); return@loadUrlAndExtract }
                var foundNew = false
                links.forEach { link -> if (link.isNotEmpty() && !chapterLinks.contains(link)) { chapterLinks.add(link); foundNew = true } }
                if (foundNew) listScanLastPage = maxOf(listScanLastPage, page)
                if (!foundNew) phase2CrawlChapter(index = 0)
                else handler.postDelayed({ phase1CollectLinks(page + 1, baseUrl) }, job.delayBetweenPagesMs)
            },
            onError = { reason ->
                if (chapterLinks.isNotEmpty()) phase2CrawlChapter(index = 0)
                else { onProgress(0, 0, "Nguồn ${listPageEntryIndex + 1} lỗi: $reason — bỏ qua"); advanceToNextEntry() }
            }
        )
    }

    // -------------------------------------------------------------------------
    // Bản 7.104 — quét danh sách THEO KẾ HOẠCH (điểm neo). Điều kiện y hệt runner Python: cập nhật tăng dần + đã có kho + một nguồn + đã biết mẫu phân trang (hoặc chế độ AJAX).
    // Luôn đi qua [ListScanPlanner] khi đủ điều kiện (chế độ đầy đủ y hệt vòng lặp cũ, lại GIỮ chương cũ nếu trang danh sách lỗi giữa chừng); chỉ NHẢY khi bật `listFastScan`.
    // Resume từ checkpoint đang ở giai đoạn thu thập link vẫn dùng vòng lặp tuần tự cũ (an toàn nhất).
    // -------------------------------------------------------------------------

    private fun canPlanScan(): Boolean {
        if (!job.incrementalUpdate || archive.isEmpty()) return false
        if (job.preListStages.isNotEmpty() || listPageEntries.size != 1 || chapterLinks.isNotEmpty()) return false
        return if (job.ajaxListMode) job.ajaxListUrlTemplate.isNotBlank() else (resolvedPattern.isNotBlank() || job.listPageUrlPattern.isNotBlank())
    }

    private fun startPlannedScan(baseUrl: String) {
        val prev = prevListMeta
        scanKnown = prev?.order?.takeIf { it.isNotEmpty() } ?: archive.keys.toList()
        scanHint = prev?.lastPage ?: 0
        scanPrevStreak = prev?.fastStreak ?: 0
        var useFast = job.listFastScan && scanHint >= 1
        if (useFast && scanPrevStreak >= ListScanPlanner.FAST_SCAN_MAX_STREAK) {
            useFast = false
            onProgress(0, 0, "Đã quét nhanh $scanPrevStreak lần liên tiếp — lần này quét ĐẦY ĐỦ để bắt chương chèn/đổi tên ở giữa danh sách")
        }
        beginPlannerAttempt(baseUrl, useFast)
    }

    private fun beginPlannerAttempt(baseUrl: String, fast: Boolean) {
        planner = ListScanPlanner(job.maxPages, scanKnown, scanHint, fast)
        stepPlannedScan(baseUrl)
    }

    private fun stepPlannedScan(baseUrl: String) {
        if (cancelled) return
        val pl = planner ?: return
        saveCheckpoint(phase = CrawlCheckpoint.Phase.COLLECTING_LINKS, chapterProgressIndex = 0)
        val p = pl.nextPage()
        if (p == null) { finishPlannedScan(baseUrl); return }
        fetchListPage(p, baseUrl) { links ->
            // Trang ĐẦU trống trong khi kho đã có chương: gần như chắc chắn là trang lỗi/chặn chứ không phải truyện bị xoá sạch => coi là lỗi để GIỮ danh sách cũ (không làm trống ebook + kho).
            val safe = if (p == 1 && links != null && links.isEmpty() && scanKnown.isNotEmpty()) {
                onProgress(0, 0, "Trang danh sách đầu tiên trả về 0 chương trong khi kho đã có ${scanKnown.size} — coi là lỗi/bị chặn, giữ danh sách cũ")
                null
            } else links
            pl.onPage(p, safe)
            handler.postDelayed({ stepPlannedScan(baseUrl) }, if (pl.nextPage() == null) 0L else job.delayBetweenPagesMs)
        }
    }

    private fun finishPlannedScan(baseUrl: String) {
        val res = planner?.result() ?: return
        if (res.inconsistent) {
            onProgress(0, 0, "Quét nhanh cho kết quả không nhất quán với kho — quét lại ĐẦY ĐỦ danh sách")
            beginPlannerAttempt(baseUrl, false)
            return
        }
        planner = null
        val meta = res.meta
        val seen = chapterLinks.toHashSet()
        res.links.forEach { if (seen.add(it)) chapterLinks.add(it) }
        listScanLastPage = if (meta.blocked) maxOf(meta.lastPage, scanHint) else meta.lastPage
        listScanFastStreak = if (meta.mode == "fast") scanPrevStreak + 1 else 0
        listScanNote = when {
            meta.blocked -> ", danh sách lỗi giữa chừng (giữ phần cũ từ kho)"
            meta.mode == "fast" -> ", quét nhanh danh sách (đọc ${meta.pagesLoaded} trang, bỏ qua ${meta.pagesSkipped})"
            else -> ""
        }
        onProgress(0, chapterLinks.size, when {
            meta.blocked -> "Trang danh sách bị chặn/lỗi giữa chừng — giữ phần danh sách cũ từ kho (${chapterLinks.size} chương)"
            meta.mode == "fast" -> "Quét nhanh: đọc ${meta.pagesLoaded} trang, bỏ qua ${meta.pagesSkipped} trang giữa danh sách (giữ nguyên thứ tự từ kho) — ${chapterLinks.size} chương"
            else -> "Nguồn 1/1: thu thập xong ${chapterLinks.size} chương"
        })
        phase2CrawlChapter(index = 0)
    }

    /** Đọc MỘT trang danh sách (HTML hoặc API AJAX) => danh sách URL chương; rỗng = trang không có chương; null = lỗi/bị chặn. */
    private fun fetchListPage(p: Int, baseUrl: String, cb: (List<String>?) -> Unit) {
        val tid = crawlTabId
        if (tid == null) { cb(null); return }
        val modeLabel = if (planner?.fast == true) " (quét nhanh)" else ""
        if (!job.ajaxListMode) {
            onProgress(0, 0, "Đang quét trang danh sách $p / ${job.maxPages}…$modeLabel")
            loadUrlAndExtract(
                url = buildListPageUrl(p, baseUrl), js = buildCollectLinksJs(job.chapterLinkSelector, job.chapterLinkAttribute),
                installAjaxPatchFirst = job.suggestAjaxEndpoints,
                onResult = { json -> collectAjaxFrom(json); cb(extractLinks(json)) },
                onError = { reason -> onProgress(0, 0, "Trang danh sách $p lỗi: $reason"); cb(null) },
            )
            return
        }
        val apiUrl = job.ajaxListUrlTemplate.replace("{page}", p.toString()).replace("{base}", baseUrl.trimEnd('/'))
        onProgress(0, 0, "Đang gọi AJAX API trang $p / ${job.maxPages}…$modeLabel")
        engine.evaluateJsOnTab(
            crawlTabId = tid, url = apiUrl,
            js = "(function(){ return document.body ? document.body.innerText : (document.documentElement ? document.documentElement.innerText : ''); })();",
            timeoutMs = 15_000L,
            onResult = { raw ->
                val links = try {
                    val root = org.json.JSONTokener(raw).nextValue()
                    val itemsArr = JsonPathExtractor.resolveArray(root, job.ajaxListItemsPath) ?: (root as? org.json.JSONArray)
                    if (itemsArr == null) {
                        onProgress(0, 0, "AJAX API trang $p: không tìm thấy mảng chương tại path \"${job.ajaxListItemsPath}\"")
                        emptyList()
                    } else (0 until itemsArr.length()).mapNotNull { i ->
                        val rawUrl = JsonPathExtractor.resolveString(itemsArr.opt(i), job.ajaxListUrlField)?.trim().orEmpty()
                        if (rawUrl.isEmpty()) null else try { java.net.URL(java.net.URL(apiUrl), rawUrl).toString() } catch (e: Exception) { rawUrl }
                    }
                } catch (e: Exception) {
                    onProgress(0, 0, "AJAX API trang $p lỗi parse JSON: ${e.message}")
                    null
                }
                cb(links)
            },
            onError = { reason -> onProgress(0, 0, "AJAX API trang $p lỗi: $reason"); cb(null) },
        )
    }

    private fun buildListPageUrl(page: Int, baseUrl: String): String {
        val pattern = resolvedPattern.ifBlank { job.listPageUrlPattern }
        return when {
            pattern.isNotEmpty() && page > 1 -> pattern.replace("{page}", page.toString())
            page == 1 -> baseUrl
            else -> "${baseUrl.trimEnd('/')}/page/$page"
        }
    }

    // -------------------------------------------------------------------------
    // Phase 2 — Cào nội dung từng chương
    // -------------------------------------------------------------------------

    private fun phase2CrawlChapter(index: Int) {
        if (cancelled) return
        if (index >= chapterLinks.size) {
            lastLinkOrder.addAll(chapterLinks)   // bản 7.104: nhớ thứ tự danh sách trước khi xoá — điểm neo cho lần quét sau
            chapterLinks.clear()
            advanceToNextEntry()
            return
        }
        saveCheckpoint(phase = CrawlCheckpoint.Phase.CRAWLING_CHAPTERS, chapterProgressIndex = index)
        val url = chapterLinks[index]
        val chapterNumber = chapters.size + 1

        // Bản 7.100 — cập nhật tăng dần: URL đã có trong ebook lần này (trùng giữa nhiều nguồn) thì bỏ; URL đã có trong kho (và không thuộc N chương cuối cần cào lại) thì
        // dùng bản đã lưu, KHÔNG mở trang. Dùng handler.post thay vì gọi đệ quy trực tiếp: hàng nghìn chương dùng lại liên tiếp sẽ tràn stack nếu đệ quy.
        if (job.incrementalUpdate) {
            if (url in seenUrls) { handler.post { phase2CrawlChapter(index + 1) }; return }
            val cached = archive[url]
            val mustRefresh = job.refreshLastN > 0 && index >= chapterLinks.size - job.refreshLastN
            if (cached != null && !mustRefresh) {
                addChapter(cached.copy(index = chapterNumber))
                reusedCount++
                if (reusedCount % 25 == 0) onProgress(chapters.size, chapterLinks.size, "Dùng lại $reusedCount chương từ kho (chưa mở trang nào)…")
                handler.post { phase2CrawlChapter(index + 1) }
                return
            }
        }
        onProgress(chapters.size, chapterLinks.size, "Đang cào chương $chapterNumber (nguồn ${listPageEntryIndex + 1}/${listPageEntries.size}, ${index + 1}/${chapterLinks.size})…")

        // ĐÃ THÊM: "AJAX Leech thật" — job.ajaxContentMode bật thì coi
        // `url` (từ chapterLinks) là 1 endpoint JSON THẬT (không phải
        // trang HTML để bóc bằng CSS selector) — parse trực tiếp theo
        // path cấu hình trong job (xem JsonPathExtractor + LeechJob các
        // field ajaxContent*). 2 nhánh CHIA SẺ chung logic xử lý kết quả
        // (blocked-check, ContentProcessor, tải ảnh, publish WordPress,
        // sang chương kế) — chỉ khác cách LẤY json thô.
        val handleChapterJson: (JSONObject) -> Unit = chapterJson@{ json ->
            if (json.optBoolean("blocked", false)) {
                val reason = json.optString("blockReason", "trang yêu cầu xác minh (Cloudflare/captcha)")
                // DỪNG LẠI CHỜ — không tự bỏ qua. Tab crawl vẫn đang
                // active + đang mở đúng trang chặn này, nên nếu
                // người dùng mở app lên lúc này họ sẽ THẤY trực tiếp
                // trang xác minh (Cloudflare checkbox/CAPTCHA...) và
                // có thể giải tay ngay trên đó. Gọi resumeAfterManualSolve()
                // (từ nút UI) để thử lại đúng URL này sau khi giải xong.
                pausedAtIndex = index
                saveCheckpoint(phase = CrawlCheckpoint.Phase.CRAWLING_CHAPTERS, chapterProgressIndex = index, pausedIdx = index)
                onNeedsManualAction(url, reason)
                return@chapterJson
            }
            val rawTitle = json.optString("title", "Chương $chapterNumber").ifBlank { "Chương $chapterNumber" }
            val rawHtml = json.optString("html", "")
            val rawText = json.optString("text", "")
            val processed = ContentProcessor.apply(rawTitle, rawHtml, rawText, job.regexRules)

            // Bản 7.100 — bỏ qua chương theo điều kiện (khoá/rỗng/thông báo). Không đưa vào ebook, không tốn số thứ tự, KHÔNG lưu vào kho => lần sau (nếu
            // site mở khoá) vẫn thử lại. Ghi tiến độ để người dùng thấy chương nào bị bỏ và vì sao.
            val skipReason = skipReasonFor(rawText, processed.text)
            if (skipReason != null) {
                skippedCount++
                onProgress(chapters.size, chapterLinks.size, "Bỏ qua \"${rawTitle.take(50)}\": $skipReason")
                handler.postDelayed({ phase2CrawlChapter(index + 1) }, job.delayBetweenPagesMs)
                return@chapterJson
            }

            // Chế độ tăng dần: tên file ảnh KHÔNG được dựa vào số thứ tự chương (số này đổi khi site bỏ/chèn chương, còn chương dùng lại từ kho giữ nguyên tên ảnh cũ
            // => dễ trùng tên). Dùng băm URL (ổn định, không đổi theo vị trí).
            val imageKey = if (job.incrementalUpdate) (url.hashCode() and 0x7fffffff) else chapterNumber
            if (job.downloadImages) {
                Thread {
                    val (rewrittenHtml, images) = ImageDownloader.processChapterImages(
                        html = processed.html, chapterIndex = imageKey,
                        userAgent = job.customUserAgent, maxImages = job.maxImagesPerChapter,
                    )
                    val chapter = LeechChapter(chapterNumber, processed.title, rewrittenHtml, processed.text, url, images)
                    handler.post {
                        addChapter(chapter); newCount++
                        publishIfEnabled(chapter)
                        handler.postDelayed({ phase2CrawlChapter(index + 1) }, job.delayBetweenPagesMs)
                    }
                }.start()
            } else {
                val chapter = LeechChapter(chapterNumber, processed.title, processed.html, processed.text, url)
                addChapter(chapter); newCount++
                publishIfEnabled(chapter)
                handler.postDelayed({ phase2CrawlChapter(index + 1) }, job.delayBetweenPagesMs)
            }
        }
        val handleChapterError: (String) -> Unit = handleErr@{ reason ->
            // Bản 7.100: chương đang cào LẠI (N chương cuối) mà lỗi mạng thì giữ bản đã lưu thay vì thay bằng chương lỗi.
            val cachedOnError = if (job.incrementalUpdate) archive[url] else null
            if (cachedOnError != null) {
                addChapter(cachedOnError.copy(index = chapterNumber)); reusedCount++
                onProgress(chapters.size, chapterLinks.size, "Chương $chapterNumber lỗi ($reason) — giữ bản đã lưu trong kho")
                handler.postDelayed({ phase2CrawlChapter(index + 1) }, job.delayBetweenPagesMs)
                return@handleErr
            }
            addChapter(LeechChapter(chapterNumber, "Chương $chapterNumber [lỗi]",
                "<p>Không lấy được nội dung: $reason</p>", "[Không lấy được nội dung: $reason]", url))
            handler.postDelayed({ phase2CrawlChapter(index + 1) }, job.delayBetweenPagesMs)
        }

        fun doExtract() {
            if (job.ajaxContentMode) {
                extractChapterJsonViaAjax(url, onResult = handleChapterJson, onError = handleChapterError)
            } else {
                loadUrlAndExtract(
                    url = url, js = buildExtractChapterJs(job.chapterTitleSelector, job.chapterContentSelector, job.chapterNextPageSelector),
                    onResult = { first -> gatherChapterPages(url, first, handleChapterJson) },
                    onError = handleChapterError,
                    scrollAttempts = lazyScrollAttempts(),
                )
            }
        }

        // Bản 7.101: cuộn lazy-load nay nằm TRONG evaluateJsOnTab (sau khi trang đích tải xong, trước khi chạy script lấy nội dung). Trước đây cuộn ở đây, TRƯỚC khi mở URL
        // đích, nên cuộn nhầm vào trang của lần trước và tuỳ chọn "Trang chỉ hiện nội dung khi cuộn xuống" thực tế không có tác dụng với trang đang cào.
        doExtract()
    }

    /**
     * Đăng chương lên WordPress ngay sau khi cào xong, nếu job bật
     * `publishToWordPress` — chạy trên thread riêng (network I/O), KHÔNG
     * chặn/làm chậm luồng cào tiếp (không đợi kết quả trước khi cào chương
     * kế — lỗi đăng bài không làm hỏng job cào).
     */
    private fun publishIfEnabled(chapter: LeechChapter) {
        if (!job.publishToWordPress) return
        Thread {
            val result = WordPressPublisher.publishChapter(job, chapter, job.name)
            handler.post {
                if (result.success) {
                    publishedCount++
                    onProgress(chapters.size, chapterLinks.size, "Đã đăng \"${chapter.title}\" lên WordPress" + (result.postUrl?.let { " — $it" } ?: ""))
                } else {
                    publishErrorCount++
                    onProgress(chapters.size, chapterLinks.size, "⚠️ Đăng WordPress lỗi ở \"${chapter.title}\": ${result.error}")
                }
            }
        }.start()
    }

    private var pausedAtIndex: Int = -1

    /**
     * Gọi từ UI khi người dùng bấm "✅ Đã giải xong, tiếp tục" — thử lại
     * ĐÚNG URL đang bị chặn (tab crawl vẫn giữ nguyên trạng thái, không
     * load lại từ đầu — script kiểm tra `blocked` sẽ tự thấy trang giờ đã
     * qua được thử thách, vì người dùng vừa giải trực tiếp trên tab đó).
     */
    fun resumeAfterManualSolve() {
        if (cancelled || pausedAtIndex < 0) return
        val idx = pausedAtIndex
        pausedAtIndex = -1
        onProgress(chapters.size, chapterLinks.size, "Đang kiểm tra lại sau khi giải xác minh thủ công…")
        phase2CrawlChapter(idx)
    }

    /**
     * Gọi từ UI khi người dùng bấm "⏭ Bỏ qua chương này" — không cố giải,
     * ghi placeholder rồi cào tiếp các chương sau.
     */
    fun skipBlockedChapter() {
        if (cancelled || pausedAtIndex < 0) return
        val idx = pausedAtIndex
        pausedAtIndex = -1
        blockedChapterCount++
        val url = chapterLinks.getOrNull(idx) ?: ""
        val chapterNumber = chapters.size + 1
        addChapter(LeechChapter(chapterNumber, "Chương $chapterNumber [BỊ CHẶN - đã bỏ qua]",
            "<p>Trang bị chặn xác minh, người dùng chọn bỏ qua. URL gốc: $url</p>",
            "[Bị chặn, đã bỏ qua: $url]", url))
        onProgress(chapters.size, chapterLinks.size, "Đã bỏ qua chương bị chặn — tiếp tục")
        handler.postDelayed({ phase2CrawlChapter(idx + 1) }, job.delayBetweenPagesMs)
    }


    // -------------------------------------------------------------------------
    // Kết thúc
    // -------------------------------------------------------------------------

    private fun finishAllEntries() {
        if (cancelled) return
        // Bản 7.104: lấy thông tin truyện (tác giả, tóm tắt, bìa...) khi tab crawl còn mở, rồi mới đóng tab và xuất.
        if (!storyMetaDone) { storyMetaDone = true; collectStoryMeta { finishAllEntries() }; return }
        cleanupTab()
        // Toàn bộ phần CÀO đã xong (mọi entry, mọi chương) — checkpoint hết
        // tác dụng từ đây, kể cả nếu job đang chờ sắp xếp mục lục
        // (manualTocReview dùng ChapterCache riêng, không phải checkpoint).
        CrawlCheckpointRepository.delete(context, slotIndex, job.id)
        if (job.suggestAjaxEndpoints && ajaxEndpointsSeen.isNotEmpty()) {
            onJobUpdate(job.copy(detectedAjaxEndpoints = ajaxEndpointsSeen.toList()))
        }
        // Bản 7.100: lưu kho SAU khi cào xong mọi nguồn (trước xuất/chờ sắp xếp mục lục) — chương lỗi/bị chặn tự bị loại (isReusable).
        if (job.incrementalUpdate) {
            val snapshot = chapters.toList()
            // Bản 7.104: điểm neo quét danh sách (chỉ khi một nguồn duy nhất, không kịch bản tiền danh sách — đúng điều kiện dùng ở lần sau, xem canPlanScan).
            val anchor = if (listPageEntries.size == 1 && job.preListStages.isEmpty() && lastLinkOrder.isNotEmpty())
                ChapterArchiveRepository.ListMeta(lastLinkOrder.toList(), listScanLastPage, listScanFastStreak) else null
            Thread {
                ChapterArchiveRepository.save(context, slotIndex, job.id, snapshot)
                if (anchor != null) ChapterArchiveRepository.saveListMeta(context, slotIndex, job.id, anchor)
            }.start()
        }
        // Bản 7.101: cập nhật tăng dần mà KHÔNG có gì đổi so với lần xuất trước (cùng danh sách chương, cùng nội dung, cùng cấu hình xuất, file cũ còn) => khỏi xuất thêm
        // một file giống hệt (mỗi lần xuất tạo file mới có dấu thời gian trong tên, chạy theo lịch sẽ chất đống file trùng). onDone("") = giữ nguyên đường dẫn ebook cũ.
        if (canSkipExport()) {
            val msg = "không có chương mới (${chapters.size} chương, dùng lại $reusedCount từ kho) — giữ nguyên ebook cũ, không xuất lại"
            onRunNote("${nowStamp()} — $msg")
            onProgress(chapters.size, chapters.size, "Không có chương mới — giữ nguyên ebook cũ")
            onDone("")
            return
        }
        // Bản 7.102: ghi chú nay có cho MỌI job (không chỉ cập nhật tăng dần) và nói rõ có bao nhiêu chương mới so với lần xuất trước.
        onRunNote(ExportFollowUp.noteFor(
            ExportFollowUp.compare(context, slotIndex, job.id, chapters.toList()),
            if (job.incrementalUpdate) "mở trang $newCount chương, dùng lại $reusedCount từ kho$listScanNote" else "",
        ))
        val incNote = if (job.incrementalUpdate) " • tăng dần: dùng lại $reusedCount từ kho, cào mới $newCount$listScanNote" else ""
        val skipNote = if (skippedCount > 0) " • bỏ qua $skippedCount chương theo điều kiện" else ""
        val blockNote = if (blockedChapterCount > 0) " ($blockedChapterCount chương bị chặn xác minh, xem chi tiết trong ebook)" else ""
        val publishNote = if (job.publishToWordPress) {
            " • WordPress: $publishedCount bài đăng thành công" + (if (publishErrorCount > 0) ", $publishErrorCount lỗi" else "")
        } else ""
        if (job.manualTocReview) {
            onProgress(chapters.size, chapters.size, "Đã cào xong ${chapters.size} chương$incNote$skipNote$blockNote$publishNote. Chờ sắp xếp mục lục…")
            onReviewReady(chapters.toList())
        } else {
            onProgress(chapters.size, chapters.size, "Đã cào xong ${chapters.size} chương$incNote$skipNote$blockNote$publishNote. Đang xuất ebook…")
            phase3Export()
        }
    }

    /**
     * Bản 7.104 — lấy THÔNG TIN TRUYỆN rồi lưu vào [StoryMetaStore] (EbookExporter đọc ra khi xuất). Trang thông tin = `job.storyInfoUrl` hoặc trang danh sách chương.
     * Thứ tự ưu tiên: lần trước (lấp chỗ trống) < tự trích (selector > JSON-LD > Open Graph > meta > microdata > nhãn "Tác giả:" > h1) < người dùng nhập tay. Mọi lỗi (trang không mở được,
     * bị chặn, không tìm thấy gì) chỉ ghi chú vào tiến độ và GIỮ thông tin cũ — không bao giờ làm hỏng lần cào.
     */
    private fun collectStoryMeta(then: () -> Unit) {
        if (cancelled) return
        val tid = crawlTabId
        if (!job.storyMetaEnabled || tid == null) {
            // Tắt tự trích: vẫn áp thông tin nhập tay (nếu có) lên bản đã lưu.
            val manual = job.storyMetaManual
            if (manual != null && !manual.isBlank()) saveStoryAsync(null, "", then) else then()
            return
        }
        val url = job.storyInfoUrl.trim().ifBlank { job.listPageUrl }
        onProgress(chapters.size, chapters.size, "Đang lấy thông tin truyện (tác giả, tóm tắt, thể loại, bìa)…")
        loadUrlAndExtract(
            url = url, js = StoryMetaCollector.scriptFor(job),
            onResult = { json ->
                val fresh = try { StoryMeta.fromExtractorJson(json, System.currentTimeMillis()) } catch (e: Exception) { null }
                if (fresh == null) onProgress(chapters.size, chapters.size, "Thông tin truyện: kết quả không đọc được — giữ thông tin cũ")
                saveStoryAsync(fresh, url, then)
            },
            onError = { reason ->
                onProgress(chapters.size, chapters.size, "Không lấy được thông tin truyện ($reason) — giữ thông tin cũ")
                saveStoryAsync(null, url, then)
            },
        )
    }

    /** Gộp + tải bìa + ghi đĩa trên luồng nền (tải ảnh qua mạng không được chạy trên luồng chính), rồi chạy [then] trên luồng chính. */
    private fun saveStoryAsync(fresh: StoryMeta?, pageUrl: String, then: () -> Unit) {
        Thread {
            var note: String? = null
            try {
                val prev = StoryMetaStore.load(context, job.id)
                val merged = StoryMeta.merge(prev?.meta, fresh, job.storyMetaManual)
                var coverBytes: ByteArray? = null
                var coverMime = prev?.meta?.coverMime.orEmpty()
                val needCover = merged.coverUrl.isNotBlank() && (prev?.cover == null || prev.meta.coverUrl != merged.coverUrl)
                if (needCover) {
                    val got = ImageDownloader.downloadCover(merged.coverUrl, job.customUserAgent, pageUrl.ifBlank { job.listPageUrl })
                    if (got != null) { coverBytes = got.first; coverMime = got.second } else note = "không tải được ảnh bìa (${merged.coverUrl.take(80)})"
                }
                if (!merged.isBlank() || merged.coverUrl.isNotBlank()) {
                    if (StoryMetaStore.save(context, job.id, merged, coverBytes, coverMime)) storyChanged = true
                    val got = listOfNotNull(
                        merged.author.takeIf { it.isNotBlank() }?.let { "tác giả" }, merged.summary.takeIf { it.isNotBlank() }?.let { "tóm tắt" },
                        merged.genres.takeIf { it.isNotEmpty() }?.let { "thể loại" }, merged.status.takeIf { it.isNotBlank() }?.let { "tình trạng" },
                        merged.rating?.let { "đánh giá" }, (if (coverBytes != null || prev?.cover != null) "bìa" else null),
                    )
                    note = "thông tin truyện: ${if (got.isEmpty()) "(không có gì mới)" else got.joinToString(", ")}" + (if (note != null) " — $note" else "")
                } else if (fresh != null) {
                    note = "trang không có thông tin truyện nhận ra được — có thể khai selector trong mục \"Thông tin truyện\""
                }
            } catch (e: Exception) {
                note = "lỗi lưu thông tin truyện: ${e.message} — bỏ qua"
            }
            val finalNote = note
            handler.post {
                if (cancelled) return@post
                if (finalNote != null) onProgress(chapters.size, chapters.size, finalNote)
                then()
            }
        }.start()
    }

    private fun finish(error: String) {
        cleanupTab()
        onError(error)
    }

    private fun nowStamp(): String = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.US).format(java.util.Date())

    /** Chữ ký cấu hình xuất: đổi định dạng/tên file/số mục lục thủ công => khác chữ ký => vẫn phải xuất lại dù không có chương mới. */
    private fun exportSignature(): String = ExportFollowUp.signatureOf(job)

    private fun outputStillExists(path: String): Boolean = ExportFollowUp.outputStillExists(context, path)

    /** Danh sách chương lần này GIỐNG HỆT kho (cùng thứ tự URL, cùng tiêu đề, cùng HTML). */
    private fun identicalToArchive(): Boolean {
        if (archive.isEmpty() || chapters.size != archive.size) return false
        val old = archive.values.toList()
        for (i in chapters.indices) {
            val a = old[i]; val c = chapters[i]
            if (a.sourceUrl != c.sourceUrl || a.title != c.title || a.htmlContent != c.htmlContent) return false
        }
        return true
    }

    private fun canSkipExport(): Boolean =
        job.incrementalUpdate && !job.manualTocReview && !storyChanged && outputStillExists(job.outputFilePath) &&
            ChapterArchiveRepository.loadExportSignature(context, slotIndex, job.id) == exportSignature() &&
            identicalToArchive()

    private fun phase3Export() {
        Thread {
            try {
                val snapshot = chapters.toList()
                val delta = ExportFollowUp.compare(context, slotIndex, job.id, snapshot)  // so với lần xuất TRƯỚC, phải đọc trước khi ghi mốc mới
                val path = EbookExporter.export(context, job, snapshot)
                ExportFollowUp.afterExport(context, slotIndex, job, snapshot)  // ghi mốc lần xuất này (+ chữ ký cấu hình xuất khi bật cập nhật tăng dần)
                handler.post {
                    onDone(path)
                    if (job.notifyNewChapters && delta.hadBaseline && delta.newCount > 0) onNewChapters(delta.newCount, delta.total)
                }
            } catch (e: Exception) {
                handler.post { onError("Xuất ebook thất bại: ${e.message}") }
            }
        }.start()
    }

    /**
     * ĐÃ THÊM — "AJAX Leech thật": `url` (lấy từ `chapterLinks`, có thể do
     * `phase1CollectLinksAjax()` tạo ra HOẶC do người dùng tự nhập link
     * API trực tiếp) được coi là 1 endpoint JSON THẬT — điều hướng tab
     * crawl thẳng tới URL đó (giữ nguyên cookie/session của tab, khác gọi
     * `fetch()` từ 1 origin khác dễ dính CORS), đọc `document.body.innerText`
     * (chính là JSON thô server trả về khi trình duyệt hiển thị 1 URL JSON
     * trần), parse theo path cấu hình trong job.
     *
     * KHÁC "AJAX sniff" cũ (`job.suggestAjaxEndpoints`) — cái đó chỉ DÒ &
     * GỢI Ý url để người dùng tự nhìn, không tự dùng làm nguồn dữ liệu. Cái
     * này DÙNG THẲNG JSON làm nguồn — đúng nghĩa "leech qua AJAX".
     */
    private fun extractChapterJsonViaAjax(url: String, onResult: (JSONObject) -> Unit, onError: (String) -> Unit) {
        val tid = crawlTabId
        if (tid == null) { onError("Tab crawl đã bị đóng"); return }
        engine.evaluateJsOnTab(
            crawlTabId = tid, url = url,
            js = "(function(){ return document.body ? document.body.innerText : (document.documentElement ? document.documentElement.innerText : ''); })();",
            timeoutMs = 15_000L,
            onResult = { raw ->
                try {
                    val root = org.json.JSONTokener(raw).nextValue()
                    val title = JsonPathExtractor.resolveString(root, job.ajaxContentTitleField)
                        ?.trim().takeUnless { it.isNullOrEmpty() }
                    val contentRaw = JsonPathExtractor.resolveString(root, job.ajaxContentField).orEmpty()
                    if (contentRaw.isEmpty()) {
                        onError("Không tìm thấy nội dung tại path \"${job.ajaxContentField}\" trong JSON trả về")
                        return@evaluateJsOnTab
                    }
                    // Nội dung từ JSON API có thể là HTML thô (site render
                    // sẵn) hoặc text thuần (site trả markdown/plain) — KHÔNG
                    // đoán được trước, nên dùng CHUNG 1 giá trị cho cả
                    // html/text; ContentProcessor + EbookExporter phía sau
                    // vẫn xử lý bình thường (EPUB/HTML output dùng field
                    // html, TXT dùng field text — nếu content thật ra là
                    // text thuần thì bản EPUB/HTML sẽ không có thẻ định
                    // dạng, vẫn đọc được, không hỏng).
                    onResult(JSONObject().apply {
                        put("title", title ?: "")
                        put("html", contentRaw)
                        put("text", stripHtmlTagsRoughly(contentRaw))
                    })
                } catch (e: Exception) {
                    onError("AJAX content — JSON không hợp lệ tại $url: ${e.message}")
                }
            },
            onError = onError,
        )
    }

    /** Bóc thẻ HTML thô để có bản text thuần dùng cho xuất TXT — KHÔNG
     * phải parser HTML đầy đủ (không cần, chỉ cần đọc được, không cần đẹp
     * tuyệt đối) — dùng khi nội dung AJAX là HTML nhưng job xuất định dạng
     * TXT (`buildExtractChapterJs` bản HTML có browser thật làm việc này
     * qua `.innerText`; nhánh AJAX không có DOM để nhờ, phải tự làm). */
    private fun stripHtmlTagsRoughly(html: String): String =
        html.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private fun extractLinks(json: JSONObject): List<String> {
        val arr = json.optJSONArray("links") ?: return emptyList()
        return (0 until arr.length()).map { arr.getString(it).trim() }.filter { it.isNotEmpty() }
    }

    private fun collectAjaxFrom(json: JSONObject) {
        if (!job.suggestAjaxEndpoints) return
        val arr = json.optJSONArray("ajaxEndpoints") ?: return
        for (i in 0 until arr.length()) {
            ajaxEndpointsSeen.add(arr.getString(i))
            if (ajaxEndpointsSeen.size >= 40) break
        }
    }

    private fun loadUrlAndExtract(
        url: String, js: String, onResult: (JSONObject) -> Unit, onError: (String) -> Unit,
        installAjaxPatchFirst: Boolean = false,
        scrollAttempts: Int = 0,
    ) {
        val tid = crawlTabId
        if (tid == null) { onError("Tab crawl đã bị đóng"); return }
        engine.evaluateJsOnTab(
            crawlTabId = tid, url = url, js = js, timeoutMs = 15_000L + scrollAttempts * 2_000L,   // mỗi lần cuộn tốn ~0,7s + độ trễ eval
            installAjaxPatchFirst = installAjaxPatchFirst, scrollAttempts = scrollAttempts,
            onResult = { raw ->
                try { onResult(JSONObject(raw)) } catch (e: Exception) { onError("JSON parse lỗi: ${e.message} (raw: ${raw.take(200)})") }
            },
            onError = onError
        )
    }

    private fun buildCollectLinksJs(selector: String, attr: String): String =
        collectLinksJs(selector, attr, job.suggestAjaxEndpoints)

    /**
     * Bản 7.100 — chương chia nhiều trang (KDN: "post pagination"). Có `job.chapterNextPageSelector` thì sau khi lấy trang 1, lần lượt mở link "trang kế" và NỐI nội dung
     * vào cùng một chương (tiêu đề lấy ở trang 1). Dừng khi: không còn link / đủ `job.maxChapterPages` / link đã đi qua (vòng lặp) / link là một CHƯƠNG khác trong danh sách
     * (nhiều site dùng chung nút "Tiếp" cho cả trang kế lẫn chương kế — nếu không chặn sẽ nuốt cả truyện vào một chương). Trang ≥2 bị chặn xác minh => trả về kết quả "blocked"
     * để luồng chờ giải tay như cũ; trang ≥2 lỗi mạng => giữ phần đã lấy và ghi chú rõ trong nội dung (không bỏ cả chương).
     */
    private fun gatherChapterPages(firstUrl: String, first: JSONObject, onComplete: (JSONObject) -> Unit) {
        if (job.chapterNextPageSelector.isBlank() || job.ajaxContentMode || first.optBoolean("blocked", false)) { onComplete(first); return }
        val html = StringBuilder(first.optString("html", ""))
        val text = StringBuilder(first.optString("text", ""))
        val title = first.optString("title", "")
        val visited = hashSetOf(firstUrl)
        fun complete() {
            onComplete(JSONObject().apply { put("title", title); put("html", html.toString()); put("text", text.toString()) })
        }
        fun step(cur: JSONObject, pageNo: Int) {
            if (cancelled) return
            val next = cur.optString("next", "")
            val isOtherChapter = next.isNotBlank() && next != firstUrl && chapterLinks.contains(next)
            if (next.isBlank() || pageNo >= job.maxChapterPages || isOtherChapter || !visited.add(next)) { complete(); return }
            onProgress(chapters.size, chapterLinks.size, "  …trang ${pageNo + 1} của chương hiện tại")
            handler.postDelayed({
                loadUrlAndExtract(
                    url = next, js = buildExtractChapterJs(job.chapterTitleSelector, job.chapterContentSelector, job.chapterNextPageSelector),
                    onResult = { nxt ->
                        if (nxt.optBoolean("blocked", false)) { onComplete(nxt); return@loadUrlAndExtract }
                        html.append("\n").append(nxt.optString("html", ""))
                        text.append("\n\n").append(nxt.optString("text", ""))
                        step(nxt, pageNo + 1)
                    },
                    onError = { reason ->
                        val note = "[Không lấy được trang ${pageNo + 1} của chương: $reason]"
                        html.append("\n<p>").append(note).append("</p>"); text.append("\n\n").append(note)
                        complete()
                    },
                    scrollAttempts = lazyScrollAttempts(),
                )
            }, job.delayBetweenPagesMs)
        }
        step(first, 1)
    }

    /** Số lần cuộn lazy-load cho một trang chương (0 = job không bật "Trang chỉ hiện nội dung khi cuộn xuống"). */
    private fun lazyScrollAttempts(): Int = if (job.simulateScrollForLazyLoad) job.maxScrollAttempts.coerceIn(1, 20) else 0

    private fun buildExtractChapterJs(titleSelector: String, contentSelector: String, nextPageSelector: String = ""): String =
        extractChapterJs(titleSelector, contentSelector, nextPageSelector)

    /**
     * Bản 7.100: hai hàm dựng script nằm trong companion (không cần job/instance) để [SelectorTester] dùng CHUNG đúng script mà crawler dùng — thử selector
     * bằng script khác với lúc cào thật thì kết quả thử chẳng chứng minh được gì.
     */
    companion object {
    /** Lý do bỏ qua chương (null = giữ). Cụm cấm kiểm trên text THÔ site trả (trước luật tìm & thay, vì luật có thể xoá đúng cụm đó); độ dài kiểm SAU luật. Dùng chung với [SelectorTester]. */
    fun skipReason(job: LeechJob, rawText: String, processedText: String): String? {
        val low = rawText.lowercase()
        for (ph in job.skipIfTextContains) {
            val p = ph.trim()
            if (p.isNotEmpty() && low.contains(p.lowercase())) return "chứa cụm \"$p\""
        }
        val len = processedText.trim().length
        if (job.minTextLength > 0 && len < job.minTextLength) return "nội dung quá ngắn ($len < ${job.minTextLength} ký tự)"
        return null
    }

    fun collectLinksJs(selector: String, attr: String, ajaxLog: Boolean = false): String {
        val safeSelector = selector.replace("'", "\\'")
        val safeAttr = attr.replace("'", "\\'")
        val ajaxPart = if (ajaxLog)
            "obj.ajaxEndpoints = (window.__ebookLeechAjaxLog || []).map(function(e){ return e.url; });"
        else ""
        return """
            (function() {
                var links = [];
                var elems = document.querySelectorAll('$safeSelector');
                elems.forEach(function(el) {
                    var val = el.getAttribute('$safeAttr') || el.href || '';
                    if (val) {
                        try { val = new URL(val, document.baseURI).href; } catch(e){}
                        links.push(val);
                    }
                });
                var obj = { links: links };
                $ajaxPart
                return JSON.stringify(obj);
            })();
        """.trimIndent()
    }

    fun extractChapterJs(titleSelector: String, contentSelector: String, nextPageSelector: String = ""): String {
        val safeTitle = titleSelector.replace("'", "\\'")
        val safeContent = contentSelector.replace("'", "\\'")
        // Selector "trang kế": dùng JSONObject.quote để ra literal JS đúng (kể cả dấu \ và " trong selector), khác hai selector cũ chỉ escape dấu '.
        val nextJs = if (nextPageSelector.isBlank()) "" else """
                var next = '';
                try {
                    var nel = document.querySelector(${JSONObject.quote(nextPageSelector)});
                    if (nel) {
                        var nv = nel.getAttribute('href') || nel.href || '';
                        if (nv) next = new URL(nv, document.baseURI).href;
                    }
                } catch (e) {}
        """
        val returnJs = if (nextPageSelector.isBlank()) "return JSON.stringify({ title: title, html: html, text: text, tm: !!titleEl, cm: !!contentEl });"
                       else "return JSON.stringify({ title: title, html: html, text: text, next: next, tm: !!titleEl, cm: !!contentEl });"
        return """
            (function() {
                // Phát hiện trang chặn xác minh (Cloudflare/captcha) — KHÔNG
                // tự giải được, chỉ nhận diện để báo cáo thay vì âm thầm cào
                // ra rác (title/nội dung rỗng, hoặc chính trang thử thách).
                // Vì GeckoView chạy JS thật (khác HTTP scraper tĩnh), phần
                // lớn thử thách "kiểm tra trình duyệt" tự động qua được —
                // đoạn này chỉ bắt phần CÒN LẠI cần con người (CAPTCHA ảnh,
                // Turnstile tương tác...).
                var titleLower = (document.title || '').toLowerCase();
                var bodyText = (document.body ? document.body.innerText : '').toLowerCase();
                var blockMarkers = [
                    'checking your browser', 'just a moment', 'attention required',
                    'verify you are human', 'xác minh bạn là người', 'cloudflare',
                    'ddos protection by', 'please wait while we verify'
                ];
                var challengeSelectors = ['#challenge-form', '#cf-challenge-running', '.cf-turnstile', 'iframe[src*="turnstile"]'];
                var isBlocked = false;
                var blockReason = '';
                for (var i = 0; i < blockMarkers.length; i++) {
                    if (titleLower.indexOf(blockMarkers[i]) !== -1 || bodyText.indexOf(blockMarkers[i]) !== -1) {
                        isBlocked = true; blockReason = 'title/nội dung khớp "' + blockMarkers[i] + '"'; break;
                    }
                }
                if (!isBlocked) {
                    for (var j = 0; j < challengeSelectors.length; j++) {
                        try {
                            if (document.querySelector(challengeSelectors[j])) {
                                isBlocked = true; blockReason = 'phát hiện phần tử ' + challengeSelectors[j]; break;
                            }
                        } catch (e) {}
                    }
                }
                if (isBlocked) {
                    return JSON.stringify({ blocked: true, blockReason: blockReason });
                }

                var titleEl = document.querySelector('$safeTitle');
                var contentEl = document.querySelector('$safeContent');
                var title = titleEl ? titleEl.innerText.trim() : document.title;
                var html = contentEl ? contentEl.innerHTML : '';
                var text = contentEl ? contentEl.innerText.trim() : document.body.innerText.trim();
                html = html.replace(/<script[\s\S]*?<\/script>/gi, '')
                           .replace(/<style[\s\S]*?<\/style>/gi, '');
                $nextJs
                $returnJs
            })();
        """.trimIndent()
    }
    }
}
