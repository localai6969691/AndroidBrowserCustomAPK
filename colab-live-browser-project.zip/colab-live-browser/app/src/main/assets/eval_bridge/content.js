// Cau noi 1 chieu -> 2 chieu: native (Kotlin) -> content script -> eval trong
// trang -> GUI KET QUA THAT (hoac loi that) VE LAI qua port.postMessage().
// TRUOC DAY: loi bi NUOT AM THAM (catch rong), khong bao gio bao ve Kotlin -
// nghia la port connect duoc KHONG co nghia la script chay dung, chi la co
// ket noi thoi. Sua de biet chac chan.
//
// BUG NGHIEM TRONG DA SUA (phat hien khi doi chieu truc tiep code Kotlin):
// Kotlin gui field "type": "eval" nhung ban JS truoc day kiem tra sai ten
// field - dieu kien if KHONG BAO GIO dung, script CHUA TUNG duoc thuc thi
// qua cau noi nay tu truoc den gio (ke ca keepPlayingScript chong YouTube
// tu pause). Sua dung "msg.type". Them echo lai "requestId" trong ket qua
// tra ve - phia Kotlin gio dung nhieu callback dong thoi (khac 1 bien
// callback dung chung truoc day, de bi ghi de mat nhau khi co nhieu lenh
// goi evaluateJs() gan nhau).
(function () {
  // BUG THẬT (xác nhận qua đối chiếu trực tiếp manifest.json +
  // GeckoViewEngine.kt::evaluateJsForTab — không phải đoán): manifest.json
  // khai "all_frames": true, nghĩa là content script này chạy trong MỌI
  // iframe của trang, không chỉ frame chính. Ở phía Kotlin,
  // `evaluateJsForTab()` gửi lệnh eval tới TẤT CẢ port khớp `tabId` —
  // `portTabId[port] == targetTabId` — nhưng port của MỌI iframe trong
  // cùng 1 tab đều được gán CHUNG 1 tabId (tabId gắn theo session/tab,
  // không phân biệt theo frame). Kết quả: khi 1 tab có iframe (quảng cáo,
  // nhúng cross-origin...), MỌI frame (kể cả iframe) đều nhận lệnh eval và
  // có thể trả lời — vì `evalCallbacks` chỉ giữ 1 callback theo requestId,
  // AI TRẢ LỜI TRƯỚC sẽ thắng (race condition). Với favicon cụ thể: script
  // fetchFavicon tìm <link rel="icon">, nếu không có sẽ fallback về
  // `location.origin + '/favicon.ico'` — nếu 1 iframe cross-origin trả lời
  // trước frame chính, favicon hiện ra là của domain HOÀN TOÀN KHÁC (vd
  // iframe quảng cáo), không phải trang người dùng đang xem — đúng khớp
  // triệu chứng "favicon không đúng như trên trang web".
  //
  // Sửa: chỉ frame TRÊN CÙNG (window === window.top) mới connect port và
  // xử lý lệnh eval chung (favicon, zoom, video diagnostic, outerHTML...).
  // Các tính năng hiện có (keepPlayingScript chống YouTube tự pause, v.v.)
  // đều nhắm vào trang top-level (youtube.com chạy ở frame chính, không
  // phải iframe), nên giới hạn này an toàn với toàn bộ tính năng đang có.
  // Nếu SAU NÀY có tính năng thật sự cần eval bên trong iframe cụ thể, cần
  // thiết kế kênh riêng có định danh frame rõ ràng — không dùng lại cầu
  // nối chung này để tránh lặp lại đúng bug này.
  if (window !== window.top) {
    return;
  }

  // BUG COLAB CÒN LẠI (log thật 17:04-17:05, bản 6.7): bản vá xuyên shadow
  // DOM ở mục 91 ĐÃ CHẠY ĐÚNG khi ô soạn thảo đang giữ focus —
  // `activeEl(xuyên shadow)=TEXTAREA.inputarea` cho ra `handled-by-page`
  // (Monaco xử lý paste). NHƯNG 4/6 lần bấm "Dán" cho ra
  // `activeEl(xuyên shadow)=UL.actions-container` — đó là danh sách của
  // MENU CHUỘT PHẢI của chính Monaco: nhấn giữ trong ô code làm Monaco mở
  // menu riêng và menu này cướp focus khỏi ô soạn thảo, nên lệnh Dán của
  // app bắn vào danh sách menu (không có handler paste) và không có gì
  // xảy ra. Cách chữa không phải đoán thêm: ghi nhớ ô soạn thảo được focus
  // GẦN NHẤT ngay lúc nó nhận focus (trước khi menu kịp cướp), để lệnh Dán
  // dùng lại đúng ô đó. `focusin` là sự kiện composed nên đi xuyên shadow
  // DOM; `composedPath()[0]` là phần tử thật bên trong shadow root. Lệnh
  // eval chạy bằng `new Function` TRONG CÙNG sandbox content script này
  // nên `window.__lbLastEditable` đọc được ở mọi lệnh evaluateJs sau đó.
  // ===== Lớp chọn văn bản cho Monaco (mục 100) =====
  // Tra cứu (microsoft/monaco-editor #246, #1504, #4622, #4860): Monaco KHÔNG có núm chọn cảm ứng
  // trên bất kỳ trình duyệt nào, kể cả Chrome Android; vùng chọn do Monaco tự vẽ bằng các <div>
  // class "selected-text", không phải Selection API. Nên app tự làm: chọn từ bằng cú nhấp đúp giả,
  // đọc hình chữ nhật từ .selected-text để đặt núm, kéo núm = nhấp đặt điểm cố định + shift+nhấp.
  try {
    var LB = window.__lbMon = {};
    var lbVV = function () {
      var v = window.visualViewport;
      return v ? { ox: v.offsetLeft, oy: v.offsetTop, w: v.width, h: v.height }
               : { ox: 0, oy: 0, w: window.innerWidth, h: window.innerHeight };
    };
    var lbCss = function (fx, fy) { var v = lbVV(); return { x: v.ox + fx * v.w, y: v.oy + fy * v.h }; };
    var lbFrac = function (x, y) { var v = lbVV(); return { x: (x - v.ox) / v.w, y: (y - v.oy) / v.h }; };
    var lbDeepAll = function (sel, root, out) {
      out = out || []; root = root || document;
      try { var f = root.querySelectorAll(sel); for (var i = 0; i < f.length; i++) out.push(f[i]); } catch (e) {}
      var all = root.querySelectorAll("*");
      for (var j = 0; j < all.length; j++) { if (all[j].shadowRoot) lbDeepAll(sel, all[j].shadowRoot, out); }
      return out;
    };
    var lbDeepPoint = function (x, y) {
      var el = document.elementFromPoint(x, y);
      while (el && el.shadowRoot) {
        var inner = el.shadowRoot.elementFromPoint(x, y);
        if (!inner || inner === el) break;
        el = inner;
      }
      return el;
    };
    var lbEditorOf = function (n) {
      while (n) {
        if (n.classList && n.classList.contains("monaco-editor")) return n;
        n = n.parentNode || n.host;
      }
      return null;
    };
    var lbFire = function (kind, x, y, o) {
      o = o || {};
      var t = lbDeepPoint(x, y) || document.body;
      var base = { bubbles: true, cancelable: true, composed: true, view: window,
        clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: o.buttons || 0,
        detail: o.detail || 1, shiftKey: !!o.shift };
      var pInit = {}; for (var k in base) pInit[k] = base[k];
      pInit.pointerId = 1; pInit.pointerType = "mouse"; pInit.isPrimary = true;
      pInit.width = 1; pInit.height = 1; pInit.pressure = o.buttons ? 0.5 : 0;
      try { t.dispatchEvent(new PointerEvent("pointer" + kind, pInit)); } catch (e) {}
      t.dispatchEvent(new MouseEvent("mouse" + kind, base));
      return t;
    };
    var lbClick = function (x, y, detail, shift) {
      lbFire("down", x, y, { buttons: 1, detail: detail, shift: shift });
      lbFire("up", x, y, { buttons: 0, detail: detail, shift: shift });
    };
    LB.isAt = function (fx, fy) {
      var c = lbCss(fx, fy);
      return !!lbEditorOf(lbDeepPoint(c.x, c.y));
    };
    LB.rects = function () {
      var active = document.activeElement;
      while (active && active.shadowRoot && active.shadowRoot.activeElement) active = active.shadowRoot.activeElement;
      var ed = lbEditorOf(active) || lbEditorOf(window.__lbLastEditable);
      var els = lbDeepAll(".selected-text"), rs = [];
      for (var i = 0; i < els.length; i++) {
        if (ed && lbEditorOf(els[i]) !== ed) continue;
        var r = els[i].getBoundingClientRect();
        if (r.width > 0.5 && r.height > 2) rs.push(r);
      }
      if (!rs.length) return JSON.stringify({ n: 0 });
      rs.sort(function (a, b) { return a.top - b.top || a.left - b.left; });
      var a = rs[0], z = rs[rs.length - 1];
      var s = lbFrac(a.left + 0.5, a.top + a.height / 2), sb = lbFrac(a.left, a.bottom);
      var e = lbFrac(z.right - 0.5, z.top + z.height / 2), eb = lbFrac(z.right, z.bottom);
      var tp = lbFrac(a.left, a.top);
      return JSON.stringify({ n: rs.length, sx: s.x, sy: s.y, sbx: sb.x, sby: sb.y,
        ex: e.x, ey: e.y, ebx: eb.x, eby: eb.y, tx: tp.x, ty: tp.y });
    };
    // Điểm nhấn có nằm trong vùng đang chọn không (nhấn giữ lên vùng đã chọn => giữ nguyên, không chọn lại từ)
    LB.hitSelection = function (fx, fy) {
      var c = lbCss(fx, fy), els = lbDeepAll(".selected-text");
      for (var i = 0; i < els.length; i++) {
        var r = els[i].getBoundingClientRect();
        if (r.width > 0.5 && c.x >= r.left - 8 && c.x <= r.right + 8 && c.y >= r.top - 4 && c.y <= r.bottom + 4) return true;
      }
      return false;
    };
    LB.wordAt = function (fx, fy) {
      var c = lbCss(fx, fy);
      lbClick(c.x, c.y, 1, false);
      lbClick(c.x, c.y, 2, false);
      return "wordAt@" + Math.round(c.x) + "," + Math.round(c.y);
    };
    LB.place = function (fx, fy) { var c = lbCss(fx, fy); lbClick(c.x, c.y, 1, false); return "place"; };
    LB.extend = function (fx, fy) { var c = lbCss(fx, fy); lbClick(c.x, c.y, 1, true); return "extend"; };
    // Đóng menu chuột phải riêng của Monaco (nhấn giữ làm nó mở và cướp focus) rồi trả focus về ô soạn thảo.
    LB.refocus = function () {
      try {
        var a = document.activeElement;
        while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
        if (a && !(a.tagName === "TEXTAREA" || a.isContentEditable || a.tagName === "INPUT")) {
          var ev = { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true, composed: true };
          a.dispatchEvent(new KeyboardEvent("keydown", ev));
          a.dispatchEvent(new KeyboardEvent("keyup", ev));
        }
        var last = window.__lbLastEditable;
        if (last && last.isConnected) { last.focus(); return "refocused"; }
        return "no-last-editable";
      } catch (e) { return "ERR:" + e.message; }
    };
  } catch (e) { /* không được làm hỏng phần còn lại của content script */ }

  // Ghi nhận MỌI sự kiện paste (capture) để app kiểm chứng dán native có thật sự tới trang (mục 99).
  try {
    document.addEventListener("paste", function (ev) {
      try { window.__lbLastPaste = { t: Date.now(), trusted: ev.isTrusted === true }; } catch (e) {}
    }, true);
  } catch (e) { /* không được làm hỏng phần còn lại */ }

  try {
    var __lbIsEditable = function (el) {
      if (!el || !el.tagName) return false;
      if (el.isContentEditable) return true;
      if (el.tagName === "TEXTAREA") return true;
      if (el.tagName === "INPUT") {
        var t = (el.type || "text").toLowerCase();
        return t === "text" || t === "search" || t === "url" || t === "tel" ||
               t === "email" || t === "password" || t === "number";
      }
      return false;
    };
    document.addEventListener("focusin", function (ev) {
      try {
        var path = ev.composedPath ? ev.composedPath() : [];
        var t = path.length ? path[0] : ev.target;
        if (__lbIsEditable(t)) window.__lbLastEditable = t;
      } catch (e) { /* bỏ qua — chỉ là gợi ý phục hồi focus */ }
    }, true);
  } catch (e) { /* không được làm hỏng phần còn lại của content script */ }

  /**
   * TÍNH NĂNG MỚI — giải quyết đúng gốc vấn đề "tên file tải về sai"
   * (khác với patch cũ đã bị chỉ ra là hardcode theo URL claude.ai và đã bỏ).
   *
   * ĐÃ TRA CỨU THỰC TẾ Chrome/Firefox làm gì (không đoán): theo đúng chuẩn
   * WHATWG + xác nhận qua nhiều nguồn (MDN, thảo luận whatwg-archive, so
   * sánh hành vi Chromium/Firefox) — trình duyệt lấy tên file tải về từ 2
   * NGUỒN, không chỉ 1:
   *   1) Header `Content-Disposition` của server (nếu có filename)
   *   2) Thuộc tính `download` trên thẻ <a> — CHỈ áp dụng cho URL cùng
   *      origin, hoặc blob:/data: — do CHÍNH TRANG WEB đặt ngay tại thời
   *      điểm tạo link tải, KHÔNG liên quan gì tới response HTTP.
   * Nếu header có filename, header thắng; nếu header thiếu hoặc là
   * "inline" không kèm filename, thuộc tính `download` được dùng.
   *
   * Quan trọng hơn: đã tra thấy CHÍNH THỨC 1 bug đã xác nhận của Mozilla
   * (bugzilla #1666013) rằng `ContentDelegate#onExternalResponse(GeckoSession,
   * WebResponse)` — API mà `GeckoViewEngine.kt` đang dùng — KHÔNG truyền
   * được fileName/Content-Disposition cho tải qua blob: URL, ví dụ minh
   * họa chính là app mẫu CHÍNH THỨC của Mozilla khi tải từ squoosh.app ra
   * tên "GVDownload" — y hệt lớp lỗi "download-file.bin" gặp phải, và đây
   * là giới hạn kiến trúc ĐÃ BIẾT của GeckoView, không phải lỗi riêng của
   * code này. Tức là nguồn (1) — Content-Disposition — có thể KHÔNG BAO
   * GIỜ tới được tầng Kotlin cho một số kiểu tải nhất định, bất kể parse
   * đúng cỡ nào — PHẢI có nguồn (2) bổ sung thì mới đúng như trình duyệt
   * thật, đây là lý do content script (có quyền truy cập DOM ngay lúc
   * click) phải tham gia, không thể giải quyết chỉ ở tầng Kotlin.
   *
   * Cách bắt: lắng nghe 'click' pha capture trên document (bắt được thẻ
   * <a download> có trong DOM), ĐỒNG THỜI ghi đè (monkey-patch)
   * HTMLAnchorElement.prototype.click — vì mẫu code JS rất phổ biến để
   * "xuất file" (nhiều khả năng đúng cách Claude.ai dùng) là tạo thẻ <a>
   * KHÔNG gắn vào DOM (`document.createElement('a')`) rồi gọi thẳng
   * `a.click()` — click() trên phần tử chưa gắn vào cây DOM không lan
   * truyền (bubble) tới document, listener thường sẽ KHÔNG bắt được, chỉ
   * có cách ghi đè thẳng hàm click() mới chắc chắn bắt được.
   *
   * Gửi kết quả bắt được qua port.postMessage() dạng "download_hint" —
   * KHÔNG cần requestId vì đây là báo TỰ NGUYỆN, không phải trả lời cho
   * lệnh eval nào. Kotlin lưu tạm (có hạn dùng ngắn) để đối chiếu khi
   * onExternalResponse tới, xem `downloadFilenameHints` trong
   * GeckoViewEngine.kt.
   *
   * GIỚI HẠN THẬT (không giấu): chỉ khớp khi Kotlin nhận được đúng URL y
   * hệt href đã bắt (không xử lý redirect đổi URL). Nếu trang dùng
   * framework che giấu hàm click() gốc theo cách khác (hiếm), sẽ bỏ lỡ —
   * lúc đó vẫn fallback về Content-Disposition/URLUtil như cũ, không tệ đi
   * so với trước.
   */
  try {
    var __lastConnectedPort = null;

    function resolveAbsoluteUrl(maybeRelative) {
      try {
        return new URL(maybeRelative, document.baseURI).href;
      } catch (e) {
        return maybeRelative;
      }
    }

    function reportDownloadHint(anchor) {
      try {
        if (!anchor || !anchor.href) return;
        var name = anchor.getAttribute("download");
        if (!name) return; // download="" (rỗng) nghĩa là "dùng tên mặc định
        // của server/URL" theo chuẩn — KHÔNG phải 1 tên hợp lệ, bỏ qua.
        var absoluteHref = resolveAbsoluteUrl(anchor.href);
        if (__lastConnectedPort) {
          __lastConnectedPort.postMessage({
            type: "download_hint",
            href: absoluteHref,
            filename: name
          });
        }
      } catch (e) {
        // Bỏ qua an toàn — không được để lỗi ở đây làm hỏng luồng click
        // thật của trang.
      }
    }

    document.addEventListener(
      "click",
      function (ev) {
        var el = ev.target;
        // Thẻ <a download> có thể lồng bên trong (vd <a download><span>Tải
        // xuống</span></a>, click trúng <span>) — closest() tìm ngược lên
        // ancestor gần nhất.
        var anchor = el && el.closest ? el.closest("a[download]") : null;
        if (anchor) reportDownloadHint(anchor);
      },
      true
    );

    if (window.HTMLAnchorElement && HTMLAnchorElement.prototype.click) {
      var __originalAnchorClick = HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click = function () {
        try {
          reportDownloadHint(this);
        } catch (e) {}
        return __originalAnchorClick.apply(this, arguments);
      };
    }
  } catch (e) {
    // Trang chặn ghi đè prototype (hiếm, CSP nghiêm ngặt...) — bỏ qua an
    // toàn, không ảnh hưởng các tính năng khác của content.js.
  }

  try {
    var port = browser.runtime.connectNative("browser");
    __lastConnectedPort = port;
    port.onMessage.addListener(function (msg) {
      if (msg && msg.type === "eval" && typeof msg.script === "string") {
        try {
          // FIX: new Function(script)() chỉ trả về giá trị nếu script có
          // "return" ở cấp cao nhất. Script dạng (function(){...return x;})()
          // là expression-statement — kết quả IIFE tính ra nhưng không được
          // return ra ngoài new Function() → value luôn undefined → log "OK".
          // Sửa: bọc "return <expr>" — nhưng phải trim dấu ";" trailing
          // trước (script Kotlin thường kết thúc bằng ";") để tránh lỗi
          // cú pháp "return (expr;)" không hợp lệ.
          var trimmed = msg.script.trim().replace(/;+$/, "");
          var value = (new Function("return (" + trimmed + ")"))();
          port.postMessage({
            result: "OK" + (value !== undefined ? (": " + String(value)) : ""),
            requestId: msg.requestId,
            // BUG THẬT tìm được (người dùng chỉ đúng — ảnh chụp cho thấy
            // tab "New chat" của claude.ai hiện icon YouTube, không phải
            // icon của chính claude.ai): khi Kotlin không tìm thấy port
            // nào khớp đúng tabId (log "CHẨN ĐOÁN evaluateJs fallback...
            // broadcast toàn bộ" — xác nhận xảy ra RẤT THƯỜNG XUYÊN qua
            // log thật gửi kèm, không phải hiếm), lệnh eval bị BROADCAST
            // tới MỌI tab đang mở, không chỉ tab đích. Tab NÀO trả lời
            // TRƯỚC sẽ thắng (evalCallbacks chỉ giữ 1 callback theo
            // requestId) — nếu 1 tab KHÁC (vd tab YouTube đang mở nền) trả
            // lời trước tab đích (vd tab Claude.ai mới), kết quả (favicon
            // của YouTube) bị gán NHẦM cho tab Claude.ai, dù code Kotlin
            // đã có sẵn guard "chỉ gán nếu tab.url == pageUrl" — guard đó
            // CHỈ kiểm tra tab ĐÍCH có còn đúng URL không, KHÔNG kiểm tra
            // kết quả có THỰC SỰ tới từ tab đích hay từ 1 tab khác bị
            // broadcast nhầm. Sửa: gửi kèm `sourceUrl` (URL THẬT của trang
            // vừa chạy script này) trong MỌI phản hồi — Kotlin đối chiếu
            // `sourceUrl` với URL tab đích TRƯỚC khi tin kết quả, xem
            // `fetchFaviconForActiveTab()` ở MainActivity.kt.
            sourceUrl: location.href
          });
        } catch (e) {
          port.postMessage({
            result: "LOI: " + (e && e.message ? e.message : String(e)),
            requestId: msg.requestId,
            sourceUrl: location.href
          });
        }
      }
    });
  } catch (e) {
    // Truong hop hiem trang chan native messaging - bo qua an toan
  }
})();
