// Cau noi 1 chieu -> 2 chieu: native (Kotlin) -> content script -> eval trong
// trang -> GUI KET QUA THAT (hoac loi that) VE LAI qua port.postMessage().
// TRUOC DAY: loi bi NUOT AM THAM (catch rong), khong bao gio bao ve Kotlin -
// nghia la port connect duoc KHONG co nghia la script chay dung, chi la co
// ket noi thoi. Sua de biet chac chan.
//
// BUG NGHIEM TRONG DA SUA (phat hien khi doi chieu truc tiep code Kotlin):
// Kotlin gui field "type": "eval" nhung ban JS truoc day kiem tra sai ten
// field - dieu kien if KHONG BAO GIO dung, script CHUA TUNG duoc thuc thi
// qua cau noi nay tu truoc den gio (ke ca keepPlayingScript chong YouTube
// tu pause). Sua dung "msg.type". Them echo lai "requestId" trong ket qua
// tra ve - phia Kotlin gio dung nhieu callback dong thoi (khac 1 bien
// callback dung chung truoc day, de bi ghi de mat nhau khi co nhieu lenh
// goi evaluateJs() gan nhau).
(function () {
  // ===== Trang đăng nhập Google (mục 106) =====
  // Từ trước manifest loại accounts.google.com vì NGHI (chưa chứng minh) listener click toàn trang + ghi đè
  // HTMLAnchorElement.prototype.click (bắt tên file tải về, mục 8zzy) làm treo luồng OAuth. Để lưu/điền mật khẩu Google mà không
  // đưa lại phần bị nghi: trên host này CHỈ chạy mô-đun mật khẩu (thụ động: listener capture không chặn/không đổi sự kiện, không
  // ghi đè prototype nào) + cổng nhắn tin; mọi lệnh eval của app bị từ chối rõ ràng (sourceUrl để app loại bỏ nhầm tab).
  var LB_GOOGLE_LOGIN = (location.hostname === "accounts.google.com");
  if (LB_GOOGLE_LOGIN) {
    try {
      var gport = browser.runtime.connectNative("browser");
      try { lbPasswordModule(function () { return gport; }); } catch (e) {}
      var gOnMsg = function (msg) {
        if (msg && msg.type === "login_fill") {
          try { if (window.__lbPass) window.__lbPass.fill(msg); } catch (e) {}
          return;
        }
        if (msg && msg.type === "eval") {
          gport.postMessage({ result: "LOI: tính năng eval tắt trên trang đăng nhập Google", requestId: msg.requestId, sourceUrl: location.href });
        }
      };
      gport.onMessage.addListener(gOnMsg);
      // Mục 118: nếu lúc trang nạp mà app chưa gắn xong delegate (tab ẩn danh mở ngay lúc khởi động...), cổng bị ngắt ngay và trước đây KHÔNG
      // bao giờ nối lại => mất tự điền cả phiên. Nối lại tối đa 12 lần, cách 1,5s, rồi báo lại các ô chưa điền.
      var gRetries = 0;
      var gReconnect = function () {
        if (gRetries >= 12) return;
        gRetries++;
        setTimeout(function () {
          try {
            gport = browser.runtime.connectNative("browser");
            gport.onMessage.addListener(gOnMsg);
            gport.onDisconnect.addListener(gReconnect);
            if (window.__lbPass && window.__lbPass.rescan) window.__lbPass.rescan();
          } catch (e) { gReconnect(); }
        }, 1500);
      };
      gport.onDisconnect.addListener(gReconnect);
    } catch (e) { /* trang chặn native messaging — bỏ qua an toàn */ }
    return;
  }
  // BUG THẬT (xác nhận qua đối chiếu trực tiếp manifest.json +
  // GeckoViewEngine.kt::evaluateJsForTab — không phải đoán): manifest.json
  // khai "all_frames": true, nghĩa là content script này chạy trong MỌI
  // iframe của trang, không chỉ frame chính. Ở phía Kotlin,
  // `evaluateJsForTab()` gửi lệnh eval tới TẤT CẢ port khớp `tabId` —
  // `portTabId[port] == targetTabId` — nhưng port của MỌI iframe trong
  // cùng 1 tab đều được gán CHUNG 1 tabId (tabId gắn theo session/tab,
  // không phân biệt theo frame). Kết quả: khi 1 tab có iframe (quảng cáo,
  // nhúng cross-origin...), MỌI frame (kể cả iframe) đều nhận lệnh eval và
  // có thể trả lời — vì `evalCallbacks` chỉ giữ 1 callback theo requestId,
  // AI TRẢ LỜI TRƯỚC sẽ thắng (race condition). Với favicon cụ thể: script
  // fetchFavicon tìm <link rel="icon">, nếu không có sẽ fallback về
  // `location.origin + '/favicon.ico'` — nếu 1 iframe cross-origin trả lời
  // trước frame chính, favicon hiện ra là của domain HOÀN TOÀN KHÁC (vd
  // iframe quảng cáo), không phải trang người dùng đang xem — đúng khớp
  // triệu chứng "favicon không đúng như trên trang web".
  //
  // Sửa: chỉ frame TRÊN CÙNG (window === window.top) mới connect port và
  // xử lý lệnh eval chung (favicon, zoom, video diagnostic, outerHTML...).
  // Các tính năng hiện có (keepPlayingScript chống YouTube tự pause, v.v.)
  // đều nhắm vào trang top-level (youtube.com chạy ở frame chính, không
  // phải iframe), nên giới hạn này an toàn với toàn bộ tính năng đang có.
  // Nếu SAU NÀY có tính năng thật sự cần eval bên trong iframe cụ thể, cần
  // thiết kế kênh riêng có định danh frame rõ ràng — không dùng lại cầu
  // nối chung này để tránh lặp lại đúng bug này.
  if (window !== window.top) {
    return;
  }

  // BUG COLAB CÒN LẠI (log thật 17:04-17:05, bản 6.7): bản vá xuyên shadow
  // DOM ở mục 91 ĐÃ CHẠY ĐÚNG khi ô soạn thảo đang giữ focus —
  // `activeEl(xuyên shadow)=TEXTAREA.inputarea` cho ra `handled-by-page`
  // (Monaco xử lý paste). NHƯNG 4/6 lần bấm "Dán" cho ra
  // `activeEl(xuyên shadow)=UL.actions-container` — đó là danh sách của
  // MENU CHUỘT PHẢI của chính Monaco: nhấn giữ trong ô code làm Monaco mở
  // menu riêng và menu này cướp focus khỏi ô soạn thảo, nên lệnh Dán của
  // app bắn vào danh sách menu (không có handler paste) và không có gì
  // xảy ra. Cách chữa không phải đoán thêm: ghi nhớ ô soạn thảo được focus
  // GẦN NHẤT ngay lúc nó nhận focus (trước khi menu kịp cướp), để lệnh Dán
  // dùng lại đúng ô đó. `focusin` là sự kiện composed nên đi xuyên shadow
  // DOM; `composedPath()[0]` là phần tử thật bên trong shadow root. Lệnh
  // eval chạy bằng `new Function` TRONG CÙNG sandbox content script này
  // nên `window.__lbLastEditable` đọc được ở mọi lệnh evaluateJs sau đó.
  // ===== Lớp chọn văn bản cho Monaco (mục 100) =====
  // Tra cứu (microsoft/monaco-editor #246, #1504, #4622, #4860): Monaco KHÔNG có núm chọn cảm ứng
  // trên bất kỳ trình duyệt nào, kể cả Chrome Android; vùng chọn do Monaco tự vẽ bằng các <div>
  // class "selected-text", không phải Selection API. Nên app tự làm: chọn từ bằng cú nhấp đúp giả,
  // đọc hình chữ nhật từ .selected-text để đặt núm, kéo núm = nhấp đặt điểm cố định + shift+nhấp.
  try {
    var LB = window.__lbMon = {};
    var lbVV = function () {
      var v = window.visualViewport;
      return v ? { ox: v.offsetLeft, oy: v.offsetTop, w: v.width, h: v.height }
               : { ox: 0, oy: 0, w: window.innerWidth, h: window.innerHeight };
    };
    var lbCss = function (fx, fy) { var v = lbVV(); return { x: v.ox + fx * v.w, y: v.oy + fy * v.h }; };
    var lbFrac = function (x, y) { var v = lbVV(); return { x: (x - v.ox) / v.w, y: (y - v.oy) / v.h }; };
    var lbDeepAll = function (sel, root, out) {
      out = out || []; root = root || document;
      try { var f = root.querySelectorAll(sel); for (var i = 0; i < f.length; i++) out.push(f[i]); } catch (e) {}
      var all = root.querySelectorAll("*");
      for (var j = 0; j < all.length; j++) { if (all[j].shadowRoot) lbDeepAll(sel, all[j].shadowRoot, out); }
      return out;
    };
    var lbDeepPoint = function (x, y) {
      var el = document.elementFromPoint(x, y);
      while (el && el.shadowRoot) {
        var inner = el.shadowRoot.elementFromPoint(x, y);
        if (!inner || inner === el) break;
        el = inner;
      }
      return el;
    };
    var lbEditorOf = function (n) {
      while (n) {
        if (n.classList && n.classList.contains("monaco-editor")) return n;
        n = n.parentNode || n.host;
      }
      return null;
    };
    // Mục 112 (Colab nhảy loạn khi nhấn giữ + Chọn hết nhầm ô): ô nhập của Monaco trong một editor, và focus KHÔNG cuộn trang.
    var lbInputOfEditor = function (ed) {
      if (!ed) return null;
      try { return ed.querySelector("textarea.inputarea") || ed.querySelector("textarea"); } catch (e) { return null; }
    };
    var lbFocus = function (el) {
      try { el.focus({ preventScroll: true }); } catch (e) { try { el.focus(); } catch (e2) {} }
    };
    var lbDeepActive = function () {
      var a = document.activeElement;
      while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
      return a;
    };
    var lbIsInput = function (a) { return !!a && (a.tagName === "TEXTAREA" || a.isContentEditable || a.tagName === "INPUT"); };
    // Ô soạn thảo ĐÍCH = ô nằm dưới điểm nhấn giữ gần nhất do app xử lý. Chạm thật của người dùng (trusted) sau đó thì bỏ đích
    // (khi đó Gecko tự lo focus); chỉ các sự kiện giả của chính app (untrusted) không xoá đích.
    var lbSetTarget = function (x, y) {
      try {
        var inp = lbInputOfEditor(lbEditorOf(lbDeepPoint(x, y)));
        if (inp) { window.__lbTargetInput = inp; window.__lbTargetAt = Date.now(); window.__lbLastEditable = inp; }
      } catch (e) {}
    };
    // Mục 115: bỏ cơ chế "chạm thật xoá ô đích" của mục 112 — Gecko có thể phát pointerdown thật quanh lúc nhấn giữ nên ô đích bị xoá
    // ngay sau khi vừa đặt, và Chọn hết quay về ô đang focus (thường là cell khác). Thanh Chọn hết chỉ xuất hiện SAU một lần nhấn giữ
    // (vừa đặt ô đích), nên ô đích luôn mới; chỉ coi là cũ nếu quá 3 phút.
    var lbTarget = function () {
      var t = window.__lbTargetInput;
      if (!t || !t.isConnected) return null;
      if (window.__lbTargetAt && Date.now() - window.__lbTargetAt > 180000) return null;
      return t;
    };
    var lbFire = function (kind, x, y, o) {
      o = o || {};
      var t = lbDeepPoint(x, y) || document.body;
      var base = { bubbles: true, cancelable: true, composed: true, view: window,
        clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: o.buttons || 0,
        detail: o.detail || 1, shiftKey: !!o.shift };
      var pInit = {}; for (var k in base) pInit[k] = base[k];
      pInit.pointerId = 1; pInit.pointerType = "mouse"; pInit.isPrimary = true;
      pInit.width = 1; pInit.height = 1; pInit.pressure = o.buttons ? 0.5 : 0;
      try { t.dispatchEvent(new PointerEvent("pointer" + kind, pInit)); } catch (e) {}
      t.dispatchEvent(new MouseEvent("mouse" + kind, base));
      return t;
    };
    var lbClick = function (x, y, detail, shift) {
      lbFire("down", x, y, { buttons: 1, detail: detail, shift: shift });
      lbFire("up", x, y, { buttons: 0, detail: detail, shift: shift });
    };
    LB.isAt = function (fx, fy) {
      var c = lbCss(fx, fy);
      return !!lbEditorOf(lbDeepPoint(c.x, c.y));
    };
    LB.rects = function () {
      var active = lbDeepActive();
      var tgt = lbTarget();
      var ed = (tgt && lbEditorOf(tgt)) || lbEditorOf(active) || lbEditorOf(window.__lbLastEditable);
      var els = lbDeepAll(".selected-text"), rs = [];
      for (var i = 0; i < els.length; i++) {
        if (ed && lbEditorOf(els[i]) !== ed) continue;
        var r = els[i].getBoundingClientRect();
        if (r.width > 0.5 && r.height > 2) rs.push(r);
      }
      if (!rs.length) return JSON.stringify({ n: 0 });
      rs.sort(function (a, b) { return a.top - b.top || a.left - b.left; });
      var a = rs[0], z = rs[rs.length - 1];
      var s = lbFrac(a.left + 0.5, a.top + a.height / 2), sb = lbFrac(a.left, a.bottom);
      var e = lbFrac(z.right - 0.5, z.top + z.height / 2), eb = lbFrac(z.right, z.bottom);
      var tp = lbFrac(a.left, a.top);
      return JSON.stringify({ n: rs.length, sx: s.x, sy: s.y, sbx: sb.x, sby: sb.y,
        ex: e.x, ey: e.y, ebx: eb.x, eby: eb.y, tx: tp.x, ty: tp.y });
    };
    // Điểm nhấn có nằm trong vùng đang chọn không (nhấn giữ lên vùng đã chọn => giữ nguyên, không chọn lại từ)
    LB.hitSelection = function (fx, fy) {
      var c = lbCss(fx, fy), els = lbDeepAll(".selected-text");
      for (var i = 0; i < els.length; i++) {
        var r = els[i].getBoundingClientRect();
        if (r.width > 0.5 && c.x >= r.left - 8 && c.x <= r.right + 8 && c.y >= r.top - 4 && c.y <= r.bottom + 4) return true;
      }
      return false;
    };
    LB.wordAt = function (fx, fy) {
      var c = lbCss(fx, fy);
      lbSetTarget(c.x, c.y);
      lbClick(c.x, c.y, 1, false);
      lbClick(c.x, c.y, 2, false);
      return "wordAt@" + Math.round(c.x) + "," + Math.round(c.y);
    };
    LB.place = function (fx, fy) { var c = lbCss(fx, fy); lbSetTarget(c.x, c.y); lbClick(c.x, c.y, 1, false); return "place"; };
    LB.extend = function (fx, fy) { var c = lbCss(fx, fy); lbClick(c.x, c.y, 1, true); return "extend"; };
    // ---- Phím giả bắn THẲNG vào ô nhập của Monaco (mục 103) ----
    // Log thật: phím Android (KeyEvent) gửi vào GeckoView không làm Monaco xoá vùng chọn / chọn hết, trong khi Ctrl+C/V chạy
    // (Gecko tự xử lý lệnh clipboard native). Backspace/Ctrl+A là keybinding do CHÍNH Monaco nghe ở sự kiện keydown, nên bắn
    // KeyboardEvent (có keyCode, vì Monaco đọc e.keyCode) vào đúng <textarea> đang focus.
    var lbActiveInput = function () {
      var a = lbDeepActive();
      // Mục 112: có ô đích (ô vừa nhấn giữ) thì LUÔN dùng ô đó — trước đây dùng ô đang focus, mà ô đang focus có thể là ô của cell
      // khác => "Chọn hết ở cell này lại chọn hết cell kia".
      var tgt = lbTarget();
      if (tgt) { if (a !== tgt) lbFocus(tgt); return tgt; }
      if (lbIsInput(a)) return a;
      var last = window.__lbLastEditable;
      if (last && last.isConnected) { lbFocus(last); return last; }
      return null;
    };
    var LB_KEYS = { Backspace: 8, Delete: 46, a: 65, A: 65 };
    LB.keyCombo = function (key, ctrl, noKeyUp) {
      var t = lbActiveInput();
      if (!t) return "no-input";
      var code = key.length === 1 ? "Key" + key.toUpperCase() : key;
      var init = { key: key, code: code, keyCode: LB_KEYS[key] || 0, which: LB_KEYS[key] || 0, charCode: 0,
        ctrlKey: !!ctrl, bubbles: true, cancelable: true, composed: true, view: window };
      var kd = new KeyboardEvent("keydown", init);
      t.dispatchEvent(kd);
      if (!noKeyUp) t.dispatchEvent(new KeyboardEvent("keyup", init));
      return "keydown:" + key + (ctrl ? "+ctrl" : "") + " prevented=" + kd.defaultPrevented + " on=" + t.tagName + " focusOk=" + (lbDeepActive() === t);
    };
    // Không bắn keyup cho Chọn hết: Monaco chạy lệnh ở keydown; keyup chỉ kích hoạt thêm các bộ lắng nghe phụ (vd chép vùng chọn
    // vào "selection clipboard" trên Linux/Android = getValueInRange cả tài liệu) — không cần và có thể làm nặng khi chọn cả ô lớn.
    // Mục 115 — Chọn hết đáng tin cậy hơn.
    // (1) `LB.prepare(fx, fy)`: chọn ĐÚNG editor của vùng chọn đang hiện (điểm đầu vùng chọn do app truyền sang, có KIỂM CHỨNG điểm đó
    //     nằm trong một hình chữ nhật .selected-text của editor), đặt làm ô đích và focus nó (không cuộn trang).
    // (2) `LB.selectAllApi()`: gọi thẳng API của Monaco (editor.setSelection(toàn bộ)) — không phụ thuộc focus/keybinding/`when`, nên
    //     không còn tình trạng phím Ctrl+A giả "prevented=true" mà vùng chọn không đổi (log 16:18). Cần `window.wrappedJSObject.monaco`.
    LB.prepare = function (fx, fy) {
      try {
        var ed = null, how = "";
        if (typeof fx === "number") {
          var c = lbCss(fx, fy);
          var e1 = lbEditorOf(lbDeepPoint(c.x, c.y));
          if (e1) {
            var sels = e1.querySelectorAll(".selected-text");
            for (var i = 0; i < sels.length; i++) {
              var r = sels[i].getBoundingClientRect();
              if (r.width > 0.5 && c.x >= r.left - 12 && c.x <= r.right + 12 && c.y >= r.top - 8 && c.y <= r.bottom + 8) { ed = e1; how = "selection-hit"; break; }
            }
            if (!ed) { ed = e1; how = "point-editor"; }
          }
        }
        if (!ed) { var t = lbTarget(); if (t) { ed = lbEditorOf(t); how = "target"; } }
        if (!ed) { var a = lbDeepActive(); if (a) { ed = lbEditorOf(a); how = "active"; } }
        if (!ed) return "no-editor";
        var inp = lbInputOfEditor(ed);
        if (inp) {
          window.__lbTargetInput = inp; window.__lbTargetAt = Date.now(); window.__lbLastEditable = inp;
          if (lbDeepActive() !== inp) lbFocus(inp);
        }
        return "prepared:" + how + " focusOk=" + (!!inp && lbDeepActive() === inp);
      } catch (e) { return "prepare-ERR:" + e.message; }
    };
    LB.selectAllApi = function () {
      try {
        var t = lbTarget() || lbDeepActive();
        var edEl = lbEditorOf(t) || lbEditorOf(window.__lbLastEditable);
        if (!edEl) return "api:no-editor-el";
        var w = window.wrappedJSObject;
        var m = w && w.monaco;
        if (!m || !m.editor || !m.editor.getEditors) return "api:no-monaco(" + (typeof (m)) + ")";
        edEl.setAttribute("data-lb-mark", "1");
        var hit = null, count = 0;
        try {
          var eds = m.editor.getEditors();
          count = eds.length;
          for (var i = 0; i < eds.length; i++) {
            var n = eds[i].getDomNode();
            if (n && n.getAttribute && n.getAttribute("data-lb-mark") === "1") { hit = eds[i]; break; }
          }
        } finally { edEl.removeAttribute("data-lb-mark"); }
        if (!hit) return "api:editor-not-found(of " + count + ")";
        var model = hit.getModel();
        var lines = model.getLineCount();
        hit.setSelection(model.getFullModelRange());
        return "api:ok lines=" + lines + " editors=" + count;
      } catch (e) { return "api:ERR " + e.message; }
    };
    LB.selectAll = function () {
      var api = LB.selectAllApi();
      if (api.indexOf("api:ok") === 0) return api;
      return api + " | " + LB.keyCombo("a", true, true);
    };
    // Ước lượng số dòng của ô code đang focus (để cảnh báo trước khi Chọn hết một ô rất dài): chiều cao ô / chiều cao 1 dòng,
    // nhân thêm tỉ lệ track/slider nếu ô có thanh cuộn dọc riêng. Chỉ là ước lượng (>= thực tế khi slider bị kẹp tối thiểu).
    LB.docInfo = function () {
      try {
        var ed = lbEditorOf(lbActiveInput());
        if (!ed) return JSON.stringify({ lines: -1, why: "no-editor" });
        var vl = ed.querySelector(".view-line");
        var lh = vl ? vl.getBoundingClientRect().height : 0;
        if (!lh) return JSON.stringify({ lines: -1, why: "no-line-height" });
        var lines = ed.getBoundingClientRect().height / lh;
        var track = ed.querySelector(".scrollbar.vertical"), slider = ed.querySelector(".scrollbar.vertical .slider");
        if (track && slider) {
          var th = track.getBoundingClientRect().height, sh = slider.getBoundingClientRect().height;
          if (th > 0 && sh > 0 && sh < th) lines = lines * th / sh;
        }
        return JSON.stringify({ lines: Math.round(lines), lineHeight: Math.round(lh * 10) / 10 });
      } catch (e) { return JSON.stringify({ lines: -1, why: "ERR " + e.message }); }
    };
    // Xoá vùng chọn: thử Backspace giả; nếu vùng chọn còn thì thử sự kiện 'cut' giả (Monaco tự xoá khi nhận 'cut').
    LB.deleteSelection = function () {
      window.__lbDelResult = "running";
      var r1 = LB.keyCombo("Backspace", false);
      setTimeout(function () {
        var still = false;
        try { still = JSON.parse(LB.rects()).n > 0; } catch (e) {}
        if (!still) { window.__lbDelResult = "backspace-ok (" + r1 + ")"; return; }
        try {
          var t = lbActiveInput(), dt = new DataTransfer();
          var ev = new ClipboardEvent("cut", { clipboardData: dt, bubbles: true, cancelable: true, composed: true });
          if (t) t.dispatchEvent(ev);
        } catch (e) {}
        setTimeout(function () {
          var still2 = false;
          try { still2 = JSON.parse(LB.rects()).n > 0; } catch (e) {}
          window.__lbDelResult = still2 ? ("failed: Backspace va cut gia deu khong xoa duoc (" + r1 + ")") : "cut-event-ok";
        }, 200);
      }, 200);
      return "started";
    };
    // Đóng menu chuột phải riêng của Monaco (nhấn giữ làm nó mở và cướp focus) rồi trả focus về ô soạn thảo.
    LB.refocus = function (fx, fy) {
      try {
        var a = lbDeepActive();
        var isInput = lbIsInput(a);
        if (a && !isInput) {
          var ev = { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true, composed: true };
          a.dispatchEvent(new KeyboardEvent("keydown", ev));
          a.dispatchEvent(new KeyboardEvent("keyup", ev));
        }
        // Mục 112: trước đây LUÔN focus lại "ô focus gần nhất" dù focus đang ở đúng ô => nhảy sang cell cũ (trang cuộn, bàn phím
        // bật/tắt) rồi mới chọn từ ở cell mới. Giờ: ưu tiên ô dưới điểm nhấn (nếu có toạ độ) > ô đích > ô gần nhất, chỉ đổi focus
        // khi thật sự khác, và không cuộn trang.
        var dest = null;
        if (typeof fx === "number") { var c = lbCss(fx, fy); dest = lbInputOfEditor(lbEditorOf(lbDeepPoint(c.x, c.y))); if (dest) { window.__lbTargetInput = dest; window.__lbTargetAt = Date.now(); } }
        dest = dest || lbTarget();
        if (!dest && isInput) return "already-focused";
        dest = dest || window.__lbLastEditable;
        if (dest && dest.isConnected) { if (a !== dest) lbFocus(dest); return "refocused"; }
        return "no-last-editable";
      } catch (e) { return "ERR:" + e.message; }
    };
  } catch (e) { /* không được làm hỏng phần còn lại của content script */ }

  // Ghi nhận MỌI sự kiện paste (capture) để app kiểm chứng dán native có thật sự tới trang (mục 99).
  try {
    document.addEventListener("paste", function (ev) {
      try {
        var len = -1;
        try { len = ev.clipboardData ? (ev.clipboardData.getData("text/plain") || "").length : -2; } catch (e2) { len = -3; }
        window.__lbLastPaste = { t: Date.now(), trusted: ev.isTrusted === true, len: len };
      } catch (e) {}
    }, true);
  } catch (e) { /* không được làm hỏng phần còn lại */ }

  try {
    var __lbIsEditable = function (el) {
      if (!el || !el.tagName) return false;
      if (el.isContentEditable) return true;
      if (el.tagName === "TEXTAREA") return true;
      if (el.tagName === "INPUT") {
        var t = (el.type || "text").toLowerCase();
        return t === "text" || t === "search" || t === "url" || t === "tel" ||
               t === "email" || t === "password" || t === "number";
      }
      return false;
    };
    document.addEventListener("focusin", function (ev) {
      try {
        var path = ev.composedPath ? ev.composedPath() : [];
        var t = path.length ? path[0] : ev.target;
        if (__lbIsEditable(t)) window.__lbLastEditable = t;
      } catch (e) { /* bỏ qua — chỉ là gợi ý phục hồi focus */ }
    }, true);
  } catch (e) { /* không được làm hỏng phần còn lại của content script */ }

  /**
   * TÍNH NĂNG MỚI — giải quyết đúng gốc vấn đề "tên file tải về sai"
   * (khác với patch cũ đã bị chỉ ra là hardcode theo URL claude.ai và đã bỏ).
   *
   * ĐÃ TRA CỨU THỰC TẾ Chrome/Firefox làm gì (không đoán): theo đúng chuẩn
   * WHATWG + xác nhận qua nhiều nguồn (MDN, thảo luận whatwg-archive, so
   * sánh hành vi Chromium/Firefox) — trình duyệt lấy tên file tải về từ 2
   * NGUỒN, không chỉ 1:
   *   1) Header `Content-Disposition` của server (nếu có filename)
   *   2) Thuộc tính `download` trên thẻ <a> — CHỈ áp dụng cho URL cùng
   *      origin, hoặc blob:/data: — do CHÍNH TRANG WEB đặt ngay tại thời
   *      điểm tạo link tải, KHÔNG liên quan gì tới response HTTP.
   * Nếu header có filename, header thắng; nếu header thiếu hoặc là
   * "inline" không kèm filename, thuộc tính `download` được dùng.
   *
   * Quan trọng hơn: đã tra thấy CHÍNH THỨC 1 bug đã xác nhận của Mozilla
   * (bugzilla #1666013) rằng `ContentDelegate#onExternalResponse(GeckoSession,
   * WebResponse)` — API mà `GeckoViewEngine.kt` đang dùng — KHÔNG truyền
   * được fileName/Content-Disposition cho tải qua blob: URL, ví dụ minh
   * họa chính là app mẫu CHÍNH THỨC của Mozilla khi tải từ squoosh.app ra
   * tên "GVDownload" — y hệt lớp lỗi "download-file.bin" gặp phải, và đây
   * là giới hạn kiến trúc ĐÃ BIẾT của GeckoView, không phải lỗi riêng của
   * code này. Tức là nguồn (1) — Content-Disposition — có thể KHÔNG BAO
   * GIỜ tới được tầng Kotlin cho một số kiểu tải nhất định, bất kể parse
   * đúng cỡ nào — PHẢI có nguồn (2) bổ sung thì mới đúng như trình duyệt
   * thật, đây là lý do content script (có quyền truy cập DOM ngay lúc
   * click) phải tham gia, không thể giải quyết chỉ ở tầng Kotlin.
   *
   * Cách bắt: lắng nghe 'click' pha capture trên document (bắt được thẻ
   * <a download> có trong DOM), ĐỒNG THỜI ghi đè (monkey-patch)
   * HTMLAnchorElement.prototype.click — vì mẫu code JS rất phổ biến để
   * "xuất file" (nhiều khả năng đúng cách Claude.ai dùng) là tạo thẻ <a>
   * KHÔNG gắn vào DOM (`document.createElement('a')`) rồi gọi thẳng
   * `a.click()` — click() trên phần tử chưa gắn vào cây DOM không lan
   * truyền (bubble) tới document, listener thường sẽ KHÔNG bắt được, chỉ
   * có cách ghi đè thẳng hàm click() mới chắc chắn bắt được.
   *
   * Gửi kết quả bắt được qua port.postMessage() dạng "download_hint" —
   * KHÔNG cần requestId vì đây là báo TỰ NGUYỆN, không phải trả lời cho
   * lệnh eval nào. Kotlin lưu tạm (có hạn dùng ngắn) để đối chiếu khi
   * onExternalResponse tới, xem `downloadFilenameHints` trong
   * GeckoViewEngine.kt.
   *
   * GIỚI HẠN THẬT (không giấu): chỉ khớp khi Kotlin nhận được đúng URL y
   * hệt href đã bắt (không xử lý redirect đổi URL). Nếu trang dùng
   * framework che giấu hàm click() gốc theo cách khác (hiếm), sẽ bỏ lỡ —
   * lúc đó vẫn fallback về Content-Disposition/URLUtil như cũ, không tệ đi
   * so với trước.
   */
  try {
    var __lastConnectedPort = null;

    function resolveAbsoluteUrl(maybeRelative) {
      try {
        return new URL(maybeRelative, document.baseURI).href;
      } catch (e) {
        return maybeRelative;
      }
    }

    function reportDownloadHint(anchor) {
      try {
        if (!anchor || !anchor.href) return;
        var name = anchor.getAttribute("download");
        if (!name) return; // download="" (rỗng) nghĩa là "dùng tên mặc định
        // của server/URL" theo chuẩn — KHÔNG phải 1 tên hợp lệ, bỏ qua.
        var absoluteHref = resolveAbsoluteUrl(anchor.href);
        if (__lastConnectedPort) {
          __lastConnectedPort.postMessage({
            type: "download_hint",
            href: absoluteHref,
            filename: name
          });
        }
      } catch (e) {
        // Bỏ qua an toàn — không được để lỗi ở đây làm hỏng luồng click
        // thật của trang.
      }
    }

    document.addEventListener(
      "click",
      function (ev) {
        var el = ev.target;
        // Thẻ <a download> có thể lồng bên trong (vd <a download><span>Tải
        // xuống</span></a>, click trúng <span>) — closest() tìm ngược lên
        // ancestor gần nhất.
        var anchor = el && el.closest ? el.closest("a[download]") : null;
        if (anchor) reportDownloadHint(anchor);
      },
      true
    );

    if (window.HTMLAnchorElement && HTMLAnchorElement.prototype.click) {
      var __originalAnchorClick = HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click = function () {
        try {
          reportDownloadHint(this);
        } catch (e) {}
        return __originalAnchorClick.apply(this, arguments);
      };
    }
  } catch (e) {
    // Trang chặn ghi đè prototype (hiếm, CSP nghiêm ngặt...) — bỏ qua an
    // toàn, không ảnh hưởng các tính năng khác của content.js.
  }

  // ===== Trình quản lý mật khẩu (mục 105) =====
  // Chạy trong mọi khung (accounts.google.com chạy bản tối thiểu ở đầu file, mục 106). Việc LƯU TRỮ và HỎI NGƯỜI DÙNG do app (Kotlin) làm; script này chỉ:
  //  - phát hiện ô mật khẩu đang hiện -> báo "login_form" để app trả tài khoản đã lưu của ĐÚNG origin này;
  //  - bắt lúc người dùng bấm đăng nhập (submit / Enter / nút đăng nhập) -> báo "login_submit" kèm tên + mật khẩu;
  //  - nhận "login_fill" và điền vào ô đang hiện (không điền ô ẩn, không điền ô đã có chữ).
  function lbPasswordModule(getPort) {
    var P = window.__lbPass = {};
    var ORIGIN = location.origin;
    if (!/^https?:/.test(location.protocol)) return;
    // Mục 118: trước đây `seen` (WeakSet) đánh dấu ô là "đã báo" sau LẦN ĐẦU và không bao giờ báo lại. Nếu lúc đó app chưa sẵn sàng (cổng chưa
    // ánh xạ tab, extension chưa gắn vào session, kho đang khoá...) thì ô KHÔNG BAO GIỜ được điền. Giờ: `sent` đếm số lần báo của từng ô và
    // báo lại (tối đa 8 lần, cách ≥1,5s — thực tế ~2s/lần theo nhịp quét) cho tới khi ô được điền (`filled`) hoặc người dùng tự gõ.
    var sent = (typeof WeakMap !== "undefined") ? new WeakMap() : null;
    var filled = (typeof WeakSet !== "undefined") ? new WeakSet() : null;
    var multi = false, pickAt = 0, lastUser = "", lastSent = { key: "", t: 0 };

    function send(o) { try { var p = getPort(); if (p) p.postMessage(o); } catch (e) {} }
    function visible(el) {
      try {
        var r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) return false;
        var cs = getComputedStyle(el);
        return cs.visibility !== "hidden" && cs.display !== "none" && cs.opacity !== "0";
      } catch (e) { return false; }
    }
    function pwFields(root) {
      var out = [], all = (root || document).querySelectorAll('input[type="password"]');
      for (var i = 0; i < all.length; i++) if (!all[i].disabled && visible(all[i])) out.push(all[i]);
      return out;
    }
    function userFieldFor(pw) {
      var scope = pw.form || document, inputs = scope.querySelectorAll("input"), best = null;
      for (var i = 0; i < inputs.length; i++) {
        var el = inputs[i], t = (el.getAttribute("type") || "text").toLowerCase();
        if (el === pw || (t !== "text" && t !== "email" && t !== "tel")) continue;
        if (el.disabled || el.readOnly || !visible(el)) continue;
        if (el.compareDocumentPosition(pw) & 4) best = el; // 4 = ô mật khẩu đứng SAU trường này: lấy trường gần nhất phía trước
      }
      return best;
    }
    // Mục 110: điền kiểu "người gõ" để các khung giao diện (Google dùng framework riêng, React...) nhận ra giá trị: dùng bộ ghi giá trị GỐC
    // của HTMLInputElement (framework hay ghi đè setter trên chính phần tử), focus trước, rồi bắn InputEvent + change + blur.
    // Gán thẳng `el.value = ...` như trước đôi khi làm ô trông đã có chữ nhưng nút "Tiếp theo" vẫn coi là rỗng.
    function setVal(el, v) {
      try { el.focus(); } catch (e) {}
      try {
        var d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
        if (d && d.set) d.set.call(el, v); else el.value = v;
      } catch (e) { el.value = v; }
      try { el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: v })); }
      catch (e) { el.dispatchEvent(new Event("input", { bubbles: true })); }
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    // Tên đăng nhập đã biết của trang: gõ ở bước 1 (SPA) hoặc trang tự ghi trong data-email/data-identifier (Google ở bước mật khẩu).
    function pageUserHint() {
      if (lastUser) return lastUser;
      try {
        var el = document.querySelector("[data-email],[data-identifier]");
        var fromAttr = (el && (el.getAttribute("data-email") || el.getAttribute("data-identifier"))) || "";
        if (fromAttr) return fromAttr;
        // Mục 110: Google ở bước mật khẩu hiển thị email trong phần đầu trang (thường #profileIdentifier / #identifierLink) — đọc chữ
        // hiển thị làm dự phòng khi tải trang mới (lastUser rỗng) và thuộc tính data-* không có. Chỉ nhận chuỗi đúng dạng email.
        var cand = document.querySelectorAll("#profileIdentifier,#identifierLink,[data-profile-identifier]");
        for (var i = 0; i < cand.length; i++) {
          var m = ((cand[i].textContent || "") + "").match(/[^\s<>()"',;:]+@[^\s<>()"',;:]+\.[^\s<>()"',;:]+/);
          if (m) return m[0];
        }
        // Mục 118: Google để email trong ô ẨN dành cho trình quản lý mật khẩu (name=hiddenEmail / identifier, autocomplete=username).
        var hid = document.querySelectorAll('input[name="hiddenEmail"],input[name="identifier"],input[autocomplete~="username"]');
        for (var h = 0; h < hid.length; h++) {
          var hv = (hid[h].value || hid[h].getAttribute("value") || "").trim();
          if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(hv)) return hv;
        }
        return "";
      } catch (e) { return ""; }
    }
    // Bước 1 của đăng nhập 2 bước: chỉ có ô tên đăng nhập (Google: input[name=identifier], autocomplete=username), CHƯA có ô mật khẩu.
    // Chỉ nhận ô có gợi ý rõ ràng để không điền bừa email vào form đăng ký/bản tin của trang khác.
    function usernameOnlyFields() {
      var out = [];
      if (pwFields().length) return out;
      var all = document.querySelectorAll('input[autocomplete~="username"],input[name="identifier"]');
      for (var i = 0; i < all.length; i++) {
        var el = all[i], t = (el.getAttribute("type") || "text").toLowerCase();
        if (t !== "text" && t !== "email" && t !== "tel") continue;
        if (el.disabled || el.readOnly || !visible(el)) continue;
        out.push(el);
      }
      return out;
    }

    // ---- báo có form đăng nhập ----
    var scanTimer = 0, lastScan = 0;
    function scan() {
      var pf = pwFields(), uo = pf.length ? [] : usernameOnlyFields(), fresh = false;
      var all = pf.length ? pf : uo, now = Date.now();
      for (var i = 0; i < all.length; i++) {
        var el = all[i];
        if (filled && filled.has(el)) continue;
        if (!sent) { fresh = true; continue; }
        var rec = sent.get(el);
        if (!rec) { sent.set(el, { n: 1, t: now }); fresh = true; }
        else if (rec.n < 8 && now - rec.t >= 1500 && !el.value) { rec.n++; rec.t = now; fresh = true; }
      }
      if (fresh) send({ type: "login_form", origin: ORIGIN, url: location.href, userHint: pageUserHint(), usernameOnly: !pf.length });
    }
    function scheduleScan() {
      if (scanTimer) return;
      var wait = Math.max(400, 800 - (Date.now() - lastScan));
      scanTimer = setTimeout(function () { scanTimer = 0; lastScan = Date.now(); scan(); }, wait);
    }
    P.scan = scan;
    // Sau khi cổng nối lại (xem lbReconnect) cho phép báo lại toàn bộ ô chưa điền.
    P.rescan = function () { try { sent = (typeof WeakMap !== "undefined") ? new WeakMap() : null; } catch (e) {} scheduleScan(); };
    document.addEventListener("DOMContentLoaded", scheduleScan);
    // Gắn vào `document` (không phải documentElement): ở document_start documentElement CHƯA tồn tại nên observe(null) lỗi âm thầm
    // và form đăng nhập hiện muộn (trang một-trang, đăng nhập 2 bước) sẽ không bao giờ được phát hiện (đã bắt được bằng thử nghiệm).
    try { new MutationObserver(scheduleScan).observe(document, { childList: true, subtree: true }); } catch (e) {}
    // Mục 118: Google (và nhiều trang một-trang) chuyển bước đăng nhập bằng đổi class/style/hidden của phần tử CÓ SẴN chứ không thêm/xoá
    // nút DOM => observer `childList` không thấy, ô mật khẩu "hiện" ra mà không ai báo. Quan sát thêm thuộc tính + quét định kỳ (mỗi 2s trong
    // 90s đầu, sau đó thưa dần 6s) — chi phí không đáng kể (1 truy vấn `input[type=password]`).
    try { new MutationObserver(scheduleScan).observe(document, { attributes: true, subtree: true, attributeFilter: ["class", "style", "hidden", "aria-hidden", "disabled"] }); } catch (e) {}
    (function () {
      var t0 = Date.now(), tick = 0;
      setInterval(function () {
        tick++;
        if (document.visibilityState === "hidden") return;
        if (Date.now() - t0 > 90000 && tick % 3 !== 0) return; // sau 90s chỉ quét 6s/lần
        scheduleScan();
      }, 2000);
    })();
    scheduleScan();

    // ---- tên đăng nhập gõ gần nhất (đăng nhập 2 bước: nhập email xong mới hiện ô mật khẩu) ----
    document.addEventListener("input", function (ev) {
      var t = ev.target;
      if (!t || t.tagName !== "INPUT") return;
      var ty = (t.getAttribute("type") || "text").toLowerCase();
      if (ty !== "text" && ty !== "email" && ty !== "tel") return;
      var hint = ((t.getAttribute("autocomplete") || "") + " " + (t.name || "") + " " + (t.id || "")).toLowerCase();
      if (/user|email|login|account|phone|identifier|tai.?khoan/.test(hint) && t.value) lastUser = t.value;
    }, true);

    // ---- điền ----
    P.fill = function (msg) {
      if (msg.pickOnly) {
        multi = true; hookPick();
        // Mục 118: Google tự focus ô mật khẩu ngay khi hiện => sẽ KHÔNG có `focusin` mới để hỏi chọn tài khoản. Nếu ô đang focus thì hỏi luôn.
        try { var ae = document.activeElement; if (ae && isLoginTarget(ae)) askPick(); } catch (e) {}
        return;
      }
      var l = msg.login;
      if (!l || typeof l.password !== "string") return;
      var f = pwFields();
      if (!f.length) { // bước 1: chỉ điền tên đăng nhập (app cố ý KHÔNG gửi mật khẩu cho trang ở bước này)
        var uo = usernameOnlyFields();
        for (var k = 0; k < uo.length; k++) if (!uo[k].value && l.username) { setVal(uo[k], l.username); if (filled) filled.add(uo[k]); }
        return;
      }
      for (var i = 0; i < f.length; i++) {
        if (f[i].value) continue; // trình duyệt/trang đã điền sẵn thì không đè
        var u = userFieldFor(f[i]);
        if (u && !u.value && l.username) setVal(u, l.username);
        setVal(f[i], l.password);
        if (filled) filled.add(f[i]);
      }
    };
    function isLoginTarget(t) {
      if (!t || t.tagName !== "INPUT") return false;
      if (t.type === "password") return true;
      var pws = pwFields(); for (var i = 0; i < pws.length; i++) if (userFieldFor(pws[i]) === t) return true;
      var uo2 = usernameOnlyFields(); for (var j = 0; j < uo2.length; j++) if (uo2[j] === t) return true;
      return false;
    }
    function askPick() {
      var now = Date.now();
      if (now - pickAt < 4000) return;
      pickAt = now;
      send({ type: "login_pick", origin: ORIGIN, userHint: pageUserHint(), usernameOnly: !pwFields().length });
    }
    function hookPick() {
      if (hookPick.done) return;
      hookPick.done = true;
      document.addEventListener("focusin", function (ev) {
        if (!multi) return;
        if (isLoginTarget(ev.target)) askPick();
      }, true);
    }

    // ---- bắt đăng nhập ----
    function pickPassword(scope) {
      var all = pwFields(scope), vals = [];
      for (var i = 0; i < all.length; i++) if (all[i].value) vals.push(all[i]);
      if (!vals.length) return null;
      if (vals.length === 1) return vals[0];
      for (var j = 0; j < vals.length; j++) if ((vals[j].getAttribute("autocomplete") || "").toLowerCase() === "new-password") return vals[j];
      if (vals.length >= 3) return vals[1];                       // cũ / mới / nhập lại
      return vals[0].value === vals[1].value ? vals[0] : vals[1]; // đăng ký (mới + nhập lại) hoặc đổi mật khẩu
    }
    function report(scope) {
      try {
        var pw = pickPassword(scope || document);
        if (!pw || pw.value.length > 512) return;
        var uf = userFieldFor(pw), user = uf ? uf.value : "";
        if (!user) user = pageUserHint();
        var key = user + "\u0000" + pw.value, now = Date.now();
        if (lastSent.key === key && now - lastSent.t < 5000) return;
        lastSent = { key: key, t: now };
        send({ type: "login_submit", origin: ORIGIN, url: location.href, username: user, password: pw.value });
      } catch (e) {}
    }
    document.addEventListener("submit", function (ev) {
      var f = ev.target;
      report(f && f.querySelectorAll ? f : document);
    }, true);
    document.addEventListener("keydown", function (ev) {
      var t = ev.target;
      if (ev.key === "Enter" && t && t.tagName === "INPUT" && t.type === "password") report(t.form || document);
    }, true);
    var GOOD = /đăng\s*nhập|dang\s*nhap|log\s*in|login|sign\s*in|signin|đăng\s*ký|dang\s*ky|sign\s*up|signup|register|continue|next|tiếp|submit|gửi|xác\s*nhận|đồng\s*ý/i;
    var BAD = /show|hide|hiện|ẩn|eye|toggle|visib|reveal|forgot|quên/i;
    document.addEventListener("click", function (ev) {
      var el = ev.target && ev.target.closest ? ev.target.closest('button,input[type="submit"],input[type="button"],[role="button"],a') : null;
      if (!el) return;
      var label = (el.innerText || el.value || el.getAttribute("aria-label") || el.title || "");
      var isSubmit = (el.tagName === "INPUT" && el.type === "submit") || (el.tagName === "BUTTON" && !!el.form && (el.getAttribute("type") || "submit").toLowerCase() === "submit");
      if (BAD.test(label) && !isSubmit) return;
      if (isSubmit || GOOD.test(label)) report(el.form || document);
    }, true);
  }

  try {
    var port = browser.runtime.connectNative("browser");
    __lastConnectedPort = port;
    try { lbPasswordModule(function () { return port; }); } catch (e) {}
    var lbOnMsg = function (msg) {
      if (msg && msg.type === "login_fill") {
        try { if (window.__lbPass) window.__lbPass.fill(msg); } catch (e) {}
        return;
      }
      if (msg && msg.type === "eval" && typeof msg.script === "string") {
        try {
          // FIX: new Function(script)() chỉ trả về giá trị nếu script có
          // "return" ở cấp cao nhất. Script dạng (function(){...return x;})()
          // là expression-statement — kết quả IIFE tính ra nhưng không được
          // return ra ngoài new Function() → value luôn undefined → log "OK".
          // Sửa: bọc "return <expr>" — nhưng phải trim dấu ";" trailing
          // trước (script Kotlin thường kết thúc bằng ";") để tránh lỗi
          // cú pháp "return (expr;)" không hợp lệ.
          var trimmed = msg.script.trim().replace(/;+$/, "");
          var value = (new Function("return (" + trimmed + ")"))();
          port.postMessage({
            result: "OK" + (value !== undefined ? (": " + String(value)) : ""),
            requestId: msg.requestId,
            // BUG THẬT tìm được (người dùng chỉ đúng — ảnh chụp cho thấy
            // tab "New chat" của claude.ai hiện icon YouTube, không phải
            // icon của chính claude.ai): khi Kotlin không tìm thấy port
            // nào khớp đúng tabId (log "CHẨN ĐOÁN evaluateJs fallback...
            // broadcast toàn bộ" — xác nhận xảy ra RẤT THƯỜNG XUYÊN qua
            // log thật gửi kèm, không phải hiếm), lệnh eval bị BROADCAST
            // tới MỌI tab đang mở, không chỉ tab đích. Tab NÀO trả lời
            // TRƯỚC sẽ thắng (evalCallbacks chỉ giữ 1 callback theo
            // requestId) — nếu 1 tab KHÁC (vd tab YouTube đang mở nền) trả
            // lời trước tab đích (vd tab Claude.ai mới), kết quả (favicon
            // của YouTube) bị gán NHẦM cho tab Claude.ai, dù code Kotlin
            // đã có sẵn guard "chỉ gán nếu tab.url == pageUrl" — guard đó
            // CHỈ kiểm tra tab ĐÍCH có còn đúng URL không, KHÔNG kiểm tra
            // kết quả có THỰC SỰ tới từ tab đích hay từ 1 tab khác bị
            // broadcast nhầm. Sửa: gửi kèm `sourceUrl` (URL THẬT của trang
            // vừa chạy script này) trong MỌI phản hồi — Kotlin đối chiếu
            // `sourceUrl` với URL tab đích TRƯỚC khi tin kết quả, xem
            // `fetchFaviconForActiveTab()` ở MainActivity.kt.
            sourceUrl: location.href
          });
        } catch (e) {
          port.postMessage({
            result: "LOI: " + (e && e.message ? e.message : String(e)),
            requestId: msg.requestId,
            sourceUrl: location.href
          });
        }
      }
    };
    port.onMessage.addListener(lbOnMsg);
    // Mục 118: tự nối lại khi cổng bị ngắt (xem chú thích ở nhánh Google). `port` là biến dùng chung nên lbPasswordModule thấy cổng mới.
    var lbRetries = 0;
    var lbReconnect = function () {
      if (lbRetries >= 12) return;
      lbRetries++;
      setTimeout(function () {
        try {
          port = browser.runtime.connectNative("browser");
          __lastConnectedPort = port;
          port.onMessage.addListener(lbOnMsg);
          port.onDisconnect.addListener(lbReconnect);
          if (window.__lbPass && window.__lbPass.rescan) window.__lbPass.rescan();
        } catch (e) { lbReconnect(); }
      }, 1500);
    };
    port.onDisconnect.addListener(lbReconnect);
  } catch (e) {
    // Truong hop hiem trang chan native messaging - bo qua an toan
  }
})();

// Mục 116 — THỬ NGHIỆM chỉ cho drive.google.com (đổi tên file làm trang nhảy lia lịa): Gecko ≥132 mặc định "resizes-visual" (bàn phím chỉ
// co khung nhìn; Gecko liên tục cuộn khung nhìn để lộ ô nhập, còn hộp thoại cố định của Drive bám khung bố cục nên trượt qua lại — log 20:27
// cho thấy vị trí ô nhập đổi y 616↔958↔1455 khi bàn phím đứng yên). Thêm `interactive-widget=resizes-content` vào meta viewport để Drive về
// hành vi cũ mà trang được thiết kế cho: khung bố cục co theo bàn phím, hộp thoại tự canh giữa phần còn thấy. Nếu trang không có meta viewport
// thì chờ tới khi tải xong rồi tạo một thẻ chỉ chứa khoá này. Kiểm chứng bằng log "[CHẨN ĐOÁN viewport]": `ch` co theo bàn phím = đã ăn.
(function () {
  try {
    if (window !== window.top) return;
    if (location.hostname !== "drive.google.com") return;
    var KEY = "interactive-widget=resizes-content";
    var apply = function () {
      var m = document.querySelector('meta[name="viewport"]');
      if (!m) return false;
      var c = m.getAttribute("content") || "";
      if (c.indexOf("interactive-widget") === -1) m.setAttribute("content", c ? c + ", " + KEY : KEY);
      return true;
    };
    if (!apply()) {
      var mo = new MutationObserver(function () { if (apply()) mo.disconnect(); });
      mo.observe(document.documentElement, { childList: true, subtree: true });
      window.addEventListener("load", function () {
        setTimeout(function () {
          if (apply()) { try { mo.disconnect(); } catch (e) {} return; }
          try {
            var nm = document.createElement("meta");
            nm.setAttribute("name", "viewport");
            nm.setAttribute("content", KEY);
            (document.head || document.documentElement).appendChild(nm);
          } catch (e) {}
          try { mo.disconnect(); } catch (e) {}
        }, 1500);
      });
    }
  } catch (e) {}
})();
