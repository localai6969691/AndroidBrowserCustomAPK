// Bản 7.56 — nền của eval_bridge: QUAN SÁT cookie qua header HTTP để thấy cả cookie HttpOnly TRONG ĐÚNG tab/vùng đang xem
// (API `cookies` của addon không với tới kho contextId/vùng ẩn danh — mục 174; document.cookie không thấy HttpOnly).
//  - Cookie (header yêu cầu)  => tên + giá trị của MỌI cookie trình duyệt gửi đi (kể cả HttpOnly).
//  - Set-Cookie (header phản hồi) => thuộc tính đầy đủ (HttpOnly/Secure/SameSite/Domain/Path/hạn) của cookie vừa được đặt/xoá.
//  - Ghi cookie HttpOnly: chèn Set-Cookie vào phản hồi kế tiếp của tab (listener `blocking` chỉ tồn tại tạm thời) — THỬ NGHIỆM, cần kiểm chứng.
// Chỉ lắng nghe khi công cụ cookie được mở (ck_start) và tự tắt sau 90 giây không dùng => không làm chậm duyệt web bình thường.
var obs = {};            // tabId -> { host -> { name -> {value, hdr:true, attrs?, t} } }
var listening = false, offTimer = null;
var injectQueue = {};    // tabId -> { cookies:[...], used:0, listener:fn, timer }

function hostOf(u) { try { return new URL(u).hostname.toLowerCase(); } catch (e) { return ""; } }
function slot(tabId, host) { var t = obs[tabId] || (obs[tabId] = {}); return t[host] || (t[host] = {}); }

function onReq(d) {
  try {
    if (d.tabId < 0 || !d.requestHeaders) return;
    var h = null;
    for (var i = 0; i < d.requestHeaders.length; i++) if (String(d.requestHeaders[i].name).toLowerCase() === "cookie") { h = d.requestHeaders[i].value; break; }
    if (!h) return;
    var host = hostOf(d.url), s = slot(d.tabId, host);
    h.split(/;\s*/).forEach(function (p) {
      var k = p.indexOf("="); if (k <= 0) return;
      var n = p.slice(0, k), v = p.slice(k + 1);
      var e = s[n] || (s[n] = {}); e.value = v; e.hdr = true; e.t = Date.now();
    });
  } catch (e) {}
}

function parseSetCookie(line) {
  var parts = String(line).split(";"), nv = parts.shift(), k = nv.indexOf("=");
  if (k <= 0) return null;
  var c = { name: nv.slice(0, k).trim(), value: nv.slice(k + 1).trim(), httpOnly: false, secure: false };
  parts.forEach(function (a) {
    var i = a.indexOf("="), key = (i < 0 ? a : a.slice(0, i)).trim().toLowerCase(), val = i < 0 ? "" : a.slice(i + 1).trim();
    if (key === "domain") c.domain = val.replace(/^\./, "");
    else if (key === "path") c.path = val;
    else if (key === "expires") { var t = Date.parse(val); if (!isNaN(t)) c.expires = t; }
    else if (key === "max-age") { var m = parseInt(val, 10); if (!isNaN(m)) c.maxAge = m; }
    else if (key === "secure") c.secure = true;
    else if (key === "httponly") c.httpOnly = true;
    else if (key === "samesite") c.sameSite = val.toLowerCase();
  });
  return c;
}

function onResp(d) {
  try {
    if (d.tabId < 0 || !d.responseHeaders) return;
    var host = hostOf(d.url);
    d.responseHeaders.forEach(function (h) {
      if (String(h.name).toLowerCase() !== "set-cookie") return;
      String(h.value || "").split("\n").forEach(function (line) {
        var c = parseSetCookie(line); if (!c) return;
        var s = slot(d.tabId, host);
        var gone = (c.maxAge !== undefined && c.maxAge <= 0) || (c.expires !== undefined && c.expires < Date.now());
        if (gone) { delete s[c.name]; return; }
        var e = s[c.name] || (s[c.name] = {});
        e.value = c.value; e.attrs = c; e.t = Date.now();
      });
    });
  } catch (e) {}
}

function ensureListening() {
  if (!listening) {
    try {
      browser.webRequest.onBeforeSendHeaders.addListener(onReq, { urls: ["<all_urls>"] }, ["requestHeaders"]);
      browser.webRequest.onHeadersReceived.addListener(onResp, { urls: ["<all_urls>"] }, ["responseHeaders"]);
      listening = true;
    } catch (e) { return String(e); }
  }
  if (offTimer) clearTimeout(offTimer);
  offTimer = setTimeout(function () {
    try { browser.webRequest.onBeforeSendHeaders.removeListener(onReq); browser.webRequest.onHeadersReceived.removeListener(onResp); } catch (e) {}
    listening = false; offTimer = null; obs = {};
  }, 90000);
  return null;
}

function buildSetCookie(c, reqHost) {
  var s = c.name + "=" + c.value + "; Path=" + (c.path || "/");
  var dom = String(c.domain || "").replace(/^\./, "");
  if (dom && !c.hostOnly) {
    if (reqHost !== dom && !reqHost.endsWith("." + dom)) return null;         // Domain phải khớp host của phản hồi
    s += "; Domain=" + dom;
  } else if (dom && dom !== reqHost) return null;
  if (c.expirationDate && !c.session) s += "; Expires=" + new Date(c.expirationDate * 1000).toUTCString();
  var ss = String(c.sameSite || "").toLowerCase();
  if (ss === "no_restriction" || ss === "none") s += "; SameSite=None";
  else if (ss === "lax") s += "; SameSite=Lax"; else if (ss === "strict") s += "; SameSite=Strict";
  if (c.secure || ss === "no_restriction" || ss === "none") s += "; Secure";
  if (c.httpOnly) s += "; HttpOnly";
  return s;
}

function startInject(tabId, cookies) {
  var q = injectQueue[tabId];
  if (q) { try { browser.webRequest.onHeadersReceived.removeListener(q.listener); } catch (e) {} clearTimeout(q.timer); }
  q = injectQueue[tabId] = { cookies: cookies, used: 0, failed: 0 };
  q.listener = function (d) {
    if (d.tabId !== tabId) return {};
    var host = hostOf(d.url), add = [];
    q.cookies.forEach(function (c) { if (c.__done) return; var sc = buildSetCookie(c, host); if (sc) { add.push({ name: "Set-Cookie", value: sc }); c.__done = true; q.used++; } });
    if (!add.length) return {};
    var hs = (d.responseHeaders || []).concat(add);
    if (q.cookies.every(function (c) { return c.__done; })) setTimeout(function () { try { browser.webRequest.onHeadersReceived.removeListener(q.listener); } catch (e) {} }, 0);
    return { responseHeaders: hs };
  };
  browser.webRequest.onHeadersReceived.addListener(q.listener, { urls: ["<all_urls>"] }, ["blocking", "responseHeaders"]);
  q.timer = setTimeout(function () { try { browser.webRequest.onHeadersReceived.removeListener(q.listener); } catch (e) {} }, 15000);
}

browser.runtime.onMessage.addListener(function (m, sender) {
  if (!m || !m.lb) return;
  var tabId = sender && sender.tab ? sender.tab.id : -1;
  if (m.lb === "ck_start") { var err = ensureListening(); return Promise.resolve({ ok: !err, error: err }); }
  if (m.lb === "ck_seen") {
    var out = [], t = obs[tabId] || {};
    Object.keys(t).forEach(function (host) { Object.keys(t[host]).forEach(function (n) { var e = t[host][n]; out.push({ host: host, name: n, value: e.value, hdr: !!e.hdr, attrs: e.attrs || null }); }); });
    return Promise.resolve(out);
  }
  if (m.lb === "ck_inject") {
    var e2 = ensureListening(); if (e2) return Promise.resolve({ ok: false, error: e2 });
    try { startInject(tabId, (m.cookies || []).map(function (c) { return Object.assign({}, c); })); return Promise.resolve({ ok: true }); }
    catch (x) { return Promise.resolve({ ok: false, error: String(x) }); }
  }
  // Bản 7.58 — thuộc tính THẬT của cookie (HttpOnly/Secure/SameSite/hạn) qua API `cookies` của addon. Theo mã nguồn Gecko (ext-cookies.js): `getAll` nhận MẪU
  // origin-attributes một phần (storeId firefox-default => userContextId=0,privateBrowsingId=0; firefox-private => privateBrowsingId=1) nên KHÔNG ràng buộc
  // geckoViewSessionContextId => có thể liệt kê được cả cookie nằm trong kho contextId/vùng. (get/set/remove dùng thuộc tính CHÍNH XÁC nên GHI thì lạc kho.)
  // Nội dung khớp theo (tên + giá trị) với cookie tab đang thấy, nên cookie cùng tên ở vùng khác (giá trị khác) bị bỏ qua.
  if (m.lb === "ck_attrs") {
    return (async function () {
      var out = [], stores = [], errs = [];
      try { stores = (await browser.cookies.getAllCookieStores()).map(function (s) { return s.id; }); } catch (e) { errs.push("stores:" + e); }
      if (!stores.length) stores = ["firefox-default", "firefox-private"];
      for (var i = 0; i < stores.length; i++) {
        var list = null;
        try { list = await browser.cookies.getAll({ url: m.url, storeId: stores[i] }); }
        catch (e1) { try { list = await browser.cookies.getAll({ url: m.url, storeId: stores[i], firstPartyDomain: null }); } catch (e2) { errs.push(stores[i] + ":" + e2); } }
        (list || []).forEach(function (c) {
          out.push({ name: c.name, value: c.value, domain: c.domain, hostOnly: c.hostOnly, path: c.path, secure: c.secure, httpOnly: c.httpOnly,
                     sameSite: c.sameSite, session: c.session, expirationDate: c.expirationDate || 0, store: stores[i] });
        });
      }
      return { cookies: out, stores: stores, errors: errs };
    })();
  }
  if (m.lb === "ck_inject_status") { var q = injectQueue[tabId]; return Promise.resolve(q ? { used: q.used, total: q.cookies.length } : { used: 0, total: 0 }); }
});

try { browser.tabs.onRemoved.addListener(function (id) { delete obs[id]; delete injectQueue[id]; }); } catch (e) {}

// ===== Bản 7.57 — GIÁM SÁT ĐĂNG NHẬP (chẩn đoán "Claude.ai bị đăng xuất") =====
// Chỉ lắng nghe các host trong WATCH (bộ lọc URL nên không tốn gì cho trang khác). KHÔNG BAO GIỜ ghi giá trị cookie — chỉ TÊN, hạn, cờ.
// Ghi lại: (1) phản hồi 401/403 (đường dẫn, không query); (2) máy chủ XOÁ cookie (Set-Cookie hết hạn/Max-Age<=0);
// (3) máy chủ cấp cookie phiên mới; (4) tab đang có cookie phiên rồi yêu cầu kế tiếp KHÔNG còn gửi nó (cookie biến mất phía trình duyệt);
// (5) header cf-mitigated (Cloudflare chặn/thử thách). Sự kiện đẩy về content script của tab => Kotlin ghi vào DebugLog.
var WATCH = ["*://claude.ai/*", "*://*.claude.ai/*", "*://*.anthropic.com/*"];
var SESSION_NAMES = ["sessionkey", "__ssid", "sessionkeylc"];     // tên cookie phiên của claude.ai (so khớp không phân biệt hoa/thường)
var awState = {};   // tabId -> { had: bool, lastNames: [] }
var awBudget = 80;  // tối đa sự kiện mỗi lần chạy addon, tránh phình log

function awEmit(tabId, text) {
  if (awBudget <= 0 || tabId < 0) return;
  awBudget--;
  try { browser.tabs.sendMessage(tabId, { lb: "authwatch", text: text }).catch(function () {}); } catch (e) {}
}
function pathOf(u) { try { var x = new URL(u); return x.hostname + x.pathname; } catch (e) { return "?"; } }
function isSessionName(n) { return SESSION_NAMES.indexOf(String(n).toLowerCase()) >= 0; }

function awOnReq(d) {
  try {
    if (d.tabId < 0 || d.type === "image" || d.type === "font" || d.type === "stylesheet") return;
    var h = null;
    for (var i = 0; i < (d.requestHeaders || []).length; i++) if (String(d.requestHeaders[i].name).toLowerCase() === "cookie") { h = d.requestHeaders[i].value; break; }
    var names = h ? h.split(/;\s*/).map(function (p) { return p.split("=")[0]; }).filter(Boolean) : [];
    var has = names.some(isSessionName);
    var st = awState[d.tabId] || (awState[d.tabId] = { had: false, lastNames: [] });
    if (st.had && !has && (d.type === "xmlhttprequest" || d.type === "main_frame")) {
      awEmit(d.tabId, "yêu cầu " + pathOf(d.url) + " KHÔNG còn gửi cookie phiên (trước đó có). Cookie đang gửi: [" + names.join(",") + "]");
      st.had = false;
    } else if (has) st.had = true;
    st.lastNames = names;
  } catch (e) {}
}

function awOnResp(d) {
  try {
    if (d.tabId < 0) return;
    var hs = d.responseHeaders || [];
    if (d.statusCode === 401 || d.statusCode === 403) {
      var cfm = "";
      hs.forEach(function (h) { if (String(h.name).toLowerCase() === "cf-mitigated") cfm = " cf-mitigated=" + h.value; });
      awEmit(d.tabId, "HTTP " + d.statusCode + " từ " + pathOf(d.url) + " (" + d.type + ")" + cfm);
    }
    hs.forEach(function (h) {
      var hn = String(h.name).toLowerCase();
      if (hn === "cf-mitigated" && d.statusCode < 400) awEmit(d.tabId, "Cloudflare cf-mitigated=" + h.value + " ở " + pathOf(d.url));
      if (hn !== "set-cookie") return;
      String(h.value || "").split("\n").forEach(function (line) {
        var c = parseSetCookie(line); if (!c) return;
        var gone = (c.maxAge !== undefined && c.maxAge <= 0) || (c.expires !== undefined && c.expires < Date.now()) || c.value === "";
        if (gone) awEmit(d.tabId, "máy chủ XOÁ cookie '" + c.name + "' (Set-Cookie hết hạn) qua " + pathOf(d.url) + " — HTTP " + d.statusCode);
        else if (isSessionName(c.name)) {
          var exp = c.expires ? Math.round((c.expires - Date.now()) / 3600000) + "h" : (c.maxAge ? Math.round(c.maxAge / 3600) + "h" : "phiên");
          awEmit(d.tabId, "máy chủ CẤP cookie phiên '" + c.name + "' (HttpOnly=" + c.httpOnly + ", Secure=" + c.secure + ", SameSite=" + (c.sameSite || "-") + ", hạn ~" + exp + ") qua " + pathOf(d.url));
        }
      });
    });
  } catch (e) {}
}
try {
  browser.webRequest.onBeforeSendHeaders.addListener(awOnReq, { urls: WATCH }, ["requestHeaders"]);
  browser.webRequest.onHeadersReceived.addListener(awOnResp, { urls: WATCH }, ["responseHeaders"]);
} catch (e) {}
