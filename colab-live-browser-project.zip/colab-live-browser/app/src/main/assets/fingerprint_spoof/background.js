// Fingerprint Spoof background (Mục 144).
// LỖI GỐC: content.js chỉ áp giả mạo khi cấu hình từ native (bất đồng bộ) trả về — trong lúc script của trang đã chạy từ document_start nên
// đã đọc giá trị THẬT. Mozilla bug 1332273 nêu đúng vấn đề: script document_start không thể chờ messaging/storage bất đồng bộ; cách chuẩn là
// đăng ký content script từ background với cấu hình NHÚNG SẴN và lưu bền qua lần khởi động. Chameleon cũng từng dính race này.
// content.js lưu cấu hình hợp lệ gần nhất vào storage.local; file này đăng ký [cấu hình nhúng sẵn + content.js] (thứ tự mảng js được đảm bảo).
(function() {
    'use strict';
    const KEY = 'lb_fp_cfg';
    const EXCLUDE = ['*://accounts.google.com/*']; // giữ đúng như manifest cũ
    let registration = null;
    let lastKey = null;
    let busy = Promise.resolve();

    function register(json) {
        busy = busy.then(async function() {
            const key = json || '';
            if (key === lastKey && registration) return;
            try { if (registration) { await registration.unregister(); registration = null; } } catch (e) {}
            try {
                const js = json ? [{ code: 'var __LB_FP_CFG=' + json + ';' }, { file: 'content.js' }] : [{ file: 'content.js' }];
                registration = await browser.contentScripts.register({
                    matches: ['<all_urls>'], excludeMatches: EXCLUDE, allFrames: true, matchAboutBlank: true, runAt: 'document_start', js: js
                });
                lastKey = key;
            } catch (e) {
                console.log('fingerprint background: contentScripts.register lỗi: ' + ((e && e.message) || e));
            }
        });
    }

    // ---- MAIN world: Intl/Date/Temporal/Worker (main_world.js, hàm __lbInstall) với cấu hình nhúng sẵn ----
    let mainReg = null, mainKey = null, mainSrc = null, mainBusy = Promise.resolve();
    function registerMain(json) {
        mainBusy = mainBusy.then(async function() {
            const key = json || '';
            if (key === mainKey) return;
            try { if (mainReg) { await mainReg.unregister(); mainReg = null; } } catch (e) {}
            mainKey = key;
            if (!json) return;
            try {
                let cfg = null; try { cfg = JSON.parse(json); } catch (e) {}
                if (!cfg || !cfg.enabled) return;
                if (!mainSrc) mainSrc = await (await fetch(browser.runtime.getURL('main_world.js'))).text();
                const code = '(function(){' + mainSrc + '\n;try{__lbInstall(window,' + json + ',false,location.href);}catch(e){}})();';
                mainReg = await browser.contentScripts.register({
                    matches: ['<all_urls>'], excludeMatches: EXCLUDE, allFrames: true, matchAboutBlank: true, runAt: 'document_start',
                    world: 'MAIN', js: [{ code: code }]
                });
            } catch (e) {
                mainKey = null;
                console.log('fingerprint background: đăng ký MAIN world lỗi: ' + ((e && e.message) || e));
            }
        });
    }

    // 1) Đăng ký NGAY bằng cấu hình đã lưu (nếu chưa có thì vẫn đăng ký content.js trần = hành vi cũ).
    register(null);
    browser.storage.local.get(KEY).then(function(r) { if (r && typeof r[KEY] === 'string') { register(r[KEY]); registerMain(r[KEY]); } }).catch(function() {});
    // 2) Khi content.js lưu cấu hình mới -> đăng ký lại cho các lần tải trang SAU.
    browser.storage.onChanged.addListener(function(changes, area) {
        if (area === 'local' && changes[KEY] && typeof changes[KEY].newValue === 'string') { register(changes[KEY].newValue); registerMain(changes[KEY].newValue); }
    });
})();
