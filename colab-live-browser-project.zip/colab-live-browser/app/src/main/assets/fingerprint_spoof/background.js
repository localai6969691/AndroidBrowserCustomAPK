// Fingerprint Spoof background (Mục 144, sửa ở bản 7.90).
// LỖI GỐC (144): content.js chỉ áp giả mạo khi cấu hình từ native (bất đồng bộ) trả về — trong lúc script của trang đã chạy từ document_start nên
// đã đọc giá trị THẬT. Mozilla bug 1332273 nêu đúng vấn đề: script document_start không thể chờ messaging/storage bất đồng bộ; cách chuẩn là
// đăng ký content script từ background với cấu hình NHÚNG SẴN và lưu bền qua lần khởi động. Chameleon cũng từng dính race này.
//
// Bản 7.90 — SỬA LỖI "cấu hình gần nhất dùng chung cho mọi lớp/vùng" (rủi ro đã ghi ở mục 209.1):
//  Trước đây chỉ có MỘT khoá `lb_fp_cfg_v2`, và MỌI tab (kể cả tab nền nhận đẩy cấu hình hàng loạt) ghi đè nó; content.js chỉ so User-Agent. UA giống nhau giữa các lớp/vùng nên
//  trang của lớp/vùng này có thể được áp cấu hình (phần cứng, GPU, múi giờ, hạt giống canvas) của lớp/vùng khác trong vài mili-giây đầu.
//  Nay: (1) bộ nhớ tách THEO LỚP — `lb_fp_cfg_v3_n` (tab thường, kể cả vùng bền) và `lb_fp_cfg_v3_p` (tab ẩn danh, kể cả vùng ẩn danh); content.js chọn theo `browser.extension.inIncognitoContext`
//  (đồng bộ, có ngay ở document_start). (2) CHỈ tab ĐANG XEM mới được ghi (app gắn cờ `early` vào cấu hình của tab đang xem) — tab nền không còn ghi đè.
//  KHÔNG dùng được tuỳ chọn `cookieStoreId` của contentScripts.register để tách theo VÙNG: mã nguồn Gecko (ext-contentScripts.js) chỉ nhận firefox-default / firefox-private /
//  firefox-container-<số>; id vùng của app là chuỗi tuỳ ý (firefox-container-zone_<id>) nên bị từ chối ("Invalid cookieStoreId") và vùng GeckoView không dùng userContextId.
//
// Bản 7.91 — CỔNG DANH TÍNH (fail-closed). Ô áp sớm của mỗi LỚP vẫn dùng chung giữa các vùng cùng lớp (không có tín hiệu đồng bộ nào ở document_start phân biệt hai vùng bền) nên app
// không còn để "tab đang xem" tự ghi ô đó nữa. Thay vào đó app (GeckoViewEngine.identityPending) GIỮ điều hướng của một tab cho tới khi ô áp sớm của lớp đó đúng là cấu hình của VÙNG
// tab này: gửi `prime` (lớp + cấu hình) qua cổng native của BACKGROUND, addon nạp vào ô, đăng ký lại content script rồi trả `primed` (kèm seq) => app mới cho tải trang.
// App cũng giữ "quyền dùng ô" của lớp cho tới khi trang đầu tải xong để tab vùng khác cùng lớp không ghi đè giữa chừng.
(function() {
    'use strict';
    const KEYS = { n: 'lb_fp_cfg_v3_n', p: 'lb_fp_cfg_v3_p' };
    const OLD_KEY = 'lb_fp_cfg_v2';                // khoá cũ dùng chung mọi lớp — bỏ đi, không đọc nữa
    const EXCLUDE = ['*://accounts.google.com/*']; // giữ đúng như manifest cũ
    const cache = { n: null, p: null };            // lớp -> chuỗi JSON cấu hình hợp lệ gần nhất của TAB ĐANG XEM thuộc lớp đó
    let registration = null;
    let lastKey = null;
    let busy = Promise.resolve();

    // Chỉ nhận chuỗi là JSON của một đối tượng cấu hình đã bật; còn lại coi như chưa có (không bao giờ nhúng chuỗi lạ vào mã đăng ký).
    function valid(s) {
        if (typeof s !== 'string' || !s) return null;
        try { const o = JSON.parse(s); return (o && typeof o === 'object' && o.enabled) ? s : null; } catch (e) { return null; }
    }

    // Mục 149: bản ISOLATED chạy ở MỌI trang (trừ accounts.google.com) để luôn nhận cấu hình MỚI từ native và tự quyết định bỏ qua theo danh sách hiện tại.
    // (Trước đây loại trừ ngay từ khâu đăng ký theo cache => script không chạy => cache không bao giờ được làm mới => danh sách cũ có hiệu lực mãi.)
    function excludesFor(json, forMain) {
        const ex = EXCLUDE.slice();
        if (!forMain) return ex;
        try {   // chỉ bản MAIN (không có đường nhận cấu hình mới) mới loại theo cache
            const cfg = json ? JSON.parse(json) : null;
            ((cfg && cfg.skipHosts) || []).forEach(function(h) {
                h = String(h || '').trim().toLowerCase();
                if (/^[a-z0-9.-]+$/.test(h)) { ex.push('*://' + h + '/*'); ex.push('*://*.' + h + '/*'); }
            });
        } catch (e) {}
        return ex;
    }

    // Mã nhúng cho bản ISOLATED: cả hai lớp trong MỘT đối tượng; content.js tự chọn lớp của mình bằng inIncognitoContext.
    function embedCode() {
        return 'var __LB_FP_CFGS={"n":' + (cache.n || 'null') + ',"p":' + (cache.p || 'null') + '};';
    }

    function register() {
        busy = busy.then(async function() {
            const key = (cache.n || '') + '\u0001' + (cache.p || '');
            if (key === lastKey && registration) return;
            try { if (registration) { await registration.unregister(); registration = null; } } catch (e) {}
            try {
                registration = await browser.contentScripts.register({
                    matches: ['<all_urls>'], excludeMatches: excludesFor(null, false), allFrames: true, matchAboutBlank: true, runAt: 'document_start',
                    js: [{ code: embedCode() }, { file: 'content.js' }]
                });
                lastKey = key;
            } catch (e) {
                console.log('fingerprint background: contentScripts.register lỗi: ' + ((e && e.message) || e));
            }
        });
        return busy;
    }

    // ---- MAIN world: Intl/Date/Temporal/Worker (main_world.js, hàm __lbInstall) với cấu hình nhúng sẵn ----
    // MAIN world không có API `browser` nên không tự biết lớp => đăng ký RIÊNG cho từng lớp với bộ lọc cookieStoreId (firefox-default / firefox-private — hai giá trị mà Gecko chấp nhận).
    const mainReg = { n: null, p: null }, mainKey = { n: null, p: null };
    let mainSrc = null, mainBusy = Promise.resolve();
    function registerMain(layer) {
        mainBusy = mainBusy.then(async function() {
            const json = cache[layer] || '';
            if (json === mainKey[layer]) return;
            try { if (mainReg[layer]) { await mainReg[layer].unregister(); mainReg[layer] = null; } } catch (e) {}
            mainKey[layer] = json;
            if (!json) return;
            try {
                let cfg = null; try { cfg = JSON.parse(json); } catch (e) {}
                if (!cfg || !cfg.enabled || cfg.mainWorld === false) return;   // fp_t_mainworld=false -> không đăng ký bản MAIN
                if (!mainSrc) mainSrc = await (await fetch(browser.runtime.getURL('main_world.js'))).text();
                const code = '(function(){' + mainSrc + '\n;try{__lbInstall(window,' + json + ',false,location.href);}catch(e){}})();';
                mainReg[layer] = await browser.contentScripts.register({
                    matches: ['<all_urls>'], excludeMatches: excludesFor(json, true), allFrames: true, matchAboutBlank: true, runAt: 'document_start',
                    world: 'MAIN', cookieStoreId: [layer === 'p' ? 'firefox-private' : 'firefox-default'], js: [{ code: code }]
                });
            } catch (e) {
                mainKey[layer] = null;
                console.log('fingerprint background: đăng ký MAIN world (' + layer + ') lỗi: ' + ((e && e.message) || e));
            }
        });
        return mainBusy;
    }

    // 1) Đăng ký NGAY (nếu chưa có cấu hình thì vẫn đăng ký content.js với cấu hình rỗng = hành vi cũ), rồi nạp cấu hình đã lưu của từng lớp.
    register();
    try { browser.storage.local.remove(OLD_KEY).catch(function() {}); } catch (e) {}
    browser.storage.local.get([KEYS.n, KEYS.p]).then(function(r) {
        r = r || {};
        // Chỉ nạp nếu trong lúc chờ chưa có bản MỚI HƠN từ onChanged.
        if (cache.n === null) cache.n = valid(r[KEYS.n]);
        if (cache.p === null) cache.p = valid(r[KEYS.p]);
        register(); registerMain('n'); registerMain('p');
    }).catch(function() {});
    // 2) Khi content.js của tab ĐANG XEM lưu cấu hình mới -> đăng ký lại cho các lần tải trang SAU.
    browser.storage.onChanged.addListener(function(changes, area) {
        if (area !== 'local') return;
        ['n', 'p'].forEach(function(layer) {
            const c = changes[KEYS[layer]];
            if (c && typeof c.newValue === 'string') {
                const v = valid(c.newValue);
                if (v !== null && v !== cache[layer]) { cache[layer] = v; register(); registerMain(layer); }
            }
        });
    });

    // 3) Bản 7.91 — kênh native của BACKGROUND (khác cổng content script theo tab): app gửi `prime`, addon nạp ô áp sớm của lớp rồi trả `primed`.
    // Kotlin chỉ gắn delegate sau khi addon được nạp nên lần nối đầu có thể hụt: nối lại mỗi 2s tới khi app báo `gate_ready` (cùng kiểu addon proxy_config).
    const SETTLE_MS = 40;   // chờ bản đăng ký lan tới các tiến trình nội dung trước khi báo xong (register() chỉ bảo đảm phía cha đã nhận)
    let nport = null, gotReady = false, nTries = 0;
    function sleep(ms) { return new Promise(function(r) { setTimeout(r, ms); }); }
    function reply(o) { try { if (nport) nport.postMessage(o); } catch (e) {} }
    function onNative(msg) {
        if (!msg || typeof msg !== 'object') return;
        if (msg.type === 'gate_ready') { gotReady = true; return; }
        if (msg.type !== 'prime') return;
        const layer = msg.layer === 'p' ? 'p' : 'n';
        const seq = msg.seq;
        const v = valid(msg.config);
        if (v === null) { reply({ type: 'primed', layer: layer, seq: seq, ok: false, why: 'cấu hình không hợp lệ/chưa bật' }); return; }
        cache[layer] = v;
        try { browser.storage.local.set({ [KEYS[layer]]: v }); } catch (e) {}   // bền qua lần khởi động; onChanged thấy cùng giá trị nên không đăng ký lại lần hai
        Promise.all([register(), registerMain(layer)]).then(function() { return sleep(SETTLE_MS); })
            .then(function() { reply({ type: 'primed', layer: layer, seq: seq, ok: true }); },
                  function(e) { reply({ type: 'primed', layer: layer, seq: seq, ok: false, why: String((e && e.message) || e) }); });
    }
    function connectNativeChannel() {
        if (gotReady) return;
        try { if (nport) { try { nport.disconnect(); } catch (e) {} nport = null; } } catch (e) {}
        try {
            nport = browser.runtime.connectNative('browser');
            nport.onMessage.addListener(onNative);
            nport.onDisconnect.addListener(function() { nport = null; gotReady = false; nTries = 0; setTimeout(connectNativeChannel, 1500); });
            nport.postMessage({ type: 'hello', who: 'fingerprint_spoof_bg' });
        } catch (e) { nport = null; }
        if (!gotReady && ++nTries < 90) setTimeout(connectNativeChannel, 2000);
    }
    try { connectNativeChannel(); } catch (e) {}
})();
