// Fingerprint Spoof — MAIN world (Mục 144).
// File này CHỈ định nghĩa hàm __lbInstall; background.js ghép nó với cấu hình rồi đăng ký chạy ở world MAIN (Firefox >= 128 hỗ trợ
// `world: "MAIN"`, không bị CSP chặn, nhưng KHÔNG có WebExtension API). Chạy trong cùng môi trường với script của trang nên bọc được
// hàm tạo (Proxy) mà không cần Xray/exportFunction. Cách làm theo các extension giả múi giờ phổ biến (Spoof Timezone, GeoSpoof, GeoMirror:
// bọc Intl.DateTimeFormat + Date + Temporal) và theo Chameleon/JShelter cho Worker (bọc hàm tạo Worker, nhúng lại cùng hook vào trong worker).
//
// Cùng một hàm được dùng cho TRANG và cho WORKER (nhúng vào đầu mã worker bằng Function.prototype.toString) nên hai nơi luôn nhất quán.
// g = globalThis (window hoặc self của worker); CFG = cấu hình; isWorker; root = URL gốc để phân giải đường dẫn tương đối của worker.
function __lbInstall(g, CFG, isWorker, root) {
    'use strict';
    if (!CFG || !CFG.enabled) return;

    const Obj = g.Object, Refl = g.Reflect, Prox = g.Proxy;
    // Tab đang ở chế độ "máy tính"/"di động" thủ công có UA khác UA trong cấu hình -> KHÔNG giả phần phần cứng cho worker của tab đó.
    if (!isWorker) { try { if (CFG.userAgent && g.navigator.userAgent !== CFG.userAgent) CFG = Obj.assign({}, CFG, { hardware: false }); } catch (e) {} }
    const nativeOf = new g.WeakMap();                       // hàm giả -> hàm gốc (để Function.prototype.toString trả chuỗi "[native code]" gốc)
    function mask(fake, orig) { try { nativeOf.set(fake, orig); } catch (e) {} }
    function hide(holder, name, value) {
        Obj.defineProperty(holder, name, { value: value, writable: true, configurable: true, enumerable: false });
    }
    // Hàm giả có đúng name/length như hàm thật.
    function def(holder, name, len, impl) {
        const orig = holder[name];
        if (typeof orig !== 'function') return null;
        const f = ({ [name]: function() { return impl.apply(this, arguments); } })[name];
        Obj.defineProperty(f, 'length', { value: len, configurable: true });
        mask(f, orig);
        hide(holder, name, f);
        return orig;
    }
    function getter(proto, name, valueFn) {
        const d = proto && Obj.getOwnPropertyDescriptor(proto, name);
        if (!d || !d.get) return;
        const f = ({ ['get ' + name]: function() { return valueFn(); } })['get ' + name];
        mask(f, d.get);
        Obj.defineProperty(proto, name, { get: f, set: undefined, enumerable: d.enumerable, configurable: true });
    }
    function step(fn) { try { fn(); } catch (e) { /* một mục lỗi không được làm hỏng mục khác / trang */ } }

    // ---- che Function.prototype.toString cho mọi hàm giả ----
    step(function() {
        const FPTS = g.Function.prototype.toString;
        const P = new Prox(FPTS, { apply: function(t, th, a) { return Refl.apply(t, nativeOf.has(th) ? nativeOf.get(th) : th, a); } });
        mask(P, FPTS);
        hide(g.Function.prototype, 'toString', P);
    });

    const hasLocale = !!(CFG.spoofLocale && CFG.timezone);
    const TZ = CFG.timezone;
    const LOC = hasLocale ? (CFG.locale || CFG.language || undefined) : undefined;
    const OD = g.Date;
    const RealDTF = g.Intl && g.Intl.DateTimeFormat;

    // =============================== MÚI GIỜ / LOCALE ===============================
    if (hasLocale && RealDTF && OD) {
        const dateUTC = OD.UTC, getTime = OD.prototype.getTime, setTime = OD.prototype.setTime, origParse = OD.parse;
        const realGet = {};      // getter gốc (múi giờ THẬT) — chỉ dùng nội bộ để đọc chuỗi ngày không có múi giờ
        ['getFullYear', 'getMonth', 'getDate', 'getHours', 'getMinutes', 'getSeconds', 'getMilliseconds'].forEach(function(m) { realGet[m] = OD.prototype[m]; });

        const offFmt = new RealDTF('en-US', { timeZone: TZ, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' });
        const dateFmt = new RealDTF('en-US', { timeZone: TZ, weekday: 'short', month: 'short', day: '2-digit', year: 'numeric', hourCycle: 'h23', hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const nameFmt = new RealDTF('en-US', { timeZone: TZ, timeZoneName: 'long' });
        const pad = function(n) { return (n < 10 ? '0' : '') + n; };

        // Số phút lệch UTC (đông là dương) của múi giờ giả tại thời điểm ms.
        function offsetAt(ms) {
            const p = {};
            offFmt.formatToParts(ms).forEach(function(x) { p[x.type] = x.value; });
            const asUTC = dateUTC(+p.year, +p.month - 1, +p.day, (+p.hour) % 24, +p.minute, +p.second);
            return Math.round((asUTC - Math.floor(ms / 1000) * 1000) / 60000);
        }
        // Giờ "tường" (wall clock, biểu diễn như UTC) -> thời điểm UTC thật, theo múi giờ giả.
        function wallToUtc(w) {
            const o1 = offsetAt(w);
            let u = w - o1 * 60000;
            const o2 = offsetAt(u);
            if (o2 !== o1) u = w - o2 * 60000;
            return u;
        }
        function wallDate(t) { return new OD(t + offsetAt(t) * 60000); }       // các getUTC* của nó = trường giờ cục bộ giả

        // ---- getters cục bộ ----
        def(OD.prototype, 'getTimezoneOffset', 0, function() { const t = getTime.call(this); return t !== t ? NaN : -offsetAt(t); });
        [['getFullYear', 'getUTCFullYear'], ['getMonth', 'getUTCMonth'], ['getDate', 'getUTCDate'], ['getDay', 'getUTCDay'],
         ['getHours', 'getUTCHours'], ['getMinutes', 'getUTCMinutes'], ['getSeconds', 'getUTCSeconds']].forEach(function(pr) {
            def(OD.prototype, pr[0], 0, function() { const t = getTime.call(this); return t !== t ? NaN : wallDate(t)[pr[1]](); });
        });
        def(OD.prototype, 'getYear', 0, function() { const t = getTime.call(this); return t !== t ? NaN : wallDate(t).getUTCFullYear() - 1900; });

        // ---- setters cục bộ ----
        [['setMilliseconds', 'setUTCMilliseconds', 1], ['setSeconds', 'setUTCSeconds', 2], ['setMinutes', 'setUTCMinutes', 3],
         ['setHours', 'setUTCHours', 4], ['setDate', 'setUTCDate', 1], ['setMonth', 'setUTCMonth', 2], ['setFullYear', 'setUTCFullYear', 3]].forEach(function(s) {
            def(OD.prototype, s[0], s[2], function() {
                const t = getTime.call(this);
                let d;
                if (t !== t) { if (s[0] !== 'setFullYear') return NaN; d = new OD(0); }
                else d = wallDate(t);
                d[s[1]].apply(d, arguments);
                const w = getTime.call(d);
                if (w !== w) return setTime.call(this, NaN);
                return setTime.call(this, wallToUtc(w));
            });
        });

        // ---- toString / toDateString / toTimeString ----
        function strParts(t) {
            const p = {};
            dateFmt.formatToParts(t).forEach(function(x) { p[x.type] = x.value; });
            let name = '';
            nameFmt.formatToParts(t).forEach(function(x) { if (x.type === 'timeZoneName') name = x.value; });
            const off = offsetAt(t), a = Math.abs(off);
            const gmt = 'GMT' + (off < 0 ? '-' : '+') + pad(Math.floor(a / 60)) + pad(a % 60);
            return { date: p.weekday + ' ' + p.month + ' ' + p.day + ' ' + p.year, time: pad((+p.hour) % 24) + ':' + p.minute + ':' + p.second + ' ' + gmt + (name ? ' (' + name + ')' : '') };
        }
        const origToString = OD.prototype.toString;
        def(OD.prototype, 'toString', 0, function() { const t = getTime.call(this); if (t !== t) return origToString.call(this); const q = strParts(t); return q.date + ' ' + q.time; });
        const origToDateString = def(OD.prototype, 'toDateString', 0, function() { const t = getTime.call(this); if (t !== t) return origToDateString.call(this); return strParts(t).date; });
        const origToTimeString = def(OD.prototype, 'toTimeString', 0, function() { const t = getTime.call(this); if (t !== t) return origToTimeString.call(this); return strParts(t).time; });

        // ---- toLocale*String: mặc định múi giờ + locale giả ----
        ['toLocaleString', 'toLocaleDateString', 'toLocaleTimeString'].forEach(function(m) {
            const orig = OD.prototype[m];
            def(OD.prototype, m, 0, function(l, o) {
                let opt = o;
                if (opt === undefined) opt = { timeZone: TZ };
                else if (opt !== null && typeof opt === 'object' && opt.timeZone === undefined) opt = Obj.assign({}, opt, { timeZone: TZ });
                return orig.call(this, l === undefined ? LOC : l, opt);
            });
        });

        // ---- Date.parse + hàm tạo Date (chuỗi / thành phần là GIỜ CỤC BỘ) ----
        function parseFix(p, str) {
            if (p !== p) return p;
            if (/^\s*\d{4}-\d{2}-\d{2}\s*$/.test(str)) return p;                                       // ISO chỉ ngày = UTC
            if (/(Z|[+-]\d{2}:?\d{2}|GMT|UTC|UT)\s*(\([^)]*\))?\s*$/i.test(str)) return p;             // đã có múi giờ
            const r = new OD(p);                                                                       // p được hiểu theo múi giờ THẬT
            const w = dateUTC(realGet.getFullYear.call(r), realGet.getMonth.call(r), realGet.getDate.call(r),
                realGet.getHours.call(r), realGet.getMinutes.call(r), realGet.getSeconds.call(r), realGet.getMilliseconds.call(r));
            return wallToUtc(w);
        }
        def(OD, 'parse', 1, function(s) { const str = String(s); return parseFix(origParse.call(OD, str), str); });
        const PD = new Prox(OD, {
            construct: function(t, a, nt) {
                const target = nt === PD ? t : nt;
                if (a.length === 0) return Refl.construct(t, a, target);
                if (a.length === 1) {
                    const v = a[0];
                    if (typeof v === 'string') return Refl.construct(t, [parseFix(origParse.call(OD, v), v)], target);
                    return Refl.construct(t, a, target);
                }
                const w = dateUTC.apply(OD, a);
                return Refl.construct(t, [w === w ? wallToUtc(w) : NaN], target);
            },
            apply: function() { return new PD().toString(); }
        });
        mask(PD, OD);
        hide(OD.prototype, 'constructor', PD);
        hide(g, 'Date', PD);

        // ---- Intl: mặc định múi giờ/locale giả ----
        function wrapIntl(name, callable, inject) {
            const O = g.Intl[name];
            if (typeof O !== 'function') return;
            const P = new Prox(O, {
                construct: function(t, a, nt) { return Refl.construct(t, inject(a), nt === P ? t : nt); },
                apply: function(t, th, a) { return callable ? Refl.construct(t, inject(a), t) : Refl.apply(t, th, a); }
            });
            mask(P, O);
            hide(g.Intl, name, P);
        }
        const withLoc = function(a) { return a[0] === undefined && LOC !== undefined ? [LOC].concat(Array.prototype.slice.call(a, 1)) : a; };
        wrapIntl('DateTimeFormat', true, function(a) {
            let o = a[1];
            if (o === undefined) o = { timeZone: TZ };
            else if (o !== null && typeof o === 'object' && o.timeZone === undefined) o = Obj.assign({}, o, { timeZone: TZ });
            return [a[0] === undefined ? LOC : a[0], o];
        });
        // ICU chuẩn hoá tên múi giờ (vd Asia/Ho_Chi_Minh -> Asia/Saigon); trả đúng tên trong cấu hình như một trình duyệt đặt múi giờ thật.
        step(function() {
            const canon = new RealDTF('en-US', { timeZone: TZ }).resolvedOptions().timeZone;
            const ro = RealDTF.prototype.resolvedOptions;
            def(RealDTF.prototype, 'resolvedOptions', 0, function() { const r = ro.call(this); if (r.timeZone === canon) r.timeZone = TZ; return r; });
        });
        if (LOC !== undefined) {
            ['NumberFormat', 'Collator'].forEach(function(n) { wrapIntl(n, true, withLoc); });
            ['PluralRules', 'RelativeTimeFormat', 'ListFormat', 'Segmenter'].forEach(function(n) { wrapIntl(n, false, withLoc); });
            const nl = g.Number.prototype.toLocaleString;
            def(g.Number.prototype, 'toLocaleString', 0, function(l, o) { return nl.call(this, l === undefined ? LOC : l, o); });
            const lc = g.String.prototype.localeCompare;
            def(g.String.prototype, 'localeCompare', 1, function(that, l, o) { return lc.call(this, that, l === undefined ? LOC : l, o); });
        }

        // ---- Temporal (Firefox >= 139) ----
        step(function() {
            const N = g.Temporal && g.Temporal.Now;
            if (!N) return;
            def(N, 'timeZoneId', 0, function() { return TZ; });
            ['zonedDateTimeISO', 'plainDateTimeISO', 'plainDateISO', 'plainTimeISO'].forEach(function(m) {
                const o = N[m];
                def(N, m, 0, function(tz) { return o.call(N, tz === undefined ? TZ : tz); });
            });
        });
    }

    // =============================== NAVIGATOR TRONG WORKER ===============================
    if (isWorker) {
        step(function() {
            const NP = g.WorkerNavigator && g.WorkerNavigator.prototype;
            if (!NP) return;
            if (CFG.hardware) {
                getter(NP, 'platform', function() { return CFG.platform; });
                getter(NP, 'hardwareConcurrency', function() { return CFG.hardwareConcurrency; });
                if (CFG.uaSync && CFG.userAgent) {
                    getter(NP, 'userAgent', function() { return CFG.userAgent; });
                    const p = String(CFG.platform || '');
                    const av = /^Win/i.test(p) ? '5.0 (Windows)' : (/^Mac/i.test(p) ? '5.0 (Macintosh)' : '5.0 (X11)');
                    getter(NP, 'appVersion', function() { return av; });
                }
            }
            if (hasLocale) {
                getter(NP, 'language', function() { return CFG.language; });
                let arr = null;
                getter(NP, 'languages', function() {
                    if (!arr) { arr = (CFG.languages || []).slice(); Obj.freeze(arr); }
                    return arr;
                });
            }
        });
    }

    // =============================== WORKER / SHAREDWORKER ===============================
    // Worker có WorkerNavigator/Intl/Date riêng nên patch ở trang KHÔNG tới được. Bọc hàm tạo: đọc mã worker (XHR đồng bộ, cùng nguồn hoặc blob:),
    // thêm hook ở đầu rồi tạo worker từ Blob. Mọi lỗi/không áp dụng được -> dùng hàm tạo gốc (không bao giờ làm hỏng worker).
    if (CFG.workerWrap !== false && (hasLocale || CFG.hardware)) {
        const base = root || (g.location && g.location.href) || '';
        const selfSrc = __lbInstall.toString();
        ['Worker', 'SharedWorker'].forEach(function(name) {
            step(function() {
                const O = g[name];
                if (typeof O !== 'function') return;
                const P = new Prox(O, {
                    construct: function(t, a, nt) {
                        const target = nt === P ? t : nt;
                        try {
                            const raw = a[0], opts = a[1];
                            if (typeof raw !== 'string' && !(g.URL && raw instanceof g.URL)) return Refl.construct(t, a, target);
                            if (opts && typeof opts === 'object' && opts.type === 'module') return Refl.construct(t, a, target);
                            const abs = new g.URL(String(raw), base).href;
                            if (!/^(https?|blob):/i.test(abs)) return Refl.construct(t, a, target);
                            if (/^https?:/i.test(abs) && new g.URL(abs).origin !== g.location.origin) return Refl.construct(t, a, target);
                            const x = new g.XMLHttpRequest();
                            x.open('GET', abs, false);
                            x.send();
                            const body = x.responseText;
                            if (!body || (x.status !== 200 && x.status !== 0)) return Refl.construct(t, a, target);
                            const sub = JSON.stringify(CFG);
                            const shim = '(function(BASE){try{var R=function(u){try{return new URL(u,BASE).href}catch(e){return u}};' +
                                'var _i=self.importScripts;if(_i)self.importScripts=function(){return _i.apply(self,Array.prototype.map.call(arguments,function(u){return R(String(u))}))};' +
                                'if(self.fetch){var _f=self.fetch;self.fetch=function(r,i){return _f.call(self,typeof r==="string"?R(r):(r instanceof URL?R(r.href):r),i)}}' +
                                'if(self.XMLHttpRequest){var _o=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){arguments[1]=R(String(u));return _o.apply(this,arguments)}}' +
                                '}catch(e){}})(' + JSON.stringify(abs) + ');\n';
                            const hook = '(' + selfSrc + ')(self,' + sub + ',true,' + JSON.stringify(abs) + ');\n';
                            const blob = new g.Blob([hook + shim + body + '\n//# sourceURL=' + abs], { type: 'text/javascript' });
                            const url = g.URL.createObjectURL(blob);
                            const rest = Array.prototype.slice.call(a, 1);
                            return Refl.construct(t, [url].concat(rest), target);
                        } catch (e) {
                            return Refl.construct(t, a, target);
                        }
                    }
                });
                mask(P, O);
                hide(g, name, P);
            });
        });
    }
}
