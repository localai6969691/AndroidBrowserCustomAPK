// Fingerprint Spoof Content Script v5.0 (Mục 139)
// Chạy ở document_start để giả tín hiệu TRƯỚC khi trang web đọc (config tới từ native qua cổng, xem setupPort()).
//
// MỤC 139 — SỬA LỖI GỐC "trang web khác vẫn dò được thiết bị thật":
// Content script của Firefox chạy trong một vùng riêng và nhìn trang web qua lớp bọc Xray. `Object.defineProperty(Navigator.prototype, ...)`
// hay `HTMLCanvasElement.prototype.toDataURL = ...` viết trong vùng này CHỈ ĐỔI CÁI CONTENT SCRIPT THẤY — script của trang vẫn đọc giá trị thật
// (đúng lỗi người dùng báo). Bản 4.0 viết toàn bộ theo kiểu đó và không có `wrappedJSObject`/`exportFunction` nào. Bản này ghi thẳng vào đối
// tượng của TRANG: `window.wrappedJSObject` (đối tượng thật của trang) + `exportFunction` (hàm xuất sang phạm vi trang).
// Đồng thời sửa các lỗi thiết kế sẽ lộ ra khi ghi đè thật sự có hiệu lực (xem từng khối bên dưới) và thêm tự kiểm tra từ GÓC NHÌN CỦA TRANG
// (gửi về native, ghi log `[fp-selftest]`).

(function() {
    'use strict';

    let config = {
        enabled: false,
        canvas: false,
        hardware: false,
        spoofLocale: false,
        audio: false,
        font: false,
        webrtc: false,
        uaSync: false,
        platform: navigator.platform,
        hardwareConcurrency: navigator.hardwareConcurrency || 4,
        deviceMemory: navigator.deviceMemory || 8,
        maxTouchPoints: navigator.maxTouchPoints || 1,
        screenWidth: screen.width,
        screenHeight: screen.height,
        colorDepth: screen.colorDepth,
        pixelRatio: window.devicePixelRatio || 1,
        webglVendor: null,
        webglRenderer: null,
        userAgent: navigator.userAgent,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        language: navigator.language,
        languages: Array.from(navigator.languages || [navigator.language]),
        locale: navigator.language,
        noiseSeed: 0
    };

    // ===== Đối tượng của TRANG + công cụ xuất hàm =====
    let W = null;
    try { W = window.wrappedJSObject || null; } catch (e) { W = null; }
    const canExport = !!(W && typeof exportFunction === 'function');
    let applied = false;
    let selfTested = false;
    const applyErrors = [];
    const patched = [];

    function ex(fn) { return exportFunction(fn, W); }

    // Mô tả thuộc tính phải được tạo TRONG phạm vi trang (`new W.Object()`), để mọi đối tượng chạm tới đều là của trang.
    function pageDefine(target, prop, attrs) {
        const d = new W.Object();
        const keys = Object.keys(attrs);
        for (let i = 0; i < keys.length; i++) d[keys[i]] = attrs[keys[i]];
        W.Object.defineProperty(target, prop, d);
    }
    function pageGetter(target, prop, getter) {
        pageDefine(target, prop, { get: ex(getter), configurable: true, enumerable: true });
    }
    // Thay phương thức bằng hàm xuất sang trang; `impl(orig, args)` chạy với `this` = đối tượng của trang.
    function pageMethod(target, prop, impl) {
        const orig = target[prop];
        if (typeof orig !== 'function') return null;
        pageDefine(target, prop, {
            value: ex(function() { return impl.call(this, orig, Array.prototype.slice.call(arguments)); }),
            writable: true, configurable: true, enumerable: true
        });
        return orig;
    }
    function guard(name, fn) {
        try { fn(); patched.push(name); } catch (e) { applyErrors.push(name + ': ' + ((e && e.message) || e)); }
    }

    // ===== Nhiễu XÁC ĐỊNH theo seed của hồ sơ =====
    // Bản 4.0 dùng bộ sinh số ngẫu nhiên tuần tự => hai lần đọc cùng một canvas cho hai kết quả khác nhau, chính là dấu hiệu "có nhiễu" mà
    // các bộ dò (CreepJS, v.v.) kiểm tra. Nay nhiễu là hàm của (seed, vị trí) nên cùng nội dung => cùng kết quả, ổn định theo hồ sơ.
    function seedNow() { return (config.noiseSeed | 0) || 0x1badf00d; }
    function h32(a, b) {
        let x = (a ^ Math.imul(b | 0, 0x9E3779B1)) | 0;
        x = Math.imul(x ^ (x >>> 16), 0x85EBCA6B);
        x = Math.imul(x ^ (x >>> 13), 0xC2B2AE35);
        return (x ^ (x >>> 16)) >>> 0;
    }
    function noisyBytes(data, salt) {            // RGBA 8-bit, ~1% điểm ảnh lệch 1 đơn vị ở một kênh
        const s = seedNow() + salt;
        for (let i = 0; i + 3 < data.length; i += 4) {
            const h = h32(s, i);
            if (h % 100 === 0) {
                const k = i + ((h >>> 8) % 3);
                data[k] = data[k] === 255 ? 254 : data[k] + 1;
            }
        }
    }
    function noisyFloats(a, salt, amp) {
        const s = seedNow() + salt;
        for (let i = 0; i < a.length; i++) {
            const h = h32(s, i);
            if (h % 32 === 0) a[i] += (((h >>> 8) % 7) - 3) * amp;
        }
    }

    // ===== Múi giờ giả (độ lệch tính bằng Intl của CHÍNH content script — bản gốc chưa bị trang sửa) =====
    const dtfCache = {};
    function tzOffsetMinutes(ms, tz) {           // phút: giờ-địa-phương = UTC + giá trị này
        let f = dtfCache[tz];
        if (!f) {
            f = dtfCache[tz] = new Intl.DateTimeFormat('en-US', {
                timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric',
                hour: 'numeric', minute: 'numeric', second: 'numeric'
            });
        }
        const p = {};
        f.formatToParts(new Date(ms)).forEach(function(x) { p[x.type] = x.value; });
        const asUTC = Date.UTC(+p.year, +p.month - 1, +p.day, (+p.hour) % 24, +p.minute, +p.second);
        return Math.round((asUTC - Math.floor(ms / 1000) * 1000) / 60000);
    }

    function appVersionFor(platform) {           // Firefox: "5.0 (Windows)" / "5.0 (Macintosh)" / "5.0 (X11)" — Android thật là "5.0 (Android 14)"
        const p = String(platform || '');
        if (/^Win/i.test(p)) return '5.0 (Windows)';
        if (/^Mac/i.test(p)) return '5.0 (Macintosh)';
        return '5.0 (X11)';
    }
    function oscpuFromUA(ua) {                   // "Windows NT 10.0; Win64; x64; rv:140.0" -> "Windows NT 10.0; Win64; x64"
        const m = /\(([^)]*)\)/.exec(String(ua || ''));
        if (!m) return null;
        const toks = m[1].split(';').map(function(t) { return t.trim(); })
            .filter(function(t) { return t && !/^rv:/.test(t) && t !== 'Macintosh' && t !== 'X11'; });
        return toks.length ? toks.join('; ') : null;
    }

    const COMMON_FONTS = ['arial', 'arial black', 'arial narrow', 'calibri', 'cambria', 'comic sans ms', 'courier new', 'georgia', 'helvetica',
        'impact', 'lucida console', 'lucida sans unicode', 'microsoft sans serif', 'palatino linotype', 'segoe ui', 'tahoma', 'times new roman',
        'trebuchet ms', 'verdana'];

    // ===== Áp dụng giả mạo lên đối tượng của TRANG (chỉ một lần mỗi tài liệu; getter đọc `config` mới nhất mỗi lần gọi) =====
    function applySpoof() {
        if (!config.enabled || applied) return;
        if (!canExport) { applyErrors.push('KHÔNG có wrappedJSObject/exportFunction — không thể ghi vào trang'); applied = true; return; }
        applied = true;

        if (config.hardware) {
            guard('navigator.*', function() {
                const NP = W.Navigator.prototype;
                pageGetter(NP, 'platform', function() { return config.platform; });
                pageGetter(NP, 'hardwareConcurrency', function() { return config.hardwareConcurrency; });
                pageGetter(NP, 'maxTouchPoints', function() { return config.maxTouchPoints; });
                pageGetter(NP, 'appVersion', function() { return appVersionFor(config.platform); });
                // Firefox KHÔNG có navigator.deviceMemory — thêm nó vào hồ sơ Firefox là dấu hiệu bị giả; chỉ thêm khi UA giả là Chrome/Edge.
                if (/(Chrome|Edg)\//.test(config.userAgent || '')) pageGetter(NP, 'deviceMemory', function() { return config.deviceMemory; });
                if (config.uaSync && config.userAgent) {
                    pageGetter(NP, 'userAgent', function() { return config.userAgent; });
                    if ('oscpu' in NP) pageGetter(NP, 'oscpu', function() { return oscpuFromUA(config.userAgent); });
                }
            });
            // Mục 143: hồ sơ DESKTOP (maxTouchPoints=0) trên máy thật là điện thoại cảm ứng => các dấu hiệu cảm ứng/mạng di động vẫn lộ.
            // Gỡ khỏi trang: sự kiện/hàm tạo Touch*, thuộc tính ontouch*, navigator.connection (Firefox desktop không có).
            guard('touch+connection (desktop)', function() {
                if (config.maxTouchPoints !== 0) return;
                const del = function(obj, name) { try { if (obj && name in obj) delete obj[name]; } catch (e) {} };
                ['TouchEvent', 'Touch', 'TouchList'].forEach(function(n) { del(W, n); });
                ['ontouchstart', 'ontouchend', 'ontouchmove', 'ontouchcancel'].forEach(function(n) {
                    [W.Window && W.Window.prototype, W.HTMLElement && W.HTMLElement.prototype, W.Document && W.Document.prototype, W.Element && W.Element.prototype]
                        .forEach(function(t) { del(t, n); });
                    del(W, n);
                });
                ['connection', 'mozConnection'].forEach(function(n) { del(W.Navigator && W.Navigator.prototype, n); });
            });
            guard('screen.*', function() {
                const SP = W.Screen.prototype;
                pageGetter(SP, 'width', function() { return config.screenWidth; });
                pageGetter(SP, 'height', function() { return config.screenHeight; });
                pageGetter(SP, 'availWidth', function() { return config.screenWidth; });
                pageGetter(SP, 'availHeight', function() { return config.screenHeight - 40; });
                pageGetter(SP, 'colorDepth', function() { return config.colorDepth; });
                pageGetter(SP, 'pixelDepth', function() { return config.colorDepth; });
                pageGetter(W, 'devicePixelRatio', function() { return config.pixelRatio; });
                // CỐ Ý KHÔNG đặt innerWidth/innerHeight/outerWidth/outerHeight: bản 4.0 đặt chúng bằng độ phân giải màn hình giả; khi ghi đè thật sự có
                // hiệu lực, mọi trang tính bố cục theo window.innerWidth (Colab, Drive...) sẽ vỡ vì viewport thật chỉ vài trăm px.
            });
        }

        if (config.spoofLocale) {
            guard('navigator.language(s)', function() {
                const NP = W.Navigator.prototype;
                pageGetter(NP, 'language', function() { return config.language; });
                // Mảng đóng băng, CÙNG đối tượng giữa các lần đọc; tạo lại chỉ khi danh sách ngôn ngữ ĐỔI (VPN đổi quốc gia) — Mục 140.
                let langKey = null, langArr = null;
                pageGetter(NP, 'languages', function() {
                    const k = (config.languages || []).join('|');
                    if (k !== langKey) {
                        langKey = k;
                        const a = new W.Array();
                        (config.languages || []).forEach(function(l) { a.push(l); });
                        W.Object.freeze(a);
                        langArr = a;
                    }
                    return langArr;
                });
            });
            guard('Date.getTimezoneOffset', function() {
                const getTime = W.Date.prototype.getTime;
                pageMethod(W.Date.prototype, 'getTimezoneOffset', function(orig, args) {
                    const t = getTime.call(this);
                    if (t !== t) return NaN;
                    return -tzOffsetMinutes(t, config.timezone);
                });
            });
            guard('Intl.resolvedOptions', function() {
                pageMethod(W.Intl.DateTimeFormat.prototype, 'resolvedOptions', function(orig, args) {
                    const ro = orig.apply(this, args);
                    try { ro.timeZone = config.timezone; ro.locale = config.locale; } catch (e) {}
                    return ro;
                });
            });
            // Mục 143: các hàm đọc giờ cục bộ (getHours/getDate/...) vẫn theo múi giờ THẬT => lệch với getTimezoneOffset/toString đã giả.
            guard('Date.get* local fields', function() {
                const getTime = W.Date.prototype.getTime;
                const fields = { getHours: 'getUTCHours', getMinutes: 'getUTCMinutes', getSeconds: 'getUTCSeconds', getDate: 'getUTCDate',
                                 getDay: 'getUTCDay', getMonth: 'getUTCMonth', getFullYear: 'getUTCFullYear' };
                Object.keys(fields).forEach(function(m) {
                    pageMethod(W.Date.prototype, m, function(orig, args) {
                        const t = getTime.call(this);
                        if (t !== t) return NaN;
                        return new Date(t + tzOffsetMinutes(t, config.timezone) * 60000)[fields[m]]();
                    });
                });
            });
            // Mục 142 (còn thiếu từ 139.3): Date.toString/toDateString/toTimeString và toLocale*String lộ múi giờ THẬT dù getTimezoneOffset đã giả.
            guard('Date.toString/toLocale*', function() {
                const getTime = W.Date.prototype.getTime;
                const pad = function(n) { return (n < 10 ? '0' : '') + n; };
                const partsOf = function(ms) {
                    const tz = config.timezone;
                    const p = {};
                    new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'short', month: 'short', day: '2-digit', year: 'numeric',
                        hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(ms))
                        .forEach(function(x) { p[x.type] = x.value; });
                    let name = '';
                    try {
                        new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'long' }).formatToParts(new Date(ms))
                            .forEach(function(x) { if (x.type === 'timeZoneName') name = x.value; });
                    } catch (e) {}
                    const off = tzOffsetMinutes(ms, tz), a = Math.abs(off);
                    const gmt = 'GMT' + (off < 0 ? '-' : '+') + pad(Math.floor(a / 60)) + pad(a % 60);
                    return { date: p.weekday + ' ' + p.month + ' ' + p.day + ' ' + p.year,
                             time: pad(+p.hour % 24) + ':' + p.minute + ':' + p.second + ' ' + gmt + (name ? ' (' + name + ')' : '') };
                };
                const defs = { toString: 2, toDateString: 0, toTimeString: 1 };
                Object.keys(defs).forEach(function(m) {
                    pageMethod(W.Date.prototype, m, function(orig, args) {
                        const t = getTime.call(this);
                        if (t !== t) return orig.apply(this, args);
                        const q = partsOf(t);
                        return defs[m] === 2 ? q.date + ' ' + q.time : (defs[m] === 0 ? q.date : q.time);
                    });
                });
                ['toLocaleString', 'toLocaleDateString', 'toLocaleTimeString'].forEach(function(m) {
                    pageMethod(W.Date.prototype, m, function(orig, args) {
                        const o = new W.Object();
                        const src = args[1];
                        if (src && typeof src === 'object') { Object.keys(src).forEach(function(k) { o[k] = src[k]; }); }
                        if (o.timeZone === undefined) o.timeZone = config.timezone;
                        return orig.call(this, args[0], o);
                    });
                });
            });
        }

        if (config.canvas) {
            guard('canvas.toDataURL/toBlob', function() {
                const CP = W.HTMLCanvasElement.prototype;
                function noisyCopy(src) {            // KHÔNG sửa canvas gốc của trang: vẽ ra bản sao rồi thêm nhiễu
                    const w = src.width, h = src.height;
                    if (!w || !h) return null;
                    const tmp = document.createElement('canvas');
                    tmp.width = w; tmp.height = h;
                    const c = tmp.getContext('2d');
                    c.drawImage(src, 0, 0);
                    const img = c.getImageData(0, 0, w, h);
                    noisyBytes(img.data, 1);
                    c.putImageData(img, 0, 0);
                    return tmp;
                }
                pageMethod(CP, 'toDataURL', function(orig, args) {
                    try { const t = noisyCopy(this); if (t) return orig.apply(t, args); } catch (e) {}
                    return orig.apply(this, args);
                });
                pageMethod(CP, 'toBlob', function(orig, args) {
                    try { const t = noisyCopy(this); if (t) return orig.apply(t, args); } catch (e) {}
                    return orig.apply(this, args);
                });
            });
            guard('canvas.getImageData/measureText', function() {
                const RP = W.CanvasRenderingContext2D.prototype;
                pageMethod(RP, 'getImageData', function(orig, args) {
                    const img = orig.apply(this, args);
                    try { noisyBytes(img.data, 2); } catch (e) {}
                    return img;
                });
                pageMethod(RP, 'measureText', function(orig, args) {
                    const m = orig.apply(this, args);
                    try {
                        const text = String(args[0]);
                        let hs = 0;
                        for (let i = 0; i < text.length; i++) hs = (Math.imul(hs, 31) + text.charCodeAt(i)) | 0;
                        const delta = ((h32(seedNow() + 3, hs) % 1000) / 1000 - 0.5) * 0.02;
                        pageDefine(m, 'width', { value: m.width + delta, writable: true, configurable: true, enumerable: true });
                    } catch (e) {}
                    return m;
                });
            });
        }

        if (config.hardware && config.webglVendor) {
            // Bản 4.0 chỉ giả 0x1F00/0x1F01 (VENDOR/RENDERER đã bị Firefox che thành "Mozilla") và KHÔNG giả 0x9245/0x9246 (UNMASKED_VENDOR/RENDERER —
            // chính hai giá trị lộ GPU thật như "Adreno 750"), lại còn giấu extension khỏi getSupportedExtensions trong khi getExtension vẫn trả về.
            [['WebGLRenderingContext'], ['WebGL2RenderingContext']].forEach(function(n) {
                guard('webgl.' + n[0], function() {
                    if (!W[n[0]]) return;
                    const P = W[n[0]].prototype;
                    pageMethod(P, 'getParameter', function(orig, args) {
                        if (args[0] === 0x9245) return config.webglVendor;
                        if (args[0] === 0x9246) return config.webglRenderer;
                        return orig.apply(this, args);
                    });
                    pageMethod(P, 'readPixels', function(orig, args) {
                        const r = orig.apply(this, args);
                        try { const px = args[6]; if (px && typeof px.length === 'number') noisyBytes(px, 4); } catch (e) {}
                        return r;
                    });
                });
            });
        }

        if (config.audio) {
            guard('audio', function() {
                if (W.AudioBuffer) {
                    const seen = new WeakSet();
                    pageMethod(W.AudioBuffer.prototype, 'getChannelData', function(orig, args) {
                        const arr = orig.apply(this, args);
                        try { if (!seen.has(arr)) { seen.add(arr); noisyFloats(arr, 5, 1e-7); } } catch (e) {}
                        return arr;
                    });
                    pageMethod(W.AudioBuffer.prototype, 'copyFromChannel', function(orig, args) {
                        const r = orig.apply(this, args);
                        try { noisyFloats(args[0], 5, 1e-7); } catch (e) {}
                        return r;
                    });
                }
                if (W.AnalyserNode) {
                    ['getFloatFrequencyData', 'getFloatTimeDomainData'].forEach(function(m) {
                        pageMethod(W.AnalyserNode.prototype, m, function(orig, args) {
                            const r = orig.apply(this, args);
                            try { noisyFloats(args[0], 6, m === 'getFloatFrequencyData' ? 1e-3 : 1e-7); } catch (e) {}
                            return r;
                        });
                    });
                }
            });
        }

        if (config.font) {
            guard('fonts.check', function() {
                if (!W.FontFaceSet) return;
                pageMethod(W.FontFaceSet.prototype, 'check', function(orig, args) {
                    try {
                        const f = String(args[0]).toLowerCase();
                        for (let i = 0; i < COMMON_FONTS.length; i++) if (f.indexOf(COMMON_FONTS[i]) !== -1) return true;
                    } catch (e) {}
                    return orig.apply(this, args);
                });
            });
        }

        if (config.webrtc) {
            guard('webrtc', function() {
                ['RTCPeerConnection', 'webkitRTCPeerConnection', 'RTCDataChannel', 'RTCSessionDescription', 'RTCIceCandidate', 'RTCSctpTransport',
                 'RTCDtlsTransport', 'RTCIceTransport', 'RTCRtpSender', 'RTCRtpReceiver'].forEach(function(p) {
                    if (p in W) pageGetter(W, p, function() { return undefined; });
                });
            });
        }
        // Bản 4.0 còn bọc `performance.now` bằng nhiễu ngẫu nhiên: khi có hiệu lực thật, giá trị có thể LÙI THỜI GIAN và làm hỏng mọi mã đo thời gian
        // (hoạt ảnh, Monaco...). Đã bỏ; Firefox tự làm tròn bộ đếm thời gian.
    }

    // ===== Tự kiểm tra: đọc lại GIÁ TRỊ MÀ TRANG THẤY (qua wrappedJSObject) và gửi về native để ghi log =====
    function selfTest(port) {
        if (selfTested) return;
        selfTested = true;
        try {
            if (window !== window.top) return;                       // chỉ khung trên cùng
            const host = location.hostname || location.protocol;
            if (!/^https?:$/.test(location.protocol)) return;
            const parts = [];
            const chk = function(name, got, want) {
                parts.push(name + '=' + got + (String(got) === String(want) ? ' OK' : ' SAI(cần ' + want + ')'));
            };
            if (!canExport) {
                port.postMessage({ action: 'selftest', text: host + ' :: KHÔNG có wrappedJSObject/exportFunction => giả mạo KHÔNG thể có hiệu lực' });
                return;
            }
            const N = W.navigator;
            if (config.hardware) {
                chk('platform', N.platform, config.platform);
                chk('cores', N.hardwareConcurrency, config.hardwareConcurrency);
                chk('màn', W.screen.width + 'x' + W.screen.height, config.screenWidth + 'x' + config.screenHeight);
                chk('dpr', W.devicePixelRatio, config.pixelRatio);
                chk('appVersion', N.appVersion, appVersionFor(config.platform));
                if (config.uaSync && config.userAgent) chk('ua', N.userAgent === config.userAgent ? 'khớp' : 'LỆCH', 'khớp');
            }
            if (config.spoofLocale) {
                chk('lang', N.language, config.language);
                chk('tz', new W.Intl.DateTimeFormat().resolvedOptions().timeZone, config.timezone);
                parts.push('tzOffset=' + new W.Date().getTimezoneOffset());
                try {   // Mục 144: kiểm tra bản MAIN world (hàm tạo Date, Intl mặc định, toString) từ góc nhìn của TRANG
                    const j1 = Date.UTC(2026, 0, 1, 0, 0, 0);
                    const wantLocal = j1 - tzOffsetMinutes(j1, config.timezone) * 60000;
                    chk('Date(cục bộ)', new W.Date(2026, 0, 1, 0, 0, 0).getTime() === wantLocal ? 'OK' : 'LỆCH', 'OK');
                    const want = new Intl.DateTimeFormat('en-US', { timeZone: config.timezone, hour: 'numeric', hourCycle: 'h23' }).format(0);
                    chk('DTF.format', new W.Intl.DateTimeFormat('en-US', { hour: 'numeric', hourCycle: 'h23' }).format(0), want);
                    const off0 = tzOffsetMinutes(0, config.timezone), a0 = Math.abs(off0);
                    const wantGmt = (off0 < 0 ? '-' : '+') + ('0' + Math.floor(a0 / 60)).slice(-2) + ('0' + (a0 % 60)).slice(-2);
                    const mm = /GMT([+-]\d{4})/.exec(String(new W.Date(0).toString()));
                    chk('toString', mm ? mm[1] : 'không có GMT', wantGmt);
                } catch (e) { parts.push('kiểm MAIN lỗi: ' + e); }
            }
            if (config.webrtc) chk('RTCPeerConnection', typeof W.RTCPeerConnection, 'undefined');
            // WebGL: tạo ngữ cảnh tốn kém => chỉ trên trang kiểm tra fingerprint quen thuộc hoặc ~10% số trang
            if (config.hardware && config.webglVendor && (/browserleaks|creepjs|amiunique|pixelscan|sannysoft|coveryourtracks|whoer|fingerprint|abrahamjuliot/i.test(host) || Math.random() < 0.1)) {
                try {
                    const gl = W.document.createElement('canvas').getContext('webgl');
                    const ext = gl && gl.getExtension('WEBGL_debug_renderer_info');
                    if (ext) chk('gpu', gl.getParameter(ext.UNMASKED_RENDERER_WEBGL), config.webglRenderer);
                    else parts.push('gpu=(không có extension)');
                } catch (e) { parts.push('gpu lỗi: ' + e); }
            }
            if ((config.hardware || config.spoofLocale) && (/browserleaks|creepjs|amiunique|pixelscan|sannysoft|coveryourtracks|whoer|fingerprint|abrahamjuliot/i.test(host) || Math.random() < 0.1)) {
                try {   // Worker: tạo worker blob từ trang rồi hỏi nó thấy gì (kết quả gửi riêng một dòng log)
                    const code = 'postMessage([Intl.DateTimeFormat().resolvedOptions().timeZone,navigator.hardwareConcurrency,navigator.platform,navigator.language,new Date(0).toString()])';
                    const blob = new W.Blob(cloneInto([code], W), cloneInto({ type: 'text/javascript' }, W));
                    const wk = new W.Worker(W.URL.createObjectURL(blob));
                    wk.onmessage = exportFunction(function(ev) {
                        try {
                            const d = ev.data;
                            port.postMessage({ action: 'selftest', text: host + ' :: [worker] tz=' + d[0] + ' ; cores=' + d[1] + ' ; platform=' + d[2] + ' ; lang=' + d[3] + ' ; ' + d[4] +
                                ' ; mong đợi tz=' + (config.spoofLocale ? config.timezone : '(không giả)') + ' cores=' + (config.hardware ? config.hardwareConcurrency : '(không giả)') });
                        } catch (e2) {}
                        try { wk.terminate(); } catch (e3) {}
                    }, W);
                    wk.onerror = exportFunction(function() { try { port.postMessage({ action: 'selftest', text: host + ' :: [worker] LỖI khi tạo worker thử' }); } catch (e4) {} }, W);
                } catch (e) { parts.push('worker test lỗi: ' + e); }
            }
            parts.push('đã áp ' + patched.length + ' mục' + (applyErrors.length ? '; LỖI ' + applyErrors.length + ': ' + applyErrors.slice(0, 4).join(' | ') : ''));
            port.postMessage({ action: 'selftest', text: host + ' :: ' + parts.join(' ; ') });
        } catch (e) {
            try { port.postMessage({ action: 'selftest', text: 'selftest lỗi: ' + ((e && e.message) || e) }); } catch (e2) {}
        }
    }

    function setupPort() {
        try {
            const port = browser.runtime.connectNative("browser");
            port.onMessage.addListener(function(msg) {
                if (msg && msg.config) {
                    config = Object.assign({}, config, msg.config);
                    applySpoof();
                    cacheConfigForEarlyApply(msg.config);
                    if (config.enabled) setTimeout(function() { selfTest(port); }, 150);
                }
            });
            port.postMessage({ action: "getConfig" });
        } catch (e) {
            console.log("Fingerprint spoof: cannot connect to native port");
        }
    }

    // Mục 144: ÁP SỚM bằng cấu hình nhúng sẵn (do background.js đăng ký), TRƯỚC khi native trả lời — chỉ khi UA thật của tab khớp UA trong cấu hình
    // (tab bình thường). Tab bật "máy tính"/chọn "di động" thủ công có UA khác => cấu hình theo-tab sẽ khác, nên KHÔNG áp sớm, chờ native như cũ.
    let earlyJson = null;
    try {
        if (typeof __LB_FP_CFG !== 'undefined' && __LB_FP_CFG && __LB_FP_CFG.enabled && __LB_FP_CFG.userAgent &&
            __LB_FP_CFG.userAgent === navigator.userAgent) {
            earlyJson = JSON.stringify(__LB_FP_CFG);
            config = Object.assign({}, config, __LB_FP_CFG);
            applySpoof();
        }
    } catch (e) { applyErrors.push('áp sớm lỗi: ' + ((e && e.message) || e)); }

    // Lưu cấu hình hợp lệ gần nhất (chỉ tab bình thường) để lần tải trang SAU được áp ngay ở document_start.
    function cacheConfigForEarlyApply(cfg) {
        try {
            if (!cfg || !cfg.enabled || !cfg.userAgent || cfg.userAgent !== navigator.userAgent) return;
            const json = JSON.stringify(cfg);
            if (json === earlyJson) return;
            browser.storage.local.set({ lb_fp_cfg: json }).catch(function() {});
        } catch (e) {}
    }

    if (typeof browser !== 'undefined') {
        setupPort();
    }

    (function setupLargePasteMonacoBypass() {
        const LARGE_PASTE_THRESHOLD = 20000; // ~20k ký tự — đủ nhỏ để không ảnh hưởng paste bình thường, đủ lớn để bắt đúng trường hợp gây đơ đã quan sát được

        /**
         * MỞ RỘNG (mục 80 PROJECT_STATUS.md — người dùng báo "dùng bộ nhớ
         * tạm của bàn phím dán vào VẪN đơ" dù mục 75 đã chặn sự kiện
         * `paste`). Nguyên nhân rất có thể: bảng nhớ tạm CỦA BÀN PHÍM ẢO
         * (GBoard...) khi người dùng chạm để chèn 1 mục đã copy trước đó,
         * KHÔNG LUÔN bắn ra sự kiện `paste` chuẩn của trình duyệt — nhiều
         * bàn phím ảo chèn text qua cơ chế IME (`InputConnection.
         * commitText()` ở tầng Android), Gecko dịch việc này thành sự kiện
         * `beforeinput`/`input` với `inputType: 'insertFromPaste'` (đúng
         * chuẩn Input Events Level 2 — trình duyệt DÙNG inputType này
         * chính xác cho trường hợp "chèn giống như dán nhưng không qua
         * đường clipboard event truyền thống") — KHÔNG bắn `paste` — nên
         * listener ở mục 75 không hề được gọi tới, giải thích đúng khớp
         * triệu chứng "mục 75 không có tác dụng cho đúng trường hợp này".
         *
         * Đã tách logic tắt/bật tokenize dùng chung thành `applyBypass()`,
         * gọi từ CẢ 2 nơi: sự kiện `paste` (giữ nguyên, bắt Ctrl+V/menu dán
         * hệ thống thật) VÀ sự kiện `beforeinput` với
         * `inputType === 'insertFromPaste'` (bắt thêm trường hợp bảng nhớ
         * tạm bàn phím ảo/IME). `beforeinput` cho `text` qua `event.data`
         * (chuỗi, không phải `clipboardData`) — chỉ có sẵn TRỰC TIẾP kích
         * thước qua `event.data.length`, không cần đọc `clipboardData`.
         */
        function applyBypass(text) {
            try {
                if (typeof window.monaco === 'undefined' || !window.monaco.editor || !window.monaco.editor.getEditors) return;
                if (!text || text.length < LARGE_PASTE_THRESHOLD) return;

                const editors = window.monaco.editor.getEditors();
                let target = null;
                for (const ed of editors) {
                    const domNode = ed.getDomNode && ed.getDomNode();
                    if (domNode && domNode.contains(document.activeElement)) { target = ed; break; }
                }
                if (!target) return;
                const model = target.getModel && target.getModel();
                if (!model) return;

                const originalLanguage = model.getLanguageId ? model.getLanguageId() : (model.getModeId ? model.getModeId() : null);
                if (!originalLanguage || originalLanguage === 'plaintext') return; // đã plaintext sẵn thì không có gì để tắt

                window.monaco.editor.setModelLanguage(model, 'plaintext');
                console.log('[colablive] tạm tắt tokenize Monaco (chèn ' + text.length + ' ký tự) để tránh đơ trên Gecko');

                // Khôi phục ngôn ngữ gốc SAU KHI nội dung đã chèn xong —
                // dùng onDidChangeContent (1 lần) thay vì setTimeout cố
                // định, vì thời điểm insertion thật sự hoàn tất phụ thuộc
                // độ dài text, không đoán trước được 1 con số cố định đủ
                // an toàn cho mọi trường hợp.
                const disposable = model.onDidChangeContent(function() {
                    disposable.dispose();
                    // Đợi thêm 1 khung hình để Monaco xử lý xong đợt render
                    // đầu (không tokenize) trước khi bật lại tokenize —
                    // tránh 2 việc nặng chồng lên nhau cùng lúc.
                    requestAnimationFrame(function() {
                        try {
                            window.monaco.editor.setModelLanguage(model, originalLanguage);
                            console.log('[colablive] đã khôi phục ngôn ngữ Monaco: ' + originalLanguage);
                        } catch (e) { /* model có thể đã bị dispose nếu người dùng đổi cell rất nhanh — bỏ qua */ }
                    });
                });
                // Lưới an toàn: nếu onDidChangeContent vì lý do gì đó không
                // bao giờ bắn (paste bị chặn giữa chừng, lỗi khác...), vẫn
                // tự khôi phục ngôn ngữ sau 15s để không kẹt vĩnh viễn ở
                // plaintext (mất tô màu cú pháp) chỉ vì 1 lần lỗi.
                setTimeout(function() {
                    try { disposable.dispose(); } catch (e) {}
                    try {
                        if (model.getLanguageId && model.getLanguageId() === 'plaintext' && originalLanguage !== 'plaintext') {
                            window.monaco.editor.setModelLanguage(model, originalLanguage);
                        }
                    } catch (e) {}
                }, 15000);
            } catch (e) {
                console.log('[colablive] largePasteMonacoBypass lỗi (bỏ qua, không chặn paste bình thường): ' + e.message);
            }
        }

        document.addEventListener('paste', function(event) {
            const text = event.clipboardData ? event.clipboardData.getData('text/plain') : '';
            applyBypass(text);
        }, true); // capture=true — chạy TRƯỚC listener 'paste' riêng của Monaco, kịp đổi ngôn ngữ trước khi Monaco bắt đầu tokenize nội dung vừa chèn

        /**
         * SỬA BUG THẬT (đối chiếu Input Events Level 2 spec + WPT test
         * chính thức của Chromium/WebKit — `assert_equals(event.data, null,
         * "beforeinput.data should be null")` cho đúng `inputType:
         * 'insertFromPaste'`): nhánh `beforeinput` thêm ở mục 80.4 đọc
         * `event.data` — SAI FIELD. Theo spec, khi nội dung chèn đến từ 1
         * nguồn dạng "transfer" (paste/kéo-thả — tức CHÍNH XÁC trường hợp
         * bàn phím ảo commit lại 1 mục đã copy), trình duyệt đặt dữ liệu ở
         * `event.dataTransfer` (1 `DataTransfer`), còn `event.data` LUÔN LÀ
         * `null` — chỉ có giá trị chuỗi cho các inputType gõ trực tiếp như
         * 'insertText'. Do đó `event.data || ''` ở bản cũ LUÔN ra chuỗi
         * rỗng cho đúng trường hợp cần bắt (dán bằng bộ nhớ tạm bàn phím ảo)
         * → `text.length < LARGE_PASTE_THRESHOLD` luôn đúng (0 < 20000) →
         * `applyBypass()` return NGAY LẬP TỨC, KHÔNG BAO GIỜ tắt tokenize —
         * toàn bộ nhánh mục 80.4 là code chết từ lúc viết ra, khớp chính
         * xác với việc người dùng vẫn thấy đơ y như trước khi có bản vá đó.
         */
        /**
         * MỞ RỘNG THÊM (bug vẫn còn sau khi sửa mục 86.2 — người dùng xác
         * nhận CHỈ đúng trang Colab bị đơ, không phải cả trình duyệt, nên
         * không phải do content script này chạy sai/vòng lặp vô hạn gì —
         * đúng hướng "applyBypass() không được gọi tới cho đúng đường bị
         * đơ", chỉ là VẪN CHƯA bắt đúng inputType).
         *
         * Xem lại đúng cách bàn phím ảo (GBoard...) chèn 1 mục đã copy từ
         * "bộ nhớ tạm bàn phím" (khác với thanh gợi ý clipboard của
         * Android — đây là tính năng RIÊNG của bàn phím, không đi qua
         * Android ClipboardManager/hệ thống clipboard chuẩn): thao tác này
         * chỉ đơn thuần là 1 lần gọi `InputConnection.commitText(text, ...)`
         * ở tầng Android — với Gecko, đây là hành vi CHÈN TEXT THÔNG
         * THƯỜNG (giống gõ phím, chỉ khác là chèn nhiều ký tự 1 lần), ĐÚNG
         * CHUẨN Input Events Level 2 sẽ ra `inputType: 'insertText'`
         * (đôi khi `'insertCompositionText'` nếu đang trong phiên IME
         * composing) — KHÔNG PHẢI `'insertFromPaste'` (inputType đó chỉ
         * dành riêng cho paste THẬT qua clipboard event/execCommand
         * paste). Bộ lọc cũ chỉ bắt `insertFromPaste`/
         * `insertFromPasteAsQuotation` nên bỏ sót đúng con đường này —
         * `applyBypass()` không bao giờ được gọi, tokenize Monaco không
         * bao giờ bị tắt, đơ y như trước khi có mục 86.2.
         *
         * Mở rộng bắt thêm `insertText`/`insertCompositionText` — đọc
         * `event.data` (ĐÚNG field cho 2 inputType này theo spec, khác với
         * `insertFromPaste` dùng `dataTransfer`). Không ảnh hưởng gõ phím
         * bình thường: `applyBypass()` đã tự return ngay nếu
         * `text.length < LARGE_PASTE_THRESHOLD` (mỗi phím gõ ra 1 ký tự,
         * không bao giờ chạm ngưỡng 20000).
         */
        document.addEventListener('beforeinput', function(event) {
            var isPasteType = event.inputType === 'insertFromPaste' || event.inputType === 'insertFromPasteAsQuotation';
            var isTypeType = event.inputType === 'insertText' || event.inputType === 'insertCompositionText';
            if (!isPasteType && !isTypeType) return;
            var text = '';
            try {
                if (isPasteType && event.dataTransfer) text = event.dataTransfer.getData('text/plain') || '';
            } catch (e) {}
            if (!text && event.data) text = event.data;
            applyBypass(text);
        }, true);
    })();

})();
