// Muc 134: thay cookie TRUC TIEP trong Gecko dang chay (khong can dong khe). App gui {type:"cookies_apply", id, base, private, cookies:[...]}
// qua kenh native "browser"; addon xoa cookie cua mien `base` (va mien con) trong kho thuong/an danh roi ghi bo cookie moi, tra {type:"cookies_result"}.
// CHI dung duoc khi khe o che do cookie CHUNG (khong dat contextId): khi co contextId, tab dung kho rieng ma API cookies khong thay.
var port = null;
var retries = 0;

function send(m) { try { if (port) port.postMessage(m); } catch (e) {} }

function connect() {
  try {
    port = browser.runtime.connectNative("browser");
    port.onMessage.addListener(onCmd);
    port.onDisconnect.addListener(function () {
      port = null;
      // App co the chua kip gan delegate luc addon khoi dong: thu lai vai lan.
      if (retries++ < 20) setTimeout(connect, 1500);
    });
  } catch (e) {
    if (retries++ < 20) setTimeout(connect, 1500);
  }
}

async function pickStore(isPrivate) {
  var ids = [];
  try {
    var stores = await browser.cookies.getAllCookieStores();
    ids = stores.map(function (s) { return s.id; });
  } catch (e) {}
  var priv = ids.filter(function (i) { return /private/i.test(i); })[0];
  var def = ids.filter(function (i) { return !/private/i.test(i); })[0];
  return isPrivate ? (priv || "firefox-private") : (def || "firefox-default");
}

function urlFor(c) {
  var host = String(c.domain || "").replace(/^\./, "");
  return (c.secure ? "https://" : "http://") + host + (c.path || "/");
}

async function onCmd(msg) {
  if (!msg || msg.type !== "cookies_apply") return;
  var res = { type: "cookies_result", id: msg.id, ok: false, removed: 0, set: 0, failed: 0, store: null, error: null, lastError: null };
  try {
    var store = await pickStore(!!msg["private"]);
    res.store = store;
    var existing = await browser.cookies.getAll({ domain: msg.base, storeId: store });
    for (var i = 0; i < existing.length; i++) {
      try {
        await browser.cookies.remove({ url: urlFor(existing[i]), name: existing[i].name, storeId: store });
        res.removed++;
      } catch (e) { res.lastError = String(e); }
    }
    var list = msg.cookies || [];
    for (var j = 0; j < list.length; j++) {
      var c = list[j];
      var det = { url: urlFor(c), name: c.name, value: c.value, path: c.path || "/", secure: !!c.secure, httpOnly: !!c.httpOnly, storeId: store };
      if (!c.hostOnly) det.domain = c.domain;
      if (c.sameSite === "no_restriction" || c.sameSite === "lax" || c.sameSite === "strict") det.sameSite = c.sameSite;
      if (!c.session && c.expirationDate) det.expirationDate = c.expirationDate;
      try {
        var r = await browser.cookies.set(det);
        if (r) res.set++; else res.failed++;
      } catch (e) { res.failed++; res.lastError = String(e); }
    }
    res.ok = true;
  } catch (e) {
    res.error = String(e);
  }
  send(res);
}

connect();
