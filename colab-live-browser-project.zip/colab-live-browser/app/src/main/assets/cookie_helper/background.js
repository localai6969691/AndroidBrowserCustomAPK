// Muc 134/138: thay cookie TRUC TIEP trong Gecko dang chay (khong can dong khe). App gui {type:"cookies_apply", id, base, private, cookies:[...]}
// qua kenh native "browser"; addon xoa cookie cua mien `base` (va mien con) trong kho thuong/an danh roi ghi bo cookie moi, tra {type:"cookies_result"}.
// CHI dung duoc khi khe o che do cookie CHUNG (khong dat contextId): khi co contextId, tab dung kho rieng ma API cookies khong thay.
// Muc 138: kenh tu noi lai den khi app tra "ack" (tranh viec noi truoc khi app kip gan delegate).
var port = null, acked = false, attempts = 0;

function send(m) { try { if (port) port.postMessage(m); } catch (e) {} }

function connect() {
  if (acked) return;
  try { if (port) { try { port.disconnect(); } catch (e) {} port = null; } } catch (e) {}
  try {
    port = browser.runtime.connectNative("browser");
    port.onMessage.addListener(function (m) {
      if (m && m.type === "ack") { acked = true; startGeo(); return; }
      if (m && m.type === "geo_refresh") { geo(); return; }
      if (m && m.type === "news_refresh") { news(true); return; }
      onCmd(m);
    });
    port.onDisconnect.addListener(function () {
      port = null; acked = false; attempts = 0;
      setTimeout(connect, 1500);
    });
    port.postMessage({ type: "hello", who: "cookie_helper" });
  } catch (e) {}
  if (++attempts < 60) setTimeout(connect, 2000);
}


// ===== Muc 140: IP/quoc gia/mui gio ma trinh duyet DI RA NGOAI (tu khop fingerprint voi VPN/proxy bat ky) =====
// Hoi mot dich vu geo-IP qua CHINH duong mang cua trinh duyet (neu co VPN/proxy thi la IP cua VPN) — khong can biet addon nao dang chay.
// Dich vu: ipapi.co (co ca ngon ngu) roi du phong ipwho.is. Chay khi nhan ack, moi 5 phut, va khi app yeu cau (addon doi trang thai).
var COUNTRY_LANG = { VN: "vi-VN", US: "en-US", GB: "en-GB", DE: "de-DE", FR: "fr-FR", JP: "ja-JP", KR: "ko-KR", CN: "zh-CN", TW: "zh-TW", HK: "zh-HK",
  SG: "en-SG", IN: "en-IN", RU: "ru-RU", UA: "uk-UA", TR: "tr-TR", BR: "pt-BR", PT: "pt-PT", ES: "es-ES", MX: "es-MX", IT: "it-IT", NL: "nl-NL",
  PL: "pl-PL", CA: "en-CA", AU: "en-AU", TH: "th-TH", ID: "id-ID", MY: "ms-MY", PH: "en-PH", SE: "sv-SE", CH: "de-CH", AT: "de-AT", BE: "nl-BE",
  IE: "en-IE", FI: "fi-FI", NO: "nb-NO", DK: "da-DK", CZ: "cs-CZ", RO: "ro-RO", HU: "hu-HU", GR: "el-GR", IL: "he-IL", AE: "ar-AE", SA: "ar-SA",
  EG: "ar-EG", ZA: "en-ZA", AR: "es-AR", CL: "es-CL", CO: "es-CO" };

function normLangs(list, cc) {
  var first = (list && list.length) ? String(list[0]) : "";
  if (!first && cc && COUNTRY_LANG[cc]) first = COUNTRY_LANG[cc];
  if (first && first.indexOf("-") === -1 && cc) first = first + "-" + cc;      // "vi" + "VN" => "vi-VN"
  if (!first) first = "en-US";
  var base = first.split("-")[0];
  var out = [first];
  if (base !== first) out.push(base);
  if (base !== "en") { out.push("en-US"); out.push("en"); }                    // nguoi dung that thuong co them tieng Anh
  return out.filter(function (v, i) { return out.indexOf(v) === i; });
}

function fetchJson(url, ms) {
  var ctrl = new AbortController();
  var t = setTimeout(function () { ctrl.abort(); }, ms);
  return fetch(url, { cache: "no-store", signal: ctrl.signal }).then(function (r) { return r.json(); }).then(
    function (j) { clearTimeout(t); return j; }, function (e) { clearTimeout(t); throw e; });
}

var geoBusy = false, geoStarted = false;
async function geo() {
  if (geoBusy) return;
  geoBusy = true;
  try {
    var res = null;
    try {
      var a = await fetchJson("https://ipapi.co/json/", 8000);
      if (a && a.ip && a.timezone) {
        var al = String(a.languages || "").split(",").map(function (x) { return x.trim(); }).filter(Boolean);
        res = { ip: a.ip, cc: a.country_code, tz: a.timezone, langs: normLangs(al, a.country_code), src: "ipapi.co", lat: a.latitude, lon: a.longitude, city: a.city || "" };
      }
    } catch (e) {}
    if (!res) {
      try {
        var b = await fetchJson("https://ipwho.is/", 8000);
        if (b && b.success !== false && b.ip && b.timezone && b.timezone.id) {
          res = { ip: b.ip, cc: b.country_code, tz: b.timezone.id, langs: normLangs([], b.country_code), src: "ipwho.is", lat: b.latitude, lon: b.longitude, city: b.city || "" };
        }
      } catch (e) {}
    }
    if (res) send({ type: "geo", ip: res.ip, cc: res.cc || "", tz: res.tz, lang: res.langs[0], langs: res.langs, src: res.src, lat: res.lat, lon: res.lon, city: res.city });
    else send({ type: "geo_error" });
  } finally { geoBusy = false; }
}
function startGeo() {
  if (geoStarted) { geo(); news(false); return; }
  geoStarted = true;
  geo();
  news(false);
  setInterval(geo, 300000);
  setInterval(function () { news(false); }, 1800000);
}

// ===== Muc 162: tin tuc cho trang "Tab moi" =====
// Lay RSS qua CHINH duong mang cua trinh duyet (neu co VPN/proxy cua khe thi di qua do) bang addon nen (co <all_urls>, khong vuong CORS),
// gui {type:"news", items:[{t,u,i,s,p}]} ve app; app luu va dua vao trang Tab moi. Moi nguon deu co ten + lien ket goc (dieu khoan RSS yeu cau ghi nguon).
var NEWS_FEEDS = [
  { name: "VnExpress", url: "https://vnexpress.net/rss/tin-moi-nhat.rss" },
  { name: "Tuổi Trẻ", url: "https://tuoitre.vn/rss/tin-moi-nhat.rss" },
  { name: "VietNamNet", url: "https://vietnamnet.vn/rss/tin-moi-nhat.rss" },
  { name: "Thanh Niên", url: "https://thanhnien.vn/rss/home.rss" }
];
var newsBusy = false, newsLast = 0;
function fetchText(url, ms) {
  var ctrl = new AbortController();
  var t = setTimeout(function () { ctrl.abort(); }, ms);
  return fetch(url, { cache: "no-store", signal: ctrl.signal }).then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.text(); }).then(
    function (x) { clearTimeout(t); return x; }, function (e) { clearTimeout(t); throw e; });
}
function xmlText(el, tag) { var e = el.getElementsByTagName(tag)[0]; return e ? String(e.textContent || "").trim() : ""; }
function httpsify(u) { return String(u || "").replace(/^http:\/\//i, "https://"); }
async function fetchFeed(f) {
  var txt = await fetchText(f.url, 9000);
  var doc = new DOMParser().parseFromString(txt, "text/xml");
  var nodes = doc.getElementsByTagName("item");
  var out = [];
  for (var i = 0; i < nodes.length && out.length < 8; i++) {
    var it = nodes[i];
    var title = xmlText(it, "title"), link = xmlText(it, "link");
    if (!title || !/^https?:\/\//i.test(link)) continue;
    var img = "";
    var enc = it.getElementsByTagName("enclosure")[0];
    if (enc && /image/i.test(enc.getAttribute("type") || "image")) img = enc.getAttribute("url") || "";
    if (!img) { var mc = it.getElementsByTagName("media:content")[0] || it.getElementsByTagName("media:thumbnail")[0]; if (mc) img = mc.getAttribute("url") || ""; }
    if (!img) { var m = /<img[^>]+src=["']([^"']+)["']/i.exec(xmlText(it, "description")); if (m) img = m[1]; }
    out.push({ t: title.substring(0, 160), u: httpsify(link), i: httpsify(img), s: f.name, p: Date.parse(xmlText(it, "pubDate")) || 0 });
  }
  return out;
}
async function news(force) {
  var now = Date.now();
  if (newsBusy || (!force && now - newsLast < 60000)) return;
  newsBusy = true; newsLast = now;
  try {
    var lists = [];
    for (var k = 0; k < NEWS_FEEDS.length; k++) {
      try { lists.push(await fetchFeed(NEWS_FEEDS[k])); } catch (e) { lists.push([]); }
    }
    // xen ke giua cac bao cho da dang, bo trung link, toi da 12 tin
    var items = [], seen = {};
    for (var r = 0; r < 8 && items.length < 12; r++) {
      for (var j = 0; j < lists.length && items.length < 12; j++) {
        var x = lists[j][r];
        if (x && !seen[x.u]) { seen[x.u] = 1; items.push(x); }
      }
    }
    if (items.length) send({ type: "news", items: items, ts: now });
    else send({ type: "news_error" });
  } finally { newsBusy = false; }
}

async function pickStore(isPrivate) {
  var ids = [];
  try { var stores = await browser.cookies.getAllCookieStores(); ids = stores.map(function (s) { return s.id; }); } catch (e) {}
  var priv = ids.filter(function (i) { return /private/i.test(i); })[0];
  var def = ids.filter(function (i) { return !/private/i.test(i); })[0];
  return isPrivate ? (priv || "firefox-private") : (def || "firefox-default");
}

function urlFor(c) {
  var host = String(c.domain || "").replace(/^\./, "");
  return (c.secure ? "https://" : "http://") + host + (c.path || "/");
}

async function onCmd(msg) {
  if (!msg || msg.type !== "cookies_apply") return;
  var res = { type: "cookies_result", id: msg.id, ok: false, removed: 0, set: 0, failed: 0, store: null, error: null, lastError: null };
  try {
    var store = await pickStore(!!msg["private"]);
    res.store = store;
    var existing = await browser.cookies.getAll({ domain: msg.base, storeId: store });
    for (var i = 0; i < existing.length; i++) {
      try { await browser.cookies.remove({ url: urlFor(existing[i]), name: existing[i].name, storeId: store }); res.removed++; }
      catch (e) { res.lastError = String(e); }
    }
    var list = msg.cookies || [];
    for (var j = 0; j < list.length; j++) {
      var c = list[j];
      var det = { url: urlFor(c), name: c.name, value: c.value, path: c.path || "/", secure: !!c.secure, httpOnly: !!c.httpOnly, storeId: store };
      if (!c.hostOnly) det.domain = c.domain;
      if (c.sameSite === "no_restriction" || c.sameSite === "lax" || c.sameSite === "strict") det.sameSite = c.sameSite;
      if (!c.session && c.expirationDate) det.expirationDate = c.expirationDate;
      try { var r = await browser.cookies.set(det); if (r) res.set++; else res.failed++; }
      catch (e) { res.failed++; res.lastError = String(e); }
    }
    res.ok = true;
  } catch (e) { res.error = String(e); }
  send(res);
}

connect();
