// Muc 137: goi THU cac API WebExtension ngay trong trinh duyet nay va bao ket qua cho app (de ghi log). KHONG dang ky listener nao
// (khong proxy.onRequest, khong webRequest) nen khong anh huong luu luong. Ket qua cho biet BAN GECKOVIEW NAY ho tro gi — ap dung cho moi addon.
function path(p) {
  var o = browser;
  var parts = p.split(".");
  for (var i = 0; i < parts.length; i++) {
    if (o === undefined || o === null) return undefined;
    o = o[parts[i]];
  }
  return o;
}
function present(p) { return p + ": " + (path(p) !== undefined ? "co" : "KHONG co"); }
async function call(p, fn) {
  if (path(p.split("(")[0]) === undefined) return p + ": KHONG co";
  try {
    var v = await fn();
    var s = "";
    try { s = JSON.stringify(v); } catch (e) { s = String(v); }
    if (s && s.length > 120) s = s.slice(0, 120) + "...";
    return p + ": OK" + (s ? " -> " + s : "");
  } catch (e) {
    return p + ": LOI -> " + String((e && e.message) || e);
  }
}

async function runAll() {
  var out = [];
  out.push(await call("runtime.getBrowserInfo", function () { return browser.runtime.getBrowserInfo(); }));
  out.push(await call("runtime.getPlatformInfo", function () { return browser.runtime.getPlatformInfo(); }));
  // --- proxy / VPN ---
  out.push(present("proxy.onRequest"));
  out.push(present("proxy.onError"));
  out.push(await call("proxy.settings.get", function () { return browser.proxy.settings.get({}); }));
  out.push(await call("browserSettings.proxyConfig.get", function () { return browser.browserSettings.proxyConfig.get({}); }));
  out.push(await call("privacy.network.webRTCIPHandlingPolicy.get", function () { return browser.privacy.network.webRTCIPHandlingPolicy.get({}); }));
  out.push(await call("privacy.network.peerConnectionEnabled.get", function () { return browser.privacy.network.peerConnectionEnabled.get({}); }));
  // --- webRequest ---
  out.push(present("webRequest.onBeforeRequest"));
  out.push(present("webRequest.onAuthRequired"));
  out.push(present("webRequest.onBeforeSendHeaders"));
  out.push(present("webRequest.filterResponseData"));
  out.push(present("declarativeNetRequest"));
  // --- quan ly addon / cookie / tab / khac ---
  out.push(await call("management.getAll", function () { return browser.management.getAll().then(function (l) { return l.length + " addon"; }); }));
  out.push(present("management.setEnabled"));
  out.push(await call("cookies.getAllCookieStores", function () { return browser.cookies.getAllCookieStores(); }));
  out.push(await call("tabs.query", function () { return browser.tabs.query({}).then(function (l) { return l.length + " tab"; }); }));
  out.push(present("tabs.create"));
  out.push(present("windows.getAll"));
  out.push(present("webNavigation.onCompleted"));
  out.push(present("notifications.create"));
  out.push(present("downloads.download"));
  out.push(present("contextMenus.create"));
  out.push(present("alarms.create"));
  out.push(present("sidebarAction"));
  out.push(present("identity.launchWebAuthFlow"));
  out.push(await call("storage.local.get", function () { return browser.storage.local.get(null).then(function () { return "ok"; }); }));
  return out;
}

var port = null;
var retries = 0;
var results = null;

function sendResults() {
  try { if (port && results) port.postMessage({ type: "api_probe_result", results: results }); } catch (e) {}
}
function connect() {
  try {
    port = browser.runtime.connectNative("browser");
    port.onDisconnect.addListener(function () {
      port = null;
      if (retries++ < 20) setTimeout(connect, 1500);
    });
    sendResults();
  } catch (e) {
    if (retries++ < 20) setTimeout(connect, 1500);
  }
}

runAll().then(function (r) { results = r; sendResults(); }).catch(function (e) { results = ["probe loi: " + String(e)]; sendResults(); });
connect();
