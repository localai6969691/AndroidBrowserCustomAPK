// Muc 137/138: goi THU cac API WebExtension ngay trong trinh duyet nay va bao ket qua cho app (de ghi log).
// Sua o muc 138: (1) moi loi goi API co TIMEOUT (7.41 co the bi ket vi mot API treo => khong bao gio gui ket qua); (2) gui TUNG DONG, khong cho het;
// (3) kenh native tu noi lai den khi app tra "ack" (7.41 co the noi truoc khi app kip gan delegate); (4) them 2 phep thu CHUC NANG:
// proxy.onRequest va webRequest.onBeforeRequest co THUC SU duoc Gecko goi trong app nay khong (bo loc chi ap dung cho 1 URL thu nghiem, tra undefined).
var TEST_URL = "https://www.gstatic.com/generate_204";
var lines = [];
var port = null, acked = false, attempts = 0, sentUpTo = 0;

function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
function withTimeout(p, ms) {
  return Promise.race([p, new Promise(function (_, rej) { setTimeout(function () { rej(new Error("TREO > " + ms + "ms")); }, ms); })]);
}
function path(p) {
  var o = browser, parts = p.split(".");
  for (var i = 0; i < parts.length; i++) { if (o === undefined || o === null) return undefined; o = o[parts[i]]; }
  return o;
}
function flush() {
  try {
    if (!port || !acked) return;
    while (sentUpTo < lines.length) { port.postMessage({ type: "api_probe_line", i: sentUpTo, text: lines[sentUpTo] }); sentUpTo++; }
  } catch (e) {}
}
function add(s) { lines.push(s); flush(); }
function present(p) { add(p + ": " + (path(p) !== undefined ? "co" : "KHONG co")); }
async function call(name, fn) {
  if (path(name) === undefined) { add(name + ": KHONG co"); return; }
  try {
    var v = await withTimeout(Promise.resolve().then(fn), 6000);
    var s = ""; try { s = JSON.stringify(v); } catch (e) { s = String(v); }
    if (s && s.length > 140) s = s.slice(0, 140) + "...";
    add(name + ": OK" + (s ? " -> " + s : ""));
  } catch (e) { add(name + ": LOI -> " + String((e && e.message) || e)); }
}

function connect() {
  if (acked) return;
  try { if (port) { try { port.disconnect(); } catch (e) {} port = null; } } catch (e) {}
  try {
    port = browser.runtime.connectNative("browser");
    port.onMessage.addListener(function (m) { if (m && m.type === "ack") { acked = true; flush(); } });
    port.onDisconnect.addListener(function () { port = null; });
    port.postMessage({ type: "hello", who: "api_probe" });
  } catch (e) {}
  if (++attempts < 40) setTimeout(connect, 2000);
}

async function functionalProxy() {
  if (!(browser.proxy && browser.proxy.onRequest)) { add("[CHUC NANG] proxy.onRequest: KHONG co API"); return; }
  var count = 0, first = null, err = null;
  var l = function (d) { count++; if (!first) first = d.url; return undefined; };
  try { browser.proxy.onRequest.addListener(l, { urls: [TEST_URL] }); } catch (e) { add("[CHUC NANG] proxy.onRequest.addListener LOI -> " + String(e)); return; }
  try { await withTimeout(fetch(TEST_URL, { cache: "no-store" }), 9000); } catch (e) { err = String(e); }
  await sleep(500);
  try { browser.proxy.onRequest.removeListener(l); } catch (e) {}
  add("[CHUC NANG] proxy.onRequest: listener duoc Gecko goi " + count + " lan cho URL thu" + (err ? " | fetch loi: " + err : " | fetch OK"));
}
async function functionalWebRequest() {
  if (!(browser.webRequest && browser.webRequest.onBeforeRequest)) { add("[CHUC NANG] webRequest.onBeforeRequest: KHONG co API"); return; }
  var count = 0;
  var l = function () { count++; };
  try { browser.webRequest.onBeforeRequest.addListener(l, { urls: [TEST_URL] }); } catch (e) { add("[CHUC NANG] webRequest.addListener LOI -> " + String(e)); return; }
  try { await withTimeout(fetch(TEST_URL, { cache: "no-store" }), 9000); } catch (e) {}
  await sleep(500);
  try { browser.webRequest.onBeforeRequest.removeListener(l); } catch (e) {}
  add("[CHUC NANG] webRequest.onBeforeRequest: listener duoc goi " + count + " lan cho URL thu");
}

async function main() {
  add("probe bat dau; navigator.onLine=" + navigator.onLine);
  await call("runtime.getBrowserInfo", function () { return browser.runtime.getBrowserInfo(); });
  await call("runtime.getPlatformInfo", function () { return browser.runtime.getPlatformInfo(); });
  present("proxy.onRequest"); present("proxy.onError");
  await call("proxy.settings.get", function () { return browser.proxy.settings.get({}); });
  await call("browserSettings.proxyConfig.get", function () { return browser.browserSettings.proxyConfig.get({}); });
  await call("privacy.network.webRTCIPHandlingPolicy.get", function () { return browser.privacy.network.webRTCIPHandlingPolicy.get({}); });
  await call("privacy.network.peerConnectionEnabled.get", function () { return browser.privacy.network.peerConnectionEnabled.get({}); });
  present("webRequest.onBeforeRequest"); present("webRequest.onAuthRequired"); present("webRequest.onBeforeSendHeaders");
  present("webRequest.filterResponseData"); present("declarativeNetRequest");
  await call("management.getAll", function () { return browser.management.getAll().then(function (l) { return l.length + " addon"; }); });
  present("management.setEnabled");
  await call("cookies.getAllCookieStores", function () { return browser.cookies.getAllCookieStores(); });
  await call("tabs.query", function () { return browser.tabs.query({}).then(function (l) { return l.length + " tab"; }); });
  present("tabs.create"); present("windows.getAll"); present("webNavigation.onCompleted");
  present("notifications.create"); present("downloads.download"); present("contextMenus.create");
  present("alarms.create"); present("sidebarAction"); present("identity.launchWebAuthFlow");
  await call("storage.local.get", function () { return browser.storage.local.get(null).then(function () { return "ok"; }); });
  await functionalProxy();
  await functionalWebRequest();
  add("probe XONG");
}

connect();
main().catch(function (e) { add("probe loi: " + String(e)); });
