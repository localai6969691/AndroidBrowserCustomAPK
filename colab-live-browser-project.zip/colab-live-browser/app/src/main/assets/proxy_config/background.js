// Proxy rieng theo tung khe qua browser.proxy.onRequest — API CHUAN cua
// WebExtension (khong phai GeckoRuntimeSettings.arguments(), cach do da xac
// nhan KHONG hoat dong qua bao cao loi cong khai). Xac nhan huong nay dung
// qua Mozilla bug 1525486 (Secure Proxy team): "co the lam duoc bang chinh
// Proxy API san co trong WebExtension".
var proxyConfig = null;

try {
  var port = browser.runtime.connectNative("browser");
  port.onMessage.addListener(function (msg) {
    if (msg && msg.type === "proxy_config") {
      proxyConfig = msg.config;
    }
  });
} catch (e) {}

// Ban 7.64 — DO THAM (chi ghi log, KHONG doi hanh vi): proxy rieng theo VUNG chi lam duoc an toan neu proxy.onRequest phan biet duoc yeu cau thuoc vung nao
// (cookieStoreId / tabId). Ghi 8 yeu cau dau (chi HOST, khong URL day du) de biet GeckoView co dien cookieStoreId cho kho contextId hay khong.
var probeLeft = 45;
var probeSeen = {}; // 7.68: toi da 3 yeu cau cho MOI tabId (de thay duoc nhieu tab/vung khac nhau thay vi 8 yeu cau dau cua cung 1 tab)
function probe(details) {
  if (probeLeft <= 0 || !port2) return;
  var k = String(details.tabId);
  probeSeen[k] = (probeSeen[k] || 0) + 1;
  if (probeSeen[k] > 3) return;
  probeLeft--;
  var h = ""; try { h = new URL(details.url).hostname; } catch (e) {}
  try {
    port2.postMessage({ type: "proxy_probe", host: h, cookieStoreId: details.cookieStoreId === undefined ? "(khong co truong)" : String(details.cookieStoreId),
      tabId: details.tabId, incognito: details.incognito, reqType: details.type, keys: Object.keys(details).join(",") });
  } catch (e) {}
}
var port2 = (typeof port !== "undefined") ? port : null; // Ban 7.66: DUNG CHUNG cong voi cau hinh (de Kotlin giu mot cong duy nhat va day cau hinh moi bat cu luc nao)

// Ban 7.65 — PROXY RIENG CHO TAB AN DANH. Gecko chi goi listener nay cho yeu cau an danh KHI addon duoc phep chay trong an danh (private browsing allowed); khi do
// `details.incognito === true` (Mozilla bug 1545163, test_proxy_incognito.js). Truoc day addon KHONG duoc phep => tab an danh/vung an danh luon di THANG bang IP that
// du khe co proxy (mot khe co 2 IP cung luc, khong ai hay biet). Nay chon duoc: privateMode 0 = truc tiep (nhu cu), 1 = dung chung proxy cua khe, 2 = proxy rieng.
// Quyet dinh theo CHINH yeu cau (co co incognito) => khong co khe ho/ban tin nhu anh xa tabId, khong ro ri IP khi tab moi mo.
function pickConfig(details) {
  var c = proxyConfig;
  if (!c) return null;
  if (details.incognito) {
    if (c.privateMode === 1) return (c.enabled && c.host) ? { type: c.type, host: c.host, port: c.port, username: c.username, password: c.password } : null;
    if (c.privateMode === 2 && c.pHost) return { type: c.pType, host: c.pHost, port: c.pPort, username: c.pUser, password: c.pPass };
    return null; // 0 = truc tiep
  }
  return (c.enabled && c.host) ? { type: c.type, host: c.host, port: c.port, username: c.username, password: c.password } : null;
}

browser.proxy.onRequest.addListener(function (details) {
  probe(details);
  var cfg = pickConfig(details);
  // Muc 133: KHONG tra {type:"direct"} — tra undefined = de nguyen ket qua bo loc truoc (khong de len proxy cua addon VPN nguoi dung cai).
  if (!cfg) return undefined;
  return { type: cfg.type, host: cfg.host, port: cfg.port };
}, { urls: ["<all_urls>"] });

// Xac thuc user/pass cho proxy (neu co) — proxy thuong (residential/mobile)
// yeu cau dang nhap, khong xu ly se bi tu choi ket noi qua proxy.
browser.webRequest.onAuthRequired.addListener(function (details) {
  if (details.isProxy && proxyConfig) {
    var cfg = pickConfig(details);
    if (cfg && cfg.username) return { authCredentials: { username: cfg.username, password: cfg.password } };
  }
}, { urls: ["<all_urls>"] }, ["blocking"]);


// Ban 7.66 — DO THAM 2 (chi ghi log): API `tabs` tren GeckoView co phat onCreated/onUpdated kem URL khong? Neu co, co the danh dau tab vung bang URL tam
// (vd about:blank#lbz=<vung>) de anh xa tabId -> vung cho proxy rieng theo vung. Ghi toi da 10 su kien (chi HOST/phan #, khong ghi URL day du).
var tabProbeLeft = 40;
function tabProbe(kind, id, url, extra) {
  if (tabProbeLeft <= 0 || !port2) return;
  tabProbeLeft--;
  var u = ""; try { var x = new URL(url || "about:blank"); u = (x.protocol === "about:" ? x.href : x.hostname) + (x.hash || ""); } catch (e) { u = "?"; }
  try { port2.postMessage({ type: "proxy_probe_tab", kind: kind, tabId: id, url: u, extra: extra || "" }); } catch (e) {}
}
try {
  browser.tabs.onCreated.addListener(function (t) { tabProbe("onCreated", t.id, t.url, "cookieStoreId=" + t.cookieStoreId + " incognito=" + t.incognito + " openerTabId=" + t.openerTabId); });
  browser.tabs.onUpdated.addListener(function (id, change, t) { if (change.url) tabProbe("onUpdated", id, change.url, "cookieStoreId=" + (t && t.cookieStoreId)); });
} catch (e) {}
