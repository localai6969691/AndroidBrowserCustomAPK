// Proxy rieng theo tung khe qua browser.proxy.onRequest — API CHUAN cua
// WebExtension (khong phai GeckoRuntimeSettings.arguments(), cach do da xac
// nhan KHONG hoat dong qua bao cao loi cong khai). Xac nhan huong nay dung
// qua Mozilla bug 1525486 (Secure Proxy team): "co the lam duoc bang chinh
// Proxy API san co trong WebExtension".
//
// Ban 7.70:
//  - FAIL-CLOSED: addon chi tra DUNG 1 proxy cho moi yeu cau (khong bao gio kem {type:"direct"}), nen proxy chet => yeu cau LOI (Gecko hien trang
//    "proxy refusing connections"), KHONG tu roi ve IP that. Phia Kotlin con giu dieu huong http(s) cho den khi addon xac nhan (ack) da nhan cau hinh.
//  - Phat hien proxy chet (webRequest.onErrorOccurred co "PROXY" trong ma loi) va bao Kotlin (proxy_state down/up) de ghi log + thong bao nguoi dung.
//  - DO TU DONG, THU DONG (chi ghi log), tu dung khi du du lieu (proxy_probe_done).
var proxyConfig = null;
var proxyDown = false;
var lastDownReport = 0;

// Ban 7.70b — NOI LAI: log thuc te cho thay addon nay KHONG BAO GIO nhan duoc cau hinh (khong co dong "da day cau hinh proxy" nao) vi chi noi 1 lan, co the
// truoc khi Kotlin kip gan delegate (cookie_helper muc 138 da gap dung loi nay va giai bang vong noi lai). Nay: noi, gui "hello", thu lai moi 2s cho den khi nhan
// "proxy_config"; mat kenh thi noi lai (GIU NGUYEN proxyConfig cu de yeu cau van di qua proxy trong luc cho). Kotlin day cau hinh moi lan onConnect.
var port = null, gotConfig = false, attempts = 0;
function connectProxyChannel() {
  if (gotConfig) return;
  try { if (port) { try { port.disconnect(); } catch (e) {} port = null; port2 = null; } } catch (e) {}
  try {
    port = browser.runtime.connectNative("browser");
    port2 = port;
    port.onMessage.addListener(function (msg) {
      if (msg && msg.type === "proxy_config") {
        proxyConfig = msg.config;
        proxyDown = false; // cau hinh moi => thu lai tu dau
        gotConfig = true;
        // Xac nhan DA NHAN: Kotlin chi mo chot chan dieu huong sau tin nay.
        try { port.postMessage({ type: "proxy_ack", failClosed: !!(proxyConfig && proxyConfig.failClosed) }); } catch (e) {}
      }
    });
    port.onDisconnect.addListener(function () { port = null; port2 = null; gotConfig = false; attempts = 0; setTimeout(connectProxyChannel, 1500); });
    port.postMessage({ type: "hello", who: "proxy_config" });
  } catch (e) {}
  if (!gotConfig && ++attempts < 90) setTimeout(connectProxyChannel, 2000);
}
var port2 = null;
connectProxyChannel();

// ---- DO THAM (chi ghi log, KHONG doi hanh vi) ----
// Proxy rieng theo VUNG chi lam duoc an toan neu proxy.onRequest phan biet duoc yeu cau thuoc vung nao (cookieStoreId / tabId).
// Ban 7.70: tu dong (mac dinh bat), 2 yeu cau/tabId, toi da 120 yeu cau + 40 su kien tab, cua so 15 phut; xong thi gui TONG KET va Kotlin tu tat neu du du lieu.
var PROBE_REQ_BUDGET = 120, PROBE_PER_TAB = 2, PROBE_TAB_BUDGET = 40, PROBE_WINDOW_MS = 15 * 60 * 1000;
var probeLeft = PROBE_REQ_BUDGET;
var tabProbeLeft = PROBE_TAB_BUDGET;
var probeSeen = {};
var probeStats = { inc: 0, nonInc: 0, tabs: {}, stores: {} };
var probeDone = false;

function probeActive() { return !probeDone && !!port2 && !!proxyConfig && proxyConfig.probe === true; }

// Tab an danh: che bot host (khong luu lich su an danh vao log); Kotlin dung cung quy tac (GeckoRuntimeProvider.maskHostForProbe).
function maskHost(h, incognito) {
  if (!incognito || !h || h.length <= 6) return h;
  return h.substring(0, 2) + "~" + h.substring(h.length - 4);
}

function finishProbe(reason) {
  if (probeDone) return;
  probeDone = true;
  var nTabs = Object.keys(probeStats.tabs).length;
  var enough = probeStats.inc > 0 && probeStats.nonInc > 0 && nTabs >= 4;
  try {
    port2.postMessage({ type: "proxy_probe_done", reason: reason, enough: enough, inc: probeStats.inc, nonInc: probeStats.nonInc,
      tabs: nTabs, tabEvents: PROBE_TAB_BUDGET - tabProbeLeft, stores: Object.keys(probeStats.stores).join("; ") });
  } catch (e) {}
}
setTimeout(function () { if (probeActive()) finishProbe("het 15 phut"); }, PROBE_WINDOW_MS);

function probe(details) {
  if (!probeActive()) return;
  var k = String(details.tabId);
  var cs = details.cookieStoreId === undefined ? "(khong co truong)" : String(details.cookieStoreId);
  // Thong ke dem MOI yeu cau (khong chi yeu cau duoc ghi log).
  if (details.incognito) probeStats.inc++; else probeStats.nonInc++;
  probeStats.tabs[k] = true;
  probeStats.stores[(details.incognito ? "an danh" : "thuong") + "|" + cs] = true;
  probeSeen[k] = (probeSeen[k] || 0) + 1;
  if (probeSeen[k] > PROBE_PER_TAB) return;
  if (probeLeft <= 0) { finishProbe("het han muc yeu cau"); return; }
  probeLeft--;
  var h = ""; try { h = new URL(details.url).hostname; } catch (e) {}
  try {
    port2.postMessage({ type: "proxy_probe", host: maskHost(h, details.incognito), cookieStoreId: cs,
      tabId: details.tabId, incognito: details.incognito, reqType: details.type, keys: Object.keys(details).join(",") });
  } catch (e) {}
}

// Ban 7.65 — PROXY RIENG CHO TAB AN DANH. Gecko chi goi listener nay cho yeu cau an danh KHI addon duoc phep chay trong an danh (private browsing allowed); khi do
// `details.incognito === true` (Mozilla bug 1545163, test_proxy_incognito.js). Nay chon duoc: privateMode 0 = truc tiep (nhu cu), 1 = dung chung proxy cua khe, 2 = proxy rieng.
// Quyet dinh theo CHINH yeu cau (co co incognito) => khong co khe ho/ban tin nhu anh xa tabId, khong ro ri IP khi tab moi mo.
function pickConfig(details) {
  var c = proxyConfig;
  if (!c) return null;
  if (details.incognito) {
    if (c.privateMode === 1) return (c.enabled && c.host) ? { type: c.type, host: c.host, port: c.port, username: c.username, password: c.password } : null;
    if (c.privateMode === 2 && c.pHost) return { type: c.pType, host: c.pHost, port: c.pPort, username: c.pUser, password: c.pPass };
    return null; // 0 = truc tiep
  }
  return (c.enabled && c.host) ? { type: c.type, host: c.host, port: c.port, username: c.username, password: c.password } : null;
}

browser.proxy.onRequest.addListener(function (details) {
  probe(details);
  var cfg = pickConfig(details);
  // Muc 133: KHONG tra {type:"direct"} — tra undefined = de nguyen ket qua bo loc truoc (khong de len proxy cua addon VPN nguoi dung cai).
  // 7.70: cung vi vay KHONG bao gio kem {type:"direct"} vao danh sach de proxy chet khong roi ve IP that (fail-closed).
  if (!cfg) return undefined;
  return { type: cfg.type, host: cfg.host, port: cfg.port };
}, { urls: ["<all_urls>"] });

// Xac thuc user/pass cho proxy (neu co) — proxy thuong (residential/mobile)
// yeu cau dang nhap, khong xu ly se bi tu choi ket noi qua proxy.
browser.webRequest.onAuthRequired.addListener(function (details) {
  if (details.isProxy && proxyConfig) {
    var cfg = pickConfig(details);
    if (cfg && cfg.username) return { authCredentials: { username: cfg.username, password: cfg.password } };
  }
}, { urls: ["<all_urls>"] }, ["blocking"]);

// Ban 7.70 — PHAT HIEN PROXY CHET. Chi tinh yeu cau THUOC ve proxy (pickConfig != null). Khong co "khoa" theo thoi gian: moi yeu cau MOI deu thu lai proxy,
// nen proxy song lai la tu phuc hoi ngay yeu cau ke tiep (tai lai trang). Bao Kotlin khi chuyen trang thai, va nhac lai moi 30s neu van loi.
function reportState(state, err) { try { if (port2) port2.postMessage({ type: "proxy_state", state: state, error: err || "" }); } catch (e) {} }
try {
  browser.webRequest.onErrorOccurred.addListener(function (d) {
    if (!proxyConfig || !d || !d.error || !/PROXY/i.test(String(d.error))) return;
    if (!pickConfig(d)) return;
    var now = Date.now();
    if (!proxyDown) { proxyDown = true; lastDownReport = now; reportState("down", d.error); }
    else if (now - lastDownReport > 30000) { lastDownReport = now; reportState("down", d.error); }
  }, { urls: ["<all_urls>"] });
  browser.webRequest.onCompleted.addListener(function (d) {
    if (!proxyDown || !d || d.fromCache || !d.statusCode || d.statusCode < 100) return;
    if (!pickConfig(d)) return;
    proxyDown = false;
    reportState("up", "");
  }, { urls: ["<all_urls>"] });
} catch (e) {}

// Ban 7.66 — DO THAM 2 (chi ghi log): API `tabs` tren GeckoView co phat onCreated/onUpdated kem URL khong? Neu co, co the danh dau tab vung bang URL tam
// (vd about:blank#lbz=<vung>) de anh xa tabId -> vung cho proxy rieng theo vung. Chi ghi HOST/phan # (khong URL day du).
function tabProbe(kind, id, url, extra, incognito) {
  if (!probeActive() || tabProbeLeft <= 0) return;
  tabProbeLeft--;
  var u = ""; try { var x = new URL(url || "about:blank"); u = (x.protocol === "about:" ? x.href : maskHost(x.hostname, incognito)) + (x.hash || ""); } catch (e) { u = "?"; }
  try { port2.postMessage({ type: "proxy_probe_tab", kind: kind, tabId: id, url: u, extra: extra || "" }); } catch (e) {}
}
try {
  browser.tabs.onCreated.addListener(function (t) { tabProbe("onCreated", t.id, t.url, "cookieStoreId=" + t.cookieStoreId + " incognito=" + t.incognito + " openerTabId=" + t.openerTabId, t.incognito); });
  browser.tabs.onUpdated.addListener(function (id, change, t) { if (change.url) tabProbe("onUpdated", id, change.url, "cookieStoreId=" + (t && t.cookieStoreId) + " incognito=" + (t && t.incognito), t && t.incognito); });
} catch (e) {}
