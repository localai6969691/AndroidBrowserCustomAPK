// Proxy rieng theo tung khe qua browser.proxy.onRequest — API CHUAN cua
// WebExtension (khong phai GeckoRuntimeSettings.arguments(), cach do da xac
// nhan KHONG hoat dong qua bao cao loi cong khai). Xac nhan huong nay dung
// qua Mozilla bug 1525486 (Secure Proxy team): "co the lam duoc bang chinh
// Proxy API san co trong WebExtension".
//
// Ban 7.70:
//  - FAIL-CLOSED: addon chi tra DUNG 1 proxy cho moi yeu cau (khong bao gio kem {type:"direct"}), nen proxy chet => yeu cau LOI (Gecko hien trang
//    "proxy refusing connections"), KHONG tu roi ve IP that. Phia Kotlin con giu dieu huong http(s) cho den khi addon xac nhan (ack) da nhan cau hinh.
//  - Phat hien proxy chet (webRequest.onErrorOccurred co "PROXY" trong ma loi) va bao Kotlin (proxy_state down/up) de ghi log + thong bao nguoi dung.
//  - DO TU DONG, THU DONG (chi ghi log), tu dung khi du du lieu (proxy_probe_done).
var proxyConfig = null;
var proxyDown = false;
var lastDownReport = 0;

// Ban 7.71 — PROXY/VPN THEO VUNG. Bang chung tu log 7.70d: trong proxy.onRequest tab cua vung ben mang cookieStoreId="firefox-default" (KHONG phan biet duoc vung)
// nhung tabs.onCreated cho dung "firefox-container-zone_<id>"; tabId on dinh va onCreated den TRUOC yeu cau dau tien cua tab. Vi vay dung bang tabId -> vung (cach
// Container Proxy cua Firefox lam tren desktop). Tab AN DANH: tabs API chi cho "firefox-private" (khong phan biet vung) => app bao truoc (expect_tab, FIFO) vung cua tab
// sap mo; addon ghep voi tab an danh vua tao roi tra tab_mapped de app moi cho tai trang.
var tabZone = {};     // tabId -> id vung ("" = khong thuoc vung)
var expectQ = [];     // [{seq, zone}] do Kotlin bao truoc khi mo tab an danh
var orphanPriv = [];  // tabId an danh vua tao, chua ghep
var zoneHitSeen = {};
var DIRECT_RULE = { direct: true };
var PASS_RULE = { pass: true };

// Ban 7.70b — NOI LAI: log thuc te cho thay addon nay KHONG BAO GIO nhan duoc cau hinh (khong co dong "da day cau hinh proxy" nao) vi chi noi 1 lan, co the
// truoc khi Kotlin kip gan delegate (cookie_helper muc 138 da gap dung loi nay va giai bang vong noi lai). Nay: noi, gui "hello", thu lai moi 2s cho den khi nhan
// "proxy_config"; mat kenh thi noi lai (GIU NGUYEN proxyConfig cu de yeu cau van di qua proxy trong luc cho). Kotlin day cau hinh moi lan onConnect.
var port = null, gotConfig = false, attempts = 0;
function connectProxyChannel() {
  if (gotConfig) return;
  try { if (port) { try { port.disconnect(); } catch (e) {} port = null; port2 = null; } } catch (e) {}
  try {
    port = browser.runtime.connectNative("browser");
    port2 = port;
    port.onMessage.addListener(function (msg) {
      if (msg && msg.type === "proxy_config") {
        proxyConfig = msg.config;
        proxyDown = false; // cau hinh moi => thu lai tu dau
        gotConfig = true;
        // Xac nhan DA NHAN: Kotlin chi mo chot chan dieu huong sau tin nay.
        try { port.postMessage({ type: "proxy_ack", failClosed: !!(proxyConfig && proxyConfig.failClosed) }); } catch (e) {}
        // Tab vung ben da mo san (khoi phuc truoc khi addon noi kenh): doc lai cookieStoreId tu tabs API.
        try { browser.tabs.query({}).then(function (ts) { ts.forEach(function (t) { if (!t.incognito) mapTab(t); }); }); } catch (e) {}
      } else if (msg && msg.type === "expect_tab") {
        expectQ.push({ seq: msg.seq, zone: msg.zone || "" });
        pairPriv();
      } else if (msg && msg.type === "probe_zone") {
        probeZoneEgress(String(msg.zone || ""), msg.reqId);
      } else if (msg && msg.type === "lang_map") {
        langMap = msg.map || {};
        // 7.90: cờ "ghép tab ẩn danh với vùng để chọn ngôn ngữ riêng". Đổi cờ => bắt đầu kỷ nguyên ghép MỚI (xoá hàng đợi) để tab/khai báo cũ không ghép nhầm.
        var pm = !!msg.privMap;
        if (pm !== privMapOn) { privMapOn = pm; expectQ = []; orphanPriv = []; }
      }
    });
    port.onDisconnect.addListener(function () { port = null; port2 = null; gotConfig = false; attempts = 0; setTimeout(connectProxyChannel, 1500); });
    port.postMessage({ type: "hello", who: "proxy_config" });
  } catch (e) {}
  if (!gotConfig && ++attempts < 90) setTimeout(connectProxyChannel, 2000);
}
var langMap = {}; // 7.89/7.90: khoa -> chuoi Accept-Language (app day xuong, xem GeckoViewEngine.pushAcceptLanguageMap). Khoa: "firefox-default" (lop thuong), "firefox-private" (an danh), "zone:<id>" (tung vung)
var privMapOn = false; // 7.90: app dang bao truoc (expect_tab) moi tab an danh de addon biet VUNG cua no (chon ngon ngu rieng cho tung vung an danh khong ben)
var port2 = null;
connectProxyChannel();

// Ban 7.88 — BANG CHUNG HEADER HTTP THAT. Cac trang kiem tra ben thu 3 (va Google chon ngon ngu giao dien) doc HEADER HTTP chu khong chi JavaScript. fp-selftest chi kiem JS
// (navigator.*); header User-Agent theo vung duoc dat bang session.settings.userAgentOverride, con Accept-Language la cai dat CHUNG cua ca khe (xem muc 7.64). Truoc day khong co cach nao
// thay header THAT da gui. Nay moi cap (host, vung) ghi MOT dong dau tien: tab, vung, UA va Accept-Language THAT (toi da 60 dong/tien trinh). Chi doc, KHONG doi hanh vi.
var hdrSeen = {}, hdrLeft = 60;
try {
  browser.webRequest.onSendHeaders.addListener(function (d) {
    try {
      if (hdrLeft <= 0 || !port2 || d.type !== "main_frame") return;
      var host = ""; try { host = new URL(d.url).host; } catch (e) { return; }
      var zone = (typeof tabZone !== "undefined" && tabZone[d.tabId]) || "";
      var ua = "", al = "";
      (d.requestHeaders || []).forEach(function (h) { var n = (h.name || "").toLowerCase(); if (n === "user-agent") ua = h.value; else if (n === "accept-language") al = h.value; });
      // 7.89: khoa gom them Accept-Language de DOI ngon ngu giua chung (VD VPN bat/tat, ghi de theo lop) van ghi lai dong moi.
      var key = host + "|" + zone + "|" + (d.incognito ? 1 : 0) + "|" + al;
      if (hdrSeen[key]) return; hdrSeen[key] = 1; hdrLeft--;
      port2.postMessage({ type: "http_headers", host: maskHost(host, d.incognito), zone: zone, tabId: d.tabId, incognito: !!d.incognito, ua: ua, al: al,
        cs: d.cookieStoreId === undefined ? "(khong co truong)" : String(d.cookieStoreId), lk: langKeyFor(d) });
    } catch (e) {}
  }, { urls: ["<all_urls>"], types: ["main_frame"] }, ["requestHeaders"]);
} catch (e) {}

// ---- DO THAM (chi ghi log, KHONG doi hanh vi) ----
// Proxy rieng theo VUNG chi lam duoc an toan neu proxy.onRequest phan biet duoc yeu cau thuoc vung nao (cookieStoreId / tabId).
// Ban 7.70: tu dong (mac dinh bat), 2 yeu cau/tabId, toi da 120 yeu cau + 40 su kien tab, cua so 15 phut; xong thi gui TONG KET va Kotlin tu tat neu du du lieu.
var PROBE_REQ_BUDGET = 120, PROBE_PER_TAB = 2, PROBE_TAB_BUDGET = 40, PROBE_WINDOW_MS = 15 * 60 * 1000;
var probeLeft = PROBE_REQ_BUDGET;
var tabProbeLeft = PROBE_TAB_BUDGET;
var probeSeen = {};
var probeStats = { inc: 0, nonInc: 0, tabs: {}, stores: {} };
var probeDone = false;

function probeActive() { return !probeDone && !!port2 && !!proxyConfig && proxyConfig.probe === true; }

// Tab an danh: che bot host (khong luu lich su an danh vao log); Kotlin dung cung quy tac (GeckoRuntimeProvider.maskHostForProbe).
function maskHost(h, incognito) {
  if (!incognito || !h || h.length <= 6) return h;
  return h.substring(0, 2) + "~" + h.substring(h.length - 4);
}

function finishProbe(reason) {
  if (probeDone) return;
  probeDone = true;
  var nTabs = Object.keys(probeStats.tabs).length;
  var enough = probeStats.inc > 0 && probeStats.nonInc > 0 && nTabs >= 4;
  try {
    port2.postMessage({ type: "proxy_probe_done", reason: reason, enough: enough, inc: probeStats.inc, nonInc: probeStats.nonInc,
      tabs: nTabs, tabEvents: PROBE_TAB_BUDGET - tabProbeLeft, stores: Object.keys(probeStats.stores).join("; ") });
  } catch (e) {}
}
setTimeout(function () { if (probeActive()) finishProbe("het 15 phut"); }, PROBE_WINDOW_MS);

function probe(details) {
  if (!probeActive()) return;
  var k = String(details.tabId);
  var cs = details.cookieStoreId === undefined ? "(khong co truong)" : String(details.cookieStoreId);
  // Thong ke dem MOI yeu cau (khong chi yeu cau duoc ghi log).
  if (details.incognito) probeStats.inc++; else probeStats.nonInc++;
  probeStats.tabs[k] = true;
  probeStats.stores[(details.incognito ? "an danh" : "thuong") + "|" + cs] = true;
  probeSeen[k] = (probeSeen[k] || 0) + 1;
  if (probeSeen[k] > PROBE_PER_TAB) return;
  if (probeLeft <= 0) { finishProbe("het han muc yeu cau"); return; }
  probeLeft--;
  var h = ""; try { h = new URL(details.url).hostname; } catch (e) {}
  try {
    port2.postMessage({ type: "proxy_probe", host: maskHost(h, details.incognito), cookieStoreId: cs,
      tabId: details.tabId, incognito: details.incognito, reqType: details.type, keys: Object.keys(details).join(",") });
  } catch (e) {}
}

// Ban 7.65 — PROXY RIENG CHO TAB AN DANH. Gecko chi goi listener nay cho yeu cau an danh KHI addon duoc phep chay trong an danh (private browsing allowed); khi do
// `details.incognito === true` (Mozilla bug 1545163, test_proxy_incognito.js). Nay chon duoc: privateMode 0 = truc tiep (nhu cu), 1 = dung chung proxy cua khe, 2 = proxy rieng.
// Quyet dinh theo CHINH yeu cau (co co incognito) => khong co khe ho/ban tin nhu anh xa tabId, khong ro ri IP khi tab moi mo.
function zoneFromStore(cs) { var m = /^firefox-container-zone_(.+)$/.exec(String(cs || "")); return m ? m[1] : ""; }
function pairPriv() {
  while (expectQ.length && orphanPriv.length) {
    var e = expectQ.shift(), tid = orphanPriv.shift();
    tabZone[tid] = e.zone || "";
    try { if (port2) port2.postMessage({ type: "tab_mapped", seq: e.seq, tabId: tid, zone: e.zone || "" }); } catch (x) {}
  }
}
function mapTab(t) {
  if (!t || t.id === undefined || t.id < 0) return;
  if (t.incognito) {
    // Chi theo doi tab an danh khi dang co quy tac vung an danh (app moi bao truoc cho moi tab an danh); neu khong thi hang doi FIFO se lech.
    // 7.90: HOAC khi app bat co privMapOn (lang_map) vi can biet vung cua tab an danh de chon Accept-Language rieng cua vung.
    if (!((proxyConfig && proxyConfig.zonePriv) || privMapOn)) return;
    if (tabZone[t.id] === undefined && orphanPriv.indexOf(t.id) < 0) { orphanPriv.push(t.id); pairPriv(); }
  } else {
    tabZone[t.id] = zoneFromStore(t.cookieStoreId);
  }
}
// Ban 7.91 — DO IP RA CUA VUNG KHONG CAN TRANG. App can biet IP/quoc gia/mui gio that ma mot vung co duong ra RIENG (proxy rieng / truc tiep) di ra TRUOC KHI tai trang dau tien
// cua vung (de gia dung danh tinh; chua gia duoc thi app giu trang lai). Cac cach cu (content script do trong tab) can mot trang da tai => bi vong tron. Nay addon nay tu fetch
// dich vu echo IP tu trang nen (tabId = -1) va them dau `lb_zp=<id vung>` vao URL; proxy.onRequest/onAuthRequired nhan ra dau do va chon DUNG quy tac cua vung (cung `c.zones[...]`
// ma tab cua vung dung) => yeu cau di ra bang dung duong mang cua vung. Dau chi o chuoi truy van gui toi dich vu echo, khong lo thong tin nao khac.
var ZP_PARAM = "lb_zp";
function zoneProbeId(details) {
  try {
    if (!details || !details.url) return "";
    if (details.tabId !== undefined && details.tabId >= 0) return "";
    if (String(details.url).indexOf(ZP_PARAM + "=") < 0) return "";
    return new URL(details.url).searchParams.get(ZP_PARAM) || "";
  } catch (e) { return ""; }
}
// Quy tac cua vung chua tab nay (null = tab khong thuoc vung hoac vung theo khe). Yeu cau do (tabId<0 + lb_zp) lay quy tac theo dau.
function zoneRule(details) {
  var c = proxyConfig;
  if (!c || !c.zones) return null;
  var zp = zoneProbeId(details);
  if (zp) return c.zones[zp] || null;
  if (details.tabId === undefined || details.tabId < 0) return null;
  var z = tabZone[details.tabId];
  if (!z) return null;
  return c.zones[z] || null;
}
function pickConfig(details) {
  var c = proxyConfig;
  if (!c) return null;
  var zr = zoneRule(details);
  if (zr) {
    // m: 1 = proxy rieng cua vung, 2 = truc tiep (bo qua proxy khe, co the de len ca addon VPN — CHUA kiem chung), 3 = de nguyen (addon VPN xu ly, khong dung proxy khe)
    if (zr.m === 1 && zr.h) return { type: zr.t, host: zr.h, port: zr.p, username: zr.u, password: zr.w };
    if (zr.m === 2) return DIRECT_RULE;
    if (zr.m === 3) return PASS_RULE;
  }
  // 7.91: yêu cầu đo lớp ẨN DANH chung (lb_zp=@p) — yêu cầu nền không mang cờ incognito nên giả lập đúng quy tắc của lớp ẩn danh.
  if (details.incognito || zoneProbeId(details) === "@p") {
    if (c.privateMode === 1) return (c.enabled && c.host) ? { type: c.type, host: c.host, port: c.port, username: c.username, password: c.password } : null;
    if (c.privateMode === 2 && c.pHost) return { type: c.pType, host: c.pHost, port: c.pPort, username: c.pUser, password: c.pPass };
    return null; // 0 = truc tiep
  }
  return (c.enabled && c.host) ? { type: c.type, host: c.host, port: c.port, username: c.username, password: c.password } : null;
}

browser.proxy.onRequest.addListener(function (details) {
  var zpid = zoneProbeId(details);
  if (!zpid) probe(details);
  var cfg = pickConfig(details);
  // Bang chung de kiem chung quy tac vung dang chay that: bao app 1 lan cho moi (vung, che do).
  var zr = zoneRule(details);
  if (zr && !zpid) {
    var zk = tabZone[details.tabId] + "|" + zr.m;
    if (!zoneHitSeen[zk]) {
      zoneHitSeen[zk] = true;
      var zh = ""; try { zh = new URL(details.url).hostname; } catch (e) {}
      try { if (port2) port2.postMessage({ type: "zone_hit", zone: tabZone[details.tabId], mode: zr.m, tabId: details.tabId, host: maskHost(zh, details.incognito) }); } catch (e) {}
    }
  }
  // Muc 133: KHONG tra {type:"direct"} cho khe thuong — tra undefined = de nguyen ket qua bo loc truoc (khong de len proxy cua addon VPN nguoi dung cai).
  // 7.70: KHONG bao gio kem {type:"direct"} vao danh sach proxy de proxy chet khong roi ve IP that (fail-closed).
  // 7.71: NGOAI LE co chu y: vung dat che do "truc tiep" (2) thi tra direct DON LE (khong kem proxy nao).
  if (!cfg) return undefined;
  if (cfg.pass) return undefined;
  if (cfg.direct) return { type: "direct" };
  return { type: cfg.type, host: cfg.host, port: cfg.port };
}, { urls: ["<all_urls>"] });

// Ban 7.91 — do IP ra cua mot vung (xem chu thich o zoneRule). Hai dich vu theo thu tu; dich vu dau loi/het han 8s thi thu dich vu sau. Tra ve app: zone_egress {zone, reqId, ip, cc, tz, how}
// hoac {zone, reqId, error}. Chua nhan cau hinh proxy thi bao loi ngay (app se thu lai).
var ZP_SERVICES = [
  { url: "https://ipwho.is/?fields=ip,success,message,country_code,timezone", parse: function (j) {
      if (!j || j.success === false || !j.ip) throw new Error("ipwho.is: " + ((j && j.message) || "khong co ip"));
      return { ip: String(j.ip), cc: String(j.country_code || ""), tz: String((j.timezone && j.timezone.id) || "") }; } },
  { url: "https://get.geojs.io/v1/ip/geo.json", parse: function (j) {
      if (!j || !j.ip) throw new Error("geojs: khong co ip");
      return { ip: String(j.ip), cc: String(j.country_code || ""), tz: String(j.timezone || "") }; } }
];
function zpUrl(u, zone) { return u + (u.indexOf("?") < 0 ? "?" : "&") + ZP_PARAM + "=" + encodeURIComponent(zone); }
function probeZoneEgress(zone, reqId) {
  var done = false;
  function send(o) { if (done) return; done = true; o.type = "zone_egress"; o.zone = zone; o.reqId = reqId; try { if (port2) port2.postMessage(o); } catch (e) {} }
  if (!zone) { send({ error: "thieu id vung" }); return; }
  if (!proxyConfig) { send({ error: "addon chua nhan cau hinh proxy" }); return; }
  var i = 0;
  function next(lastErr) {
    if (i >= ZP_SERVICES.length) { send({ error: String(lastErr || "khong do duoc") }); return; }
    var svc = ZP_SERVICES[i++];
    var ac = (typeof AbortController !== "undefined") ? new AbortController() : null;
    var timer = ac ? setTimeout(function () { try { ac.abort(); } catch (e) {} }, 8000) : null;
    fetch(zpUrl(svc.url, zone), { cache: "no-store", credentials: "omit", signal: ac ? ac.signal : undefined })
      .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
      .then(function (j) {
        if (timer) clearTimeout(timer);
        var o = svc.parse(j); o.how = "proxy_config.fetch#" + i; send(o);
      })
      .catch(function (e) { if (timer) clearTimeout(timer); next((e && e.message) || e); });
  }
  next("");
}

// Xac thuc user/pass cho proxy (neu co) — proxy thuong (residential/mobile)
// yeu cau dang nhap, khong xu ly se bi tu choi ket noi qua proxy.
browser.webRequest.onAuthRequired.addListener(function (details) {
  if (details.isProxy && proxyConfig) {
    var cfg = pickConfig(details);
    if (cfg && cfg.username) return { authCredentials: { username: cfg.username, password: cfg.password } };
  }
}, { urls: ["<all_urls>"] }, ["blocking"]);

// Ban 7.70 — PHAT HIEN PROXY CHET. Chi tinh yeu cau THUOC ve proxy (pickConfig != null). Khong co "khoa" theo thoi gian: moi yeu cau MOI deu thu lai proxy,
// nen proxy song lai la tu phuc hoi ngay yeu cau ke tiep (tai lai trang). Bao Kotlin khi chuyen trang thai, va nhac lai moi 30s neu van loi.
function reportState(state, err) { try { if (port2) port2.postMessage({ type: "proxy_state", state: state, error: err || "" }); } catch (e) {} }
try {
  browser.webRequest.onErrorOccurred.addListener(function (d) {
    if (!proxyConfig || !d || !d.error || !/PROXY/i.test(String(d.error))) return;
    var pc = pickConfig(d);
    if (!pc || !pc.host) return;
    var now = Date.now();
    if (!proxyDown) { proxyDown = true; lastDownReport = now; reportState("down", d.error); }
    else if (now - lastDownReport > 30000) { lastDownReport = now; reportState("down", d.error); }
  }, { urls: ["<all_urls>"] });
  browser.webRequest.onCompleted.addListener(function (d) {
    if (!proxyDown || !d || d.fromCache || !d.statusCode || d.statusCode < 100) return;
    var pc2 = pickConfig(d);
    if (!pc2 || !pc2.host) return;
    proxyDown = false;
    reportState("up", "");
  }, { urls: ["<all_urls>"] });
} catch (e) {}

// Ban 7.76 — "VPN TAP": ghi lai may chu proxy (kieu/host/cong, co/khong user) ma CHINH Gecko bao da dung cho request KHONG do addon nay gan proxy (tuc la do addon VPN
// nhu Browsec gan). Chi dung API webRequest chinh thuc (details.proxyInfo), KHONG doc kho du lieu cua addon khac, KHONG ghi mat khau (API khong tra mat khau). Muc dich: biet
// VPN dang di qua dau va cach xac thuc ra sao, de quyet dinh co ket noi truc tiep duoc hay khong DUA TREN DU LIEU.
var vpnTapSeen = {}, vpnTapCount = 0;
try {
  browser.webRequest.onCompleted.addListener(function (d) {
    try {
      var pi = d && d.proxyInfo; if (!pi || !pi.host || vpnTapCount >= 20 || !port2) return;
      var mine = pickConfig(d);
      if (mine && mine.host && String(mine.host) === String(pi.host) && String(mine.port) === String(pi.port)) return; // proxy do chinh addon nay gan
      var key = pi.type + "|" + pi.host + "|" + pi.port;
      if (vpnTapSeen[key]) return; vpnTapSeen[key] = true; vpnTapCount++;
      var rh = ""; try { rh = new URL(d.url).hostname; } catch (e) {}
      port2.postMessage({ type: "vpn_tap", ptype: pi.type, host: pi.host, port: pi.port, hasUser: !!pi.username, dns: !!pi.proxyDNS, tabId: d.tabId, zone: tabZone[d.tabId] || "", req: maskHost(rh, d.incognito) });
    } catch (e) {}
  }, { urls: ["<all_urls>"] });
} catch (e) {}

// Ban 7.66 — DO THAM 2 (chi ghi log): API `tabs` tren GeckoView co phat onCreated/onUpdated kem URL khong? Neu co, co the danh dau tab vung bang URL tam
// (vd about:blank#lbz=<vung>) de anh xa tabId -> vung cho proxy rieng theo vung. Chi ghi HOST/phan # (khong URL day du).
function tabProbe(kind, id, url, extra, incognito) {
  if (!probeActive() || tabProbeLeft <= 0) return;
  tabProbeLeft--;
  var u = ""; try { var x = new URL(url || "about:blank"); u = (x.protocol === "about:" ? x.href : maskHost(x.hostname, incognito)) + (x.hash || ""); } catch (e) { u = "?"; }
  try { port2.postMessage({ type: "proxy_probe_tab", kind: kind, tabId: id, url: u, extra: extra || "" }); } catch (e) {}
}
try {
  browser.tabs.onCreated.addListener(function (t) { mapTab(t); });
  browser.tabs.onUpdated.addListener(function (id, change, t) { if (t && tabZone[id] === undefined && !t.incognito) mapTab(t); });
  browser.tabs.onRemoved.addListener(function (id) { delete tabZone[id]; var i = orphanPriv.indexOf(id); if (i >= 0) orphanPriv.splice(i, 1); });
} catch (e) {}
try {
  browser.tabs.onCreated.addListener(function (t) { tabProbe("onCreated", t.id, t.url, "cookieStoreId=" + t.cookieStoreId + " incognito=" + t.incognito + " openerTabId=" + t.openerTabId, t.incognito); });
  browser.tabs.onUpdated.addListener(function (id, change, t) { if (change.url) tabProbe("onUpdated", id, change.url, "cookieStoreId=" + (t && t.cookieStoreId) + " incognito=" + (t && t.incognito), t && t.incognito); });
} catch (e) {}

// Ban 7.89 — GHI DE HEADER Accept-Language THEO LOP. Gecko chi co MOT Accept-Language chung cho ca khe (theo lop thuong), nen tab an danh va vung ben di thang khong qua VPN
// van gui ngon ngu cua lop thuong (log 12:14: an danh IP=VN, JS=vi-VN nhung header nl-NL). Moi lop gio gui dung ngon ngu cua chinh no (cung nguon voi navigator.languages).
// Ban 7.90 — THEO VUNG. (a) Vung BEN: webRequest co the bao cookieStoreId="firefox-default" cho tab vung (bang chung 7.70d cua proxy.onRequest; tabs API moi cho
// "firefox-container-zone_<id>"), nen 7.89 tra khoa theo details.cookieStoreId co the roi ve lop thuong => nay tra theo tabId -> vung (tabZone, tu tabs API) TRUOC.
// (b) Vung AN DANH khong ben: moi tab an danh deu la "firefox-private"; app bao truoc (expect_tab) vung cua tung tab an danh va addon ghep FIFO (cung co che cua proxy vung, muc 7.71)
// => tabZone[tabId] co ca vung an danh. Khoa ngon ngu: "zone:<id>" neu vung co ngon ngu rieng, khong thi theo lop ("firefox-private" / "firefox-default").
function langKeyFor(d) {
  var z = "";
  if (d.tabId !== undefined && d.tabId >= 0 && tabZone[d.tabId]) z = tabZone[d.tabId];
  else z = zoneFromStore(d.cookieStoreId);
  if (z && langMap["zone:" + z]) return "zone:" + z;
  var cs = d.cookieStoreId;
  if (d.incognito) return "firefox-private";
  if (cs && langMap[cs]) return cs;
  return "firefox-default";
}
try {
  browser.webRequest.onBeforeSendHeaders.addListener(function (d) {
    try {
      var want = langMap[langKeyFor(d)];
      if (!want) return {};
      var hs = d.requestHeaders || [], i;
      for (i = 0; i < hs.length; i++) {
        if ((hs[i].name || "").toLowerCase() === "accept-language") {
          if (hs[i].value === want) return {};
          hs[i].value = want;
          return { requestHeaders: hs };
        }
      }
      hs.push({ name: "Accept-Language", value: want });
      return { requestHeaders: hs };
    } catch (e) { return {}; }
  }, { urls: ["<all_urls>"] }, ["blocking", "requestHeaders"]);
} catch (e) {}
